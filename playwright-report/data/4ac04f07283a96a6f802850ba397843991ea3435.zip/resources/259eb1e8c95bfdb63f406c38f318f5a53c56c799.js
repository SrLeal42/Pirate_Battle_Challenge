import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/HUD.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import { useGameStore } from "/src/stores/gameStore.ts";
import { GAME_CONFIG } from "/src/core/config.ts";
import { getHealthTier } from "/src/core/health.ts";
import { CONTROLS_BY_ACTION, CONTROL_ICON_PATH, TOUCH_INPUT_EVENT } from "/src/input/controls.ts";
import { AssetBar } from "/src/ui/components/AssetBar.tsx";
import styles from "/src/ui/components/HUD.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/HUD.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
const TIER_COLOR = {
	high: "green",
	medium: "amber",
	low: "red"
};
const emitTouch = (action, state) => {
	window.dispatchEvent(new CustomEvent(TOUCH_INPUT_EVENT, { detail: {
		action,
		state
	} }));
};
const TouchButton = ({ action, area }) => {
	const { label, icon } = CONTROLS_BY_ACTION[action];
	return /* @__PURE__ */ _jsxDEV("button", {
		type: "button",
		className: styles.touchButton,
		style: { gridArea: area },
		"aria-label": label,
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			emitTouch(action, true);
		},
		// Fires on pointerup, pointercancel and implicit capture loss
		onLostPointerCapture: () => emitTouch(action, false),
		onContextMenu: (e) => e.preventDefault(),
		children: /* @__PURE__ */ _jsxDEV("img", {
			src: `${CONTROL_ICON_PATH}${icon}`,
			className: styles.touchIcon,
			alt: "",
			"aria-hidden": "true",
			draggable: false
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 9
	}, this);
};
_c = TouchButton;
const formatTime = (ms) => {
	const total = Math.ceil(ms / 1e3);
	return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
};
export const HUD = ({ onPause }) => {
	_s();
	const health = useGameStore((s) => s.playerHealth);
	const timeRemaining = useGameStore((s) => s.timeRemaining);
	const score = useGameStore((s) => s.score);
	const maxHealth = GAME_CONFIG.playerMaxHealth;
	const currentHealth = Math.max(0, Math.ceil(health));
	const healthRatio = currentHealth / maxHealth;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: styles.container,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.healthWrapper,
				children: /* @__PURE__ */ _jsxDEV(AssetBar, {
					ratio: healthRatio,
					color: TIER_COLOR[getHealthTier(healthRatio)],
					label: `${currentHealth} / ${maxHealth}`,
					role: "meter",
					"aria-label": "Health",
					"aria-valuemin": 0,
					"aria-valuemax": maxHealth,
					"aria-valuenow": currentHealth,
					"aria-valuetext": `${currentHealth} of ${maxHealth}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.statsWrapper,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: styles.counter,
					children: [/* @__PURE__ */ _jsxDEV("img", {
						src: "/assets/png/default/ui/hud/icon_score.png",
						alt: "Score",
						className: styles.icon
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: styles.value,
						children: score
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: styles.counter,
					children: [/* @__PURE__ */ _jsxDEV("img", {
						src: "/assets/png/default/ui/hud/icon_time.png",
						alt: "Time remaining",
						className: styles.icon
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: styles.value,
						children: formatTime(timeRemaining)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.pauseContainer,
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: styles.pauseButton,
					onClick: onPause,
					"aria-label": "Pause game",
					children: /* @__PURE__ */ _jsxDEV("img", {
						src: `${CONTROL_ICON_PATH}icon_pause.png`,
						className: styles.pauseIcon,
						alt: "",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 21
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.touchControls,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: styles.leftControls,
					children: [
						/* @__PURE__ */ _jsxDEV(TouchButton, {
							action: "thrust",
							area: "up"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV(TouchButton, {
							action: "turnLeft",
							area: "left"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV(TouchButton, {
							action: "turnRight",
							area: "right"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: styles.rightControls,
					children: [
						/* @__PURE__ */ _jsxDEV(TouchButton, {
							action: "fireFront",
							area: "front"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV(TouchButton, {
							action: "fireLeft",
							area: "left"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV(TouchButton, {
							action: "fireRight",
							area: "right"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 9
	}, this);
};
_s(HUD, "L3t4Vq8GV83XS+GzyQ3Zx88JItE=", false, function() {
	return [
		useGameStore,
		useGameStore,
		useGameStore
	];
});
_c2 = HUD;
var _c, _c2;
$RefreshReg$(_c, "TouchButton");
$RefreshReg$(_c2, "HUD");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/HUD.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/HUD.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/HUD.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/HUD.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMscUJBQXNDO0FBQy9DLFNBQ0ksb0JBQW9CLG1CQUFtQix5QkFFcEM7QUFDUCxTQUFTLGdCQUErQjtBQUN4QyxPQUFPLFlBQVk7Ozs7QUFFbkIsTUFBTSxhQUEyQztDQUFFLE1BQU07Q0FBUyxRQUFRO0NBQVMsS0FBSztBQUFNO0FBRTlGLE1BQU0sYUFBYSxRQUFvQixVQUF5QjtDQUM1RCxPQUFPLGNBQWMsSUFBSSxZQUE4QixtQkFBbUIsRUFBRSxRQUFRO0VBQUU7RUFBUTtDQUFNLEVBQUUsQ0FBQyxDQUFDO0FBQzVHO0FBRUEsTUFBTSxlQUErRCxFQUFFLFFBQVEsV0FBVztDQUN0RixNQUFNLEVBQUUsT0FBTyxTQUFTLG1CQUFtQjtDQUUzQyxPQUNJLHdCQUFDLFVBQUQ7RUFDSSxNQUFLO0VBQ0wsV0FBVyxPQUFPO0VBQ2xCLE9BQU8sRUFBRSxVQUFVLEtBQUs7RUFDeEIsY0FBWTtFQUNaLGdCQUFnQixNQUFNO0dBQ2xCLEVBQUUsY0FBYyxrQkFBa0IsRUFBRSxTQUFTO0dBQzdDLFVBQVUsUUFBUSxJQUFJO0VBQzFCOztFQUVBLDRCQUE0QixVQUFVLFFBQVEsS0FBSztFQUNuRCxnQkFBZ0IsTUFBTSxFQUFFLGVBQWU7WUFFdkMsd0JBQUMsT0FBRDtHQUFLLEtBQUssR0FBRyxvQkFBb0I7R0FBUSxXQUFXLE9BQU87R0FBVyxLQUFJO0dBQUcsZUFBWTtHQUFPLFdBQVc7RUFBUTs7Ozs7Q0FDL0c7Ozs7O0FBRWhCOztBQUVBLE1BQU0sY0FBYyxPQUF1QjtDQUN2QyxNQUFNLFFBQVEsS0FBSyxLQUFLLEtBQUssR0FBSTtDQUNqQyxPQUFPLEdBQUcsS0FBSyxNQUFNLFFBQVEsRUFBRSxFQUFFLEdBQUcsT0FBTyxRQUFRLEVBQUUsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0FBQzFFO0FBTUEsT0FBTyxNQUFNLE9BQTJCLEVBQUUsY0FBYzs7Q0FDcEQsTUFBTSxTQUFTLGNBQWMsTUFBTSxFQUFFLFlBQVk7Q0FDakQsTUFBTSxnQkFBZ0IsY0FBYyxNQUFNLEVBQUUsYUFBYTtDQUN6RCxNQUFNLFFBQVEsY0FBYyxNQUFNLEVBQUUsS0FBSztDQUV6QyxNQUFNLFlBQVksWUFBWTtDQUM5QixNQUFNLGdCQUFnQixLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssTUFBTSxDQUFDO0NBQ25ELE1BQU0sY0FBYyxnQkFBZ0I7Q0FFcEMsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVyxPQUFPO1lBQXZCO0dBQ0ksd0JBQUMsT0FBRDtJQUFLLFdBQVcsT0FBTztjQUNuQix3QkFBQyxVQUFEO0tBQ0ksT0FBTztLQUNQLE9BQU8sV0FBVyxjQUFjLFdBQVc7S0FDM0MsT0FBTyxHQUFHLGNBQWMsS0FBSztLQUM3QixNQUFLO0tBQ0wsY0FBVztLQUNYLGlCQUFlO0tBQ2YsaUJBQWU7S0FDZixpQkFBZTtLQUNmLGtCQUFnQixHQUFHLGNBQWMsTUFBTTtJQUMxQzs7Ozs7R0FDQTs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVyxPQUFPO2NBQXZCLENBQ0ksd0JBQUMsT0FBRDtLQUFLLFdBQVcsT0FBTztlQUF2QixDQUNJLHdCQUFDLE9BQUQ7TUFBSyxLQUFJO01BQTRDLEtBQUk7TUFBUSxXQUFXLE9BQU87S0FBTzs7OztlQUMxRix3QkFBQyxRQUFEO01BQU0sV0FBVyxPQUFPO2dCQUFRO0tBQVk7Ozs7YUFDM0M7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVcsT0FBTztlQUF2QixDQUNJLHdCQUFDLE9BQUQ7TUFBSyxLQUFJO01BQTJDLEtBQUk7TUFBaUIsV0FBVyxPQUFPO0tBQU87Ozs7ZUFDbEcsd0JBQUMsUUFBRDtNQUFNLFdBQVcsT0FBTztnQkFBUSxXQUFXLGFBQWE7S0FBUTs7OzthQUMvRDs7Ozs7WUFDSjs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVcsT0FBTztjQUNuQix3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFdBQVcsT0FBTztLQUFhLFNBQVM7S0FBUyxjQUFXO2VBQzlFLHdCQUFDLE9BQUQ7TUFBSyxLQUFLLEdBQUcsa0JBQWtCO01BQWlCLFdBQVcsT0FBTztNQUFXLEtBQUk7TUFBRyxlQUFZO0tBQVE7Ozs7O0lBQ3BHOzs7OztHQUNQOzs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLE9BQU87Y0FBdkIsQ0FDSSx3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO2VBQXZCO01BQ0ksd0JBQUMsYUFBRDtPQUFhLFFBQU87T0FBUyxNQUFLO01BQU07Ozs7O01BQ3hDLHdCQUFDLGFBQUQ7T0FBYSxRQUFPO09BQVcsTUFBSztNQUFROzs7OztNQUM1Qyx3QkFBQyxhQUFEO09BQWEsUUFBTztPQUFZLE1BQUs7TUFBUzs7Ozs7S0FDN0M7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVcsT0FBTztlQUF2QjtNQUNJLHdCQUFDLGFBQUQ7T0FBYSxRQUFPO09BQVksTUFBSztNQUFTOzs7OztNQUM5Qyx3QkFBQyxhQUFEO09BQWEsUUFBTztPQUFXLE1BQUs7TUFBUTs7Ozs7TUFDNUMsd0JBQUMsYUFBRDtPQUFhLFFBQU87T0FBWSxNQUFLO01BQVM7Ozs7O0tBQzdDOzs7OztZQUNKOzs7Ozs7RUFFSjs7Ozs7O0FBR2IiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSFVELnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VHYW1lU3RvcmUgfSBmcm9tICcuLi8uLi9zdG9yZXMvZ2FtZVN0b3JlJztcclxuaW1wb3J0IHsgR0FNRV9DT05GSUcgfSBmcm9tICcuLi8uLi9jb3JlL2NvbmZpZyc7XHJcbmltcG9ydCB7IGdldEhlYWx0aFRpZXIsIHR5cGUgSGVhbHRoVGllciB9IGZyb20gJy4uLy4uL2NvcmUvaGVhbHRoJztcclxuaW1wb3J0IHtcclxuICAgIENPTlRST0xTX0JZX0FDVElPTiwgQ09OVFJPTF9JQ09OX1BBVEgsIFRPVUNIX0lOUFVUX0VWRU5ULFxyXG4gICAgdHlwZSBHYW1lQWN0aW9uLCB0eXBlIFRvdWNoSW5wdXREZXRhaWwsXHJcbn0gZnJvbSAnLi4vLi4vaW5wdXQvY29udHJvbHMnO1xyXG5pbXBvcnQgeyBBc3NldEJhciwgdHlwZSBCYXJDb2xvciB9IGZyb20gJy4vQXNzZXRCYXInO1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4vSFVELm1vZHVsZS5jc3MnO1xyXG5cclxuY29uc3QgVElFUl9DT0xPUjogUmVjb3JkPEhlYWx0aFRpZXIsIEJhckNvbG9yPiA9IHsgaGlnaDogJ2dyZWVuJywgbWVkaXVtOiAnYW1iZXInLCBsb3c6ICdyZWQnIH07XHJcblxyXG5jb25zdCBlbWl0VG91Y2ggPSAoYWN0aW9uOiBHYW1lQWN0aW9uLCBzdGF0ZTogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50PFRvdWNoSW5wdXREZXRhaWw+KFRPVUNIX0lOUFVUX0VWRU5ULCB7IGRldGFpbDogeyBhY3Rpb24sIHN0YXRlIH0gfSkpO1xyXG59O1xyXG5cclxuY29uc3QgVG91Y2hCdXR0b246IFJlYWN0LkZDPHsgYWN0aW9uOiBHYW1lQWN0aW9uOyBhcmVhOiBzdHJpbmcgfT4gPSAoeyBhY3Rpb24sIGFyZWEgfSkgPT4ge1xyXG4gICAgY29uc3QgeyBsYWJlbCwgaWNvbiB9ID0gQ09OVFJPTFNfQllfQUNUSU9OW2FjdGlvbl07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy50b3VjaEJ1dHRvbn1cclxuICAgICAgICAgICAgc3R5bGU9e3sgZ3JpZEFyZWE6IGFyZWEgfX1cclxuICAgICAgICAgICAgYXJpYS1sYWJlbD17bGFiZWx9XHJcbiAgICAgICAgICAgIG9uUG9pbnRlckRvd249eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBlLmN1cnJlbnRUYXJnZXQuc2V0UG9pbnRlckNhcHR1cmUoZS5wb2ludGVySWQpO1xyXG4gICAgICAgICAgICAgICAgZW1pdFRvdWNoKGFjdGlvbiwgdHJ1ZSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIC8vIEZpcmVzIG9uIHBvaW50ZXJ1cCwgcG9pbnRlcmNhbmNlbCBhbmQgaW1wbGljaXQgY2FwdHVyZSBsb3NzXHJcbiAgICAgICAgICAgIG9uTG9zdFBvaW50ZXJDYXB0dXJlPXsoKSA9PiBlbWl0VG91Y2goYWN0aW9uLCBmYWxzZSl9XHJcbiAgICAgICAgICAgIG9uQ29udGV4dE1lbnU9eyhlKSA9PiBlLnByZXZlbnREZWZhdWx0KCl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICA8aW1nIHNyYz17YCR7Q09OVFJPTF9JQ09OX1BBVEh9JHtpY29ufWB9IGNsYXNzTmFtZT17c3R5bGVzLnRvdWNoSWNvbn0gYWx0PVwiXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgZHJhZ2dhYmxlPXtmYWxzZX0gLz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICk7XHJcbn07XHJcblxyXG5jb25zdCBmb3JtYXRUaW1lID0gKG1zOiBudW1iZXIpOiBzdHJpbmcgPT4ge1xyXG4gICAgY29uc3QgdG90YWwgPSBNYXRoLmNlaWwobXMgLyAxMDAwKTtcclxuICAgIHJldHVybiBgJHtNYXRoLmZsb29yKHRvdGFsIC8gNjApfToke1N0cmluZyh0b3RhbCAlIDYwKS5wYWRTdGFydCgyLCAnMCcpfWA7XHJcbn07XHJcblxyXG5pbnRlcmZhY2UgSFVEUHJvcHMge1xyXG4gICAgb25QYXVzZTogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IEhVRDogUmVhY3QuRkM8SFVEUHJvcHM+ID0gKHsgb25QYXVzZSB9KSA9PiB7XHJcbiAgICBjb25zdCBoZWFsdGggPSB1c2VHYW1lU3RvcmUoKHMpID0+IHMucGxheWVySGVhbHRoKTtcclxuICAgIGNvbnN0IHRpbWVSZW1haW5pbmcgPSB1c2VHYW1lU3RvcmUoKHMpID0+IHMudGltZVJlbWFpbmluZyk7XHJcbiAgICBjb25zdCBzY29yZSA9IHVzZUdhbWVTdG9yZSgocykgPT4gcy5zY29yZSk7XHJcblxyXG4gICAgY29uc3QgbWF4SGVhbHRoID0gR0FNRV9DT05GSUcucGxheWVyTWF4SGVhbHRoO1xyXG4gICAgY29uc3QgY3VycmVudEhlYWx0aCA9IE1hdGgubWF4KDAsIE1hdGguY2VpbChoZWFsdGgpKTtcclxuICAgIGNvbnN0IGhlYWx0aFJhdGlvID0gY3VycmVudEhlYWx0aCAvIG1heEhlYWx0aDtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGFpbmVyfT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5oZWFsdGhXcmFwcGVyfT5cclxuICAgICAgICAgICAgICAgIDxBc3NldEJhclxyXG4gICAgICAgICAgICAgICAgICAgIHJhdGlvPXtoZWFsdGhSYXRpb31cclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj17VElFUl9DT0xPUltnZXRIZWFsdGhUaWVyKGhlYWx0aFJhdGlvKV19XHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9e2Ake2N1cnJlbnRIZWFsdGh9IC8gJHttYXhIZWFsdGh9YH1cclxuICAgICAgICAgICAgICAgICAgICByb2xlPVwibWV0ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJIZWFsdGhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtdmFsdWVtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS12YWx1ZW1heD17bWF4SGVhbHRofVxyXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtdmFsdWVub3c9e2N1cnJlbnRIZWFsdGh9XHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS12YWx1ZXRleHQ9e2Ake2N1cnJlbnRIZWFsdGh9IG9mICR7bWF4SGVhbHRofWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuc3RhdHNXcmFwcGVyfT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY291bnRlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9XCIvYXNzZXRzL3BuZy9kZWZhdWx0L3VpL2h1ZC9pY29uX3Njb3JlLnBuZ1wiIGFsdD1cIlNjb3JlXCIgY2xhc3NOYW1lPXtzdHlsZXMuaWNvbn0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3N0eWxlcy52YWx1ZX0+e3Njb3JlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY291bnRlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9XCIvYXNzZXRzL3BuZy9kZWZhdWx0L3VpL2h1ZC9pY29uX3RpbWUucG5nXCIgYWx0PVwiVGltZSByZW1haW5pbmdcIiBjbGFzc05hbWU9e3N0eWxlcy5pY29ufSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17c3R5bGVzLnZhbHVlfT57Zm9ybWF0VGltZSh0aW1lUmVtYWluaW5nKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnBhdXNlQ29udGFpbmVyfT5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17c3R5bGVzLnBhdXNlQnV0dG9ufSBvbkNsaWNrPXtvblBhdXNlfSBhcmlhLWxhYmVsPVwiUGF1c2UgZ2FtZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtgJHtDT05UUk9MX0lDT05fUEFUSH1pY29uX3BhdXNlLnBuZ2B9IGNsYXNzTmFtZT17c3R5bGVzLnBhdXNlSWNvbn0gYWx0PVwiXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMudG91Y2hDb250cm9sc30+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmxlZnRDb250cm9sc30+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRvdWNoQnV0dG9uIGFjdGlvbj1cInRocnVzdFwiIGFyZWE9XCJ1cFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRvdWNoQnV0dG9uIGFjdGlvbj1cInR1cm5MZWZ0XCIgYXJlYT1cImxlZnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUb3VjaEJ1dHRvbiBhY3Rpb249XCJ0dXJuUmlnaHRcIiBhcmVhPVwicmlnaHRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5yaWdodENvbnRyb2xzfT5cclxuICAgICAgICAgICAgICAgICAgICA8VG91Y2hCdXR0b24gYWN0aW9uPVwiZmlyZUZyb250XCIgYXJlYT1cImZyb250XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8VG91Y2hCdXR0b24gYWN0aW9uPVwiZmlyZUxlZnRcIiBhcmVhPVwibGVmdFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRvdWNoQnV0dG9uIGFjdGlvbj1cImZpcmVSaWdodFwiIGFyZWE9XCJyaWdodFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuXHJcbn07XHJcbiJdfQ==