import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/ControlsGuide.tsx");const React = __vite__cjsImport0_react; const useId = __vite__cjsImport0_react["useId"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import { CONTROLS, PAUSE_KEYS, CONTROL_ICON_PATH, formatKey } from "/src/input/controls.ts";
import { useDialog } from "/src/ui/hooks/useDialog.ts";
import styles from "/src/ui/components/ControlsGuide.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/ControlsGuide.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
const Keys = ({ codes }) => /* @__PURE__ */ _jsxDEV(_Fragment, { children: codes.map((code) => /* @__PURE__ */ _jsxDEV("kbd", {
	className: styles.key,
	children: formatKey(code)
}, code, false, {
	fileName: _jsxFileName,
	lineNumber: 14,
	columnNumber: 30
}, this)) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 13,
	columnNumber: 5
}, this);
_c = Keys;
export const ControlsGuide = ({ onClose }) => {
	_s();
	const titleId = useId();
	const dialogRef = useDialog(true, onClose);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: `${styles.card} responsive-card`,
		"aria-labelledby": titleId,
		role: "dialog",
		"aria-modal": "true",
		ref: dialogRef,
		tabIndex: -1,
		children: [
			/* @__PURE__ */ _jsxDEV("h2", {
				id: titleId,
				className: styles.title,
				children: "Controls"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("table", {
				className: styles.table,
				children: [
					/* @__PURE__ */ _jsxDEV("caption", {
						className: "sr-only",
						children: "Keyboard and touch controls"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							children: "Action"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							children: "Keyboard"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "col",
							children: "Touch"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 25
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 21
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("tbody", { children: [CONTROLS.map((c) => /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "row",
							children: c.label
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV(Keys, { codes: c.keys }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 33
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 29
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("img", {
							src: `${CONTROL_ICON_PATH}${c.icon}`,
							alt: `${c.label} button`,
							className: styles.icon
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 33
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 29
						}, this)
					] }, c.action, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 25
					}, this)), /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", {
							scope: "row",
							children: "Pause / resume"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV(Keys, { codes: PAUSE_KEYS }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 29
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("img", {
							src: `${CONTROL_ICON_PATH}icon_pause.png`,
							alt: "Pause button",
							className: styles.icon
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 29
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 25
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 21
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: styles.hint,
				children: "Move and fire at the same time. The game pauses automatically when the tab loses focus."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: styles.closeButton,
				onClick: onClose,
				children: "Back"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 9
	}, this);
};
_s(ControlsGuide, "QjNTX+TugSW2XYxPIvKhkcvnZpY=", false, function() {
	return [useDialog];
});
_c2 = ControlsGuide;
var _c, _c2;
$RefreshReg$(_c, "Keys");
$RefreshReg$(_c2, "ControlsGuide");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/ControlsGuide.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/ControlsGuide.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/ControlsGuide.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/ControlsGuide.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGFBQWE7QUFDN0IsU0FBUyxVQUFVLFlBQVksbUJBQW1CLGlCQUFpQjtBQUVuRSxTQUFTLGlCQUFpQjtBQUUxQixPQUFPLFlBQVk7Ozs7QUFNbkIsTUFBTSxRQUFnRCxFQUFFLFlBQ3BELCtDQUNLLE1BQU0sS0FBSyxTQUFTLHdCQUFDLE9BQUQ7Q0FBZ0IsV0FBVyxPQUFPO1dBQU0sVUFBVSxJQUFJO0FBQU8sR0FBbkQ7Ozs7T0FBbUQsQ0FBQyxFQUNyRjs7Ozs7O0FBR04sT0FBTyxNQUFNLGlCQUErQyxFQUFFLGNBQWM7O0NBQ3hFLE1BQU0sVUFBVSxNQUFNO0NBQ3RCLE1BQU0sWUFBWSxVQUFVLE1BQU0sT0FBTztDQUV6QyxPQUNJLHdCQUFDLFdBQUQ7RUFDSSxXQUFXLEdBQUcsT0FBTyxLQUFLO0VBQzFCLG1CQUFpQjtFQUNqQixNQUFLO0VBQ0wsY0FBVztFQUNYLEtBQUs7RUFDTCxVQUFVLENBQUM7WUFOZjtHQVFJLHdCQUFDLE1BQUQ7SUFBSSxJQUFJO0lBQVMsV0FBVyxPQUFPO2NBQU87R0FBWTs7Ozs7R0FFdEQsd0JBQUMsU0FBRDtJQUFPLFdBQVcsT0FBTztjQUF6QjtLQUNJLHdCQUFDLFdBQUQ7TUFBUyxXQUFVO2dCQUFVO0tBQW9DOzs7OztLQUNqRSx3QkFBQyxTQUFELFlBQ0ksd0JBQUMsTUFBRDtNQUNJLHdCQUFDLE1BQUQ7T0FBSSxPQUFNO2lCQUFNO01BQVU7Ozs7O01BQzFCLHdCQUFDLE1BQUQ7T0FBSSxPQUFNO2lCQUFNO01BQVk7Ozs7O01BQzVCLHdCQUFDLE1BQUQ7T0FBSSxPQUFNO2lCQUFNO01BQVM7Ozs7O0tBQ3pCOzs7O2NBQ0Q7Ozs7O0tBQ1Asd0JBQUMsU0FBRCxhQUNLLFNBQVMsS0FBSyxNQUNYLHdCQUFDLE1BQUQ7TUFDSSx3QkFBQyxNQUFEO09BQUksT0FBTTtpQkFBTyxFQUFFO01BQVU7Ozs7O01BQzdCLHdCQUFDLE1BQUQsWUFBSSx3QkFBQyxNQUFELEVBQU0sT0FBTyxFQUFFLEtBQU87Ozs7ZUFBSzs7Ozs7TUFDL0Isd0JBQUMsTUFBRCxZQUFJLHdCQUFDLE9BQUQ7T0FBSyxLQUFLLEdBQUcsb0JBQW9CLEVBQUU7T0FBUSxLQUFLLEdBQUcsRUFBRSxNQUFNO09BQVUsV0FBVyxPQUFPO01BQU87Ozs7ZUFBSzs7Ozs7S0FDdkcsS0FKSyxFQUFFOzs7O1lBSVAsQ0FDUCxHQUNELHdCQUFDLE1BQUQ7TUFDSSx3QkFBQyxNQUFEO09BQUksT0FBTTtpQkFBTTtNQUFrQjs7Ozs7TUFDbEMsd0JBQUMsTUFBRCxZQUFJLHdCQUFDLE1BQUQsRUFBTSxPQUFPLFdBQWE7Ozs7ZUFBSzs7Ozs7TUFDbkMsd0JBQUMsTUFBRCxZQUFJLHdCQUFDLE9BQUQ7T0FBSyxLQUFLLEdBQUcsa0JBQWtCO09BQWlCLEtBQUk7T0FBZSxXQUFXLE9BQU87TUFBTzs7OztlQUFLOzs7OztLQUNyRzs7OzthQUNEOzs7OztJQUNKOzs7Ozs7R0FFUCx3QkFBQyxLQUFEO0lBQUcsV0FBVyxPQUFPO2NBQU07R0FBMEY7Ozs7O0dBRXJILHdCQUFDLFVBQUQ7SUFBUSxNQUFLO0lBQVMsV0FBVyxPQUFPO0lBQWEsU0FBUztjQUFTO0dBRS9EOzs7OztFQUNIOzs7Ozs7QUFHakIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ29udHJvbHNHdWlkZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUlkIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBDT05UUk9MUywgUEFVU0VfS0VZUywgQ09OVFJPTF9JQ09OX1BBVEgsIGZvcm1hdEtleSB9IGZyb20gJy4uLy4uL2lucHV0L2NvbnRyb2xzJztcclxuXHJcbmltcG9ydCB7IHVzZURpYWxvZyB9IGZyb20gJy4uL2hvb2tzL3VzZURpYWxvZyc7XHJcblxyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4vQ29udHJvbHNHdWlkZS5tb2R1bGUuY3NzJztcclxuXHJcbmludGVyZmFjZSBDb250cm9sc0d1aWRlUHJvcHMge1xyXG4gICAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuY29uc3QgS2V5czogUmVhY3QuRkM8eyBjb2RlczogcmVhZG9ubHkgc3RyaW5nW10gfT4gPSAoeyBjb2RlcyB9KSA9PiAoXHJcbiAgICA8PlxyXG4gICAgICAgIHtjb2Rlcy5tYXAoKGNvZGUpID0+IDxrYmQga2V5PXtjb2RlfSBjbGFzc05hbWU9e3N0eWxlcy5rZXl9Pntmb3JtYXRLZXkoY29kZSl9PC9rYmQ+KX1cclxuICAgIDwvPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IENvbnRyb2xzR3VpZGU6IFJlYWN0LkZDPENvbnRyb2xzR3VpZGVQcm9wcz4gPSAoeyBvbkNsb3NlIH0pID0+IHtcclxuICAgIGNvbnN0IHRpdGxlSWQgPSB1c2VJZCgpO1xyXG4gICAgY29uc3QgZGlhbG9nUmVmID0gdXNlRGlhbG9nKHRydWUsIG9uQ2xvc2UpO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtzdHlsZXMuY2FyZH0gcmVzcG9uc2l2ZS1jYXJkYH1cclxuICAgICAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PXt0aXRsZUlkfVxyXG4gICAgICAgICAgICByb2xlPVwiZGlhbG9nXCJcclxuICAgICAgICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxyXG4gICAgICAgICAgICByZWY9e2RpYWxvZ1JlZn1cclxuICAgICAgICAgICAgdGFiSW5kZXg9ey0xfVxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGgyIGlkPXt0aXRsZUlkfSBjbGFzc05hbWU9e3N0eWxlcy50aXRsZX0+Q29udHJvbHM8L2gyPlxyXG5cclxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT17c3R5bGVzLnRhYmxlfT5cclxuICAgICAgICAgICAgICAgIDxjYXB0aW9uIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5LZXlib2FyZCBhbmQgdG91Y2ggY29udHJvbHM8L2NhcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIj5BY3Rpb248L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIj5LZXlib2FyZDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiPlRvdWNoPC90aD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICB7Q09OVFJPTFMubWFwKChjKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2MuYWN0aW9ufT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPntjLmxhYmVsfTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+PEtleXMgY29kZXM9e2Mua2V5c30gLz48L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPjxpbWcgc3JjPXtgJHtDT05UUk9MX0lDT05fUEFUSH0ke2MuaWNvbn1gfSBhbHQ9e2Ake2MubGFiZWx9IGJ1dHRvbmB9IGNsYXNzTmFtZT17c3R5bGVzLmljb259IC8+PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cInJvd1wiPlBhdXNlIC8gcmVzdW1lPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPjxLZXlzIGNvZGVzPXtQQVVTRV9LRVlTfSAvPjwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD48aW1nIHNyYz17YCR7Q09OVFJPTF9JQ09OX1BBVEh9aWNvbl9wYXVzZS5wbmdgfSBhbHQ9XCJQYXVzZSBidXR0b25cIiBjbGFzc05hbWU9e3N0eWxlcy5pY29ufSAvPjwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcblxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5oaW50fT5Nb3ZlIGFuZCBmaXJlIGF0IHRoZSBzYW1lIHRpbWUuIFRoZSBnYW1lIHBhdXNlcyBhdXRvbWF0aWNhbGx5IHdoZW4gdGhlIHRhYiBsb3NlcyBmb2N1cy48L3A+XHJcblxyXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e3N0eWxlcy5jbG9zZUJ1dHRvbn0gb25DbGljaz17b25DbG9zZX0+XHJcbiAgICAgICAgICAgICAgICBCYWNrXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvc2VjdGlvbj5cclxuICAgICk7XHJcblxyXG59O1xyXG4iXX0=