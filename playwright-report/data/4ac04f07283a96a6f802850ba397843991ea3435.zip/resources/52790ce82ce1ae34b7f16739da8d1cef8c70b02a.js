import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/OptionsScreen.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import { useGameStore } from "/src/stores/gameStore.ts";
import { SPAWN_STEPS, SESSION_STEPS, STORAGE_KEYS } from "/src/core/config.ts";
import styles from "/src/ui/components/OptionsScreen.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/OptionsScreen.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
export const OptionsScreen = ({ onClose }) => {
	_s();
	const initialSession = useGameStore((s) => s.sessionTime);
	const initialSpawn = useGameStore((s) => s.spawnInterval);
	const [sessionIdx, setSessionIdx] = useState(() => Math.max(0, SESSION_STEPS.indexOf(initialSession)));
	const [spawnIdx, setSpawnIdx] = useState(() => Math.max(0, SPAWN_STEPS.indexOf(initialSpawn)));
	const handleSave = () => {
		const finalSession = SESSION_STEPS[sessionIdx];
		const finalSpawn = SPAWN_STEPS[spawnIdx];
		localStorage.setItem(STORAGE_KEYS.sessionTime, finalSession.toString());
		localStorage.setItem(STORAGE_KEYS.spawnInterval, finalSpawn.toString());
		useGameStore.setState({
			sessionTime: finalSession,
			spawnInterval: finalSpawn
		});
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `${styles.card} responsive-card`,
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: styles.title,
				children: "Options"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.optionGroup,
				children: [/* @__PURE__ */ _jsxDEV("label", {
					className: styles.label,
					children: "Match Duration"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: styles.selector,
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							className: styles.stepButton,
							onClick: () => setSessionIdx(Math.max(0, sessionIdx - 1)),
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: "/assets/png/default/ui/controls/icon_minus.png",
								alt: "-",
								className: styles.stepIcon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 25
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: styles.valueDisplay,
							children: [SESSION_STEPS[sessionIdx], "s"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: styles.stepButton,
							onClick: () => setSessionIdx(Math.min(SESSION_STEPS.length - 1, sessionIdx + 1)),
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: "/assets/png/default/ui/controls/icon_plus.png",
								alt: "+",
								className: styles.stepIcon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 25
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.optionGroup,
				children: [/* @__PURE__ */ _jsxDEV("label", {
					className: styles.label,
					children: "Enemy Spawn"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: styles.selector,
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							className: styles.stepButton,
							onClick: () => setSpawnIdx(Math.max(0, spawnIdx - 1)),
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: "/assets/png/default/ui/controls/icon_minus.png",
								alt: "-",
								className: styles.stepIcon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 25
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: styles.valueDisplay,
							children: [SPAWN_STEPS[spawnIdx], "s"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: styles.stepButton,
							onClick: () => setSpawnIdx(Math.min(SPAWN_STEPS.length - 1, spawnIdx + 1)),
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: "/assets/png/default/ui/controls/icon_plus.png",
								alt: "+",
								className: styles.stepIcon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 25
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				className: styles.saveButton,
				onClick: handleSave,
				children: "Save & Close"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 9
	}, this);
};
_s(OptionsScreen, "N3XPzuOQSnGOyVtsKViDsCfBeEc=", false, function() {
	return [useGameStore, useGameStore];
});
_c = OptionsScreen;
var _c;
$RefreshReg$(_c, "OptionsScreen");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/OptionsScreen.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/OptionsScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/OptionsScreen.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/OptionsScreen.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUVoQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGFBQWEsZUFBZSxvQkFBb0I7QUFFekQsT0FBTyxZQUFZOzs7O0FBTW5CLE9BQU8sTUFBTSxpQkFBK0MsRUFBRSxjQUFjOztDQUN4RSxNQUFNLGlCQUFpQixjQUFhLE1BQUssRUFBRSxXQUFXO0NBQ3RELE1BQU0sZUFBZSxjQUFhLE1BQUssRUFBRSxhQUFhO0NBRXRELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixlQUNoQyxLQUFLLElBQUksR0FBSSxjQUFvQyxRQUFRLGNBQWMsQ0FBQyxDQUM1RTtDQUVBLE1BQU0sQ0FBQyxVQUFVLGVBQWUsZUFDNUIsS0FBSyxJQUFJLEdBQUksWUFBa0MsUUFBUSxZQUFZLENBQUMsQ0FDeEU7Q0FFQSxNQUFNLG1CQUFtQjtFQUNyQixNQUFNLGVBQWUsY0FBYztFQUNuQyxNQUFNLGFBQWEsWUFBWTtFQUUvQixhQUFhLFFBQVEsYUFBYSxhQUFhLGFBQWEsU0FBUyxDQUFDO0VBQ3RFLGFBQWEsUUFBUSxhQUFhLGVBQWUsV0FBVyxTQUFTLENBQUM7RUFFdEUsYUFBYSxTQUFTO0dBQUUsYUFBYTtHQUFjLGVBQWU7RUFBVyxDQUFDO0VBRTlFLFFBQVE7Q0FDWjtDQUVBLE9BQ0ksd0JBQUMsT0FBRDtFQUFLLFdBQVcsR0FBRyxPQUFPLEtBQUs7WUFBL0I7R0FDSSx3QkFBQyxNQUFEO0lBQUksV0FBVyxPQUFPO2NBQU87R0FBVzs7Ozs7R0FFeEMsd0JBQUMsT0FBRDtJQUFLLFdBQVcsT0FBTztjQUF2QixDQUVJLHdCQUFDLFNBQUQ7S0FBTyxXQUFXLE9BQU87ZUFBTztJQUFxQjs7OztjQUVyRCx3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO2VBQXZCO01BQ0ksd0JBQUMsVUFBRDtPQUFRLFdBQVcsT0FBTztPQUFZLGVBQWUsY0FBYyxLQUFLLElBQUksR0FBRyxhQUFhLENBQUMsQ0FBQztpQkFDMUYsd0JBQUMsT0FBRDtRQUFLLEtBQUk7UUFBaUQsS0FBSTtRQUFJLFdBQVcsT0FBTztPQUFXOzs7OztNQUMzRjs7Ozs7TUFDUix3QkFBQyxRQUFEO09BQU0sV0FBVyxPQUFPO2lCQUF4QixDQUF1QyxjQUFjLGFBQVksR0FBTzs7Ozs7O01BQ3hFLHdCQUFDLFVBQUQ7T0FBUSxXQUFXLE9BQU87T0FBWSxlQUFlLGNBQWMsS0FBSyxJQUFJLGNBQWMsU0FBUyxHQUFHLGFBQWEsQ0FBQyxDQUFDO2lCQUNqSCx3QkFBQyxPQUFEO1FBQUssS0FBSTtRQUFnRCxLQUFJO1FBQUksV0FBVyxPQUFPO09BQVc7Ozs7O01BQzFGOzs7OztLQUNQOzs7OztZQUVKOzs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVyxPQUFPO2NBQXZCLENBRUksd0JBQUMsU0FBRDtLQUFPLFdBQVcsT0FBTztlQUFPO0lBQWtCOzs7O2NBQ2xELHdCQUFDLE9BQUQ7S0FBSyxXQUFXLE9BQU87ZUFBdkI7TUFDSSx3QkFBQyxVQUFEO09BQVEsV0FBVyxPQUFPO09BQVksZUFBZSxZQUFZLEtBQUssSUFBSSxHQUFHLFdBQVcsQ0FBQyxDQUFDO2lCQUN0Rix3QkFBQyxPQUFEO1FBQUssS0FBSTtRQUFpRCxLQUFJO1FBQUksV0FBVyxPQUFPO09BQVc7Ozs7O01BQzNGOzs7OztNQUNSLHdCQUFDLFFBQUQ7T0FBTSxXQUFXLE9BQU87aUJBQXhCLENBQXVDLFlBQVksV0FBVSxHQUFPOzs7Ozs7TUFDcEUsd0JBQUMsVUFBRDtPQUFRLFdBQVcsT0FBTztPQUFZLGVBQWUsWUFBWSxLQUFLLElBQUksWUFBWSxTQUFTLEdBQUcsV0FBVyxDQUFDLENBQUM7aUJBQzNHLHdCQUFDLE9BQUQ7UUFBSyxLQUFJO1FBQWdELEtBQUk7UUFBSSxXQUFXLE9BQU87T0FBVzs7Ozs7TUFDMUY7Ozs7O0tBQ1A7Ozs7O1lBRUo7Ozs7OztHQUVMLHdCQUFDLFVBQUQ7SUFBUSxXQUFXLE9BQU87SUFBWSxTQUFTO2NBQVk7R0FFbkQ7Ozs7O0VBQ1A7Ozs7OztBQUdiIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk9wdGlvbnNTY3JlZW4udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuXHJcbmltcG9ydCB7IHVzZUdhbWVTdG9yZSB9IGZyb20gJy4uLy4uL3N0b3Jlcy9nYW1lU3RvcmUnO1xyXG5pbXBvcnQgeyBTUEFXTl9TVEVQUywgU0VTU0lPTl9TVEVQUywgU1RPUkFHRV9LRVlTIH0gZnJvbSAnLi4vLi4vY29yZS9jb25maWcnO1xyXG5cclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuL09wdGlvbnNTY3JlZW4ubW9kdWxlLmNzcyc7XHJcblxyXG5pbnRlcmZhY2UgT3B0aW9uc1NjcmVlblByb3BzIHtcclxuICAgIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBPcHRpb25zU2NyZWVuOiBSZWFjdC5GQzxPcHRpb25zU2NyZWVuUHJvcHM+ID0gKHsgb25DbG9zZSB9KSA9PiB7XHJcbiAgICBjb25zdCBpbml0aWFsU2Vzc2lvbiA9IHVzZUdhbWVTdG9yZShzID0+IHMuc2Vzc2lvblRpbWUpO1xyXG4gICAgY29uc3QgaW5pdGlhbFNwYXduID0gdXNlR2FtZVN0b3JlKHMgPT4gcy5zcGF3bkludGVydmFsKTtcclxuXHJcbiAgICBjb25zdCBbc2Vzc2lvbklkeCwgc2V0U2Vzc2lvbklkeF0gPSB1c2VTdGF0ZSgoKSA9PlxyXG4gICAgICAgIE1hdGgubWF4KDAsIChTRVNTSU9OX1NURVBTIGFzIHJlYWRvbmx5IG51bWJlcltdKS5pbmRleE9mKGluaXRpYWxTZXNzaW9uKSlcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgW3NwYXduSWR4LCBzZXRTcGF3bklkeF0gPSB1c2VTdGF0ZSgoKSA9PlxyXG4gICAgICAgIE1hdGgubWF4KDAsIChTUEFXTl9TVEVQUyBhcyByZWFkb25seSBudW1iZXJbXSkuaW5kZXhPZihpbml0aWFsU3Bhd24pKVxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVTYXZlID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGZpbmFsU2Vzc2lvbiA9IFNFU1NJT05fU1RFUFNbc2Vzc2lvbklkeF07XHJcbiAgICAgICAgY29uc3QgZmluYWxTcGF3biA9IFNQQVdOX1NURVBTW3NwYXduSWR4XTtcclxuXHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVlTLnNlc3Npb25UaW1lLCBmaW5hbFNlc3Npb24udG9TdHJpbmcoKSk7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVlTLnNwYXduSW50ZXJ2YWwsIGZpbmFsU3Bhd24udG9TdHJpbmcoKSk7XHJcblxyXG4gICAgICAgIHVzZUdhbWVTdG9yZS5zZXRTdGF0ZSh7IHNlc3Npb25UaW1lOiBmaW5hbFNlc3Npb24sIHNwYXduSW50ZXJ2YWw6IGZpbmFsU3Bhd24gfSk7XHJcblxyXG4gICAgICAgIG9uQ2xvc2UoKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7c3R5bGVzLmNhcmR9IHJlc3BvbnNpdmUtY2FyZGB9PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPXtzdHlsZXMudGl0bGV9Pk9wdGlvbnM8L2gxPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5vcHRpb25Hcm91cH0+XHJcblxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT17c3R5bGVzLmxhYmVsfT5NYXRjaCBEdXJhdGlvbjwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5zZWxlY3Rvcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9e3N0eWxlcy5zdGVwQnV0dG9ufSBvbkNsaWNrPXsoKSA9PiBzZXRTZXNzaW9uSWR4KE1hdGgubWF4KDAsIHNlc3Npb25JZHggLSAxKSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz1cIi9hc3NldHMvcG5nL2RlZmF1bHQvdWkvY29udHJvbHMvaWNvbl9taW51cy5wbmdcIiBhbHQ9XCItXCIgY2xhc3NOYW1lPXtzdHlsZXMuc3RlcEljb259IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMudmFsdWVEaXNwbGF5fT57U0VTU0lPTl9TVEVQU1tzZXNzaW9uSWR4XX1zPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPXtzdHlsZXMuc3RlcEJ1dHRvbn0gb25DbGljaz17KCkgPT4gc2V0U2Vzc2lvbklkeChNYXRoLm1pbihTRVNTSU9OX1NURVBTLmxlbmd0aCAtIDEsIHNlc3Npb25JZHggKyAxKSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz1cIi9hc3NldHMvcG5nL2RlZmF1bHQvdWkvY29udHJvbHMvaWNvbl9wbHVzLnBuZ1wiIGFsdD1cIitcIiBjbGFzc05hbWU9e3N0eWxlcy5zdGVwSWNvbn0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm9wdGlvbkdyb3VwfT5cclxuXHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPXtzdHlsZXMubGFiZWx9PkVuZW15IFNwYXduPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuc2VsZWN0b3J9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPXtzdHlsZXMuc3RlcEJ1dHRvbn0gb25DbGljaz17KCkgPT4gc2V0U3Bhd25JZHgoTWF0aC5tYXgoMCwgc3Bhd25JZHggLSAxKSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz1cIi9hc3NldHMvcG5nL2RlZmF1bHQvdWkvY29udHJvbHMvaWNvbl9taW51cy5wbmdcIiBhbHQ9XCItXCIgY2xhc3NOYW1lPXtzdHlsZXMuc3RlcEljb259IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMudmFsdWVEaXNwbGF5fT57U1BBV05fU1RFUFNbc3Bhd25JZHhdfXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9e3N0eWxlcy5zdGVwQnV0dG9ufSBvbkNsaWNrPXsoKSA9PiBzZXRTcGF3bklkeChNYXRoLm1pbihTUEFXTl9TVEVQUy5sZW5ndGggLSAxLCBzcGF3bklkeCArIDEpKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPVwiL2Fzc2V0cy9wbmcvZGVmYXVsdC91aS9jb250cm9scy9pY29uX3BsdXMucG5nXCIgYWx0PVwiK1wiIGNsYXNzTmFtZT17c3R5bGVzLnN0ZXBJY29ufSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPXtzdHlsZXMuc2F2ZUJ1dHRvbn0gb25DbGljaz17aGFuZGxlU2F2ZX0+XHJcbiAgICAgICAgICAgICAgICBTYXZlICYgQ2xvc2VcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG5cclxufTtcclxuIl19