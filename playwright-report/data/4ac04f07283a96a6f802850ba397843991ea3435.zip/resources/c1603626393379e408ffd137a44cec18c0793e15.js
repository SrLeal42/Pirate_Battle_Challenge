import { $ as nextPow2, F as ScreenSizeRegistry, G as Texture, H as warn, I as InstructionSet, J as TextureSource, L as multiplyHexColors, N as DOMAdapter, R as BigPool, U as Color, V as GlobalResourceRegistry, W as Bounds, Y as TextureStyle, Z as isPow2, _t as ExtensionType, c as Shader, ct as uid, dt as Matrix, ft as Point, g as GpuProgram, gt as eventemitter3_default, ht as RAD_TO_DEG, it as v8_21_0, nt as deprecation, pt as DEG_TO_RAD, rt as v8_0_0, vt as extensions, w as GlProgram } from "/node_modules/.vite/deps/CanvasPool-BcIVNj8Y.js?v=43418a0e";
//#region node_modules/pixi.js/lib/maths/point/ObservablePoint.mjs
var ObservablePoint = class ObservablePoint {
	/**
	* Creates a new `ObservablePoint`
	* @param observer - Observer to pass to listen for change events.
	* @param {number} [x=0] - position of the point on the x axis
	* @param {number} [y=0] - position of the point on the y axis
	*/
	constructor(observer, x, y) {
		this._x = x || 0;
		this._y = y || 0;
		this._observer = observer;
	}
	/**
	* Creates a clone of this point.
	* @example
	* ```ts
	* // Basic cloning
	* const point = new ObservablePoint(observer, 100, 200);
	* const copy = point.clone();
	*
	* // Clone with new observer
	* const newObserver = {
	*     _onUpdate: (p) => console.log(`Clone updated: (${p.x}, ${p.y})`)
	* };
	* const watched = point.clone(newObserver);
	*
	* // Verify independence
	* watched.set(300, 400); // Only triggers new observer
	* ```
	* @param observer - Optional observer to pass to the new observable point
	* @returns A copy of this observable point
	* @see {@link ObservablePoint.copyFrom} For copying into existing point
	* @see {@link Observer} For observer interface details
	*/
	clone(observer) {
		return new ObservablePoint(observer ?? this._observer, this._x, this._y);
	}
	/**
	* Sets the point to a new x and y position.
	*
	* If y is omitted, both x and y will be set to x.
	* @example
	* ```ts
	* // Basic position setting
	* const point = new ObservablePoint(observer);
	* point.set(100, 200);
	*
	* // Set both x and y to same value
	* point.set(50); // x=50, y=50
	* ```
	* @param x - Position on the x axis
	* @param y - Position on the y axis, defaults to x
	* @returns The point instance itself
	* @see {@link ObservablePoint.copyFrom} For copying from another point
	* @see {@link ObservablePoint.equals} For comparing positions
	*/
	set(x = 0, y = x) {
		if (this._x !== x || this._y !== y) {
			this._x = x;
			this._y = y;
			this._observer._onUpdate(this);
		}
		return this;
	}
	/**
	* Copies x and y from the given point into this point.
	* @example
	* ```ts
	* // Basic copying
	* const source = new ObservablePoint(observer, 100, 200);
	* const target = new ObservablePoint();
	* target.copyFrom(source);
	*
	* // Copy and chain operations
	* const point = new ObservablePoint()
	*     .copyFrom(source)
	*     .set(x + 50, y + 50);
	*
	* // Copy from any PointData
	* const data = { x: 10, y: 20 };
	* point.copyFrom(data);
	* ```
	* @param p - The point to copy from
	* @returns The point instance itself
	* @see {@link ObservablePoint.copyTo} For copying to another point
	* @see {@link ObservablePoint.clone} For creating new point copy
	*/
	copyFrom(p) {
		if (this._x !== p.x || this._y !== p.y) {
			this._x = p.x;
			this._y = p.y;
			this._observer._onUpdate(this);
		}
		return this;
	}
	/**
	* Copies this point's x and y into the given point.
	* @example
	* ```ts
	* // Basic copying
	* const source = new ObservablePoint(100, 200);
	* const target = new ObservablePoint();
	* source.copyTo(target);
	* ```
	* @param p - The point to copy to. Can be any type that is or extends `PointLike`
	* @returns The point (`p`) with values updated
	* @see {@link ObservablePoint.copyFrom} For copying from another point
	* @see {@link ObservablePoint.clone} For creating new point copy
	*/
	copyTo(p) {
		p.set(this._x, this._y);
		return p;
	}
	/**
	* Checks if another point is equal to this point.
	*
	* Compares x and y values using strict equality.
	* @example
	* ```ts
	* // Basic equality check
	* const p1 = new ObservablePoint(100, 200);
	* const p2 = new ObservablePoint(100, 200);
	* console.log(p1.equals(p2)); // true
	*
	* // Compare with PointData
	* const data = { x: 100, y: 200 };
	* console.log(p1.equals(data)); // true
	*
	* // Check different points
	* const p3 = new ObservablePoint(200, 300);
	* console.log(p1.equals(p3)); // false
	* ```
	* @param p - The point to check
	* @returns `true` if both `x` and `y` are equal
	* @see {@link ObservablePoint.copyFrom} For making points equal
	* @see {@link PointData} For point data interface
	*/
	equals(p) {
		return p.x === this._x && p.y === this._y;
	}
	toString() {
		return `[pixi.js/math:ObservablePoint x=${this._x} y=${this._y} scope=${this._observer}]`;
	}
	/**
	* Position of the observable point on the x axis.
	* Triggers observer callback when value changes.
	* @example
	* ```ts
	* // Basic x position
	* const point = new ObservablePoint(observer);
	* point.x = 100; // Triggers observer
	*
	* // Use in calculations
	* const width = rightPoint.x - leftPoint.x;
	* ```
	* @default 0
	*/
	get x() {
		return this._x;
	}
	set x(value) {
		if (this._x !== value) {
			this._x = value;
			this._observer._onUpdate(this);
		}
	}
	/**
	* Position of the observable point on the y axis.
	* Triggers observer callback when value changes.
	* @example
	* ```ts
	* // Basic y position
	* const point = new ObservablePoint(observer);
	* point.y = 200; // Triggers observer
	*
	* // Use in calculations
	* const height = bottomPoint.y - topPoint.y;
	* ```
	* @default 0
	*/
	get y() {
		return this._y;
	}
	set y(value) {
		if (this._y !== value) {
			this._y = value;
			this._observer._onUpdate(this);
		}
	}
};
//#endregion
//#region node_modules/pixi.js/lib/utils/data/updateQuadBounds.mjs
function updateQuadBounds(bounds, anchor, texture) {
	const { width, height } = texture.orig;
	const trim = texture.trim;
	if (trim) {
		const sourceWidth = trim.width;
		const sourceHeight = trim.height;
		bounds.minX = trim.x - anchor._x * width;
		bounds.maxX = bounds.minX + sourceWidth;
		bounds.minY = trim.y - anchor._y * height;
		bounds.maxY = bounds.minY + sourceHeight;
	} else {
		bounds.minX = -anchor._x * width;
		bounds.maxX = bounds.minX + width;
		bounds.minY = -anchor._y * height;
		bounds.maxY = bounds.minY + height;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/culling/cullingMixin.mjs
var cullingMixin = {
	cullArea: null,
	cullable: false,
	cullableChildren: true
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/cacheAsTextureMixin.mjs
var cacheAsTextureMixin = {
	get isCachedAsTexture() {
		return !!this.renderGroup?.isCachedAsTexture;
	},
	cacheAsTexture(val) {
		if (typeof val === "boolean" && val === false) this.disableRenderGroup();
		else {
			this.enableRenderGroup();
			this.renderGroup.enableCacheAsTexture(val === true ? {} : val);
		}
	},
	updateCacheTexture() {
		this.renderGroup?.updateCacheTexture();
	},
	get cacheAsBitmap() {
		return this.isCachedAsTexture;
	},
	set cacheAsBitmap(val) {
		deprecation("v8.6.0", "cacheAsBitmap is deprecated, use cacheAsTexture instead.");
		this.cacheAsTexture(val);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/utils/data/removeItems.mjs
function removeItems(arr, startIdx, removeCount) {
	const length = arr.length;
	let i;
	if (startIdx >= length || removeCount === 0) return;
	removeCount = startIdx + removeCount > length ? length - startIdx : removeCount;
	const len = length - removeCount;
	for (i = startIdx; i < len; ++i) arr[i] = arr[i + removeCount];
	arr.length = len;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/childrenHelperMixin.mjs
var childrenHelperMixin = {
	allowChildren: true,
	removeChildren(beginIndex = 0, endIndex) {
		const end = endIndex ?? this.children.length;
		const range = end - beginIndex;
		const removed = [];
		if (range > 0 && range <= end) {
			for (let i = end - 1; i >= beginIndex; i--) {
				const child = this.children[i];
				if (!child) continue;
				removed.push(child);
				child.parent = null;
			}
			removeItems(this.children, beginIndex, end);
			const renderGroup = this.renderGroup || this.parentRenderGroup;
			if (renderGroup) renderGroup.removeChildren(removed);
			for (let i = 0; i < removed.length; ++i) {
				const child = removed[i];
				child.parentRenderLayer?.detach(child);
				this.emit("childRemoved", child, this, i);
				removed[i].emit("removed", this);
			}
			if (removed.length > 0) this._didViewChangeTick++;
			return removed;
		} else if (range === 0 && this.children.length === 0) return removed;
		throw new RangeError("removeChildren: numeric values are outside the acceptable range.");
	},
	removeChildAt(index) {
		const child = this.getChildAt(index);
		return this.removeChild(child);
	},
	getChildAt(index) {
		if (index < 0 || index >= this.children.length) throw new Error(`getChildAt: Index (${index}) does not exist.`);
		return this.children[index];
	},
	setChildIndex(child, index) {
		if (index < 0 || index >= this.children.length) throw new Error(`The index ${index} supplied is out of bounds ${this.children.length}`);
		this.getChildIndex(child);
		this.addChildAt(child, index);
	},
	getChildIndex(child) {
		const index = this.children.indexOf(child);
		if (index === -1) throw new Error("The supplied Container must be a child of the caller");
		return index;
	},
	addChildAt(child, index) {
		if (!this.allowChildren) deprecation(v8_0_0, "addChildAt: Only Containers will be allowed to add children in v8.0.0");
		const { children } = this;
		if (index < 0 || index > children.length) throw new Error(`${child}addChildAt: The index ${index} supplied is out of bounds ${children.length}`);
		const sameParent = child.parent === this;
		if (child.parent) {
			const currentIndex = child.parent.children.indexOf(child);
			if (sameParent) {
				if (currentIndex === index) return child;
				child.parent.children.splice(currentIndex, 1);
			} else child.removeFromParent();
		}
		if (index === children.length) children.push(child);
		else children.splice(index, 0, child);
		const renderGroup = this.renderGroup || this.parentRenderGroup;
		if (this.sortableChildren) this.sortDirty = true;
		if (sameParent) {
			if (renderGroup) renderGroup.structureDidChange = true;
			return child;
		}
		child.parent = this;
		child.didChange = true;
		child._updateFlags = 15;
		if (renderGroup) renderGroup.addChild(child);
		this.emit("childAdded", child, this, index);
		child.emit("added", this);
		return child;
	},
	swapChildren(child, child2) {
		if (child === child2) return;
		const index1 = this.getChildIndex(child);
		const index2 = this.getChildIndex(child2);
		this.children[index1] = child2;
		this.children[index2] = child;
		const renderGroup = this.renderGroup || this.parentRenderGroup;
		if (renderGroup) renderGroup.structureDidChange = true;
		this._didContainerChangeTick++;
	},
	removeFromParent() {
		this.parent?.removeChild(this);
	},
	reparentChild(...child) {
		if (child.length === 1) return this.reparentChildAt(child[0], this.children.length);
		child.forEach((c) => this.reparentChildAt(c, this.children.length));
		return child[0];
	},
	reparentChildAt(child, index) {
		if (child.parent === this) {
			this.setChildIndex(child, index);
			return child;
		}
		const childMat = child.worldTransform.clone();
		child.removeFromParent();
		this.addChildAt(child, index);
		const newMatrix = this.worldTransform.clone();
		newMatrix.invert();
		childMat.prepend(newMatrix);
		child.setFromMatrix(childMat);
		return child;
	},
	replaceChild(oldChild, newChild) {
		oldChild.updateLocalTransform();
		this.addChildAt(newChild, this.getChildIndex(oldChild));
		newChild.setFromMatrix(oldChild.localTransform);
		newChild.updateLocalTransform();
		this.removeChild(oldChild);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/collectRenderablesMixin.mjs
var collectRenderablesMixin = {
	collectRenderables(instructionSet, renderer, currentLayer) {
		if (this.parentRenderLayer && this.parentRenderLayer !== currentLayer || this.globalDisplayStatus < 7 || !this.includeInBuild) return;
		if (this.sortableChildren) this.sortChildren();
		if (this.isSimple) this.collectRenderablesSimple(instructionSet, renderer, currentLayer);
		else if (this.renderGroup) renderer.renderPipes.renderGroup.addRenderGroup(this.renderGroup, instructionSet);
		else this.collectRenderablesWithEffects(instructionSet, renderer, currentLayer);
	},
	collectRenderablesSimple(instructionSet, renderer, currentLayer) {
		const children = this.children;
		const length = children.length;
		for (let i = 0; i < length; i++) children[i].collectRenderables(instructionSet, renderer, currentLayer);
	},
	collectRenderablesWithEffects(instructionSet, renderer, currentLayer) {
		const { renderPipes } = renderer;
		for (let i = 0; i < this.effects.length; i++) {
			const effect = this.effects[i];
			renderPipes[effect.pipe].push(effect, this, instructionSet);
		}
		this.collectRenderablesSimple(instructionSet, renderer, currentLayer);
		for (let i = this.effects.length - 1; i >= 0; i--) {
			const effect = this.effects[i];
			renderPipes[effect.pipe].pop(effect, this, instructionSet);
		}
	}
};
//#endregion
//#region node_modules/pixi.js/lib/filters/FilterEffect.mjs
var FilterEffect = class {
	constructor() {
		/** the pipe that knows how to handle this effect */
		this.pipe = "filter";
		/** the priority of this effect */
		this.priority = 1;
	}
	destroy() {
		for (let i = 0; i < this.filters.length; i++) this.filters[i].destroy();
		this.filters = null;
		this.filterArea = null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/MaskEffectManager.mjs
var MaskEffectManagerClass = class {
	constructor() {
		/** @private */
		this._effectClasses = [];
		this._tests = [];
		this._initialized = false;
	}
	init() {
		if (this._initialized) return;
		this._initialized = true;
		this._effectClasses.forEach((test) => {
			this.add({
				test: test.test,
				maskClass: test
			});
		});
	}
	add(test) {
		this._tests.push(test);
	}
	getMaskEffect(item) {
		if (!this._initialized) this.init();
		for (let i = 0; i < this._tests.length; i++) {
			const test = this._tests[i];
			if (test.test(item)) return BigPool.get(test.maskClass, item);
		}
		return item;
	}
	returnMaskEffect(effect) {
		BigPool.return(effect);
	}
};
var MaskEffectManager = new MaskEffectManagerClass();
extensions.handleByList(ExtensionType.MaskEffect, MaskEffectManager._effectClasses);
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/effectsMixin.mjs
var effectsMixin = {
	_maskEffect: null,
	_maskOptions: {
		inverse: false,
		channel: "red"
	},
	_filterEffect: null,
	effects: [],
	_markStructureAsChanged() {
		const renderGroup = this.renderGroup || this.parentRenderGroup;
		if (renderGroup) renderGroup.structureDidChange = true;
	},
	addEffect(effect) {
		if (this.effects.indexOf(effect) !== -1) return;
		this.effects.push(effect);
		this.effects.sort((a, b) => a.priority - b.priority);
		this._markStructureAsChanged();
		this._updateIsSimple();
	},
	removeEffect(effect) {
		const index = this.effects.indexOf(effect);
		if (index === -1) return;
		this.effects.splice(index, 1);
		this._markStructureAsChanged();
		this._updateIsSimple();
	},
	set mask(value) {
		const effect = this._maskEffect;
		if (effect?.mask === value) return;
		if (effect) {
			this.removeEffect(effect);
			MaskEffectManager.returnMaskEffect(effect);
			this._maskEffect = null;
		}
		if (value === null || value === void 0) return;
		this._maskEffect = MaskEffectManager.getMaskEffect(value);
		this.addEffect(this._maskEffect);
	},
	get mask() {
		return this._maskEffect?.mask;
	},
	setMask(options) {
		this._maskOptions = {
			...this._maskOptions,
			...options
		};
		if (options.mask) this.mask = options.mask;
		this._markStructureAsChanged();
	},
	set filters(value) {
		if (!Array.isArray(value) && value) value = [value];
		const effect = this._filterEffect || (this._filterEffect = new FilterEffect());
		value = value;
		const hasFilters = value?.length > 0;
		const didChange = hasFilters !== effect.filters?.length > 0;
		value = Array.isArray(value) ? value.slice(0) : value;
		effect.filters = Object.freeze(value);
		if (didChange) {
			if (hasFilters) this.addEffect(effect);
			else {
				this.removeEffect(effect);
				effect.filters = value ?? null;
			}
		}
	},
	get filters() {
		return this._filterEffect?.filters;
	},
	set filterArea(value) {
		this._filterEffect || (this._filterEffect = new FilterEffect());
		this._filterEffect.filterArea = value;
	},
	get filterArea() {
		return this._filterEffect?.filterArea;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/findMixin.mjs
var findMixin = {
	label: null,
	get name() {
		deprecation(v8_0_0, "Container.name property has been removed, use Container.label instead");
		return this.label;
	},
	set name(value) {
		deprecation(v8_0_0, "Container.name property has been removed, use Container.label instead");
		this.label = value;
	},
	getChildByName(name, deep = false) {
		return this.getChildByLabel(name, deep);
	},
	getChildByLabel(label, deep = false) {
		const children = this.children;
		for (let i = 0; i < children.length; i++) {
			const child = children[i];
			if (child.label === label || label instanceof RegExp && label.test(child.label)) return child;
		}
		if (deep) for (let i = 0; i < children.length; i++) {
			const found = children[i].getChildByLabel(label, true);
			if (found) return found;
		}
		return null;
	},
	getChildrenByLabel(label, deep = false, out = []) {
		const children = this.children;
		for (let i = 0; i < children.length; i++) {
			const child = children[i];
			if (child.label === label || label instanceof RegExp && label.test(child.label)) out.push(child);
		}
		if (deep) for (let i = 0; i < children.length; i++) children[i].getChildrenByLabel(label, true, out);
		return out;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/bounds/utils/matrixAndBoundsPool.mjs
var matrixPool = BigPool.getPool(Matrix);
var boundsPool = BigPool.getPool(Bounds);
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/getFastGlobalBoundsMixin.mjs
var tempMatrix$1 = new Matrix();
var getFastGlobalBoundsMixin = {
	getFastGlobalBounds(factorRenderLayers, bounds) {
		bounds || (bounds = new Bounds());
		bounds.clear();
		this._getGlobalBoundsRecursive(!!factorRenderLayers, bounds, this.parentRenderLayer);
		if (!bounds.isValid) bounds.set(0, 0, 0, 0);
		const renderGroup = this.renderGroup || this.parentRenderGroup;
		bounds.applyMatrix(renderGroup.worldTransform);
		return bounds;
	},
	_getGlobalBoundsRecursive(factorRenderLayers, bounds, currentLayer) {
		let localBounds = bounds;
		if (factorRenderLayers && this.parentRenderLayer && this.parentRenderLayer !== currentLayer) return;
		if (this.localDisplayStatus !== 7 || !this.measurable) return;
		const manageEffects = !!this.effects.length;
		if (this.renderGroup || manageEffects) localBounds = boundsPool.get().clear();
		if (this.boundsArea) bounds.addRect(this.boundsArea, this.worldTransform);
		else {
			if (this.renderPipeId) {
				const viewBounds = this.bounds;
				localBounds.addFrame(viewBounds.minX, viewBounds.minY, viewBounds.maxX, viewBounds.maxY, this.groupTransform);
			}
			const children = this.children;
			for (let i = 0; i < children.length; i++) children[i]._getGlobalBoundsRecursive(factorRenderLayers, localBounds, currentLayer);
		}
		if (manageEffects) {
			let advanced = false;
			const renderGroup = this.renderGroup || this.parentRenderGroup;
			for (let i = 0; i < this.effects.length; i++) if (this.effects[i].addBounds) {
				if (!advanced) {
					advanced = true;
					localBounds.applyMatrix(renderGroup.worldTransform);
				}
				this.effects[i].addBounds(localBounds, true);
			}
			if (advanced) localBounds.applyMatrix(renderGroup.worldTransform.copyTo(tempMatrix$1).invert());
			bounds.addBounds(localBounds);
			boundsPool.return(localBounds);
		} else if (this.renderGroup) {
			bounds.addBounds(localBounds, this.relativeGroupTransform);
			boundsPool.return(localBounds);
		}
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/bounds/getGlobalBounds.mjs
function getGlobalBounds(target, skipUpdateTransform, bounds) {
	bounds.clear();
	let parentTransform;
	let pooledMatrix;
	if (target.parent) {
		if (!skipUpdateTransform) {
			pooledMatrix = matrixPool.get().identity();
			parentTransform = updateTransformBackwards(target, pooledMatrix);
		} else parentTransform = target.parent.worldTransform;
	} else parentTransform = Matrix.IDENTITY;
	_getGlobalBounds(target, bounds, parentTransform, skipUpdateTransform);
	if (pooledMatrix) matrixPool.return(pooledMatrix);
	if (!bounds.isValid) bounds.set(0, 0, 0, 0);
	return bounds;
}
function _getGlobalBounds(target, bounds, parentTransform, skipUpdateTransform) {
	if (!target.visible || !target.measurable) return;
	let worldTransform;
	if (!skipUpdateTransform) {
		target.updateLocalTransform();
		worldTransform = matrixPool.get();
		worldTransform.appendFrom(target.localTransform, parentTransform);
	} else worldTransform = target.worldTransform;
	const parentBounds = bounds;
	const preserveBounds = !!target.effects.length;
	if (preserveBounds) bounds = boundsPool.get().clear();
	if (target.boundsArea) bounds.addRect(target.boundsArea, worldTransform);
	else {
		const renderableBounds = target.bounds;
		if (renderableBounds && !renderableBounds.isEmpty()) {
			bounds.matrix = worldTransform;
			bounds.addBounds(renderableBounds);
		}
		for (let i = 0; i < target.children.length; i++) _getGlobalBounds(target.children[i], bounds, worldTransform, skipUpdateTransform);
	}
	if (preserveBounds) {
		for (let i = 0; i < target.effects.length; i++) target.effects[i].addBounds?.(bounds);
		parentBounds.addBounds(bounds, Matrix.IDENTITY);
		boundsPool.return(bounds);
	}
	if (!skipUpdateTransform) matrixPool.return(worldTransform);
}
function updateTransformBackwards(target, parentTransform) {
	const parent = target.parent;
	if (parent) {
		updateTransformBackwards(parent, parentTransform);
		parent.updateLocalTransform();
		parentTransform.append(parent.localTransform);
	}
	return parentTransform;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/multiplyColors.mjs
var WHITE_BGR = 16777215;
function multiplyColors(localBGRColor, parentBGRColor) {
	if (localBGRColor === WHITE_BGR) return parentBGRColor;
	if (parentBGRColor === WHITE_BGR) return localBGRColor;
	return multiplyHexColors(localBGRColor, parentBGRColor);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/getGlobalMixin.mjs
function bgr2rgb(color) {
	return ((color & 255) << 16) + (color & 65280) + (color >> 16 & 255);
}
var getGlobalMixin = {
	getGlobalAlpha(skipUpdate) {
		if (skipUpdate) {
			if (this.renderGroup) return this.renderGroup.worldAlpha;
			if (this.parentRenderGroup) return this.parentRenderGroup.worldAlpha * this.alpha;
			return this.alpha;
		}
		let alpha = this.alpha;
		let current = this.parent;
		while (current) {
			alpha *= current.alpha;
			current = current.parent;
		}
		return alpha;
	},
	getGlobalTransform(matrix = new Matrix(), skipUpdate) {
		if (skipUpdate) return matrix.copyFrom(this.worldTransform);
		this.updateLocalTransform();
		const parentTransform = updateTransformBackwards(this, matrixPool.get().identity());
		matrix.appendFrom(this.localTransform, parentTransform);
		matrixPool.return(parentTransform);
		return matrix;
	},
	getGlobalTint(skipUpdate) {
		if (skipUpdate) {
			if (this.renderGroup) return bgr2rgb(this.renderGroup.worldColor);
			if (this.parentRenderGroup) return bgr2rgb(multiplyColors(this.localColor, this.parentRenderGroup.worldColor));
			return this.tint;
		}
		let color = this.localColor;
		let parent = this.parent;
		while (parent) {
			color = multiplyColors(color, parent.localColor);
			parent = parent.parent;
		}
		return bgr2rgb(color);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/bounds/getLocalBounds.mjs
function getLocalBounds(target, bounds, relativeMatrix) {
	bounds.clear();
	relativeMatrix || (relativeMatrix = Matrix.IDENTITY);
	_getLocalBounds(target, bounds, relativeMatrix, target, true);
	if (!bounds.isValid) bounds.set(0, 0, 0, 0);
	return bounds;
}
function _getLocalBounds(target, bounds, parentTransform, rootContainer, isRoot) {
	let relativeTransform;
	if (!isRoot) {
		if (!target.visible || !target.measurable) return;
		target.updateLocalTransform();
		const localTransform = target.localTransform;
		relativeTransform = matrixPool.get();
		relativeTransform.appendFrom(localTransform, parentTransform);
	} else {
		relativeTransform = matrixPool.get();
		relativeTransform = parentTransform.copyTo(relativeTransform);
	}
	const parentBounds = bounds;
	const preserveBounds = !!target.effects.length;
	if (preserveBounds) bounds = boundsPool.get().clear();
	if (target.boundsArea) bounds.addRect(target.boundsArea, relativeTransform);
	else {
		if (target.renderPipeId) {
			bounds.matrix = relativeTransform;
			bounds.addBounds(target.bounds);
		}
		const children = target.children;
		for (let i = 0; i < children.length; i++) _getLocalBounds(children[i], bounds, relativeTransform, rootContainer, false);
	}
	if (preserveBounds) {
		for (let i = 0; i < target.effects.length; i++) target.effects[i].addLocalBounds?.(bounds, rootContainer);
		parentBounds.addBounds(bounds, Matrix.IDENTITY);
		boundsPool.return(bounds);
	}
	matrixPool.return(relativeTransform);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/checkChildrenDidChange.mjs
function checkChildrenDidChange(container, previousData) {
	const children = container.children;
	for (let i = 0; i < children.length; i++) {
		const child = children[i];
		const uid = child.uid;
		const didChange = (child._didViewChangeTick & 65535) << 16 | child._didContainerChangeTick & 65535;
		const index = previousData.index;
		if (previousData.data[index] !== uid || previousData.data[index + 1] !== didChange) {
			previousData.data[previousData.index] = uid;
			previousData.data[previousData.index + 1] = didChange;
			previousData.didChange = true;
		}
		previousData.index = index + 2;
		if (child.children.length) checkChildrenDidChange(child, previousData);
	}
	return previousData.didChange;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/measureMixin.mjs
var tempMatrix = new Matrix();
var measureMixin = {
	_localBoundsCacheId: -1,
	_localBoundsCacheData: null,
	_setWidth(value, localWidth) {
		const sign = Math.sign(this.scale.x) || 1;
		if (localWidth !== 0) this.scale.x = value / localWidth * sign;
		else this.scale.x = sign;
	},
	_setHeight(value, localHeight) {
		const sign = Math.sign(this.scale.y) || 1;
		if (localHeight !== 0) this.scale.y = value / localHeight * sign;
		else this.scale.y = sign;
	},
	getLocalBounds() {
		if (!this._localBoundsCacheData) this._localBoundsCacheData = {
			data: [],
			index: 1,
			didChange: false,
			localBounds: new Bounds()
		};
		const localBoundsCacheData = this._localBoundsCacheData;
		localBoundsCacheData.index = 1;
		localBoundsCacheData.didChange = false;
		if (localBoundsCacheData.data[0] !== this._didViewChangeTick) {
			localBoundsCacheData.didChange = true;
			localBoundsCacheData.data[0] = this._didViewChangeTick;
		}
		checkChildrenDidChange(this, localBoundsCacheData);
		if (localBoundsCacheData.didChange) getLocalBounds(this, localBoundsCacheData.localBounds, tempMatrix);
		return localBoundsCacheData.localBounds;
	},
	getBounds(skipUpdate, bounds) {
		return getGlobalBounds(this, skipUpdate, bounds || new Bounds());
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/onRenderMixin.mjs
var onRenderMixin = {
	_onRender: null,
	set onRender(func) {
		const renderGroup = this.renderGroup || this.parentRenderGroup;
		if (!func) {
			if (this._onRender) renderGroup?.removeOnRender(this);
			this._onRender = null;
			return;
		}
		if (!this._onRender) renderGroup?.addOnRender(this);
		this._onRender = func;
	},
	get onRender() {
		return this._onRender;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/sortMixin.mjs
var sortMixin = {
	_zIndex: 0,
	sortDirty: false,
	sortableChildren: false,
	get zIndex() {
		return this._zIndex;
	},
	set zIndex(value) {
		if (this._zIndex === value) return;
		this._zIndex = value;
		this.depthOfChildModified();
	},
	depthOfChildModified() {
		if (this.parent) {
			this.parent.sortableChildren = true;
			this.parent.sortDirty = true;
		}
		if (this.parentRenderGroup) this.parentRenderGroup.structureDidChange = true;
	},
	sortChildren() {
		if (!this.sortDirty) return;
		this.sortDirty = false;
		this.children.sort(sortChildren);
	}
};
function sortChildren(a, b) {
	return a._zIndex - b._zIndex;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/container-mixins/toLocalGlobalMixin.mjs
var toLocalGlobalMixin = {
	getGlobalPosition(point = new Point(), skipUpdate = false) {
		if (this.parent) this.parent.toGlobal(this._position, point, skipUpdate);
		else {
			point.x = this._position.x;
			point.y = this._position.y;
		}
		return point;
	},
	toGlobal(position, point, skipUpdate = false) {
		const globalMatrix = this.getGlobalTransform(matrixPool.get(), skipUpdate);
		point = globalMatrix.apply(position, point);
		matrixPool.return(globalMatrix);
		return point;
	},
	toLocal(position, from, point, skipUpdate) {
		if (from) position = from.toGlobal(position, point, skipUpdate);
		const globalMatrix = this.getGlobalTransform(matrixPool.get(), skipUpdate);
		point = globalMatrix.applyInverse(position, point);
		matrixPool.return(globalMatrix);
		return point;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/TexturePool.mjs
var count = 0;
var maxKeyDimension = 32767;
var scaleBit = 4294967296;
var formatBit = 8589934592;
var formatIds = /* @__PURE__ */ Object.create(null);
var nextFormatId = 0;
function formatId(format) {
	const id = formatIds[format];
	if (id !== void 0) return id;
	return formatIds[format] = nextFormatId++;
}
function bucketKey(width, height, antialias, autoGenerateMipmaps, format, scaleMode) {
	return (width << 17) + (height << 2) + ((autoGenerateMipmaps ? 1 : 0) << 1) + (antialias ? 1 : 0) + (scaleMode === "nearest" ? 1 : 0) * scaleBit + formatId(format) * formatBit;
}
var TexturePoolClass = class {
	/**
	* @param textureOptions - options that will be passed to BaseRenderTexture constructor
	* @param {SCALE_MODE} [textureOptions.scaleMode] - See {@link SCALE_MODE} for possible values.
	*/
	constructor(textureOptions) {
		/** idle textures, keyed by format, scale mode, size and flags */
		this._buckets = /* @__PURE__ */ new Map();
		/** the bucket key of every texture handed out, by texture uid */
		this._poolKey = /* @__PURE__ */ Object.create(null);
		/** the style the pool created for every texture handed out, by texture uid */
		this._poolStyle = /* @__PURE__ */ Object.create(null);
		/** the screens this pool is sizing its textures for */
		this._screens = new ScreenSizeRegistry();
		this._enableFullScreen = false;
		this.textureOptions = textureOptions || {};
	}
	/**
	* A style built from the pool options. The pool no longer applies it to anything.
	* @deprecated since 8.21.0, pooled textures carry their own style; pass `scaleMode` in the request instead.
	*/
	get textureStyle() {
		deprecation(v8_21_0, "TexturePool.textureStyle is no longer used, pooled textures carry their own style. Pass scaleMode in the request instead.");
		if (!this._textureStyle) this._textureStyle = new TextureStyle(this.textureOptions);
		return this._textureStyle;
	}
	set textureStyle(value) {
		deprecation(v8_21_0, "TexturePool.textureStyle is no longer used, pooled textures carry their own style. Pass scaleMode in the request instead.");
		this._textureStyle = value;
	}
	/**
	* Has no effect. The pool sizes textures to the screens registered with
	* {@link TexturePoolClass#setScreenSize|setScreenSize}.
	* @deprecated since 8.21.0
	*/
	get enableFullScreen() {
		deprecation(v8_21_0, "TexturePool.enableFullScreen is no longer used, the pool sizes textures to the screens registered with setScreenSize.");
		return this._enableFullScreen;
	}
	set enableFullScreen(value) {
		deprecation(v8_21_0, "TexturePool.enableFullScreen is no longer used, the pool sizes textures to the screens registered with setScreenSize.");
		this._enableFullScreen = value;
	}
	createTexture(...args) {
		let options = args[0];
		if (typeof options === "number") {
			deprecation(v8_21_0, "TexturePool.createTexture params are now an options object. See params: { width, height, antialias, autoGenerateMipmaps }");
			options = {
				width: options,
				height: args[1],
				antialias: args[2] ?? false,
				autoGenerateMipmaps: args[3] ?? false
			};
		}
		const format = options.format ?? this.textureOptions.format ?? TextureSource.defaultOptions.format;
		const scaleMode = options.scaleMode ?? this.textureOptions.scaleMode ?? TextureStyle.defaultOptions.scaleMode;
		const textureSource = new TextureSource({
			...this.textureOptions,
			width: options.width,
			height: options.height,
			resolution: 1,
			antialias: options.antialias ?? false,
			autoGarbageCollect: false,
			autoGenerateMipmaps: options.autoGenerateMipmaps ?? false,
			format,
			scaleMode
		});
		return new Texture({
			source: textureSource,
			label: `texturePool_${count++}`
		});
	}
	getOptimalTexture(...args) {
		let options = args[0];
		if (typeof options === "number") {
			deprecation(v8_21_0, "TexturePool.getOptimalTexture params are now an options object. See params: { width, height, resolution, antialias, autoGenerateMipmaps }");
			options = {
				width: options,
				height: args[1],
				resolution: args[2] ?? 1,
				antialias: args[3] ?? false,
				autoGenerateMipmaps: args[4] ?? false
			};
		}
		const frameWidth = options.width;
		const frameHeight = options.height;
		const resolution = options.resolution ?? 1;
		const antialias = options.antialias ?? false;
		const autoGenerateMipmaps = options.autoGenerateMipmaps ?? false;
		const format = options.format ?? this.textureOptions.format ?? TextureSource.defaultOptions.format;
		const scaleMode = options.scaleMode ?? this.textureOptions.scaleMode ?? TextureStyle.defaultOptions.scaleMode;
		const { width: textureWidth, height: textureHeight } = this.getOptimalSize(frameWidth, frameHeight, resolution);
		if (textureWidth > maxKeyDimension || textureHeight > maxKeyDimension) warn(`TexturePool: ${textureWidth}x${textureHeight} is larger than the ${maxKeyDimension}px pool key limit, textures of this size may be pooled together`);
		const key = bucketKey(textureWidth, textureHeight, antialias, autoGenerateMipmaps, format, scaleMode);
		let bucket = this._buckets.get(key);
		if (!bucket) {
			bucket = [];
			this._buckets.set(key, bucket);
		}
		let texture = bucket.pop();
		if (!texture) {
			texture = this.createTexture({
				width: textureWidth,
				height: textureHeight,
				antialias,
				autoGenerateMipmaps,
				format,
				scaleMode
			});
			this._poolStyle[texture.uid] = texture.source.style;
		}
		texture.source._resolution = resolution;
		texture.source.width = textureWidth / resolution;
		texture.source.height = textureHeight / resolution;
		texture.source.pixelWidth = textureWidth;
		texture.source.pixelHeight = textureHeight;
		texture.frame.x = 0;
		texture.frame.y = 0;
		texture.frame.width = frameWidth;
		texture.frame.height = frameHeight;
		texture.updateUvs();
		this._poolKey[texture.uid] = key;
		return texture;
	}
	/**
	* The backing size, in physical pixels, that {@link TexturePoolClass#getOptimalTexture|getOptimalTexture}
	* would allocate for a request, without taking a texture from the pool.
	*
	* Each axis is the next power of two, or the smallest registered screen the request fits inside
	* (see {@link TexturePoolClass#setScreenSize|setScreenSize}). Use it when a consumer needs to know
	* where a request's content will sit inside its pooled texture before it has one, such as a uniform
	* that maps content space onto texture space.
	* @param frameWidth - The minimum width of the texture.
	* @param frameHeight - The minimum height of the texture.
	* @param resolution - The resolution of the texture.
	* @returns The width and height the pooled texture would have, in physical pixels.
	*/
	getOptimalSize(frameWidth, frameHeight, resolution = 1) {
		const pixelWidth = Math.ceil(frameWidth * resolution - 1e-6);
		const pixelHeight = Math.ceil(frameHeight * resolution - 1e-6);
		const po2Width = nextPow2(pixelWidth);
		const screenWidth = this._screens.getFittingWidth(pixelWidth);
		const po2Height = nextPow2(pixelHeight);
		const screenHeight = this._screens.getFittingHeight(pixelHeight);
		return {
			width: screenWidth !== void 0 ? Math.min(screenWidth, po2Width) : po2Width,
			height: screenHeight !== void 0 ? Math.min(screenHeight, po2Height) : po2Height
		};
	}
	/**
	* Gets a pooled texture matching the dimensions and resolution of the given texture.
	*
	* This is a convenience wrapper around {@link TexturePoolClass#getOptimalTexture|getOptimalTexture}
	* that copies width, height, and resolution from an existing texture. Useful when a filter needs
	* a temporary texture the same size as its input (e.g., for multi-pass blur).
	* @param texture - The texture whose dimensions to match.
	* @param antialias - Whether to use antialias on the pooled texture. Defaults to `false`.
	* @returns A pooled texture with power-of-two or screen sized backing dimensions at the source resolution.
	*/
	getSameSizeTexture(texture, antialias = false) {
		const source = texture.source;
		return this.getOptimalTexture({
			width: texture.width,
			height: texture.height,
			resolution: source._resolution,
			antialias
		});
	}
	/**
	* Returns a texture to the pool so it can be reused by future
	* {@link TexturePoolClass#getOptimalTexture|getOptimalTexture}
	* or {@link TexturePoolClass#getSameSizeTexture|getSameSizeTexture} calls.
	*
	* If you gave the texture a style of your own after obtaining it (a different address mode, anisotropy
	* or similar), pass `resetStyle = true` so the pool puts its own style back. Otherwise your style stays
	* on the texture and the next consumer inherits it.
	* @param renderTexture - The texture to return to the pool.
	* @param resetStyle - When `true`, restores the style the pool created for this texture. Defaults to `false`.
	*/
	returnTexture(renderTexture, resetStyle = false) {
		const uid = renderTexture.uid;
		const key = this._poolKey[uid];
		if (key === void 0) {
			warn("TexturePool: returnTexture was passed a texture that did not come from this pool, ignoring it");
			return;
		}
		const poolStyle = this._poolStyle[uid];
		if (resetStyle && renderTexture.source.style !== poolStyle) renderTexture.source.style = poolStyle;
		const textures = this._buckets.get(key);
		if (!textures) {
			delete this._poolKey[uid];
			delete this._poolStyle[uid];
			renderTexture.destroy(true);
			return;
		}
		textures.push(renderTexture);
	}
	/**
	* Registers the screen size of a renderer with the pool, in physical pixels.
	*
	* While a screen is registered, a request that fits inside it on an axis is given that screen's size on
	* that axis instead of the next power of two, which stops a full screen filter from allocating a texture
	* far larger than the screen. Requests larger than every registered screen on an axis keep the power of
	* two size - the pool never rounds a request up to a screen it does not fit in.
	* @param rendererUid - The uid of the renderer, used to update or remove this screen later.
	* @param pixelWidth - The width of the screen in physical pixels.
	* @param pixelHeight - The height of the screen in physical pixels.
	*/
	setScreenSize(rendererUid, pixelWidth, pixelHeight) {
		if (!this._screens.set(rendererUid, pixelWidth, pixelHeight)) return;
		this._pruneScreenTextures();
	}
	/**
	* Removes a screen previously registered with
	* {@link TexturePoolClass#setScreenSize|setScreenSize}, destroying any idle textures that were
	* only being kept for it.
	* @param rendererUid - The uid the screen was registered with.
	*/
	removeScreen(rendererUid) {
		if (!this._screens.remove(rendererUid)) return;
		this._pruneScreenTextures();
	}
	/**
	* Destroys the idle textures in every bucket that has a non power of two dimension matching no live
	* screen. Power of two buckets are always kept, as any request can fall back to them.
	*/
	_pruneScreenTextures() {
		for (const [key, textures] of this._buckets) {
			const packed = key >>> 0;
			const width = packed >>> 17;
			const height = packed >>> 2 & 32767;
			if ((isPow2(width) || this._screens.hasWidth(width)) && (isPow2(height) || this._screens.hasHeight(height))) continue;
			this._dropTextures(textures, true);
			this._buckets.delete(key);
		}
	}
	/**
	* Forgets idle textures were ever handed out, so a later return is ignored, and optionally destroys them.
	* @param textures - The textures of one bucket.
	* @param destroy - Whether to destroy the textures as well.
	*/
	_dropTextures(textures, destroy) {
		for (let i = 0; i < textures.length; i++) {
			const texture = textures[i];
			delete this._poolKey[texture.uid];
			delete this._poolStyle[texture.uid];
			if (destroy) texture.destroy(true);
		}
	}
	/**
	* Clears the pool.
	* @param destroyTextures - Destroy all stored textures.
	*/
	clear(destroyTextures) {
		for (const textures of this._buckets.values()) this._dropTextures(textures, destroyTextures !== false);
		this._buckets.clear();
	}
};
var TexturePool = new TexturePoolClass();
GlobalResourceRegistry.register(TexturePool);
//#endregion
//#region node_modules/pixi.js/lib/scene/container/RenderGroup.mjs
var RenderGroup = class {
	constructor() {
		this.renderPipeId = "renderGroup";
		this.root = null;
		this.canBundle = false;
		this.renderGroupParent = null;
		this.renderGroupChildren = [];
		this.worldTransform = new Matrix();
		this.worldColorAlpha = 4294967295;
		this.worldColor = 16777215;
		this.worldAlpha = 1;
		this.childrenToUpdate = /* @__PURE__ */ Object.create(null);
		this.updateTick = 0;
		this.gcTick = 0;
		this.childrenRenderablesToUpdate = {
			list: [],
			index: 0
		};
		this.structureDidChange = true;
		this.instructionSet = new InstructionSet();
		this._onRenderContainers = [];
		/**
		* Indicates if the cached texture needs to be updated.
		* @default true
		*/
		this.textureNeedsUpdate = true;
		/**
		* Indicates if the container should be cached as a texture.
		* @default false
		*/
		this.isCachedAsTexture = false;
		this._matrixDirty = 7;
	}
	init(root) {
		this.root = root;
		if (root._onRender) this.addOnRender(root);
		root.didChange = true;
		const children = root.children;
		for (let i = 0; i < children.length; i++) {
			const child = children[i];
			child._updateFlags = 15;
			this.addChild(child);
		}
	}
	enableCacheAsTexture(options = {}) {
		this.textureOptions = options;
		this.isCachedAsTexture = true;
		this.textureNeedsUpdate = true;
	}
	disableCacheAsTexture() {
		this.isCachedAsTexture = false;
		if (this.texture) {
			TexturePool.returnTexture(this.texture);
			this.texture = null;
		}
	}
	updateCacheTexture() {
		this.textureNeedsUpdate = true;
		const cachedParent = this._parentCacheAsTextureRenderGroup;
		if (cachedParent && !cachedParent.textureNeedsUpdate) cachedParent.updateCacheTexture();
	}
	reset() {
		this.renderGroupChildren.length = 0;
		for (const i in this.childrenToUpdate) {
			const childrenAtDepth = this.childrenToUpdate[i];
			childrenAtDepth.list.fill(null);
			childrenAtDepth.index = 0;
		}
		this.childrenRenderablesToUpdate.index = 0;
		this.childrenRenderablesToUpdate.list.fill(null);
		this.root = null;
		this.updateTick = 0;
		this.structureDidChange = true;
		this._onRenderContainers.length = 0;
		this.renderGroupParent = null;
		this.disableCacheAsTexture();
	}
	get localTransform() {
		return this.root.localTransform;
	}
	addRenderGroupChild(renderGroupChild) {
		if (renderGroupChild.renderGroupParent) renderGroupChild.renderGroupParent._removeRenderGroupChild(renderGroupChild);
		renderGroupChild.renderGroupParent = this;
		this.renderGroupChildren.push(renderGroupChild);
	}
	_removeRenderGroupChild(renderGroupChild) {
		const index = this.renderGroupChildren.indexOf(renderGroupChild);
		if (index > -1) this.renderGroupChildren.splice(index, 1);
		renderGroupChild.renderGroupParent = null;
	}
	addChild(child) {
		this.structureDidChange = true;
		child.parentRenderGroup = this;
		child.updateTick = -1;
		if (child.parent === this.root) child.relativeRenderGroupDepth = 1;
		else child.relativeRenderGroupDepth = child.parent.relativeRenderGroupDepth + 1;
		child.didChange = true;
		this.onChildUpdate(child);
		if (child.renderGroup) {
			this.addRenderGroupChild(child.renderGroup);
			return;
		}
		if (child._onRender) this.addOnRender(child);
		const children = child.children;
		for (let i = 0; i < children.length; i++) this.addChild(children[i]);
	}
	removeChild(child) {
		this.structureDidChange = true;
		if (child._onRender) {
			if (!child.renderGroup) this.removeOnRender(child);
		}
		child.parentRenderGroup = null;
		if (child.renderGroup) {
			this._removeRenderGroupChild(child.renderGroup);
			return;
		}
		const children = child.children;
		for (let i = 0; i < children.length; i++) this.removeChild(children[i]);
	}
	removeChildren(children) {
		for (let i = 0; i < children.length; i++) this.removeChild(children[i]);
	}
	onChildUpdate(child) {
		let childrenToUpdate = this.childrenToUpdate[child.relativeRenderGroupDepth];
		if (!childrenToUpdate) childrenToUpdate = this.childrenToUpdate[child.relativeRenderGroupDepth] = {
			index: 0,
			list: []
		};
		childrenToUpdate.list[childrenToUpdate.index++] = child;
	}
	updateRenderable(renderable) {
		if (renderable.globalDisplayStatus < 7) return;
		this.instructionSet.renderPipes[renderable.renderPipeId].updateRenderable(renderable);
		renderable.didViewUpdate = false;
	}
	onChildViewUpdate(child) {
		this.childrenRenderablesToUpdate.list[this.childrenRenderablesToUpdate.index++] = child;
	}
	get isRenderable() {
		return this.root.localDisplayStatus === 7 && this.worldAlpha > 0;
	}
	/**
	* adding a container to the onRender list will make sure the user function
	* passed in to the user defined 'onRender` callBack
	* @param container - the container to add to the onRender list
	*/
	addOnRender(container) {
		if (this._onRenderContainers.indexOf(container) === -1) this._onRenderContainers.push(container);
	}
	removeOnRender(container) {
		const idx = this._onRenderContainers.indexOf(container);
		if (idx !== -1) this._onRenderContainers.splice(idx, 1);
	}
	runOnRender(renderer) {
		for (let i = 0; i < this._onRenderContainers.length; i++) this._onRenderContainers[i]._onRender(renderer);
	}
	destroy() {
		this.disableCacheAsTexture();
		this.renderGroupParent = null;
		this.root = null;
		this.childrenRenderablesToUpdate = null;
		this.childrenToUpdate = null;
		this.renderGroupChildren = null;
		this._onRenderContainers = null;
		this.instructionSet?.destroy();
		this.instructionSet = null;
	}
	getChildren(out = []) {
		const children = this.root.children;
		for (let i = 0; i < children.length; i++) this._getChildren(children[i], out);
		return out;
	}
	_getChildren(container, out = []) {
		out.push(container);
		if (container.renderGroup) return out;
		const children = container.children;
		for (let i = 0; i < children.length; i++) this._getChildren(children[i], out);
		return out;
	}
	invalidateMatrices() {
		this._matrixDirty = 7;
	}
	/**
	* Returns the inverse of the world transform matrix.
	* @returns {Matrix} The inverse of the world transform matrix.
	*/
	get inverseWorldTransform() {
		if ((this._matrixDirty & 1) === 0) return this._inverseWorldTransform;
		this._matrixDirty &= -2;
		this._inverseWorldTransform || (this._inverseWorldTransform = new Matrix());
		return this._inverseWorldTransform.copyFrom(this.worldTransform).invert();
	}
	/**
	* Returns the inverse of the texture offset transform matrix.
	* @returns {Matrix} The inverse of the texture offset transform matrix.
	*/
	get textureOffsetInverseTransform() {
		if ((this._matrixDirty & 2) === 0) return this._textureOffsetInverseTransform;
		this._matrixDirty &= -3;
		this._textureOffsetInverseTransform || (this._textureOffsetInverseTransform = new Matrix());
		return this._textureOffsetInverseTransform.copyFrom(this.inverseWorldTransform).translate(-this._textureBounds.x, -this._textureBounds.y);
	}
	/**
	* Returns the inverse of the parent texture transform matrix.
	* This is used to properly transform coordinates when rendering into cached textures.
	* @returns {Matrix} The inverse of the parent texture transform matrix.
	*/
	get inverseParentTextureTransform() {
		if ((this._matrixDirty & 4) === 0) return this._inverseParentTextureTransform;
		this._matrixDirty &= -5;
		const parentCacheAsTexture = this._parentCacheAsTextureRenderGroup;
		if (parentCacheAsTexture) {
			this._inverseParentTextureTransform || (this._inverseParentTextureTransform = new Matrix());
			return this._inverseParentTextureTransform.copyFrom(this.worldTransform).prepend(parentCacheAsTexture.inverseWorldTransform).translate(-parentCacheAsTexture._textureBounds.x, -parentCacheAsTexture._textureBounds.y);
		}
		return this.worldTransform;
	}
	/**
	* Returns a matrix that transforms coordinates to the correct coordinate space of the texture being rendered to.
	* This is the texture offset inverse transform of the closest parent RenderGroup that is cached as a texture.
	* @returns {Matrix | null} The transform matrix for the cached texture coordinate space,
	* or null if no parent is cached as texture.
	*/
	get cacheToLocalTransform() {
		if (this.isCachedAsTexture) return this.textureOffsetInverseTransform;
		if (!this._parentCacheAsTextureRenderGroup) return null;
		return this._parentCacheAsTextureRenderGroup.textureOffsetInverseTransform;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/assignWithIgnore.mjs
function assignWithIgnore(target, options, ignore = {}) {
	for (const key in options) if (!ignore[key] && options[key] !== void 0) target[key] = options[key];
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/Container.mjs
var defaultSkew = new ObservablePoint(null);
var defaultPivot = new ObservablePoint(null);
var defaultScale = new ObservablePoint(null, 1, 1);
var defaultOrigin = new ObservablePoint(null);
var UPDATE_COLOR = 1;
var UPDATE_BLEND = 2;
var UPDATE_VISIBLE = 4;
var UPDATE_TRANSFORM = 8;
var Container = class Container extends eventemitter3_default {
	constructor(options = {}) {
		super();
		/**
		* unique id for this container
		* @internal
		*/
		this.uid = uid("renderable");
		/** @private */
		this._updateFlags = 15;
		/** @private */
		this.renderGroup = null;
		/** @private */
		this.parentRenderGroup = null;
		/** @private */
		this.parentRenderGroupIndex = 0;
		/** @private */
		this.didChange = false;
		/** @private */
		this.didViewUpdate = false;
		/** @private */
		this.relativeRenderGroupDepth = 0;
		/**
		* The array of children of this container. Each child must be a Container or extend from it.
		*
		* The array is read-only, but its contents can be modified using Container methods.
		* @example
		* ```ts
		* // Access children
		* const firstChild = container.children[0];
		* const lastChild = container.children[container.children.length - 1];
		* ```
		* @readonly
		* @see {@link Container#addChild} For adding children
		* @see {@link Container#removeChild} For removing children
		*/
		this.children = [];
		/**
		* The display object container that contains this display object.
		* This represents the parent-child relationship in the display tree.
		* @example
		* ```ts
		* // Basic parent access
		* const parent = sprite.parent;
		*
		* // Walk up the tree
		* let current = sprite;
		* while (current.parent) {
		*     console.log('Level up:', current.parent.constructor.name);
		*     current = current.parent;
		* }
		* ```
		* @readonly
		* @see {@link Container#addChild} For adding to a parent
		* @see {@link Container#removeChild} For removing from parent
		*/
		this.parent = null;
		/** @private */
		this.includeInBuild = true;
		/** @private */
		this.measurable = true;
		/** @private */
		this.isSimple = true;
		/**
		* The RenderLayer this container belongs to, if any.
		* If it belongs to a RenderLayer, it will be rendered from the RenderLayer's position in the scene.
		* @readonly
		* @advanced
		*/
		this.parentRenderLayer = null;
		/** @internal */
		this.updateTick = -1;
		/**
		* Current transform of the object based on local factors: position, scale, other stuff.
		* This matrix represents the local transformation without any parent influence.
		* @example
		* ```ts
		* // Basic transform access
		* const localMatrix = sprite.localTransform;
		* console.log(localMatrix.toString());
		* ```
		* @readonly
		* @see {@link Container#worldTransform} For global transform
		* @see {@link Container#groupTransform} For render group transform
		*/
		this.localTransform = new Matrix();
		/**
		* The relative group transform is a transform relative to the render group it belongs too. It will include all parent
		* transforms and up to the render group (think of it as kind of like a stage - but the stage can be nested).
		* If this container is is self a render group matrix will be relative to its parent render group
		* @readonly
		* @advanced
		*/
		this.relativeGroupTransform = new Matrix();
		/**
		* The group transform is a transform relative to the render group it belongs too.
		* If this container is render group then this will be an identity matrix. other wise it
		* will be the same as the relativeGroupTransform.
		* Use this value when actually rendering things to the screen
		* @readonly
		* @advanced
		*/
		this.groupTransform = this.relativeGroupTransform;
		/**
		* Whether this object has been destroyed. If true, the object should no longer be used.
		* After an object is destroyed, all of its functionality is disabled and references are removed.
		* @example
		* ```ts
		* // Cleanup with destroy
		* sprite.destroy();
		* console.log(sprite.destroyed); // true
		* ```
		* @default false
		* @see {@link Container#destroy} For destroying objects
		*/
		this.destroyed = false;
		/**
		* The coordinate of the object relative to the local coordinates of the parent.
		* @internal
		*/
		this._position = new ObservablePoint(this, 0, 0);
		/**
		* The scale factor of the object.
		* @internal
		*/
		this._scale = defaultScale;
		/**
		* The pivot point of the container that it rotates around.
		* @internal
		*/
		this._pivot = defaultPivot;
		/**
		* The origin point around which the container rotates and scales.
		* Unlike pivot, changing origin will not move the container's position.
		* @private
		*/
		this._origin = defaultOrigin;
		/**
		* The skew amount, on the x and y axis.
		* @internal
		*/
		this._skew = defaultSkew;
		/**
		* The X-coordinate value of the normalized local X axis,
		* the first column of the local transformation matrix without a scale.
		* @internal
		*/
		this._cx = 1;
		/**
		* The Y-coordinate value of the normalized local X axis,
		* the first column of the local transformation matrix without a scale.
		* @internal
		*/
		this._sx = 0;
		/**
		* The X-coordinate value of the normalized local Y axis,
		* the second column of the local transformation matrix without a scale.
		* @internal
		*/
		this._cy = 0;
		/**
		* The Y-coordinate value of the normalized local Y axis,
		* the second column of the local transformation matrix without a scale.
		* @internal
		*/
		this._sy = 1;
		/**
		* The rotation amount.
		* @internal
		*/
		this._rotation = 0;
		/** @internal */
		this.localColor = 16777215;
		/** @internal */
		this.localAlpha = 1;
		/** @internal */
		this.groupAlpha = 1;
		/** @internal */
		this.groupColor = 16777215;
		/** @internal */
		this.groupColorAlpha = 4294967295;
		/** @internal */
		this.localBlendMode = "inherit";
		/** @internal */
		this.groupBlendMode = "normal";
		/**
		* This property holds three bits: culled, visible, renderable
		* the third bit represents culling (0 = culled, 1 = not culled) 0b100
		* the second bit represents visibility (0 = not visible, 1 = visible) 0b010
		* the first bit represents renderable (0 = not renderable, 1 = renderable) 0b001
		* @internal
		*/
		this.localDisplayStatus = 7;
		/** @internal */
		this.globalDisplayStatus = 7;
		/**
		* A value that increments each time the containe is modified
		* eg children added, removed etc
		* @ignore
		*/
		this._didContainerChangeTick = 0;
		/**
		* A value that increments each time the container view is modified
		* eg texture swap, geometry change etc
		* @ignore
		*/
		this._didViewChangeTick = 0;
		/**
		* property that tracks if the container transform has changed
		* @ignore
		*/
		this._didLocalTransformChangeId = -1;
		this.effects = [];
		assignWithIgnore(this, options, {
			children: true,
			parent: true,
			effects: true
		});
		options.children?.forEach((child) => this.addChild(child));
		options.parent?.addChild(this);
	}
	/**
	* Mixes all enumerable properties and methods from a source object to Container.
	* @param source - The source of properties and methods to mix in.
	* @deprecated since 8.8.0
	*/
	static mixin(source) {
		deprecation("8.8.0", "Container.mixin is deprecated, please use extensions.mixin instead.");
		extensions.mixin(Container, source);
	}
	/**
	* We now use the _didContainerChangeTick and _didViewChangeTick to track changes
	* @deprecated since 8.2.6
	* @ignore
	*/
	set _didChangeId(value) {
		this._didViewChangeTick = value >> 12 & 4095;
		this._didContainerChangeTick = value & 4095;
	}
	/** @ignore */
	get _didChangeId() {
		return this._didContainerChangeTick & 4095 | (this._didViewChangeTick & 4095) << 12;
	}
	/**
	* Adds one or more children to the container.
	* The children will be rendered as part of this container's display list.
	* @example
	* ```ts
	* // Add a single child
	* container.addChild(sprite);
	*
	* // Add multiple children
	* container.addChild(background, player, foreground);
	*
	* // Add with type checking
	* const sprite = container.addChild<Sprite>(new Sprite(texture));
	* sprite.tint = 'red';
	* ```
	* @param children - The Container(s) to add to the container
	* @returns The first child that was added
	* @see {@link Container#removeChild} For removing children
	* @see {@link Container#addChildAt} For adding at specific index
	*/
	addChild(...children) {
		if (!this.allowChildren) deprecation(v8_0_0, "addChild: Only Containers will be allowed to add children in v8.0.0");
		if (children.length > 1) {
			for (let i = 0; i < children.length; i++) this.addChild(children[i]);
			return children[0];
		}
		const child = children[0];
		const renderGroup = this.renderGroup || this.parentRenderGroup;
		if (child.parent === this) {
			this.children.splice(this.children.indexOf(child), 1);
			this.children.push(child);
			if (renderGroup) renderGroup.structureDidChange = true;
			return child;
		}
		if (child.parent) child.parent.removeChild(child);
		this.children.push(child);
		if (this.sortableChildren) this.sortDirty = true;
		child.parent = this;
		child.didChange = true;
		child._updateFlags = 15;
		if (renderGroup) renderGroup.addChild(child);
		this.emit("childAdded", child, this, this.children.length - 1);
		child.emit("added", this);
		this._didViewChangeTick++;
		if (child._zIndex !== 0) child.depthOfChildModified();
		return child;
	}
	/**
	* Removes one or more children from the container.
	* When removing multiple children, events will be triggered for each child in sequence.
	* @example
	* ```ts
	* // Remove a single child
	* const removed = container.removeChild(sprite);
	*
	* // Remove multiple children
	* const bg = container.removeChild(background, player, userInterface);
	*
	* // Remove with type checking
	* const sprite = container.removeChild<Sprite>(childSprite);
	* sprite.texture = newTexture;
	* ```
	* @param children - The Container(s) to remove
	* @returns The first child that was removed
	* @see {@link Container#addChild} For adding children
	* @see {@link Container#removeChildren} For removing multiple children
	*/
	removeChild(...children) {
		if (children.length > 1) {
			for (let i = 0; i < children.length; i++) this.removeChild(children[i]);
			return children[0];
		}
		const child = children[0];
		const index = this.children.indexOf(child);
		if (index > -1) {
			this._didViewChangeTick++;
			this.children.splice(index, 1);
			if (this.renderGroup) this.renderGroup.removeChild(child);
			else if (this.parentRenderGroup) this.parentRenderGroup.removeChild(child);
			if (child.parentRenderLayer) child.parentRenderLayer.detach(child);
			child.parent = null;
			this.emit("childRemoved", child, this, index);
			child.emit("removed", this);
		}
		return child;
	}
	/** @ignore */
	_onUpdate(point) {
		if (point) {
			if (point === this._skew) this._updateSkew();
		}
		this._didContainerChangeTick++;
		if (this.didChange) return;
		this.didChange = true;
		if (this.parentRenderGroup) this.parentRenderGroup.onChildUpdate(this);
	}
	set isRenderGroup(value) {
		if (!!this.renderGroup === value) return;
		if (value) this.enableRenderGroup();
		else this.disableRenderGroup();
	}
	/**
	* Returns true if this container is a render group.
	* This means that it will be rendered as a separate pass, with its own set of instructions
	* @advanced
	*/
	get isRenderGroup() {
		return !!this.renderGroup;
	}
	/**
	* Calling this enables a render group for this container.
	* This means it will be rendered as a separate set of instructions.
	* The transform of the container will also be handled on the GPU rather than the CPU.
	* @advanced
	*/
	enableRenderGroup() {
		if (this.renderGroup) return;
		const parentRenderGroup = this.parentRenderGroup;
		parentRenderGroup?.removeChild(this);
		this.renderGroup = BigPool.get(RenderGroup, this);
		this.groupTransform = Matrix.IDENTITY;
		parentRenderGroup?.addChild(this);
		this._updateIsSimple();
	}
	/**
	* This will disable the render group for this container.
	* @advanced
	*/
	disableRenderGroup() {
		if (!this.renderGroup) return;
		const parentRenderGroup = this.parentRenderGroup;
		parentRenderGroup?.removeChild(this);
		BigPool.return(this.renderGroup);
		this.renderGroup = null;
		this.groupTransform = this.relativeGroupTransform;
		parentRenderGroup?.addChild(this);
		this._updateIsSimple();
	}
	/** @ignore */
	_updateIsSimple() {
		this.isSimple = !this.renderGroup && this.effects.length === 0;
	}
	/**
	* Current transform of the object based on world (parent) factors.
	*
	* This matrix represents the absolute transformation in the scene graph.
	* @example
	* ```ts
	* // Get world position
	* const worldPos = container.worldTransform;
	* console.log(`World position: (${worldPos.tx}, ${worldPos.ty})`);
	* ```
	* @readonly
	* @see {@link Container#localTransform} For local space transform
	*/
	get worldTransform() {
		this._worldTransform || (this._worldTransform = new Matrix());
		if (this.renderGroup) this._worldTransform.copyFrom(this.renderGroup.worldTransform);
		else if (this.parentRenderGroup) this._worldTransform.appendFrom(this.relativeGroupTransform, this.parentRenderGroup.worldTransform);
		return this._worldTransform;
	}
	/**
	* The position of the container on the x axis relative to the local coordinates of the parent.
	*
	* An alias to position.x
	* @example
	* ```ts
	* // Basic position
	* container.x = 100;
	* ```
	*/
	get x() {
		return this._position.x;
	}
	set x(value) {
		this._position.x = value;
	}
	/**
	* The position of the container on the y axis relative to the local coordinates of the parent.
	*
	* An alias to position.y
	* @example
	* ```ts
	* // Basic position
	* container.y = 200;
	* ```
	*/
	get y() {
		return this._position.y;
	}
	set y(value) {
		this._position.y = value;
	}
	/**
	* The coordinate of the object relative to the local coordinates of the parent.
	* @example
	* ```ts
	* // Basic position setting
	* container.position.set(100, 200);
	* container.position.set(100); // Sets both x and y to 100
	* // Using point data
	* container.position = { x: 50, y: 75 };
	* ```
	* @since 4.0.0
	*/
	get position() {
		return this._position;
	}
	set position(value) {
		this._position.copyFrom(value);
	}
	/**
	* The rotation of the object in radians.
	*
	* > [!NOTE] 'rotation' and 'angle' have the same effect on a display object;
	* > rotation is in radians, angle is in degrees.
	* @example
	* ```ts
	* // Basic rotation
	* container.rotation = Math.PI / 4; // 45 degrees
	*
	* // Convert from degrees
	* const degrees = 45;
	* container.rotation = degrees * Math.PI / 180;
	*
	* // Rotate around center
	* container.pivot.set(container.width / 2, container.height / 2);
	* container.rotation = Math.PI; // 180 degrees
	*
	* // Rotate around center with origin
	* container.origin.set(container.width / 2, container.height / 2);
	* container.rotation = Math.PI; // 180 degrees
	* ```
	*/
	get rotation() {
		return this._rotation;
	}
	set rotation(value) {
		if (this._rotation !== value) {
			this._rotation = value;
			this._onUpdate(this._skew);
		}
	}
	/**
	* The angle of the object in degrees.
	*
	* > [!NOTE] 'rotation' and 'angle' have the same effect on a display object;
	* > rotation is in radians, angle is in degrees.
	* @example
	* ```ts
	* // Basic angle rotation
	* sprite.angle = 45; // 45 degrees
	*
	* // Rotate around center
	* sprite.pivot.set(sprite.width / 2, sprite.height / 2);
	* sprite.angle = 180; // Half rotation
	*
	* // Rotate around center with origin
	* sprite.origin.set(sprite.width / 2, sprite.height / 2);
	* sprite.angle = 180; // Half rotation
	*
	* // Reset rotation
	* sprite.angle = 0;
	* ```
	*/
	get angle() {
		return this.rotation * RAD_TO_DEG;
	}
	set angle(value) {
		this.rotation = value * DEG_TO_RAD;
	}
	/**
	* The center of rotation, scaling, and skewing for this display object in its local space.
	* The `position` is the projection of `pivot` in the parent's local space.
	*
	* By default, the pivot is the origin (0, 0).
	* @example
	* ```ts
	* // Rotate around center
	* container.pivot.set(container.width / 2, container.height / 2);
	* container.rotation = Math.PI; // Rotates around center
	* ```
	* @since 4.0.0
	*/
	get pivot() {
		if (this._pivot === defaultPivot) this._pivot = new ObservablePoint(this, 0, 0);
		return this._pivot;
	}
	set pivot(value) {
		if (this._pivot === defaultPivot) {
			this._pivot = new ObservablePoint(this, 0, 0);
			if (this._origin !== defaultOrigin) warn(`Setting both a pivot and origin on a Container is not recommended. This can lead to unexpected behavior if not handled carefully.`);
		}
		typeof value === "number" ? this._pivot.set(value) : this._pivot.copyFrom(value);
	}
	/**
	* The skew factor for the object in radians. Skewing is a transformation that distorts
	* the object by rotating it differently at each point, creating a non-uniform shape.
	* @example
	* ```ts
	* // Basic skewing
	* container.skew.set(0.5, 0); // Skew horizontally
	* container.skew.set(0, 0.5); // Skew vertically
	*
	* // Skew with point data
	* container.skew = { x: 0.3, y: 0.3 }; // Diagonal skew
	*
	* // Reset skew
	* container.skew.set(0, 0);
	*
	* // Animate skew
	* app.ticker.add(() => {
	*     // Create wave effect
	*     container.skew.x = Math.sin(Date.now() / 1000) * 0.3;
	* });
	*
	* // Combine with rotation
	* container.rotation = Math.PI / 4; // 45 degrees
	* container.skew.set(0.2, 0.2); // Skew the rotated object
	* ```
	* @since 4.0.0
	* @type {ObservablePoint} Point-like object with x/y properties in radians
	* @default {x: 0, y: 0}
	*/
	get skew() {
		if (this._skew === defaultSkew) this._skew = new ObservablePoint(this, 0, 0);
		return this._skew;
	}
	set skew(value) {
		if (this._skew === defaultSkew) this._skew = new ObservablePoint(this, 0, 0);
		this._skew.copyFrom(value);
	}
	/**
	* The scale factors of this object along the local coordinate axes.
	*
	* The default scale is (1, 1).
	* @example
	* ```ts
	* // Basic scaling
	* container.scale.set(2, 2); // Scales to double size
	* container.scale.set(2); // Scales uniformly to double size
	* container.scale = 2; // Scales uniformly to double size
	* // Scale to a specific width and height
	* container.setSize(200, 100); // Sets width to 200 and height to 100
	* ```
	* @since 4.0.0
	*/
	get scale() {
		if (this._scale === defaultScale) this._scale = new ObservablePoint(this, 1, 1);
		return this._scale;
	}
	set scale(value) {
		if (this._scale === defaultScale) this._scale = new ObservablePoint(this, 0, 0);
		if (typeof value === "string") value = parseFloat(value);
		typeof value === "number" ? this._scale.set(value) : this._scale.copyFrom(value);
	}
	/**
	* @experimental
	* The origin point around which the container rotates and scales without affecting its position.
	* Unlike pivot, changing the origin will not move the container's position.
	* @example
	* ```ts
	* // Rotate around center point
	* container.origin.set(container.width / 2, container.height / 2);
	* container.rotation = Math.PI; // Rotates around center
	*
	* // Reset origin
	* container.origin.set(0, 0);
	* ```
	*/
	get origin() {
		if (this._origin === defaultOrigin) this._origin = new ObservablePoint(this, 0, 0);
		return this._origin;
	}
	set origin(value) {
		if (this._origin === defaultOrigin) {
			this._origin = new ObservablePoint(this, 0, 0);
			if (this._pivot !== defaultPivot) warn(`Setting both a pivot and origin on a Container is not recommended. This can lead to unexpected behavior if not handled carefully.`);
		}
		typeof value === "number" ? this._origin.set(value) : this._origin.copyFrom(value);
	}
	/**
	* The width of the Container, setting this will actually modify the scale to achieve the value set.
	* > [!NOTE] Changing the width will adjust the scale.x property of the container while maintaining its aspect ratio.
	* > [!NOTE] If you want to set both width and height at the same time, use {@link Container#setSize}
	* as it is more optimized by not recalculating the local bounds twice.
	* @example
	* ```ts
	* // Basic width setting
	* container.width = 100;
	* // Optimized width setting
	* container.setSize(100, 100);
	* ```
	*/
	get width() {
		return Math.abs(this.scale.x * this.getLocalBounds().width);
	}
	set width(value) {
		const localWidth = this.getLocalBounds().width;
		this._setWidth(value, localWidth);
	}
	/**
	* The height of the Container,
	* > [!NOTE] Changing the height will adjust the scale.y property of the container while maintaining its aspect ratio.
	* > [!NOTE] If you want to set both width and height at the same time, use {@link Container#setSize}
	* as it is more optimized by not recalculating the local bounds twice.
	* @example
	* ```ts
	* // Basic height setting
	* container.height = 200;
	* // Optimized height setting
	* container.setSize(100, 200);
	* ```
	*/
	get height() {
		return Math.abs(this.scale.y * this.getLocalBounds().height);
	}
	set height(value) {
		const localHeight = this.getLocalBounds().height;
		this._setHeight(value, localHeight);
	}
	/**
	* Retrieves the size of the container as a [Size]{@link Size} object.
	*
	* This is faster than get the width and height separately.
	* @example
	* ```ts
	* // Basic size retrieval
	* const size = container.getSize();
	* console.log(`Size: ${size.width}x${size.height}`);
	*
	* // Reuse existing size object
	* const reuseSize = { width: 0, height: 0 };
	* container.getSize(reuseSize);
	* ```
	* @param out - Optional object to store the size in.
	* @returns The size of the container.
	*/
	getSize(out) {
		if (!out) out = {};
		const bounds = this.getLocalBounds();
		out.width = Math.abs(this.scale.x * bounds.width);
		out.height = Math.abs(this.scale.y * bounds.height);
		return out;
	}
	/**
	* Sets the size of the container to the specified width and height.
	* This is more efficient than setting width and height separately as it only recalculates bounds once.
	* @example
	* ```ts
	* // Basic size setting
	* container.setSize(100, 200);
	*
	* // Set uniform size
	* container.setSize(100); // Sets both width and height to 100
	* ```
	* @param value - This can be either a number or a [Size]{@link Size} object.
	* @param height - The height to set. Defaults to the value of `width` if not provided.
	*/
	setSize(value, height) {
		const size = this.getLocalBounds();
		if (typeof value === "object") {
			height = value.height ?? value.width;
			value = value.width;
		} else height ?? (height = value);
		value !== void 0 && this._setWidth(value, size.width);
		height !== void 0 && this._setHeight(height, size.height);
	}
	/** Called when the skew or the rotation changes. */
	_updateSkew() {
		const rotation = this._rotation;
		const skew = this._skew;
		this._cx = Math.cos(rotation + skew._y);
		this._sx = Math.sin(rotation + skew._y);
		this._cy = -Math.sin(rotation - skew._x);
		this._sy = Math.cos(rotation - skew._x);
	}
	/**
	* Updates the transform properties of the container.
	* Allows partial updates of transform properties for optimized manipulation.
	* @example
	* ```ts
	* // Basic transform update
	* container.updateTransform({
	*     x: 100,
	*     y: 200,
	*     rotation: Math.PI / 4
	* });
	*
	* // Scale and rotate around center
	* sprite.updateTransform({
	*     pivotX: sprite.width / 2,
	*     pivotY: sprite.height / 2,
	*     scaleX: 2,
	*     scaleY: 2,
	*     rotation: Math.PI
	* });
	*
	* // Update position only
	* button.updateTransform({
	*     x: button.x + 10, // Move right
	*     y: button.y      // Keep same y
	* });
	* ```
	* @param opts - Transform options to update
	* @param opts.x - The x position
	* @param opts.y - The y position
	* @param opts.scaleX - The x-axis scale factor
	* @param opts.scaleY - The y-axis scale factor
	* @param opts.rotation - The rotation in radians
	* @param opts.skewX - The x-axis skew factor
	* @param opts.skewY - The y-axis skew factor
	* @param opts.pivotX - The x-axis pivot point
	* @param opts.pivotY - The y-axis pivot point
	* @returns This container, for chaining
	* @see {@link Container#setFromMatrix} For matrix-based transforms
	* @see {@link Container#position} For direct position access
	*/
	updateTransform(opts) {
		this.position.set(typeof opts.x === "number" ? opts.x : this.position.x, typeof opts.y === "number" ? opts.y : this.position.y);
		this.scale.set(typeof opts.scaleX === "number" ? opts.scaleX : this.scale.x, typeof opts.scaleY === "number" ? opts.scaleY : this.scale.y);
		this.rotation = typeof opts.rotation === "number" ? opts.rotation : this.rotation;
		this.skew.set(typeof opts.skewX === "number" ? opts.skewX : this.skew.x, typeof opts.skewY === "number" ? opts.skewY : this.skew.y);
		this.pivot.set(typeof opts.pivotX === "number" ? opts.pivotX : this.pivot.x, typeof opts.pivotY === "number" ? opts.pivotY : this.pivot.y);
		this.origin.set(typeof opts.originX === "number" ? opts.originX : this.origin.x, typeof opts.originY === "number" ? opts.originY : this.origin.y);
		return this;
	}
	/**
	* Updates the local transform properties by decomposing the given matrix.
	* Extracts position, scale, rotation, and skew from a transformation matrix.
	* @example
	* ```ts
	* // Basic matrix transform
	* const matrix = new Matrix()
	*     .translate(100, 100)
	*     .rotate(Math.PI / 4)
	*     .scale(2, 2);
	*
	* container.setFromMatrix(matrix);
	*
	* // Copy transform from another container
	* const source = new Container();
	* source.position.set(100, 100);
	* source.rotation = Math.PI / 2;
	*
	* target.setFromMatrix(source.localTransform);
	*
	* // Reset transform
	* container.setFromMatrix(Matrix.IDENTITY);
	* ```
	* @param matrix - The matrix to use for updating the transform
	* @see {@link Container#updateTransform} For property-based updates
	* @see {@link Matrix#decompose} For matrix decomposition details
	*/
	setFromMatrix(matrix) {
		matrix.decompose(this);
	}
	/** Updates the local transform. */
	updateLocalTransform() {
		const localTransformChangeId = this._didContainerChangeTick;
		if (this._didLocalTransformChangeId === localTransformChangeId) return;
		this._didLocalTransformChangeId = localTransformChangeId;
		const lt = this.localTransform;
		const scale = this._scale;
		const pivot = this._pivot;
		const origin = this._origin;
		const position = this._position;
		const sx = scale._x;
		const sy = scale._y;
		const px = pivot._x;
		const py = pivot._y;
		const ox = -origin._x;
		const oy = -origin._y;
		lt.a = this._cx * sx;
		lt.b = this._sx * sx;
		lt.c = this._cy * sy;
		lt.d = this._sy * sy;
		lt.tx = position._x - (px * lt.a + py * lt.c) + (ox * lt.a + oy * lt.c) - ox;
		lt.ty = position._y - (px * lt.b + py * lt.d) + (ox * lt.b + oy * lt.d) - oy;
	}
	set alpha(value) {
		if (value === this.localAlpha) return;
		this.localAlpha = value;
		this._updateFlags |= 1;
		this._onUpdate();
	}
	/**
	* The opacity of the object relative to its parent's opacity.
	* Value ranges from 0 (fully transparent) to 1 (fully opaque).
	* @example
	* ```ts
	* // Basic transparency
	* sprite.alpha = 0.5; // 50% opacity
	*
	* // Inherited opacity
	* container.alpha = 0.5;
	* const child = new Sprite(texture);
	* child.alpha = 0.5;
	* container.addChild(child);
	* // child's effective opacity is 0.25 (0.5 * 0.5)
	* ```
	* @default 1
	* @see {@link Container#visible} For toggling visibility
	* @see {@link Container#renderable} For render control
	*/
	get alpha() {
		return this.localAlpha;
	}
	set tint(value) {
		const bgr = Color.shared.setValue(value ?? 16777215).toBgrNumber();
		if (bgr === this.localColor) return;
		this.localColor = bgr;
		this._updateFlags |= 1;
		this._onUpdate();
	}
	/**
	* The tint applied to the sprite.
	*
	* This can be any valid {@link ColorSource}.
	* @example
	* ```ts
	* // Basic color tinting
	* container.tint = 0xff0000; // Red tint
	* container.tint = 'red';    // Same as above
	* container.tint = '#00ff00'; // Green
	* container.tint = 'rgb(0,0,255)'; // Blue
	*
	* // Remove tint
	* container.tint = 0xffffff; // White = no tint
	* container.tint = null;     // Also removes tint
	* ```
	* @default 0xFFFFFF
	* @see {@link Container#alpha} For transparency
	* @see {@link Container#visible} For visibility control
	*/
	get tint() {
		return bgr2rgb(this.localColor);
	}
	set blendMode(value) {
		if (this.localBlendMode === value) return;
		if (this.parentRenderGroup) this.parentRenderGroup.structureDidChange = true;
		this._updateFlags |= 2;
		this.localBlendMode = value;
		this._onUpdate();
	}
	/**
	* The blend mode to be applied to the sprite. Controls how pixels are blended when rendering.
	*
	* Setting to 'normal' will reset to default blending.
	* > [!NOTE] More blend modes are available after importing the `pixi.js/advanced-blend-modes` sub-export.
	* @example
	* ```ts
	* // Basic blend modes
	* sprite.blendMode = 'add';        // Additive blending
	* sprite.blendMode = 'multiply';   // Multiply colors
	* sprite.blendMode = 'screen';     // Screen blend
	*
	* // Reset blend mode
	* sprite.blendMode = 'normal';     // Normal blending
	* ```
	* @default 'normal'
	* @see {@link Container#alpha} For transparency
	* @see {@link Container#tint} For color adjustments
	*/
	get blendMode() {
		return this.localBlendMode;
	}
	/**
	* The visibility of the object. If false the object will not be drawn,
	* and the transform will not be updated.
	* @example
	* ```ts
	* // Basic visibility toggle
	* sprite.visible = false; // Hide sprite
	* sprite.visible = true;  // Show sprite
	* ```
	* @default true
	* @see {@link Container#renderable} For render-only control
	* @see {@link Container#alpha} For transparency
	*/
	get visible() {
		return !!(this.localDisplayStatus & 2);
	}
	set visible(value) {
		const valueNumber = value ? 2 : 0;
		if ((this.localDisplayStatus & 2) === valueNumber) return;
		if (this.parentRenderGroup) this.parentRenderGroup.structureDidChange = true;
		this._updateFlags |= 4;
		this.localDisplayStatus ^= 2;
		this._onUpdate();
		this.emit("visibleChanged", value);
	}
	/** @ignore */
	get culled() {
		return !(this.localDisplayStatus & 4);
	}
	/** @ignore */
	set culled(value) {
		const valueNumber = value ? 0 : 4;
		if ((this.localDisplayStatus & 4) === valueNumber) return;
		if (this.parentRenderGroup) this.parentRenderGroup.structureDidChange = true;
		this._updateFlags |= 4;
		this.localDisplayStatus ^= 4;
		this._onUpdate();
	}
	/**
	* Controls whether this object can be rendered. If false the object will not be drawn,
	* but the transform will still be updated. This is different from visible, which skips
	* transform updates.
	* @example
	* ```ts
	* // Basic render control
	* sprite.renderable = false; // Skip rendering
	* sprite.renderable = true;  // Enable rendering
	* ```
	* @default true
	* @see {@link Container#visible} For skipping transform updates
	* @see {@link Container#alpha} For transparency
	*/
	get renderable() {
		return !!(this.localDisplayStatus & 1);
	}
	set renderable(value) {
		const valueNumber = value ? 1 : 0;
		if ((this.localDisplayStatus & 1) === valueNumber) return;
		this._updateFlags |= 4;
		this.localDisplayStatus ^= 1;
		if (this.parentRenderGroup) this.parentRenderGroup.structureDidChange = true;
		this._onUpdate();
	}
	/**
	* Whether or not the object should be rendered.
	* @advanced
	*/
	get isRenderable() {
		return this.localDisplayStatus === 7 && this.groupAlpha > 0;
	}
	/**
	* Removes all internal references and listeners as well as removes children from the display list.
	* Do not use a Container after calling `destroy`.
	* @param options - Options parameter. A boolean will act as if all options
	*  have been set to that value
	* @example
	* ```ts
	* container.destroy();
	* container.destroy(true);
	* container.destroy({ children: true });
	* container.destroy({ children: true, texture: true, textureSource: true });
	* ```
	*/
	destroy(options = false) {
		if (this.destroyed) return;
		this.destroyed = true;
		let oldChildren;
		if (this.children.length) oldChildren = this.removeChildren(0, this.children.length);
		this.removeFromParent();
		this.parent = null;
		this._maskEffect = null;
		this._filterEffect = null;
		this.effects = null;
		this._position = null;
		this._scale = null;
		this._pivot = null;
		this._origin = null;
		this._skew = null;
		this.emit("destroyed", this);
		this.removeAllListeners();
		if ((typeof options === "boolean" ? options : options?.children) && oldChildren) for (let i = 0; i < oldChildren.length; ++i) oldChildren[i].destroy(options);
		this.renderGroup?.destroy();
		this.renderGroup = null;
	}
};
extensions.mixin(Container, childrenHelperMixin, getFastGlobalBoundsMixin, toLocalGlobalMixin, onRenderMixin, measureMixin, effectsMixin, findMixin, sortMixin, cullingMixin, cacheAsTextureMixin, getGlobalMixin, collectRenderablesMixin);
//#endregion
//#region node_modules/pixi.js/lib/scene/view/ViewContainer.mjs
var ViewContainer = class extends Container {
	constructor(options) {
		super(options);
		/** @internal */
		this.canBundle = true;
		/** @internal */
		this.allowChildren = false;
		/** @internal */
		this._roundPixels = 0;
		/** @internal */
		this._lastUsed = -1;
		/** @internal */
		this._gpuData = /* @__PURE__ */ Object.create(null);
		/** If set to true, the resource will be garbage collected automatically when it is not used. */
		this.autoGarbageCollect = true;
		/** @internal */
		this._gcLastUsed = -1;
		this._bounds = new Bounds(0, 1, 0, 0);
		this._boundsDirty = true;
		this.autoGarbageCollect = options.autoGarbageCollect ?? true;
	}
	/**
	* The local bounds of the view in its own coordinate space.
	* Bounds are automatically updated when the view's content changes.
	* @example
	* ```ts
	* // Get bounds dimensions
	* const bounds = view.bounds;
	* console.log(`Width: ${bounds.maxX - bounds.minX}`);
	* console.log(`Height: ${bounds.maxY - bounds.minY}`);
	* ```
	* @returns The rectangular bounds of the view
	* @see {@link Bounds} For bounds operations
	*/
	get bounds() {
		if (!this._boundsDirty) return this._bounds;
		this.updateBounds();
		this._boundsDirty = false;
		return this._bounds;
	}
	/**
	* Whether or not to round the x/y position of the sprite.
	* @example
	* ```ts
	* // Enable pixel rounding for crisp rendering
	* view.roundPixels = true;
	* ```
	* @default false
	*/
	get roundPixels() {
		return !!this._roundPixels;
	}
	set roundPixels(value) {
		this._roundPixels = value ? 1 : 0;
	}
	/**
	* Checks if the object contains the given point in local coordinates.
	* Uses the view's bounds for hit testing.
	* @example
	* ```ts
	* // Basic point check
	* const localPoint = { x: 50, y: 25 };
	* const contains = view.containsPoint(localPoint);
	* console.log('Point is inside:', contains);
	* ```
	* @param point - The point to check in local coordinates
	* @returns True if the point is within the view's bounds
	* @see {@link ViewContainer#bounds} For the bounds used in hit testing
	* @see {@link Container#toLocal} For converting global coordinates to local
	*/
	containsPoint(point) {
		const bounds = this.bounds;
		const { x, y } = point;
		return x >= bounds.minX && x <= bounds.maxX && y >= bounds.minY && y <= bounds.maxY;
	}
	/** @private */
	onViewUpdate() {
		this._didViewChangeTick++;
		this._boundsDirty = true;
		if (this.didViewUpdate) return;
		this.didViewUpdate = true;
		const renderGroup = this.renderGroup || this.parentRenderGroup;
		if (renderGroup) renderGroup.onChildViewUpdate(this);
	}
	/** Unloads the GPU data from the view. */
	unload() {
		this.emit("unload", this);
		for (const key in this._gpuData) this._gpuData[key]?.destroy();
		this._gpuData = /* @__PURE__ */ Object.create(null);
		this.onViewUpdate();
	}
	destroy(options) {
		this.unload();
		super.destroy(options);
		this._bounds = null;
	}
	/**
	* Collects renderables for the view container.
	* @param instructionSet - The instruction set to collect renderables for.
	* @param renderer - The renderer to collect renderables for.
	* @param currentLayer - The current render layer.
	* @internal
	*/
	collectRenderablesSimple(instructionSet, renderer, currentLayer) {
		const { renderPipes } = renderer;
		renderPipes.blendMode.pushBlendMode(this, this.groupBlendMode, instructionSet);
		const pipe = renderPipes[this.renderPipeId];
		if (pipe?.addRenderable) pipe.addRenderable(this, instructionSet);
		this.didViewUpdate = false;
		const children = this.children;
		const length = children.length;
		for (let i = 0; i < length; i++) children[i].collectRenderables(instructionSet, renderer, currentLayer);
		renderPipes.blendMode.popBlendMode(instructionSet);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite/Sprite.mjs
var Sprite = class Sprite extends ViewContainer {
	/**
	* @param options - The options for creating the sprite.
	*/
	constructor(options = Texture.EMPTY) {
		if (options instanceof Texture) options = { texture: options };
		const { texture = Texture.EMPTY, anchor, roundPixels, width, height, ...rest } = options;
		super({
			label: "Sprite",
			...rest
		});
		/** @internal */
		this.renderPipeId = "sprite";
		/** @internal */
		this.batched = true;
		this._visualBounds = {
			minX: 0,
			maxX: 1,
			minY: 0,
			maxY: 0
		};
		this._anchor = new ObservablePoint({ _onUpdate: () => {
			this.onViewUpdate();
		} });
		if (anchor) this.anchor = anchor;
		else if (texture.defaultAnchor) this.anchor = texture.defaultAnchor;
		this.texture = texture;
		this.allowChildren = false;
		this.roundPixels = roundPixels ?? false;
		if (width !== void 0) this.width = width;
		if (height !== void 0) this.height = height;
	}
	/**
	* Creates a new sprite based on a source texture, image, video, or canvas element.
	* This is a convenience method that automatically creates and manages textures.
	* @example
	* ```ts
	* // Create from path or URL
	* const sprite = Sprite.from('assets/image.png');
	*
	* // Create from existing texture
	* const sprite = Sprite.from(texture);
	*
	* // Create from canvas
	* const canvas = document.createElement('canvas');
	* const sprite = Sprite.from(canvas, true); // Skip caching new texture
	* ```
	* @param source - The source to create the sprite from. Can be a path to an image, a texture,
	* or any valid texture source (canvas, video, etc.)
	* @param skipCache - Whether to skip adding to the texture cache when creating a new texture
	* @returns A new sprite based on the source
	* @see {@link Texture.from} For texture creation details
	* @see {@link Assets} For asset loading and management
	*/
	static from(source, skipCache = false) {
		if (source instanceof Texture) return new Sprite(source);
		return new Sprite(Texture.from(source, skipCache));
	}
	set texture(value) {
		value || (value = Texture.EMPTY);
		const currentTexture = this._texture;
		if (currentTexture === value) return;
		if (currentTexture && currentTexture.dynamic) currentTexture.off("update", this.onViewUpdate, this);
		if (value.dynamic) value.on("update", this.onViewUpdate, this);
		this._texture = value;
		if (this._width) this._setWidth(this._width, this._texture.orig.width);
		if (this._height) this._setHeight(this._height, this._texture.orig.height);
		this.onViewUpdate();
	}
	/**
	* The texture that is displayed by the sprite. When changed, automatically updates
	* the sprite dimensions and manages texture event listeners.
	* @example
	* ```ts
	* // Create sprite with texture
	* const sprite = new Sprite({
	*     texture: Texture.from('sprite.png')
	* });
	*
	* // Update texture
	* sprite.texture = Texture.from('newSprite.png');
	*
	* // Use texture from spritesheet
	* const sheet = await Assets.load('spritesheet.json');
	* sprite.texture = sheet.textures['frame1.png'];
	*
	* // Reset to empty texture
	* sprite.texture = Texture.EMPTY;
	* ```
	* @see {@link Texture} For texture creation and management
	* @see {@link Assets} For asset loading
	*/
	get texture() {
		return this._texture;
	}
	/**
	* The bounds of the sprite, taking into account the texture's trim area.
	* @example
	* ```ts
	* const texture = new Texture({
	*     source: new TextureSource({ width: 300, height: 300 }),
	*     frame: new Rectangle(196, 66, 58, 56),
	*     trim: new Rectangle(4, 4, 58, 56),
	*     orig: new Rectangle(0, 0, 64, 64),
	*     rotate: 2,
	* });
	* const sprite = new Sprite(texture);
	* const visualBounds = sprite.visualBounds;
	* // console.log(visualBounds); // { minX: -4, maxX: 62, minY: -4, maxY: 60 }
	*/
	get visualBounds() {
		updateQuadBounds(this._visualBounds, this._anchor, this._texture);
		return this._visualBounds;
	}
	/**
	* @deprecated
	* @ignore
	*/
	get sourceBounds() {
		deprecation("8.6.1", "Sprite.sourceBounds is deprecated, use visualBounds instead.");
		return this.visualBounds;
	}
	/** @private */
	updateBounds() {
		const anchor = this._anchor;
		const texture = this._texture;
		const bounds = this._bounds;
		const { width, height } = texture.orig;
		bounds.minX = -anchor._x * width;
		bounds.maxX = bounds.minX + width;
		bounds.minY = -anchor._y * height;
		bounds.maxY = bounds.minY + height;
	}
	/**
	* Destroys this sprite renderable and optionally its texture.
	* @param options - Options parameter. A boolean will act as if all options
	*  have been set to that value
	* @example
	* sprite.destroy();
	* sprite.destroy(true);
	* sprite.destroy({ texture: true, textureSource: true });
	*/
	destroy(options = false) {
		super.destroy(options);
		if (typeof options === "boolean" ? options : options?.texture) {
			const destroyTextureSource = typeof options === "boolean" ? options : options?.textureSource;
			this._texture.destroy(destroyTextureSource);
		}
		this._texture = null;
		this._visualBounds = null;
		this._bounds = null;
		this._anchor = null;
	}
	/**
	* The anchor sets the origin point of the sprite. The default value is taken from the {@link Texture}
	* and passed to the constructor.
	*
	* - The default is `(0,0)`, this means the sprite's origin is the top left.
	* - Setting the anchor to `(0.5,0.5)` means the sprite's origin is centered.
	* - Setting the anchor to `(1,1)` would mean the sprite's origin point will be the bottom right corner.
	*
	* If you pass only single parameter, it will set both x and y to the same value as shown in the example below.
	* @example
	* ```ts
	* // Center the anchor point
	* sprite.anchor = 0.5; // Sets both x and y to 0.5
	* sprite.position.set(400, 300); // Sprite will be centered at this position
	*
	* // Set specific x/y anchor points
	* sprite.anchor = {
	*     x: 1, // Right edge
	*     y: 0  // Top edge
	* };
	*
	* // Using individual coordinates
	* sprite.anchor.set(0.5, 1); // Center-bottom
	*
	* // For rotation around center
	* sprite.anchor.set(0.5);
	* sprite.rotation = Math.PI / 4; // 45 degrees around center
	*
	* // For scaling from center
	* sprite.anchor.set(0.5);
	* sprite.scale.set(2); // Scales from center point
	* ```
	*/
	get anchor() {
		return this._anchor;
	}
	set anchor(value) {
		typeof value === "number" ? this._anchor.set(value) : this._anchor.copyFrom(value);
	}
	/**
	* The width of the sprite, setting this will actually modify the scale to achieve the value set.
	* @example
	* ```ts
	* // Set width directly
	* sprite.width = 200;
	* console.log(sprite.scale.x); // Scale adjusted to match width
	*
	* // Set width while preserving aspect ratio
	* const ratio = sprite.height / sprite.width;
	* sprite.width = 300;
	* sprite.height = 300 * ratio;
	*
	* // For better performance when setting both width and height
	* sprite.setSize(300, 400); // Avoids recalculating bounds twice
	*
	* // Reset to original texture size
	* sprite.width = sprite.texture.orig.width;
	* ```
	*/
	get width() {
		return Math.abs(this.scale.x) * this._texture.orig.width;
	}
	set width(value) {
		this._setWidth(value, this._texture.orig.width);
		this._width = value;
	}
	/**
	* The height of the sprite, setting this will actually modify the scale to achieve the value set.
	* @example
	* ```ts
	* // Set height directly
	* sprite.height = 150;
	* console.log(sprite.scale.y); // Scale adjusted to match height
	*
	* // Set height while preserving aspect ratio
	* const ratio = sprite.width / sprite.height;
	* sprite.height = 200;
	* sprite.width = 200 * ratio;
	*
	* // For better performance when setting both width and height
	* sprite.setSize(300, 400); // Avoids recalculating bounds twice
	*
	* // Reset to original texture size
	* sprite.height = sprite.texture.orig.height;
	* ```
	*/
	get height() {
		return Math.abs(this.scale.y) * this._texture.orig.height;
	}
	set height(value) {
		this._setHeight(value, this._texture.orig.height);
		this._height = value;
	}
	/**
	* Retrieves the size of the Sprite as a [Size]{@link Size} object based on the texture dimensions and scale.
	* This is faster than getting width and height separately as it only calculates the bounds once.
	* @example
	* ```ts
	* // Basic size retrieval
	* const sprite = new Sprite(Texture.from('sprite.png'));
	* const size = sprite.getSize();
	* console.log(`Size: ${size.width}x${size.height}`);
	*
	* // Reuse existing size object
	* const reuseSize = { width: 0, height: 0 };
	* sprite.getSize(reuseSize);
	* ```
	* @param out - Optional object to store the size in, to avoid allocating a new object
	* @returns The size of the Sprite
	* @see {@link Sprite#width} For getting just the width
	* @see {@link Sprite#height} For getting just the height
	* @see {@link Sprite#setSize} For setting both width and height
	*/
	getSize(out) {
		out || (out = {});
		out.width = Math.abs(this.scale.x) * this._texture.orig.width;
		out.height = Math.abs(this.scale.y) * this._texture.orig.height;
		return out;
	}
	/**
	* Sets the size of the Sprite to the specified width and height.
	* This is faster than setting width and height separately as it only recalculates bounds once.
	* @example
	* ```ts
	* // Basic size setting
	* const sprite = new Sprite(Texture.from('sprite.png'));
	* sprite.setSize(100, 200); // Width: 100, Height: 200
	*
	* // Set uniform size
	* sprite.setSize(100); // Sets both width and height to 100
	*
	* // Set size with object
	* sprite.setSize({
	*     width: 200,
	*     height: 300
	* });
	*
	* // Reset to texture size
	* sprite.setSize(
	*     sprite.texture.orig.width,
	*     sprite.texture.orig.height
	* );
	* ```
	* @param value - This can be either a number or a {@link Size} object
	* @param height - The height to set. Defaults to the value of `width` if not provided
	* @see {@link Sprite#width} For setting width only
	* @see {@link Sprite#height} For setting height only
	* @see {@link Sprite#texture} For the source dimensions
	*/
	setSize(value, height) {
		if (typeof value === "object") {
			height = value.height ?? value.width;
			value = value.width;
		} else height ?? (height = value);
		value !== void 0 && this._setWidth(value, this._texture.orig.width);
		height !== void 0 && this._setHeight(height, this._texture.orig.height);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/sources/CanvasSource.mjs
var CanvasSource = class extends TextureSource {
	constructor(options) {
		if (!options.resource) options.resource = DOMAdapter.get().createCanvas();
		if (!options.width) {
			options.width = options.resource.width;
			if (!options.autoDensity) options.width /= options.resolution;
		}
		if (!options.height) {
			options.height = options.resource.height;
			if (!options.autoDensity) options.height /= options.resolution;
		}
		super(options);
		this.uploadMethodId = "image";
		this.autoDensity = options.autoDensity;
		this.resizeCanvas();
		this.transparent = !!options.transparent;
	}
	resizeCanvas() {
		if (this.autoDensity && "style" in this.resource) {
			this.resource.style.width = `${this.width}px`;
			this.resource.style.height = `${this.height}px`;
		}
		if (this.resource.width !== this.pixelWidth || this.resource.height !== this.pixelHeight) {
			this.resource.width = this.pixelWidth;
			this.resource.height = this.pixelHeight;
		}
	}
	resize(width = this.width, height = this.height, resolution = this._resolution) {
		const didResize = super.resize(width, height, resolution);
		if (didResize) this.resizeCanvas();
		return didResize;
	}
	static test(resource) {
		return globalThis.HTMLCanvasElement && resource instanceof HTMLCanvasElement || globalThis.OffscreenCanvas && resource instanceof OffscreenCanvas;
	}
	/**
	* Returns the 2D rendering context for the canvas.
	* Caches the context after creating it.
	* @returns The 2D rendering context of the canvas.
	*/
	get context2D() {
		return this._context2D || (this._context2D = this.resource.getContext("2d"));
	}
};
CanvasSource.extension = ExtensionType.TextureSource;
//#endregion
//#region node_modules/pixi.js/lib/ticker/const.mjs
var UPDATE_PRIORITY = /* @__PURE__ */ ((UPDATE_PRIORITY2) => {
	UPDATE_PRIORITY2[UPDATE_PRIORITY2["INTERACTION"] = 50] = "INTERACTION";
	UPDATE_PRIORITY2[UPDATE_PRIORITY2["HIGH"] = 25] = "HIGH";
	UPDATE_PRIORITY2[UPDATE_PRIORITY2["NORMAL"] = 0] = "NORMAL";
	UPDATE_PRIORITY2[UPDATE_PRIORITY2["LOW"] = -25] = "LOW";
	UPDATE_PRIORITY2[UPDATE_PRIORITY2["UTILITY"] = -50] = "UTILITY";
	return UPDATE_PRIORITY2;
})(UPDATE_PRIORITY || {});
//#endregion
//#region node_modules/pixi.js/lib/ticker/TickerListener.mjs
var TickerListener = class {
	/**
	* Constructor
	* @private
	* @param fn - The listener function to be added for one update
	* @param context - The listener context
	* @param priority - The priority for emitting
	* @param once - If the handler should fire once
	*/
	constructor(fn, context = null, priority = 0, once = false) {
		/** The next item in chain. */
		this.next = null;
		/** The previous item in chain. */
		this.previous = null;
		/** `true` if this listener has been destroyed already. */
		this._destroyed = false;
		this._fn = fn;
		this._context = context;
		this.priority = priority;
		this._once = once;
	}
	/**
	* Simple compare function to figure out if a function and context match.
	* @param fn - The listener function to be added for one update
	* @param context - The listener context
	* @returns `true` if the listener match the arguments
	*/
	match(fn, context = null) {
		return this._fn === fn && this._context === context;
	}
	/**
	* Emit by calling the current function.
	* @param ticker - The ticker emitting.
	* @returns Next ticker
	*/
	emit(ticker) {
		if (this._fn) {
			if (this._context) this._fn.call(this._context, ticker);
			else this._fn(ticker);
		}
		const redirect = this.next;
		if (this._once) this.destroy(true);
		if (this._destroyed) this.next = null;
		return redirect;
	}
	/**
	* Connect to the list.
	* @param previous - Input node, previous listener
	*/
	connect(previous) {
		this.previous = previous;
		if (previous.next) previous.next.previous = this;
		this.next = previous.next;
		previous.next = this;
	}
	/**
	* Destroy and don't use after this.
	* @param hard - `true` to remove the `next` reference, this
	*        is considered a hard destroy. Soft destroy maintains the next reference.
	* @returns The listener to redirect while emitting or removing.
	*/
	destroy(hard = false) {
		this._destroyed = true;
		this._fn = null;
		this._context = null;
		if (this.previous) this.previous.next = this.next;
		if (this.next) this.next.previous = this.previous;
		const redirect = this.next;
		this.next = hard ? null : redirect;
		this.previous = null;
		return redirect;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/ticker/Ticker.mjs
var _Ticker = class _Ticker {
	constructor() {
		/**
		* Whether or not this ticker should invoke the method {@link Ticker#start|start}
		* automatically when a listener is added.
		* @example
		* ```ts
		* // Default behavior (manual start)
		* const ticker = new Ticker();
		* ticker.autoStart = false;
		* ticker.add(() => {
		*     // Won't run until ticker.start() is called
		* });
		*
		* // Auto-start behavior
		* const autoTicker = new Ticker();
		* autoTicker.autoStart = true;
		* autoTicker.add(() => {
		*     // Runs immediately when added
		* });
		* ```
		* @default false
		* @see {@link Ticker#start} For manually starting the ticker
		* @see {@link Ticker#stop} For manually stopping the ticker
		*/
		this.autoStart = false;
		/**
		* Scalar representing the delta time factor.
		* This is a dimensionless value representing the fraction of a frame at the target framerate.
		* At 60 FPS, this value is typically around 1.0.
		*
		* This is NOT in milliseconds - it's a scalar multiplier for frame-independent animations.
		* For actual milliseconds, use {@link Ticker#deltaMS}.
		* @example
		* ```ts
		* // Frame-independent animation using deltaTime scalar
		* ticker.add((ticker) => {
		*     // Rotate sprite by 0.1 radians per frame, scaled by deltaTime
		*     sprite.rotation += 0.1 * ticker.deltaTime;
		* });
		* ```
		*/
		this.deltaTime = 1;
		/**
		* The last time update was invoked, in milliseconds since epoch.
		* Similar to performance.now() timestamp format.
		*
		* Used internally for calculating time deltas between frames.
		* @example
		* ```ts
		* ticker.add((ticker) => {
		*     const currentTime = performance.now();
		*     const timeSinceLastFrame = currentTime - ticker.lastTime;
		*     console.log(`Time since last frame: ${timeSinceLastFrame}ms`);
		* });
		* ```
		*/
		this.lastTime = -1;
		/**
		* Factor of current {@link Ticker#deltaTime|deltaTime}.
		* Used to scale time for slow motion or fast-forward effects.
		* @example
		* ```ts
		* // Basic speed adjustment
		* ticker.speed = 0.5; // Half speed (slow motion)
		* ticker.speed = 2.0; // Double speed (fast forward)
		*
		* // Temporary speed changes
		* function slowMotion() {
		*     const normalSpeed = ticker.speed;
		*     ticker.speed = 0.2;
		*     setTimeout(() => {
		*         ticker.speed = normalSpeed;
		*     }, 1000);
		* }
		* ```
		*/
		this.speed = 1;
		/**
		* Whether or not this ticker has been started.
		*
		* `true` if {@link Ticker#start|start} has been called.
		* `false` if {@link Ticker#stop|Stop} has been called.
		*
		* While `false`, this value may change to `true` in the
		* event of {@link Ticker#autoStart|autoStart} being `true`
		* and a listener is added.
		* @example
		* ```ts
		* // Check ticker state
		* const ticker = new Ticker();
		* console.log(ticker.started); // false
		*
		* // Start and verify
		* ticker.start();
		* console.log(ticker.started); // true
		* ```
		*/
		this.started = false;
		/** Internal current frame request ID */
		this._requestId = null;
		/**
		* Internal value managed by minFPS property setter and getter.
		* This is the maximum allowed milliseconds between updates.
		*/
		this._maxElapsedMS = 100;
		/**
		* Internal value managed by maxFPS property setter and getter.
		* This is the minimum allowed milliseconds between updates.
		*/
		this._minElapsedMS = 0;
		/** If enabled, deleting is disabled.*/
		this._protected = false;
		/** The last time keyframe was executed. Maintains a relatively fixed interval with the previous value. */
		this._lastFrame = -1;
		this._head = new TickerListener(null, null, Infinity);
		this.deltaMS = 1 / _Ticker.targetFPMS;
		this.elapsedMS = 1 / _Ticker.targetFPMS;
		this._tick = (time) => {
			this._requestId = null;
			if (this.started) {
				this.update(time);
				if (this.started && this._requestId === null && this._head.next) this._requestId = requestAnimationFrame(this._tick);
			}
		};
	}
	/**
	* Conditionally requests a new animation frame.
	* If a frame has not already been requested, and if the internal
	* emitter has listeners, a new frame is requested.
	*/
	_requestIfNeeded() {
		if (this._requestId === null && this._head.next) {
			this.lastTime = performance.now();
			this._lastFrame = this.lastTime;
			this._requestId = requestAnimationFrame(this._tick);
		}
	}
	/** Conditionally cancels a pending animation frame. */
	_cancelIfNeeded() {
		if (this._requestId !== null) {
			cancelAnimationFrame(this._requestId);
			this._requestId = null;
		}
	}
	/**
	* Conditionally requests a new animation frame.
	* If the ticker has been started it checks if a frame has not already
	* been requested, and if the internal emitter has listeners. If these
	* conditions are met, a new frame is requested. If the ticker has not
	* been started, but autoStart is `true`, then the ticker starts now,
	* and continues with the previous conditions to request a new frame.
	*/
	_startIfPossible() {
		if (this.started) this._requestIfNeeded();
		else if (this.autoStart) this.start();
	}
	/**
	* Register a handler for tick events.
	* @param fn - The listener function to add. Receives the Ticker instance as parameter
	* @param context - The context for the listener
	* @param priority - The priority of the listener
	* @example
	* ```ts
	* // Access time properties through the ticker parameter
	* ticker.add((ticker) => {
	*     // Use deltaTime (dimensionless scalar) for frame-independent animations
	*     sprite.rotation += 0.1 * ticker.deltaTime;
	*
	*     // Use deltaMS (milliseconds) for time-based calculations
	*     const progress = ticker.deltaMS / animationDuration;
	*
	*     // Use elapsedMS for raw timing measurements
	*     console.log(`Raw frame time: ${ticker.elapsedMS}ms`);
	* });
	* ```
	*/
	add(fn, context, priority = UPDATE_PRIORITY.NORMAL) {
		return this._addListener(new TickerListener(fn, context, priority));
	}
	/**
	* Add a handler for the tick event which is only executed once on the next frame.
	* @example
	* ```ts
	* // Basic one-time update
	* ticker.addOnce(() => {
	*     console.log('Runs next frame only');
	* });
	*
	* // With specific context
	* const game = {
	*     init(ticker) {
	*         this.loadResources();
	*         console.log('Game initialized');
	*     }
	* };
	* ticker.addOnce(game.init, game);
	*
	* // With priority
	* ticker.addOnce(
	*     () => {
	*         // High priority one-time setup
	*         physics.init();
	*     },
	*     undefined,
	*     UPDATE_PRIORITY.HIGH
	* );
	* ```
	* @param fn - The listener function to be added for one update
	* @param context - The listener context
	* @param priority - The priority for emitting (default: UPDATE_PRIORITY.NORMAL)
	* @returns This instance of a ticker
	* @see {@link Ticker#add} For continuous updates
	* @see {@link Ticker#remove} For removing handlers
	*/
	addOnce(fn, context, priority = UPDATE_PRIORITY.NORMAL) {
		return this._addListener(new TickerListener(fn, context, priority, true));
	}
	/**
	* Internally adds the event handler so that it can be sorted by priority.
	* Priority allows certain handler (user, AnimatedSprite, Interaction) to be run
	* before the rendering.
	* @private
	* @param listener - Current listener being added.
	* @returns This instance of a ticker
	*/
	_addListener(listener) {
		let current = this._head.next;
		let previous = this._head;
		if (!current) listener.connect(previous);
		else {
			while (current) {
				if (listener.priority > current.priority) {
					listener.connect(previous);
					break;
				}
				previous = current;
				current = current.next;
			}
			if (!listener.previous) listener.connect(previous);
		}
		this._startIfPossible();
		return this;
	}
	/**
	* Removes any handlers matching the function and context parameters.
	* If no handlers are left after removing, then it cancels the animation frame.
	* @example
	* ```ts
	* // Basic removal
	* const onTick = () => {
	*     sprite.rotation += 0.1;
	* };
	* ticker.add(onTick);
	* ticker.remove(onTick);
	*
	* // Remove with context
	* const game = {
	*     update(ticker) {
	*         this.physics.update(ticker.deltaTime);
	*     }
	* };
	* ticker.add(game.update, game);
	* ticker.remove(game.update, game);
	*
	* // Remove all matching handlers
	* // (if same function was added multiple times)
	* ticker.add(onTick);
	* ticker.add(onTick);
	* ticker.remove(onTick); // Removes all instances
	* ```
	* @param fn - The listener function to be removed
	* @param context - The listener context to be removed
	* @returns This instance of a ticker
	* @see {@link Ticker#add} For adding handlers
	* @see {@link Ticker#addOnce} For one-time handlers
	*/
	remove(fn, context) {
		let listener = this._head.next;
		while (listener) if (listener.match(fn, context)) listener = listener.destroy();
		else listener = listener.next;
		if (!this._head.next) this._cancelIfNeeded();
		return this;
	}
	/**
	* The number of listeners on this ticker, calculated by walking through linked list.
	* @example
	* ```ts
	* // Check number of active listeners
	* const ticker = new Ticker();
	* console.log(ticker.count); // 0
	*
	* // Add some listeners
	* ticker.add(() => {});
	* ticker.add(() => {});
	* console.log(ticker.count); // 2
	*
	* // Check after cleanup
	* ticker.destroy();
	* console.log(ticker.count); // 0
	* ```
	* @readonly
	* @see {@link Ticker#add} For adding listeners
	* @see {@link Ticker#remove} For removing listeners
	*/
	get count() {
		if (!this._head) return 0;
		let count = 0;
		let current = this._head;
		while (current = current.next) count++;
		return count;
	}
	/**
	* Starts the ticker. If the ticker has listeners a new animation frame is requested at this point.
	* @example
	* ```ts
	* // Basic manual start
	* const ticker = new Ticker();
	* ticker.add(() => {
	*     // Animation code here
	* });
	* ticker.start();
	* ```
	* @see {@link Ticker#stop} For stopping the ticker
	* @see {@link Ticker#autoStart} For automatic starting
	* @see {@link Ticker#started} For checking ticker state
	*/
	start() {
		if (!this.started) {
			this.started = true;
			this._requestIfNeeded();
		}
	}
	/**
	* Stops the ticker. If the ticker has requested an animation frame it is canceled at this point.
	* @example
	* ```ts
	* // Basic stop
	* const ticker = new Ticker();
	* ticker.stop();
	* ```
	* @see {@link Ticker#start} For starting the ticker
	* @see {@link Ticker#started} For checking ticker state
	* @see {@link Ticker#destroy} For cleaning up the ticker
	*/
	stop() {
		if (this.started) {
			this.started = false;
			this._cancelIfNeeded();
		}
	}
	/**
	* Destroy the ticker and don't use after this. Calling this method removes all references to internal events.
	* @example
	* ```ts
	* // Clean up with active listeners
	* const ticker = new Ticker();
	* ticker.add(() => {});
	* ticker.destroy(); // Removes all listeners
	* ```
	* @see {@link Ticker#stop} For stopping without destroying
	* @see {@link Ticker#remove} For removing specific listeners
	*/
	destroy() {
		if (!this._protected) {
			this.stop();
			let listener = this._head.next;
			while (listener) listener = listener.destroy(true);
			this._head.destroy();
			this._head = null;
		}
	}
	/**
	* Triggers an update.
	*
	* An update entails setting the
	* current {@link Ticker#elapsedMS|elapsedMS},
	* the current {@link Ticker#deltaTime|deltaTime},
	* invoking all listeners with current deltaTime,
	* and then finally setting {@link Ticker#lastTime|lastTime}
	* with the value of currentTime that was provided.
	*
	* This method will be called automatically by animation
	* frame callbacks if the ticker instance has been started
	* and listeners are added.
	* @example
	* ```ts
	* // Basic manual update
	* const ticker = new Ticker();
	* ticker.update(performance.now());
	* ```
	* @param currentTime - The current time of execution (defaults to performance.now())
	* @see {@link Ticker#deltaTime} For frame delta value
	* @see {@link Ticker#elapsedMS} For raw elapsed time
	*/
	update(currentTime = performance.now()) {
		let elapsedMS;
		if (currentTime > this.lastTime) {
			elapsedMS = this.elapsedMS = currentTime - this.lastTime;
			if (elapsedMS > this._maxElapsedMS) elapsedMS = this._maxElapsedMS;
			elapsedMS *= this.speed;
			if (this._minElapsedMS) {
				const delta = currentTime - this._lastFrame | 0;
				if (delta < this._minElapsedMS) return;
				this._lastFrame = currentTime - delta % this._minElapsedMS;
			}
			this.deltaMS = elapsedMS;
			this.deltaTime = this.deltaMS * _Ticker.targetFPMS;
			const head = this._head;
			let listener = head.next;
			while (listener) listener = listener.emit(this);
			if (!head.next) this._cancelIfNeeded();
		} else this.deltaTime = this.deltaMS = this.elapsedMS = 0;
		this.lastTime = currentTime;
	}
	/**
	* The frames per second at which this ticker is running.
	* The default is approximately 60 in most modern browsers.
	* > [!NOTE] This does not factor in the value of
	* > {@link Ticker#speed|speed}, which is specific
	* > to scaling {@link Ticker#deltaTime|deltaTime}.
	* @example
	* ```ts
	* // Basic FPS monitoring
	* ticker.add(() => {
	*     console.log(`Current FPS: ${Math.round(ticker.FPS)}`);
	* });
	* ```
	* @readonly
	*/
	get FPS() {
		return 1e3 / this.elapsedMS;
	}
	/**
	* Manages the maximum amount of milliseconds allowed to
	* elapse between invoking {@link Ticker#update|update}.
	*
	* This value is used to cap {@link Ticker#deltaTime|deltaTime},
	* but does not effect the measured value of {@link Ticker#FPS|FPS}.
	*
	* When setting this property it is clamped to a value between
	* `0` and `Ticker.targetFPMS * 1000` (typically 60).
	*
	* If `maxFPS` is currently set (non-zero) and `minFPS` is set above it,
	* `maxFPS` is automatically raised to match. This keeps the two limits consistent.
	* @example
	* ```ts
	* // Set minimum acceptable frame rate
	* const ticker = new Ticker();
	* ticker.minFPS = 30; // Never go below 30 FPS
	*
	* // Use with maxFPS for frame rate clamping
	* ticker.minFPS = 30;
	* ticker.maxFPS = 60;
	*
	* // minFPS above maxFPS pushes maxFPS up
	* ticker.minFPS = 50; // maxFPS is raised to 50
	* ```
	* @default 10
	*/
	get minFPS() {
		return 1e3 / this._maxElapsedMS;
	}
	set minFPS(fps) {
		const minFPMS = Math.min(Math.max(0, fps) / 1e3, _Ticker.targetFPMS);
		this._maxElapsedMS = 1 / minFPMS;
		if (this._minElapsedMS && fps > this.maxFPS) this.maxFPS = fps;
	}
	/**
	* Manages the minimum amount of milliseconds required to
	* elapse between invoking {@link Ticker#update|update}.
	*
	* This will effect the measured value of {@link Ticker#FPS|FPS}.
	*
	* If it is set to `0`, then there is no limit; PixiJS will render as many frames as it can.
	* Otherwise it will be at least `minFPS`.
	*
	* If `maxFPS` is set below the current `minFPS`, `minFPS` is automatically lowered to match.
	* This keeps the two limits consistent.
	* @example
	* ```ts
	* // Cap the frame rate
	* const ticker = new Ticker();
	* ticker.maxFPS = 60; // Never go above 60 FPS
	*
	* // Use with minFPS for frame rate clamping
	* ticker.minFPS = 30;
	* ticker.maxFPS = 60;
	*
	* // maxFPS below minFPS pushes minFPS down
	* ticker.maxFPS = 20; // minFPS is now also 20
	* ```
	* @default 0
	*/
	get maxFPS() {
		if (this._minElapsedMS) return Math.round(1e3 / this._minElapsedMS);
		return 0;
	}
	set maxFPS(fps) {
		if (fps === 0) this._minElapsedMS = 0;
		else {
			if (fps < this.minFPS) this.minFPS = fps;
			this._minElapsedMS = 1 / (fps / 1e3);
		}
	}
	/**
	* The shared ticker instance used by {@link AnimatedSprite} and by
	* {@link VideoSource} to update animation frames / video textures.
	*
	* It may also be used by {@link Application} if created with the `sharedTicker` option property set to true.
	*
	* The property {@link Ticker#autoStart|autoStart} is set to `true` for this instance.
	* Please follow the examples for usage, including how to opt-out of auto-starting the shared ticker.
	* @example
	* import { Ticker } from 'pixi.js';
	*
	* const ticker = Ticker.shared;
	* // Set this to prevent starting this ticker when listeners are added.
	* // By default this is true only for the Ticker.shared instance.
	* ticker.autoStart = false;
	*
	* // FYI, call this to ensure the ticker is stopped. It should be stopped
	* // if you have not attempted to render anything yet.
	* ticker.stop();
	*
	* // Call this when you are ready for a running shared ticker.
	* ticker.start();
	* @example
	* import { autoDetectRenderer, Container } from 'pixi.js';
	*
	* // You may use the shared ticker to render...
	* const renderer = autoDetectRenderer();
	* const stage = new Container();
	* document.body.appendChild(renderer.view);
	* ticker.add((time) => renderer.render(stage));
	*
	* // Or you can just update it manually.
	* ticker.autoStart = false;
	* ticker.stop();
	* const animate = (time) => {
	*     ticker.update(time);
	*     renderer.render(stage);
	*     requestAnimationFrame(animate);
	* };
	* animate(performance.now());
	* @type {Ticker}
	* @readonly
	*/
	static get shared() {
		if (!_Ticker._shared) {
			const shared = _Ticker._shared = new _Ticker();
			shared.autoStart = true;
			shared._protected = true;
		}
		return _Ticker._shared;
	}
	/**
	* The system ticker instance used by {@link PrepareBase} for core timing
	* functionality that shouldn't usually need to be paused, unlike the `shared`
	* ticker which drives visual animations and rendering which may want to be paused.
	*
	* The property {@link Ticker#autoStart|autoStart} is set to `true` for this instance.
	* @type {Ticker}
	* @readonly
	* @advanced
	*/
	static get system() {
		if (!_Ticker._system) {
			const system = _Ticker._system = new _Ticker();
			system.autoStart = true;
			system._protected = true;
		}
		return _Ticker._system;
	}
};
/**
* Target frame rate in frames per millisecond.
* Used for converting deltaTime to a scalar time delta.
* @example
* ```ts
* // Default is 0.06 (60 FPS)
* console.log(Ticker.targetFPMS); // 0.06
*
* // Calculate target frame duration
* const frameDuration = 1 / Ticker.targetFPMS; // ≈ 16.67ms
*
* // Use in custom timing calculations
* const deltaTime = elapsedMS * Ticker.targetFPMS;
* ```
* @remarks
* - Default is 0.06 (equivalent to 60 FPS)
* - Used in deltaTime calculations
* - Affects all ticker instances
* @default 0.06
* @see {@link Ticker#deltaTime} For time scaling
* @see {@link Ticker#FPS} For actual frame rate
*/
_Ticker.targetFPMS = .06;
var Ticker = _Ticker;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/state/State.mjs
var blendModeIds = {
	normal: 0,
	add: 1,
	multiply: 2,
	screen: 3,
	overlay: 4,
	erase: 5,
	"normal-npm": 6,
	"add-npm": 7,
	"screen-npm": 8,
	min: 9,
	max: 10
};
var STATE_BITS = {
	BLEND: 0,
	OFFSET: 1,
	CULLING: 2,
	DEPTH_TEST: 3,
	WINDING: 4,
	DEPTH_MASK: 5
};
var { BLEND, OFFSET, CULLING, DEPTH_TEST, WINDING, DEPTH_MASK } = STATE_BITS;
var _State = class _State {
	constructor() {
		this.data = 0;
		this.blendMode = "normal";
		this.polygonOffset = 0;
		this.blend = true;
		this.depthMask = true;
	}
	/**
	* Activates blending of the computed fragment color values.
	* @default true
	*/
	get blend() {
		return !!(this.data & 1 << BLEND);
	}
	set blend(value) {
		if (!!(this.data & 1 << BLEND) !== value) this.data ^= 1 << BLEND;
	}
	/**
	* Activates adding an offset to depth values of polygon's fragments
	* @default false
	*/
	get offsets() {
		return !!(this.data & 1 << OFFSET);
	}
	set offsets(value) {
		if (!!(this.data & 1 << OFFSET) !== value) this.data ^= 1 << OFFSET;
	}
	/** The culling settings for this state none - No culling back - Back face culling front - Front face culling */
	set cullMode(value) {
		if (value === "none") {
			this.culling = false;
			return;
		}
		this.culling = true;
		this.clockwiseFrontFace = value === "front";
	}
	get cullMode() {
		if (!this.culling) return "none";
		return this.clockwiseFrontFace ? "front" : "back";
	}
	/**
	* Activates culling of polygons.
	* @default false
	*/
	get culling() {
		return !!(this.data & 1 << CULLING);
	}
	set culling(value) {
		if (!!(this.data & 1 << CULLING) !== value) this.data ^= 1 << CULLING;
	}
	/**
	* Activates depth comparisons and updates to the depth buffer.
	* @default false
	*/
	get depthTest() {
		return !!(this.data & 1 << DEPTH_TEST);
	}
	set depthTest(value) {
		if (!!(this.data & 1 << DEPTH_TEST) !== value) this.data ^= 1 << DEPTH_TEST;
	}
	/**
	* Enables or disables writing to the depth buffer.
	* @default true
	*/
	get depthMask() {
		return !!(this.data & 1 << DEPTH_MASK);
	}
	set depthMask(value) {
		if (!!(this.data & 1 << DEPTH_MASK) !== value) this.data ^= 1 << DEPTH_MASK;
	}
	/**
	* Specifies whether or not front or back-facing polygons can be culled.
	* @default false
	*/
	get clockwiseFrontFace() {
		return !!(this.data & 1 << WINDING);
	}
	set clockwiseFrontFace(value) {
		if (!!(this.data & 1 << WINDING) !== value) this.data ^= 1 << WINDING;
	}
	/**
	* The blend mode to be applied when this state is set. Apply a value of `normal` to reset the blend mode.
	* Setting this mode to anything other than NO_BLEND will automatically switch blending on.
	* @default 'normal'
	*/
	get blendMode() {
		return this._blendMode;
	}
	set blendMode(value) {
		this.blend = value !== "none";
		this._blendMode = value;
		this._blendModeId = blendModeIds[value] || 0;
	}
	/**
	* The polygon offset. Setting this property to anything other than 0 will automatically enable polygon offset fill.
	* @default 0
	*/
	get polygonOffset() {
		return this._polygonOffset;
	}
	set polygonOffset(value) {
		this.offsets = !!value;
		this._polygonOffset = value;
	}
	toString() {
		return `[pixi.js/core:State blendMode=${this.blendMode} clockwiseFrontFace=${this.clockwiseFrontFace} culling=${this.culling} depthMask=${this.depthMask} polygonOffset=${this.polygonOffset}]`;
	}
	/**
	* A quickly getting an instance of a State that is configured for 2d rendering.
	* @returns a new State with values set for 2d rendering
	*/
	static for2d() {
		const state = new _State();
		state.depthTest = false;
		state.depthMask = false;
		state.blend = true;
		return state;
	}
};
_State.default2d = _State.for2d();
var State = _State;
//#endregion
//#region node_modules/pixi.js/lib/filters/Filter.mjs
var _Filter = class _Filter extends Shader {
	/**
	* @param options - The optional parameters of this filter.
	*/
	constructor(options) {
		options = {
			..._Filter.defaultOptions,
			...options
		};
		super(options);
		/** If enabled is true the filter is applied, if false it will not. */
		this.enabled = true;
		/**
		* The gpu state the filter requires to render.
		* @internal
		*/
		this._state = State.for2d();
		this.blendMode = options.blendMode;
		this.padding = options.padding;
		if (typeof options.antialias === "boolean") this.antialias = options.antialias ? "on" : "off";
		else this.antialias = options.antialias;
		this.resolution = options.resolution;
		this.blendRequired = options.blendRequired;
		this.clipToViewport = options.clipToViewport;
		this.addResource("uTexture", 0, 1);
		if (options.blendRequired) this.addResource("uBackTexture", 0, 3);
	}
	/**
	* Applies the filter
	* @param filterManager - The renderer to retrieve the filter from
	* @param input - The input render target.
	* @param output - The target to output to.
	* @param clearMode - Should the output be cleared before rendering to it
	*/
	apply(filterManager, input, output, clearMode) {
		filterManager.applyFilter(this, input, output, clearMode);
	}
	/**
	* Get the blend mode of the filter.
	* @default "normal"
	*/
	get blendMode() {
		return this._state.blendMode;
	}
	/** Sets the blend mode of the filter. */
	set blendMode(value) {
		this._state.blendMode = value;
	}
	/**
	* A short hand function to create a filter based of a vertex and fragment shader src.
	* @param options
	* @returns A shiny new PixiJS filter!
	*/
	static from(options) {
		const { gpu, gl, ...rest } = options;
		let gpuProgram;
		let glProgram;
		if (gpu) gpuProgram = GpuProgram.from(gpu);
		if (gl) glProgram = GlProgram.from(gl);
		return new _Filter({
			gpuProgram,
			glProgram,
			...rest
		});
	}
};
/** The default filter settings */
_Filter.defaultOptions = {
	blendMode: "normal",
	resolution: 1,
	padding: 0,
	antialias: "off",
	blendRequired: false,
	clipToViewport: true
};
var Filter = _Filter;
//#endregion
export { getFastGlobalBoundsMixin as A, removeItems as B, checkChildrenDidChange as C, multiplyColors as D, getGlobalMixin as E, MaskEffectManager as F, cullingMixin as H, MaskEffectManagerClass as I, FilterEffect as L, matrixPool as M, findMixin as N, getGlobalBounds as O, effectsMixin as P, collectRenderablesMixin as R, measureMixin as S, bgr2rgb as T, updateQuadBounds as U, cacheAsTextureMixin as V, ObservablePoint as W, TexturePool as _, TickerListener as a, sortMixin as b, Sprite as c, UPDATE_BLEND as d, UPDATE_COLOR as f, RenderGroup as g, assignWithIgnore as h, Ticker as i, boundsPool as j, updateTransformBackwards as k, ViewContainer as l, UPDATE_VISIBLE as m, STATE_BITS as n, UPDATE_PRIORITY as o, UPDATE_TRANSFORM as p, State as r, CanvasSource as s, Filter as t, Container as u, TexturePoolClass as v, getLocalBounds as w, onRenderMixin as x, toLocalGlobalMixin as y, childrenHelperMixin as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRmlsdGVyLUJwY2ZYR1dULmpzIiwibmFtZXMiOlsidGVtcE1hdHJpeCIsIkV2ZW50RW1pdHRlciIsInJwIl0sInNvdXJjZXMiOlsiLi4vLi4vcGl4aS5qcy9saWIvbWF0aHMvcG9pbnQvT2JzZXJ2YWJsZVBvaW50Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3V0aWxzL2RhdGEvdXBkYXRlUXVhZEJvdW5kcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9jdWxsaW5nL2N1bGxpbmdNaXhpbi5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvY29udGFpbmVyLW1peGlucy9jYWNoZUFzVGV4dHVyZU1peGluLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3V0aWxzL2RhdGEvcmVtb3ZlSXRlbXMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL2NvbnRhaW5lci1taXhpbnMvY2hpbGRyZW5IZWxwZXJNaXhpbi5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvY29udGFpbmVyLW1peGlucy9jb2xsZWN0UmVuZGVyYWJsZXNNaXhpbi5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9maWx0ZXJzL0ZpbHRlckVmZmVjdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvbWFzay9NYXNrRWZmZWN0TWFuYWdlci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvY29udGFpbmVyLW1peGlucy9lZmZlY3RzTWl4aW4ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL2NvbnRhaW5lci1taXhpbnMvZmluZE1peGluLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvdXRpbHMvbWF0cml4QW5kQm91bmRzUG9vbC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvY29udGFpbmVyLW1peGlucy9nZXRGYXN0R2xvYmFsQm91bmRzTWl4aW4ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL2JvdW5kcy9nZXRHbG9iYWxCb3VuZHMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL3V0aWxzL211bHRpcGx5Q29sb3JzLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2NvbnRhaW5lci9jb250YWluZXItbWl4aW5zL2dldEdsb2JhbE1peGluLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvZ2V0TG9jYWxCb3VuZHMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL3V0aWxzL2NoZWNrQ2hpbGRyZW5EaWRDaGFuZ2UubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL2NvbnRhaW5lci1taXhpbnMvbWVhc3VyZU1peGluLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2NvbnRhaW5lci9jb250YWluZXItbWl4aW5zL29uUmVuZGVyTWl4aW4ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL2NvbnRhaW5lci1taXhpbnMvc29ydE1peGluLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2NvbnRhaW5lci9jb250YWluZXItbWl4aW5zL3RvTG9jYWxHbG9iYWxNaXhpbi5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL1RleHR1cmVQb29sLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2NvbnRhaW5lci9SZW5kZXJHcm91cC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvdXRpbHMvYXNzaWduV2l0aElnbm9yZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvQ29udGFpbmVyLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL3ZpZXcvVmlld0NvbnRhaW5lci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9zcHJpdGUvU3ByaXRlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvc291cmNlcy9DYW52YXNTb3VyY2UubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvdGlja2VyL2NvbnN0Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3RpY2tlci9UaWNrZXJMaXN0ZW5lci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi90aWNrZXIvVGlja2VyLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3N0YXRlL1N0YXRlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2ZpbHRlcnMvRmlsdGVyLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbmNsYXNzIE9ic2VydmFibGVQb2ludCB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGBPYnNlcnZhYmxlUG9pbnRgXG4gICAqIEBwYXJhbSBvYnNlcnZlciAtIE9ic2VydmVyIHRvIHBhc3MgdG8gbGlzdGVuIGZvciBjaGFuZ2UgZXZlbnRzLlxuICAgKiBAcGFyYW0ge251bWJlcn0gW3g9MF0gLSBwb3NpdGlvbiBvZiB0aGUgcG9pbnQgb24gdGhlIHggYXhpc1xuICAgKiBAcGFyYW0ge251bWJlcn0gW3k9MF0gLSBwb3NpdGlvbiBvZiB0aGUgcG9pbnQgb24gdGhlIHkgYXhpc1xuICAgKi9cbiAgY29uc3RydWN0b3Iob2JzZXJ2ZXIsIHgsIHkpIHtcbiAgICB0aGlzLl94ID0geCB8fCAwO1xuICAgIHRoaXMuX3kgPSB5IHx8IDA7XG4gICAgdGhpcy5fb2JzZXJ2ZXIgPSBvYnNlcnZlcjtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBhIGNsb25lIG9mIHRoaXMgcG9pbnQuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNsb25pbmdcbiAgICogY29uc3QgcG9pbnQgPSBuZXcgT2JzZXJ2YWJsZVBvaW50KG9ic2VydmVyLCAxMDAsIDIwMCk7XG4gICAqIGNvbnN0IGNvcHkgPSBwb2ludC5jbG9uZSgpO1xuICAgKlxuICAgKiAvLyBDbG9uZSB3aXRoIG5ldyBvYnNlcnZlclxuICAgKiBjb25zdCBuZXdPYnNlcnZlciA9IHtcbiAgICogICAgIF9vblVwZGF0ZTogKHApID0+IGNvbnNvbGUubG9nKGBDbG9uZSB1cGRhdGVkOiAoJHtwLnh9LCAke3AueX0pYClcbiAgICogfTtcbiAgICogY29uc3Qgd2F0Y2hlZCA9IHBvaW50LmNsb25lKG5ld09ic2VydmVyKTtcbiAgICpcbiAgICogLy8gVmVyaWZ5IGluZGVwZW5kZW5jZVxuICAgKiB3YXRjaGVkLnNldCgzMDAsIDQwMCk7IC8vIE9ubHkgdHJpZ2dlcnMgbmV3IG9ic2VydmVyXG4gICAqIGBgYFxuICAgKiBAcGFyYW0gb2JzZXJ2ZXIgLSBPcHRpb25hbCBvYnNlcnZlciB0byBwYXNzIHRvIHRoZSBuZXcgb2JzZXJ2YWJsZSBwb2ludFxuICAgKiBAcmV0dXJucyBBIGNvcHkgb2YgdGhpcyBvYnNlcnZhYmxlIHBvaW50XG4gICAqIEBzZWUge0BsaW5rIE9ic2VydmFibGVQb2ludC5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgaW50byBleGlzdGluZyBwb2ludFxuICAgKiBAc2VlIHtAbGluayBPYnNlcnZlcn0gRm9yIG9ic2VydmVyIGludGVyZmFjZSBkZXRhaWxzXG4gICAqL1xuICBjbG9uZShvYnNlcnZlcikge1xuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZVBvaW50KG9ic2VydmVyID8/IHRoaXMuX29ic2VydmVyLCB0aGlzLl94LCB0aGlzLl95KTtcbiAgfVxuICAvKipcbiAgICogU2V0cyB0aGUgcG9pbnQgdG8gYSBuZXcgeCBhbmQgeSBwb3NpdGlvbi5cbiAgICpcbiAgICogSWYgeSBpcyBvbWl0dGVkLCBib3RoIHggYW5kIHkgd2lsbCBiZSBzZXQgdG8geC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgcG9zaXRpb24gc2V0dGluZ1xuICAgKiBjb25zdCBwb2ludCA9IG5ldyBPYnNlcnZhYmxlUG9pbnQob2JzZXJ2ZXIpO1xuICAgKiBwb2ludC5zZXQoMTAwLCAyMDApO1xuICAgKlxuICAgKiAvLyBTZXQgYm90aCB4IGFuZCB5IHRvIHNhbWUgdmFsdWVcbiAgICogcG9pbnQuc2V0KDUwKTsgLy8geD01MCwgeT01MFxuICAgKiBgYGBcbiAgICogQHBhcmFtIHggLSBQb3NpdGlvbiBvbiB0aGUgeCBheGlzXG4gICAqIEBwYXJhbSB5IC0gUG9zaXRpb24gb24gdGhlIHkgYXhpcywgZGVmYXVsdHMgdG8geFxuICAgKiBAcmV0dXJucyBUaGUgcG9pbnQgaW5zdGFuY2UgaXRzZWxmXG4gICAqIEBzZWUge0BsaW5rIE9ic2VydmFibGVQb2ludC5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgZnJvbSBhbm90aGVyIHBvaW50XG4gICAqIEBzZWUge0BsaW5rIE9ic2VydmFibGVQb2ludC5lcXVhbHN9IEZvciBjb21wYXJpbmcgcG9zaXRpb25zXG4gICAqL1xuICBzZXQoeCA9IDAsIHkgPSB4KSB7XG4gICAgaWYgKHRoaXMuX3ggIT09IHggfHwgdGhpcy5feSAhPT0geSkge1xuICAgICAgdGhpcy5feCA9IHg7XG4gICAgICB0aGlzLl95ID0geTtcbiAgICAgIHRoaXMuX29ic2VydmVyLl9vblVwZGF0ZSh0aGlzKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENvcGllcyB4IGFuZCB5IGZyb20gdGhlIGdpdmVuIHBvaW50IGludG8gdGhpcyBwb2ludC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY29weWluZ1xuICAgKiBjb25zdCBzb3VyY2UgPSBuZXcgT2JzZXJ2YWJsZVBvaW50KG9ic2VydmVyLCAxMDAsIDIwMCk7XG4gICAqIGNvbnN0IHRhcmdldCA9IG5ldyBPYnNlcnZhYmxlUG9pbnQoKTtcbiAgICogdGFyZ2V0LmNvcHlGcm9tKHNvdXJjZSk7XG4gICAqXG4gICAqIC8vIENvcHkgYW5kIGNoYWluIG9wZXJhdGlvbnNcbiAgICogY29uc3QgcG9pbnQgPSBuZXcgT2JzZXJ2YWJsZVBvaW50KClcbiAgICogICAgIC5jb3B5RnJvbShzb3VyY2UpXG4gICAqICAgICAuc2V0KHggKyA1MCwgeSArIDUwKTtcbiAgICpcbiAgICogLy8gQ29weSBmcm9tIGFueSBQb2ludERhdGFcbiAgICogY29uc3QgZGF0YSA9IHsgeDogMTAsIHk6IDIwIH07XG4gICAqIHBvaW50LmNvcHlGcm9tKGRhdGEpO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIHAgLSBUaGUgcG9pbnQgdG8gY29weSBmcm9tXG4gICAqIEByZXR1cm5zIFRoZSBwb2ludCBpbnN0YW5jZSBpdHNlbGZcbiAgICogQHNlZSB7QGxpbmsgT2JzZXJ2YWJsZVBvaW50LmNvcHlUb30gRm9yIGNvcHlpbmcgdG8gYW5vdGhlciBwb2ludFxuICAgKiBAc2VlIHtAbGluayBPYnNlcnZhYmxlUG9pbnQuY2xvbmV9IEZvciBjcmVhdGluZyBuZXcgcG9pbnQgY29weVxuICAgKi9cbiAgY29weUZyb20ocCkge1xuICAgIGlmICh0aGlzLl94ICE9PSBwLnggfHwgdGhpcy5feSAhPT0gcC55KSB7XG4gICAgICB0aGlzLl94ID0gcC54O1xuICAgICAgdGhpcy5feSA9IHAueTtcbiAgICAgIHRoaXMuX29ic2VydmVyLl9vblVwZGF0ZSh0aGlzKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENvcGllcyB0aGlzIHBvaW50J3MgeCBhbmQgeSBpbnRvIHRoZSBnaXZlbiBwb2ludC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY29weWluZ1xuICAgKiBjb25zdCBzb3VyY2UgPSBuZXcgT2JzZXJ2YWJsZVBvaW50KDEwMCwgMjAwKTtcbiAgICogY29uc3QgdGFyZ2V0ID0gbmV3IE9ic2VydmFibGVQb2ludCgpO1xuICAgKiBzb3VyY2UuY29weVRvKHRhcmdldCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcCAtIFRoZSBwb2ludCB0byBjb3B5IHRvLiBDYW4gYmUgYW55IHR5cGUgdGhhdCBpcyBvciBleHRlbmRzIGBQb2ludExpa2VgXG4gICAqIEByZXR1cm5zIFRoZSBwb2ludCAoYHBgKSB3aXRoIHZhbHVlcyB1cGRhdGVkXG4gICAqIEBzZWUge0BsaW5rIE9ic2VydmFibGVQb2ludC5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgZnJvbSBhbm90aGVyIHBvaW50XG4gICAqIEBzZWUge0BsaW5rIE9ic2VydmFibGVQb2ludC5jbG9uZX0gRm9yIGNyZWF0aW5nIG5ldyBwb2ludCBjb3B5XG4gICAqL1xuICBjb3B5VG8ocCkge1xuICAgIHAuc2V0KHRoaXMuX3gsIHRoaXMuX3kpO1xuICAgIHJldHVybiBwO1xuICB9XG4gIC8qKlxuICAgKiBDaGVja3MgaWYgYW5vdGhlciBwb2ludCBpcyBlcXVhbCB0byB0aGlzIHBvaW50LlxuICAgKlxuICAgKiBDb21wYXJlcyB4IGFuZCB5IHZhbHVlcyB1c2luZyBzdHJpY3QgZXF1YWxpdHkuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGVxdWFsaXR5IGNoZWNrXG4gICAqIGNvbnN0IHAxID0gbmV3IE9ic2VydmFibGVQb2ludCgxMDAsIDIwMCk7XG4gICAqIGNvbnN0IHAyID0gbmV3IE9ic2VydmFibGVQb2ludCgxMDAsIDIwMCk7XG4gICAqIGNvbnNvbGUubG9nKHAxLmVxdWFscyhwMikpOyAvLyB0cnVlXG4gICAqXG4gICAqIC8vIENvbXBhcmUgd2l0aCBQb2ludERhdGFcbiAgICogY29uc3QgZGF0YSA9IHsgeDogMTAwLCB5OiAyMDAgfTtcbiAgICogY29uc29sZS5sb2cocDEuZXF1YWxzKGRhdGEpKTsgLy8gdHJ1ZVxuICAgKlxuICAgKiAvLyBDaGVjayBkaWZmZXJlbnQgcG9pbnRzXG4gICAqIGNvbnN0IHAzID0gbmV3IE9ic2VydmFibGVQb2ludCgyMDAsIDMwMCk7XG4gICAqIGNvbnNvbGUubG9nKHAxLmVxdWFscyhwMykpOyAvLyBmYWxzZVxuICAgKiBgYGBcbiAgICogQHBhcmFtIHAgLSBUaGUgcG9pbnQgdG8gY2hlY2tcbiAgICogQHJldHVybnMgYHRydWVgIGlmIGJvdGggYHhgIGFuZCBgeWAgYXJlIGVxdWFsXG4gICAqIEBzZWUge0BsaW5rIE9ic2VydmFibGVQb2ludC5jb3B5RnJvbX0gRm9yIG1ha2luZyBwb2ludHMgZXF1YWxcbiAgICogQHNlZSB7QGxpbmsgUG9pbnREYXRhfSBGb3IgcG9pbnQgZGF0YSBpbnRlcmZhY2VcbiAgICovXG4gIGVxdWFscyhwKSB7XG4gICAgcmV0dXJuIHAueCA9PT0gdGhpcy5feCAmJiBwLnkgPT09IHRoaXMuX3k7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIGBbcGl4aS5qcy9tYXRoOk9ic2VydmFibGVQb2ludCB4PSR7dGhpcy5feH0geT0ke3RoaXMuX3l9IHNjb3BlPSR7dGhpcy5fb2JzZXJ2ZXJ9XWA7XG4gIH1cbiAgLyoqXG4gICAqIFBvc2l0aW9uIG9mIHRoZSBvYnNlcnZhYmxlIHBvaW50IG9uIHRoZSB4IGF4aXMuXG4gICAqIFRyaWdnZXJzIG9ic2VydmVyIGNhbGxiYWNrIHdoZW4gdmFsdWUgY2hhbmdlcy5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgeCBwb3NpdGlvblxuICAgKiBjb25zdCBwb2ludCA9IG5ldyBPYnNlcnZhYmxlUG9pbnQob2JzZXJ2ZXIpO1xuICAgKiBwb2ludC54ID0gMTAwOyAvLyBUcmlnZ2VycyBvYnNlcnZlclxuICAgKlxuICAgKiAvLyBVc2UgaW4gY2FsY3VsYXRpb25zXG4gICAqIGNvbnN0IHdpZHRoID0gcmlnaHRQb2ludC54IC0gbGVmdFBvaW50Lng7XG4gICAqIGBgYFxuICAgKiBAZGVmYXVsdCAwXG4gICAqL1xuICBnZXQgeCgpIHtcbiAgICByZXR1cm4gdGhpcy5feDtcbiAgfVxuICBzZXQgeCh2YWx1ZSkge1xuICAgIGlmICh0aGlzLl94ICE9PSB2YWx1ZSkge1xuICAgICAgdGhpcy5feCA9IHZhbHVlO1xuICAgICAgdGhpcy5fb2JzZXJ2ZXIuX29uVXBkYXRlKHRoaXMpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogUG9zaXRpb24gb2YgdGhlIG9ic2VydmFibGUgcG9pbnQgb24gdGhlIHkgYXhpcy5cbiAgICogVHJpZ2dlcnMgb2JzZXJ2ZXIgY2FsbGJhY2sgd2hlbiB2YWx1ZSBjaGFuZ2VzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyB5IHBvc2l0aW9uXG4gICAqIGNvbnN0IHBvaW50ID0gbmV3IE9ic2VydmFibGVQb2ludChvYnNlcnZlcik7XG4gICAqIHBvaW50LnkgPSAyMDA7IC8vIFRyaWdnZXJzIG9ic2VydmVyXG4gICAqXG4gICAqIC8vIFVzZSBpbiBjYWxjdWxhdGlvbnNcbiAgICogY29uc3QgaGVpZ2h0ID0gYm90dG9tUG9pbnQueSAtIHRvcFBvaW50Lnk7XG4gICAqIGBgYFxuICAgKiBAZGVmYXVsdCAwXG4gICAqL1xuICBnZXQgeSgpIHtcbiAgICByZXR1cm4gdGhpcy5feTtcbiAgfVxuICBzZXQgeSh2YWx1ZSkge1xuICAgIGlmICh0aGlzLl95ICE9PSB2YWx1ZSkge1xuICAgICAgdGhpcy5feSA9IHZhbHVlO1xuICAgICAgdGhpcy5fb2JzZXJ2ZXIuX29uVXBkYXRlKHRoaXMpO1xuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgeyBPYnNlcnZhYmxlUG9pbnQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPU9ic2VydmFibGVQb2ludC5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIHVwZGF0ZVF1YWRCb3VuZHMoYm91bmRzLCBhbmNob3IsIHRleHR1cmUpIHtcbiAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0IH0gPSB0ZXh0dXJlLm9yaWc7XG4gIGNvbnN0IHRyaW0gPSB0ZXh0dXJlLnRyaW07XG4gIGlmICh0cmltKSB7XG4gICAgY29uc3Qgc291cmNlV2lkdGggPSB0cmltLndpZHRoO1xuICAgIGNvbnN0IHNvdXJjZUhlaWdodCA9IHRyaW0uaGVpZ2h0O1xuICAgIGJvdW5kcy5taW5YID0gdHJpbS54IC0gYW5jaG9yLl94ICogd2lkdGg7XG4gICAgYm91bmRzLm1heFggPSBib3VuZHMubWluWCArIHNvdXJjZVdpZHRoO1xuICAgIGJvdW5kcy5taW5ZID0gdHJpbS55IC0gYW5jaG9yLl95ICogaGVpZ2h0O1xuICAgIGJvdW5kcy5tYXhZID0gYm91bmRzLm1pblkgKyBzb3VyY2VIZWlnaHQ7XG4gIH0gZWxzZSB7XG4gICAgYm91bmRzLm1pblggPSAtYW5jaG9yLl94ICogd2lkdGg7XG4gICAgYm91bmRzLm1heFggPSBib3VuZHMubWluWCArIHdpZHRoO1xuICAgIGJvdW5kcy5taW5ZID0gLWFuY2hvci5feSAqIGhlaWdodDtcbiAgICBib3VuZHMubWF4WSA9IGJvdW5kcy5taW5ZICsgaGVpZ2h0O1xuICB9XG59XG5cbmV4cG9ydCB7IHVwZGF0ZVF1YWRCb3VuZHMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVwZGF0ZVF1YWRCb3VuZHMubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBjdWxsaW5nTWl4aW4gPSB7XG4gIGN1bGxBcmVhOiBudWxsLFxuICBjdWxsYWJsZTogZmFsc2UsXG4gIGN1bGxhYmxlQ2hpbGRyZW46IHRydWVcbn07XG5cbmV4cG9ydCB7IGN1bGxpbmdNaXhpbiB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y3VsbGluZ01peGluLm1qcy5tYXBcbiIsImltcG9ydCB7IGRlcHJlY2F0aW9uIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy9kZXByZWNhdGlvbi5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IGNhY2hlQXNUZXh0dXJlTWl4aW4gPSB7XG4gIGdldCBpc0NhY2hlZEFzVGV4dHVyZSgpIHtcbiAgICByZXR1cm4gISF0aGlzLnJlbmRlckdyb3VwPy5pc0NhY2hlZEFzVGV4dHVyZTtcbiAgfSxcbiAgY2FjaGVBc1RleHR1cmUodmFsKSB7XG4gICAgaWYgKHR5cGVvZiB2YWwgPT09IFwiYm9vbGVhblwiICYmIHZhbCA9PT0gZmFsc2UpIHtcbiAgICAgIHRoaXMuZGlzYWJsZVJlbmRlckdyb3VwKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuZW5hYmxlUmVuZGVyR3JvdXAoKTtcbiAgICAgIHRoaXMucmVuZGVyR3JvdXAuZW5hYmxlQ2FjaGVBc1RleHR1cmUodmFsID09PSB0cnVlID8ge30gOiB2YWwpO1xuICAgIH1cbiAgfSxcbiAgdXBkYXRlQ2FjaGVUZXh0dXJlKCkge1xuICAgIHRoaXMucmVuZGVyR3JvdXA/LnVwZGF0ZUNhY2hlVGV4dHVyZSgpO1xuICB9LFxuICBnZXQgY2FjaGVBc0JpdG1hcCgpIHtcbiAgICByZXR1cm4gdGhpcy5pc0NhY2hlZEFzVGV4dHVyZTtcbiAgfSxcbiAgc2V0IGNhY2hlQXNCaXRtYXAodmFsKSB7XG4gICAgZGVwcmVjYXRpb24oXCJ2OC42LjBcIiwgXCJjYWNoZUFzQml0bWFwIGlzIGRlcHJlY2F0ZWQsIHVzZSBjYWNoZUFzVGV4dHVyZSBpbnN0ZWFkLlwiKTtcbiAgICB0aGlzLmNhY2hlQXNUZXh0dXJlKHZhbCk7XG4gIH1cbn07XG5cbmV4cG9ydCB7IGNhY2hlQXNUZXh0dXJlTWl4aW4gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNhY2hlQXNUZXh0dXJlTWl4aW4ubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiByZW1vdmVJdGVtcyhhcnIsIHN0YXJ0SWR4LCByZW1vdmVDb3VudCkge1xuICBjb25zdCBsZW5ndGggPSBhcnIubGVuZ3RoO1xuICBsZXQgaTtcbiAgaWYgKHN0YXJ0SWR4ID49IGxlbmd0aCB8fCByZW1vdmVDb3VudCA9PT0gMCkge1xuICAgIHJldHVybjtcbiAgfVxuICByZW1vdmVDb3VudCA9IHN0YXJ0SWR4ICsgcmVtb3ZlQ291bnQgPiBsZW5ndGggPyBsZW5ndGggLSBzdGFydElkeCA6IHJlbW92ZUNvdW50O1xuICBjb25zdCBsZW4gPSBsZW5ndGggLSByZW1vdmVDb3VudDtcbiAgZm9yIChpID0gc3RhcnRJZHg7IGkgPCBsZW47ICsraSkge1xuICAgIGFycltpXSA9IGFycltpICsgcmVtb3ZlQ291bnRdO1xuICB9XG4gIGFyci5sZW5ndGggPSBsZW47XG59XG5cbmV4cG9ydCB7IHJlbW92ZUl0ZW1zIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZW1vdmVJdGVtcy5tanMubWFwXG4iLCJpbXBvcnQgeyByZW1vdmVJdGVtcyB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2RhdGEvcmVtb3ZlSXRlbXMubWpzJztcbmltcG9ydCB7IGRlcHJlY2F0aW9uLCB2OF8wXzAgfSBmcm9tICcuLi8uLi8uLi91dGlscy9sb2dnaW5nL2RlcHJlY2F0aW9uLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgY2hpbGRyZW5IZWxwZXJNaXhpbiA9IHtcbiAgYWxsb3dDaGlsZHJlbjogdHJ1ZSxcbiAgcmVtb3ZlQ2hpbGRyZW4oYmVnaW5JbmRleCA9IDAsIGVuZEluZGV4KSB7XG4gICAgY29uc3QgZW5kID0gZW5kSW5kZXggPz8gdGhpcy5jaGlsZHJlbi5sZW5ndGg7XG4gICAgY29uc3QgcmFuZ2UgPSBlbmQgLSBiZWdpbkluZGV4O1xuICAgIGNvbnN0IHJlbW92ZWQgPSBbXTtcbiAgICBpZiAocmFuZ2UgPiAwICYmIHJhbmdlIDw9IGVuZCkge1xuICAgICAgZm9yIChsZXQgaSA9IGVuZCAtIDE7IGkgPj0gYmVnaW5JbmRleDsgaS0tKSB7XG4gICAgICAgIGNvbnN0IGNoaWxkID0gdGhpcy5jaGlsZHJlbltpXTtcbiAgICAgICAgaWYgKCFjaGlsZCkgY29udGludWU7XG4gICAgICAgIHJlbW92ZWQucHVzaChjaGlsZCk7XG4gICAgICAgIGNoaWxkLnBhcmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICByZW1vdmVJdGVtcyh0aGlzLmNoaWxkcmVuLCBiZWdpbkluZGV4LCBlbmQpO1xuICAgICAgY29uc3QgcmVuZGVyR3JvdXAgPSB0aGlzLnJlbmRlckdyb3VwIHx8IHRoaXMucGFyZW50UmVuZGVyR3JvdXA7XG4gICAgICBpZiAocmVuZGVyR3JvdXApIHtcbiAgICAgICAgcmVuZGVyR3JvdXAucmVtb3ZlQ2hpbGRyZW4ocmVtb3ZlZCk7XG4gICAgICB9XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlbW92ZWQubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgY29uc3QgY2hpbGQgPSByZW1vdmVkW2ldO1xuICAgICAgICBjaGlsZC5wYXJlbnRSZW5kZXJMYXllcj8uZGV0YWNoKGNoaWxkKTtcbiAgICAgICAgdGhpcy5lbWl0KFwiY2hpbGRSZW1vdmVkXCIsIGNoaWxkLCB0aGlzLCBpKTtcbiAgICAgICAgcmVtb3ZlZFtpXS5lbWl0KFwicmVtb3ZlZFwiLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGlmIChyZW1vdmVkLmxlbmd0aCA+IDApIHtcbiAgICAgICAgdGhpcy5fZGlkVmlld0NoYW5nZVRpY2srKztcbiAgICAgIH1cbiAgICAgIHJldHVybiByZW1vdmVkO1xuICAgIH0gZWxzZSBpZiAocmFuZ2UgPT09IDAgJiYgdGhpcy5jaGlsZHJlbi5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiByZW1vdmVkO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcInJlbW92ZUNoaWxkcmVuOiBudW1lcmljIHZhbHVlcyBhcmUgb3V0c2lkZSB0aGUgYWNjZXB0YWJsZSByYW5nZS5cIik7XG4gIH0sXG4gIHJlbW92ZUNoaWxkQXQoaW5kZXgpIHtcbiAgICBjb25zdCBjaGlsZCA9IHRoaXMuZ2V0Q2hpbGRBdChpbmRleCk7XG4gICAgcmV0dXJuIHRoaXMucmVtb3ZlQ2hpbGQoY2hpbGQpO1xuICB9LFxuICBnZXRDaGlsZEF0KGluZGV4KSB7XG4gICAgaWYgKGluZGV4IDwgMCB8fCBpbmRleCA+PSB0aGlzLmNoaWxkcmVuLmxlbmd0aCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBnZXRDaGlsZEF0OiBJbmRleCAoJHtpbmRleH0pIGRvZXMgbm90IGV4aXN0LmApO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5jaGlsZHJlbltpbmRleF07XG4gIH0sXG4gIHNldENoaWxkSW5kZXgoY2hpbGQsIGluZGV4KSB7XG4gICAgaWYgKGluZGV4IDwgMCB8fCBpbmRleCA+PSB0aGlzLmNoaWxkcmVuLmxlbmd0aCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBUaGUgaW5kZXggJHtpbmRleH0gc3VwcGxpZWQgaXMgb3V0IG9mIGJvdW5kcyAke3RoaXMuY2hpbGRyZW4ubGVuZ3RofWApO1xuICAgIH1cbiAgICB0aGlzLmdldENoaWxkSW5kZXgoY2hpbGQpO1xuICAgIHRoaXMuYWRkQ2hpbGRBdChjaGlsZCwgaW5kZXgpO1xuICB9LFxuICBnZXRDaGlsZEluZGV4KGNoaWxkKSB7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLmNoaWxkcmVuLmluZGV4T2YoY2hpbGQpO1xuICAgIGlmIChpbmRleCA9PT0gLTEpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoZSBzdXBwbGllZCBDb250YWluZXIgbXVzdCBiZSBhIGNoaWxkIG9mIHRoZSBjYWxsZXJcIik7XG4gICAgfVxuICAgIHJldHVybiBpbmRleDtcbiAgfSxcbiAgYWRkQ2hpbGRBdChjaGlsZCwgaW5kZXgpIHtcbiAgICBpZiAoIXRoaXMuYWxsb3dDaGlsZHJlbikge1xuICAgICAgZGVwcmVjYXRpb24odjhfMF8wLCBcImFkZENoaWxkQXQ6IE9ubHkgQ29udGFpbmVycyB3aWxsIGJlIGFsbG93ZWQgdG8gYWRkIGNoaWxkcmVuIGluIHY4LjAuMFwiKTtcbiAgICB9XG4gICAgY29uc3QgeyBjaGlsZHJlbiB9ID0gdGhpcztcbiAgICBpZiAoaW5kZXggPCAwIHx8IGluZGV4ID4gY2hpbGRyZW4ubGVuZ3RoKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7Y2hpbGR9YWRkQ2hpbGRBdDogVGhlIGluZGV4ICR7aW5kZXh9IHN1cHBsaWVkIGlzIG91dCBvZiBib3VuZHMgJHtjaGlsZHJlbi5sZW5ndGh9YCk7XG4gICAgfVxuICAgIGNvbnN0IHNhbWVQYXJlbnQgPSBjaGlsZC5wYXJlbnQgPT09IHRoaXM7XG4gICAgaWYgKGNoaWxkLnBhcmVudCkge1xuICAgICAgY29uc3QgY3VycmVudEluZGV4ID0gY2hpbGQucGFyZW50LmNoaWxkcmVuLmluZGV4T2YoY2hpbGQpO1xuICAgICAgaWYgKHNhbWVQYXJlbnQpIHtcbiAgICAgICAgaWYgKGN1cnJlbnRJbmRleCA9PT0gaW5kZXgpIHtcbiAgICAgICAgICByZXR1cm4gY2hpbGQ7XG4gICAgICAgIH1cbiAgICAgICAgY2hpbGQucGFyZW50LmNoaWxkcmVuLnNwbGljZShjdXJyZW50SW5kZXgsIDEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2hpbGQucmVtb3ZlRnJvbVBhcmVudCgpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoaW5kZXggPT09IGNoaWxkcmVuLmxlbmd0aCkge1xuICAgICAgY2hpbGRyZW4ucHVzaChjaGlsZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNoaWxkcmVuLnNwbGljZShpbmRleCwgMCwgY2hpbGQpO1xuICAgIH1cbiAgICBjb25zdCByZW5kZXJHcm91cCA9IHRoaXMucmVuZGVyR3JvdXAgfHwgdGhpcy5wYXJlbnRSZW5kZXJHcm91cDtcbiAgICBpZiAodGhpcy5zb3J0YWJsZUNoaWxkcmVuKSB0aGlzLnNvcnREaXJ0eSA9IHRydWU7XG4gICAgaWYgKHNhbWVQYXJlbnQpIHtcbiAgICAgIGlmIChyZW5kZXJHcm91cCkge1xuICAgICAgICByZW5kZXJHcm91cC5zdHJ1Y3R1cmVEaWRDaGFuZ2UgPSB0cnVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGNoaWxkO1xuICAgIH1cbiAgICBjaGlsZC5wYXJlbnQgPSB0aGlzO1xuICAgIGNoaWxkLmRpZENoYW5nZSA9IHRydWU7XG4gICAgY2hpbGQuX3VwZGF0ZUZsYWdzID0gMTU7XG4gICAgaWYgKHJlbmRlckdyb3VwKSB7XG4gICAgICByZW5kZXJHcm91cC5hZGRDaGlsZChjaGlsZCk7XG4gICAgfVxuICAgIHRoaXMuZW1pdChcImNoaWxkQWRkZWRcIiwgY2hpbGQsIHRoaXMsIGluZGV4KTtcbiAgICBjaGlsZC5lbWl0KFwiYWRkZWRcIiwgdGhpcyk7XG4gICAgcmV0dXJuIGNoaWxkO1xuICB9LFxuICBzd2FwQ2hpbGRyZW4oY2hpbGQsIGNoaWxkMikge1xuICAgIGlmIChjaGlsZCA9PT0gY2hpbGQyKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGluZGV4MSA9IHRoaXMuZ2V0Q2hpbGRJbmRleChjaGlsZCk7XG4gICAgY29uc3QgaW5kZXgyID0gdGhpcy5nZXRDaGlsZEluZGV4KGNoaWxkMik7XG4gICAgdGhpcy5jaGlsZHJlbltpbmRleDFdID0gY2hpbGQyO1xuICAgIHRoaXMuY2hpbGRyZW5baW5kZXgyXSA9IGNoaWxkO1xuICAgIGNvbnN0IHJlbmRlckdyb3VwID0gdGhpcy5yZW5kZXJHcm91cCB8fCB0aGlzLnBhcmVudFJlbmRlckdyb3VwO1xuICAgIGlmIChyZW5kZXJHcm91cCkge1xuICAgICAgcmVuZGVyR3JvdXAuc3RydWN0dXJlRGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICB9XG4gICAgdGhpcy5fZGlkQ29udGFpbmVyQ2hhbmdlVGljaysrO1xuICB9LFxuICByZW1vdmVGcm9tUGFyZW50KCkge1xuICAgIHRoaXMucGFyZW50Py5yZW1vdmVDaGlsZCh0aGlzKTtcbiAgfSxcbiAgcmVwYXJlbnRDaGlsZCguLi5jaGlsZCkge1xuICAgIGlmIChjaGlsZC5sZW5ndGggPT09IDEpIHtcbiAgICAgIHJldHVybiB0aGlzLnJlcGFyZW50Q2hpbGRBdChjaGlsZFswXSwgdGhpcy5jaGlsZHJlbi5sZW5ndGgpO1xuICAgIH1cbiAgICBjaGlsZC5mb3JFYWNoKChjKSA9PiB0aGlzLnJlcGFyZW50Q2hpbGRBdChjLCB0aGlzLmNoaWxkcmVuLmxlbmd0aCkpO1xuICAgIHJldHVybiBjaGlsZFswXTtcbiAgfSxcbiAgcmVwYXJlbnRDaGlsZEF0KGNoaWxkLCBpbmRleCkge1xuICAgIGlmIChjaGlsZC5wYXJlbnQgPT09IHRoaXMpIHtcbiAgICAgIHRoaXMuc2V0Q2hpbGRJbmRleChjaGlsZCwgaW5kZXgpO1xuICAgICAgcmV0dXJuIGNoaWxkO1xuICAgIH1cbiAgICBjb25zdCBjaGlsZE1hdCA9IGNoaWxkLndvcmxkVHJhbnNmb3JtLmNsb25lKCk7XG4gICAgY2hpbGQucmVtb3ZlRnJvbVBhcmVudCgpO1xuICAgIHRoaXMuYWRkQ2hpbGRBdChjaGlsZCwgaW5kZXgpO1xuICAgIGNvbnN0IG5ld01hdHJpeCA9IHRoaXMud29ybGRUcmFuc2Zvcm0uY2xvbmUoKTtcbiAgICBuZXdNYXRyaXguaW52ZXJ0KCk7XG4gICAgY2hpbGRNYXQucHJlcGVuZChuZXdNYXRyaXgpO1xuICAgIGNoaWxkLnNldEZyb21NYXRyaXgoY2hpbGRNYXQpO1xuICAgIHJldHVybiBjaGlsZDtcbiAgfSxcbiAgcmVwbGFjZUNoaWxkKG9sZENoaWxkLCBuZXdDaGlsZCkge1xuICAgIG9sZENoaWxkLnVwZGF0ZUxvY2FsVHJhbnNmb3JtKCk7XG4gICAgdGhpcy5hZGRDaGlsZEF0KG5ld0NoaWxkLCB0aGlzLmdldENoaWxkSW5kZXgob2xkQ2hpbGQpKTtcbiAgICBuZXdDaGlsZC5zZXRGcm9tTWF0cml4KG9sZENoaWxkLmxvY2FsVHJhbnNmb3JtKTtcbiAgICBuZXdDaGlsZC51cGRhdGVMb2NhbFRyYW5zZm9ybSgpO1xuICAgIHRoaXMucmVtb3ZlQ2hpbGQob2xkQ2hpbGQpO1xuICB9XG59O1xuXG5leHBvcnQgeyBjaGlsZHJlbkhlbHBlck1peGluIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jaGlsZHJlbkhlbHBlck1peGluLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY29uc3QgY29sbGVjdFJlbmRlcmFibGVzTWl4aW4gPSB7XG4gIGNvbGxlY3RSZW5kZXJhYmxlcyhpbnN0cnVjdGlvblNldCwgcmVuZGVyZXIsIGN1cnJlbnRMYXllcikge1xuICAgIGlmICh0aGlzLnBhcmVudFJlbmRlckxheWVyICYmIHRoaXMucGFyZW50UmVuZGVyTGF5ZXIgIT09IGN1cnJlbnRMYXllciB8fCB0aGlzLmdsb2JhbERpc3BsYXlTdGF0dXMgPCA3IHx8ICF0aGlzLmluY2x1ZGVJbkJ1aWxkKSByZXR1cm47XG4gICAgaWYgKHRoaXMuc29ydGFibGVDaGlsZHJlbikge1xuICAgICAgdGhpcy5zb3J0Q2hpbGRyZW4oKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuaXNTaW1wbGUpIHtcbiAgICAgIHRoaXMuY29sbGVjdFJlbmRlcmFibGVzU2ltcGxlKGluc3RydWN0aW9uU2V0LCByZW5kZXJlciwgY3VycmVudExheWVyKTtcbiAgICB9IGVsc2UgaWYgKHRoaXMucmVuZGVyR3JvdXApIHtcbiAgICAgIHJlbmRlcmVyLnJlbmRlclBpcGVzLnJlbmRlckdyb3VwLmFkZFJlbmRlckdyb3VwKHRoaXMucmVuZGVyR3JvdXAsIGluc3RydWN0aW9uU2V0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb2xsZWN0UmVuZGVyYWJsZXNXaXRoRWZmZWN0cyhpbnN0cnVjdGlvblNldCwgcmVuZGVyZXIsIGN1cnJlbnRMYXllcik7XG4gICAgfVxuICB9LFxuICBjb2xsZWN0UmVuZGVyYWJsZXNTaW1wbGUoaW5zdHJ1Y3Rpb25TZXQsIHJlbmRlcmVyLCBjdXJyZW50TGF5ZXIpIHtcbiAgICBjb25zdCBjaGlsZHJlbiA9IHRoaXMuY2hpbGRyZW47XG4gICAgY29uc3QgbGVuZ3RoID0gY2hpbGRyZW4ubGVuZ3RoO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgIGNoaWxkcmVuW2ldLmNvbGxlY3RSZW5kZXJhYmxlcyhpbnN0cnVjdGlvblNldCwgcmVuZGVyZXIsIGN1cnJlbnRMYXllcik7XG4gICAgfVxuICB9LFxuICBjb2xsZWN0UmVuZGVyYWJsZXNXaXRoRWZmZWN0cyhpbnN0cnVjdGlvblNldCwgcmVuZGVyZXIsIGN1cnJlbnRMYXllcikge1xuICAgIGNvbnN0IHsgcmVuZGVyUGlwZXMgfSA9IHJlbmRlcmVyO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5lZmZlY3RzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBlZmZlY3QgPSB0aGlzLmVmZmVjdHNbaV07XG4gICAgICBjb25zdCBwaXBlID0gcmVuZGVyUGlwZXNbZWZmZWN0LnBpcGVdO1xuICAgICAgcGlwZS5wdXNoKGVmZmVjdCwgdGhpcywgaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIH1cbiAgICB0aGlzLmNvbGxlY3RSZW5kZXJhYmxlc1NpbXBsZShpbnN0cnVjdGlvblNldCwgcmVuZGVyZXIsIGN1cnJlbnRMYXllcik7XG4gICAgZm9yIChsZXQgaSA9IHRoaXMuZWZmZWN0cy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgY29uc3QgZWZmZWN0ID0gdGhpcy5lZmZlY3RzW2ldO1xuICAgICAgY29uc3QgcGlwZSA9IHJlbmRlclBpcGVzW2VmZmVjdC5waXBlXTtcbiAgICAgIHBpcGUucG9wKGVmZmVjdCwgdGhpcywgaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIH1cbiAgfVxufTtcblxuZXhwb3J0IHsgY29sbGVjdFJlbmRlcmFibGVzTWl4aW4gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbGxlY3RSZW5kZXJhYmxlc01peGluLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY2xhc3MgRmlsdGVyRWZmZWN0IHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLyoqIHRoZSBwaXBlIHRoYXQga25vd3MgaG93IHRvIGhhbmRsZSB0aGlzIGVmZmVjdCAqL1xuICAgIHRoaXMucGlwZSA9IFwiZmlsdGVyXCI7XG4gICAgLyoqIHRoZSBwcmlvcml0eSBvZiB0aGlzIGVmZmVjdCAqL1xuICAgIHRoaXMucHJpb3JpdHkgPSAxO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmZpbHRlcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHRoaXMuZmlsdGVyc1tpXS5kZXN0cm95KCk7XG4gICAgfVxuICAgIHRoaXMuZmlsdGVycyA9IG51bGw7XG4gICAgdGhpcy5maWx0ZXJBcmVhID0gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgeyBGaWx0ZXJFZmZlY3QgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUZpbHRlckVmZmVjdC5tanMubWFwXG4iLCJpbXBvcnQgeyBleHRlbnNpb25zLCBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBCaWdQb29sIH0gZnJvbSAnLi4vLi4vdXRpbHMvcG9vbC9Qb29sR3JvdXAubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBNYXNrRWZmZWN0TWFuYWdlckNsYXNzIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLyoqIEBwcml2YXRlICovXG4gICAgdGhpcy5fZWZmZWN0Q2xhc3NlcyA9IFtdO1xuICAgIHRoaXMuX3Rlc3RzID0gW107XG4gICAgdGhpcy5faW5pdGlhbGl6ZWQgPSBmYWxzZTtcbiAgfVxuICBpbml0KCkge1xuICAgIGlmICh0aGlzLl9pbml0aWFsaXplZCkgcmV0dXJuO1xuICAgIHRoaXMuX2luaXRpYWxpemVkID0gdHJ1ZTtcbiAgICB0aGlzLl9lZmZlY3RDbGFzc2VzLmZvckVhY2goKHRlc3QpID0+IHtcbiAgICAgIHRoaXMuYWRkKHtcbiAgICAgICAgdGVzdDogdGVzdC50ZXN0LFxuICAgICAgICBtYXNrQ2xhc3M6IHRlc3RcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIGFkZCh0ZXN0KSB7XG4gICAgdGhpcy5fdGVzdHMucHVzaCh0ZXN0KTtcbiAgfVxuICBnZXRNYXNrRWZmZWN0KGl0ZW0pIHtcbiAgICBpZiAoIXRoaXMuX2luaXRpYWxpemVkKSB0aGlzLmluaXQoKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuX3Rlc3RzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCB0ZXN0ID0gdGhpcy5fdGVzdHNbaV07XG4gICAgICBpZiAodGVzdC50ZXN0KGl0ZW0pKSB7XG4gICAgICAgIHJldHVybiBCaWdQb29sLmdldCh0ZXN0Lm1hc2tDbGFzcywgaXRlbSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBpdGVtO1xuICB9XG4gIHJldHVybk1hc2tFZmZlY3QoZWZmZWN0KSB7XG4gICAgQmlnUG9vbC5yZXR1cm4oZWZmZWN0KTtcbiAgfVxufVxuY29uc3QgTWFza0VmZmVjdE1hbmFnZXIgPSBuZXcgTWFza0VmZmVjdE1hbmFnZXJDbGFzcygpO1xuZXh0ZW5zaW9ucy5oYW5kbGVCeUxpc3QoRXh0ZW5zaW9uVHlwZS5NYXNrRWZmZWN0LCBNYXNrRWZmZWN0TWFuYWdlci5fZWZmZWN0Q2xhc3Nlcyk7XG5cbmV4cG9ydCB7IE1hc2tFZmZlY3RNYW5hZ2VyLCBNYXNrRWZmZWN0TWFuYWdlckNsYXNzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1NYXNrRWZmZWN0TWFuYWdlci5tanMubWFwXG4iLCJpbXBvcnQgeyBGaWx0ZXJFZmZlY3QgfSBmcm9tICcuLi8uLi8uLi9maWx0ZXJzL0ZpbHRlckVmZmVjdC5tanMnO1xuaW1wb3J0IHsgTWFza0VmZmVjdE1hbmFnZXIgfSBmcm9tICcuLi8uLi8uLi9yZW5kZXJpbmcvbWFzay9NYXNrRWZmZWN0TWFuYWdlci5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IGVmZmVjdHNNaXhpbiA9IHtcbiAgX21hc2tFZmZlY3Q6IG51bGwsXG4gIF9tYXNrT3B0aW9uczoge1xuICAgIGludmVyc2U6IGZhbHNlLFxuICAgIGNoYW5uZWw6IFwicmVkXCJcbiAgfSxcbiAgX2ZpbHRlckVmZmVjdDogbnVsbCxcbiAgZWZmZWN0czogW10sXG4gIF9tYXJrU3RydWN0dXJlQXNDaGFuZ2VkKCkge1xuICAgIGNvbnN0IHJlbmRlckdyb3VwID0gdGhpcy5yZW5kZXJHcm91cCB8fCB0aGlzLnBhcmVudFJlbmRlckdyb3VwO1xuICAgIGlmIChyZW5kZXJHcm91cCkge1xuICAgICAgcmVuZGVyR3JvdXAuc3RydWN0dXJlRGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICB9XG4gIH0sXG4gIGFkZEVmZmVjdChlZmZlY3QpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuZWZmZWN0cy5pbmRleE9mKGVmZmVjdCk7XG4gICAgaWYgKGluZGV4ICE9PSAtMSkgcmV0dXJuO1xuICAgIHRoaXMuZWZmZWN0cy5wdXNoKGVmZmVjdCk7XG4gICAgdGhpcy5lZmZlY3RzLnNvcnQoKGEsIGIpID0+IGEucHJpb3JpdHkgLSBiLnByaW9yaXR5KTtcbiAgICB0aGlzLl9tYXJrU3RydWN0dXJlQXNDaGFuZ2VkKCk7XG4gICAgdGhpcy5fdXBkYXRlSXNTaW1wbGUoKTtcbiAgfSxcbiAgcmVtb3ZlRWZmZWN0KGVmZmVjdCkge1xuICAgIGNvbnN0IGluZGV4ID0gdGhpcy5lZmZlY3RzLmluZGV4T2YoZWZmZWN0KTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSByZXR1cm47XG4gICAgdGhpcy5lZmZlY3RzLnNwbGljZShpbmRleCwgMSk7XG4gICAgdGhpcy5fbWFya1N0cnVjdHVyZUFzQ2hhbmdlZCgpO1xuICAgIHRoaXMuX3VwZGF0ZUlzU2ltcGxlKCk7XG4gIH0sXG4gIHNldCBtYXNrKHZhbHVlKSB7XG4gICAgY29uc3QgZWZmZWN0ID0gdGhpcy5fbWFza0VmZmVjdDtcbiAgICBpZiAoZWZmZWN0Py5tYXNrID09PSB2YWx1ZSkgcmV0dXJuO1xuICAgIGlmIChlZmZlY3QpIHtcbiAgICAgIHRoaXMucmVtb3ZlRWZmZWN0KGVmZmVjdCk7XG4gICAgICBNYXNrRWZmZWN0TWFuYWdlci5yZXR1cm5NYXNrRWZmZWN0KGVmZmVjdCk7XG4gICAgICB0aGlzLl9tYXNrRWZmZWN0ID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB2b2lkIDApIHJldHVybjtcbiAgICB0aGlzLl9tYXNrRWZmZWN0ID0gTWFza0VmZmVjdE1hbmFnZXIuZ2V0TWFza0VmZmVjdCh2YWx1ZSk7XG4gICAgdGhpcy5hZGRFZmZlY3QodGhpcy5fbWFza0VmZmVjdCk7XG4gIH0sXG4gIGdldCBtYXNrKCkge1xuICAgIHJldHVybiB0aGlzLl9tYXNrRWZmZWN0Py5tYXNrO1xuICB9LFxuICBzZXRNYXNrKG9wdGlvbnMpIHtcbiAgICB0aGlzLl9tYXNrT3B0aW9ucyA9IHtcbiAgICAgIC4uLnRoaXMuX21hc2tPcHRpb25zLFxuICAgICAgLi4ub3B0aW9uc1xuICAgIH07XG4gICAgaWYgKG9wdGlvbnMubWFzaykge1xuICAgICAgdGhpcy5tYXNrID0gb3B0aW9ucy5tYXNrO1xuICAgIH1cbiAgICB0aGlzLl9tYXJrU3RydWN0dXJlQXNDaGFuZ2VkKCk7XG4gIH0sXG4gIHNldCBmaWx0ZXJzKHZhbHVlKSB7XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KHZhbHVlKSAmJiB2YWx1ZSkgdmFsdWUgPSBbdmFsdWVdO1xuICAgIGNvbnN0IGVmZmVjdCA9IHRoaXMuX2ZpbHRlckVmZmVjdCB8fCAodGhpcy5fZmlsdGVyRWZmZWN0ID0gbmV3IEZpbHRlckVmZmVjdCgpKTtcbiAgICB2YWx1ZSA9IHZhbHVlO1xuICAgIGNvbnN0IGhhc0ZpbHRlcnMgPSB2YWx1ZT8ubGVuZ3RoID4gMDtcbiAgICBjb25zdCBoYWRGaWx0ZXJzID0gZWZmZWN0LmZpbHRlcnM/Lmxlbmd0aCA+IDA7XG4gICAgY29uc3QgZGlkQ2hhbmdlID0gaGFzRmlsdGVycyAhPT0gaGFkRmlsdGVycztcbiAgICB2YWx1ZSA9IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUuc2xpY2UoMCkgOiB2YWx1ZTtcbiAgICBlZmZlY3QuZmlsdGVycyA9IE9iamVjdC5mcmVlemUodmFsdWUpO1xuICAgIGlmIChkaWRDaGFuZ2UpIHtcbiAgICAgIGlmIChoYXNGaWx0ZXJzKSB7XG4gICAgICAgIHRoaXMuYWRkRWZmZWN0KGVmZmVjdCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnJlbW92ZUVmZmVjdChlZmZlY3QpO1xuICAgICAgICBlZmZlY3QuZmlsdGVycyA9IHZhbHVlID8/IG51bGw7XG4gICAgICB9XG4gICAgfVxuICB9LFxuICBnZXQgZmlsdGVycygpIHtcbiAgICByZXR1cm4gdGhpcy5fZmlsdGVyRWZmZWN0Py5maWx0ZXJzO1xuICB9LFxuICBzZXQgZmlsdGVyQXJlYSh2YWx1ZSkge1xuICAgIHRoaXMuX2ZpbHRlckVmZmVjdCB8fCAodGhpcy5fZmlsdGVyRWZmZWN0ID0gbmV3IEZpbHRlckVmZmVjdCgpKTtcbiAgICB0aGlzLl9maWx0ZXJFZmZlY3QuZmlsdGVyQXJlYSA9IHZhbHVlO1xuICB9LFxuICBnZXQgZmlsdGVyQXJlYSgpIHtcbiAgICByZXR1cm4gdGhpcy5fZmlsdGVyRWZmZWN0Py5maWx0ZXJBcmVhO1xuICB9XG59O1xuXG5leHBvcnQgeyBlZmZlY3RzTWl4aW4gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVmZmVjdHNNaXhpbi5tanMubWFwXG4iLCJpbXBvcnQgeyBkZXByZWNhdGlvbiwgdjhfMF8wIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy9kZXByZWNhdGlvbi5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IGZpbmRNaXhpbiA9IHtcbiAgbGFiZWw6IG51bGwsXG4gIGdldCBuYW1lKCkge1xuICAgIGRlcHJlY2F0aW9uKHY4XzBfMCwgXCJDb250YWluZXIubmFtZSBwcm9wZXJ0eSBoYXMgYmVlbiByZW1vdmVkLCB1c2UgQ29udGFpbmVyLmxhYmVsIGluc3RlYWRcIik7XG4gICAgcmV0dXJuIHRoaXMubGFiZWw7XG4gIH0sXG4gIHNldCBuYW1lKHZhbHVlKSB7XG4gICAgZGVwcmVjYXRpb24odjhfMF8wLCBcIkNvbnRhaW5lci5uYW1lIHByb3BlcnR5IGhhcyBiZWVuIHJlbW92ZWQsIHVzZSBDb250YWluZXIubGFiZWwgaW5zdGVhZFwiKTtcbiAgICB0aGlzLmxhYmVsID0gdmFsdWU7XG4gIH0sXG4gIGdldENoaWxkQnlOYW1lKG5hbWUsIGRlZXAgPSBmYWxzZSkge1xuICAgIHJldHVybiB0aGlzLmdldENoaWxkQnlMYWJlbChuYW1lLCBkZWVwKTtcbiAgfSxcbiAgZ2V0Q2hpbGRCeUxhYmVsKGxhYmVsLCBkZWVwID0gZmFsc2UpIHtcbiAgICBjb25zdCBjaGlsZHJlbiA9IHRoaXMuY2hpbGRyZW47XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgY2hpbGQgPSBjaGlsZHJlbltpXTtcbiAgICAgIGlmIChjaGlsZC5sYWJlbCA9PT0gbGFiZWwgfHwgbGFiZWwgaW5zdGFuY2VvZiBSZWdFeHAgJiYgbGFiZWwudGVzdChjaGlsZC5sYWJlbCkpIHJldHVybiBjaGlsZDtcbiAgICB9XG4gICAgaWYgKGRlZXApIHtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgY2hpbGQgPSBjaGlsZHJlbltpXTtcbiAgICAgICAgY29uc3QgZm91bmQgPSBjaGlsZC5nZXRDaGlsZEJ5TGFiZWwobGFiZWwsIHRydWUpO1xuICAgICAgICBpZiAoZm91bmQpIHtcbiAgICAgICAgICByZXR1cm4gZm91bmQ7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH0sXG4gIGdldENoaWxkcmVuQnlMYWJlbChsYWJlbCwgZGVlcCA9IGZhbHNlLCBvdXQgPSBbXSkge1xuICAgIGNvbnN0IGNoaWxkcmVuID0gdGhpcy5jaGlsZHJlbjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBjaGlsZCA9IGNoaWxkcmVuW2ldO1xuICAgICAgaWYgKGNoaWxkLmxhYmVsID09PSBsYWJlbCB8fCBsYWJlbCBpbnN0YW5jZW9mIFJlZ0V4cCAmJiBsYWJlbC50ZXN0KGNoaWxkLmxhYmVsKSkge1xuICAgICAgICBvdXQucHVzaChjaGlsZCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChkZWVwKSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNoaWxkcmVuW2ldLmdldENoaWxkcmVuQnlMYWJlbChsYWJlbCwgdHJ1ZSwgb3V0KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG91dDtcbiAgfVxufTtcblxuZXhwb3J0IHsgZmluZE1peGluIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1maW5kTWl4aW4ubWpzLm1hcFxuIiwiaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgQmlnUG9vbCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3Bvb2wvUG9vbEdyb3VwLm1qcyc7XG5pbXBvcnQgeyBCb3VuZHMgfSBmcm9tICcuLi9Cb3VuZHMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBtYXRyaXhQb29sID0gQmlnUG9vbC5nZXRQb29sKE1hdHJpeCk7XG5jb25zdCBib3VuZHNQb29sID0gQmlnUG9vbC5nZXRQb29sKEJvdW5kcyk7XG5cbmV4cG9ydCB7IGJvdW5kc1Bvb2wsIG1hdHJpeFBvb2wgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1hdHJpeEFuZEJvdW5kc1Bvb2wubWpzLm1hcFxuIiwiaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgQm91bmRzIH0gZnJvbSAnLi4vYm91bmRzL0JvdW5kcy5tanMnO1xuaW1wb3J0IHsgYm91bmRzUG9vbCB9IGZyb20gJy4uL2JvdW5kcy91dGlscy9tYXRyaXhBbmRCb3VuZHNQb29sLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgdGVtcE1hdHJpeCA9IG5ldyBNYXRyaXgoKTtcbmNvbnN0IGdldEZhc3RHbG9iYWxCb3VuZHNNaXhpbiA9IHtcbiAgZ2V0RmFzdEdsb2JhbEJvdW5kcyhmYWN0b3JSZW5kZXJMYXllcnMsIGJvdW5kcykge1xuICAgIGJvdW5kcyB8fCAoYm91bmRzID0gbmV3IEJvdW5kcygpKTtcbiAgICBib3VuZHMuY2xlYXIoKTtcbiAgICB0aGlzLl9nZXRHbG9iYWxCb3VuZHNSZWN1cnNpdmUoISFmYWN0b3JSZW5kZXJMYXllcnMsIGJvdW5kcywgdGhpcy5wYXJlbnRSZW5kZXJMYXllcik7XG4gICAgaWYgKCFib3VuZHMuaXNWYWxpZCkge1xuICAgICAgYm91bmRzLnNldCgwLCAwLCAwLCAwKTtcbiAgICB9XG4gICAgY29uc3QgcmVuZGVyR3JvdXAgPSB0aGlzLnJlbmRlckdyb3VwIHx8IHRoaXMucGFyZW50UmVuZGVyR3JvdXA7XG4gICAgYm91bmRzLmFwcGx5TWF0cml4KHJlbmRlckdyb3VwLndvcmxkVHJhbnNmb3JtKTtcbiAgICByZXR1cm4gYm91bmRzO1xuICB9LFxuICBfZ2V0R2xvYmFsQm91bmRzUmVjdXJzaXZlKGZhY3RvclJlbmRlckxheWVycywgYm91bmRzLCBjdXJyZW50TGF5ZXIpIHtcbiAgICBsZXQgbG9jYWxCb3VuZHMgPSBib3VuZHM7XG4gICAgaWYgKGZhY3RvclJlbmRlckxheWVycyAmJiB0aGlzLnBhcmVudFJlbmRlckxheWVyICYmIHRoaXMucGFyZW50UmVuZGVyTGF5ZXIgIT09IGN1cnJlbnRMYXllcikgcmV0dXJuO1xuICAgIGlmICh0aGlzLmxvY2FsRGlzcGxheVN0YXR1cyAhPT0gNyB8fCAhdGhpcy5tZWFzdXJhYmxlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG1hbmFnZUVmZmVjdHMgPSAhIXRoaXMuZWZmZWN0cy5sZW5ndGg7XG4gICAgaWYgKHRoaXMucmVuZGVyR3JvdXAgfHwgbWFuYWdlRWZmZWN0cykge1xuICAgICAgbG9jYWxCb3VuZHMgPSBib3VuZHNQb29sLmdldCgpLmNsZWFyKCk7XG4gICAgfVxuICAgIGlmICh0aGlzLmJvdW5kc0FyZWEpIHtcbiAgICAgIGJvdW5kcy5hZGRSZWN0KHRoaXMuYm91bmRzQXJlYSwgdGhpcy53b3JsZFRyYW5zZm9ybSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICh0aGlzLnJlbmRlclBpcGVJZCkge1xuICAgICAgICBjb25zdCB2aWV3Qm91bmRzID0gdGhpcy5ib3VuZHM7XG4gICAgICAgIGxvY2FsQm91bmRzLmFkZEZyYW1lKFxuICAgICAgICAgIHZpZXdCb3VuZHMubWluWCxcbiAgICAgICAgICB2aWV3Qm91bmRzLm1pblksXG4gICAgICAgICAgdmlld0JvdW5kcy5tYXhYLFxuICAgICAgICAgIHZpZXdCb3VuZHMubWF4WSxcbiAgICAgICAgICB0aGlzLmdyb3VwVHJhbnNmb3JtXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBjb25zdCBjaGlsZHJlbiA9IHRoaXMuY2hpbGRyZW47XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNoaWxkcmVuW2ldLl9nZXRHbG9iYWxCb3VuZHNSZWN1cnNpdmUoZmFjdG9yUmVuZGVyTGF5ZXJzLCBsb2NhbEJvdW5kcywgY3VycmVudExheWVyKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKG1hbmFnZUVmZmVjdHMpIHtcbiAgICAgIGxldCBhZHZhbmNlZCA9IGZhbHNlO1xuICAgICAgY29uc3QgcmVuZGVyR3JvdXAgPSB0aGlzLnJlbmRlckdyb3VwIHx8IHRoaXMucGFyZW50UmVuZGVyR3JvdXA7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuZWZmZWN0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAodGhpcy5lZmZlY3RzW2ldLmFkZEJvdW5kcykge1xuICAgICAgICAgIGlmICghYWR2YW5jZWQpIHtcbiAgICAgICAgICAgIGFkdmFuY2VkID0gdHJ1ZTtcbiAgICAgICAgICAgIGxvY2FsQm91bmRzLmFwcGx5TWF0cml4KHJlbmRlckdyb3VwLndvcmxkVHJhbnNmb3JtKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5lZmZlY3RzW2ldLmFkZEJvdW5kcyhsb2NhbEJvdW5kcywgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChhZHZhbmNlZCkge1xuICAgICAgICBsb2NhbEJvdW5kcy5hcHBseU1hdHJpeChyZW5kZXJHcm91cC53b3JsZFRyYW5zZm9ybS5jb3B5VG8odGVtcE1hdHJpeCkuaW52ZXJ0KCkpO1xuICAgICAgfVxuICAgICAgYm91bmRzLmFkZEJvdW5kcyhsb2NhbEJvdW5kcyk7XG4gICAgICBib3VuZHNQb29sLnJldHVybihsb2NhbEJvdW5kcyk7XG4gICAgfSBlbHNlIGlmICh0aGlzLnJlbmRlckdyb3VwKSB7XG4gICAgICBib3VuZHMuYWRkQm91bmRzKGxvY2FsQm91bmRzLCB0aGlzLnJlbGF0aXZlR3JvdXBUcmFuc2Zvcm0pO1xuICAgICAgYm91bmRzUG9vbC5yZXR1cm4obG9jYWxCb3VuZHMpO1xuICAgIH1cbiAgfVxufTtcblxuZXhwb3J0IHsgZ2V0RmFzdEdsb2JhbEJvdW5kc01peGluIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1nZXRGYXN0R2xvYmFsQm91bmRzTWl4aW4ubWpzLm1hcFxuIiwiaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgbWF0cml4UG9vbCwgYm91bmRzUG9vbCB9IGZyb20gJy4vdXRpbHMvbWF0cml4QW5kQm91bmRzUG9vbC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGdldEdsb2JhbEJvdW5kcyh0YXJnZXQsIHNraXBVcGRhdGVUcmFuc2Zvcm0sIGJvdW5kcykge1xuICBib3VuZHMuY2xlYXIoKTtcbiAgbGV0IHBhcmVudFRyYW5zZm9ybTtcbiAgbGV0IHBvb2xlZE1hdHJpeDtcbiAgaWYgKHRhcmdldC5wYXJlbnQpIHtcbiAgICBpZiAoIXNraXBVcGRhdGVUcmFuc2Zvcm0pIHtcbiAgICAgIHBvb2xlZE1hdHJpeCA9IG1hdHJpeFBvb2wuZ2V0KCkuaWRlbnRpdHkoKTtcbiAgICAgIHBhcmVudFRyYW5zZm9ybSA9IHVwZGF0ZVRyYW5zZm9ybUJhY2t3YXJkcyh0YXJnZXQsIHBvb2xlZE1hdHJpeCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhcmVudFRyYW5zZm9ybSA9IHRhcmdldC5wYXJlbnQud29ybGRUcmFuc2Zvcm07XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHBhcmVudFRyYW5zZm9ybSA9IE1hdHJpeC5JREVOVElUWTtcbiAgfVxuICBfZ2V0R2xvYmFsQm91bmRzKHRhcmdldCwgYm91bmRzLCBwYXJlbnRUcmFuc2Zvcm0sIHNraXBVcGRhdGVUcmFuc2Zvcm0pO1xuICBpZiAocG9vbGVkTWF0cml4KSB7XG4gICAgbWF0cml4UG9vbC5yZXR1cm4ocG9vbGVkTWF0cml4KTtcbiAgfVxuICBpZiAoIWJvdW5kcy5pc1ZhbGlkKSB7XG4gICAgYm91bmRzLnNldCgwLCAwLCAwLCAwKTtcbiAgfVxuICByZXR1cm4gYm91bmRzO1xufVxuZnVuY3Rpb24gX2dldEdsb2JhbEJvdW5kcyh0YXJnZXQsIGJvdW5kcywgcGFyZW50VHJhbnNmb3JtLCBza2lwVXBkYXRlVHJhbnNmb3JtKSB7XG4gIGlmICghdGFyZ2V0LnZpc2libGUgfHwgIXRhcmdldC5tZWFzdXJhYmxlKSByZXR1cm47XG4gIGxldCB3b3JsZFRyYW5zZm9ybTtcbiAgaWYgKCFza2lwVXBkYXRlVHJhbnNmb3JtKSB7XG4gICAgdGFyZ2V0LnVwZGF0ZUxvY2FsVHJhbnNmb3JtKCk7XG4gICAgd29ybGRUcmFuc2Zvcm0gPSBtYXRyaXhQb29sLmdldCgpO1xuICAgIHdvcmxkVHJhbnNmb3JtLmFwcGVuZEZyb20odGFyZ2V0LmxvY2FsVHJhbnNmb3JtLCBwYXJlbnRUcmFuc2Zvcm0pO1xuICB9IGVsc2Uge1xuICAgIHdvcmxkVHJhbnNmb3JtID0gdGFyZ2V0LndvcmxkVHJhbnNmb3JtO1xuICB9XG4gIGNvbnN0IHBhcmVudEJvdW5kcyA9IGJvdW5kcztcbiAgY29uc3QgcHJlc2VydmVCb3VuZHMgPSAhIXRhcmdldC5lZmZlY3RzLmxlbmd0aDtcbiAgaWYgKHByZXNlcnZlQm91bmRzKSB7XG4gICAgYm91bmRzID0gYm91bmRzUG9vbC5nZXQoKS5jbGVhcigpO1xuICB9XG4gIGlmICh0YXJnZXQuYm91bmRzQXJlYSkge1xuICAgIGJvdW5kcy5hZGRSZWN0KHRhcmdldC5ib3VuZHNBcmVhLCB3b3JsZFRyYW5zZm9ybSk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgcmVuZGVyYWJsZUJvdW5kcyA9IHRhcmdldC5ib3VuZHM7XG4gICAgaWYgKHJlbmRlcmFibGVCb3VuZHMgJiYgIXJlbmRlcmFibGVCb3VuZHMuaXNFbXB0eSgpKSB7XG4gICAgICBib3VuZHMubWF0cml4ID0gd29ybGRUcmFuc2Zvcm07XG4gICAgICBib3VuZHMuYWRkQm91bmRzKHJlbmRlcmFibGVCb3VuZHMpO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhcmdldC5jaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgX2dldEdsb2JhbEJvdW5kcyh0YXJnZXQuY2hpbGRyZW5baV0sIGJvdW5kcywgd29ybGRUcmFuc2Zvcm0sIHNraXBVcGRhdGVUcmFuc2Zvcm0pO1xuICAgIH1cbiAgfVxuICBpZiAocHJlc2VydmVCb3VuZHMpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhcmdldC5lZmZlY3RzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB0YXJnZXQuZWZmZWN0c1tpXS5hZGRCb3VuZHM/Lihib3VuZHMpO1xuICAgIH1cbiAgICBwYXJlbnRCb3VuZHMuYWRkQm91bmRzKGJvdW5kcywgTWF0cml4LklERU5USVRZKTtcbiAgICBib3VuZHNQb29sLnJldHVybihib3VuZHMpO1xuICB9XG4gIGlmICghc2tpcFVwZGF0ZVRyYW5zZm9ybSkge1xuICAgIG1hdHJpeFBvb2wucmV0dXJuKHdvcmxkVHJhbnNmb3JtKTtcbiAgfVxufVxuZnVuY3Rpb24gdXBkYXRlVHJhbnNmb3JtQmFja3dhcmRzKHRhcmdldCwgcGFyZW50VHJhbnNmb3JtKSB7XG4gIGNvbnN0IHBhcmVudCA9IHRhcmdldC5wYXJlbnQ7XG4gIGlmIChwYXJlbnQpIHtcbiAgICB1cGRhdGVUcmFuc2Zvcm1CYWNrd2FyZHMocGFyZW50LCBwYXJlbnRUcmFuc2Zvcm0pO1xuICAgIHBhcmVudC51cGRhdGVMb2NhbFRyYW5zZm9ybSgpO1xuICAgIHBhcmVudFRyYW5zZm9ybS5hcHBlbmQocGFyZW50LmxvY2FsVHJhbnNmb3JtKTtcbiAgfVxuICByZXR1cm4gcGFyZW50VHJhbnNmb3JtO1xufVxuXG5leHBvcnQgeyBnZXRHbG9iYWxCb3VuZHMsIHVwZGF0ZVRyYW5zZm9ybUJhY2t3YXJkcyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Z2V0R2xvYmFsQm91bmRzLm1qcy5tYXBcbiIsImltcG9ydCB7IG11bHRpcGx5SGV4Q29sb3JzIH0gZnJvbSAnLi9tdWx0aXBseUhleENvbG9ycy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IFdISVRFX0JHUiA9IDE2Nzc3MjE1O1xuZnVuY3Rpb24gbXVsdGlwbHlDb2xvcnMobG9jYWxCR1JDb2xvciwgcGFyZW50QkdSQ29sb3IpIHtcbiAgaWYgKGxvY2FsQkdSQ29sb3IgPT09IFdISVRFX0JHUikge1xuICAgIHJldHVybiBwYXJlbnRCR1JDb2xvcjtcbiAgfVxuICBpZiAocGFyZW50QkdSQ29sb3IgPT09IFdISVRFX0JHUikge1xuICAgIHJldHVybiBsb2NhbEJHUkNvbG9yO1xuICB9XG4gIHJldHVybiBtdWx0aXBseUhleENvbG9ycyhsb2NhbEJHUkNvbG9yLCBwYXJlbnRCR1JDb2xvcik7XG59XG5cbmV4cG9ydCB7IG11bHRpcGx5Q29sb3JzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdWx0aXBseUNvbG9ycy5tanMubWFwXG4iLCJpbXBvcnQgeyBNYXRyaXggfSBmcm9tICcuLi8uLi8uLi9tYXRocy9tYXRyaXgvTWF0cml4Lm1qcyc7XG5pbXBvcnQgeyB1cGRhdGVUcmFuc2Zvcm1CYWNrd2FyZHMgfSBmcm9tICcuLi9ib3VuZHMvZ2V0R2xvYmFsQm91bmRzLm1qcyc7XG5pbXBvcnQgeyBtYXRyaXhQb29sIH0gZnJvbSAnLi4vYm91bmRzL3V0aWxzL21hdHJpeEFuZEJvdW5kc1Bvb2wubWpzJztcbmltcG9ydCB7IG11bHRpcGx5Q29sb3JzIH0gZnJvbSAnLi4vdXRpbHMvbXVsdGlwbHlDb2xvcnMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBiZ3IycmdiKGNvbG9yKSB7XG4gIHJldHVybiAoKGNvbG9yICYgMjU1KSA8PCAxNikgKyAoY29sb3IgJiA2NTI4MCkgKyAoY29sb3IgPj4gMTYgJiAyNTUpO1xufVxuY29uc3QgZ2V0R2xvYmFsTWl4aW4gPSB7XG4gIGdldEdsb2JhbEFscGhhKHNraXBVcGRhdGUpIHtcbiAgICBpZiAoc2tpcFVwZGF0ZSkge1xuICAgICAgaWYgKHRoaXMucmVuZGVyR3JvdXApIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVuZGVyR3JvdXAud29ybGRBbHBoYTtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLnBhcmVudFJlbmRlckdyb3VwKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnBhcmVudFJlbmRlckdyb3VwLndvcmxkQWxwaGEgKiB0aGlzLmFscGhhO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuYWxwaGE7XG4gICAgfVxuICAgIGxldCBhbHBoYSA9IHRoaXMuYWxwaGE7XG4gICAgbGV0IGN1cnJlbnQgPSB0aGlzLnBhcmVudDtcbiAgICB3aGlsZSAoY3VycmVudCkge1xuICAgICAgYWxwaGEgKj0gY3VycmVudC5hbHBoYTtcbiAgICAgIGN1cnJlbnQgPSBjdXJyZW50LnBhcmVudDtcbiAgICB9XG4gICAgcmV0dXJuIGFscGhhO1xuICB9LFxuICBnZXRHbG9iYWxUcmFuc2Zvcm0obWF0cml4ID0gbmV3IE1hdHJpeCgpLCBza2lwVXBkYXRlKSB7XG4gICAgaWYgKHNraXBVcGRhdGUpIHtcbiAgICAgIHJldHVybiBtYXRyaXguY29weUZyb20odGhpcy53b3JsZFRyYW5zZm9ybSk7XG4gICAgfVxuICAgIHRoaXMudXBkYXRlTG9jYWxUcmFuc2Zvcm0oKTtcbiAgICBjb25zdCBwYXJlbnRUcmFuc2Zvcm0gPSB1cGRhdGVUcmFuc2Zvcm1CYWNrd2FyZHModGhpcywgbWF0cml4UG9vbC5nZXQoKS5pZGVudGl0eSgpKTtcbiAgICBtYXRyaXguYXBwZW5kRnJvbSh0aGlzLmxvY2FsVHJhbnNmb3JtLCBwYXJlbnRUcmFuc2Zvcm0pO1xuICAgIG1hdHJpeFBvb2wucmV0dXJuKHBhcmVudFRyYW5zZm9ybSk7XG4gICAgcmV0dXJuIG1hdHJpeDtcbiAgfSxcbiAgZ2V0R2xvYmFsVGludChza2lwVXBkYXRlKSB7XG4gICAgaWYgKHNraXBVcGRhdGUpIHtcbiAgICAgIGlmICh0aGlzLnJlbmRlckdyb3VwKSB7XG4gICAgICAgIHJldHVybiBiZ3IycmdiKHRoaXMucmVuZGVyR3JvdXAud29ybGRDb2xvcik7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5wYXJlbnRSZW5kZXJHcm91cCkge1xuICAgICAgICByZXR1cm4gYmdyMnJnYihcbiAgICAgICAgICBtdWx0aXBseUNvbG9ycyh0aGlzLmxvY2FsQ29sb3IsIHRoaXMucGFyZW50UmVuZGVyR3JvdXAud29ybGRDb2xvcilcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLnRpbnQ7XG4gICAgfVxuICAgIGxldCBjb2xvciA9IHRoaXMubG9jYWxDb2xvcjtcbiAgICBsZXQgcGFyZW50ID0gdGhpcy5wYXJlbnQ7XG4gICAgd2hpbGUgKHBhcmVudCkge1xuICAgICAgY29sb3IgPSBtdWx0aXBseUNvbG9ycyhjb2xvciwgcGFyZW50LmxvY2FsQ29sb3IpO1xuICAgICAgcGFyZW50ID0gcGFyZW50LnBhcmVudDtcbiAgICB9XG4gICAgcmV0dXJuIGJncjJyZ2IoY29sb3IpO1xuICB9XG59O1xuXG5leHBvcnQgeyBiZ3IycmdiLCBnZXRHbG9iYWxNaXhpbiB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Z2V0R2xvYmFsTWl4aW4ubWpzLm1hcFxuIiwiaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgbWF0cml4UG9vbCwgYm91bmRzUG9vbCB9IGZyb20gJy4vdXRpbHMvbWF0cml4QW5kQm91bmRzUG9vbC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGdldExvY2FsQm91bmRzKHRhcmdldCwgYm91bmRzLCByZWxhdGl2ZU1hdHJpeCkge1xuICBib3VuZHMuY2xlYXIoKTtcbiAgcmVsYXRpdmVNYXRyaXggfHwgKHJlbGF0aXZlTWF0cml4ID0gTWF0cml4LklERU5USVRZKTtcbiAgX2dldExvY2FsQm91bmRzKHRhcmdldCwgYm91bmRzLCByZWxhdGl2ZU1hdHJpeCwgdGFyZ2V0LCB0cnVlKTtcbiAgaWYgKCFib3VuZHMuaXNWYWxpZCkge1xuICAgIGJvdW5kcy5zZXQoMCwgMCwgMCwgMCk7XG4gIH1cbiAgcmV0dXJuIGJvdW5kcztcbn1cbmZ1bmN0aW9uIF9nZXRMb2NhbEJvdW5kcyh0YXJnZXQsIGJvdW5kcywgcGFyZW50VHJhbnNmb3JtLCByb290Q29udGFpbmVyLCBpc1Jvb3QpIHtcbiAgbGV0IHJlbGF0aXZlVHJhbnNmb3JtO1xuICBpZiAoIWlzUm9vdCkge1xuICAgIGlmICghdGFyZ2V0LnZpc2libGUgfHwgIXRhcmdldC5tZWFzdXJhYmxlKSByZXR1cm47XG4gICAgdGFyZ2V0LnVwZGF0ZUxvY2FsVHJhbnNmb3JtKCk7XG4gICAgY29uc3QgbG9jYWxUcmFuc2Zvcm0gPSB0YXJnZXQubG9jYWxUcmFuc2Zvcm07XG4gICAgcmVsYXRpdmVUcmFuc2Zvcm0gPSBtYXRyaXhQb29sLmdldCgpO1xuICAgIHJlbGF0aXZlVHJhbnNmb3JtLmFwcGVuZEZyb20obG9jYWxUcmFuc2Zvcm0sIHBhcmVudFRyYW5zZm9ybSk7XG4gIH0gZWxzZSB7XG4gICAgcmVsYXRpdmVUcmFuc2Zvcm0gPSBtYXRyaXhQb29sLmdldCgpO1xuICAgIHJlbGF0aXZlVHJhbnNmb3JtID0gcGFyZW50VHJhbnNmb3JtLmNvcHlUbyhyZWxhdGl2ZVRyYW5zZm9ybSk7XG4gIH1cbiAgY29uc3QgcGFyZW50Qm91bmRzID0gYm91bmRzO1xuICBjb25zdCBwcmVzZXJ2ZUJvdW5kcyA9ICEhdGFyZ2V0LmVmZmVjdHMubGVuZ3RoO1xuICBpZiAocHJlc2VydmVCb3VuZHMpIHtcbiAgICBib3VuZHMgPSBib3VuZHNQb29sLmdldCgpLmNsZWFyKCk7XG4gIH1cbiAgaWYgKHRhcmdldC5ib3VuZHNBcmVhKSB7XG4gICAgYm91bmRzLmFkZFJlY3QodGFyZ2V0LmJvdW5kc0FyZWEsIHJlbGF0aXZlVHJhbnNmb3JtKTtcbiAgfSBlbHNlIHtcbiAgICBpZiAodGFyZ2V0LnJlbmRlclBpcGVJZCkge1xuICAgICAgYm91bmRzLm1hdHJpeCA9IHJlbGF0aXZlVHJhbnNmb3JtO1xuICAgICAgYm91bmRzLmFkZEJvdW5kcyh0YXJnZXQuYm91bmRzKTtcbiAgICB9XG4gICAgY29uc3QgY2hpbGRyZW4gPSB0YXJnZXQuY2hpbGRyZW47XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgX2dldExvY2FsQm91bmRzKGNoaWxkcmVuW2ldLCBib3VuZHMsIHJlbGF0aXZlVHJhbnNmb3JtLCByb290Q29udGFpbmVyLCBmYWxzZSk7XG4gICAgfVxuICB9XG4gIGlmIChwcmVzZXJ2ZUJvdW5kcykge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFyZ2V0LmVmZmVjdHMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHRhcmdldC5lZmZlY3RzW2ldLmFkZExvY2FsQm91bmRzPy4oYm91bmRzLCByb290Q29udGFpbmVyKTtcbiAgICB9XG4gICAgcGFyZW50Qm91bmRzLmFkZEJvdW5kcyhib3VuZHMsIE1hdHJpeC5JREVOVElUWSk7XG4gICAgYm91bmRzUG9vbC5yZXR1cm4oYm91bmRzKTtcbiAgfVxuICBtYXRyaXhQb29sLnJldHVybihyZWxhdGl2ZVRyYW5zZm9ybSk7XG59XG5cbmV4cG9ydCB7IGdldExvY2FsQm91bmRzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1nZXRMb2NhbEJvdW5kcy5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGNoZWNrQ2hpbGRyZW5EaWRDaGFuZ2UoY29udGFpbmVyLCBwcmV2aW91c0RhdGEpIHtcbiAgY29uc3QgY2hpbGRyZW4gPSBjb250YWluZXIuY2hpbGRyZW47XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjaGlsZCA9IGNoaWxkcmVuW2ldO1xuICAgIGNvbnN0IHVpZCA9IGNoaWxkLnVpZDtcbiAgICBjb25zdCBkaWRDaGFuZ2UgPSAoY2hpbGQuX2RpZFZpZXdDaGFuZ2VUaWNrICYgNjU1MzUpIDw8IDE2IHwgY2hpbGQuX2RpZENvbnRhaW5lckNoYW5nZVRpY2sgJiA2NTUzNTtcbiAgICBjb25zdCBpbmRleCA9IHByZXZpb3VzRGF0YS5pbmRleDtcbiAgICBpZiAocHJldmlvdXNEYXRhLmRhdGFbaW5kZXhdICE9PSB1aWQgfHwgcHJldmlvdXNEYXRhLmRhdGFbaW5kZXggKyAxXSAhPT0gZGlkQ2hhbmdlKSB7XG4gICAgICBwcmV2aW91c0RhdGEuZGF0YVtwcmV2aW91c0RhdGEuaW5kZXhdID0gdWlkO1xuICAgICAgcHJldmlvdXNEYXRhLmRhdGFbcHJldmlvdXNEYXRhLmluZGV4ICsgMV0gPSBkaWRDaGFuZ2U7XG4gICAgICBwcmV2aW91c0RhdGEuZGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICB9XG4gICAgcHJldmlvdXNEYXRhLmluZGV4ID0gaW5kZXggKyAyO1xuICAgIGlmIChjaGlsZC5jaGlsZHJlbi5sZW5ndGgpIHtcbiAgICAgIGNoZWNrQ2hpbGRyZW5EaWRDaGFuZ2UoY2hpbGQsIHByZXZpb3VzRGF0YSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBwcmV2aW91c0RhdGEuZGlkQ2hhbmdlO1xufVxuXG5leHBvcnQgeyBjaGVja0NoaWxkcmVuRGlkQ2hhbmdlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jaGVja0NoaWxkcmVuRGlkQ2hhbmdlLm1qcy5tYXBcbiIsImltcG9ydCB7IE1hdHJpeCB9IGZyb20gJy4uLy4uLy4uL21hdGhzL21hdHJpeC9NYXRyaXgubWpzJztcbmltcG9ydCB7IEJvdW5kcyB9IGZyb20gJy4uL2JvdW5kcy9Cb3VuZHMubWpzJztcbmltcG9ydCB7IGdldEdsb2JhbEJvdW5kcyB9IGZyb20gJy4uL2JvdW5kcy9nZXRHbG9iYWxCb3VuZHMubWpzJztcbmltcG9ydCB7IGdldExvY2FsQm91bmRzIH0gZnJvbSAnLi4vYm91bmRzL2dldExvY2FsQm91bmRzLm1qcyc7XG5pbXBvcnQgeyBjaGVja0NoaWxkcmVuRGlkQ2hhbmdlIH0gZnJvbSAnLi4vdXRpbHMvY2hlY2tDaGlsZHJlbkRpZENoYW5nZS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IHRlbXBNYXRyaXggPSBuZXcgTWF0cml4KCk7XG5jb25zdCBtZWFzdXJlTWl4aW4gPSB7XG4gIF9sb2NhbEJvdW5kc0NhY2hlSWQ6IC0xLFxuICBfbG9jYWxCb3VuZHNDYWNoZURhdGE6IG51bGwsXG4gIF9zZXRXaWR0aCh2YWx1ZSwgbG9jYWxXaWR0aCkge1xuICAgIGNvbnN0IHNpZ24gPSBNYXRoLnNpZ24odGhpcy5zY2FsZS54KSB8fCAxO1xuICAgIGlmIChsb2NhbFdpZHRoICE9PSAwKSB7XG4gICAgICB0aGlzLnNjYWxlLnggPSB2YWx1ZSAvIGxvY2FsV2lkdGggKiBzaWduO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNjYWxlLnggPSBzaWduO1xuICAgIH1cbiAgfSxcbiAgX3NldEhlaWdodCh2YWx1ZSwgbG9jYWxIZWlnaHQpIHtcbiAgICBjb25zdCBzaWduID0gTWF0aC5zaWduKHRoaXMuc2NhbGUueSkgfHwgMTtcbiAgICBpZiAobG9jYWxIZWlnaHQgIT09IDApIHtcbiAgICAgIHRoaXMuc2NhbGUueSA9IHZhbHVlIC8gbG9jYWxIZWlnaHQgKiBzaWduO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNjYWxlLnkgPSBzaWduO1xuICAgIH1cbiAgfSxcbiAgZ2V0TG9jYWxCb3VuZHMoKSB7XG4gICAgaWYgKCF0aGlzLl9sb2NhbEJvdW5kc0NhY2hlRGF0YSkge1xuICAgICAgdGhpcy5fbG9jYWxCb3VuZHNDYWNoZURhdGEgPSB7XG4gICAgICAgIGRhdGE6IFtdLFxuICAgICAgICBpbmRleDogMSxcbiAgICAgICAgZGlkQ2hhbmdlOiBmYWxzZSxcbiAgICAgICAgbG9jYWxCb3VuZHM6IG5ldyBCb3VuZHMoKVxuICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgbG9jYWxCb3VuZHNDYWNoZURhdGEgPSB0aGlzLl9sb2NhbEJvdW5kc0NhY2hlRGF0YTtcbiAgICBsb2NhbEJvdW5kc0NhY2hlRGF0YS5pbmRleCA9IDE7XG4gICAgbG9jYWxCb3VuZHNDYWNoZURhdGEuZGlkQ2hhbmdlID0gZmFsc2U7XG4gICAgaWYgKGxvY2FsQm91bmRzQ2FjaGVEYXRhLmRhdGFbMF0gIT09IHRoaXMuX2RpZFZpZXdDaGFuZ2VUaWNrKSB7XG4gICAgICBsb2NhbEJvdW5kc0NhY2hlRGF0YS5kaWRDaGFuZ2UgPSB0cnVlO1xuICAgICAgbG9jYWxCb3VuZHNDYWNoZURhdGEuZGF0YVswXSA9IHRoaXMuX2RpZFZpZXdDaGFuZ2VUaWNrO1xuICAgIH1cbiAgICBjaGVja0NoaWxkcmVuRGlkQ2hhbmdlKHRoaXMsIGxvY2FsQm91bmRzQ2FjaGVEYXRhKTtcbiAgICBpZiAobG9jYWxCb3VuZHNDYWNoZURhdGEuZGlkQ2hhbmdlKSB7XG4gICAgICBnZXRMb2NhbEJvdW5kcyh0aGlzLCBsb2NhbEJvdW5kc0NhY2hlRGF0YS5sb2NhbEJvdW5kcywgdGVtcE1hdHJpeCk7XG4gICAgfVxuICAgIHJldHVybiBsb2NhbEJvdW5kc0NhY2hlRGF0YS5sb2NhbEJvdW5kcztcbiAgfSxcbiAgZ2V0Qm91bmRzKHNraXBVcGRhdGUsIGJvdW5kcykge1xuICAgIHJldHVybiBnZXRHbG9iYWxCb3VuZHModGhpcywgc2tpcFVwZGF0ZSwgYm91bmRzIHx8IG5ldyBCb3VuZHMoKSk7XG4gIH1cbn07XG5cbmV4cG9ydCB7IG1lYXN1cmVNaXhpbiB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bWVhc3VyZU1peGluLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY29uc3Qgb25SZW5kZXJNaXhpbiA9IHtcbiAgX29uUmVuZGVyOiBudWxsLFxuICBzZXQgb25SZW5kZXIoZnVuYykge1xuICAgIGNvbnN0IHJlbmRlckdyb3VwID0gdGhpcy5yZW5kZXJHcm91cCB8fCB0aGlzLnBhcmVudFJlbmRlckdyb3VwO1xuICAgIGlmICghZnVuYykge1xuICAgICAgaWYgKHRoaXMuX29uUmVuZGVyKSB7XG4gICAgICAgIHJlbmRlckdyb3VwPy5yZW1vdmVPblJlbmRlcih0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuX29uUmVuZGVyID0gbnVsbDtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCF0aGlzLl9vblJlbmRlcikge1xuICAgICAgcmVuZGVyR3JvdXA/LmFkZE9uUmVuZGVyKHRoaXMpO1xuICAgIH1cbiAgICB0aGlzLl9vblJlbmRlciA9IGZ1bmM7XG4gIH0sXG4gIGdldCBvblJlbmRlcigpIHtcbiAgICByZXR1cm4gdGhpcy5fb25SZW5kZXI7XG4gIH1cbn07XG5cbmV4cG9ydCB7IG9uUmVuZGVyTWl4aW4gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW9uUmVuZGVyTWl4aW4ubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBzb3J0TWl4aW4gPSB7XG4gIF96SW5kZXg6IDAsXG4gIHNvcnREaXJ0eTogZmFsc2UsXG4gIHNvcnRhYmxlQ2hpbGRyZW46IGZhbHNlLFxuICBnZXQgekluZGV4KCkge1xuICAgIHJldHVybiB0aGlzLl96SW5kZXg7XG4gIH0sXG4gIHNldCB6SW5kZXgodmFsdWUpIHtcbiAgICBpZiAodGhpcy5fekluZGV4ID09PSB2YWx1ZSkgcmV0dXJuO1xuICAgIHRoaXMuX3pJbmRleCA9IHZhbHVlO1xuICAgIHRoaXMuZGVwdGhPZkNoaWxkTW9kaWZpZWQoKTtcbiAgfSxcbiAgZGVwdGhPZkNoaWxkTW9kaWZpZWQoKSB7XG4gICAgaWYgKHRoaXMucGFyZW50KSB7XG4gICAgICB0aGlzLnBhcmVudC5zb3J0YWJsZUNoaWxkcmVuID0gdHJ1ZTtcbiAgICAgIHRoaXMucGFyZW50LnNvcnREaXJ0eSA9IHRydWU7XG4gICAgfVxuICAgIGlmICh0aGlzLnBhcmVudFJlbmRlckdyb3VwKSB7XG4gICAgICB0aGlzLnBhcmVudFJlbmRlckdyb3VwLnN0cnVjdHVyZURpZENoYW5nZSA9IHRydWU7XG4gICAgfVxuICB9LFxuICBzb3J0Q2hpbGRyZW4oKSB7XG4gICAgaWYgKCF0aGlzLnNvcnREaXJ0eSkgcmV0dXJuO1xuICAgIHRoaXMuc29ydERpcnR5ID0gZmFsc2U7XG4gICAgdGhpcy5jaGlsZHJlbi5zb3J0KHNvcnRDaGlsZHJlbik7XG4gIH1cbn07XG5mdW5jdGlvbiBzb3J0Q2hpbGRyZW4oYSwgYikge1xuICByZXR1cm4gYS5fekluZGV4IC0gYi5fekluZGV4O1xufVxuXG5leHBvcnQgeyBzb3J0TWl4aW4gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNvcnRNaXhpbi5tanMubWFwXG4iLCJpbXBvcnQgeyBQb2ludCB9IGZyb20gJy4uLy4uLy4uL21hdGhzL3BvaW50L1BvaW50Lm1qcyc7XG5pbXBvcnQgeyBtYXRyaXhQb29sIH0gZnJvbSAnLi4vYm91bmRzL3V0aWxzL21hdHJpeEFuZEJvdW5kc1Bvb2wubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCB0b0xvY2FsR2xvYmFsTWl4aW4gPSB7XG4gIGdldEdsb2JhbFBvc2l0aW9uKHBvaW50ID0gbmV3IFBvaW50KCksIHNraXBVcGRhdGUgPSBmYWxzZSkge1xuICAgIGlmICh0aGlzLnBhcmVudCkge1xuICAgICAgdGhpcy5wYXJlbnQudG9HbG9iYWwodGhpcy5fcG9zaXRpb24sIHBvaW50LCBza2lwVXBkYXRlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcG9pbnQueCA9IHRoaXMuX3Bvc2l0aW9uLng7XG4gICAgICBwb2ludC55ID0gdGhpcy5fcG9zaXRpb24ueTtcbiAgICB9XG4gICAgcmV0dXJuIHBvaW50O1xuICB9LFxuICB0b0dsb2JhbChwb3NpdGlvbiwgcG9pbnQsIHNraXBVcGRhdGUgPSBmYWxzZSkge1xuICAgIGNvbnN0IGdsb2JhbE1hdHJpeCA9IHRoaXMuZ2V0R2xvYmFsVHJhbnNmb3JtKG1hdHJpeFBvb2wuZ2V0KCksIHNraXBVcGRhdGUpO1xuICAgIHBvaW50ID0gZ2xvYmFsTWF0cml4LmFwcGx5KHBvc2l0aW9uLCBwb2ludCk7XG4gICAgbWF0cml4UG9vbC5yZXR1cm4oZ2xvYmFsTWF0cml4KTtcbiAgICByZXR1cm4gcG9pbnQ7XG4gIH0sXG4gIHRvTG9jYWwocG9zaXRpb24sIGZyb20sIHBvaW50LCBza2lwVXBkYXRlKSB7XG4gICAgaWYgKGZyb20pIHtcbiAgICAgIHBvc2l0aW9uID0gZnJvbS50b0dsb2JhbChwb3NpdGlvbiwgcG9pbnQsIHNraXBVcGRhdGUpO1xuICAgIH1cbiAgICBjb25zdCBnbG9iYWxNYXRyaXggPSB0aGlzLmdldEdsb2JhbFRyYW5zZm9ybShtYXRyaXhQb29sLmdldCgpLCBza2lwVXBkYXRlKTtcbiAgICBwb2ludCA9IGdsb2JhbE1hdHJpeC5hcHBseUludmVyc2UocG9zaXRpb24sIHBvaW50KTtcbiAgICBtYXRyaXhQb29sLnJldHVybihnbG9iYWxNYXRyaXgpO1xuICAgIHJldHVybiBwb2ludDtcbiAgfVxufTtcblxuZXhwb3J0IHsgdG9Mb2NhbEdsb2JhbE1peGluIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD10b0xvY2FsR2xvYmFsTWl4aW4ubWpzLm1hcFxuIiwiaW1wb3J0IHsgbmV4dFBvdzIsIGlzUG93MiB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL21pc2MvcG93Mi5tanMnO1xuaW1wb3J0IHsgZGVwcmVjYXRpb24sIHY4XzIxXzAgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9sb2dnaW5nL2RlcHJlY2F0aW9uLm1qcyc7XG5pbXBvcnQgeyB3YXJuIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy93YXJuLm1qcyc7XG5pbXBvcnQgeyBHbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5IH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvcG9vbC9HbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5Lm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlU291cmNlIH0gZnJvbSAnLi9zb3VyY2VzL1RleHR1cmVTb3VyY2UubWpzJztcbmltcG9ydCB7IFRleHR1cmUgfSBmcm9tICcuL1RleHR1cmUubWpzJztcbmltcG9ydCB7IFRleHR1cmVTdHlsZSB9IGZyb20gJy4vVGV4dHVyZVN0eWxlLm1qcyc7XG5pbXBvcnQgeyBTY3JlZW5TaXplUmVnaXN0cnkgfSBmcm9tICcuL3V0aWxzL1NjcmVlblNpemVSZWdpc3RyeS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmxldCBjb3VudCA9IDA7XG5jb25zdCBtYXhLZXlEaW1lbnNpb24gPSAzMjc2NztcbmNvbnN0IHNjYWxlQml0ID0gNDI5NDk2NzI5NjtcbmNvbnN0IGZvcm1hdEJpdCA9IDg1ODk5MzQ1OTI7XG5jb25zdCBmb3JtYXRJZHMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbmxldCBuZXh0Rm9ybWF0SWQgPSAwO1xuZnVuY3Rpb24gZm9ybWF0SWQoZm9ybWF0KSB7XG4gIGNvbnN0IGlkID0gZm9ybWF0SWRzW2Zvcm1hdF07XG4gIGlmIChpZCAhPT0gdm9pZCAwKSByZXR1cm4gaWQ7XG4gIHJldHVybiBmb3JtYXRJZHNbZm9ybWF0XSA9IG5leHRGb3JtYXRJZCsrO1xufVxuZnVuY3Rpb24gYnVja2V0S2V5KHdpZHRoLCBoZWlnaHQsIGFudGlhbGlhcywgYXV0b0dlbmVyYXRlTWlwbWFwcywgZm9ybWF0LCBzY2FsZU1vZGUpIHtcbiAgY29uc3QgcGFja2VkID0gKHdpZHRoIDw8IDE3KSArIChoZWlnaHQgPDwgMikgKyAoKGF1dG9HZW5lcmF0ZU1pcG1hcHMgPyAxIDogMCkgPDwgMSkgKyAoYW50aWFsaWFzID8gMSA6IDApO1xuICBjb25zdCBzY2FsZSA9IHNjYWxlTW9kZSA9PT0gXCJuZWFyZXN0XCIgPyAxIDogMDtcbiAgcmV0dXJuIHBhY2tlZCArIHNjYWxlICogc2NhbGVCaXQgKyBmb3JtYXRJZChmb3JtYXQpICogZm9ybWF0Qml0O1xufVxuY2xhc3MgVGV4dHVyZVBvb2xDbGFzcyB7XG4gIC8qKlxuICAgKiBAcGFyYW0gdGV4dHVyZU9wdGlvbnMgLSBvcHRpb25zIHRoYXQgd2lsbCBiZSBwYXNzZWQgdG8gQmFzZVJlbmRlclRleHR1cmUgY29uc3RydWN0b3JcbiAgICogQHBhcmFtIHtTQ0FMRV9NT0RFfSBbdGV4dHVyZU9wdGlvbnMuc2NhbGVNb2RlXSAtIFNlZSB7QGxpbmsgU0NBTEVfTU9ERX0gZm9yIHBvc3NpYmxlIHZhbHVlcy5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHRleHR1cmVPcHRpb25zKSB7XG4gICAgLyoqIGlkbGUgdGV4dHVyZXMsIGtleWVkIGJ5IGZvcm1hdCwgc2NhbGUgbW9kZSwgc2l6ZSBhbmQgZmxhZ3MgKi9cbiAgICB0aGlzLl9idWNrZXRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICAvKiogdGhlIGJ1Y2tldCBrZXkgb2YgZXZlcnkgdGV4dHVyZSBoYW5kZWQgb3V0LCBieSB0ZXh0dXJlIHVpZCAqL1xuICAgIHRoaXMuX3Bvb2xLZXkgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAvKiogdGhlIHN0eWxlIHRoZSBwb29sIGNyZWF0ZWQgZm9yIGV2ZXJ5IHRleHR1cmUgaGFuZGVkIG91dCwgYnkgdGV4dHVyZSB1aWQgKi9cbiAgICB0aGlzLl9wb29sU3R5bGUgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAvKiogdGhlIHNjcmVlbnMgdGhpcyBwb29sIGlzIHNpemluZyBpdHMgdGV4dHVyZXMgZm9yICovXG4gICAgdGhpcy5fc2NyZWVucyA9IG5ldyBTY3JlZW5TaXplUmVnaXN0cnkoKTtcbiAgICB0aGlzLl9lbmFibGVGdWxsU2NyZWVuID0gZmFsc2U7XG4gICAgdGhpcy50ZXh0dXJlT3B0aW9ucyA9IHRleHR1cmVPcHRpb25zIHx8IHt9O1xuICB9XG4gIC8qKlxuICAgKiBBIHN0eWxlIGJ1aWx0IGZyb20gdGhlIHBvb2wgb3B0aW9ucy4gVGhlIHBvb2wgbm8gbG9uZ2VyIGFwcGxpZXMgaXQgdG8gYW55dGhpbmcuXG4gICAqIEBkZXByZWNhdGVkIHNpbmNlIDguMjEuMCwgcG9vbGVkIHRleHR1cmVzIGNhcnJ5IHRoZWlyIG93biBzdHlsZTsgcGFzcyBgc2NhbGVNb2RlYCBpbiB0aGUgcmVxdWVzdCBpbnN0ZWFkLlxuICAgKi9cbiAgZ2V0IHRleHR1cmVTdHlsZSgpIHtcbiAgICBkZXByZWNhdGlvbih2OF8yMV8wLCBcIlRleHR1cmVQb29sLnRleHR1cmVTdHlsZSBpcyBubyBsb25nZXIgdXNlZCwgcG9vbGVkIHRleHR1cmVzIGNhcnJ5IHRoZWlyIG93biBzdHlsZS4gUGFzcyBzY2FsZU1vZGUgaW4gdGhlIHJlcXVlc3QgaW5zdGVhZC5cIik7XG4gICAgaWYgKCF0aGlzLl90ZXh0dXJlU3R5bGUpIHRoaXMuX3RleHR1cmVTdHlsZSA9IG5ldyBUZXh0dXJlU3R5bGUodGhpcy50ZXh0dXJlT3B0aW9ucyk7XG4gICAgcmV0dXJuIHRoaXMuX3RleHR1cmVTdHlsZTtcbiAgfVxuICBzZXQgdGV4dHVyZVN0eWxlKHZhbHVlKSB7XG4gICAgZGVwcmVjYXRpb24odjhfMjFfMCwgXCJUZXh0dXJlUG9vbC50ZXh0dXJlU3R5bGUgaXMgbm8gbG9uZ2VyIHVzZWQsIHBvb2xlZCB0ZXh0dXJlcyBjYXJyeSB0aGVpciBvd24gc3R5bGUuIFBhc3Mgc2NhbGVNb2RlIGluIHRoZSByZXF1ZXN0IGluc3RlYWQuXCIpO1xuICAgIHRoaXMuX3RleHR1cmVTdHlsZSA9IHZhbHVlO1xuICB9XG4gIC8qKlxuICAgKiBIYXMgbm8gZWZmZWN0LiBUaGUgcG9vbCBzaXplcyB0ZXh0dXJlcyB0byB0aGUgc2NyZWVucyByZWdpc3RlcmVkIHdpdGhcbiAgICoge0BsaW5rIFRleHR1cmVQb29sQ2xhc3Mjc2V0U2NyZWVuU2l6ZXxzZXRTY3JlZW5TaXplfS5cbiAgICogQGRlcHJlY2F0ZWQgc2luY2UgOC4yMS4wXG4gICAqL1xuICBnZXQgZW5hYmxlRnVsbFNjcmVlbigpIHtcbiAgICBkZXByZWNhdGlvbih2OF8yMV8wLCBcIlRleHR1cmVQb29sLmVuYWJsZUZ1bGxTY3JlZW4gaXMgbm8gbG9uZ2VyIHVzZWQsIHRoZSBwb29sIHNpemVzIHRleHR1cmVzIHRvIHRoZSBzY3JlZW5zIHJlZ2lzdGVyZWQgd2l0aCBzZXRTY3JlZW5TaXplLlwiKTtcbiAgICByZXR1cm4gdGhpcy5fZW5hYmxlRnVsbFNjcmVlbjtcbiAgfVxuICBzZXQgZW5hYmxlRnVsbFNjcmVlbih2YWx1ZSkge1xuICAgIGRlcHJlY2F0aW9uKHY4XzIxXzAsIFwiVGV4dHVyZVBvb2wuZW5hYmxlRnVsbFNjcmVlbiBpcyBubyBsb25nZXIgdXNlZCwgdGhlIHBvb2wgc2l6ZXMgdGV4dHVyZXMgdG8gdGhlIHNjcmVlbnMgcmVnaXN0ZXJlZCB3aXRoIHNldFNjcmVlblNpemUuXCIpO1xuICAgIHRoaXMuX2VuYWJsZUZ1bGxTY3JlZW4gPSB2YWx1ZTtcbiAgfVxuICBjcmVhdGVUZXh0dXJlKC4uLmFyZ3MpIHtcbiAgICBsZXQgb3B0aW9ucyA9IGFyZ3NbMF07XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zID09PSBcIm51bWJlclwiKSB7XG4gICAgICBkZXByZWNhdGlvbih2OF8yMV8wLCBcIlRleHR1cmVQb29sLmNyZWF0ZVRleHR1cmUgcGFyYW1zIGFyZSBub3cgYW4gb3B0aW9ucyBvYmplY3QuIFNlZSBwYXJhbXM6IHsgd2lkdGgsIGhlaWdodCwgYW50aWFsaWFzLCBhdXRvR2VuZXJhdGVNaXBtYXBzIH1cIik7XG4gICAgICBvcHRpb25zID0ge1xuICAgICAgICB3aWR0aDogb3B0aW9ucyxcbiAgICAgICAgaGVpZ2h0OiBhcmdzWzFdLFxuICAgICAgICBhbnRpYWxpYXM6IGFyZ3NbMl0gPz8gZmFsc2UsXG4gICAgICAgIGF1dG9HZW5lcmF0ZU1pcG1hcHM6IGFyZ3NbM10gPz8gZmFsc2VcbiAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0IGZvcm1hdCA9IG9wdGlvbnMuZm9ybWF0ID8/IHRoaXMudGV4dHVyZU9wdGlvbnMuZm9ybWF0ID8/IFRleHR1cmVTb3VyY2UuZGVmYXVsdE9wdGlvbnMuZm9ybWF0O1xuICAgIGNvbnN0IHNjYWxlTW9kZSA9IG9wdGlvbnMuc2NhbGVNb2RlID8/IHRoaXMudGV4dHVyZU9wdGlvbnMuc2NhbGVNb2RlID8/IFRleHR1cmVTdHlsZS5kZWZhdWx0T3B0aW9ucy5zY2FsZU1vZGU7XG4gICAgY29uc3QgdGV4dHVyZVNvdXJjZSA9IG5ldyBUZXh0dXJlU291cmNlKHtcbiAgICAgIC4uLnRoaXMudGV4dHVyZU9wdGlvbnMsXG4gICAgICB3aWR0aDogb3B0aW9ucy53aWR0aCxcbiAgICAgIGhlaWdodDogb3B0aW9ucy5oZWlnaHQsXG4gICAgICByZXNvbHV0aW9uOiAxLFxuICAgICAgYW50aWFsaWFzOiBvcHRpb25zLmFudGlhbGlhcyA/PyBmYWxzZSxcbiAgICAgIGF1dG9HYXJiYWdlQ29sbGVjdDogZmFsc2UsXG4gICAgICBhdXRvR2VuZXJhdGVNaXBtYXBzOiBvcHRpb25zLmF1dG9HZW5lcmF0ZU1pcG1hcHMgPz8gZmFsc2UsXG4gICAgICBmb3JtYXQsXG4gICAgICBzY2FsZU1vZGVcbiAgICB9KTtcbiAgICByZXR1cm4gbmV3IFRleHR1cmUoe1xuICAgICAgc291cmNlOiB0ZXh0dXJlU291cmNlLFxuICAgICAgbGFiZWw6IGB0ZXh0dXJlUG9vbF8ke2NvdW50Kyt9YFxuICAgIH0pO1xuICB9XG4gIGdldE9wdGltYWxUZXh0dXJlKC4uLmFyZ3MpIHtcbiAgICBsZXQgb3B0aW9ucyA9IGFyZ3NbMF07XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zID09PSBcIm51bWJlclwiKSB7XG4gICAgICBkZXByZWNhdGlvbih2OF8yMV8wLCBcIlRleHR1cmVQb29sLmdldE9wdGltYWxUZXh0dXJlIHBhcmFtcyBhcmUgbm93IGFuIG9wdGlvbnMgb2JqZWN0LiBTZWUgcGFyYW1zOiB7IHdpZHRoLCBoZWlnaHQsIHJlc29sdXRpb24sIGFudGlhbGlhcywgYXV0b0dlbmVyYXRlTWlwbWFwcyB9XCIpO1xuICAgICAgb3B0aW9ucyA9IHtcbiAgICAgICAgd2lkdGg6IG9wdGlvbnMsXG4gICAgICAgIGhlaWdodDogYXJnc1sxXSxcbiAgICAgICAgcmVzb2x1dGlvbjogYXJnc1syXSA/PyAxLFxuICAgICAgICBhbnRpYWxpYXM6IGFyZ3NbM10gPz8gZmFsc2UsXG4gICAgICAgIGF1dG9HZW5lcmF0ZU1pcG1hcHM6IGFyZ3NbNF0gPz8gZmFsc2VcbiAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0IGZyYW1lV2lkdGggPSBvcHRpb25zLndpZHRoO1xuICAgIGNvbnN0IGZyYW1lSGVpZ2h0ID0gb3B0aW9ucy5oZWlnaHQ7XG4gICAgY29uc3QgcmVzb2x1dGlvbiA9IG9wdGlvbnMucmVzb2x1dGlvbiA/PyAxO1xuICAgIGNvbnN0IGFudGlhbGlhcyA9IG9wdGlvbnMuYW50aWFsaWFzID8/IGZhbHNlO1xuICAgIGNvbnN0IGF1dG9HZW5lcmF0ZU1pcG1hcHMgPSBvcHRpb25zLmF1dG9HZW5lcmF0ZU1pcG1hcHMgPz8gZmFsc2U7XG4gICAgY29uc3QgZm9ybWF0ID0gb3B0aW9ucy5mb3JtYXQgPz8gdGhpcy50ZXh0dXJlT3B0aW9ucy5mb3JtYXQgPz8gVGV4dHVyZVNvdXJjZS5kZWZhdWx0T3B0aW9ucy5mb3JtYXQ7XG4gICAgY29uc3Qgc2NhbGVNb2RlID0gb3B0aW9ucy5zY2FsZU1vZGUgPz8gdGhpcy50ZXh0dXJlT3B0aW9ucy5zY2FsZU1vZGUgPz8gVGV4dHVyZVN0eWxlLmRlZmF1bHRPcHRpb25zLnNjYWxlTW9kZTtcbiAgICBjb25zdCB7IHdpZHRoOiB0ZXh0dXJlV2lkdGgsIGhlaWdodDogdGV4dHVyZUhlaWdodCB9ID0gdGhpcy5nZXRPcHRpbWFsU2l6ZShcbiAgICAgIGZyYW1lV2lkdGgsXG4gICAgICBmcmFtZUhlaWdodCxcbiAgICAgIHJlc29sdXRpb25cbiAgICApO1xuICAgIGlmICh0ZXh0dXJlV2lkdGggPiBtYXhLZXlEaW1lbnNpb24gfHwgdGV4dHVyZUhlaWdodCA+IG1heEtleURpbWVuc2lvbikge1xuICAgICAgd2FybihgVGV4dHVyZVBvb2w6ICR7dGV4dHVyZVdpZHRofXgke3RleHR1cmVIZWlnaHR9IGlzIGxhcmdlciB0aGFuIHRoZSAke21heEtleURpbWVuc2lvbn1weCBwb29sIGtleSBsaW1pdCwgdGV4dHVyZXMgb2YgdGhpcyBzaXplIG1heSBiZSBwb29sZWQgdG9nZXRoZXJgKTtcbiAgICB9XG4gICAgY29uc3Qga2V5ID0gYnVja2V0S2V5KHRleHR1cmVXaWR0aCwgdGV4dHVyZUhlaWdodCwgYW50aWFsaWFzLCBhdXRvR2VuZXJhdGVNaXBtYXBzLCBmb3JtYXQsIHNjYWxlTW9kZSk7XG4gICAgbGV0IGJ1Y2tldCA9IHRoaXMuX2J1Y2tldHMuZ2V0KGtleSk7XG4gICAgaWYgKCFidWNrZXQpIHtcbiAgICAgIGJ1Y2tldCA9IFtdO1xuICAgICAgdGhpcy5fYnVja2V0cy5zZXQoa2V5LCBidWNrZXQpO1xuICAgIH1cbiAgICBsZXQgdGV4dHVyZSA9IGJ1Y2tldC5wb3AoKTtcbiAgICBpZiAoIXRleHR1cmUpIHtcbiAgICAgIHRleHR1cmUgPSB0aGlzLmNyZWF0ZVRleHR1cmUoe1xuICAgICAgICB3aWR0aDogdGV4dHVyZVdpZHRoLFxuICAgICAgICBoZWlnaHQ6IHRleHR1cmVIZWlnaHQsXG4gICAgICAgIGFudGlhbGlhcyxcbiAgICAgICAgYXV0b0dlbmVyYXRlTWlwbWFwcyxcbiAgICAgICAgZm9ybWF0LFxuICAgICAgICBzY2FsZU1vZGVcbiAgICAgIH0pO1xuICAgICAgdGhpcy5fcG9vbFN0eWxlW3RleHR1cmUudWlkXSA9IHRleHR1cmUuc291cmNlLnN0eWxlO1xuICAgIH1cbiAgICB0ZXh0dXJlLnNvdXJjZS5fcmVzb2x1dGlvbiA9IHJlc29sdXRpb247XG4gICAgdGV4dHVyZS5zb3VyY2Uud2lkdGggPSB0ZXh0dXJlV2lkdGggLyByZXNvbHV0aW9uO1xuICAgIHRleHR1cmUuc291cmNlLmhlaWdodCA9IHRleHR1cmVIZWlnaHQgLyByZXNvbHV0aW9uO1xuICAgIHRleHR1cmUuc291cmNlLnBpeGVsV2lkdGggPSB0ZXh0dXJlV2lkdGg7XG4gICAgdGV4dHVyZS5zb3VyY2UucGl4ZWxIZWlnaHQgPSB0ZXh0dXJlSGVpZ2h0O1xuICAgIHRleHR1cmUuZnJhbWUueCA9IDA7XG4gICAgdGV4dHVyZS5mcmFtZS55ID0gMDtcbiAgICB0ZXh0dXJlLmZyYW1lLndpZHRoID0gZnJhbWVXaWR0aDtcbiAgICB0ZXh0dXJlLmZyYW1lLmhlaWdodCA9IGZyYW1lSGVpZ2h0O1xuICAgIHRleHR1cmUudXBkYXRlVXZzKCk7XG4gICAgdGhpcy5fcG9vbEtleVt0ZXh0dXJlLnVpZF0gPSBrZXk7XG4gICAgcmV0dXJuIHRleHR1cmU7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBiYWNraW5nIHNpemUsIGluIHBoeXNpY2FsIHBpeGVscywgdGhhdCB7QGxpbmsgVGV4dHVyZVBvb2xDbGFzcyNnZXRPcHRpbWFsVGV4dHVyZXxnZXRPcHRpbWFsVGV4dHVyZX1cbiAgICogd291bGQgYWxsb2NhdGUgZm9yIGEgcmVxdWVzdCwgd2l0aG91dCB0YWtpbmcgYSB0ZXh0dXJlIGZyb20gdGhlIHBvb2wuXG4gICAqXG4gICAqIEVhY2ggYXhpcyBpcyB0aGUgbmV4dCBwb3dlciBvZiB0d28sIG9yIHRoZSBzbWFsbGVzdCByZWdpc3RlcmVkIHNjcmVlbiB0aGUgcmVxdWVzdCBmaXRzIGluc2lkZVxuICAgKiAoc2VlIHtAbGluayBUZXh0dXJlUG9vbENsYXNzI3NldFNjcmVlblNpemV8c2V0U2NyZWVuU2l6ZX0pLiBVc2UgaXQgd2hlbiBhIGNvbnN1bWVyIG5lZWRzIHRvIGtub3dcbiAgICogd2hlcmUgYSByZXF1ZXN0J3MgY29udGVudCB3aWxsIHNpdCBpbnNpZGUgaXRzIHBvb2xlZCB0ZXh0dXJlIGJlZm9yZSBpdCBoYXMgb25lLCBzdWNoIGFzIGEgdW5pZm9ybVxuICAgKiB0aGF0IG1hcHMgY29udGVudCBzcGFjZSBvbnRvIHRleHR1cmUgc3BhY2UuXG4gICAqIEBwYXJhbSBmcmFtZVdpZHRoIC0gVGhlIG1pbmltdW0gd2lkdGggb2YgdGhlIHRleHR1cmUuXG4gICAqIEBwYXJhbSBmcmFtZUhlaWdodCAtIFRoZSBtaW5pbXVtIGhlaWdodCBvZiB0aGUgdGV4dHVyZS5cbiAgICogQHBhcmFtIHJlc29sdXRpb24gLSBUaGUgcmVzb2x1dGlvbiBvZiB0aGUgdGV4dHVyZS5cbiAgICogQHJldHVybnMgVGhlIHdpZHRoIGFuZCBoZWlnaHQgdGhlIHBvb2xlZCB0ZXh0dXJlIHdvdWxkIGhhdmUsIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICovXG4gIGdldE9wdGltYWxTaXplKGZyYW1lV2lkdGgsIGZyYW1lSGVpZ2h0LCByZXNvbHV0aW9uID0gMSkge1xuICAgIGNvbnN0IHBpeGVsV2lkdGggPSBNYXRoLmNlaWwoZnJhbWVXaWR0aCAqIHJlc29sdXRpb24gLSAxZS02KTtcbiAgICBjb25zdCBwaXhlbEhlaWdodCA9IE1hdGguY2VpbChmcmFtZUhlaWdodCAqIHJlc29sdXRpb24gLSAxZS02KTtcbiAgICBjb25zdCBwbzJXaWR0aCA9IG5leHRQb3cyKHBpeGVsV2lkdGgpO1xuICAgIGNvbnN0IHNjcmVlbldpZHRoID0gdGhpcy5fc2NyZWVucy5nZXRGaXR0aW5nV2lkdGgocGl4ZWxXaWR0aCk7XG4gICAgY29uc3QgcG8ySGVpZ2h0ID0gbmV4dFBvdzIocGl4ZWxIZWlnaHQpO1xuICAgIGNvbnN0IHNjcmVlbkhlaWdodCA9IHRoaXMuX3NjcmVlbnMuZ2V0Rml0dGluZ0hlaWdodChwaXhlbEhlaWdodCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHdpZHRoOiBzY3JlZW5XaWR0aCAhPT0gdm9pZCAwID8gTWF0aC5taW4oc2NyZWVuV2lkdGgsIHBvMldpZHRoKSA6IHBvMldpZHRoLFxuICAgICAgaGVpZ2h0OiBzY3JlZW5IZWlnaHQgIT09IHZvaWQgMCA/IE1hdGgubWluKHNjcmVlbkhlaWdodCwgcG8ySGVpZ2h0KSA6IHBvMkhlaWdodFxuICAgIH07XG4gIH1cbiAgLyoqXG4gICAqIEdldHMgYSBwb29sZWQgdGV4dHVyZSBtYXRjaGluZyB0aGUgZGltZW5zaW9ucyBhbmQgcmVzb2x1dGlvbiBvZiB0aGUgZ2l2ZW4gdGV4dHVyZS5cbiAgICpcbiAgICogVGhpcyBpcyBhIGNvbnZlbmllbmNlIHdyYXBwZXIgYXJvdW5kIHtAbGluayBUZXh0dXJlUG9vbENsYXNzI2dldE9wdGltYWxUZXh0dXJlfGdldE9wdGltYWxUZXh0dXJlfVxuICAgKiB0aGF0IGNvcGllcyB3aWR0aCwgaGVpZ2h0LCBhbmQgcmVzb2x1dGlvbiBmcm9tIGFuIGV4aXN0aW5nIHRleHR1cmUuIFVzZWZ1bCB3aGVuIGEgZmlsdGVyIG5lZWRzXG4gICAqIGEgdGVtcG9yYXJ5IHRleHR1cmUgdGhlIHNhbWUgc2l6ZSBhcyBpdHMgaW5wdXQgKGUuZy4sIGZvciBtdWx0aS1wYXNzIGJsdXIpLlxuICAgKiBAcGFyYW0gdGV4dHVyZSAtIFRoZSB0ZXh0dXJlIHdob3NlIGRpbWVuc2lvbnMgdG8gbWF0Y2guXG4gICAqIEBwYXJhbSBhbnRpYWxpYXMgLSBXaGV0aGVyIHRvIHVzZSBhbnRpYWxpYXMgb24gdGhlIHBvb2xlZCB0ZXh0dXJlLiBEZWZhdWx0cyB0byBgZmFsc2VgLlxuICAgKiBAcmV0dXJucyBBIHBvb2xlZCB0ZXh0dXJlIHdpdGggcG93ZXItb2YtdHdvIG9yIHNjcmVlbiBzaXplZCBiYWNraW5nIGRpbWVuc2lvbnMgYXQgdGhlIHNvdXJjZSByZXNvbHV0aW9uLlxuICAgKi9cbiAgZ2V0U2FtZVNpemVUZXh0dXJlKHRleHR1cmUsIGFudGlhbGlhcyA9IGZhbHNlKSB7XG4gICAgY29uc3Qgc291cmNlID0gdGV4dHVyZS5zb3VyY2U7XG4gICAgcmV0dXJuIHRoaXMuZ2V0T3B0aW1hbFRleHR1cmUoe1xuICAgICAgd2lkdGg6IHRleHR1cmUud2lkdGgsXG4gICAgICBoZWlnaHQ6IHRleHR1cmUuaGVpZ2h0LFxuICAgICAgcmVzb2x1dGlvbjogc291cmNlLl9yZXNvbHV0aW9uLFxuICAgICAgYW50aWFsaWFzXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgYSB0ZXh0dXJlIHRvIHRoZSBwb29sIHNvIGl0IGNhbiBiZSByZXVzZWQgYnkgZnV0dXJlXG4gICAqIHtAbGluayBUZXh0dXJlUG9vbENsYXNzI2dldE9wdGltYWxUZXh0dXJlfGdldE9wdGltYWxUZXh0dXJlfVxuICAgKiBvciB7QGxpbmsgVGV4dHVyZVBvb2xDbGFzcyNnZXRTYW1lU2l6ZVRleHR1cmV8Z2V0U2FtZVNpemVUZXh0dXJlfSBjYWxscy5cbiAgICpcbiAgICogSWYgeW91IGdhdmUgdGhlIHRleHR1cmUgYSBzdHlsZSBvZiB5b3VyIG93biBhZnRlciBvYnRhaW5pbmcgaXQgKGEgZGlmZmVyZW50IGFkZHJlc3MgbW9kZSwgYW5pc290cm9weVxuICAgKiBvciBzaW1pbGFyKSwgcGFzcyBgcmVzZXRTdHlsZSA9IHRydWVgIHNvIHRoZSBwb29sIHB1dHMgaXRzIG93biBzdHlsZSBiYWNrLiBPdGhlcndpc2UgeW91ciBzdHlsZSBzdGF5c1xuICAgKiBvbiB0aGUgdGV4dHVyZSBhbmQgdGhlIG5leHQgY29uc3VtZXIgaW5oZXJpdHMgaXQuXG4gICAqIEBwYXJhbSByZW5kZXJUZXh0dXJlIC0gVGhlIHRleHR1cmUgdG8gcmV0dXJuIHRvIHRoZSBwb29sLlxuICAgKiBAcGFyYW0gcmVzZXRTdHlsZSAtIFdoZW4gYHRydWVgLCByZXN0b3JlcyB0aGUgc3R5bGUgdGhlIHBvb2wgY3JlYXRlZCBmb3IgdGhpcyB0ZXh0dXJlLiBEZWZhdWx0cyB0byBgZmFsc2VgLlxuICAgKi9cbiAgcmV0dXJuVGV4dHVyZShyZW5kZXJUZXh0dXJlLCByZXNldFN0eWxlID0gZmFsc2UpIHtcbiAgICBjb25zdCB1aWQgPSByZW5kZXJUZXh0dXJlLnVpZDtcbiAgICBjb25zdCBrZXkgPSB0aGlzLl9wb29sS2V5W3VpZF07XG4gICAgaWYgKGtleSA9PT0gdm9pZCAwKSB7XG4gICAgICB3YXJuKFwiVGV4dHVyZVBvb2w6IHJldHVyblRleHR1cmUgd2FzIHBhc3NlZCBhIHRleHR1cmUgdGhhdCBkaWQgbm90IGNvbWUgZnJvbSB0aGlzIHBvb2wsIGlnbm9yaW5nIGl0XCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBwb29sU3R5bGUgPSB0aGlzLl9wb29sU3R5bGVbdWlkXTtcbiAgICBpZiAocmVzZXRTdHlsZSAmJiByZW5kZXJUZXh0dXJlLnNvdXJjZS5zdHlsZSAhPT0gcG9vbFN0eWxlKSB7XG4gICAgICByZW5kZXJUZXh0dXJlLnNvdXJjZS5zdHlsZSA9IHBvb2xTdHlsZTtcbiAgICB9XG4gICAgY29uc3QgdGV4dHVyZXMgPSB0aGlzLl9idWNrZXRzLmdldChrZXkpO1xuICAgIGlmICghdGV4dHVyZXMpIHtcbiAgICAgIGRlbGV0ZSB0aGlzLl9wb29sS2V5W3VpZF07XG4gICAgICBkZWxldGUgdGhpcy5fcG9vbFN0eWxlW3VpZF07XG4gICAgICByZW5kZXJUZXh0dXJlLmRlc3Ryb3kodHJ1ZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRleHR1cmVzLnB1c2gocmVuZGVyVGV4dHVyZSk7XG4gIH1cbiAgLyoqXG4gICAqIFJlZ2lzdGVycyB0aGUgc2NyZWVuIHNpemUgb2YgYSByZW5kZXJlciB3aXRoIHRoZSBwb29sLCBpbiBwaHlzaWNhbCBwaXhlbHMuXG4gICAqXG4gICAqIFdoaWxlIGEgc2NyZWVuIGlzIHJlZ2lzdGVyZWQsIGEgcmVxdWVzdCB0aGF0IGZpdHMgaW5zaWRlIGl0IG9uIGFuIGF4aXMgaXMgZ2l2ZW4gdGhhdCBzY3JlZW4ncyBzaXplIG9uXG4gICAqIHRoYXQgYXhpcyBpbnN0ZWFkIG9mIHRoZSBuZXh0IHBvd2VyIG9mIHR3bywgd2hpY2ggc3RvcHMgYSBmdWxsIHNjcmVlbiBmaWx0ZXIgZnJvbSBhbGxvY2F0aW5nIGEgdGV4dHVyZVxuICAgKiBmYXIgbGFyZ2VyIHRoYW4gdGhlIHNjcmVlbi4gUmVxdWVzdHMgbGFyZ2VyIHRoYW4gZXZlcnkgcmVnaXN0ZXJlZCBzY3JlZW4gb24gYW4gYXhpcyBrZWVwIHRoZSBwb3dlciBvZlxuICAgKiB0d28gc2l6ZSAtIHRoZSBwb29sIG5ldmVyIHJvdW5kcyBhIHJlcXVlc3QgdXAgdG8gYSBzY3JlZW4gaXQgZG9lcyBub3QgZml0IGluLlxuICAgKiBAcGFyYW0gcmVuZGVyZXJVaWQgLSBUaGUgdWlkIG9mIHRoZSByZW5kZXJlciwgdXNlZCB0byB1cGRhdGUgb3IgcmVtb3ZlIHRoaXMgc2NyZWVuIGxhdGVyLlxuICAgKiBAcGFyYW0gcGl4ZWxXaWR0aCAtIFRoZSB3aWR0aCBvZiB0aGUgc2NyZWVuIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICogQHBhcmFtIHBpeGVsSGVpZ2h0IC0gVGhlIGhlaWdodCBvZiB0aGUgc2NyZWVuIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICovXG4gIHNldFNjcmVlblNpemUocmVuZGVyZXJVaWQsIHBpeGVsV2lkdGgsIHBpeGVsSGVpZ2h0KSB7XG4gICAgaWYgKCF0aGlzLl9zY3JlZW5zLnNldChyZW5kZXJlclVpZCwgcGl4ZWxXaWR0aCwgcGl4ZWxIZWlnaHQpKSByZXR1cm47XG4gICAgdGhpcy5fcHJ1bmVTY3JlZW5UZXh0dXJlcygpO1xuICB9XG4gIC8qKlxuICAgKiBSZW1vdmVzIGEgc2NyZWVuIHByZXZpb3VzbHkgcmVnaXN0ZXJlZCB3aXRoXG4gICAqIHtAbGluayBUZXh0dXJlUG9vbENsYXNzI3NldFNjcmVlblNpemV8c2V0U2NyZWVuU2l6ZX0sIGRlc3Ryb3lpbmcgYW55IGlkbGUgdGV4dHVyZXMgdGhhdCB3ZXJlXG4gICAqIG9ubHkgYmVpbmcga2VwdCBmb3IgaXQuXG4gICAqIEBwYXJhbSByZW5kZXJlclVpZCAtIFRoZSB1aWQgdGhlIHNjcmVlbiB3YXMgcmVnaXN0ZXJlZCB3aXRoLlxuICAgKi9cbiAgcmVtb3ZlU2NyZWVuKHJlbmRlcmVyVWlkKSB7XG4gICAgaWYgKCF0aGlzLl9zY3JlZW5zLnJlbW92ZShyZW5kZXJlclVpZCkpIHJldHVybjtcbiAgICB0aGlzLl9wcnVuZVNjcmVlblRleHR1cmVzKCk7XG4gIH1cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoZSBpZGxlIHRleHR1cmVzIGluIGV2ZXJ5IGJ1Y2tldCB0aGF0IGhhcyBhIG5vbiBwb3dlciBvZiB0d28gZGltZW5zaW9uIG1hdGNoaW5nIG5vIGxpdmVcbiAgICogc2NyZWVuLiBQb3dlciBvZiB0d28gYnVja2V0cyBhcmUgYWx3YXlzIGtlcHQsIGFzIGFueSByZXF1ZXN0IGNhbiBmYWxsIGJhY2sgdG8gdGhlbS5cbiAgICovXG4gIF9wcnVuZVNjcmVlblRleHR1cmVzKCkge1xuICAgIGZvciAoY29uc3QgW2tleSwgdGV4dHVyZXNdIG9mIHRoaXMuX2J1Y2tldHMpIHtcbiAgICAgIGNvbnN0IHBhY2tlZCA9IGtleSA+Pj4gMDtcbiAgICAgIGNvbnN0IHdpZHRoID0gcGFja2VkID4+PiAxNztcbiAgICAgIGNvbnN0IGhlaWdodCA9IHBhY2tlZCA+Pj4gMiAmIDMyNzY3O1xuICAgICAgaWYgKChpc1BvdzIod2lkdGgpIHx8IHRoaXMuX3NjcmVlbnMuaGFzV2lkdGgod2lkdGgpKSAmJiAoaXNQb3cyKGhlaWdodCkgfHwgdGhpcy5fc2NyZWVucy5oYXNIZWlnaHQoaGVpZ2h0KSkpIGNvbnRpbnVlO1xuICAgICAgdGhpcy5fZHJvcFRleHR1cmVzKHRleHR1cmVzLCB0cnVlKTtcbiAgICAgIHRoaXMuX2J1Y2tldHMuZGVsZXRlKGtleSk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBGb3JnZXRzIGlkbGUgdGV4dHVyZXMgd2VyZSBldmVyIGhhbmRlZCBvdXQsIHNvIGEgbGF0ZXIgcmV0dXJuIGlzIGlnbm9yZWQsIGFuZCBvcHRpb25hbGx5IGRlc3Ryb3lzIHRoZW0uXG4gICAqIEBwYXJhbSB0ZXh0dXJlcyAtIFRoZSB0ZXh0dXJlcyBvZiBvbmUgYnVja2V0LlxuICAgKiBAcGFyYW0gZGVzdHJveSAtIFdoZXRoZXIgdG8gZGVzdHJveSB0aGUgdGV4dHVyZXMgYXMgd2VsbC5cbiAgICovXG4gIF9kcm9wVGV4dHVyZXModGV4dHVyZXMsIGRlc3Ryb3kpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRleHR1cmVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCB0ZXh0dXJlID0gdGV4dHVyZXNbaV07XG4gICAgICBkZWxldGUgdGhpcy5fcG9vbEtleVt0ZXh0dXJlLnVpZF07XG4gICAgICBkZWxldGUgdGhpcy5fcG9vbFN0eWxlW3RleHR1cmUudWlkXTtcbiAgICAgIGlmIChkZXN0cm95KSB0ZXh0dXJlLmRlc3Ryb3kodHJ1ZSk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBDbGVhcnMgdGhlIHBvb2wuXG4gICAqIEBwYXJhbSBkZXN0cm95VGV4dHVyZXMgLSBEZXN0cm95IGFsbCBzdG9yZWQgdGV4dHVyZXMuXG4gICAqL1xuICBjbGVhcihkZXN0cm95VGV4dHVyZXMpIHtcbiAgICBmb3IgKGNvbnN0IHRleHR1cmVzIG9mIHRoaXMuX2J1Y2tldHMudmFsdWVzKCkpIHtcbiAgICAgIHRoaXMuX2Ryb3BUZXh0dXJlcyh0ZXh0dXJlcywgZGVzdHJveVRleHR1cmVzICE9PSBmYWxzZSk7XG4gICAgfVxuICAgIHRoaXMuX2J1Y2tldHMuY2xlYXIoKTtcbiAgfVxufVxuY29uc3QgVGV4dHVyZVBvb2wgPSBuZXcgVGV4dHVyZVBvb2xDbGFzcygpO1xuR2xvYmFsUmVzb3VyY2VSZWdpc3RyeS5yZWdpc3RlcihUZXh0dXJlUG9vbCk7XG5cbmV4cG9ydCB7IFRleHR1cmVQb29sLCBUZXh0dXJlUG9vbENsYXNzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1UZXh0dXJlUG9vbC5tanMubWFwXG4iLCJpbXBvcnQgeyBNYXRyaXggfSBmcm9tICcuLi8uLi9tYXRocy9tYXRyaXgvTWF0cml4Lm1qcyc7XG5pbXBvcnQgeyBJbnN0cnVjdGlvblNldCB9IGZyb20gJy4uLy4uL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL2luc3RydWN0aW9ucy9JbnN0cnVjdGlvblNldC5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVBvb2wgfSBmcm9tICcuLi8uLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL1RleHR1cmVQb29sLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgUmVuZGVyR3JvdXAge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnJlbmRlclBpcGVJZCA9IFwicmVuZGVyR3JvdXBcIjtcbiAgICB0aGlzLnJvb3QgPSBudWxsO1xuICAgIHRoaXMuY2FuQnVuZGxlID0gZmFsc2U7XG4gICAgdGhpcy5yZW5kZXJHcm91cFBhcmVudCA9IG51bGw7XG4gICAgdGhpcy5yZW5kZXJHcm91cENoaWxkcmVuID0gW107XG4gICAgdGhpcy53b3JsZFRyYW5zZm9ybSA9IG5ldyBNYXRyaXgoKTtcbiAgICB0aGlzLndvcmxkQ29sb3JBbHBoYSA9IDQyOTQ5NjcyOTU7XG4gICAgdGhpcy53b3JsZENvbG9yID0gMTY3NzcyMTU7XG4gICAgdGhpcy53b3JsZEFscGhhID0gMTtcbiAgICAvLyB0aGVzZSB1cGRhdGVzIGFyZSB0cmFuc2Zvcm0gY2hhbmdlcy4uXG4gICAgdGhpcy5jaGlsZHJlblRvVXBkYXRlID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgdGhpcy51cGRhdGVUaWNrID0gMDtcbiAgICB0aGlzLmdjVGljayA9IDA7XG4gICAgLy8gdGhlc2UgdXBkYXRlIGFyZSByZW5kZXJhYmxlIGNoYW5nZXMuLlxuICAgIHRoaXMuY2hpbGRyZW5SZW5kZXJhYmxlc1RvVXBkYXRlID0geyBsaXN0OiBbXSwgaW5kZXg6IDAgfTtcbiAgICAvLyBvdGhlclxuICAgIHRoaXMuc3RydWN0dXJlRGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICB0aGlzLmluc3RydWN0aW9uU2V0ID0gbmV3IEluc3RydWN0aW9uU2V0KCk7XG4gICAgdGhpcy5fb25SZW5kZXJDb250YWluZXJzID0gW107XG4gICAgLyoqXG4gICAgICogSW5kaWNhdGVzIGlmIHRoZSBjYWNoZWQgdGV4dHVyZSBuZWVkcyB0byBiZSB1cGRhdGVkLlxuICAgICAqIEBkZWZhdWx0IHRydWVcbiAgICAgKi9cbiAgICB0aGlzLnRleHR1cmVOZWVkc1VwZGF0ZSA9IHRydWU7XG4gICAgLyoqXG4gICAgICogSW5kaWNhdGVzIGlmIHRoZSBjb250YWluZXIgc2hvdWxkIGJlIGNhY2hlZCBhcyBhIHRleHR1cmUuXG4gICAgICogQGRlZmF1bHQgZmFsc2VcbiAgICAgKi9cbiAgICB0aGlzLmlzQ2FjaGVkQXNUZXh0dXJlID0gZmFsc2U7XG4gICAgdGhpcy5fbWF0cml4RGlydHkgPSA3O1xuICB9XG4gIGluaXQocm9vdCkge1xuICAgIHRoaXMucm9vdCA9IHJvb3Q7XG4gICAgaWYgKHJvb3QuX29uUmVuZGVyKSB0aGlzLmFkZE9uUmVuZGVyKHJvb3QpO1xuICAgIHJvb3QuZGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICBjb25zdCBjaGlsZHJlbiA9IHJvb3QuY2hpbGRyZW47XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgY2hpbGQgPSBjaGlsZHJlbltpXTtcbiAgICAgIGNoaWxkLl91cGRhdGVGbGFncyA9IDE1O1xuICAgICAgdGhpcy5hZGRDaGlsZChjaGlsZCk7XG4gICAgfVxuICB9XG4gIGVuYWJsZUNhY2hlQXNUZXh0dXJlKG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMudGV4dHVyZU9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMuaXNDYWNoZWRBc1RleHR1cmUgPSB0cnVlO1xuICAgIHRoaXMudGV4dHVyZU5lZWRzVXBkYXRlID0gdHJ1ZTtcbiAgfVxuICBkaXNhYmxlQ2FjaGVBc1RleHR1cmUoKSB7XG4gICAgdGhpcy5pc0NhY2hlZEFzVGV4dHVyZSA9IGZhbHNlO1xuICAgIGlmICh0aGlzLnRleHR1cmUpIHtcbiAgICAgIFRleHR1cmVQb29sLnJldHVyblRleHR1cmUodGhpcy50ZXh0dXJlKTtcbiAgICAgIHRoaXMudGV4dHVyZSA9IG51bGw7XG4gICAgfVxuICB9XG4gIHVwZGF0ZUNhY2hlVGV4dHVyZSgpIHtcbiAgICB0aGlzLnRleHR1cmVOZWVkc1VwZGF0ZSA9IHRydWU7XG4gICAgY29uc3QgY2FjaGVkUGFyZW50ID0gdGhpcy5fcGFyZW50Q2FjaGVBc1RleHR1cmVSZW5kZXJHcm91cDtcbiAgICBpZiAoY2FjaGVkUGFyZW50ICYmICFjYWNoZWRQYXJlbnQudGV4dHVyZU5lZWRzVXBkYXRlKSB7XG4gICAgICBjYWNoZWRQYXJlbnQudXBkYXRlQ2FjaGVUZXh0dXJlKCk7XG4gICAgfVxuICB9XG4gIHJlc2V0KCkge1xuICAgIHRoaXMucmVuZGVyR3JvdXBDaGlsZHJlbi5sZW5ndGggPSAwO1xuICAgIGZvciAoY29uc3QgaSBpbiB0aGlzLmNoaWxkcmVuVG9VcGRhdGUpIHtcbiAgICAgIGNvbnN0IGNoaWxkcmVuQXREZXB0aCA9IHRoaXMuY2hpbGRyZW5Ub1VwZGF0ZVtpXTtcbiAgICAgIGNoaWxkcmVuQXREZXB0aC5saXN0LmZpbGwobnVsbCk7XG4gICAgICBjaGlsZHJlbkF0RGVwdGguaW5kZXggPSAwO1xuICAgIH1cbiAgICB0aGlzLmNoaWxkcmVuUmVuZGVyYWJsZXNUb1VwZGF0ZS5pbmRleCA9IDA7XG4gICAgdGhpcy5jaGlsZHJlblJlbmRlcmFibGVzVG9VcGRhdGUubGlzdC5maWxsKG51bGwpO1xuICAgIHRoaXMucm9vdCA9IG51bGw7XG4gICAgdGhpcy51cGRhdGVUaWNrID0gMDtcbiAgICB0aGlzLnN0cnVjdHVyZURpZENoYW5nZSA9IHRydWU7XG4gICAgdGhpcy5fb25SZW5kZXJDb250YWluZXJzLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5yZW5kZXJHcm91cFBhcmVudCA9IG51bGw7XG4gICAgdGhpcy5kaXNhYmxlQ2FjaGVBc1RleHR1cmUoKTtcbiAgfVxuICBnZXQgbG9jYWxUcmFuc2Zvcm0oKSB7XG4gICAgcmV0dXJuIHRoaXMucm9vdC5sb2NhbFRyYW5zZm9ybTtcbiAgfVxuICBhZGRSZW5kZXJHcm91cENoaWxkKHJlbmRlckdyb3VwQ2hpbGQpIHtcbiAgICBpZiAocmVuZGVyR3JvdXBDaGlsZC5yZW5kZXJHcm91cFBhcmVudCkge1xuICAgICAgcmVuZGVyR3JvdXBDaGlsZC5yZW5kZXJHcm91cFBhcmVudC5fcmVtb3ZlUmVuZGVyR3JvdXBDaGlsZChyZW5kZXJHcm91cENoaWxkKTtcbiAgICB9XG4gICAgcmVuZGVyR3JvdXBDaGlsZC5yZW5kZXJHcm91cFBhcmVudCA9IHRoaXM7XG4gICAgdGhpcy5yZW5kZXJHcm91cENoaWxkcmVuLnB1c2gocmVuZGVyR3JvdXBDaGlsZCk7XG4gIH1cbiAgX3JlbW92ZVJlbmRlckdyb3VwQ2hpbGQocmVuZGVyR3JvdXBDaGlsZCkge1xuICAgIGNvbnN0IGluZGV4ID0gdGhpcy5yZW5kZXJHcm91cENoaWxkcmVuLmluZGV4T2YocmVuZGVyR3JvdXBDaGlsZCk7XG4gICAgaWYgKGluZGV4ID4gLTEpIHtcbiAgICAgIHRoaXMucmVuZGVyR3JvdXBDaGlsZHJlbi5zcGxpY2UoaW5kZXgsIDEpO1xuICAgIH1cbiAgICByZW5kZXJHcm91cENoaWxkLnJlbmRlckdyb3VwUGFyZW50ID0gbnVsbDtcbiAgfVxuICBhZGRDaGlsZChjaGlsZCkge1xuICAgIHRoaXMuc3RydWN0dXJlRGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICBjaGlsZC5wYXJlbnRSZW5kZXJHcm91cCA9IHRoaXM7XG4gICAgY2hpbGQudXBkYXRlVGljayA9IC0xO1xuICAgIGlmIChjaGlsZC5wYXJlbnQgPT09IHRoaXMucm9vdCkge1xuICAgICAgY2hpbGQucmVsYXRpdmVSZW5kZXJHcm91cERlcHRoID0gMTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2hpbGQucmVsYXRpdmVSZW5kZXJHcm91cERlcHRoID0gY2hpbGQucGFyZW50LnJlbGF0aXZlUmVuZGVyR3JvdXBEZXB0aCArIDE7XG4gICAgfVxuICAgIGNoaWxkLmRpZENoYW5nZSA9IHRydWU7XG4gICAgdGhpcy5vbkNoaWxkVXBkYXRlKGNoaWxkKTtcbiAgICBpZiAoY2hpbGQucmVuZGVyR3JvdXApIHtcbiAgICAgIHRoaXMuYWRkUmVuZGVyR3JvdXBDaGlsZChjaGlsZC5yZW5kZXJHcm91cCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChjaGlsZC5fb25SZW5kZXIpIHRoaXMuYWRkT25SZW5kZXIoY2hpbGQpO1xuICAgIGNvbnN0IGNoaWxkcmVuID0gY2hpbGQuY2hpbGRyZW47XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgdGhpcy5hZGRDaGlsZChjaGlsZHJlbltpXSk7XG4gICAgfVxuICB9XG4gIHJlbW92ZUNoaWxkKGNoaWxkKSB7XG4gICAgdGhpcy5zdHJ1Y3R1cmVEaWRDaGFuZ2UgPSB0cnVlO1xuICAgIGlmIChjaGlsZC5fb25SZW5kZXIpIHtcbiAgICAgIGlmICghY2hpbGQucmVuZGVyR3JvdXApIHtcbiAgICAgICAgdGhpcy5yZW1vdmVPblJlbmRlcihjaGlsZCk7XG4gICAgICB9XG4gICAgfVxuICAgIGNoaWxkLnBhcmVudFJlbmRlckdyb3VwID0gbnVsbDtcbiAgICBpZiAoY2hpbGQucmVuZGVyR3JvdXApIHtcbiAgICAgIHRoaXMuX3JlbW92ZVJlbmRlckdyb3VwQ2hpbGQoY2hpbGQucmVuZGVyR3JvdXApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjaGlsZHJlbiA9IGNoaWxkLmNoaWxkcmVuO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICAgIHRoaXMucmVtb3ZlQ2hpbGQoY2hpbGRyZW5baV0pO1xuICAgIH1cbiAgfVxuICByZW1vdmVDaGlsZHJlbihjaGlsZHJlbikge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICAgIHRoaXMucmVtb3ZlQ2hpbGQoY2hpbGRyZW5baV0pO1xuICAgIH1cbiAgfVxuICBvbkNoaWxkVXBkYXRlKGNoaWxkKSB7XG4gICAgbGV0IGNoaWxkcmVuVG9VcGRhdGUgPSB0aGlzLmNoaWxkcmVuVG9VcGRhdGVbY2hpbGQucmVsYXRpdmVSZW5kZXJHcm91cERlcHRoXTtcbiAgICBpZiAoIWNoaWxkcmVuVG9VcGRhdGUpIHtcbiAgICAgIGNoaWxkcmVuVG9VcGRhdGUgPSB0aGlzLmNoaWxkcmVuVG9VcGRhdGVbY2hpbGQucmVsYXRpdmVSZW5kZXJHcm91cERlcHRoXSA9IHtcbiAgICAgICAgaW5kZXg6IDAsXG4gICAgICAgIGxpc3Q6IFtdXG4gICAgICB9O1xuICAgIH1cbiAgICBjaGlsZHJlblRvVXBkYXRlLmxpc3RbY2hpbGRyZW5Ub1VwZGF0ZS5pbmRleCsrXSA9IGNoaWxkO1xuICB9XG4gIHVwZGF0ZVJlbmRlcmFibGUocmVuZGVyYWJsZSkge1xuICAgIGlmIChyZW5kZXJhYmxlLmdsb2JhbERpc3BsYXlTdGF0dXMgPCA3KSByZXR1cm47XG4gICAgdGhpcy5pbnN0cnVjdGlvblNldC5yZW5kZXJQaXBlc1tyZW5kZXJhYmxlLnJlbmRlclBpcGVJZF0udXBkYXRlUmVuZGVyYWJsZShyZW5kZXJhYmxlKTtcbiAgICByZW5kZXJhYmxlLmRpZFZpZXdVcGRhdGUgPSBmYWxzZTtcbiAgfVxuICBvbkNoaWxkVmlld1VwZGF0ZShjaGlsZCkge1xuICAgIHRoaXMuY2hpbGRyZW5SZW5kZXJhYmxlc1RvVXBkYXRlLmxpc3RbdGhpcy5jaGlsZHJlblJlbmRlcmFibGVzVG9VcGRhdGUuaW5kZXgrK10gPSBjaGlsZDtcbiAgfVxuICBnZXQgaXNSZW5kZXJhYmxlKCkge1xuICAgIHJldHVybiB0aGlzLnJvb3QubG9jYWxEaXNwbGF5U3RhdHVzID09PSA3ICYmIHRoaXMud29ybGRBbHBoYSA+IDA7XG4gIH1cbiAgLyoqXG4gICAqIGFkZGluZyBhIGNvbnRhaW5lciB0byB0aGUgb25SZW5kZXIgbGlzdCB3aWxsIG1ha2Ugc3VyZSB0aGUgdXNlciBmdW5jdGlvblxuICAgKiBwYXNzZWQgaW4gdG8gdGhlIHVzZXIgZGVmaW5lZCAnb25SZW5kZXJgIGNhbGxCYWNrXG4gICAqIEBwYXJhbSBjb250YWluZXIgLSB0aGUgY29udGFpbmVyIHRvIGFkZCB0byB0aGUgb25SZW5kZXIgbGlzdFxuICAgKi9cbiAgYWRkT25SZW5kZXIoY29udGFpbmVyKSB7XG4gICAgaWYgKHRoaXMuX29uUmVuZGVyQ29udGFpbmVycy5pbmRleE9mKGNvbnRhaW5lcikgPT09IC0xKSB7XG4gICAgICB0aGlzLl9vblJlbmRlckNvbnRhaW5lcnMucHVzaChjb250YWluZXIpO1xuICAgIH1cbiAgfVxuICByZW1vdmVPblJlbmRlcihjb250YWluZXIpIHtcbiAgICBjb25zdCBpZHggPSB0aGlzLl9vblJlbmRlckNvbnRhaW5lcnMuaW5kZXhPZihjb250YWluZXIpO1xuICAgIGlmIChpZHggIT09IC0xKSB0aGlzLl9vblJlbmRlckNvbnRhaW5lcnMuc3BsaWNlKGlkeCwgMSk7XG4gIH1cbiAgcnVuT25SZW5kZXIocmVuZGVyZXIpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuX29uUmVuZGVyQ29udGFpbmVycy5sZW5ndGg7IGkrKykge1xuICAgICAgdGhpcy5fb25SZW5kZXJDb250YWluZXJzW2ldLl9vblJlbmRlcihyZW5kZXJlcik7XG4gICAgfVxuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5kaXNhYmxlQ2FjaGVBc1RleHR1cmUoKTtcbiAgICB0aGlzLnJlbmRlckdyb3VwUGFyZW50ID0gbnVsbDtcbiAgICB0aGlzLnJvb3QgPSBudWxsO1xuICAgIHRoaXMuY2hpbGRyZW5SZW5kZXJhYmxlc1RvVXBkYXRlID0gbnVsbDtcbiAgICB0aGlzLmNoaWxkcmVuVG9VcGRhdGUgPSBudWxsO1xuICAgIHRoaXMucmVuZGVyR3JvdXBDaGlsZHJlbiA9IG51bGw7XG4gICAgdGhpcy5fb25SZW5kZXJDb250YWluZXJzID0gbnVsbDtcbiAgICB0aGlzLmluc3RydWN0aW9uU2V0Py5kZXN0cm95KCk7XG4gICAgdGhpcy5pbnN0cnVjdGlvblNldCA9IG51bGw7XG4gIH1cbiAgZ2V0Q2hpbGRyZW4ob3V0ID0gW10pIHtcbiAgICBjb25zdCBjaGlsZHJlbiA9IHRoaXMucm9vdC5jaGlsZHJlbjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICB0aGlzLl9nZXRDaGlsZHJlbihjaGlsZHJlbltpXSwgb3V0KTtcbiAgICB9XG4gICAgcmV0dXJuIG91dDtcbiAgfVxuICBfZ2V0Q2hpbGRyZW4oY29udGFpbmVyLCBvdXQgPSBbXSkge1xuICAgIG91dC5wdXNoKGNvbnRhaW5lcik7XG4gICAgaWYgKGNvbnRhaW5lci5yZW5kZXJHcm91cCkgcmV0dXJuIG91dDtcbiAgICBjb25zdCBjaGlsZHJlbiA9IGNvbnRhaW5lci5jaGlsZHJlbjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICB0aGlzLl9nZXRDaGlsZHJlbihjaGlsZHJlbltpXSwgb3V0KTtcbiAgICB9XG4gICAgcmV0dXJuIG91dDtcbiAgfVxuICBpbnZhbGlkYXRlTWF0cmljZXMoKSB7XG4gICAgdGhpcy5fbWF0cml4RGlydHkgPSA3O1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBpbnZlcnNlIG9mIHRoZSB3b3JsZCB0cmFuc2Zvcm0gbWF0cml4LlxuICAgKiBAcmV0dXJucyB7TWF0cml4fSBUaGUgaW52ZXJzZSBvZiB0aGUgd29ybGQgdHJhbnNmb3JtIG1hdHJpeC5cbiAgICovXG4gIGdldCBpbnZlcnNlV29ybGRUcmFuc2Zvcm0oKSB7XG4gICAgaWYgKCh0aGlzLl9tYXRyaXhEaXJ0eSAmIDEpID09PSAwKSByZXR1cm4gdGhpcy5faW52ZXJzZVdvcmxkVHJhbnNmb3JtO1xuICAgIHRoaXMuX21hdHJpeERpcnR5ICY9IH4xO1xuICAgIHRoaXMuX2ludmVyc2VXb3JsZFRyYW5zZm9ybSB8fCAodGhpcy5faW52ZXJzZVdvcmxkVHJhbnNmb3JtID0gbmV3IE1hdHJpeCgpKTtcbiAgICByZXR1cm4gdGhpcy5faW52ZXJzZVdvcmxkVHJhbnNmb3JtLmNvcHlGcm9tKHRoaXMud29ybGRUcmFuc2Zvcm0pLmludmVydCgpO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBpbnZlcnNlIG9mIHRoZSB0ZXh0dXJlIG9mZnNldCB0cmFuc2Zvcm0gbWF0cml4LlxuICAgKiBAcmV0dXJucyB7TWF0cml4fSBUaGUgaW52ZXJzZSBvZiB0aGUgdGV4dHVyZSBvZmZzZXQgdHJhbnNmb3JtIG1hdHJpeC5cbiAgICovXG4gIGdldCB0ZXh0dXJlT2Zmc2V0SW52ZXJzZVRyYW5zZm9ybSgpIHtcbiAgICBpZiAoKHRoaXMuX21hdHJpeERpcnR5ICYgMikgPT09IDApIHJldHVybiB0aGlzLl90ZXh0dXJlT2Zmc2V0SW52ZXJzZVRyYW5zZm9ybTtcbiAgICB0aGlzLl9tYXRyaXhEaXJ0eSAmPSB+MjtcbiAgICB0aGlzLl90ZXh0dXJlT2Zmc2V0SW52ZXJzZVRyYW5zZm9ybSB8fCAodGhpcy5fdGV4dHVyZU9mZnNldEludmVyc2VUcmFuc2Zvcm0gPSBuZXcgTWF0cml4KCkpO1xuICAgIHJldHVybiB0aGlzLl90ZXh0dXJlT2Zmc2V0SW52ZXJzZVRyYW5zZm9ybS5jb3B5RnJvbSh0aGlzLmludmVyc2VXb3JsZFRyYW5zZm9ybSkudHJhbnNsYXRlKFxuICAgICAgLXRoaXMuX3RleHR1cmVCb3VuZHMueCxcbiAgICAgIC10aGlzLl90ZXh0dXJlQm91bmRzLnlcbiAgICApO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBpbnZlcnNlIG9mIHRoZSBwYXJlbnQgdGV4dHVyZSB0cmFuc2Zvcm0gbWF0cml4LlxuICAgKiBUaGlzIGlzIHVzZWQgdG8gcHJvcGVybHkgdHJhbnNmb3JtIGNvb3JkaW5hdGVzIHdoZW4gcmVuZGVyaW5nIGludG8gY2FjaGVkIHRleHR1cmVzLlxuICAgKiBAcmV0dXJucyB7TWF0cml4fSBUaGUgaW52ZXJzZSBvZiB0aGUgcGFyZW50IHRleHR1cmUgdHJhbnNmb3JtIG1hdHJpeC5cbiAgICovXG4gIGdldCBpbnZlcnNlUGFyZW50VGV4dHVyZVRyYW5zZm9ybSgpIHtcbiAgICBpZiAoKHRoaXMuX21hdHJpeERpcnR5ICYgNCkgPT09IDApIHJldHVybiB0aGlzLl9pbnZlcnNlUGFyZW50VGV4dHVyZVRyYW5zZm9ybTtcbiAgICB0aGlzLl9tYXRyaXhEaXJ0eSAmPSB+NDtcbiAgICBjb25zdCBwYXJlbnRDYWNoZUFzVGV4dHVyZSA9IHRoaXMuX3BhcmVudENhY2hlQXNUZXh0dXJlUmVuZGVyR3JvdXA7XG4gICAgaWYgKHBhcmVudENhY2hlQXNUZXh0dXJlKSB7XG4gICAgICB0aGlzLl9pbnZlcnNlUGFyZW50VGV4dHVyZVRyYW5zZm9ybSB8fCAodGhpcy5faW52ZXJzZVBhcmVudFRleHR1cmVUcmFuc2Zvcm0gPSBuZXcgTWF0cml4KCkpO1xuICAgICAgcmV0dXJuIHRoaXMuX2ludmVyc2VQYXJlbnRUZXh0dXJlVHJhbnNmb3JtLmNvcHlGcm9tKHRoaXMud29ybGRUcmFuc2Zvcm0pLnByZXBlbmQocGFyZW50Q2FjaGVBc1RleHR1cmUuaW52ZXJzZVdvcmxkVHJhbnNmb3JtKS50cmFuc2xhdGUoXG4gICAgICAgIC1wYXJlbnRDYWNoZUFzVGV4dHVyZS5fdGV4dHVyZUJvdW5kcy54LFxuICAgICAgICAtcGFyZW50Q2FjaGVBc1RleHR1cmUuX3RleHR1cmVCb3VuZHMueVxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMud29ybGRUcmFuc2Zvcm07XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgYSBtYXRyaXggdGhhdCB0cmFuc2Zvcm1zIGNvb3JkaW5hdGVzIHRvIHRoZSBjb3JyZWN0IGNvb3JkaW5hdGUgc3BhY2Ugb2YgdGhlIHRleHR1cmUgYmVpbmcgcmVuZGVyZWQgdG8uXG4gICAqIFRoaXMgaXMgdGhlIHRleHR1cmUgb2Zmc2V0IGludmVyc2UgdHJhbnNmb3JtIG9mIHRoZSBjbG9zZXN0IHBhcmVudCBSZW5kZXJHcm91cCB0aGF0IGlzIGNhY2hlZCBhcyBhIHRleHR1cmUuXG4gICAqIEByZXR1cm5zIHtNYXRyaXggfCBudWxsfSBUaGUgdHJhbnNmb3JtIG1hdHJpeCBmb3IgdGhlIGNhY2hlZCB0ZXh0dXJlIGNvb3JkaW5hdGUgc3BhY2UsXG4gICAqIG9yIG51bGwgaWYgbm8gcGFyZW50IGlzIGNhY2hlZCBhcyB0ZXh0dXJlLlxuICAgKi9cbiAgZ2V0IGNhY2hlVG9Mb2NhbFRyYW5zZm9ybSgpIHtcbiAgICBpZiAodGhpcy5pc0NhY2hlZEFzVGV4dHVyZSkge1xuICAgICAgcmV0dXJuIHRoaXMudGV4dHVyZU9mZnNldEludmVyc2VUcmFuc2Zvcm07XG4gICAgfVxuICAgIGlmICghdGhpcy5fcGFyZW50Q2FjaGVBc1RleHR1cmVSZW5kZXJHcm91cCkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIHRoaXMuX3BhcmVudENhY2hlQXNUZXh0dXJlUmVuZGVyR3JvdXAudGV4dHVyZU9mZnNldEludmVyc2VUcmFuc2Zvcm07XG4gIH1cbn1cblxuZXhwb3J0IHsgUmVuZGVyR3JvdXAgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVJlbmRlckdyb3VwLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gYXNzaWduV2l0aElnbm9yZSh0YXJnZXQsIG9wdGlvbnMsIGlnbm9yZSA9IHt9KSB7XG4gIGZvciAoY29uc3Qga2V5IGluIG9wdGlvbnMpIHtcbiAgICBpZiAoIWlnbm9yZVtrZXldICYmIG9wdGlvbnNba2V5XSAhPT0gdm9pZCAwKSB7XG4gICAgICB0YXJnZXRba2V5XSA9IG9wdGlvbnNba2V5XTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IHsgYXNzaWduV2l0aElnbm9yZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXNzaWduV2l0aElnbm9yZS5tanMubWFwXG4iLCJpbXBvcnQgRXZlbnRFbWl0dGVyIGZyb20gJ2V2ZW50ZW1pdHRlcjMnO1xuaW1wb3J0IHsgQ29sb3IgfSBmcm9tICcuLi8uLi9jb2xvci9Db2xvci5tanMnO1xuaW1wb3J0IHsgY3VsbGluZ01peGluIH0gZnJvbSAnLi4vLi4vY3VsbGluZy9jdWxsaW5nTWl4aW4ubWpzJztcbmltcG9ydCB7IGV4dGVuc2lvbnMgfSBmcm9tICcuLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IE1hdHJpeCB9IGZyb20gJy4uLy4uL21hdGhzL21hdHJpeC9NYXRyaXgubWpzJztcbmltcG9ydCB7IFJBRF9UT19ERUcsIERFR19UT19SQUQgfSBmcm9tICcuLi8uLi9tYXRocy9taXNjL2NvbnN0Lm1qcyc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlUG9pbnQgfSBmcm9tICcuLi8uLi9tYXRocy9wb2ludC9PYnNlcnZhYmxlUG9pbnQubWpzJztcbmltcG9ydCB7IHVpZCB9IGZyb20gJy4uLy4uL3V0aWxzL2RhdGEvdWlkLm1qcyc7XG5pbXBvcnQgeyBkZXByZWNhdGlvbiwgdjhfMF8wIH0gZnJvbSAnLi4vLi4vdXRpbHMvbG9nZ2luZy9kZXByZWNhdGlvbi5tanMnO1xuaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uLy4uL3V0aWxzL2xvZ2dpbmcvd2Fybi5tanMnO1xuaW1wb3J0IHsgQmlnUG9vbCB9IGZyb20gJy4uLy4uL3V0aWxzL3Bvb2wvUG9vbEdyb3VwLm1qcyc7XG5pbXBvcnQgeyBjYWNoZUFzVGV4dHVyZU1peGluIH0gZnJvbSAnLi9jb250YWluZXItbWl4aW5zL2NhY2hlQXNUZXh0dXJlTWl4aW4ubWpzJztcbmltcG9ydCB7IGNoaWxkcmVuSGVscGVyTWl4aW4gfSBmcm9tICcuL2NvbnRhaW5lci1taXhpbnMvY2hpbGRyZW5IZWxwZXJNaXhpbi5tanMnO1xuaW1wb3J0IHsgY29sbGVjdFJlbmRlcmFibGVzTWl4aW4gfSBmcm9tICcuL2NvbnRhaW5lci1taXhpbnMvY29sbGVjdFJlbmRlcmFibGVzTWl4aW4ubWpzJztcbmltcG9ydCB7IGVmZmVjdHNNaXhpbiB9IGZyb20gJy4vY29udGFpbmVyLW1peGlucy9lZmZlY3RzTWl4aW4ubWpzJztcbmltcG9ydCB7IGZpbmRNaXhpbiB9IGZyb20gJy4vY29udGFpbmVyLW1peGlucy9maW5kTWl4aW4ubWpzJztcbmltcG9ydCB7IGdldEZhc3RHbG9iYWxCb3VuZHNNaXhpbiB9IGZyb20gJy4vY29udGFpbmVyLW1peGlucy9nZXRGYXN0R2xvYmFsQm91bmRzTWl4aW4ubWpzJztcbmltcG9ydCB7IGJncjJyZ2IsIGdldEdsb2JhbE1peGluIH0gZnJvbSAnLi9jb250YWluZXItbWl4aW5zL2dldEdsb2JhbE1peGluLm1qcyc7XG5pbXBvcnQgeyBtZWFzdXJlTWl4aW4gfSBmcm9tICcuL2NvbnRhaW5lci1taXhpbnMvbWVhc3VyZU1peGluLm1qcyc7XG5pbXBvcnQgeyBvblJlbmRlck1peGluIH0gZnJvbSAnLi9jb250YWluZXItbWl4aW5zL29uUmVuZGVyTWl4aW4ubWpzJztcbmltcG9ydCB7IHNvcnRNaXhpbiB9IGZyb20gJy4vY29udGFpbmVyLW1peGlucy9zb3J0TWl4aW4ubWpzJztcbmltcG9ydCB7IHRvTG9jYWxHbG9iYWxNaXhpbiB9IGZyb20gJy4vY29udGFpbmVyLW1peGlucy90b0xvY2FsR2xvYmFsTWl4aW4ubWpzJztcbmltcG9ydCB7IFJlbmRlckdyb3VwIH0gZnJvbSAnLi9SZW5kZXJHcm91cC5tanMnO1xuaW1wb3J0IHsgYXNzaWduV2l0aElnbm9yZSB9IGZyb20gJy4vdXRpbHMvYXNzaWduV2l0aElnbm9yZS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IGRlZmF1bHRTa2V3ID0gbmV3IE9ic2VydmFibGVQb2ludChudWxsKTtcbmNvbnN0IGRlZmF1bHRQaXZvdCA9IG5ldyBPYnNlcnZhYmxlUG9pbnQobnVsbCk7XG5jb25zdCBkZWZhdWx0U2NhbGUgPSBuZXcgT2JzZXJ2YWJsZVBvaW50KG51bGwsIDEsIDEpO1xuY29uc3QgZGVmYXVsdE9yaWdpbiA9IG5ldyBPYnNlcnZhYmxlUG9pbnQobnVsbCk7XG5jb25zdCBVUERBVEVfQ09MT1IgPSAxO1xuY29uc3QgVVBEQVRFX0JMRU5EID0gMjtcbmNvbnN0IFVQREFURV9WSVNJQkxFID0gNDtcbmNvbnN0IFVQREFURV9UUkFOU0ZPUk0gPSA4O1xuY2xhc3MgQ29udGFpbmVyIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgc3VwZXIoKTtcbiAgICAvKipcbiAgICAgKiB1bmlxdWUgaWQgZm9yIHRoaXMgY29udGFpbmVyXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy51aWQgPSB1aWQoXCJyZW5kZXJhYmxlXCIpO1xuICAgIC8qKiBAcHJpdmF0ZSAqL1xuICAgIHRoaXMuX3VwZGF0ZUZsYWdzID0gMTU7XG4gICAgLy8gdGhlIHJlbmRlciBncm91cCB0aGlzIGNvbnRhaW5lciBvd25zXG4gICAgLyoqIEBwcml2YXRlICovXG4gICAgdGhpcy5yZW5kZXJHcm91cCA9IG51bGw7XG4gICAgLy8gdGhlIHJlbmRlciBncm91cCB0aGlzIGNvbnRhaW5lciBiZWxvbmdzIHRvXG4gICAgLyoqIEBwcml2YXRlICovXG4gICAgdGhpcy5wYXJlbnRSZW5kZXJHcm91cCA9IG51bGw7XG4gICAgLy8gdGhlIGluZGV4IG9mIHRoZSBjb250YWluZXIgaW4gdGhlIHJlbmRlciBncm91cFxuICAgIC8qKiBAcHJpdmF0ZSAqL1xuICAgIHRoaXMucGFyZW50UmVuZGVyR3JvdXBJbmRleCA9IDA7XG4gICAgLy8gc2V0IHRvIHRydWUgaWYgdGhlIGNvbnRhaW5lciBoYXMgY2hhbmdlZC4gSXQgaXMgcmVzZXQgb25jZSB0aGUgY2hhbmdlcyBoYXZlIGJlZW4gYXBwbGllZFxuICAgIC8vIGJ5IHRoZSB0cmFuc2Zvcm0gc3lzdGVtXG4gICAgLy8gaXRzIGhlcmUgdG8gc3RvcCBlbnN1cmUgdGhhdCB3aGVuIHRoaW5ncyBjaGFuZ2UsIG9ubHkgb25lIHVwZGF0ZSBnZXRzIHJlZ2lzdGVycyB3aXRoIHRoZSB0cmFuc2Zvcm0gc3lzdGVtXG4gICAgLyoqIEBwcml2YXRlICovXG4gICAgdGhpcy5kaWRDaGFuZ2UgPSBmYWxzZTtcbiAgICAvLyBzYW1lIGFzIGFib3ZlLCBidXQgZm9yIHRoZSByZW5kZXJhYmxlXG4gICAgLyoqIEBwcml2YXRlICovXG4gICAgdGhpcy5kaWRWaWV3VXBkYXRlID0gZmFsc2U7XG4gICAgLy8gaG93IGRlZXAgaXMgdGhlIGNvbnRhaW5lciByZWxhdGl2ZSB0byBpdHMgcmVuZGVyIGdyb3VwLi5cbiAgICAvLyB1bmxlc3MgdGhlIGVsZW1lbnQgaXMgdGhlIHJvb3QgcmVuZGVyIGdyb3VwIC0gaXQgd2lsbCBiZSByZWxhdGl2ZSB0byBpdHMgcGFyZW50XG4gICAgLyoqIEBwcml2YXRlICovXG4gICAgdGhpcy5yZWxhdGl2ZVJlbmRlckdyb3VwRGVwdGggPSAwO1xuICAgIC8qKlxuICAgICAqIFRoZSBhcnJheSBvZiBjaGlsZHJlbiBvZiB0aGlzIGNvbnRhaW5lci4gRWFjaCBjaGlsZCBtdXN0IGJlIGEgQ29udGFpbmVyIG9yIGV4dGVuZCBmcm9tIGl0LlxuICAgICAqXG4gICAgICogVGhlIGFycmF5IGlzIHJlYWQtb25seSwgYnV0IGl0cyBjb250ZW50cyBjYW4gYmUgbW9kaWZpZWQgdXNpbmcgQ29udGFpbmVyIG1ldGhvZHMuXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIC8vIEFjY2VzcyBjaGlsZHJlblxuICAgICAqIGNvbnN0IGZpcnN0Q2hpbGQgPSBjb250YWluZXIuY2hpbGRyZW5bMF07XG4gICAgICogY29uc3QgbGFzdENoaWxkID0gY29udGFpbmVyLmNoaWxkcmVuW2NvbnRhaW5lci5jaGlsZHJlbi5sZW5ndGggLSAxXTtcbiAgICAgKiBgYGBcbiAgICAgKiBAcmVhZG9ubHlcbiAgICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjYWRkQ2hpbGR9IEZvciBhZGRpbmcgY2hpbGRyZW5cbiAgICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjcmVtb3ZlQ2hpbGR9IEZvciByZW1vdmluZyBjaGlsZHJlblxuICAgICAqL1xuICAgIHRoaXMuY2hpbGRyZW4gPSBbXTtcbiAgICAvKipcbiAgICAgKiBUaGUgZGlzcGxheSBvYmplY3QgY29udGFpbmVyIHRoYXQgY29udGFpbnMgdGhpcyBkaXNwbGF5IG9iamVjdC5cbiAgICAgKiBUaGlzIHJlcHJlc2VudHMgdGhlIHBhcmVudC1jaGlsZCByZWxhdGlvbnNoaXAgaW4gdGhlIGRpc3BsYXkgdHJlZS5cbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogLy8gQmFzaWMgcGFyZW50IGFjY2Vzc1xuICAgICAqIGNvbnN0IHBhcmVudCA9IHNwcml0ZS5wYXJlbnQ7XG4gICAgICpcbiAgICAgKiAvLyBXYWxrIHVwIHRoZSB0cmVlXG4gICAgICogbGV0IGN1cnJlbnQgPSBzcHJpdGU7XG4gICAgICogd2hpbGUgKGN1cnJlbnQucGFyZW50KSB7XG4gICAgICogICAgIGNvbnNvbGUubG9nKCdMZXZlbCB1cDonLCBjdXJyZW50LnBhcmVudC5jb25zdHJ1Y3Rvci5uYW1lKTtcbiAgICAgKiAgICAgY3VycmVudCA9IGN1cnJlbnQucGFyZW50O1xuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgKiBAcmVhZG9ubHlcbiAgICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjYWRkQ2hpbGR9IEZvciBhZGRpbmcgdG8gYSBwYXJlbnRcbiAgICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjcmVtb3ZlQ2hpbGR9IEZvciByZW1vdmluZyBmcm9tIHBhcmVudFxuICAgICAqL1xuICAgIHRoaXMucGFyZW50ID0gbnVsbDtcbiAgICAvLyB1c2VkIGludGVybmFsbHkgZm9yIGNoYW5naW5nIHVwIHRoZSByZW5kZXIgb3JkZXIuLiBtYWlubHkgZm9yIG1hc2tzIGFuZCBmaWx0ZXJzXG4gICAgLy8gVE9ETyBzZXR0aW5nIHRoaXMgc2hvdWxkIGNhdXNlIGEgcmVidWlsZD8/XG4gICAgLyoqIEBwcml2YXRlICovXG4gICAgdGhpcy5pbmNsdWRlSW5CdWlsZCA9IHRydWU7XG4gICAgLyoqIEBwcml2YXRlICovXG4gICAgdGhpcy5tZWFzdXJhYmxlID0gdHJ1ZTtcbiAgICAvKiogQHByaXZhdGUgKi9cbiAgICB0aGlzLmlzU2ltcGxlID0gdHJ1ZTtcbiAgICAvKipcbiAgICAgKiBUaGUgUmVuZGVyTGF5ZXIgdGhpcyBjb250YWluZXIgYmVsb25ncyB0bywgaWYgYW55LlxuICAgICAqIElmIGl0IGJlbG9uZ3MgdG8gYSBSZW5kZXJMYXllciwgaXQgd2lsbCBiZSByZW5kZXJlZCBmcm9tIHRoZSBSZW5kZXJMYXllcidzIHBvc2l0aW9uIGluIHRoZSBzY2VuZS5cbiAgICAgKiBAcmVhZG9ubHlcbiAgICAgKiBAYWR2YW5jZWRcbiAgICAgKi9cbiAgICB0aGlzLnBhcmVudFJlbmRlckxheWVyID0gbnVsbDtcbiAgICAvLyAvIC8vLy8vLy8vLy8vLy9UcmFuc2Zvcm0gcmVsYXRlZCBwcm9wcy8vLy8vLy8vLy8vLy8vXG4gICAgLy8gdXNlZCBieSB0aGUgdHJhbnNmb3JtIHN5c3RlbSB0byBjaGVjayBpZiBhIGNvbnRhaW5lciBuZWVkcyB0byBiZSB1cGRhdGVkIHRoYXQgZnJhbWVcbiAgICAvLyBpZiB0aGUgdGljayBtYXRjaGVzIHRoZSBjdXJyZW50IHRyYW5zZm9ybSBzeXN0ZW0gdGljaywgaXQgaXMgbm90IHVwZGF0ZWQgYWdhaW5cbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy51cGRhdGVUaWNrID0gLTE7XG4gICAgLyoqXG4gICAgICogQ3VycmVudCB0cmFuc2Zvcm0gb2YgdGhlIG9iamVjdCBiYXNlZCBvbiBsb2NhbCBmYWN0b3JzOiBwb3NpdGlvbiwgc2NhbGUsIG90aGVyIHN0dWZmLlxuICAgICAqIFRoaXMgbWF0cml4IHJlcHJlc2VudHMgdGhlIGxvY2FsIHRyYW5zZm9ybWF0aW9uIHdpdGhvdXQgYW55IHBhcmVudCBpbmZsdWVuY2UuXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIC8vIEJhc2ljIHRyYW5zZm9ybSBhY2Nlc3NcbiAgICAgKiBjb25zdCBsb2NhbE1hdHJpeCA9IHNwcml0ZS5sb2NhbFRyYW5zZm9ybTtcbiAgICAgKiBjb25zb2xlLmxvZyhsb2NhbE1hdHJpeC50b1N0cmluZygpKTtcbiAgICAgKiBgYGBcbiAgICAgKiBAcmVhZG9ubHlcbiAgICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjd29ybGRUcmFuc2Zvcm19IEZvciBnbG9iYWwgdHJhbnNmb3JtXG4gICAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI2dyb3VwVHJhbnNmb3JtfSBGb3IgcmVuZGVyIGdyb3VwIHRyYW5zZm9ybVxuICAgICAqL1xuICAgIHRoaXMubG9jYWxUcmFuc2Zvcm0gPSBuZXcgTWF0cml4KCk7XG4gICAgLyoqXG4gICAgICogVGhlIHJlbGF0aXZlIGdyb3VwIHRyYW5zZm9ybSBpcyBhIHRyYW5zZm9ybSByZWxhdGl2ZSB0byB0aGUgcmVuZGVyIGdyb3VwIGl0IGJlbG9uZ3MgdG9vLiBJdCB3aWxsIGluY2x1ZGUgYWxsIHBhcmVudFxuICAgICAqIHRyYW5zZm9ybXMgYW5kIHVwIHRvIHRoZSByZW5kZXIgZ3JvdXAgKHRoaW5rIG9mIGl0IGFzIGtpbmQgb2YgbGlrZSBhIHN0YWdlIC0gYnV0IHRoZSBzdGFnZSBjYW4gYmUgbmVzdGVkKS5cbiAgICAgKiBJZiB0aGlzIGNvbnRhaW5lciBpcyBpcyBzZWxmIGEgcmVuZGVyIGdyb3VwIG1hdHJpeCB3aWxsIGJlIHJlbGF0aXZlIHRvIGl0cyBwYXJlbnQgcmVuZGVyIGdyb3VwXG4gICAgICogQHJlYWRvbmx5XG4gICAgICogQGFkdmFuY2VkXG4gICAgICovXG4gICAgdGhpcy5yZWxhdGl2ZUdyb3VwVHJhbnNmb3JtID0gbmV3IE1hdHJpeCgpO1xuICAgIC8qKlxuICAgICAqIFRoZSBncm91cCB0cmFuc2Zvcm0gaXMgYSB0cmFuc2Zvcm0gcmVsYXRpdmUgdG8gdGhlIHJlbmRlciBncm91cCBpdCBiZWxvbmdzIHRvby5cbiAgICAgKiBJZiB0aGlzIGNvbnRhaW5lciBpcyByZW5kZXIgZ3JvdXAgdGhlbiB0aGlzIHdpbGwgYmUgYW4gaWRlbnRpdHkgbWF0cml4LiBvdGhlciB3aXNlIGl0XG4gICAgICogd2lsbCBiZSB0aGUgc2FtZSBhcyB0aGUgcmVsYXRpdmVHcm91cFRyYW5zZm9ybS5cbiAgICAgKiBVc2UgdGhpcyB2YWx1ZSB3aGVuIGFjdHVhbGx5IHJlbmRlcmluZyB0aGluZ3MgdG8gdGhlIHNjcmVlblxuICAgICAqIEByZWFkb25seVxuICAgICAqIEBhZHZhbmNlZFxuICAgICAqL1xuICAgIHRoaXMuZ3JvdXBUcmFuc2Zvcm0gPSB0aGlzLnJlbGF0aXZlR3JvdXBUcmFuc2Zvcm07XG4gICAgLyoqXG4gICAgICogV2hldGhlciB0aGlzIG9iamVjdCBoYXMgYmVlbiBkZXN0cm95ZWQuIElmIHRydWUsIHRoZSBvYmplY3Qgc2hvdWxkIG5vIGxvbmdlciBiZSB1c2VkLlxuICAgICAqIEFmdGVyIGFuIG9iamVjdCBpcyBkZXN0cm95ZWQsIGFsbCBvZiBpdHMgZnVuY3Rpb25hbGl0eSBpcyBkaXNhYmxlZCBhbmQgcmVmZXJlbmNlcyBhcmUgcmVtb3ZlZC5cbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogLy8gQ2xlYW51cCB3aXRoIGRlc3Ryb3lcbiAgICAgKiBzcHJpdGUuZGVzdHJveSgpO1xuICAgICAqIGNvbnNvbGUubG9nKHNwcml0ZS5kZXN0cm95ZWQpOyAvLyB0cnVlXG4gICAgICogYGBgXG4gICAgICogQGRlZmF1bHQgZmFsc2VcbiAgICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjZGVzdHJveX0gRm9yIGRlc3Ryb3lpbmcgb2JqZWN0c1xuICAgICAqL1xuICAgIHRoaXMuZGVzdHJveWVkID0gZmFsc2U7XG4gICAgLy8gdHJhbnNmb3JtIGRhdGEuLlxuICAgIC8qKlxuICAgICAqIFRoZSBjb29yZGluYXRlIG9mIHRoZSBvYmplY3QgcmVsYXRpdmUgdG8gdGhlIGxvY2FsIGNvb3JkaW5hdGVzIG9mIHRoZSBwYXJlbnQuXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fcG9zaXRpb24gPSBuZXcgT2JzZXJ2YWJsZVBvaW50KHRoaXMsIDAsIDApO1xuICAgIC8qKlxuICAgICAqIFRoZSBzY2FsZSBmYWN0b3Igb2YgdGhlIG9iamVjdC5cbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9zY2FsZSA9IGRlZmF1bHRTY2FsZTtcbiAgICAvKipcbiAgICAgKiBUaGUgcGl2b3QgcG9pbnQgb2YgdGhlIGNvbnRhaW5lciB0aGF0IGl0IHJvdGF0ZXMgYXJvdW5kLlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX3Bpdm90ID0gZGVmYXVsdFBpdm90O1xuICAgIC8qKlxuICAgICAqIFRoZSBvcmlnaW4gcG9pbnQgYXJvdW5kIHdoaWNoIHRoZSBjb250YWluZXIgcm90YXRlcyBhbmQgc2NhbGVzLlxuICAgICAqIFVubGlrZSBwaXZvdCwgY2hhbmdpbmcgb3JpZ2luIHdpbGwgbm90IG1vdmUgdGhlIGNvbnRhaW5lcidzIHBvc2l0aW9uLlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgdGhpcy5fb3JpZ2luID0gZGVmYXVsdE9yaWdpbjtcbiAgICAvKipcbiAgICAgKiBUaGUgc2tldyBhbW91bnQsIG9uIHRoZSB4IGFuZCB5IGF4aXMuXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fc2tldyA9IGRlZmF1bHRTa2V3O1xuICAgIC8qKlxuICAgICAqIFRoZSBYLWNvb3JkaW5hdGUgdmFsdWUgb2YgdGhlIG5vcm1hbGl6ZWQgbG9jYWwgWCBheGlzLFxuICAgICAqIHRoZSBmaXJzdCBjb2x1bW4gb2YgdGhlIGxvY2FsIHRyYW5zZm9ybWF0aW9uIG1hdHJpeCB3aXRob3V0IGEgc2NhbGUuXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fY3ggPSAxO1xuICAgIC8qKlxuICAgICAqIFRoZSBZLWNvb3JkaW5hdGUgdmFsdWUgb2YgdGhlIG5vcm1hbGl6ZWQgbG9jYWwgWCBheGlzLFxuICAgICAqIHRoZSBmaXJzdCBjb2x1bW4gb2YgdGhlIGxvY2FsIHRyYW5zZm9ybWF0aW9uIG1hdHJpeCB3aXRob3V0IGEgc2NhbGUuXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fc3ggPSAwO1xuICAgIC8qKlxuICAgICAqIFRoZSBYLWNvb3JkaW5hdGUgdmFsdWUgb2YgdGhlIG5vcm1hbGl6ZWQgbG9jYWwgWSBheGlzLFxuICAgICAqIHRoZSBzZWNvbmQgY29sdW1uIG9mIHRoZSBsb2NhbCB0cmFuc2Zvcm1hdGlvbiBtYXRyaXggd2l0aG91dCBhIHNjYWxlLlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX2N5ID0gMDtcbiAgICAvKipcbiAgICAgKiBUaGUgWS1jb29yZGluYXRlIHZhbHVlIG9mIHRoZSBub3JtYWxpemVkIGxvY2FsIFkgYXhpcyxcbiAgICAgKiB0aGUgc2Vjb25kIGNvbHVtbiBvZiB0aGUgbG9jYWwgdHJhbnNmb3JtYXRpb24gbWF0cml4IHdpdGhvdXQgYSBzY2FsZS5cbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9zeSA9IDE7XG4gICAgLyoqXG4gICAgICogVGhlIHJvdGF0aW9uIGFtb3VudC5cbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9yb3RhdGlvbiA9IDA7XG4gICAgLy8gLyBDT0xPUiByZWxhdGVkIHByb3BzIC8vLy8vLy8vLy8vLy8vXG4gICAgLy8gY29sb3Igc3RvcmVkIGFzIEFCR1JcbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy5sb2NhbENvbG9yID0gMTY3NzcyMTU7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMubG9jYWxBbHBoYSA9IDE7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuZ3JvdXBBbHBoYSA9IDE7XG4gICAgLy8gQVxuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLmdyb3VwQ29sb3IgPSAxNjc3NzIxNTtcbiAgICAvLyBCR1JcbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy5ncm91cENvbG9yQWxwaGEgPSA0Mjk0OTY3Mjk1O1xuICAgIC8vIEFCR1JcbiAgICAvLyAvIEJMRU5EIHJlbGF0ZWQgcHJvcHMgLy8vLy8vLy8vLy8vLy9cbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy5sb2NhbEJsZW5kTW9kZSA9IFwiaW5oZXJpdFwiO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLmdyb3VwQmxlbmRNb2RlID0gXCJub3JtYWxcIjtcbiAgICAvLyAvIFZJU0lCSUxJVFkgcmVsYXRlZCBwcm9wcyAvLy8vLy8vLy8vLy8vL1xuICAgIC8vIHZpc2liaWxpdHlcbiAgICAvLyAwYjExXG4gICAgLy8gZmlyc3QgYml0IGlzIHZpc2libGUsIHNlY29uZCBiaXQgaXMgcmVuZGVyYWJsZVxuICAgIC8qKlxuICAgICAqIFRoaXMgcHJvcGVydHkgaG9sZHMgdGhyZWUgYml0czogY3VsbGVkLCB2aXNpYmxlLCByZW5kZXJhYmxlXG4gICAgICogdGhlIHRoaXJkIGJpdCByZXByZXNlbnRzIGN1bGxpbmcgKDAgPSBjdWxsZWQsIDEgPSBub3QgY3VsbGVkKSAwYjEwMFxuICAgICAqIHRoZSBzZWNvbmQgYml0IHJlcHJlc2VudHMgdmlzaWJpbGl0eSAoMCA9IG5vdCB2aXNpYmxlLCAxID0gdmlzaWJsZSkgMGIwMTBcbiAgICAgKiB0aGUgZmlyc3QgYml0IHJlcHJlc2VudHMgcmVuZGVyYWJsZSAoMCA9IG5vdCByZW5kZXJhYmxlLCAxID0gcmVuZGVyYWJsZSkgMGIwMDFcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLmxvY2FsRGlzcGxheVN0YXR1cyA9IDc7XG4gICAgLy8gMGIxMSB8IDBiMTAgfCAwYjAxIHwgMGIwMFxuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLmdsb2JhbERpc3BsYXlTdGF0dXMgPSA3O1xuICAgIC8qKlxuICAgICAqIEEgdmFsdWUgdGhhdCBpbmNyZW1lbnRzIGVhY2ggdGltZSB0aGUgY29udGFpbmUgaXMgbW9kaWZpZWRcbiAgICAgKiBlZyBjaGlsZHJlbiBhZGRlZCwgcmVtb3ZlZCBldGNcbiAgICAgKiBAaWdub3JlXG4gICAgICovXG4gICAgdGhpcy5fZGlkQ29udGFpbmVyQ2hhbmdlVGljayA9IDA7XG4gICAgLyoqXG4gICAgICogQSB2YWx1ZSB0aGF0IGluY3JlbWVudHMgZWFjaCB0aW1lIHRoZSBjb250YWluZXIgdmlldyBpcyBtb2RpZmllZFxuICAgICAqIGVnIHRleHR1cmUgc3dhcCwgZ2VvbWV0cnkgY2hhbmdlIGV0Y1xuICAgICAqIEBpZ25vcmVcbiAgICAgKi9cbiAgICB0aGlzLl9kaWRWaWV3Q2hhbmdlVGljayA9IDA7XG4gICAgLyoqXG4gICAgICogcHJvcGVydHkgdGhhdCB0cmFja3MgaWYgdGhlIGNvbnRhaW5lciB0cmFuc2Zvcm0gaGFzIGNoYW5nZWRcbiAgICAgKiBAaWdub3JlXG4gICAgICovXG4gICAgdGhpcy5fZGlkTG9jYWxUcmFuc2Zvcm1DaGFuZ2VJZCA9IC0xO1xuICAgIHRoaXMuZWZmZWN0cyA9IFtdO1xuICAgIGFzc2lnbldpdGhJZ25vcmUodGhpcywgb3B0aW9ucywge1xuICAgICAgY2hpbGRyZW46IHRydWUsXG4gICAgICBwYXJlbnQ6IHRydWUsXG4gICAgICBlZmZlY3RzOiB0cnVlXG4gICAgfSk7XG4gICAgb3B0aW9ucy5jaGlsZHJlbj8uZm9yRWFjaCgoY2hpbGQpID0+IHRoaXMuYWRkQ2hpbGQoY2hpbGQpKTtcbiAgICBvcHRpb25zLnBhcmVudD8uYWRkQ2hpbGQodGhpcyk7XG4gIH1cbiAgLyoqXG4gICAqIE1peGVzIGFsbCBlbnVtZXJhYmxlIHByb3BlcnRpZXMgYW5kIG1ldGhvZHMgZnJvbSBhIHNvdXJjZSBvYmplY3QgdG8gQ29udGFpbmVyLlxuICAgKiBAcGFyYW0gc291cmNlIC0gVGhlIHNvdXJjZSBvZiBwcm9wZXJ0aWVzIGFuZCBtZXRob2RzIHRvIG1peCBpbi5cbiAgICogQGRlcHJlY2F0ZWQgc2luY2UgOC44LjBcbiAgICovXG4gIHN0YXRpYyBtaXhpbihzb3VyY2UpIHtcbiAgICBkZXByZWNhdGlvbihcIjguOC4wXCIsIFwiQ29udGFpbmVyLm1peGluIGlzIGRlcHJlY2F0ZWQsIHBsZWFzZSB1c2UgZXh0ZW5zaW9ucy5taXhpbiBpbnN0ZWFkLlwiKTtcbiAgICBleHRlbnNpb25zLm1peGluKENvbnRhaW5lciwgc291cmNlKTtcbiAgfVxuICAvLyA9ICdkZWZhdWx0JztcbiAgLyoqXG4gICAqIFdlIG5vdyB1c2UgdGhlIF9kaWRDb250YWluZXJDaGFuZ2VUaWNrIGFuZCBfZGlkVmlld0NoYW5nZVRpY2sgdG8gdHJhY2sgY2hhbmdlc1xuICAgKiBAZGVwcmVjYXRlZCBzaW5jZSA4LjIuNlxuICAgKiBAaWdub3JlXG4gICAqL1xuICBzZXQgX2RpZENoYW5nZUlkKHZhbHVlKSB7XG4gICAgdGhpcy5fZGlkVmlld0NoYW5nZVRpY2sgPSB2YWx1ZSA+PiAxMiAmIDQwOTU7XG4gICAgdGhpcy5fZGlkQ29udGFpbmVyQ2hhbmdlVGljayA9IHZhbHVlICYgNDA5NTtcbiAgfVxuICAvKiogQGlnbm9yZSAqL1xuICBnZXQgX2RpZENoYW5nZUlkKCkge1xuICAgIHJldHVybiB0aGlzLl9kaWRDb250YWluZXJDaGFuZ2VUaWNrICYgNDA5NSB8ICh0aGlzLl9kaWRWaWV3Q2hhbmdlVGljayAmIDQwOTUpIDw8IDEyO1xuICB9XG4gIC8qKlxuICAgKiBBZGRzIG9uZSBvciBtb3JlIGNoaWxkcmVuIHRvIHRoZSBjb250YWluZXIuXG4gICAqIFRoZSBjaGlsZHJlbiB3aWxsIGJlIHJlbmRlcmVkIGFzIHBhcnQgb2YgdGhpcyBjb250YWluZXIncyBkaXNwbGF5IGxpc3QuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEFkZCBhIHNpbmdsZSBjaGlsZFxuICAgKiBjb250YWluZXIuYWRkQ2hpbGQoc3ByaXRlKTtcbiAgICpcbiAgICogLy8gQWRkIG11bHRpcGxlIGNoaWxkcmVuXG4gICAqIGNvbnRhaW5lci5hZGRDaGlsZChiYWNrZ3JvdW5kLCBwbGF5ZXIsIGZvcmVncm91bmQpO1xuICAgKlxuICAgKiAvLyBBZGQgd2l0aCB0eXBlIGNoZWNraW5nXG4gICAqIGNvbnN0IHNwcml0ZSA9IGNvbnRhaW5lci5hZGRDaGlsZDxTcHJpdGU+KG5ldyBTcHJpdGUodGV4dHVyZSkpO1xuICAgKiBzcHJpdGUudGludCA9ICdyZWQnO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIGNoaWxkcmVuIC0gVGhlIENvbnRhaW5lcihzKSB0byBhZGQgdG8gdGhlIGNvbnRhaW5lclxuICAgKiBAcmV0dXJucyBUaGUgZmlyc3QgY2hpbGQgdGhhdCB3YXMgYWRkZWRcbiAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI3JlbW92ZUNoaWxkfSBGb3IgcmVtb3ZpbmcgY2hpbGRyZW5cbiAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI2FkZENoaWxkQXR9IEZvciBhZGRpbmcgYXQgc3BlY2lmaWMgaW5kZXhcbiAgICovXG4gIGFkZENoaWxkKC4uLmNoaWxkcmVuKSB7XG4gICAgaWYgKCF0aGlzLmFsbG93Q2hpbGRyZW4pIHtcbiAgICAgIGRlcHJlY2F0aW9uKHY4XzBfMCwgXCJhZGRDaGlsZDogT25seSBDb250YWluZXJzIHdpbGwgYmUgYWxsb3dlZCB0byBhZGQgY2hpbGRyZW4gaW4gdjguMC4wXCIpO1xuICAgIH1cbiAgICBpZiAoY2hpbGRyZW4ubGVuZ3RoID4gMSkge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgICB0aGlzLmFkZENoaWxkKGNoaWxkcmVuW2ldKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjaGlsZHJlblswXTtcbiAgICB9XG4gICAgY29uc3QgY2hpbGQgPSBjaGlsZHJlblswXTtcbiAgICBjb25zdCByZW5kZXJHcm91cCA9IHRoaXMucmVuZGVyR3JvdXAgfHwgdGhpcy5wYXJlbnRSZW5kZXJHcm91cDtcbiAgICBpZiAoY2hpbGQucGFyZW50ID09PSB0aGlzKSB7XG4gICAgICB0aGlzLmNoaWxkcmVuLnNwbGljZSh0aGlzLmNoaWxkcmVuLmluZGV4T2YoY2hpbGQpLCAxKTtcbiAgICAgIHRoaXMuY2hpbGRyZW4ucHVzaChjaGlsZCk7XG4gICAgICBpZiAocmVuZGVyR3JvdXApIHtcbiAgICAgICAgcmVuZGVyR3JvdXAuc3RydWN0dXJlRGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjaGlsZDtcbiAgICB9XG4gICAgaWYgKGNoaWxkLnBhcmVudCkge1xuICAgICAgY2hpbGQucGFyZW50LnJlbW92ZUNoaWxkKGNoaWxkKTtcbiAgICB9XG4gICAgdGhpcy5jaGlsZHJlbi5wdXNoKGNoaWxkKTtcbiAgICBpZiAodGhpcy5zb3J0YWJsZUNoaWxkcmVuKSB0aGlzLnNvcnREaXJ0eSA9IHRydWU7XG4gICAgY2hpbGQucGFyZW50ID0gdGhpcztcbiAgICBjaGlsZC5kaWRDaGFuZ2UgPSB0cnVlO1xuICAgIGNoaWxkLl91cGRhdGVGbGFncyA9IDE1O1xuICAgIGlmIChyZW5kZXJHcm91cCkge1xuICAgICAgcmVuZGVyR3JvdXAuYWRkQ2hpbGQoY2hpbGQpO1xuICAgIH1cbiAgICB0aGlzLmVtaXQoXCJjaGlsZEFkZGVkXCIsIGNoaWxkLCB0aGlzLCB0aGlzLmNoaWxkcmVuLmxlbmd0aCAtIDEpO1xuICAgIGNoaWxkLmVtaXQoXCJhZGRlZFwiLCB0aGlzKTtcbiAgICB0aGlzLl9kaWRWaWV3Q2hhbmdlVGljaysrO1xuICAgIGlmIChjaGlsZC5fekluZGV4ICE9PSAwKSB7XG4gICAgICBjaGlsZC5kZXB0aE9mQ2hpbGRNb2RpZmllZCgpO1xuICAgIH1cbiAgICByZXR1cm4gY2hpbGQ7XG4gIH1cbiAgLyoqXG4gICAqIFJlbW92ZXMgb25lIG9yIG1vcmUgY2hpbGRyZW4gZnJvbSB0aGUgY29udGFpbmVyLlxuICAgKiBXaGVuIHJlbW92aW5nIG11bHRpcGxlIGNoaWxkcmVuLCBldmVudHMgd2lsbCBiZSB0cmlnZ2VyZWQgZm9yIGVhY2ggY2hpbGQgaW4gc2VxdWVuY2UuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIFJlbW92ZSBhIHNpbmdsZSBjaGlsZFxuICAgKiBjb25zdCByZW1vdmVkID0gY29udGFpbmVyLnJlbW92ZUNoaWxkKHNwcml0ZSk7XG4gICAqXG4gICAqIC8vIFJlbW92ZSBtdWx0aXBsZSBjaGlsZHJlblxuICAgKiBjb25zdCBiZyA9IGNvbnRhaW5lci5yZW1vdmVDaGlsZChiYWNrZ3JvdW5kLCBwbGF5ZXIsIHVzZXJJbnRlcmZhY2UpO1xuICAgKlxuICAgKiAvLyBSZW1vdmUgd2l0aCB0eXBlIGNoZWNraW5nXG4gICAqIGNvbnN0IHNwcml0ZSA9IGNvbnRhaW5lci5yZW1vdmVDaGlsZDxTcHJpdGU+KGNoaWxkU3ByaXRlKTtcbiAgICogc3ByaXRlLnRleHR1cmUgPSBuZXdUZXh0dXJlO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIGNoaWxkcmVuIC0gVGhlIENvbnRhaW5lcihzKSB0byByZW1vdmVcbiAgICogQHJldHVybnMgVGhlIGZpcnN0IGNoaWxkIHRoYXQgd2FzIHJlbW92ZWRcbiAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI2FkZENoaWxkfSBGb3IgYWRkaW5nIGNoaWxkcmVuXG4gICAqIEBzZWUge0BsaW5rIENvbnRhaW5lciNyZW1vdmVDaGlsZHJlbn0gRm9yIHJlbW92aW5nIG11bHRpcGxlIGNoaWxkcmVuXG4gICAqL1xuICByZW1vdmVDaGlsZCguLi5jaGlsZHJlbikge1xuICAgIGlmIChjaGlsZHJlbi5sZW5ndGggPiAxKSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHRoaXMucmVtb3ZlQ2hpbGQoY2hpbGRyZW5baV0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGNoaWxkcmVuWzBdO1xuICAgIH1cbiAgICBjb25zdCBjaGlsZCA9IGNoaWxkcmVuWzBdO1xuICAgIGNvbnN0IGluZGV4ID0gdGhpcy5jaGlsZHJlbi5pbmRleE9mKGNoaWxkKTtcbiAgICBpZiAoaW5kZXggPiAtMSkge1xuICAgICAgdGhpcy5fZGlkVmlld0NoYW5nZVRpY2srKztcbiAgICAgIHRoaXMuY2hpbGRyZW4uc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgIGlmICh0aGlzLnJlbmRlckdyb3VwKSB7XG4gICAgICAgIHRoaXMucmVuZGVyR3JvdXAucmVtb3ZlQ2hpbGQoY2hpbGQpO1xuICAgICAgfSBlbHNlIGlmICh0aGlzLnBhcmVudFJlbmRlckdyb3VwKSB7XG4gICAgICAgIHRoaXMucGFyZW50UmVuZGVyR3JvdXAucmVtb3ZlQ2hpbGQoY2hpbGQpO1xuICAgICAgfVxuICAgICAgaWYgKGNoaWxkLnBhcmVudFJlbmRlckxheWVyKSB7XG4gICAgICAgIGNoaWxkLnBhcmVudFJlbmRlckxheWVyLmRldGFjaChjaGlsZCk7XG4gICAgICB9XG4gICAgICBjaGlsZC5wYXJlbnQgPSBudWxsO1xuICAgICAgdGhpcy5lbWl0KFwiY2hpbGRSZW1vdmVkXCIsIGNoaWxkLCB0aGlzLCBpbmRleCk7XG4gICAgICBjaGlsZC5lbWl0KFwicmVtb3ZlZFwiLCB0aGlzKTtcbiAgICB9XG4gICAgcmV0dXJuIGNoaWxkO1xuICB9XG4gIC8qKiBAaWdub3JlICovXG4gIF9vblVwZGF0ZShwb2ludCkge1xuICAgIGlmIChwb2ludCkge1xuICAgICAgaWYgKHBvaW50ID09PSB0aGlzLl9za2V3KSB7XG4gICAgICAgIHRoaXMuX3VwZGF0ZVNrZXcoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5fZGlkQ29udGFpbmVyQ2hhbmdlVGljaysrO1xuICAgIGlmICh0aGlzLmRpZENoYW5nZSkgcmV0dXJuO1xuICAgIHRoaXMuZGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICBpZiAodGhpcy5wYXJlbnRSZW5kZXJHcm91cCkge1xuICAgICAgdGhpcy5wYXJlbnRSZW5kZXJHcm91cC5vbkNoaWxkVXBkYXRlKHRoaXMpO1xuICAgIH1cbiAgfVxuICBzZXQgaXNSZW5kZXJHcm91cCh2YWx1ZSkge1xuICAgIGlmICghIXRoaXMucmVuZGVyR3JvdXAgPT09IHZhbHVlKSByZXR1cm47XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICB0aGlzLmVuYWJsZVJlbmRlckdyb3VwKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuZGlzYWJsZVJlbmRlckdyb3VwKCk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRydWUgaWYgdGhpcyBjb250YWluZXIgaXMgYSByZW5kZXIgZ3JvdXAuXG4gICAqIFRoaXMgbWVhbnMgdGhhdCBpdCB3aWxsIGJlIHJlbmRlcmVkIGFzIGEgc2VwYXJhdGUgcGFzcywgd2l0aCBpdHMgb3duIHNldCBvZiBpbnN0cnVjdGlvbnNcbiAgICogQGFkdmFuY2VkXG4gICAqL1xuICBnZXQgaXNSZW5kZXJHcm91cCgpIHtcbiAgICByZXR1cm4gISF0aGlzLnJlbmRlckdyb3VwO1xuICB9XG4gIC8qKlxuICAgKiBDYWxsaW5nIHRoaXMgZW5hYmxlcyBhIHJlbmRlciBncm91cCBmb3IgdGhpcyBjb250YWluZXIuXG4gICAqIFRoaXMgbWVhbnMgaXQgd2lsbCBiZSByZW5kZXJlZCBhcyBhIHNlcGFyYXRlIHNldCBvZiBpbnN0cnVjdGlvbnMuXG4gICAqIFRoZSB0cmFuc2Zvcm0gb2YgdGhlIGNvbnRhaW5lciB3aWxsIGFsc28gYmUgaGFuZGxlZCBvbiB0aGUgR1BVIHJhdGhlciB0aGFuIHRoZSBDUFUuXG4gICAqIEBhZHZhbmNlZFxuICAgKi9cbiAgZW5hYmxlUmVuZGVyR3JvdXAoKSB7XG4gICAgaWYgKHRoaXMucmVuZGVyR3JvdXApIHJldHVybjtcbiAgICBjb25zdCBwYXJlbnRSZW5kZXJHcm91cCA9IHRoaXMucGFyZW50UmVuZGVyR3JvdXA7XG4gICAgcGFyZW50UmVuZGVyR3JvdXA/LnJlbW92ZUNoaWxkKHRoaXMpO1xuICAgIHRoaXMucmVuZGVyR3JvdXAgPSBCaWdQb29sLmdldChSZW5kZXJHcm91cCwgdGhpcyk7XG4gICAgdGhpcy5ncm91cFRyYW5zZm9ybSA9IE1hdHJpeC5JREVOVElUWTtcbiAgICBwYXJlbnRSZW5kZXJHcm91cD8uYWRkQ2hpbGQodGhpcyk7XG4gICAgdGhpcy5fdXBkYXRlSXNTaW1wbGUoKTtcbiAgfVxuICAvKipcbiAgICogVGhpcyB3aWxsIGRpc2FibGUgdGhlIHJlbmRlciBncm91cCBmb3IgdGhpcyBjb250YWluZXIuXG4gICAqIEBhZHZhbmNlZFxuICAgKi9cbiAgZGlzYWJsZVJlbmRlckdyb3VwKCkge1xuICAgIGlmICghdGhpcy5yZW5kZXJHcm91cCkgcmV0dXJuO1xuICAgIGNvbnN0IHBhcmVudFJlbmRlckdyb3VwID0gdGhpcy5wYXJlbnRSZW5kZXJHcm91cDtcbiAgICBwYXJlbnRSZW5kZXJHcm91cD8ucmVtb3ZlQ2hpbGQodGhpcyk7XG4gICAgQmlnUG9vbC5yZXR1cm4odGhpcy5yZW5kZXJHcm91cCk7XG4gICAgdGhpcy5yZW5kZXJHcm91cCA9IG51bGw7XG4gICAgdGhpcy5ncm91cFRyYW5zZm9ybSA9IHRoaXMucmVsYXRpdmVHcm91cFRyYW5zZm9ybTtcbiAgICBwYXJlbnRSZW5kZXJHcm91cD8uYWRkQ2hpbGQodGhpcyk7XG4gICAgdGhpcy5fdXBkYXRlSXNTaW1wbGUoKTtcbiAgfVxuICAvKiogQGlnbm9yZSAqL1xuICBfdXBkYXRlSXNTaW1wbGUoKSB7XG4gICAgdGhpcy5pc1NpbXBsZSA9ICF0aGlzLnJlbmRlckdyb3VwICYmIHRoaXMuZWZmZWN0cy5sZW5ndGggPT09IDA7XG4gIH1cbiAgLyoqXG4gICAqIEN1cnJlbnQgdHJhbnNmb3JtIG9mIHRoZSBvYmplY3QgYmFzZWQgb24gd29ybGQgKHBhcmVudCkgZmFjdG9ycy5cbiAgICpcbiAgICogVGhpcyBtYXRyaXggcmVwcmVzZW50cyB0aGUgYWJzb2x1dGUgdHJhbnNmb3JtYXRpb24gaW4gdGhlIHNjZW5lIGdyYXBoLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBHZXQgd29ybGQgcG9zaXRpb25cbiAgICogY29uc3Qgd29ybGRQb3MgPSBjb250YWluZXIud29ybGRUcmFuc2Zvcm07XG4gICAqIGNvbnNvbGUubG9nKGBXb3JsZCBwb3NpdGlvbjogKCR7d29ybGRQb3MudHh9LCAke3dvcmxkUG9zLnR5fSlgKTtcbiAgICogYGBgXG4gICAqIEByZWFkb25seVxuICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjbG9jYWxUcmFuc2Zvcm19IEZvciBsb2NhbCBzcGFjZSB0cmFuc2Zvcm1cbiAgICovXG4gIGdldCB3b3JsZFRyYW5zZm9ybSgpIHtcbiAgICB0aGlzLl93b3JsZFRyYW5zZm9ybSB8fCAodGhpcy5fd29ybGRUcmFuc2Zvcm0gPSBuZXcgTWF0cml4KCkpO1xuICAgIGlmICh0aGlzLnJlbmRlckdyb3VwKSB7XG4gICAgICB0aGlzLl93b3JsZFRyYW5zZm9ybS5jb3B5RnJvbSh0aGlzLnJlbmRlckdyb3VwLndvcmxkVHJhbnNmb3JtKTtcbiAgICB9IGVsc2UgaWYgKHRoaXMucGFyZW50UmVuZGVyR3JvdXApIHtcbiAgICAgIHRoaXMuX3dvcmxkVHJhbnNmb3JtLmFwcGVuZEZyb20odGhpcy5yZWxhdGl2ZUdyb3VwVHJhbnNmb3JtLCB0aGlzLnBhcmVudFJlbmRlckdyb3VwLndvcmxkVHJhbnNmb3JtKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX3dvcmxkVHJhbnNmb3JtO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgcG9zaXRpb24gb2YgdGhlIGNvbnRhaW5lciBvbiB0aGUgeCBheGlzIHJlbGF0aXZlIHRvIHRoZSBsb2NhbCBjb29yZGluYXRlcyBvZiB0aGUgcGFyZW50LlxuICAgKlxuICAgKiBBbiBhbGlhcyB0byBwb3NpdGlvbi54XG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHBvc2l0aW9uXG4gICAqIGNvbnRhaW5lci54ID0gMTAwO1xuICAgKiBgYGBcbiAgICovXG4gIGdldCB4KCkge1xuICAgIHJldHVybiB0aGlzLl9wb3NpdGlvbi54O1xuICB9XG4gIHNldCB4KHZhbHVlKSB7XG4gICAgdGhpcy5fcG9zaXRpb24ueCA9IHZhbHVlO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgcG9zaXRpb24gb2YgdGhlIGNvbnRhaW5lciBvbiB0aGUgeSBheGlzIHJlbGF0aXZlIHRvIHRoZSBsb2NhbCBjb29yZGluYXRlcyBvZiB0aGUgcGFyZW50LlxuICAgKlxuICAgKiBBbiBhbGlhcyB0byBwb3NpdGlvbi55XG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHBvc2l0aW9uXG4gICAqIGNvbnRhaW5lci55ID0gMjAwO1xuICAgKiBgYGBcbiAgICovXG4gIGdldCB5KCkge1xuICAgIHJldHVybiB0aGlzLl9wb3NpdGlvbi55O1xuICB9XG4gIHNldCB5KHZhbHVlKSB7XG4gICAgdGhpcy5fcG9zaXRpb24ueSA9IHZhbHVlO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgY29vcmRpbmF0ZSBvZiB0aGUgb2JqZWN0IHJlbGF0aXZlIHRvIHRoZSBsb2NhbCBjb29yZGluYXRlcyBvZiB0aGUgcGFyZW50LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBwb3NpdGlvbiBzZXR0aW5nXG4gICAqIGNvbnRhaW5lci5wb3NpdGlvbi5zZXQoMTAwLCAyMDApO1xuICAgKiBjb250YWluZXIucG9zaXRpb24uc2V0KDEwMCk7IC8vIFNldHMgYm90aCB4IGFuZCB5IHRvIDEwMFxuICAgKiAvLyBVc2luZyBwb2ludCBkYXRhXG4gICAqIGNvbnRhaW5lci5wb3NpdGlvbiA9IHsgeDogNTAsIHk6IDc1IH07XG4gICAqIGBgYFxuICAgKiBAc2luY2UgNC4wLjBcbiAgICovXG4gIGdldCBwb3NpdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5fcG9zaXRpb247XG4gIH1cbiAgc2V0IHBvc2l0aW9uKHZhbHVlKSB7XG4gICAgdGhpcy5fcG9zaXRpb24uY29weUZyb20odmFsdWUpO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgcm90YXRpb24gb2YgdGhlIG9iamVjdCBpbiByYWRpYW5zLlxuICAgKlxuICAgKiA+IFshTk9URV0gJ3JvdGF0aW9uJyBhbmQgJ2FuZ2xlJyBoYXZlIHRoZSBzYW1lIGVmZmVjdCBvbiBhIGRpc3BsYXkgb2JqZWN0O1xuICAgKiA+IHJvdGF0aW9uIGlzIGluIHJhZGlhbnMsIGFuZ2xlIGlzIGluIGRlZ3JlZXMuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHJvdGF0aW9uXG4gICAqIGNvbnRhaW5lci5yb3RhdGlvbiA9IE1hdGguUEkgLyA0OyAvLyA0NSBkZWdyZWVzXG4gICAqXG4gICAqIC8vIENvbnZlcnQgZnJvbSBkZWdyZWVzXG4gICAqIGNvbnN0IGRlZ3JlZXMgPSA0NTtcbiAgICogY29udGFpbmVyLnJvdGF0aW9uID0gZGVncmVlcyAqIE1hdGguUEkgLyAxODA7XG4gICAqXG4gICAqIC8vIFJvdGF0ZSBhcm91bmQgY2VudGVyXG4gICAqIGNvbnRhaW5lci5waXZvdC5zZXQoY29udGFpbmVyLndpZHRoIC8gMiwgY29udGFpbmVyLmhlaWdodCAvIDIpO1xuICAgKiBjb250YWluZXIucm90YXRpb24gPSBNYXRoLlBJOyAvLyAxODAgZGVncmVlc1xuICAgKlxuICAgKiAvLyBSb3RhdGUgYXJvdW5kIGNlbnRlciB3aXRoIG9yaWdpblxuICAgKiBjb250YWluZXIub3JpZ2luLnNldChjb250YWluZXIud2lkdGggLyAyLCBjb250YWluZXIuaGVpZ2h0IC8gMik7XG4gICAqIGNvbnRhaW5lci5yb3RhdGlvbiA9IE1hdGguUEk7IC8vIDE4MCBkZWdyZWVzXG4gICAqIGBgYFxuICAgKi9cbiAgZ2V0IHJvdGF0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLl9yb3RhdGlvbjtcbiAgfVxuICBzZXQgcm90YXRpb24odmFsdWUpIHtcbiAgICBpZiAodGhpcy5fcm90YXRpb24gIT09IHZhbHVlKSB7XG4gICAgICB0aGlzLl9yb3RhdGlvbiA9IHZhbHVlO1xuICAgICAgdGhpcy5fb25VcGRhdGUodGhpcy5fc2tldyk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBUaGUgYW5nbGUgb2YgdGhlIG9iamVjdCBpbiBkZWdyZWVzLlxuICAgKlxuICAgKiA+IFshTk9URV0gJ3JvdGF0aW9uJyBhbmQgJ2FuZ2xlJyBoYXZlIHRoZSBzYW1lIGVmZmVjdCBvbiBhIGRpc3BsYXkgb2JqZWN0O1xuICAgKiA+IHJvdGF0aW9uIGlzIGluIHJhZGlhbnMsIGFuZ2xlIGlzIGluIGRlZ3JlZXMuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGFuZ2xlIHJvdGF0aW9uXG4gICAqIHNwcml0ZS5hbmdsZSA9IDQ1OyAvLyA0NSBkZWdyZWVzXG4gICAqXG4gICAqIC8vIFJvdGF0ZSBhcm91bmQgY2VudGVyXG4gICAqIHNwcml0ZS5waXZvdC5zZXQoc3ByaXRlLndpZHRoIC8gMiwgc3ByaXRlLmhlaWdodCAvIDIpO1xuICAgKiBzcHJpdGUuYW5nbGUgPSAxODA7IC8vIEhhbGYgcm90YXRpb25cbiAgICpcbiAgICogLy8gUm90YXRlIGFyb3VuZCBjZW50ZXIgd2l0aCBvcmlnaW5cbiAgICogc3ByaXRlLm9yaWdpbi5zZXQoc3ByaXRlLndpZHRoIC8gMiwgc3ByaXRlLmhlaWdodCAvIDIpO1xuICAgKiBzcHJpdGUuYW5nbGUgPSAxODA7IC8vIEhhbGYgcm90YXRpb25cbiAgICpcbiAgICogLy8gUmVzZXQgcm90YXRpb25cbiAgICogc3ByaXRlLmFuZ2xlID0gMDtcbiAgICogYGBgXG4gICAqL1xuICBnZXQgYW5nbGUoKSB7XG4gICAgcmV0dXJuIHRoaXMucm90YXRpb24gKiBSQURfVE9fREVHO1xuICB9XG4gIHNldCBhbmdsZSh2YWx1ZSkge1xuICAgIHRoaXMucm90YXRpb24gPSB2YWx1ZSAqIERFR19UT19SQUQ7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBjZW50ZXIgb2Ygcm90YXRpb24sIHNjYWxpbmcsIGFuZCBza2V3aW5nIGZvciB0aGlzIGRpc3BsYXkgb2JqZWN0IGluIGl0cyBsb2NhbCBzcGFjZS5cbiAgICogVGhlIGBwb3NpdGlvbmAgaXMgdGhlIHByb2plY3Rpb24gb2YgYHBpdm90YCBpbiB0aGUgcGFyZW50J3MgbG9jYWwgc3BhY2UuXG4gICAqXG4gICAqIEJ5IGRlZmF1bHQsIHRoZSBwaXZvdCBpcyB0aGUgb3JpZ2luICgwLCAwKS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gUm90YXRlIGFyb3VuZCBjZW50ZXJcbiAgICogY29udGFpbmVyLnBpdm90LnNldChjb250YWluZXIud2lkdGggLyAyLCBjb250YWluZXIuaGVpZ2h0IC8gMik7XG4gICAqIGNvbnRhaW5lci5yb3RhdGlvbiA9IE1hdGguUEk7IC8vIFJvdGF0ZXMgYXJvdW5kIGNlbnRlclxuICAgKiBgYGBcbiAgICogQHNpbmNlIDQuMC4wXG4gICAqL1xuICBnZXQgcGl2b3QoKSB7XG4gICAgaWYgKHRoaXMuX3Bpdm90ID09PSBkZWZhdWx0UGl2b3QpIHtcbiAgICAgIHRoaXMuX3Bpdm90ID0gbmV3IE9ic2VydmFibGVQb2ludCh0aGlzLCAwLCAwKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX3Bpdm90O1xuICB9XG4gIHNldCBwaXZvdCh2YWx1ZSkge1xuICAgIGlmICh0aGlzLl9waXZvdCA9PT0gZGVmYXVsdFBpdm90KSB7XG4gICAgICB0aGlzLl9waXZvdCA9IG5ldyBPYnNlcnZhYmxlUG9pbnQodGhpcywgMCwgMCk7XG4gICAgICBpZiAodGhpcy5fb3JpZ2luICE9PSBkZWZhdWx0T3JpZ2luKSB7XG4gICAgICAgIHdhcm4oYFNldHRpbmcgYm90aCBhIHBpdm90IGFuZCBvcmlnaW4gb24gYSBDb250YWluZXIgaXMgbm90IHJlY29tbWVuZGVkLiBUaGlzIGNhbiBsZWFkIHRvIHVuZXhwZWN0ZWQgYmVoYXZpb3IgaWYgbm90IGhhbmRsZWQgY2FyZWZ1bGx5LmApO1xuICAgICAgfVxuICAgIH1cbiAgICB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIgPyB0aGlzLl9waXZvdC5zZXQodmFsdWUpIDogdGhpcy5fcGl2b3QuY29weUZyb20odmFsdWUpO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgc2tldyBmYWN0b3IgZm9yIHRoZSBvYmplY3QgaW4gcmFkaWFucy4gU2tld2luZyBpcyBhIHRyYW5zZm9ybWF0aW9uIHRoYXQgZGlzdG9ydHNcbiAgICogdGhlIG9iamVjdCBieSByb3RhdGluZyBpdCBkaWZmZXJlbnRseSBhdCBlYWNoIHBvaW50LCBjcmVhdGluZyBhIG5vbi11bmlmb3JtIHNoYXBlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBza2V3aW5nXG4gICAqIGNvbnRhaW5lci5za2V3LnNldCgwLjUsIDApOyAvLyBTa2V3IGhvcml6b250YWxseVxuICAgKiBjb250YWluZXIuc2tldy5zZXQoMCwgMC41KTsgLy8gU2tldyB2ZXJ0aWNhbGx5XG4gICAqXG4gICAqIC8vIFNrZXcgd2l0aCBwb2ludCBkYXRhXG4gICAqIGNvbnRhaW5lci5za2V3ID0geyB4OiAwLjMsIHk6IDAuMyB9OyAvLyBEaWFnb25hbCBza2V3XG4gICAqXG4gICAqIC8vIFJlc2V0IHNrZXdcbiAgICogY29udGFpbmVyLnNrZXcuc2V0KDAsIDApO1xuICAgKlxuICAgKiAvLyBBbmltYXRlIHNrZXdcbiAgICogYXBwLnRpY2tlci5hZGQoKCkgPT4ge1xuICAgKiAgICAgLy8gQ3JlYXRlIHdhdmUgZWZmZWN0XG4gICAqICAgICBjb250YWluZXIuc2tldy54ID0gTWF0aC5zaW4oRGF0ZS5ub3coKSAvIDEwMDApICogMC4zO1xuICAgKiB9KTtcbiAgICpcbiAgICogLy8gQ29tYmluZSB3aXRoIHJvdGF0aW9uXG4gICAqIGNvbnRhaW5lci5yb3RhdGlvbiA9IE1hdGguUEkgLyA0OyAvLyA0NSBkZWdyZWVzXG4gICAqIGNvbnRhaW5lci5za2V3LnNldCgwLjIsIDAuMik7IC8vIFNrZXcgdGhlIHJvdGF0ZWQgb2JqZWN0XG4gICAqIGBgYFxuICAgKiBAc2luY2UgNC4wLjBcbiAgICogQHR5cGUge09ic2VydmFibGVQb2ludH0gUG9pbnQtbGlrZSBvYmplY3Qgd2l0aCB4L3kgcHJvcGVydGllcyBpbiByYWRpYW5zXG4gICAqIEBkZWZhdWx0IHt4OiAwLCB5OiAwfVxuICAgKi9cbiAgZ2V0IHNrZXcoKSB7XG4gICAgaWYgKHRoaXMuX3NrZXcgPT09IGRlZmF1bHRTa2V3KSB7XG4gICAgICB0aGlzLl9za2V3ID0gbmV3IE9ic2VydmFibGVQb2ludCh0aGlzLCAwLCAwKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX3NrZXc7XG4gIH1cbiAgc2V0IHNrZXcodmFsdWUpIHtcbiAgICBpZiAodGhpcy5fc2tldyA9PT0gZGVmYXVsdFNrZXcpIHtcbiAgICAgIHRoaXMuX3NrZXcgPSBuZXcgT2JzZXJ2YWJsZVBvaW50KHRoaXMsIDAsIDApO1xuICAgIH1cbiAgICB0aGlzLl9za2V3LmNvcHlGcm9tKHZhbHVlKTtcbiAgfVxuICAvKipcbiAgICogVGhlIHNjYWxlIGZhY3RvcnMgb2YgdGhpcyBvYmplY3QgYWxvbmcgdGhlIGxvY2FsIGNvb3JkaW5hdGUgYXhlcy5cbiAgICpcbiAgICogVGhlIGRlZmF1bHQgc2NhbGUgaXMgKDEsIDEpLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBzY2FsaW5nXG4gICAqIGNvbnRhaW5lci5zY2FsZS5zZXQoMiwgMik7IC8vIFNjYWxlcyB0byBkb3VibGUgc2l6ZVxuICAgKiBjb250YWluZXIuc2NhbGUuc2V0KDIpOyAvLyBTY2FsZXMgdW5pZm9ybWx5IHRvIGRvdWJsZSBzaXplXG4gICAqIGNvbnRhaW5lci5zY2FsZSA9IDI7IC8vIFNjYWxlcyB1bmlmb3JtbHkgdG8gZG91YmxlIHNpemVcbiAgICogLy8gU2NhbGUgdG8gYSBzcGVjaWZpYyB3aWR0aCBhbmQgaGVpZ2h0XG4gICAqIGNvbnRhaW5lci5zZXRTaXplKDIwMCwgMTAwKTsgLy8gU2V0cyB3aWR0aCB0byAyMDAgYW5kIGhlaWdodCB0byAxMDBcbiAgICogYGBgXG4gICAqIEBzaW5jZSA0LjAuMFxuICAgKi9cbiAgZ2V0IHNjYWxlKCkge1xuICAgIGlmICh0aGlzLl9zY2FsZSA9PT0gZGVmYXVsdFNjYWxlKSB7XG4gICAgICB0aGlzLl9zY2FsZSA9IG5ldyBPYnNlcnZhYmxlUG9pbnQodGhpcywgMSwgMSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9zY2FsZTtcbiAgfVxuICBzZXQgc2NhbGUodmFsdWUpIHtcbiAgICBpZiAodGhpcy5fc2NhbGUgPT09IGRlZmF1bHRTY2FsZSkge1xuICAgICAgdGhpcy5fc2NhbGUgPSBuZXcgT2JzZXJ2YWJsZVBvaW50KHRoaXMsIDAsIDApO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICB2YWx1ZSA9IHBhcnNlRmxvYXQodmFsdWUpO1xuICAgIH1cbiAgICB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIgPyB0aGlzLl9zY2FsZS5zZXQodmFsdWUpIDogdGhpcy5fc2NhbGUuY29weUZyb20odmFsdWUpO1xuICB9XG4gIC8qKlxuICAgKiBAZXhwZXJpbWVudGFsXG4gICAqIFRoZSBvcmlnaW4gcG9pbnQgYXJvdW5kIHdoaWNoIHRoZSBjb250YWluZXIgcm90YXRlcyBhbmQgc2NhbGVzIHdpdGhvdXQgYWZmZWN0aW5nIGl0cyBwb3NpdGlvbi5cbiAgICogVW5saWtlIHBpdm90LCBjaGFuZ2luZyB0aGUgb3JpZ2luIHdpbGwgbm90IG1vdmUgdGhlIGNvbnRhaW5lcidzIHBvc2l0aW9uLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBSb3RhdGUgYXJvdW5kIGNlbnRlciBwb2ludFxuICAgKiBjb250YWluZXIub3JpZ2luLnNldChjb250YWluZXIud2lkdGggLyAyLCBjb250YWluZXIuaGVpZ2h0IC8gMik7XG4gICAqIGNvbnRhaW5lci5yb3RhdGlvbiA9IE1hdGguUEk7IC8vIFJvdGF0ZXMgYXJvdW5kIGNlbnRlclxuICAgKlxuICAgKiAvLyBSZXNldCBvcmlnaW5cbiAgICogY29udGFpbmVyLm9yaWdpbi5zZXQoMCwgMCk7XG4gICAqIGBgYFxuICAgKi9cbiAgZ2V0IG9yaWdpbigpIHtcbiAgICBpZiAodGhpcy5fb3JpZ2luID09PSBkZWZhdWx0T3JpZ2luKSB7XG4gICAgICB0aGlzLl9vcmlnaW4gPSBuZXcgT2JzZXJ2YWJsZVBvaW50KHRoaXMsIDAsIDApO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fb3JpZ2luO1xuICB9XG4gIHNldCBvcmlnaW4odmFsdWUpIHtcbiAgICBpZiAodGhpcy5fb3JpZ2luID09PSBkZWZhdWx0T3JpZ2luKSB7XG4gICAgICB0aGlzLl9vcmlnaW4gPSBuZXcgT2JzZXJ2YWJsZVBvaW50KHRoaXMsIDAsIDApO1xuICAgICAgaWYgKHRoaXMuX3Bpdm90ICE9PSBkZWZhdWx0UGl2b3QpIHtcbiAgICAgICAgd2FybihgU2V0dGluZyBib3RoIGEgcGl2b3QgYW5kIG9yaWdpbiBvbiBhIENvbnRhaW5lciBpcyBub3QgcmVjb21tZW5kZWQuIFRoaXMgY2FuIGxlYWQgdG8gdW5leHBlY3RlZCBiZWhhdmlvciBpZiBub3QgaGFuZGxlZCBjYXJlZnVsbHkuYCk7XG4gICAgICB9XG4gICAgfVxuICAgIHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIiA/IHRoaXMuX29yaWdpbi5zZXQodmFsdWUpIDogdGhpcy5fb3JpZ2luLmNvcHlGcm9tKHZhbHVlKTtcbiAgfVxuICAvKipcbiAgICogVGhlIHdpZHRoIG9mIHRoZSBDb250YWluZXIsIHNldHRpbmcgdGhpcyB3aWxsIGFjdHVhbGx5IG1vZGlmeSB0aGUgc2NhbGUgdG8gYWNoaWV2ZSB0aGUgdmFsdWUgc2V0LlxuICAgKiA+IFshTk9URV0gQ2hhbmdpbmcgdGhlIHdpZHRoIHdpbGwgYWRqdXN0IHRoZSBzY2FsZS54IHByb3BlcnR5IG9mIHRoZSBjb250YWluZXIgd2hpbGUgbWFpbnRhaW5pbmcgaXRzIGFzcGVjdCByYXRpby5cbiAgICogPiBbIU5PVEVdIElmIHlvdSB3YW50IHRvIHNldCBib3RoIHdpZHRoIGFuZCBoZWlnaHQgYXQgdGhlIHNhbWUgdGltZSwgdXNlIHtAbGluayBDb250YWluZXIjc2V0U2l6ZX1cbiAgICogYXMgaXQgaXMgbW9yZSBvcHRpbWl6ZWQgYnkgbm90IHJlY2FsY3VsYXRpbmcgdGhlIGxvY2FsIGJvdW5kcyB0d2ljZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgd2lkdGggc2V0dGluZ1xuICAgKiBjb250YWluZXIud2lkdGggPSAxMDA7XG4gICAqIC8vIE9wdGltaXplZCB3aWR0aCBzZXR0aW5nXG4gICAqIGNvbnRhaW5lci5zZXRTaXplKDEwMCwgMTAwKTtcbiAgICogYGBgXG4gICAqL1xuICBnZXQgd2lkdGgoKSB7XG4gICAgcmV0dXJuIE1hdGguYWJzKHRoaXMuc2NhbGUueCAqIHRoaXMuZ2V0TG9jYWxCb3VuZHMoKS53aWR0aCk7XG4gIH1cbiAgc2V0IHdpZHRoKHZhbHVlKSB7XG4gICAgY29uc3QgbG9jYWxXaWR0aCA9IHRoaXMuZ2V0TG9jYWxCb3VuZHMoKS53aWR0aDtcbiAgICB0aGlzLl9zZXRXaWR0aCh2YWx1ZSwgbG9jYWxXaWR0aCk7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBoZWlnaHQgb2YgdGhlIENvbnRhaW5lcixcbiAgICogPiBbIU5PVEVdIENoYW5naW5nIHRoZSBoZWlnaHQgd2lsbCBhZGp1c3QgdGhlIHNjYWxlLnkgcHJvcGVydHkgb2YgdGhlIGNvbnRhaW5lciB3aGlsZSBtYWludGFpbmluZyBpdHMgYXNwZWN0IHJhdGlvLlxuICAgKiA+IFshTk9URV0gSWYgeW91IHdhbnQgdG8gc2V0IGJvdGggd2lkdGggYW5kIGhlaWdodCBhdCB0aGUgc2FtZSB0aW1lLCB1c2Uge0BsaW5rIENvbnRhaW5lciNzZXRTaXplfVxuICAgKiBhcyBpdCBpcyBtb3JlIG9wdGltaXplZCBieSBub3QgcmVjYWxjdWxhdGluZyB0aGUgbG9jYWwgYm91bmRzIHR3aWNlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBoZWlnaHQgc2V0dGluZ1xuICAgKiBjb250YWluZXIuaGVpZ2h0ID0gMjAwO1xuICAgKiAvLyBPcHRpbWl6ZWQgaGVpZ2h0IHNldHRpbmdcbiAgICogY29udGFpbmVyLnNldFNpemUoMTAwLCAyMDApO1xuICAgKiBgYGBcbiAgICovXG4gIGdldCBoZWlnaHQoKSB7XG4gICAgcmV0dXJuIE1hdGguYWJzKHRoaXMuc2NhbGUueSAqIHRoaXMuZ2V0TG9jYWxCb3VuZHMoKS5oZWlnaHQpO1xuICB9XG4gIHNldCBoZWlnaHQodmFsdWUpIHtcbiAgICBjb25zdCBsb2NhbEhlaWdodCA9IHRoaXMuZ2V0TG9jYWxCb3VuZHMoKS5oZWlnaHQ7XG4gICAgdGhpcy5fc2V0SGVpZ2h0KHZhbHVlLCBsb2NhbEhlaWdodCk7XG4gIH1cbiAgLyoqXG4gICAqIFJldHJpZXZlcyB0aGUgc2l6ZSBvZiB0aGUgY29udGFpbmVyIGFzIGEgW1NpemVde0BsaW5rIFNpemV9IG9iamVjdC5cbiAgICpcbiAgICogVGhpcyBpcyBmYXN0ZXIgdGhhbiBnZXQgdGhlIHdpZHRoIGFuZCBoZWlnaHQgc2VwYXJhdGVseS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgc2l6ZSByZXRyaWV2YWxcbiAgICogY29uc3Qgc2l6ZSA9IGNvbnRhaW5lci5nZXRTaXplKCk7XG4gICAqIGNvbnNvbGUubG9nKGBTaXplOiAke3NpemUud2lkdGh9eCR7c2l6ZS5oZWlnaHR9YCk7XG4gICAqXG4gICAqIC8vIFJldXNlIGV4aXN0aW5nIHNpemUgb2JqZWN0XG4gICAqIGNvbnN0IHJldXNlU2l6ZSA9IHsgd2lkdGg6IDAsIGhlaWdodDogMCB9O1xuICAgKiBjb250YWluZXIuZ2V0U2l6ZShyZXVzZVNpemUpO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIG91dCAtIE9wdGlvbmFsIG9iamVjdCB0byBzdG9yZSB0aGUgc2l6ZSBpbi5cbiAgICogQHJldHVybnMgVGhlIHNpemUgb2YgdGhlIGNvbnRhaW5lci5cbiAgICovXG4gIGdldFNpemUob3V0KSB7XG4gICAgaWYgKCFvdXQpIHtcbiAgICAgIG91dCA9IHt9O1xuICAgIH1cbiAgICBjb25zdCBib3VuZHMgPSB0aGlzLmdldExvY2FsQm91bmRzKCk7XG4gICAgb3V0LndpZHRoID0gTWF0aC5hYnModGhpcy5zY2FsZS54ICogYm91bmRzLndpZHRoKTtcbiAgICBvdXQuaGVpZ2h0ID0gTWF0aC5hYnModGhpcy5zY2FsZS55ICogYm91bmRzLmhlaWdodCk7XG4gICAgcmV0dXJuIG91dDtcbiAgfVxuICAvKipcbiAgICogU2V0cyB0aGUgc2l6ZSBvZiB0aGUgY29udGFpbmVyIHRvIHRoZSBzcGVjaWZpZWQgd2lkdGggYW5kIGhlaWdodC5cbiAgICogVGhpcyBpcyBtb3JlIGVmZmljaWVudCB0aGFuIHNldHRpbmcgd2lkdGggYW5kIGhlaWdodCBzZXBhcmF0ZWx5IGFzIGl0IG9ubHkgcmVjYWxjdWxhdGVzIGJvdW5kcyBvbmNlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBzaXplIHNldHRpbmdcbiAgICogY29udGFpbmVyLnNldFNpemUoMTAwLCAyMDApO1xuICAgKlxuICAgKiAvLyBTZXQgdW5pZm9ybSBzaXplXG4gICAqIGNvbnRhaW5lci5zZXRTaXplKDEwMCk7IC8vIFNldHMgYm90aCB3aWR0aCBhbmQgaGVpZ2h0IHRvIDEwMFxuICAgKiBgYGBcbiAgICogQHBhcmFtIHZhbHVlIC0gVGhpcyBjYW4gYmUgZWl0aGVyIGEgbnVtYmVyIG9yIGEgW1NpemVde0BsaW5rIFNpemV9IG9iamVjdC5cbiAgICogQHBhcmFtIGhlaWdodCAtIFRoZSBoZWlnaHQgdG8gc2V0LiBEZWZhdWx0cyB0byB0aGUgdmFsdWUgb2YgYHdpZHRoYCBpZiBub3QgcHJvdmlkZWQuXG4gICAqL1xuICBzZXRTaXplKHZhbHVlLCBoZWlnaHQpIHtcbiAgICBjb25zdCBzaXplID0gdGhpcy5nZXRMb2NhbEJvdW5kcygpO1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIGhlaWdodCA9IHZhbHVlLmhlaWdodCA/PyB2YWx1ZS53aWR0aDtcbiAgICAgIHZhbHVlID0gdmFsdWUud2lkdGg7XG4gICAgfSBlbHNlIHtcbiAgICAgIGhlaWdodCA/PyAoaGVpZ2h0ID0gdmFsdWUpO1xuICAgIH1cbiAgICB2YWx1ZSAhPT0gdm9pZCAwICYmIHRoaXMuX3NldFdpZHRoKHZhbHVlLCBzaXplLndpZHRoKTtcbiAgICBoZWlnaHQgIT09IHZvaWQgMCAmJiB0aGlzLl9zZXRIZWlnaHQoaGVpZ2h0LCBzaXplLmhlaWdodCk7XG4gIH1cbiAgLyoqIENhbGxlZCB3aGVuIHRoZSBza2V3IG9yIHRoZSByb3RhdGlvbiBjaGFuZ2VzLiAqL1xuICBfdXBkYXRlU2tldygpIHtcbiAgICBjb25zdCByb3RhdGlvbiA9IHRoaXMuX3JvdGF0aW9uO1xuICAgIGNvbnN0IHNrZXcgPSB0aGlzLl9za2V3O1xuICAgIHRoaXMuX2N4ID0gTWF0aC5jb3Mocm90YXRpb24gKyBza2V3Ll95KTtcbiAgICB0aGlzLl9zeCA9IE1hdGguc2luKHJvdGF0aW9uICsgc2tldy5feSk7XG4gICAgdGhpcy5fY3kgPSAtTWF0aC5zaW4ocm90YXRpb24gLSBza2V3Ll94KTtcbiAgICB0aGlzLl9zeSA9IE1hdGguY29zKHJvdGF0aW9uIC0gc2tldy5feCk7XG4gIH1cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIHRyYW5zZm9ybSBwcm9wZXJ0aWVzIG9mIHRoZSBjb250YWluZXIuXG4gICAqIEFsbG93cyBwYXJ0aWFsIHVwZGF0ZXMgb2YgdHJhbnNmb3JtIHByb3BlcnRpZXMgZm9yIG9wdGltaXplZCBtYW5pcHVsYXRpb24uXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHRyYW5zZm9ybSB1cGRhdGVcbiAgICogY29udGFpbmVyLnVwZGF0ZVRyYW5zZm9ybSh7XG4gICAqICAgICB4OiAxMDAsXG4gICAqICAgICB5OiAyMDAsXG4gICAqICAgICByb3RhdGlvbjogTWF0aC5QSSAvIDRcbiAgICogfSk7XG4gICAqXG4gICAqIC8vIFNjYWxlIGFuZCByb3RhdGUgYXJvdW5kIGNlbnRlclxuICAgKiBzcHJpdGUudXBkYXRlVHJhbnNmb3JtKHtcbiAgICogICAgIHBpdm90WDogc3ByaXRlLndpZHRoIC8gMixcbiAgICogICAgIHBpdm90WTogc3ByaXRlLmhlaWdodCAvIDIsXG4gICAqICAgICBzY2FsZVg6IDIsXG4gICAqICAgICBzY2FsZVk6IDIsXG4gICAqICAgICByb3RhdGlvbjogTWF0aC5QSVxuICAgKiB9KTtcbiAgICpcbiAgICogLy8gVXBkYXRlIHBvc2l0aW9uIG9ubHlcbiAgICogYnV0dG9uLnVwZGF0ZVRyYW5zZm9ybSh7XG4gICAqICAgICB4OiBidXR0b24ueCArIDEwLCAvLyBNb3ZlIHJpZ2h0XG4gICAqICAgICB5OiBidXR0b24ueSAgICAgIC8vIEtlZXAgc2FtZSB5XG4gICAqIH0pO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIG9wdHMgLSBUcmFuc2Zvcm0gb3B0aW9ucyB0byB1cGRhdGVcbiAgICogQHBhcmFtIG9wdHMueCAtIFRoZSB4IHBvc2l0aW9uXG4gICAqIEBwYXJhbSBvcHRzLnkgLSBUaGUgeSBwb3NpdGlvblxuICAgKiBAcGFyYW0gb3B0cy5zY2FsZVggLSBUaGUgeC1heGlzIHNjYWxlIGZhY3RvclxuICAgKiBAcGFyYW0gb3B0cy5zY2FsZVkgLSBUaGUgeS1heGlzIHNjYWxlIGZhY3RvclxuICAgKiBAcGFyYW0gb3B0cy5yb3RhdGlvbiAtIFRoZSByb3RhdGlvbiBpbiByYWRpYW5zXG4gICAqIEBwYXJhbSBvcHRzLnNrZXdYIC0gVGhlIHgtYXhpcyBza2V3IGZhY3RvclxuICAgKiBAcGFyYW0gb3B0cy5za2V3WSAtIFRoZSB5LWF4aXMgc2tldyBmYWN0b3JcbiAgICogQHBhcmFtIG9wdHMucGl2b3RYIC0gVGhlIHgtYXhpcyBwaXZvdCBwb2ludFxuICAgKiBAcGFyYW0gb3B0cy5waXZvdFkgLSBUaGUgeS1heGlzIHBpdm90IHBvaW50XG4gICAqIEByZXR1cm5zIFRoaXMgY29udGFpbmVyLCBmb3IgY2hhaW5pbmdcbiAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI3NldEZyb21NYXRyaXh9IEZvciBtYXRyaXgtYmFzZWQgdHJhbnNmb3Jtc1xuICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjcG9zaXRpb259IEZvciBkaXJlY3QgcG9zaXRpb24gYWNjZXNzXG4gICAqL1xuICB1cGRhdGVUcmFuc2Zvcm0ob3B0cykge1xuICAgIHRoaXMucG9zaXRpb24uc2V0KFxuICAgICAgdHlwZW9mIG9wdHMueCA9PT0gXCJudW1iZXJcIiA/IG9wdHMueCA6IHRoaXMucG9zaXRpb24ueCxcbiAgICAgIHR5cGVvZiBvcHRzLnkgPT09IFwibnVtYmVyXCIgPyBvcHRzLnkgOiB0aGlzLnBvc2l0aW9uLnlcbiAgICApO1xuICAgIHRoaXMuc2NhbGUuc2V0KFxuICAgICAgdHlwZW9mIG9wdHMuc2NhbGVYID09PSBcIm51bWJlclwiID8gb3B0cy5zY2FsZVggOiB0aGlzLnNjYWxlLngsXG4gICAgICB0eXBlb2Ygb3B0cy5zY2FsZVkgPT09IFwibnVtYmVyXCIgPyBvcHRzLnNjYWxlWSA6IHRoaXMuc2NhbGUueVxuICAgICk7XG4gICAgdGhpcy5yb3RhdGlvbiA9IHR5cGVvZiBvcHRzLnJvdGF0aW9uID09PSBcIm51bWJlclwiID8gb3B0cy5yb3RhdGlvbiA6IHRoaXMucm90YXRpb247XG4gICAgdGhpcy5za2V3LnNldChcbiAgICAgIHR5cGVvZiBvcHRzLnNrZXdYID09PSBcIm51bWJlclwiID8gb3B0cy5za2V3WCA6IHRoaXMuc2tldy54LFxuICAgICAgdHlwZW9mIG9wdHMuc2tld1kgPT09IFwibnVtYmVyXCIgPyBvcHRzLnNrZXdZIDogdGhpcy5za2V3LnlcbiAgICApO1xuICAgIHRoaXMucGl2b3Quc2V0KFxuICAgICAgdHlwZW9mIG9wdHMucGl2b3RYID09PSBcIm51bWJlclwiID8gb3B0cy5waXZvdFggOiB0aGlzLnBpdm90LngsXG4gICAgICB0eXBlb2Ygb3B0cy5waXZvdFkgPT09IFwibnVtYmVyXCIgPyBvcHRzLnBpdm90WSA6IHRoaXMucGl2b3QueVxuICAgICk7XG4gICAgdGhpcy5vcmlnaW4uc2V0KFxuICAgICAgdHlwZW9mIG9wdHMub3JpZ2luWCA9PT0gXCJudW1iZXJcIiA/IG9wdHMub3JpZ2luWCA6IHRoaXMub3JpZ2luLngsXG4gICAgICB0eXBlb2Ygb3B0cy5vcmlnaW5ZID09PSBcIm51bWJlclwiID8gb3B0cy5vcmlnaW5ZIDogdGhpcy5vcmlnaW4ueVxuICAgICk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIGxvY2FsIHRyYW5zZm9ybSBwcm9wZXJ0aWVzIGJ5IGRlY29tcG9zaW5nIHRoZSBnaXZlbiBtYXRyaXguXG4gICAqIEV4dHJhY3RzIHBvc2l0aW9uLCBzY2FsZSwgcm90YXRpb24sIGFuZCBza2V3IGZyb20gYSB0cmFuc2Zvcm1hdGlvbiBtYXRyaXguXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIG1hdHJpeCB0cmFuc2Zvcm1cbiAgICogY29uc3QgbWF0cml4ID0gbmV3IE1hdHJpeCgpXG4gICAqICAgICAudHJhbnNsYXRlKDEwMCwgMTAwKVxuICAgKiAgICAgLnJvdGF0ZShNYXRoLlBJIC8gNClcbiAgICogICAgIC5zY2FsZSgyLCAyKTtcbiAgICpcbiAgICogY29udGFpbmVyLnNldEZyb21NYXRyaXgobWF0cml4KTtcbiAgICpcbiAgICogLy8gQ29weSB0cmFuc2Zvcm0gZnJvbSBhbm90aGVyIGNvbnRhaW5lclxuICAgKiBjb25zdCBzb3VyY2UgPSBuZXcgQ29udGFpbmVyKCk7XG4gICAqIHNvdXJjZS5wb3NpdGlvbi5zZXQoMTAwLCAxMDApO1xuICAgKiBzb3VyY2Uucm90YXRpb24gPSBNYXRoLlBJIC8gMjtcbiAgICpcbiAgICogdGFyZ2V0LnNldEZyb21NYXRyaXgoc291cmNlLmxvY2FsVHJhbnNmb3JtKTtcbiAgICpcbiAgICogLy8gUmVzZXQgdHJhbnNmb3JtXG4gICAqIGNvbnRhaW5lci5zZXRGcm9tTWF0cml4KE1hdHJpeC5JREVOVElUWSk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gbWF0cml4IC0gVGhlIG1hdHJpeCB0byB1c2UgZm9yIHVwZGF0aW5nIHRoZSB0cmFuc2Zvcm1cbiAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI3VwZGF0ZVRyYW5zZm9ybX0gRm9yIHByb3BlcnR5LWJhc2VkIHVwZGF0ZXNcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4I2RlY29tcG9zZX0gRm9yIG1hdHJpeCBkZWNvbXBvc2l0aW9uIGRldGFpbHNcbiAgICovXG4gIHNldEZyb21NYXRyaXgobWF0cml4KSB7XG4gICAgbWF0cml4LmRlY29tcG9zZSh0aGlzKTtcbiAgfVxuICAvKiogVXBkYXRlcyB0aGUgbG9jYWwgdHJhbnNmb3JtLiAqL1xuICB1cGRhdGVMb2NhbFRyYW5zZm9ybSgpIHtcbiAgICBjb25zdCBsb2NhbFRyYW5zZm9ybUNoYW5nZUlkID0gdGhpcy5fZGlkQ29udGFpbmVyQ2hhbmdlVGljaztcbiAgICBpZiAodGhpcy5fZGlkTG9jYWxUcmFuc2Zvcm1DaGFuZ2VJZCA9PT0gbG9jYWxUcmFuc2Zvcm1DaGFuZ2VJZCkgcmV0dXJuO1xuICAgIHRoaXMuX2RpZExvY2FsVHJhbnNmb3JtQ2hhbmdlSWQgPSBsb2NhbFRyYW5zZm9ybUNoYW5nZUlkO1xuICAgIGNvbnN0IGx0ID0gdGhpcy5sb2NhbFRyYW5zZm9ybTtcbiAgICBjb25zdCBzY2FsZSA9IHRoaXMuX3NjYWxlO1xuICAgIGNvbnN0IHBpdm90ID0gdGhpcy5fcGl2b3Q7XG4gICAgY29uc3Qgb3JpZ2luID0gdGhpcy5fb3JpZ2luO1xuICAgIGNvbnN0IHBvc2l0aW9uID0gdGhpcy5fcG9zaXRpb247XG4gICAgY29uc3Qgc3ggPSBzY2FsZS5feDtcbiAgICBjb25zdCBzeSA9IHNjYWxlLl95O1xuICAgIGNvbnN0IHB4ID0gcGl2b3QuX3g7XG4gICAgY29uc3QgcHkgPSBwaXZvdC5feTtcbiAgICBjb25zdCBveCA9IC1vcmlnaW4uX3g7XG4gICAgY29uc3Qgb3kgPSAtb3JpZ2luLl95O1xuICAgIGx0LmEgPSB0aGlzLl9jeCAqIHN4O1xuICAgIGx0LmIgPSB0aGlzLl9zeCAqIHN4O1xuICAgIGx0LmMgPSB0aGlzLl9jeSAqIHN5O1xuICAgIGx0LmQgPSB0aGlzLl9zeSAqIHN5O1xuICAgIGx0LnR4ID0gcG9zaXRpb24uX3ggLSAocHggKiBsdC5hICsgcHkgKiBsdC5jKSArIChveCAqIGx0LmEgKyBveSAqIGx0LmMpIC0gb3g7XG4gICAgbHQudHkgPSBwb3NpdGlvbi5feSAtIChweCAqIGx0LmIgKyBweSAqIGx0LmQpICsgKG94ICogbHQuYiArIG95ICogbHQuZCkgLSBveTtcbiAgfVxuICAvLyAvIC8vLy8vIGNvbG9yIHJlbGF0ZWQgc3R1ZmZcbiAgc2V0IGFscGhhKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlID09PSB0aGlzLmxvY2FsQWxwaGEpIHJldHVybjtcbiAgICB0aGlzLmxvY2FsQWxwaGEgPSB2YWx1ZTtcbiAgICB0aGlzLl91cGRhdGVGbGFncyB8PSBVUERBVEVfQ09MT1I7XG4gICAgdGhpcy5fb25VcGRhdGUoKTtcbiAgfVxuICAvKipcbiAgICogVGhlIG9wYWNpdHkgb2YgdGhlIG9iamVjdCByZWxhdGl2ZSB0byBpdHMgcGFyZW50J3Mgb3BhY2l0eS5cbiAgICogVmFsdWUgcmFuZ2VzIGZyb20gMCAoZnVsbHkgdHJhbnNwYXJlbnQpIHRvIDEgKGZ1bGx5IG9wYXF1ZSkuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHRyYW5zcGFyZW5jeVxuICAgKiBzcHJpdGUuYWxwaGEgPSAwLjU7IC8vIDUwJSBvcGFjaXR5XG4gICAqXG4gICAqIC8vIEluaGVyaXRlZCBvcGFjaXR5XG4gICAqIGNvbnRhaW5lci5hbHBoYSA9IDAuNTtcbiAgICogY29uc3QgY2hpbGQgPSBuZXcgU3ByaXRlKHRleHR1cmUpO1xuICAgKiBjaGlsZC5hbHBoYSA9IDAuNTtcbiAgICogY29udGFpbmVyLmFkZENoaWxkKGNoaWxkKTtcbiAgICogLy8gY2hpbGQncyBlZmZlY3RpdmUgb3BhY2l0eSBpcyAwLjI1ICgwLjUgKiAwLjUpXG4gICAqIGBgYFxuICAgKiBAZGVmYXVsdCAxXG4gICAqIEBzZWUge0BsaW5rIENvbnRhaW5lciN2aXNpYmxlfSBGb3IgdG9nZ2xpbmcgdmlzaWJpbGl0eVxuICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjcmVuZGVyYWJsZX0gRm9yIHJlbmRlciBjb250cm9sXG4gICAqL1xuICBnZXQgYWxwaGEoKSB7XG4gICAgcmV0dXJuIHRoaXMubG9jYWxBbHBoYTtcbiAgfVxuICBzZXQgdGludCh2YWx1ZSkge1xuICAgIGNvbnN0IHRlbXBDb2xvciA9IENvbG9yLnNoYXJlZC5zZXRWYWx1ZSh2YWx1ZSA/PyAxNjc3NzIxNSk7XG4gICAgY29uc3QgYmdyID0gdGVtcENvbG9yLnRvQmdyTnVtYmVyKCk7XG4gICAgaWYgKGJnciA9PT0gdGhpcy5sb2NhbENvbG9yKSByZXR1cm47XG4gICAgdGhpcy5sb2NhbENvbG9yID0gYmdyO1xuICAgIHRoaXMuX3VwZGF0ZUZsYWdzIHw9IFVQREFURV9DT0xPUjtcbiAgICB0aGlzLl9vblVwZGF0ZSgpO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgdGludCBhcHBsaWVkIHRvIHRoZSBzcHJpdGUuXG4gICAqXG4gICAqIFRoaXMgY2FuIGJlIGFueSB2YWxpZCB7QGxpbmsgQ29sb3JTb3VyY2V9LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb2xvciB0aW50aW5nXG4gICAqIGNvbnRhaW5lci50aW50ID0gMHhmZjAwMDA7IC8vIFJlZCB0aW50XG4gICAqIGNvbnRhaW5lci50aW50ID0gJ3JlZCc7ICAgIC8vIFNhbWUgYXMgYWJvdmVcbiAgICogY29udGFpbmVyLnRpbnQgPSAnIzAwZmYwMCc7IC8vIEdyZWVuXG4gICAqIGNvbnRhaW5lci50aW50ID0gJ3JnYigwLDAsMjU1KSc7IC8vIEJsdWVcbiAgICpcbiAgICogLy8gUmVtb3ZlIHRpbnRcbiAgICogY29udGFpbmVyLnRpbnQgPSAweGZmZmZmZjsgLy8gV2hpdGUgPSBubyB0aW50XG4gICAqIGNvbnRhaW5lci50aW50ID0gbnVsbDsgICAgIC8vIEFsc28gcmVtb3ZlcyB0aW50XG4gICAqIGBgYFxuICAgKiBAZGVmYXVsdCAweEZGRkZGRlxuICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjYWxwaGF9IEZvciB0cmFuc3BhcmVuY3lcbiAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI3Zpc2libGV9IEZvciB2aXNpYmlsaXR5IGNvbnRyb2xcbiAgICovXG4gIGdldCB0aW50KCkge1xuICAgIHJldHVybiBiZ3IycmdiKHRoaXMubG9jYWxDb2xvcik7XG4gIH1cbiAgLy8gLyAvLy8vLy8vLy8vLy8vLy8vIGJsZW5kIHJlbGF0ZWQgc3R1ZmZcbiAgc2V0IGJsZW5kTW9kZSh2YWx1ZSkge1xuICAgIGlmICh0aGlzLmxvY2FsQmxlbmRNb2RlID09PSB2YWx1ZSkgcmV0dXJuO1xuICAgIGlmICh0aGlzLnBhcmVudFJlbmRlckdyb3VwKSB7XG4gICAgICB0aGlzLnBhcmVudFJlbmRlckdyb3VwLnN0cnVjdHVyZURpZENoYW5nZSA9IHRydWU7XG4gICAgfVxuICAgIHRoaXMuX3VwZGF0ZUZsYWdzIHw9IFVQREFURV9CTEVORDtcbiAgICB0aGlzLmxvY2FsQmxlbmRNb2RlID0gdmFsdWU7XG4gICAgdGhpcy5fb25VcGRhdGUoKTtcbiAgfVxuICAvKipcbiAgICogVGhlIGJsZW5kIG1vZGUgdG8gYmUgYXBwbGllZCB0byB0aGUgc3ByaXRlLiBDb250cm9scyBob3cgcGl4ZWxzIGFyZSBibGVuZGVkIHdoZW4gcmVuZGVyaW5nLlxuICAgKlxuICAgKiBTZXR0aW5nIHRvICdub3JtYWwnIHdpbGwgcmVzZXQgdG8gZGVmYXVsdCBibGVuZGluZy5cbiAgICogPiBbIU5PVEVdIE1vcmUgYmxlbmQgbW9kZXMgYXJlIGF2YWlsYWJsZSBhZnRlciBpbXBvcnRpbmcgdGhlIGBwaXhpLmpzL2FkdmFuY2VkLWJsZW5kLW1vZGVzYCBzdWItZXhwb3J0LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBibGVuZCBtb2Rlc1xuICAgKiBzcHJpdGUuYmxlbmRNb2RlID0gJ2FkZCc7ICAgICAgICAvLyBBZGRpdGl2ZSBibGVuZGluZ1xuICAgKiBzcHJpdGUuYmxlbmRNb2RlID0gJ211bHRpcGx5JzsgICAvLyBNdWx0aXBseSBjb2xvcnNcbiAgICogc3ByaXRlLmJsZW5kTW9kZSA9ICdzY3JlZW4nOyAgICAgLy8gU2NyZWVuIGJsZW5kXG4gICAqXG4gICAqIC8vIFJlc2V0IGJsZW5kIG1vZGVcbiAgICogc3ByaXRlLmJsZW5kTW9kZSA9ICdub3JtYWwnOyAgICAgLy8gTm9ybWFsIGJsZW5kaW5nXG4gICAqIGBgYFxuICAgKiBAZGVmYXVsdCAnbm9ybWFsJ1xuICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjYWxwaGF9IEZvciB0cmFuc3BhcmVuY3lcbiAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI3RpbnR9IEZvciBjb2xvciBhZGp1c3RtZW50c1xuICAgKi9cbiAgZ2V0IGJsZW5kTW9kZSgpIHtcbiAgICByZXR1cm4gdGhpcy5sb2NhbEJsZW5kTW9kZTtcbiAgfVxuICAvLyAvIC8vLy8vLy8vLyBWSVNJQklMSVRZIC8gUkVOREVSQUJMRSAvLy8vLy8vLy8vLy8vLy8vL1xuICAvKipcbiAgICogVGhlIHZpc2liaWxpdHkgb2YgdGhlIG9iamVjdC4gSWYgZmFsc2UgdGhlIG9iamVjdCB3aWxsIG5vdCBiZSBkcmF3bixcbiAgICogYW5kIHRoZSB0cmFuc2Zvcm0gd2lsbCBub3QgYmUgdXBkYXRlZC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgdmlzaWJpbGl0eSB0b2dnbGVcbiAgICogc3ByaXRlLnZpc2libGUgPSBmYWxzZTsgLy8gSGlkZSBzcHJpdGVcbiAgICogc3ByaXRlLnZpc2libGUgPSB0cnVlOyAgLy8gU2hvdyBzcHJpdGVcbiAgICogYGBgXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI3JlbmRlcmFibGV9IEZvciByZW5kZXItb25seSBjb250cm9sXG4gICAqIEBzZWUge0BsaW5rIENvbnRhaW5lciNhbHBoYX0gRm9yIHRyYW5zcGFyZW5jeVxuICAgKi9cbiAgZ2V0IHZpc2libGUoKSB7XG4gICAgcmV0dXJuICEhKHRoaXMubG9jYWxEaXNwbGF5U3RhdHVzICYgMik7XG4gIH1cbiAgc2V0IHZpc2libGUodmFsdWUpIHtcbiAgICBjb25zdCB2YWx1ZU51bWJlciA9IHZhbHVlID8gMiA6IDA7XG4gICAgaWYgKCh0aGlzLmxvY2FsRGlzcGxheVN0YXR1cyAmIDIpID09PSB2YWx1ZU51bWJlcikgcmV0dXJuO1xuICAgIGlmICh0aGlzLnBhcmVudFJlbmRlckdyb3VwKSB7XG4gICAgICB0aGlzLnBhcmVudFJlbmRlckdyb3VwLnN0cnVjdHVyZURpZENoYW5nZSA9IHRydWU7XG4gICAgfVxuICAgIHRoaXMuX3VwZGF0ZUZsYWdzIHw9IFVQREFURV9WSVNJQkxFO1xuICAgIHRoaXMubG9jYWxEaXNwbGF5U3RhdHVzIF49IDI7XG4gICAgdGhpcy5fb25VcGRhdGUoKTtcbiAgICB0aGlzLmVtaXQoXCJ2aXNpYmxlQ2hhbmdlZFwiLCB2YWx1ZSk7XG4gIH1cbiAgLyoqIEBpZ25vcmUgKi9cbiAgZ2V0IGN1bGxlZCgpIHtcbiAgICByZXR1cm4gISh0aGlzLmxvY2FsRGlzcGxheVN0YXR1cyAmIDQpO1xuICB9XG4gIC8qKiBAaWdub3JlICovXG4gIHNldCBjdWxsZWQodmFsdWUpIHtcbiAgICBjb25zdCB2YWx1ZU51bWJlciA9IHZhbHVlID8gMCA6IDQ7XG4gICAgaWYgKCh0aGlzLmxvY2FsRGlzcGxheVN0YXR1cyAmIDQpID09PSB2YWx1ZU51bWJlcikgcmV0dXJuO1xuICAgIGlmICh0aGlzLnBhcmVudFJlbmRlckdyb3VwKSB7XG4gICAgICB0aGlzLnBhcmVudFJlbmRlckdyb3VwLnN0cnVjdHVyZURpZENoYW5nZSA9IHRydWU7XG4gICAgfVxuICAgIHRoaXMuX3VwZGF0ZUZsYWdzIHw9IFVQREFURV9WSVNJQkxFO1xuICAgIHRoaXMubG9jYWxEaXNwbGF5U3RhdHVzIF49IDQ7XG4gICAgdGhpcy5fb25VcGRhdGUoKTtcbiAgfVxuICAvKipcbiAgICogQ29udHJvbHMgd2hldGhlciB0aGlzIG9iamVjdCBjYW4gYmUgcmVuZGVyZWQuIElmIGZhbHNlIHRoZSBvYmplY3Qgd2lsbCBub3QgYmUgZHJhd24sXG4gICAqIGJ1dCB0aGUgdHJhbnNmb3JtIHdpbGwgc3RpbGwgYmUgdXBkYXRlZC4gVGhpcyBpcyBkaWZmZXJlbnQgZnJvbSB2aXNpYmxlLCB3aGljaCBza2lwc1xuICAgKiB0cmFuc2Zvcm0gdXBkYXRlcy5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgcmVuZGVyIGNvbnRyb2xcbiAgICogc3ByaXRlLnJlbmRlcmFibGUgPSBmYWxzZTsgLy8gU2tpcCByZW5kZXJpbmdcbiAgICogc3ByaXRlLnJlbmRlcmFibGUgPSB0cnVlOyAgLy8gRW5hYmxlIHJlbmRlcmluZ1xuICAgKiBgYGBcbiAgICogQGRlZmF1bHQgdHJ1ZVxuICAgKiBAc2VlIHtAbGluayBDb250YWluZXIjdmlzaWJsZX0gRm9yIHNraXBwaW5nIHRyYW5zZm9ybSB1cGRhdGVzXG4gICAqIEBzZWUge0BsaW5rIENvbnRhaW5lciNhbHBoYX0gRm9yIHRyYW5zcGFyZW5jeVxuICAgKi9cbiAgZ2V0IHJlbmRlcmFibGUoKSB7XG4gICAgcmV0dXJuICEhKHRoaXMubG9jYWxEaXNwbGF5U3RhdHVzICYgMSk7XG4gIH1cbiAgc2V0IHJlbmRlcmFibGUodmFsdWUpIHtcbiAgICBjb25zdCB2YWx1ZU51bWJlciA9IHZhbHVlID8gMSA6IDA7XG4gICAgaWYgKCh0aGlzLmxvY2FsRGlzcGxheVN0YXR1cyAmIDEpID09PSB2YWx1ZU51bWJlcikgcmV0dXJuO1xuICAgIHRoaXMuX3VwZGF0ZUZsYWdzIHw9IFVQREFURV9WSVNJQkxFO1xuICAgIHRoaXMubG9jYWxEaXNwbGF5U3RhdHVzIF49IDE7XG4gICAgaWYgKHRoaXMucGFyZW50UmVuZGVyR3JvdXApIHtcbiAgICAgIHRoaXMucGFyZW50UmVuZGVyR3JvdXAuc3RydWN0dXJlRGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICB9XG4gICAgdGhpcy5fb25VcGRhdGUoKTtcbiAgfVxuICAvKipcbiAgICogV2hldGhlciBvciBub3QgdGhlIG9iamVjdCBzaG91bGQgYmUgcmVuZGVyZWQuXG4gICAqIEBhZHZhbmNlZFxuICAgKi9cbiAgZ2V0IGlzUmVuZGVyYWJsZSgpIHtcbiAgICByZXR1cm4gdGhpcy5sb2NhbERpc3BsYXlTdGF0dXMgPT09IDcgJiYgdGhpcy5ncm91cEFscGhhID4gMDtcbiAgfVxuICAvKipcbiAgICogUmVtb3ZlcyBhbGwgaW50ZXJuYWwgcmVmZXJlbmNlcyBhbmQgbGlzdGVuZXJzIGFzIHdlbGwgYXMgcmVtb3ZlcyBjaGlsZHJlbiBmcm9tIHRoZSBkaXNwbGF5IGxpc3QuXG4gICAqIERvIG5vdCB1c2UgYSBDb250YWluZXIgYWZ0ZXIgY2FsbGluZyBgZGVzdHJveWAuXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gT3B0aW9ucyBwYXJhbWV0ZXIuIEEgYm9vbGVhbiB3aWxsIGFjdCBhcyBpZiBhbGwgb3B0aW9uc1xuICAgKiAgaGF2ZSBiZWVuIHNldCB0byB0aGF0IHZhbHVlXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnRhaW5lci5kZXN0cm95KCk7XG4gICAqIGNvbnRhaW5lci5kZXN0cm95KHRydWUpO1xuICAgKiBjb250YWluZXIuZGVzdHJveSh7IGNoaWxkcmVuOiB0cnVlIH0pO1xuICAgKiBjb250YWluZXIuZGVzdHJveSh7IGNoaWxkcmVuOiB0cnVlLCB0ZXh0dXJlOiB0cnVlLCB0ZXh0dXJlU291cmNlOiB0cnVlIH0pO1xuICAgKiBgYGBcbiAgICovXG4gIGRlc3Ryb3kob3B0aW9ucyA9IGZhbHNlKSB7XG4gICAgaWYgKHRoaXMuZGVzdHJveWVkKSByZXR1cm47XG4gICAgdGhpcy5kZXN0cm95ZWQgPSB0cnVlO1xuICAgIGxldCBvbGRDaGlsZHJlbjtcbiAgICBpZiAodGhpcy5jaGlsZHJlbi5sZW5ndGgpIHtcbiAgICAgIG9sZENoaWxkcmVuID0gdGhpcy5yZW1vdmVDaGlsZHJlbigwLCB0aGlzLmNoaWxkcmVuLmxlbmd0aCk7XG4gICAgfVxuICAgIHRoaXMucmVtb3ZlRnJvbVBhcmVudCgpO1xuICAgIHRoaXMucGFyZW50ID0gbnVsbDtcbiAgICB0aGlzLl9tYXNrRWZmZWN0ID0gbnVsbDtcbiAgICB0aGlzLl9maWx0ZXJFZmZlY3QgPSBudWxsO1xuICAgIHRoaXMuZWZmZWN0cyA9IG51bGw7XG4gICAgdGhpcy5fcG9zaXRpb24gPSBudWxsO1xuICAgIHRoaXMuX3NjYWxlID0gbnVsbDtcbiAgICB0aGlzLl9waXZvdCA9IG51bGw7XG4gICAgdGhpcy5fb3JpZ2luID0gbnVsbDtcbiAgICB0aGlzLl9za2V3ID0gbnVsbDtcbiAgICB0aGlzLmVtaXQoXCJkZXN0cm95ZWRcIiwgdGhpcyk7XG4gICAgdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcbiAgICBjb25zdCBkZXN0cm95Q2hpbGRyZW4gPSB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJib29sZWFuXCIgPyBvcHRpb25zIDogb3B0aW9ucz8uY2hpbGRyZW47XG4gICAgaWYgKGRlc3Ryb3lDaGlsZHJlbiAmJiBvbGRDaGlsZHJlbikge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBvbGRDaGlsZHJlbi5sZW5ndGg7ICsraSkge1xuICAgICAgICBvbGRDaGlsZHJlbltpXS5kZXN0cm95KG9wdGlvbnMpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLnJlbmRlckdyb3VwPy5kZXN0cm95KCk7XG4gICAgdGhpcy5yZW5kZXJHcm91cCA9IG51bGw7XG4gIH1cbn1cbmV4dGVuc2lvbnMubWl4aW4oXG4gIENvbnRhaW5lcixcbiAgY2hpbGRyZW5IZWxwZXJNaXhpbixcbiAgZ2V0RmFzdEdsb2JhbEJvdW5kc01peGluLFxuICB0b0xvY2FsR2xvYmFsTWl4aW4sXG4gIG9uUmVuZGVyTWl4aW4sXG4gIG1lYXN1cmVNaXhpbixcbiAgZWZmZWN0c01peGluLFxuICBmaW5kTWl4aW4sXG4gIHNvcnRNaXhpbixcbiAgY3VsbGluZ01peGluLFxuICBjYWNoZUFzVGV4dHVyZU1peGluLFxuICBnZXRHbG9iYWxNaXhpbixcbiAgY29sbGVjdFJlbmRlcmFibGVzTWl4aW5cbik7XG5cbmV4cG9ydCB7IENvbnRhaW5lciwgVVBEQVRFX0JMRU5ELCBVUERBVEVfQ09MT1IsIFVQREFURV9UUkFOU0ZPUk0sIFVQREFURV9WSVNJQkxFIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1Db250YWluZXIubWpzLm1hcFxuIiwiaW1wb3J0IHsgQm91bmRzIH0gZnJvbSAnLi4vY29udGFpbmVyL2JvdW5kcy9Cb3VuZHMubWpzJztcbmltcG9ydCB7IENvbnRhaW5lciB9IGZyb20gJy4uL2NvbnRhaW5lci9Db250YWluZXIubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBWaWV3Q29udGFpbmVyIGV4dGVuZHMgQ29udGFpbmVyIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLmNhbkJ1bmRsZSA9IHRydWU7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuYWxsb3dDaGlsZHJlbiA9IGZhbHNlO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLl9yb3VuZFBpeGVscyA9IDA7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuX2xhc3RVc2VkID0gLTE7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuX2dwdURhdGEgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAvKiogSWYgc2V0IHRvIHRydWUsIHRoZSByZXNvdXJjZSB3aWxsIGJlIGdhcmJhZ2UgY29sbGVjdGVkIGF1dG9tYXRpY2FsbHkgd2hlbiBpdCBpcyBub3QgdXNlZC4gKi9cbiAgICB0aGlzLmF1dG9HYXJiYWdlQ29sbGVjdCA9IHRydWU7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuX2djTGFzdFVzZWQgPSAtMTtcbiAgICB0aGlzLl9ib3VuZHMgPSBuZXcgQm91bmRzKDAsIDEsIDAsIDApO1xuICAgIHRoaXMuX2JvdW5kc0RpcnR5ID0gdHJ1ZTtcbiAgICB0aGlzLmF1dG9HYXJiYWdlQ29sbGVjdCA9IG9wdGlvbnMuYXV0b0dhcmJhZ2VDb2xsZWN0ID8/IHRydWU7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBsb2NhbCBib3VuZHMgb2YgdGhlIHZpZXcgaW4gaXRzIG93biBjb29yZGluYXRlIHNwYWNlLlxuICAgKiBCb3VuZHMgYXJlIGF1dG9tYXRpY2FsbHkgdXBkYXRlZCB3aGVuIHRoZSB2aWV3J3MgY29udGVudCBjaGFuZ2VzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBHZXQgYm91bmRzIGRpbWVuc2lvbnNcbiAgICogY29uc3QgYm91bmRzID0gdmlldy5ib3VuZHM7XG4gICAqIGNvbnNvbGUubG9nKGBXaWR0aDogJHtib3VuZHMubWF4WCAtIGJvdW5kcy5taW5YfWApO1xuICAgKiBjb25zb2xlLmxvZyhgSGVpZ2h0OiAke2JvdW5kcy5tYXhZIC0gYm91bmRzLm1pbll9YCk7XG4gICAqIGBgYFxuICAgKiBAcmV0dXJucyBUaGUgcmVjdGFuZ3VsYXIgYm91bmRzIG9mIHRoZSB2aWV3XG4gICAqIEBzZWUge0BsaW5rIEJvdW5kc30gRm9yIGJvdW5kcyBvcGVyYXRpb25zXG4gICAqL1xuICBnZXQgYm91bmRzKCkge1xuICAgIGlmICghdGhpcy5fYm91bmRzRGlydHkpIHJldHVybiB0aGlzLl9ib3VuZHM7XG4gICAgdGhpcy51cGRhdGVCb3VuZHMoKTtcbiAgICB0aGlzLl9ib3VuZHNEaXJ0eSA9IGZhbHNlO1xuICAgIHJldHVybiB0aGlzLl9ib3VuZHM7XG4gIH1cbiAgLyoqXG4gICAqIFdoZXRoZXIgb3Igbm90IHRvIHJvdW5kIHRoZSB4L3kgcG9zaXRpb24gb2YgdGhlIHNwcml0ZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gRW5hYmxlIHBpeGVsIHJvdW5kaW5nIGZvciBjcmlzcCByZW5kZXJpbmdcbiAgICogdmlldy5yb3VuZFBpeGVscyA9IHRydWU7XG4gICAqIGBgYFxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgZ2V0IHJvdW5kUGl4ZWxzKCkge1xuICAgIHJldHVybiAhIXRoaXMuX3JvdW5kUGl4ZWxzO1xuICB9XG4gIHNldCByb3VuZFBpeGVscyh2YWx1ZSkge1xuICAgIHRoaXMuX3JvdW5kUGl4ZWxzID0gdmFsdWUgPyAxIDogMDtcbiAgfVxuICAvKipcbiAgICogQ2hlY2tzIGlmIHRoZSBvYmplY3QgY29udGFpbnMgdGhlIGdpdmVuIHBvaW50IGluIGxvY2FsIGNvb3JkaW5hdGVzLlxuICAgKiBVc2VzIHRoZSB2aWV3J3MgYm91bmRzIGZvciBoaXQgdGVzdGluZy5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgcG9pbnQgY2hlY2tcbiAgICogY29uc3QgbG9jYWxQb2ludCA9IHsgeDogNTAsIHk6IDI1IH07XG4gICAqIGNvbnN0IGNvbnRhaW5zID0gdmlldy5jb250YWluc1BvaW50KGxvY2FsUG9pbnQpO1xuICAgKiBjb25zb2xlLmxvZygnUG9pbnQgaXMgaW5zaWRlOicsIGNvbnRhaW5zKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSBwb2ludCAtIFRoZSBwb2ludCB0byBjaGVjayBpbiBsb2NhbCBjb29yZGluYXRlc1xuICAgKiBAcmV0dXJucyBUcnVlIGlmIHRoZSBwb2ludCBpcyB3aXRoaW4gdGhlIHZpZXcncyBib3VuZHNcbiAgICogQHNlZSB7QGxpbmsgVmlld0NvbnRhaW5lciNib3VuZHN9IEZvciB0aGUgYm91bmRzIHVzZWQgaW4gaGl0IHRlc3RpbmdcbiAgICogQHNlZSB7QGxpbmsgQ29udGFpbmVyI3RvTG9jYWx9IEZvciBjb252ZXJ0aW5nIGdsb2JhbCBjb29yZGluYXRlcyB0byBsb2NhbFxuICAgKi9cbiAgY29udGFpbnNQb2ludChwb2ludCkge1xuICAgIGNvbnN0IGJvdW5kcyA9IHRoaXMuYm91bmRzO1xuICAgIGNvbnN0IHsgeCwgeSB9ID0gcG9pbnQ7XG4gICAgcmV0dXJuIHggPj0gYm91bmRzLm1pblggJiYgeCA8PSBib3VuZHMubWF4WCAmJiB5ID49IGJvdW5kcy5taW5ZICYmIHkgPD0gYm91bmRzLm1heFk7XG4gIH1cbiAgLyoqIEBwcml2YXRlICovXG4gIG9uVmlld1VwZGF0ZSgpIHtcbiAgICB0aGlzLl9kaWRWaWV3Q2hhbmdlVGljaysrO1xuICAgIHRoaXMuX2JvdW5kc0RpcnR5ID0gdHJ1ZTtcbiAgICBpZiAodGhpcy5kaWRWaWV3VXBkYXRlKSByZXR1cm47XG4gICAgdGhpcy5kaWRWaWV3VXBkYXRlID0gdHJ1ZTtcbiAgICBjb25zdCByZW5kZXJHcm91cCA9IHRoaXMucmVuZGVyR3JvdXAgfHwgdGhpcy5wYXJlbnRSZW5kZXJHcm91cDtcbiAgICBpZiAocmVuZGVyR3JvdXApIHtcbiAgICAgIHJlbmRlckdyb3VwLm9uQ2hpbGRWaWV3VXBkYXRlKHRoaXMpO1xuICAgIH1cbiAgfVxuICAvKiogVW5sb2FkcyB0aGUgR1BVIGRhdGEgZnJvbSB0aGUgdmlldy4gKi9cbiAgdW5sb2FkKCkge1xuICAgIHRoaXMuZW1pdChcInVubG9hZFwiLCB0aGlzKTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiB0aGlzLl9ncHVEYXRhKSB7XG4gICAgICB0aGlzLl9ncHVEYXRhW2tleV0/LmRlc3Ryb3koKTtcbiAgICB9XG4gICAgdGhpcy5fZ3B1RGF0YSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIHRoaXMub25WaWV3VXBkYXRlKCk7XG4gIH1cbiAgZGVzdHJveShvcHRpb25zKSB7XG4gICAgdGhpcy51bmxvYWQoKTtcbiAgICBzdXBlci5kZXN0cm95KG9wdGlvbnMpO1xuICAgIHRoaXMuX2JvdW5kcyA9IG51bGw7XG4gIH1cbiAgLyoqXG4gICAqIENvbGxlY3RzIHJlbmRlcmFibGVzIGZvciB0aGUgdmlldyBjb250YWluZXIuXG4gICAqIEBwYXJhbSBpbnN0cnVjdGlvblNldCAtIFRoZSBpbnN0cnVjdGlvbiBzZXQgdG8gY29sbGVjdCByZW5kZXJhYmxlcyBmb3IuXG4gICAqIEBwYXJhbSByZW5kZXJlciAtIFRoZSByZW5kZXJlciB0byBjb2xsZWN0IHJlbmRlcmFibGVzIGZvci5cbiAgICogQHBhcmFtIGN1cnJlbnRMYXllciAtIFRoZSBjdXJyZW50IHJlbmRlciBsYXllci5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBjb2xsZWN0UmVuZGVyYWJsZXNTaW1wbGUoaW5zdHJ1Y3Rpb25TZXQsIHJlbmRlcmVyLCBjdXJyZW50TGF5ZXIpIHtcbiAgICBjb25zdCB7IHJlbmRlclBpcGVzIH0gPSByZW5kZXJlcjtcbiAgICByZW5kZXJQaXBlcy5ibGVuZE1vZGUucHVzaEJsZW5kTW9kZSh0aGlzLCB0aGlzLmdyb3VwQmxlbmRNb2RlLCBpbnN0cnVjdGlvblNldCk7XG4gICAgY29uc3QgcnAgPSByZW5kZXJQaXBlcztcbiAgICBjb25zdCBwaXBlID0gcnBbdGhpcy5yZW5kZXJQaXBlSWRdO1xuICAgIGlmIChwaXBlPy5hZGRSZW5kZXJhYmxlKSB7XG4gICAgICBwaXBlLmFkZFJlbmRlcmFibGUodGhpcywgaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIH1cbiAgICB0aGlzLmRpZFZpZXdVcGRhdGUgPSBmYWxzZTtcbiAgICBjb25zdCBjaGlsZHJlbiA9IHRoaXMuY2hpbGRyZW47XG4gICAgY29uc3QgbGVuZ3RoID0gY2hpbGRyZW4ubGVuZ3RoO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgIGNoaWxkcmVuW2ldLmNvbGxlY3RSZW5kZXJhYmxlcyhpbnN0cnVjdGlvblNldCwgcmVuZGVyZXIsIGN1cnJlbnRMYXllcik7XG4gICAgfVxuICAgIHJlbmRlclBpcGVzLmJsZW5kTW9kZS5wb3BCbGVuZE1vZGUoaW5zdHJ1Y3Rpb25TZXQpO1xuICB9XG59XG5cbmV4cG9ydCB7IFZpZXdDb250YWluZXIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVZpZXdDb250YWluZXIubWpzLm1hcFxuIiwiaW1wb3J0IHsgT2JzZXJ2YWJsZVBvaW50IH0gZnJvbSAnLi4vLi4vbWF0aHMvcG9pbnQvT2JzZXJ2YWJsZVBvaW50Lm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlIH0gZnJvbSAnLi4vLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9UZXh0dXJlLm1qcyc7XG5pbXBvcnQgeyB1cGRhdGVRdWFkQm91bmRzIH0gZnJvbSAnLi4vLi4vdXRpbHMvZGF0YS91cGRhdGVRdWFkQm91bmRzLm1qcyc7XG5pbXBvcnQgeyBkZXByZWNhdGlvbiB9IGZyb20gJy4uLy4uL3V0aWxzL2xvZ2dpbmcvZGVwcmVjYXRpb24ubWpzJztcbmltcG9ydCB7IFZpZXdDb250YWluZXIgfSBmcm9tICcuLi92aWV3L1ZpZXdDb250YWluZXIubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBTcHJpdGUgZXh0ZW5kcyBWaWV3Q29udGFpbmVyIHtcbiAgLyoqXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgZm9yIGNyZWF0aW5nIHRoZSBzcHJpdGUuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0gVGV4dHVyZS5FTVBUWSkge1xuICAgIGlmIChvcHRpb25zIGluc3RhbmNlb2YgVGV4dHVyZSkge1xuICAgICAgb3B0aW9ucyA9IHsgdGV4dHVyZTogb3B0aW9ucyB9O1xuICAgIH1cbiAgICBjb25zdCB7IHRleHR1cmUgPSBUZXh0dXJlLkVNUFRZLCBhbmNob3IsIHJvdW5kUGl4ZWxzLCB3aWR0aCwgaGVpZ2h0LCAuLi5yZXN0IH0gPSBvcHRpb25zO1xuICAgIHN1cGVyKHtcbiAgICAgIGxhYmVsOiBcIlNwcml0ZVwiLFxuICAgICAgLi4ucmVzdFxuICAgIH0pO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLnJlbmRlclBpcGVJZCA9IFwic3ByaXRlXCI7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuYmF0Y2hlZCA9IHRydWU7XG4gICAgdGhpcy5fdmlzdWFsQm91bmRzID0geyBtaW5YOiAwLCBtYXhYOiAxLCBtaW5ZOiAwLCBtYXhZOiAwIH07XG4gICAgdGhpcy5fYW5jaG9yID0gbmV3IE9ic2VydmFibGVQb2ludChcbiAgICAgIHtcbiAgICAgICAgX29uVXBkYXRlOiAoKSA9PiB7XG4gICAgICAgICAgdGhpcy5vblZpZXdVcGRhdGUoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gICAgaWYgKGFuY2hvcikge1xuICAgICAgdGhpcy5hbmNob3IgPSBhbmNob3I7XG4gICAgfSBlbHNlIGlmICh0ZXh0dXJlLmRlZmF1bHRBbmNob3IpIHtcbiAgICAgIHRoaXMuYW5jaG9yID0gdGV4dHVyZS5kZWZhdWx0QW5jaG9yO1xuICAgIH1cbiAgICB0aGlzLnRleHR1cmUgPSB0ZXh0dXJlO1xuICAgIHRoaXMuYWxsb3dDaGlsZHJlbiA9IGZhbHNlO1xuICAgIHRoaXMucm91bmRQaXhlbHMgPSByb3VuZFBpeGVscyA/PyBmYWxzZTtcbiAgICBpZiAod2lkdGggIT09IHZvaWQgMCkgdGhpcy53aWR0aCA9IHdpZHRoO1xuICAgIGlmIChoZWlnaHQgIT09IHZvaWQgMCkgdGhpcy5oZWlnaHQgPSBoZWlnaHQ7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgc3ByaXRlIGJhc2VkIG9uIGEgc291cmNlIHRleHR1cmUsIGltYWdlLCB2aWRlbywgb3IgY2FudmFzIGVsZW1lbnQuXG4gICAqIFRoaXMgaXMgYSBjb252ZW5pZW5jZSBtZXRob2QgdGhhdCBhdXRvbWF0aWNhbGx5IGNyZWF0ZXMgYW5kIG1hbmFnZXMgdGV4dHVyZXMuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIENyZWF0ZSBmcm9tIHBhdGggb3IgVVJMXG4gICAqIGNvbnN0IHNwcml0ZSA9IFNwcml0ZS5mcm9tKCdhc3NldHMvaW1hZ2UucG5nJyk7XG4gICAqXG4gICAqIC8vIENyZWF0ZSBmcm9tIGV4aXN0aW5nIHRleHR1cmVcbiAgICogY29uc3Qgc3ByaXRlID0gU3ByaXRlLmZyb20odGV4dHVyZSk7XG4gICAqXG4gICAqIC8vIENyZWF0ZSBmcm9tIGNhbnZhc1xuICAgKiBjb25zdCBjYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcbiAgICogY29uc3Qgc3ByaXRlID0gU3ByaXRlLmZyb20oY2FudmFzLCB0cnVlKTsgLy8gU2tpcCBjYWNoaW5nIG5ldyB0ZXh0dXJlXG4gICAqIGBgYFxuICAgKiBAcGFyYW0gc291cmNlIC0gVGhlIHNvdXJjZSB0byBjcmVhdGUgdGhlIHNwcml0ZSBmcm9tLiBDYW4gYmUgYSBwYXRoIHRvIGFuIGltYWdlLCBhIHRleHR1cmUsXG4gICAqIG9yIGFueSB2YWxpZCB0ZXh0dXJlIHNvdXJjZSAoY2FudmFzLCB2aWRlbywgZXRjLilcbiAgICogQHBhcmFtIHNraXBDYWNoZSAtIFdoZXRoZXIgdG8gc2tpcCBhZGRpbmcgdG8gdGhlIHRleHR1cmUgY2FjaGUgd2hlbiBjcmVhdGluZyBhIG5ldyB0ZXh0dXJlXG4gICAqIEByZXR1cm5zIEEgbmV3IHNwcml0ZSBiYXNlZCBvbiB0aGUgc291cmNlXG4gICAqIEBzZWUge0BsaW5rIFRleHR1cmUuZnJvbX0gRm9yIHRleHR1cmUgY3JlYXRpb24gZGV0YWlsc1xuICAgKiBAc2VlIHtAbGluayBBc3NldHN9IEZvciBhc3NldCBsb2FkaW5nIGFuZCBtYW5hZ2VtZW50XG4gICAqL1xuICBzdGF0aWMgZnJvbShzb3VyY2UsIHNraXBDYWNoZSA9IGZhbHNlKSB7XG4gICAgaWYgKHNvdXJjZSBpbnN0YW5jZW9mIFRleHR1cmUpIHtcbiAgICAgIHJldHVybiBuZXcgU3ByaXRlKHNvdXJjZSk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgU3ByaXRlKFRleHR1cmUuZnJvbShzb3VyY2UsIHNraXBDYWNoZSkpO1xuICB9XG4gIHNldCB0ZXh0dXJlKHZhbHVlKSB7XG4gICAgdmFsdWUgfHwgKHZhbHVlID0gVGV4dHVyZS5FTVBUWSk7XG4gICAgY29uc3QgY3VycmVudFRleHR1cmUgPSB0aGlzLl90ZXh0dXJlO1xuICAgIGlmIChjdXJyZW50VGV4dHVyZSA9PT0gdmFsdWUpIHJldHVybjtcbiAgICBpZiAoY3VycmVudFRleHR1cmUgJiYgY3VycmVudFRleHR1cmUuZHluYW1pYykgY3VycmVudFRleHR1cmUub2ZmKFwidXBkYXRlXCIsIHRoaXMub25WaWV3VXBkYXRlLCB0aGlzKTtcbiAgICBpZiAodmFsdWUuZHluYW1pYykgdmFsdWUub24oXCJ1cGRhdGVcIiwgdGhpcy5vblZpZXdVcGRhdGUsIHRoaXMpO1xuICAgIHRoaXMuX3RleHR1cmUgPSB2YWx1ZTtcbiAgICBpZiAodGhpcy5fd2lkdGgpIHtcbiAgICAgIHRoaXMuX3NldFdpZHRoKHRoaXMuX3dpZHRoLCB0aGlzLl90ZXh0dXJlLm9yaWcud2lkdGgpO1xuICAgIH1cbiAgICBpZiAodGhpcy5faGVpZ2h0KSB7XG4gICAgICB0aGlzLl9zZXRIZWlnaHQodGhpcy5faGVpZ2h0LCB0aGlzLl90ZXh0dXJlLm9yaWcuaGVpZ2h0KTtcbiAgICB9XG4gICAgdGhpcy5vblZpZXdVcGRhdGUoKTtcbiAgfVxuICAvKipcbiAgICogVGhlIHRleHR1cmUgdGhhdCBpcyBkaXNwbGF5ZWQgYnkgdGhlIHNwcml0ZS4gV2hlbiBjaGFuZ2VkLCBhdXRvbWF0aWNhbGx5IHVwZGF0ZXNcbiAgICogdGhlIHNwcml0ZSBkaW1lbnNpb25zIGFuZCBtYW5hZ2VzIHRleHR1cmUgZXZlbnQgbGlzdGVuZXJzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBDcmVhdGUgc3ByaXRlIHdpdGggdGV4dHVyZVxuICAgKiBjb25zdCBzcHJpdGUgPSBuZXcgU3ByaXRlKHtcbiAgICogICAgIHRleHR1cmU6IFRleHR1cmUuZnJvbSgnc3ByaXRlLnBuZycpXG4gICAqIH0pO1xuICAgKlxuICAgKiAvLyBVcGRhdGUgdGV4dHVyZVxuICAgKiBzcHJpdGUudGV4dHVyZSA9IFRleHR1cmUuZnJvbSgnbmV3U3ByaXRlLnBuZycpO1xuICAgKlxuICAgKiAvLyBVc2UgdGV4dHVyZSBmcm9tIHNwcml0ZXNoZWV0XG4gICAqIGNvbnN0IHNoZWV0ID0gYXdhaXQgQXNzZXRzLmxvYWQoJ3Nwcml0ZXNoZWV0Lmpzb24nKTtcbiAgICogc3ByaXRlLnRleHR1cmUgPSBzaGVldC50ZXh0dXJlc1snZnJhbWUxLnBuZyddO1xuICAgKlxuICAgKiAvLyBSZXNldCB0byBlbXB0eSB0ZXh0dXJlXG4gICAqIHNwcml0ZS50ZXh0dXJlID0gVGV4dHVyZS5FTVBUWTtcbiAgICogYGBgXG4gICAqIEBzZWUge0BsaW5rIFRleHR1cmV9IEZvciB0ZXh0dXJlIGNyZWF0aW9uIGFuZCBtYW5hZ2VtZW50XG4gICAqIEBzZWUge0BsaW5rIEFzc2V0c30gRm9yIGFzc2V0IGxvYWRpbmdcbiAgICovXG4gIGdldCB0ZXh0dXJlKCkge1xuICAgIHJldHVybiB0aGlzLl90ZXh0dXJlO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgYm91bmRzIG9mIHRoZSBzcHJpdGUsIHRha2luZyBpbnRvIGFjY291bnQgdGhlIHRleHR1cmUncyB0cmltIGFyZWEuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IHRleHR1cmUgPSBuZXcgVGV4dHVyZSh7XG4gICAqICAgICBzb3VyY2U6IG5ldyBUZXh0dXJlU291cmNlKHsgd2lkdGg6IDMwMCwgaGVpZ2h0OiAzMDAgfSksXG4gICAqICAgICBmcmFtZTogbmV3IFJlY3RhbmdsZSgxOTYsIDY2LCA1OCwgNTYpLFxuICAgKiAgICAgdHJpbTogbmV3IFJlY3RhbmdsZSg0LCA0LCA1OCwgNTYpLFxuICAgKiAgICAgb3JpZzogbmV3IFJlY3RhbmdsZSgwLCAwLCA2NCwgNjQpLFxuICAgKiAgICAgcm90YXRlOiAyLFxuICAgKiB9KTtcbiAgICogY29uc3Qgc3ByaXRlID0gbmV3IFNwcml0ZSh0ZXh0dXJlKTtcbiAgICogY29uc3QgdmlzdWFsQm91bmRzID0gc3ByaXRlLnZpc3VhbEJvdW5kcztcbiAgICogLy8gY29uc29sZS5sb2codmlzdWFsQm91bmRzKTsgLy8geyBtaW5YOiAtNCwgbWF4WDogNjIsIG1pblk6IC00LCBtYXhZOiA2MCB9XG4gICAqL1xuICBnZXQgdmlzdWFsQm91bmRzKCkge1xuICAgIHVwZGF0ZVF1YWRCb3VuZHModGhpcy5fdmlzdWFsQm91bmRzLCB0aGlzLl9hbmNob3IsIHRoaXMuX3RleHR1cmUpO1xuICAgIHJldHVybiB0aGlzLl92aXN1YWxCb3VuZHM7XG4gIH1cbiAgLyoqXG4gICAqIEBkZXByZWNhdGVkXG4gICAqIEBpZ25vcmVcbiAgICovXG4gIGdldCBzb3VyY2VCb3VuZHMoKSB7XG4gICAgZGVwcmVjYXRpb24oXCI4LjYuMVwiLCBcIlNwcml0ZS5zb3VyY2VCb3VuZHMgaXMgZGVwcmVjYXRlZCwgdXNlIHZpc3VhbEJvdW5kcyBpbnN0ZWFkLlwiKTtcbiAgICByZXR1cm4gdGhpcy52aXN1YWxCb3VuZHM7XG4gIH1cbiAgLyoqIEBwcml2YXRlICovXG4gIHVwZGF0ZUJvdW5kcygpIHtcbiAgICBjb25zdCBhbmNob3IgPSB0aGlzLl9hbmNob3I7XG4gICAgY29uc3QgdGV4dHVyZSA9IHRoaXMuX3RleHR1cmU7XG4gICAgY29uc3QgYm91bmRzID0gdGhpcy5fYm91bmRzO1xuICAgIGNvbnN0IHsgd2lkdGgsIGhlaWdodCB9ID0gdGV4dHVyZS5vcmlnO1xuICAgIGJvdW5kcy5taW5YID0gLWFuY2hvci5feCAqIHdpZHRoO1xuICAgIGJvdW5kcy5tYXhYID0gYm91bmRzLm1pblggKyB3aWR0aDtcbiAgICBib3VuZHMubWluWSA9IC1hbmNob3IuX3kgKiBoZWlnaHQ7XG4gICAgYm91bmRzLm1heFkgPSBib3VuZHMubWluWSArIGhlaWdodDtcbiAgfVxuICAvKipcbiAgICogRGVzdHJveXMgdGhpcyBzcHJpdGUgcmVuZGVyYWJsZSBhbmQgb3B0aW9uYWxseSBpdHMgdGV4dHVyZS5cbiAgICogQHBhcmFtIG9wdGlvbnMgLSBPcHRpb25zIHBhcmFtZXRlci4gQSBib29sZWFuIHdpbGwgYWN0IGFzIGlmIGFsbCBvcHRpb25zXG4gICAqICBoYXZlIGJlZW4gc2V0IHRvIHRoYXQgdmFsdWVcbiAgICogQGV4YW1wbGVcbiAgICogc3ByaXRlLmRlc3Ryb3koKTtcbiAgICogc3ByaXRlLmRlc3Ryb3kodHJ1ZSk7XG4gICAqIHNwcml0ZS5kZXN0cm95KHsgdGV4dHVyZTogdHJ1ZSwgdGV4dHVyZVNvdXJjZTogdHJ1ZSB9KTtcbiAgICovXG4gIGRlc3Ryb3kob3B0aW9ucyA9IGZhbHNlKSB7XG4gICAgc3VwZXIuZGVzdHJveShvcHRpb25zKTtcbiAgICBjb25zdCBkZXN0cm95VGV4dHVyZSA9IHR5cGVvZiBvcHRpb25zID09PSBcImJvb2xlYW5cIiA/IG9wdGlvbnMgOiBvcHRpb25zPy50ZXh0dXJlO1xuICAgIGlmIChkZXN0cm95VGV4dHVyZSkge1xuICAgICAgY29uc3QgZGVzdHJveVRleHR1cmVTb3VyY2UgPSB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJib29sZWFuXCIgPyBvcHRpb25zIDogb3B0aW9ucz8udGV4dHVyZVNvdXJjZTtcbiAgICAgIHRoaXMuX3RleHR1cmUuZGVzdHJveShkZXN0cm95VGV4dHVyZVNvdXJjZSk7XG4gICAgfVxuICAgIHRoaXMuX3RleHR1cmUgPSBudWxsO1xuICAgIHRoaXMuX3Zpc3VhbEJvdW5kcyA9IG51bGw7XG4gICAgdGhpcy5fYm91bmRzID0gbnVsbDtcbiAgICB0aGlzLl9hbmNob3IgPSBudWxsO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgYW5jaG9yIHNldHMgdGhlIG9yaWdpbiBwb2ludCBvZiB0aGUgc3ByaXRlLiBUaGUgZGVmYXVsdCB2YWx1ZSBpcyB0YWtlbiBmcm9tIHRoZSB7QGxpbmsgVGV4dHVyZX1cbiAgICogYW5kIHBhc3NlZCB0byB0aGUgY29uc3RydWN0b3IuXG4gICAqXG4gICAqIC0gVGhlIGRlZmF1bHQgaXMgYCgwLDApYCwgdGhpcyBtZWFucyB0aGUgc3ByaXRlJ3Mgb3JpZ2luIGlzIHRoZSB0b3AgbGVmdC5cbiAgICogLSBTZXR0aW5nIHRoZSBhbmNob3IgdG8gYCgwLjUsMC41KWAgbWVhbnMgdGhlIHNwcml0ZSdzIG9yaWdpbiBpcyBjZW50ZXJlZC5cbiAgICogLSBTZXR0aW5nIHRoZSBhbmNob3IgdG8gYCgxLDEpYCB3b3VsZCBtZWFuIHRoZSBzcHJpdGUncyBvcmlnaW4gcG9pbnQgd2lsbCBiZSB0aGUgYm90dG9tIHJpZ2h0IGNvcm5lci5cbiAgICpcbiAgICogSWYgeW91IHBhc3Mgb25seSBzaW5nbGUgcGFyYW1ldGVyLCBpdCB3aWxsIHNldCBib3RoIHggYW5kIHkgdG8gdGhlIHNhbWUgdmFsdWUgYXMgc2hvd24gaW4gdGhlIGV4YW1wbGUgYmVsb3cuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIENlbnRlciB0aGUgYW5jaG9yIHBvaW50XG4gICAqIHNwcml0ZS5hbmNob3IgPSAwLjU7IC8vIFNldHMgYm90aCB4IGFuZCB5IHRvIDAuNVxuICAgKiBzcHJpdGUucG9zaXRpb24uc2V0KDQwMCwgMzAwKTsgLy8gU3ByaXRlIHdpbGwgYmUgY2VudGVyZWQgYXQgdGhpcyBwb3NpdGlvblxuICAgKlxuICAgKiAvLyBTZXQgc3BlY2lmaWMgeC95IGFuY2hvciBwb2ludHNcbiAgICogc3ByaXRlLmFuY2hvciA9IHtcbiAgICogICAgIHg6IDEsIC8vIFJpZ2h0IGVkZ2VcbiAgICogICAgIHk6IDAgIC8vIFRvcCBlZGdlXG4gICAqIH07XG4gICAqXG4gICAqIC8vIFVzaW5nIGluZGl2aWR1YWwgY29vcmRpbmF0ZXNcbiAgICogc3ByaXRlLmFuY2hvci5zZXQoMC41LCAxKTsgLy8gQ2VudGVyLWJvdHRvbVxuICAgKlxuICAgKiAvLyBGb3Igcm90YXRpb24gYXJvdW5kIGNlbnRlclxuICAgKiBzcHJpdGUuYW5jaG9yLnNldCgwLjUpO1xuICAgKiBzcHJpdGUucm90YXRpb24gPSBNYXRoLlBJIC8gNDsgLy8gNDUgZGVncmVlcyBhcm91bmQgY2VudGVyXG4gICAqXG4gICAqIC8vIEZvciBzY2FsaW5nIGZyb20gY2VudGVyXG4gICAqIHNwcml0ZS5hbmNob3Iuc2V0KDAuNSk7XG4gICAqIHNwcml0ZS5zY2FsZS5zZXQoMik7IC8vIFNjYWxlcyBmcm9tIGNlbnRlciBwb2ludFxuICAgKiBgYGBcbiAgICovXG4gIGdldCBhbmNob3IoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FuY2hvcjtcbiAgfVxuICBzZXQgYW5jaG9yKHZhbHVlKSB7XG4gICAgdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiID8gdGhpcy5fYW5jaG9yLnNldCh2YWx1ZSkgOiB0aGlzLl9hbmNob3IuY29weUZyb20odmFsdWUpO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgd2lkdGggb2YgdGhlIHNwcml0ZSwgc2V0dGluZyB0aGlzIHdpbGwgYWN0dWFsbHkgbW9kaWZ5IHRoZSBzY2FsZSB0byBhY2hpZXZlIHRoZSB2YWx1ZSBzZXQuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIFNldCB3aWR0aCBkaXJlY3RseVxuICAgKiBzcHJpdGUud2lkdGggPSAyMDA7XG4gICAqIGNvbnNvbGUubG9nKHNwcml0ZS5zY2FsZS54KTsgLy8gU2NhbGUgYWRqdXN0ZWQgdG8gbWF0Y2ggd2lkdGhcbiAgICpcbiAgICogLy8gU2V0IHdpZHRoIHdoaWxlIHByZXNlcnZpbmcgYXNwZWN0IHJhdGlvXG4gICAqIGNvbnN0IHJhdGlvID0gc3ByaXRlLmhlaWdodCAvIHNwcml0ZS53aWR0aDtcbiAgICogc3ByaXRlLndpZHRoID0gMzAwO1xuICAgKiBzcHJpdGUuaGVpZ2h0ID0gMzAwICogcmF0aW87XG4gICAqXG4gICAqIC8vIEZvciBiZXR0ZXIgcGVyZm9ybWFuY2Ugd2hlbiBzZXR0aW5nIGJvdGggd2lkdGggYW5kIGhlaWdodFxuICAgKiBzcHJpdGUuc2V0U2l6ZSgzMDAsIDQwMCk7IC8vIEF2b2lkcyByZWNhbGN1bGF0aW5nIGJvdW5kcyB0d2ljZVxuICAgKlxuICAgKiAvLyBSZXNldCB0byBvcmlnaW5hbCB0ZXh0dXJlIHNpemVcbiAgICogc3ByaXRlLndpZHRoID0gc3ByaXRlLnRleHR1cmUub3JpZy53aWR0aDtcbiAgICogYGBgXG4gICAqL1xuICBnZXQgd2lkdGgoKSB7XG4gICAgcmV0dXJuIE1hdGguYWJzKHRoaXMuc2NhbGUueCkgKiB0aGlzLl90ZXh0dXJlLm9yaWcud2lkdGg7XG4gIH1cbiAgc2V0IHdpZHRoKHZhbHVlKSB7XG4gICAgdGhpcy5fc2V0V2lkdGgodmFsdWUsIHRoaXMuX3RleHR1cmUub3JpZy53aWR0aCk7XG4gICAgdGhpcy5fd2lkdGggPSB2YWx1ZTtcbiAgfVxuICAvKipcbiAgICogVGhlIGhlaWdodCBvZiB0aGUgc3ByaXRlLCBzZXR0aW5nIHRoaXMgd2lsbCBhY3R1YWxseSBtb2RpZnkgdGhlIHNjYWxlIHRvIGFjaGlldmUgdGhlIHZhbHVlIHNldC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gU2V0IGhlaWdodCBkaXJlY3RseVxuICAgKiBzcHJpdGUuaGVpZ2h0ID0gMTUwO1xuICAgKiBjb25zb2xlLmxvZyhzcHJpdGUuc2NhbGUueSk7IC8vIFNjYWxlIGFkanVzdGVkIHRvIG1hdGNoIGhlaWdodFxuICAgKlxuICAgKiAvLyBTZXQgaGVpZ2h0IHdoaWxlIHByZXNlcnZpbmcgYXNwZWN0IHJhdGlvXG4gICAqIGNvbnN0IHJhdGlvID0gc3ByaXRlLndpZHRoIC8gc3ByaXRlLmhlaWdodDtcbiAgICogc3ByaXRlLmhlaWdodCA9IDIwMDtcbiAgICogc3ByaXRlLndpZHRoID0gMjAwICogcmF0aW87XG4gICAqXG4gICAqIC8vIEZvciBiZXR0ZXIgcGVyZm9ybWFuY2Ugd2hlbiBzZXR0aW5nIGJvdGggd2lkdGggYW5kIGhlaWdodFxuICAgKiBzcHJpdGUuc2V0U2l6ZSgzMDAsIDQwMCk7IC8vIEF2b2lkcyByZWNhbGN1bGF0aW5nIGJvdW5kcyB0d2ljZVxuICAgKlxuICAgKiAvLyBSZXNldCB0byBvcmlnaW5hbCB0ZXh0dXJlIHNpemVcbiAgICogc3ByaXRlLmhlaWdodCA9IHNwcml0ZS50ZXh0dXJlLm9yaWcuaGVpZ2h0O1xuICAgKiBgYGBcbiAgICovXG4gIGdldCBoZWlnaHQoKSB7XG4gICAgcmV0dXJuIE1hdGguYWJzKHRoaXMuc2NhbGUueSkgKiB0aGlzLl90ZXh0dXJlLm9yaWcuaGVpZ2h0O1xuICB9XG4gIHNldCBoZWlnaHQodmFsdWUpIHtcbiAgICB0aGlzLl9zZXRIZWlnaHQodmFsdWUsIHRoaXMuX3RleHR1cmUub3JpZy5oZWlnaHQpO1xuICAgIHRoaXMuX2hlaWdodCA9IHZhbHVlO1xuICB9XG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgdGhlIHNpemUgb2YgdGhlIFNwcml0ZSBhcyBhIFtTaXplXXtAbGluayBTaXplfSBvYmplY3QgYmFzZWQgb24gdGhlIHRleHR1cmUgZGltZW5zaW9ucyBhbmQgc2NhbGUuXG4gICAqIFRoaXMgaXMgZmFzdGVyIHRoYW4gZ2V0dGluZyB3aWR0aCBhbmQgaGVpZ2h0IHNlcGFyYXRlbHkgYXMgaXQgb25seSBjYWxjdWxhdGVzIHRoZSBib3VuZHMgb25jZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgc2l6ZSByZXRyaWV2YWxcbiAgICogY29uc3Qgc3ByaXRlID0gbmV3IFNwcml0ZShUZXh0dXJlLmZyb20oJ3Nwcml0ZS5wbmcnKSk7XG4gICAqIGNvbnN0IHNpemUgPSBzcHJpdGUuZ2V0U2l6ZSgpO1xuICAgKiBjb25zb2xlLmxvZyhgU2l6ZTogJHtzaXplLndpZHRofXgke3NpemUuaGVpZ2h0fWApO1xuICAgKlxuICAgKiAvLyBSZXVzZSBleGlzdGluZyBzaXplIG9iamVjdFxuICAgKiBjb25zdCByZXVzZVNpemUgPSB7IHdpZHRoOiAwLCBoZWlnaHQ6IDAgfTtcbiAgICogc3ByaXRlLmdldFNpemUocmV1c2VTaXplKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSBvdXQgLSBPcHRpb25hbCBvYmplY3QgdG8gc3RvcmUgdGhlIHNpemUgaW4sIHRvIGF2b2lkIGFsbG9jYXRpbmcgYSBuZXcgb2JqZWN0XG4gICAqIEByZXR1cm5zIFRoZSBzaXplIG9mIHRoZSBTcHJpdGVcbiAgICogQHNlZSB7QGxpbmsgU3ByaXRlI3dpZHRofSBGb3IgZ2V0dGluZyBqdXN0IHRoZSB3aWR0aFxuICAgKiBAc2VlIHtAbGluayBTcHJpdGUjaGVpZ2h0fSBGb3IgZ2V0dGluZyBqdXN0IHRoZSBoZWlnaHRcbiAgICogQHNlZSB7QGxpbmsgU3ByaXRlI3NldFNpemV9IEZvciBzZXR0aW5nIGJvdGggd2lkdGggYW5kIGhlaWdodFxuICAgKi9cbiAgZ2V0U2l6ZShvdXQpIHtcbiAgICBvdXQgfHwgKG91dCA9IHt9KTtcbiAgICBvdXQud2lkdGggPSBNYXRoLmFicyh0aGlzLnNjYWxlLngpICogdGhpcy5fdGV4dHVyZS5vcmlnLndpZHRoO1xuICAgIG91dC5oZWlnaHQgPSBNYXRoLmFicyh0aGlzLnNjYWxlLnkpICogdGhpcy5fdGV4dHVyZS5vcmlnLmhlaWdodDtcbiAgICByZXR1cm4gb3V0O1xuICB9XG4gIC8qKlxuICAgKiBTZXRzIHRoZSBzaXplIG9mIHRoZSBTcHJpdGUgdG8gdGhlIHNwZWNpZmllZCB3aWR0aCBhbmQgaGVpZ2h0LlxuICAgKiBUaGlzIGlzIGZhc3RlciB0aGFuIHNldHRpbmcgd2lkdGggYW5kIGhlaWdodCBzZXBhcmF0ZWx5IGFzIGl0IG9ubHkgcmVjYWxjdWxhdGVzIGJvdW5kcyBvbmNlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBzaXplIHNldHRpbmdcbiAgICogY29uc3Qgc3ByaXRlID0gbmV3IFNwcml0ZShUZXh0dXJlLmZyb20oJ3Nwcml0ZS5wbmcnKSk7XG4gICAqIHNwcml0ZS5zZXRTaXplKDEwMCwgMjAwKTsgLy8gV2lkdGg6IDEwMCwgSGVpZ2h0OiAyMDBcbiAgICpcbiAgICogLy8gU2V0IHVuaWZvcm0gc2l6ZVxuICAgKiBzcHJpdGUuc2V0U2l6ZSgxMDApOyAvLyBTZXRzIGJvdGggd2lkdGggYW5kIGhlaWdodCB0byAxMDBcbiAgICpcbiAgICogLy8gU2V0IHNpemUgd2l0aCBvYmplY3RcbiAgICogc3ByaXRlLnNldFNpemUoe1xuICAgKiAgICAgd2lkdGg6IDIwMCxcbiAgICogICAgIGhlaWdodDogMzAwXG4gICAqIH0pO1xuICAgKlxuICAgKiAvLyBSZXNldCB0byB0ZXh0dXJlIHNpemVcbiAgICogc3ByaXRlLnNldFNpemUoXG4gICAqICAgICBzcHJpdGUudGV4dHVyZS5vcmlnLndpZHRoLFxuICAgKiAgICAgc3ByaXRlLnRleHR1cmUub3JpZy5oZWlnaHRcbiAgICogKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSB2YWx1ZSAtIFRoaXMgY2FuIGJlIGVpdGhlciBhIG51bWJlciBvciBhIHtAbGluayBTaXplfSBvYmplY3RcbiAgICogQHBhcmFtIGhlaWdodCAtIFRoZSBoZWlnaHQgdG8gc2V0LiBEZWZhdWx0cyB0byB0aGUgdmFsdWUgb2YgYHdpZHRoYCBpZiBub3QgcHJvdmlkZWRcbiAgICogQHNlZSB7QGxpbmsgU3ByaXRlI3dpZHRofSBGb3Igc2V0dGluZyB3aWR0aCBvbmx5XG4gICAqIEBzZWUge0BsaW5rIFNwcml0ZSNoZWlnaHR9IEZvciBzZXR0aW5nIGhlaWdodCBvbmx5XG4gICAqIEBzZWUge0BsaW5rIFNwcml0ZSN0ZXh0dXJlfSBGb3IgdGhlIHNvdXJjZSBkaW1lbnNpb25zXG4gICAqL1xuICBzZXRTaXplKHZhbHVlLCBoZWlnaHQpIHtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiKSB7XG4gICAgICBoZWlnaHQgPSB2YWx1ZS5oZWlnaHQgPz8gdmFsdWUud2lkdGg7XG4gICAgICB2YWx1ZSA9IHZhbHVlLndpZHRoO1xuICAgIH0gZWxzZSB7XG4gICAgICBoZWlnaHQgPz8gKGhlaWdodCA9IHZhbHVlKTtcbiAgICB9XG4gICAgdmFsdWUgIT09IHZvaWQgMCAmJiB0aGlzLl9zZXRXaWR0aCh2YWx1ZSwgdGhpcy5fdGV4dHVyZS5vcmlnLndpZHRoKTtcbiAgICBoZWlnaHQgIT09IHZvaWQgMCAmJiB0aGlzLl9zZXRIZWlnaHQoaGVpZ2h0LCB0aGlzLl90ZXh0dXJlLm9yaWcuaGVpZ2h0KTtcbiAgfVxufVxuXG5leHBvcnQgeyBTcHJpdGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVNwcml0ZS5tanMubWFwXG4iLCJpbXBvcnQgeyBET01BZGFwdGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vZW52aXJvbm1lbnQvYWRhcHRlci5tanMnO1xuaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVNvdXJjZSB9IGZyb20gJy4vVGV4dHVyZVNvdXJjZS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIENhbnZhc1NvdXJjZSBleHRlbmRzIFRleHR1cmVTb3VyY2Uge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgaWYgKCFvcHRpb25zLnJlc291cmNlKSB7XG4gICAgICBvcHRpb25zLnJlc291cmNlID0gRE9NQWRhcHRlci5nZXQoKS5jcmVhdGVDYW52YXMoKTtcbiAgICB9XG4gICAgaWYgKCFvcHRpb25zLndpZHRoKSB7XG4gICAgICBvcHRpb25zLndpZHRoID0gb3B0aW9ucy5yZXNvdXJjZS53aWR0aDtcbiAgICAgIGlmICghb3B0aW9ucy5hdXRvRGVuc2l0eSkge1xuICAgICAgICBvcHRpb25zLndpZHRoIC89IG9wdGlvbnMucmVzb2x1dGlvbjtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFvcHRpb25zLmhlaWdodCkge1xuICAgICAgb3B0aW9ucy5oZWlnaHQgPSBvcHRpb25zLnJlc291cmNlLmhlaWdodDtcbiAgICAgIGlmICghb3B0aW9ucy5hdXRvRGVuc2l0eSkge1xuICAgICAgICBvcHRpb25zLmhlaWdodCAvPSBvcHRpb25zLnJlc29sdXRpb247XG4gICAgICB9XG4gICAgfVxuICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgIHRoaXMudXBsb2FkTWV0aG9kSWQgPSBcImltYWdlXCI7XG4gICAgdGhpcy5hdXRvRGVuc2l0eSA9IG9wdGlvbnMuYXV0b0RlbnNpdHk7XG4gICAgdGhpcy5yZXNpemVDYW52YXMoKTtcbiAgICB0aGlzLnRyYW5zcGFyZW50ID0gISFvcHRpb25zLnRyYW5zcGFyZW50O1xuICB9XG4gIHJlc2l6ZUNhbnZhcygpIHtcbiAgICBpZiAodGhpcy5hdXRvRGVuc2l0eSAmJiBcInN0eWxlXCIgaW4gdGhpcy5yZXNvdXJjZSkge1xuICAgICAgdGhpcy5yZXNvdXJjZS5zdHlsZS53aWR0aCA9IGAke3RoaXMud2lkdGh9cHhgO1xuICAgICAgdGhpcy5yZXNvdXJjZS5zdHlsZS5oZWlnaHQgPSBgJHt0aGlzLmhlaWdodH1weGA7XG4gICAgfVxuICAgIGlmICh0aGlzLnJlc291cmNlLndpZHRoICE9PSB0aGlzLnBpeGVsV2lkdGggfHwgdGhpcy5yZXNvdXJjZS5oZWlnaHQgIT09IHRoaXMucGl4ZWxIZWlnaHQpIHtcbiAgICAgIHRoaXMucmVzb3VyY2Uud2lkdGggPSB0aGlzLnBpeGVsV2lkdGg7XG4gICAgICB0aGlzLnJlc291cmNlLmhlaWdodCA9IHRoaXMucGl4ZWxIZWlnaHQ7XG4gICAgfVxuICB9XG4gIHJlc2l6ZSh3aWR0aCA9IHRoaXMud2lkdGgsIGhlaWdodCA9IHRoaXMuaGVpZ2h0LCByZXNvbHV0aW9uID0gdGhpcy5fcmVzb2x1dGlvbikge1xuICAgIGNvbnN0IGRpZFJlc2l6ZSA9IHN1cGVyLnJlc2l6ZSh3aWR0aCwgaGVpZ2h0LCByZXNvbHV0aW9uKTtcbiAgICBpZiAoZGlkUmVzaXplKSB7XG4gICAgICB0aGlzLnJlc2l6ZUNhbnZhcygpO1xuICAgIH1cbiAgICByZXR1cm4gZGlkUmVzaXplO1xuICB9XG4gIHN0YXRpYyB0ZXN0KHJlc291cmNlKSB7XG4gICAgcmV0dXJuIGdsb2JhbFRoaXMuSFRNTENhbnZhc0VsZW1lbnQgJiYgcmVzb3VyY2UgaW5zdGFuY2VvZiBIVE1MQ2FudmFzRWxlbWVudCB8fCBnbG9iYWxUaGlzLk9mZnNjcmVlbkNhbnZhcyAmJiByZXNvdXJjZSBpbnN0YW5jZW9mIE9mZnNjcmVlbkNhbnZhcztcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgMkQgcmVuZGVyaW5nIGNvbnRleHQgZm9yIHRoZSBjYW52YXMuXG4gICAqIENhY2hlcyB0aGUgY29udGV4dCBhZnRlciBjcmVhdGluZyBpdC5cbiAgICogQHJldHVybnMgVGhlIDJEIHJlbmRlcmluZyBjb250ZXh0IG9mIHRoZSBjYW52YXMuXG4gICAqL1xuICBnZXQgY29udGV4dDJEKCkge1xuICAgIHJldHVybiB0aGlzLl9jb250ZXh0MkQgfHwgKHRoaXMuX2NvbnRleHQyRCA9IHRoaXMucmVzb3VyY2UuZ2V0Q29udGV4dChcIjJkXCIpKTtcbiAgfVxufVxuQ2FudmFzU291cmNlLmV4dGVuc2lvbiA9IEV4dGVuc2lvblR5cGUuVGV4dHVyZVNvdXJjZTtcblxuZXhwb3J0IHsgQ2FudmFzU291cmNlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1DYW52YXNTb3VyY2UubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgVVBEQVRFX1BSSU9SSVRZID0gLyogQF9fUFVSRV9fICovICgoVVBEQVRFX1BSSU9SSVRZMikgPT4ge1xuICBVUERBVEVfUFJJT1JJVFkyW1VQREFURV9QUklPUklUWTJbXCJJTlRFUkFDVElPTlwiXSA9IDUwXSA9IFwiSU5URVJBQ1RJT05cIjtcbiAgVVBEQVRFX1BSSU9SSVRZMltVUERBVEVfUFJJT1JJVFkyW1wiSElHSFwiXSA9IDI1XSA9IFwiSElHSFwiO1xuICBVUERBVEVfUFJJT1JJVFkyW1VQREFURV9QUklPUklUWTJbXCJOT1JNQUxcIl0gPSAwXSA9IFwiTk9STUFMXCI7XG4gIFVQREFURV9QUklPUklUWTJbVVBEQVRFX1BSSU9SSVRZMltcIkxPV1wiXSA9IC0yNV0gPSBcIkxPV1wiO1xuICBVUERBVEVfUFJJT1JJVFkyW1VQREFURV9QUklPUklUWTJbXCJVVElMSVRZXCJdID0gLTUwXSA9IFwiVVRJTElUWVwiO1xuICByZXR1cm4gVVBEQVRFX1BSSU9SSVRZMjtcbn0pKFVQREFURV9QUklPUklUWSB8fCB7fSk7XG5cbmV4cG9ydCB7IFVQREFURV9QUklPUklUWSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29uc3QubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBUaWNrZXJMaXN0ZW5lciB7XG4gIC8qKlxuICAgKiBDb25zdHJ1Y3RvclxuICAgKiBAcHJpdmF0ZVxuICAgKiBAcGFyYW0gZm4gLSBUaGUgbGlzdGVuZXIgZnVuY3Rpb24gdG8gYmUgYWRkZWQgZm9yIG9uZSB1cGRhdGVcbiAgICogQHBhcmFtIGNvbnRleHQgLSBUaGUgbGlzdGVuZXIgY29udGV4dFxuICAgKiBAcGFyYW0gcHJpb3JpdHkgLSBUaGUgcHJpb3JpdHkgZm9yIGVtaXR0aW5nXG4gICAqIEBwYXJhbSBvbmNlIC0gSWYgdGhlIGhhbmRsZXIgc2hvdWxkIGZpcmUgb25jZVxuICAgKi9cbiAgY29uc3RydWN0b3IoZm4sIGNvbnRleHQgPSBudWxsLCBwcmlvcml0eSA9IDAsIG9uY2UgPSBmYWxzZSkge1xuICAgIC8qKiBUaGUgbmV4dCBpdGVtIGluIGNoYWluLiAqL1xuICAgIHRoaXMubmV4dCA9IG51bGw7XG4gICAgLyoqIFRoZSBwcmV2aW91cyBpdGVtIGluIGNoYWluLiAqL1xuICAgIHRoaXMucHJldmlvdXMgPSBudWxsO1xuICAgIC8qKiBgdHJ1ZWAgaWYgdGhpcyBsaXN0ZW5lciBoYXMgYmVlbiBkZXN0cm95ZWQgYWxyZWFkeS4gKi9cbiAgICB0aGlzLl9kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9mbiA9IGZuO1xuICAgIHRoaXMuX2NvbnRleHQgPSBjb250ZXh0O1xuICAgIHRoaXMucHJpb3JpdHkgPSBwcmlvcml0eTtcbiAgICB0aGlzLl9vbmNlID0gb25jZTtcbiAgfVxuICAvKipcbiAgICogU2ltcGxlIGNvbXBhcmUgZnVuY3Rpb24gdG8gZmlndXJlIG91dCBpZiBhIGZ1bmN0aW9uIGFuZCBjb250ZXh0IG1hdGNoLlxuICAgKiBAcGFyYW0gZm4gLSBUaGUgbGlzdGVuZXIgZnVuY3Rpb24gdG8gYmUgYWRkZWQgZm9yIG9uZSB1cGRhdGVcbiAgICogQHBhcmFtIGNvbnRleHQgLSBUaGUgbGlzdGVuZXIgY29udGV4dFxuICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGxpc3RlbmVyIG1hdGNoIHRoZSBhcmd1bWVudHNcbiAgICovXG4gIG1hdGNoKGZuLCBjb250ZXh0ID0gbnVsbCkge1xuICAgIHJldHVybiB0aGlzLl9mbiA9PT0gZm4gJiYgdGhpcy5fY29udGV4dCA9PT0gY29udGV4dDtcbiAgfVxuICAvKipcbiAgICogRW1pdCBieSBjYWxsaW5nIHRoZSBjdXJyZW50IGZ1bmN0aW9uLlxuICAgKiBAcGFyYW0gdGlja2VyIC0gVGhlIHRpY2tlciBlbWl0dGluZy5cbiAgICogQHJldHVybnMgTmV4dCB0aWNrZXJcbiAgICovXG4gIGVtaXQodGlja2VyKSB7XG4gICAgaWYgKHRoaXMuX2ZuKSB7XG4gICAgICBpZiAodGhpcy5fY29udGV4dCkge1xuICAgICAgICB0aGlzLl9mbi5jYWxsKHRoaXMuX2NvbnRleHQsIHRpY2tlcik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLl9mbih0aWNrZXIpO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCByZWRpcmVjdCA9IHRoaXMubmV4dDtcbiAgICBpZiAodGhpcy5fb25jZSkge1xuICAgICAgdGhpcy5kZXN0cm95KHRydWUpO1xuICAgIH1cbiAgICBpZiAodGhpcy5fZGVzdHJveWVkKSB7XG4gICAgICB0aGlzLm5leHQgPSBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gcmVkaXJlY3Q7XG4gIH1cbiAgLyoqXG4gICAqIENvbm5lY3QgdG8gdGhlIGxpc3QuXG4gICAqIEBwYXJhbSBwcmV2aW91cyAtIElucHV0IG5vZGUsIHByZXZpb3VzIGxpc3RlbmVyXG4gICAqL1xuICBjb25uZWN0KHByZXZpb3VzKSB7XG4gICAgdGhpcy5wcmV2aW91cyA9IHByZXZpb3VzO1xuICAgIGlmIChwcmV2aW91cy5uZXh0KSB7XG4gICAgICBwcmV2aW91cy5uZXh0LnByZXZpb3VzID0gdGhpcztcbiAgICB9XG4gICAgdGhpcy5uZXh0ID0gcHJldmlvdXMubmV4dDtcbiAgICBwcmV2aW91cy5uZXh0ID0gdGhpcztcbiAgfVxuICAvKipcbiAgICogRGVzdHJveSBhbmQgZG9uJ3QgdXNlIGFmdGVyIHRoaXMuXG4gICAqIEBwYXJhbSBoYXJkIC0gYHRydWVgIHRvIHJlbW92ZSB0aGUgYG5leHRgIHJlZmVyZW5jZSwgdGhpc1xuICAgKiAgICAgICAgaXMgY29uc2lkZXJlZCBhIGhhcmQgZGVzdHJveS4gU29mdCBkZXN0cm95IG1haW50YWlucyB0aGUgbmV4dCByZWZlcmVuY2UuXG4gICAqIEByZXR1cm5zIFRoZSBsaXN0ZW5lciB0byByZWRpcmVjdCB3aGlsZSBlbWl0dGluZyBvciByZW1vdmluZy5cbiAgICovXG4gIGRlc3Ryb3koaGFyZCA9IGZhbHNlKSB7XG4gICAgdGhpcy5fZGVzdHJveWVkID0gdHJ1ZTtcbiAgICB0aGlzLl9mbiA9IG51bGw7XG4gICAgdGhpcy5fY29udGV4dCA9IG51bGw7XG4gICAgaWYgKHRoaXMucHJldmlvdXMpIHtcbiAgICAgIHRoaXMucHJldmlvdXMubmV4dCA9IHRoaXMubmV4dDtcbiAgICB9XG4gICAgaWYgKHRoaXMubmV4dCkge1xuICAgICAgdGhpcy5uZXh0LnByZXZpb3VzID0gdGhpcy5wcmV2aW91cztcbiAgICB9XG4gICAgY29uc3QgcmVkaXJlY3QgPSB0aGlzLm5leHQ7XG4gICAgdGhpcy5uZXh0ID0gaGFyZCA/IG51bGwgOiByZWRpcmVjdDtcbiAgICB0aGlzLnByZXZpb3VzID0gbnVsbDtcbiAgICByZXR1cm4gcmVkaXJlY3Q7XG4gIH1cbn1cblxuZXhwb3J0IHsgVGlja2VyTGlzdGVuZXIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVRpY2tlckxpc3RlbmVyLm1qcy5tYXBcbiIsImltcG9ydCB7IFVQREFURV9QUklPUklUWSB9IGZyb20gJy4vY29uc3QubWpzJztcbmltcG9ydCB7IFRpY2tlckxpc3RlbmVyIH0gZnJvbSAnLi9UaWNrZXJMaXN0ZW5lci5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IF9UaWNrZXIgPSBjbGFzcyBfVGlja2VyIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLyoqXG4gICAgICogV2hldGhlciBvciBub3QgdGhpcyB0aWNrZXIgc2hvdWxkIGludm9rZSB0aGUgbWV0aG9kIHtAbGluayBUaWNrZXIjc3RhcnR8c3RhcnR9XG4gICAgICogYXV0b21hdGljYWxseSB3aGVuIGEgbGlzdGVuZXIgaXMgYWRkZWQuXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIC8vIERlZmF1bHQgYmVoYXZpb3IgKG1hbnVhbCBzdGFydClcbiAgICAgKiBjb25zdCB0aWNrZXIgPSBuZXcgVGlja2VyKCk7XG4gICAgICogdGlja2VyLmF1dG9TdGFydCA9IGZhbHNlO1xuICAgICAqIHRpY2tlci5hZGQoKCkgPT4ge1xuICAgICAqICAgICAvLyBXb24ndCBydW4gdW50aWwgdGlja2VyLnN0YXJ0KCkgaXMgY2FsbGVkXG4gICAgICogfSk7XG4gICAgICpcbiAgICAgKiAvLyBBdXRvLXN0YXJ0IGJlaGF2aW9yXG4gICAgICogY29uc3QgYXV0b1RpY2tlciA9IG5ldyBUaWNrZXIoKTtcbiAgICAgKiBhdXRvVGlja2VyLmF1dG9TdGFydCA9IHRydWU7XG4gICAgICogYXV0b1RpY2tlci5hZGQoKCkgPT4ge1xuICAgICAqICAgICAvLyBSdW5zIGltbWVkaWF0ZWx5IHdoZW4gYWRkZWRcbiAgICAgKiB9KTtcbiAgICAgKiBgYGBcbiAgICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgICAqIEBzZWUge0BsaW5rIFRpY2tlciNzdGFydH0gRm9yIG1hbnVhbGx5IHN0YXJ0aW5nIHRoZSB0aWNrZXJcbiAgICAgKiBAc2VlIHtAbGluayBUaWNrZXIjc3RvcH0gRm9yIG1hbnVhbGx5IHN0b3BwaW5nIHRoZSB0aWNrZXJcbiAgICAgKi9cbiAgICB0aGlzLmF1dG9TdGFydCA9IGZhbHNlO1xuICAgIC8qKlxuICAgICAqIFNjYWxhciByZXByZXNlbnRpbmcgdGhlIGRlbHRhIHRpbWUgZmFjdG9yLlxuICAgICAqIFRoaXMgaXMgYSBkaW1lbnNpb25sZXNzIHZhbHVlIHJlcHJlc2VudGluZyB0aGUgZnJhY3Rpb24gb2YgYSBmcmFtZSBhdCB0aGUgdGFyZ2V0IGZyYW1lcmF0ZS5cbiAgICAgKiBBdCA2MCBGUFMsIHRoaXMgdmFsdWUgaXMgdHlwaWNhbGx5IGFyb3VuZCAxLjAuXG4gICAgICpcbiAgICAgKiBUaGlzIGlzIE5PVCBpbiBtaWxsaXNlY29uZHMgLSBpdCdzIGEgc2NhbGFyIG11bHRpcGxpZXIgZm9yIGZyYW1lLWluZGVwZW5kZW50IGFuaW1hdGlvbnMuXG4gICAgICogRm9yIGFjdHVhbCBtaWxsaXNlY29uZHMsIHVzZSB7QGxpbmsgVGlja2VyI2RlbHRhTVN9LlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiAvLyBGcmFtZS1pbmRlcGVuZGVudCBhbmltYXRpb24gdXNpbmcgZGVsdGFUaW1lIHNjYWxhclxuICAgICAqIHRpY2tlci5hZGQoKHRpY2tlcikgPT4ge1xuICAgICAqICAgICAvLyBSb3RhdGUgc3ByaXRlIGJ5IDAuMSByYWRpYW5zIHBlciBmcmFtZSwgc2NhbGVkIGJ5IGRlbHRhVGltZVxuICAgICAqICAgICBzcHJpdGUucm90YXRpb24gKz0gMC4xICogdGlja2VyLmRlbHRhVGltZTtcbiAgICAgKiB9KTtcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICB0aGlzLmRlbHRhVGltZSA9IDE7XG4gICAgLyoqXG4gICAgICogVGhlIGxhc3QgdGltZSB1cGRhdGUgd2FzIGludm9rZWQsIGluIG1pbGxpc2Vjb25kcyBzaW5jZSBlcG9jaC5cbiAgICAgKiBTaW1pbGFyIHRvIHBlcmZvcm1hbmNlLm5vdygpIHRpbWVzdGFtcCBmb3JtYXQuXG4gICAgICpcbiAgICAgKiBVc2VkIGludGVybmFsbHkgZm9yIGNhbGN1bGF0aW5nIHRpbWUgZGVsdGFzIGJldHdlZW4gZnJhbWVzLlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiB0aWNrZXIuYWRkKCh0aWNrZXIpID0+IHtcbiAgICAgKiAgICAgY29uc3QgY3VycmVudFRpbWUgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgKiAgICAgY29uc3QgdGltZVNpbmNlTGFzdEZyYW1lID0gY3VycmVudFRpbWUgLSB0aWNrZXIubGFzdFRpbWU7XG4gICAgICogICAgIGNvbnNvbGUubG9nKGBUaW1lIHNpbmNlIGxhc3QgZnJhbWU6ICR7dGltZVNpbmNlTGFzdEZyYW1lfW1zYCk7XG4gICAgICogfSk7XG4gICAgICogYGBgXG4gICAgICovXG4gICAgdGhpcy5sYXN0VGltZSA9IC0xO1xuICAgIC8qKlxuICAgICAqIEZhY3RvciBvZiBjdXJyZW50IHtAbGluayBUaWNrZXIjZGVsdGFUaW1lfGRlbHRhVGltZX0uXG4gICAgICogVXNlZCB0byBzY2FsZSB0aW1lIGZvciBzbG93IG1vdGlvbiBvciBmYXN0LWZvcndhcmQgZWZmZWN0cy5cbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogLy8gQmFzaWMgc3BlZWQgYWRqdXN0bWVudFxuICAgICAqIHRpY2tlci5zcGVlZCA9IDAuNTsgLy8gSGFsZiBzcGVlZCAoc2xvdyBtb3Rpb24pXG4gICAgICogdGlja2VyLnNwZWVkID0gMi4wOyAvLyBEb3VibGUgc3BlZWQgKGZhc3QgZm9yd2FyZClcbiAgICAgKlxuICAgICAqIC8vIFRlbXBvcmFyeSBzcGVlZCBjaGFuZ2VzXG4gICAgICogZnVuY3Rpb24gc2xvd01vdGlvbigpIHtcbiAgICAgKiAgICAgY29uc3Qgbm9ybWFsU3BlZWQgPSB0aWNrZXIuc3BlZWQ7XG4gICAgICogICAgIHRpY2tlci5zcGVlZCA9IDAuMjtcbiAgICAgKiAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICogICAgICAgICB0aWNrZXIuc3BlZWQgPSBub3JtYWxTcGVlZDtcbiAgICAgKiAgICAgfSwgMTAwMCk7XG4gICAgICogfVxuICAgICAqIGBgYFxuICAgICAqL1xuICAgIHRoaXMuc3BlZWQgPSAxO1xuICAgIC8qKlxuICAgICAqIFdoZXRoZXIgb3Igbm90IHRoaXMgdGlja2VyIGhhcyBiZWVuIHN0YXJ0ZWQuXG4gICAgICpcbiAgICAgKiBgdHJ1ZWAgaWYge0BsaW5rIFRpY2tlciNzdGFydHxzdGFydH0gaGFzIGJlZW4gY2FsbGVkLlxuICAgICAqIGBmYWxzZWAgaWYge0BsaW5rIFRpY2tlciNzdG9wfFN0b3B9IGhhcyBiZWVuIGNhbGxlZC5cbiAgICAgKlxuICAgICAqIFdoaWxlIGBmYWxzZWAsIHRoaXMgdmFsdWUgbWF5IGNoYW5nZSB0byBgdHJ1ZWAgaW4gdGhlXG4gICAgICogZXZlbnQgb2Yge0BsaW5rIFRpY2tlciNhdXRvU3RhcnR8YXV0b1N0YXJ0fSBiZWluZyBgdHJ1ZWBcbiAgICAgKiBhbmQgYSBsaXN0ZW5lciBpcyBhZGRlZC5cbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogLy8gQ2hlY2sgdGlja2VyIHN0YXRlXG4gICAgICogY29uc3QgdGlja2VyID0gbmV3IFRpY2tlcigpO1xuICAgICAqIGNvbnNvbGUubG9nKHRpY2tlci5zdGFydGVkKTsgLy8gZmFsc2VcbiAgICAgKlxuICAgICAqIC8vIFN0YXJ0IGFuZCB2ZXJpZnlcbiAgICAgKiB0aWNrZXIuc3RhcnQoKTtcbiAgICAgKiBjb25zb2xlLmxvZyh0aWNrZXIuc3RhcnRlZCk7IC8vIHRydWVcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICB0aGlzLnN0YXJ0ZWQgPSBmYWxzZTtcbiAgICAvKiogSW50ZXJuYWwgY3VycmVudCBmcmFtZSByZXF1ZXN0IElEICovXG4gICAgdGhpcy5fcmVxdWVzdElkID0gbnVsbDtcbiAgICAvKipcbiAgICAgKiBJbnRlcm5hbCB2YWx1ZSBtYW5hZ2VkIGJ5IG1pbkZQUyBwcm9wZXJ0eSBzZXR0ZXIgYW5kIGdldHRlci5cbiAgICAgKiBUaGlzIGlzIHRoZSBtYXhpbXVtIGFsbG93ZWQgbWlsbGlzZWNvbmRzIGJldHdlZW4gdXBkYXRlcy5cbiAgICAgKi9cbiAgICB0aGlzLl9tYXhFbGFwc2VkTVMgPSAxMDA7XG4gICAgLyoqXG4gICAgICogSW50ZXJuYWwgdmFsdWUgbWFuYWdlZCBieSBtYXhGUFMgcHJvcGVydHkgc2V0dGVyIGFuZCBnZXR0ZXIuXG4gICAgICogVGhpcyBpcyB0aGUgbWluaW11bSBhbGxvd2VkIG1pbGxpc2Vjb25kcyBiZXR3ZWVuIHVwZGF0ZXMuXG4gICAgICovXG4gICAgdGhpcy5fbWluRWxhcHNlZE1TID0gMDtcbiAgICAvKiogSWYgZW5hYmxlZCwgZGVsZXRpbmcgaXMgZGlzYWJsZWQuKi9cbiAgICB0aGlzLl9wcm90ZWN0ZWQgPSBmYWxzZTtcbiAgICAvKiogVGhlIGxhc3QgdGltZSBrZXlmcmFtZSB3YXMgZXhlY3V0ZWQuIE1haW50YWlucyBhIHJlbGF0aXZlbHkgZml4ZWQgaW50ZXJ2YWwgd2l0aCB0aGUgcHJldmlvdXMgdmFsdWUuICovXG4gICAgdGhpcy5fbGFzdEZyYW1lID0gLTE7XG4gICAgdGhpcy5faGVhZCA9IG5ldyBUaWNrZXJMaXN0ZW5lcihudWxsLCBudWxsLCBJbmZpbml0eSk7XG4gICAgdGhpcy5kZWx0YU1TID0gMSAvIF9UaWNrZXIudGFyZ2V0RlBNUztcbiAgICB0aGlzLmVsYXBzZWRNUyA9IDEgLyBfVGlja2VyLnRhcmdldEZQTVM7XG4gICAgdGhpcy5fdGljayA9ICh0aW1lKSA9PiB7XG4gICAgICB0aGlzLl9yZXF1ZXN0SWQgPSBudWxsO1xuICAgICAgaWYgKHRoaXMuc3RhcnRlZCkge1xuICAgICAgICB0aGlzLnVwZGF0ZSh0aW1lKTtcbiAgICAgICAgaWYgKHRoaXMuc3RhcnRlZCAmJiB0aGlzLl9yZXF1ZXN0SWQgPT09IG51bGwgJiYgdGhpcy5faGVhZC5uZXh0KSB7XG4gICAgICAgICAgdGhpcy5fcmVxdWVzdElkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRoaXMuX3RpY2spO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgfVxuICAvKipcbiAgICogQ29uZGl0aW9uYWxseSByZXF1ZXN0cyBhIG5ldyBhbmltYXRpb24gZnJhbWUuXG4gICAqIElmIGEgZnJhbWUgaGFzIG5vdCBhbHJlYWR5IGJlZW4gcmVxdWVzdGVkLCBhbmQgaWYgdGhlIGludGVybmFsXG4gICAqIGVtaXR0ZXIgaGFzIGxpc3RlbmVycywgYSBuZXcgZnJhbWUgaXMgcmVxdWVzdGVkLlxuICAgKi9cbiAgX3JlcXVlc3RJZk5lZWRlZCgpIHtcbiAgICBpZiAodGhpcy5fcmVxdWVzdElkID09PSBudWxsICYmIHRoaXMuX2hlYWQubmV4dCkge1xuICAgICAgdGhpcy5sYXN0VGltZSA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgdGhpcy5fbGFzdEZyYW1lID0gdGhpcy5sYXN0VGltZTtcbiAgICAgIHRoaXMuX3JlcXVlc3RJZCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh0aGlzLl90aWNrKTtcbiAgICB9XG4gIH1cbiAgLyoqIENvbmRpdGlvbmFsbHkgY2FuY2VscyBhIHBlbmRpbmcgYW5pbWF0aW9uIGZyYW1lLiAqL1xuICBfY2FuY2VsSWZOZWVkZWQoKSB7XG4gICAgaWYgKHRoaXMuX3JlcXVlc3RJZCAhPT0gbnVsbCkge1xuICAgICAgY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5fcmVxdWVzdElkKTtcbiAgICAgIHRoaXMuX3JlcXVlc3RJZCA9IG51bGw7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBDb25kaXRpb25hbGx5IHJlcXVlc3RzIGEgbmV3IGFuaW1hdGlvbiBmcmFtZS5cbiAgICogSWYgdGhlIHRpY2tlciBoYXMgYmVlbiBzdGFydGVkIGl0IGNoZWNrcyBpZiBhIGZyYW1lIGhhcyBub3QgYWxyZWFkeVxuICAgKiBiZWVuIHJlcXVlc3RlZCwgYW5kIGlmIHRoZSBpbnRlcm5hbCBlbWl0dGVyIGhhcyBsaXN0ZW5lcnMuIElmIHRoZXNlXG4gICAqIGNvbmRpdGlvbnMgYXJlIG1ldCwgYSBuZXcgZnJhbWUgaXMgcmVxdWVzdGVkLiBJZiB0aGUgdGlja2VyIGhhcyBub3RcbiAgICogYmVlbiBzdGFydGVkLCBidXQgYXV0b1N0YXJ0IGlzIGB0cnVlYCwgdGhlbiB0aGUgdGlja2VyIHN0YXJ0cyBub3csXG4gICAqIGFuZCBjb250aW51ZXMgd2l0aCB0aGUgcHJldmlvdXMgY29uZGl0aW9ucyB0byByZXF1ZXN0IGEgbmV3IGZyYW1lLlxuICAgKi9cbiAgX3N0YXJ0SWZQb3NzaWJsZSgpIHtcbiAgICBpZiAodGhpcy5zdGFydGVkKSB7XG4gICAgICB0aGlzLl9yZXF1ZXN0SWZOZWVkZWQoKTtcbiAgICB9IGVsc2UgaWYgKHRoaXMuYXV0b1N0YXJ0KSB7XG4gICAgICB0aGlzLnN0YXJ0KCk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBSZWdpc3RlciBhIGhhbmRsZXIgZm9yIHRpY2sgZXZlbnRzLlxuICAgKiBAcGFyYW0gZm4gLSBUaGUgbGlzdGVuZXIgZnVuY3Rpb24gdG8gYWRkLiBSZWNlaXZlcyB0aGUgVGlja2VyIGluc3RhbmNlIGFzIHBhcmFtZXRlclxuICAgKiBAcGFyYW0gY29udGV4dCAtIFRoZSBjb250ZXh0IGZvciB0aGUgbGlzdGVuZXJcbiAgICogQHBhcmFtIHByaW9yaXR5IC0gVGhlIHByaW9yaXR5IG9mIHRoZSBsaXN0ZW5lclxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBBY2Nlc3MgdGltZSBwcm9wZXJ0aWVzIHRocm91Z2ggdGhlIHRpY2tlciBwYXJhbWV0ZXJcbiAgICogdGlja2VyLmFkZCgodGlja2VyKSA9PiB7XG4gICAqICAgICAvLyBVc2UgZGVsdGFUaW1lIChkaW1lbnNpb25sZXNzIHNjYWxhcikgZm9yIGZyYW1lLWluZGVwZW5kZW50IGFuaW1hdGlvbnNcbiAgICogICAgIHNwcml0ZS5yb3RhdGlvbiArPSAwLjEgKiB0aWNrZXIuZGVsdGFUaW1lO1xuICAgKlxuICAgKiAgICAgLy8gVXNlIGRlbHRhTVMgKG1pbGxpc2Vjb25kcykgZm9yIHRpbWUtYmFzZWQgY2FsY3VsYXRpb25zXG4gICAqICAgICBjb25zdCBwcm9ncmVzcyA9IHRpY2tlci5kZWx0YU1TIC8gYW5pbWF0aW9uRHVyYXRpb247XG4gICAqXG4gICAqICAgICAvLyBVc2UgZWxhcHNlZE1TIGZvciByYXcgdGltaW5nIG1lYXN1cmVtZW50c1xuICAgKiAgICAgY29uc29sZS5sb2coYFJhdyBmcmFtZSB0aW1lOiAke3RpY2tlci5lbGFwc2VkTVN9bXNgKTtcbiAgICogfSk7XG4gICAqIGBgYFxuICAgKi9cbiAgYWRkKGZuLCBjb250ZXh0LCBwcmlvcml0eSA9IFVQREFURV9QUklPUklUWS5OT1JNQUwpIHtcbiAgICByZXR1cm4gdGhpcy5fYWRkTGlzdGVuZXIobmV3IFRpY2tlckxpc3RlbmVyKGZuLCBjb250ZXh0LCBwcmlvcml0eSkpO1xuICB9XG4gIC8qKlxuICAgKiBBZGQgYSBoYW5kbGVyIGZvciB0aGUgdGljayBldmVudCB3aGljaCBpcyBvbmx5IGV4ZWN1dGVkIG9uY2Ugb24gdGhlIG5leHQgZnJhbWUuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIG9uZS10aW1lIHVwZGF0ZVxuICAgKiB0aWNrZXIuYWRkT25jZSgoKSA9PiB7XG4gICAqICAgICBjb25zb2xlLmxvZygnUnVucyBuZXh0IGZyYW1lIG9ubHknKTtcbiAgICogfSk7XG4gICAqXG4gICAqIC8vIFdpdGggc3BlY2lmaWMgY29udGV4dFxuICAgKiBjb25zdCBnYW1lID0ge1xuICAgKiAgICAgaW5pdCh0aWNrZXIpIHtcbiAgICogICAgICAgICB0aGlzLmxvYWRSZXNvdXJjZXMoKTtcbiAgICogICAgICAgICBjb25zb2xlLmxvZygnR2FtZSBpbml0aWFsaXplZCcpO1xuICAgKiAgICAgfVxuICAgKiB9O1xuICAgKiB0aWNrZXIuYWRkT25jZShnYW1lLmluaXQsIGdhbWUpO1xuICAgKlxuICAgKiAvLyBXaXRoIHByaW9yaXR5XG4gICAqIHRpY2tlci5hZGRPbmNlKFxuICAgKiAgICAgKCkgPT4ge1xuICAgKiAgICAgICAgIC8vIEhpZ2ggcHJpb3JpdHkgb25lLXRpbWUgc2V0dXBcbiAgICogICAgICAgICBwaHlzaWNzLmluaXQoKTtcbiAgICogICAgIH0sXG4gICAqICAgICB1bmRlZmluZWQsXG4gICAqICAgICBVUERBVEVfUFJJT1JJVFkuSElHSFxuICAgKiApO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIGZuIC0gVGhlIGxpc3RlbmVyIGZ1bmN0aW9uIHRvIGJlIGFkZGVkIGZvciBvbmUgdXBkYXRlXG4gICAqIEBwYXJhbSBjb250ZXh0IC0gVGhlIGxpc3RlbmVyIGNvbnRleHRcbiAgICogQHBhcmFtIHByaW9yaXR5IC0gVGhlIHByaW9yaXR5IGZvciBlbWl0dGluZyAoZGVmYXVsdDogVVBEQVRFX1BSSU9SSVRZLk5PUk1BTClcbiAgICogQHJldHVybnMgVGhpcyBpbnN0YW5jZSBvZiBhIHRpY2tlclxuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjYWRkfSBGb3IgY29udGludW91cyB1cGRhdGVzXG4gICAqIEBzZWUge0BsaW5rIFRpY2tlciNyZW1vdmV9IEZvciByZW1vdmluZyBoYW5kbGVyc1xuICAgKi9cbiAgYWRkT25jZShmbiwgY29udGV4dCwgcHJpb3JpdHkgPSBVUERBVEVfUFJJT1JJVFkuTk9STUFMKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkZExpc3RlbmVyKG5ldyBUaWNrZXJMaXN0ZW5lcihmbiwgY29udGV4dCwgcHJpb3JpdHksIHRydWUpKTtcbiAgfVxuICAvKipcbiAgICogSW50ZXJuYWxseSBhZGRzIHRoZSBldmVudCBoYW5kbGVyIHNvIHRoYXQgaXQgY2FuIGJlIHNvcnRlZCBieSBwcmlvcml0eS5cbiAgICogUHJpb3JpdHkgYWxsb3dzIGNlcnRhaW4gaGFuZGxlciAodXNlciwgQW5pbWF0ZWRTcHJpdGUsIEludGVyYWN0aW9uKSB0byBiZSBydW5cbiAgICogYmVmb3JlIHRoZSByZW5kZXJpbmcuXG4gICAqIEBwcml2YXRlXG4gICAqIEBwYXJhbSBsaXN0ZW5lciAtIEN1cnJlbnQgbGlzdGVuZXIgYmVpbmcgYWRkZWQuXG4gICAqIEByZXR1cm5zIFRoaXMgaW5zdGFuY2Ugb2YgYSB0aWNrZXJcbiAgICovXG4gIF9hZGRMaXN0ZW5lcihsaXN0ZW5lcikge1xuICAgIGxldCBjdXJyZW50ID0gdGhpcy5faGVhZC5uZXh0O1xuICAgIGxldCBwcmV2aW91cyA9IHRoaXMuX2hlYWQ7XG4gICAgaWYgKCFjdXJyZW50KSB7XG4gICAgICBsaXN0ZW5lci5jb25uZWN0KHByZXZpb3VzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgd2hpbGUgKGN1cnJlbnQpIHtcbiAgICAgICAgaWYgKGxpc3RlbmVyLnByaW9yaXR5ID4gY3VycmVudC5wcmlvcml0eSkge1xuICAgICAgICAgIGxpc3RlbmVyLmNvbm5lY3QocHJldmlvdXMpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHByZXZpb3VzID0gY3VycmVudDtcbiAgICAgICAgY3VycmVudCA9IGN1cnJlbnQubmV4dDtcbiAgICAgIH1cbiAgICAgIGlmICghbGlzdGVuZXIucHJldmlvdXMpIHtcbiAgICAgICAgbGlzdGVuZXIuY29ubmVjdChwcmV2aW91cyk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuX3N0YXJ0SWZQb3NzaWJsZSgpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBSZW1vdmVzIGFueSBoYW5kbGVycyBtYXRjaGluZyB0aGUgZnVuY3Rpb24gYW5kIGNvbnRleHQgcGFyYW1ldGVycy5cbiAgICogSWYgbm8gaGFuZGxlcnMgYXJlIGxlZnQgYWZ0ZXIgcmVtb3ZpbmcsIHRoZW4gaXQgY2FuY2VscyB0aGUgYW5pbWF0aW9uIGZyYW1lLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyByZW1vdmFsXG4gICAqIGNvbnN0IG9uVGljayA9ICgpID0+IHtcbiAgICogICAgIHNwcml0ZS5yb3RhdGlvbiArPSAwLjE7XG4gICAqIH07XG4gICAqIHRpY2tlci5hZGQob25UaWNrKTtcbiAgICogdGlja2VyLnJlbW92ZShvblRpY2spO1xuICAgKlxuICAgKiAvLyBSZW1vdmUgd2l0aCBjb250ZXh0XG4gICAqIGNvbnN0IGdhbWUgPSB7XG4gICAqICAgICB1cGRhdGUodGlja2VyKSB7XG4gICAqICAgICAgICAgdGhpcy5waHlzaWNzLnVwZGF0ZSh0aWNrZXIuZGVsdGFUaW1lKTtcbiAgICogICAgIH1cbiAgICogfTtcbiAgICogdGlja2VyLmFkZChnYW1lLnVwZGF0ZSwgZ2FtZSk7XG4gICAqIHRpY2tlci5yZW1vdmUoZ2FtZS51cGRhdGUsIGdhbWUpO1xuICAgKlxuICAgKiAvLyBSZW1vdmUgYWxsIG1hdGNoaW5nIGhhbmRsZXJzXG4gICAqIC8vIChpZiBzYW1lIGZ1bmN0aW9uIHdhcyBhZGRlZCBtdWx0aXBsZSB0aW1lcylcbiAgICogdGlja2VyLmFkZChvblRpY2spO1xuICAgKiB0aWNrZXIuYWRkKG9uVGljayk7XG4gICAqIHRpY2tlci5yZW1vdmUob25UaWNrKTsgLy8gUmVtb3ZlcyBhbGwgaW5zdGFuY2VzXG4gICAqIGBgYFxuICAgKiBAcGFyYW0gZm4gLSBUaGUgbGlzdGVuZXIgZnVuY3Rpb24gdG8gYmUgcmVtb3ZlZFxuICAgKiBAcGFyYW0gY29udGV4dCAtIFRoZSBsaXN0ZW5lciBjb250ZXh0IHRvIGJlIHJlbW92ZWRcbiAgICogQHJldHVybnMgVGhpcyBpbnN0YW5jZSBvZiBhIHRpY2tlclxuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjYWRkfSBGb3IgYWRkaW5nIGhhbmRsZXJzXG4gICAqIEBzZWUge0BsaW5rIFRpY2tlciNhZGRPbmNlfSBGb3Igb25lLXRpbWUgaGFuZGxlcnNcbiAgICovXG4gIHJlbW92ZShmbiwgY29udGV4dCkge1xuICAgIGxldCBsaXN0ZW5lciA9IHRoaXMuX2hlYWQubmV4dDtcbiAgICB3aGlsZSAobGlzdGVuZXIpIHtcbiAgICAgIGlmIChsaXN0ZW5lci5tYXRjaChmbiwgY29udGV4dCkpIHtcbiAgICAgICAgbGlzdGVuZXIgPSBsaXN0ZW5lci5kZXN0cm95KCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsaXN0ZW5lciA9IGxpc3RlbmVyLm5leHQ7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghdGhpcy5faGVhZC5uZXh0KSB7XG4gICAgICB0aGlzLl9jYW5jZWxJZk5lZWRlZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogVGhlIG51bWJlciBvZiBsaXN0ZW5lcnMgb24gdGhpcyB0aWNrZXIsIGNhbGN1bGF0ZWQgYnkgd2Fsa2luZyB0aHJvdWdoIGxpbmtlZCBsaXN0LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBDaGVjayBudW1iZXIgb2YgYWN0aXZlIGxpc3RlbmVyc1xuICAgKiBjb25zdCB0aWNrZXIgPSBuZXcgVGlja2VyKCk7XG4gICAqIGNvbnNvbGUubG9nKHRpY2tlci5jb3VudCk7IC8vIDBcbiAgICpcbiAgICogLy8gQWRkIHNvbWUgbGlzdGVuZXJzXG4gICAqIHRpY2tlci5hZGQoKCkgPT4ge30pO1xuICAgKiB0aWNrZXIuYWRkKCgpID0+IHt9KTtcbiAgICogY29uc29sZS5sb2codGlja2VyLmNvdW50KTsgLy8gMlxuICAgKlxuICAgKiAvLyBDaGVjayBhZnRlciBjbGVhbnVwXG4gICAqIHRpY2tlci5kZXN0cm95KCk7XG4gICAqIGNvbnNvbGUubG9nKHRpY2tlci5jb3VudCk7IC8vIDBcbiAgICogYGBgXG4gICAqIEByZWFkb25seVxuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjYWRkfSBGb3IgYWRkaW5nIGxpc3RlbmVyc1xuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjcmVtb3ZlfSBGb3IgcmVtb3ZpbmcgbGlzdGVuZXJzXG4gICAqL1xuICBnZXQgY291bnQoKSB7XG4gICAgaWYgKCF0aGlzLl9oZWFkKSB7XG4gICAgICByZXR1cm4gMDtcbiAgICB9XG4gICAgbGV0IGNvdW50ID0gMDtcbiAgICBsZXQgY3VycmVudCA9IHRoaXMuX2hlYWQ7XG4gICAgd2hpbGUgKGN1cnJlbnQgPSBjdXJyZW50Lm5leHQpIHtcbiAgICAgIGNvdW50Kys7XG4gICAgfVxuICAgIHJldHVybiBjb3VudDtcbiAgfVxuICAvKipcbiAgICogU3RhcnRzIHRoZSB0aWNrZXIuIElmIHRoZSB0aWNrZXIgaGFzIGxpc3RlbmVycyBhIG5ldyBhbmltYXRpb24gZnJhbWUgaXMgcmVxdWVzdGVkIGF0IHRoaXMgcG9pbnQuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIG1hbnVhbCBzdGFydFxuICAgKiBjb25zdCB0aWNrZXIgPSBuZXcgVGlja2VyKCk7XG4gICAqIHRpY2tlci5hZGQoKCkgPT4ge1xuICAgKiAgICAgLy8gQW5pbWF0aW9uIGNvZGUgaGVyZVxuICAgKiB9KTtcbiAgICogdGlja2VyLnN0YXJ0KCk7XG4gICAqIGBgYFxuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjc3RvcH0gRm9yIHN0b3BwaW5nIHRoZSB0aWNrZXJcbiAgICogQHNlZSB7QGxpbmsgVGlja2VyI2F1dG9TdGFydH0gRm9yIGF1dG9tYXRpYyBzdGFydGluZ1xuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjc3RhcnRlZH0gRm9yIGNoZWNraW5nIHRpY2tlciBzdGF0ZVxuICAgKi9cbiAgc3RhcnQoKSB7XG4gICAgaWYgKCF0aGlzLnN0YXJ0ZWQpIHtcbiAgICAgIHRoaXMuc3RhcnRlZCA9IHRydWU7XG4gICAgICB0aGlzLl9yZXF1ZXN0SWZOZWVkZWQoKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIFN0b3BzIHRoZSB0aWNrZXIuIElmIHRoZSB0aWNrZXIgaGFzIHJlcXVlc3RlZCBhbiBhbmltYXRpb24gZnJhbWUgaXQgaXMgY2FuY2VsZWQgYXQgdGhpcyBwb2ludC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgc3RvcFxuICAgKiBjb25zdCB0aWNrZXIgPSBuZXcgVGlja2VyKCk7XG4gICAqIHRpY2tlci5zdG9wKCk7XG4gICAqIGBgYFxuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjc3RhcnR9IEZvciBzdGFydGluZyB0aGUgdGlja2VyXG4gICAqIEBzZWUge0BsaW5rIFRpY2tlciNzdGFydGVkfSBGb3IgY2hlY2tpbmcgdGlja2VyIHN0YXRlXG4gICAqIEBzZWUge0BsaW5rIFRpY2tlciNkZXN0cm95fSBGb3IgY2xlYW5pbmcgdXAgdGhlIHRpY2tlclxuICAgKi9cbiAgc3RvcCgpIHtcbiAgICBpZiAodGhpcy5zdGFydGVkKSB7XG4gICAgICB0aGlzLnN0YXJ0ZWQgPSBmYWxzZTtcbiAgICAgIHRoaXMuX2NhbmNlbElmTmVlZGVkKCk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBEZXN0cm95IHRoZSB0aWNrZXIgYW5kIGRvbid0IHVzZSBhZnRlciB0aGlzLiBDYWxsaW5nIHRoaXMgbWV0aG9kIHJlbW92ZXMgYWxsIHJlZmVyZW5jZXMgdG8gaW50ZXJuYWwgZXZlbnRzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBDbGVhbiB1cCB3aXRoIGFjdGl2ZSBsaXN0ZW5lcnNcbiAgICogY29uc3QgdGlja2VyID0gbmV3IFRpY2tlcigpO1xuICAgKiB0aWNrZXIuYWRkKCgpID0+IHt9KTtcbiAgICogdGlja2VyLmRlc3Ryb3koKTsgLy8gUmVtb3ZlcyBhbGwgbGlzdGVuZXJzXG4gICAqIGBgYFxuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjc3RvcH0gRm9yIHN0b3BwaW5nIHdpdGhvdXQgZGVzdHJveWluZ1xuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjcmVtb3ZlfSBGb3IgcmVtb3Zpbmcgc3BlY2lmaWMgbGlzdGVuZXJzXG4gICAqL1xuICBkZXN0cm95KCkge1xuICAgIGlmICghdGhpcy5fcHJvdGVjdGVkKSB7XG4gICAgICB0aGlzLnN0b3AoKTtcbiAgICAgIGxldCBsaXN0ZW5lciA9IHRoaXMuX2hlYWQubmV4dDtcbiAgICAgIHdoaWxlIChsaXN0ZW5lcikge1xuICAgICAgICBsaXN0ZW5lciA9IGxpc3RlbmVyLmRlc3Ryb3kodHJ1ZSk7XG4gICAgICB9XG4gICAgICB0aGlzLl9oZWFkLmRlc3Ryb3koKTtcbiAgICAgIHRoaXMuX2hlYWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogVHJpZ2dlcnMgYW4gdXBkYXRlLlxuICAgKlxuICAgKiBBbiB1cGRhdGUgZW50YWlscyBzZXR0aW5nIHRoZVxuICAgKiBjdXJyZW50IHtAbGluayBUaWNrZXIjZWxhcHNlZE1TfGVsYXBzZWRNU30sXG4gICAqIHRoZSBjdXJyZW50IHtAbGluayBUaWNrZXIjZGVsdGFUaW1lfGRlbHRhVGltZX0sXG4gICAqIGludm9raW5nIGFsbCBsaXN0ZW5lcnMgd2l0aCBjdXJyZW50IGRlbHRhVGltZSxcbiAgICogYW5kIHRoZW4gZmluYWxseSBzZXR0aW5nIHtAbGluayBUaWNrZXIjbGFzdFRpbWV8bGFzdFRpbWV9XG4gICAqIHdpdGggdGhlIHZhbHVlIG9mIGN1cnJlbnRUaW1lIHRoYXQgd2FzIHByb3ZpZGVkLlxuICAgKlxuICAgKiBUaGlzIG1ldGhvZCB3aWxsIGJlIGNhbGxlZCBhdXRvbWF0aWNhbGx5IGJ5IGFuaW1hdGlvblxuICAgKiBmcmFtZSBjYWxsYmFja3MgaWYgdGhlIHRpY2tlciBpbnN0YW5jZSBoYXMgYmVlbiBzdGFydGVkXG4gICAqIGFuZCBsaXN0ZW5lcnMgYXJlIGFkZGVkLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBtYW51YWwgdXBkYXRlXG4gICAqIGNvbnN0IHRpY2tlciA9IG5ldyBUaWNrZXIoKTtcbiAgICogdGlja2VyLnVwZGF0ZShwZXJmb3JtYW5jZS5ub3coKSk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gY3VycmVudFRpbWUgLSBUaGUgY3VycmVudCB0aW1lIG9mIGV4ZWN1dGlvbiAoZGVmYXVsdHMgdG8gcGVyZm9ybWFuY2Uubm93KCkpXG4gICAqIEBzZWUge0BsaW5rIFRpY2tlciNkZWx0YVRpbWV9IEZvciBmcmFtZSBkZWx0YSB2YWx1ZVxuICAgKiBAc2VlIHtAbGluayBUaWNrZXIjZWxhcHNlZE1TfSBGb3IgcmF3IGVsYXBzZWQgdGltZVxuICAgKi9cbiAgdXBkYXRlKGN1cnJlbnRUaW1lID0gcGVyZm9ybWFuY2Uubm93KCkpIHtcbiAgICBsZXQgZWxhcHNlZE1TO1xuICAgIGlmIChjdXJyZW50VGltZSA+IHRoaXMubGFzdFRpbWUpIHtcbiAgICAgIGVsYXBzZWRNUyA9IHRoaXMuZWxhcHNlZE1TID0gY3VycmVudFRpbWUgLSB0aGlzLmxhc3RUaW1lO1xuICAgICAgaWYgKGVsYXBzZWRNUyA+IHRoaXMuX21heEVsYXBzZWRNUykge1xuICAgICAgICBlbGFwc2VkTVMgPSB0aGlzLl9tYXhFbGFwc2VkTVM7XG4gICAgICB9XG4gICAgICBlbGFwc2VkTVMgKj0gdGhpcy5zcGVlZDtcbiAgICAgIGlmICh0aGlzLl9taW5FbGFwc2VkTVMpIHtcbiAgICAgICAgY29uc3QgZGVsdGEgPSBjdXJyZW50VGltZSAtIHRoaXMuX2xhc3RGcmFtZSB8IDA7XG4gICAgICAgIGlmIChkZWx0YSA8IHRoaXMuX21pbkVsYXBzZWRNUykge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9sYXN0RnJhbWUgPSBjdXJyZW50VGltZSAtIGRlbHRhICUgdGhpcy5fbWluRWxhcHNlZE1TO1xuICAgICAgfVxuICAgICAgdGhpcy5kZWx0YU1TID0gZWxhcHNlZE1TO1xuICAgICAgdGhpcy5kZWx0YVRpbWUgPSB0aGlzLmRlbHRhTVMgKiBfVGlja2VyLnRhcmdldEZQTVM7XG4gICAgICBjb25zdCBoZWFkID0gdGhpcy5faGVhZDtcbiAgICAgIGxldCBsaXN0ZW5lciA9IGhlYWQubmV4dDtcbiAgICAgIHdoaWxlIChsaXN0ZW5lcikge1xuICAgICAgICBsaXN0ZW5lciA9IGxpc3RlbmVyLmVtaXQodGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoIWhlYWQubmV4dCkge1xuICAgICAgICB0aGlzLl9jYW5jZWxJZk5lZWRlZCgpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmRlbHRhVGltZSA9IHRoaXMuZGVsdGFNUyA9IHRoaXMuZWxhcHNlZE1TID0gMDtcbiAgICB9XG4gICAgdGhpcy5sYXN0VGltZSA9IGN1cnJlbnRUaW1lO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgZnJhbWVzIHBlciBzZWNvbmQgYXQgd2hpY2ggdGhpcyB0aWNrZXIgaXMgcnVubmluZy5cbiAgICogVGhlIGRlZmF1bHQgaXMgYXBwcm94aW1hdGVseSA2MCBpbiBtb3N0IG1vZGVybiBicm93c2Vycy5cbiAgICogPiBbIU5PVEVdIFRoaXMgZG9lcyBub3QgZmFjdG9yIGluIHRoZSB2YWx1ZSBvZlxuICAgKiA+IHtAbGluayBUaWNrZXIjc3BlZWR8c3BlZWR9LCB3aGljaCBpcyBzcGVjaWZpY1xuICAgKiA+IHRvIHNjYWxpbmcge0BsaW5rIFRpY2tlciNkZWx0YVRpbWV8ZGVsdGFUaW1lfS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgRlBTIG1vbml0b3JpbmdcbiAgICogdGlja2VyLmFkZCgoKSA9PiB7XG4gICAqICAgICBjb25zb2xlLmxvZyhgQ3VycmVudCBGUFM6ICR7TWF0aC5yb3VuZCh0aWNrZXIuRlBTKX1gKTtcbiAgICogfSk7XG4gICAqIGBgYFxuICAgKiBAcmVhZG9ubHlcbiAgICovXG4gIGdldCBGUFMoKSB7XG4gICAgcmV0dXJuIDFlMyAvIHRoaXMuZWxhcHNlZE1TO1xuICB9XG4gIC8qKlxuICAgKiBNYW5hZ2VzIHRoZSBtYXhpbXVtIGFtb3VudCBvZiBtaWxsaXNlY29uZHMgYWxsb3dlZCB0b1xuICAgKiBlbGFwc2UgYmV0d2VlbiBpbnZva2luZyB7QGxpbmsgVGlja2VyI3VwZGF0ZXx1cGRhdGV9LlxuICAgKlxuICAgKiBUaGlzIHZhbHVlIGlzIHVzZWQgdG8gY2FwIHtAbGluayBUaWNrZXIjZGVsdGFUaW1lfGRlbHRhVGltZX0sXG4gICAqIGJ1dCBkb2VzIG5vdCBlZmZlY3QgdGhlIG1lYXN1cmVkIHZhbHVlIG9mIHtAbGluayBUaWNrZXIjRlBTfEZQU30uXG4gICAqXG4gICAqIFdoZW4gc2V0dGluZyB0aGlzIHByb3BlcnR5IGl0IGlzIGNsYW1wZWQgdG8gYSB2YWx1ZSBiZXR3ZWVuXG4gICAqIGAwYCBhbmQgYFRpY2tlci50YXJnZXRGUE1TICogMTAwMGAgKHR5cGljYWxseSA2MCkuXG4gICAqXG4gICAqIElmIGBtYXhGUFNgIGlzIGN1cnJlbnRseSBzZXQgKG5vbi16ZXJvKSBhbmQgYG1pbkZQU2AgaXMgc2V0IGFib3ZlIGl0LFxuICAgKiBgbWF4RlBTYCBpcyBhdXRvbWF0aWNhbGx5IHJhaXNlZCB0byBtYXRjaC4gVGhpcyBrZWVwcyB0aGUgdHdvIGxpbWl0cyBjb25zaXN0ZW50LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBTZXQgbWluaW11bSBhY2NlcHRhYmxlIGZyYW1lIHJhdGVcbiAgICogY29uc3QgdGlja2VyID0gbmV3IFRpY2tlcigpO1xuICAgKiB0aWNrZXIubWluRlBTID0gMzA7IC8vIE5ldmVyIGdvIGJlbG93IDMwIEZQU1xuICAgKlxuICAgKiAvLyBVc2Ugd2l0aCBtYXhGUFMgZm9yIGZyYW1lIHJhdGUgY2xhbXBpbmdcbiAgICogdGlja2VyLm1pbkZQUyA9IDMwO1xuICAgKiB0aWNrZXIubWF4RlBTID0gNjA7XG4gICAqXG4gICAqIC8vIG1pbkZQUyBhYm92ZSBtYXhGUFMgcHVzaGVzIG1heEZQUyB1cFxuICAgKiB0aWNrZXIubWluRlBTID0gNTA7IC8vIG1heEZQUyBpcyByYWlzZWQgdG8gNTBcbiAgICogYGBgXG4gICAqIEBkZWZhdWx0IDEwXG4gICAqL1xuICBnZXQgbWluRlBTKCkge1xuICAgIHJldHVybiAxZTMgLyB0aGlzLl9tYXhFbGFwc2VkTVM7XG4gIH1cbiAgc2V0IG1pbkZQUyhmcHMpIHtcbiAgICBjb25zdCBtaW5GUE1TID0gTWF0aC5taW4oTWF0aC5tYXgoMCwgZnBzKSAvIDFlMywgX1RpY2tlci50YXJnZXRGUE1TKTtcbiAgICB0aGlzLl9tYXhFbGFwc2VkTVMgPSAxIC8gbWluRlBNUztcbiAgICBpZiAodGhpcy5fbWluRWxhcHNlZE1TICYmIGZwcyA+IHRoaXMubWF4RlBTKSB7XG4gICAgICB0aGlzLm1heEZQUyA9IGZwcztcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIE1hbmFnZXMgdGhlIG1pbmltdW0gYW1vdW50IG9mIG1pbGxpc2Vjb25kcyByZXF1aXJlZCB0b1xuICAgKiBlbGFwc2UgYmV0d2VlbiBpbnZva2luZyB7QGxpbmsgVGlja2VyI3VwZGF0ZXx1cGRhdGV9LlxuICAgKlxuICAgKiBUaGlzIHdpbGwgZWZmZWN0IHRoZSBtZWFzdXJlZCB2YWx1ZSBvZiB7QGxpbmsgVGlja2VyI0ZQU3xGUFN9LlxuICAgKlxuICAgKiBJZiBpdCBpcyBzZXQgdG8gYDBgLCB0aGVuIHRoZXJlIGlzIG5vIGxpbWl0OyBQaXhpSlMgd2lsbCByZW5kZXIgYXMgbWFueSBmcmFtZXMgYXMgaXQgY2FuLlxuICAgKiBPdGhlcndpc2UgaXQgd2lsbCBiZSBhdCBsZWFzdCBgbWluRlBTYC5cbiAgICpcbiAgICogSWYgYG1heEZQU2AgaXMgc2V0IGJlbG93IHRoZSBjdXJyZW50IGBtaW5GUFNgLCBgbWluRlBTYCBpcyBhdXRvbWF0aWNhbGx5IGxvd2VyZWQgdG8gbWF0Y2guXG4gICAqIFRoaXMga2VlcHMgdGhlIHR3byBsaW1pdHMgY29uc2lzdGVudC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQ2FwIHRoZSBmcmFtZSByYXRlXG4gICAqIGNvbnN0IHRpY2tlciA9IG5ldyBUaWNrZXIoKTtcbiAgICogdGlja2VyLm1heEZQUyA9IDYwOyAvLyBOZXZlciBnbyBhYm92ZSA2MCBGUFNcbiAgICpcbiAgICogLy8gVXNlIHdpdGggbWluRlBTIGZvciBmcmFtZSByYXRlIGNsYW1waW5nXG4gICAqIHRpY2tlci5taW5GUFMgPSAzMDtcbiAgICogdGlja2VyLm1heEZQUyA9IDYwO1xuICAgKlxuICAgKiAvLyBtYXhGUFMgYmVsb3cgbWluRlBTIHB1c2hlcyBtaW5GUFMgZG93blxuICAgKiB0aWNrZXIubWF4RlBTID0gMjA7IC8vIG1pbkZQUyBpcyBub3cgYWxzbyAyMFxuICAgKiBgYGBcbiAgICogQGRlZmF1bHQgMFxuICAgKi9cbiAgZ2V0IG1heEZQUygpIHtcbiAgICBpZiAodGhpcy5fbWluRWxhcHNlZE1TKSB7XG4gICAgICByZXR1cm4gTWF0aC5yb3VuZCgxZTMgLyB0aGlzLl9taW5FbGFwc2VkTVMpO1xuICAgIH1cbiAgICByZXR1cm4gMDtcbiAgfVxuICBzZXQgbWF4RlBTKGZwcykge1xuICAgIGlmIChmcHMgPT09IDApIHtcbiAgICAgIHRoaXMuX21pbkVsYXBzZWRNUyA9IDA7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChmcHMgPCB0aGlzLm1pbkZQUykge1xuICAgICAgICB0aGlzLm1pbkZQUyA9IGZwcztcbiAgICAgIH1cbiAgICAgIHRoaXMuX21pbkVsYXBzZWRNUyA9IDEgLyAoZnBzIC8gMWUzKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBzaGFyZWQgdGlja2VyIGluc3RhbmNlIHVzZWQgYnkge0BsaW5rIEFuaW1hdGVkU3ByaXRlfSBhbmQgYnlcbiAgICoge0BsaW5rIFZpZGVvU291cmNlfSB0byB1cGRhdGUgYW5pbWF0aW9uIGZyYW1lcyAvIHZpZGVvIHRleHR1cmVzLlxuICAgKlxuICAgKiBJdCBtYXkgYWxzbyBiZSB1c2VkIGJ5IHtAbGluayBBcHBsaWNhdGlvbn0gaWYgY3JlYXRlZCB3aXRoIHRoZSBgc2hhcmVkVGlja2VyYCBvcHRpb24gcHJvcGVydHkgc2V0IHRvIHRydWUuXG4gICAqXG4gICAqIFRoZSBwcm9wZXJ0eSB7QGxpbmsgVGlja2VyI2F1dG9TdGFydHxhdXRvU3RhcnR9IGlzIHNldCB0byBgdHJ1ZWAgZm9yIHRoaXMgaW5zdGFuY2UuXG4gICAqIFBsZWFzZSBmb2xsb3cgdGhlIGV4YW1wbGVzIGZvciB1c2FnZSwgaW5jbHVkaW5nIGhvdyB0byBvcHQtb3V0IG9mIGF1dG8tc3RhcnRpbmcgdGhlIHNoYXJlZCB0aWNrZXIuXG4gICAqIEBleGFtcGxlXG4gICAqIGltcG9ydCB7IFRpY2tlciB9IGZyb20gJ3BpeGkuanMnO1xuICAgKlxuICAgKiBjb25zdCB0aWNrZXIgPSBUaWNrZXIuc2hhcmVkO1xuICAgKiAvLyBTZXQgdGhpcyB0byBwcmV2ZW50IHN0YXJ0aW5nIHRoaXMgdGlja2VyIHdoZW4gbGlzdGVuZXJzIGFyZSBhZGRlZC5cbiAgICogLy8gQnkgZGVmYXVsdCB0aGlzIGlzIHRydWUgb25seSBmb3IgdGhlIFRpY2tlci5zaGFyZWQgaW5zdGFuY2UuXG4gICAqIHRpY2tlci5hdXRvU3RhcnQgPSBmYWxzZTtcbiAgICpcbiAgICogLy8gRllJLCBjYWxsIHRoaXMgdG8gZW5zdXJlIHRoZSB0aWNrZXIgaXMgc3RvcHBlZC4gSXQgc2hvdWxkIGJlIHN0b3BwZWRcbiAgICogLy8gaWYgeW91IGhhdmUgbm90IGF0dGVtcHRlZCB0byByZW5kZXIgYW55dGhpbmcgeWV0LlxuICAgKiB0aWNrZXIuc3RvcCgpO1xuICAgKlxuICAgKiAvLyBDYWxsIHRoaXMgd2hlbiB5b3UgYXJlIHJlYWR5IGZvciBhIHJ1bm5pbmcgc2hhcmVkIHRpY2tlci5cbiAgICogdGlja2VyLnN0YXJ0KCk7XG4gICAqIEBleGFtcGxlXG4gICAqIGltcG9ydCB7IGF1dG9EZXRlY3RSZW5kZXJlciwgQ29udGFpbmVyIH0gZnJvbSAncGl4aS5qcyc7XG4gICAqXG4gICAqIC8vIFlvdSBtYXkgdXNlIHRoZSBzaGFyZWQgdGlja2VyIHRvIHJlbmRlci4uLlxuICAgKiBjb25zdCByZW5kZXJlciA9IGF1dG9EZXRlY3RSZW5kZXJlcigpO1xuICAgKiBjb25zdCBzdGFnZSA9IG5ldyBDb250YWluZXIoKTtcbiAgICogZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChyZW5kZXJlci52aWV3KTtcbiAgICogdGlja2VyLmFkZCgodGltZSkgPT4gcmVuZGVyZXIucmVuZGVyKHN0YWdlKSk7XG4gICAqXG4gICAqIC8vIE9yIHlvdSBjYW4ganVzdCB1cGRhdGUgaXQgbWFudWFsbHkuXG4gICAqIHRpY2tlci5hdXRvU3RhcnQgPSBmYWxzZTtcbiAgICogdGlja2VyLnN0b3AoKTtcbiAgICogY29uc3QgYW5pbWF0ZSA9ICh0aW1lKSA9PiB7XG4gICAqICAgICB0aWNrZXIudXBkYXRlKHRpbWUpO1xuICAgKiAgICAgcmVuZGVyZXIucmVuZGVyKHN0YWdlKTtcbiAgICogICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZShhbmltYXRlKTtcbiAgICogfTtcbiAgICogYW5pbWF0ZShwZXJmb3JtYW5jZS5ub3coKSk7XG4gICAqIEB0eXBlIHtUaWNrZXJ9XG4gICAqIEByZWFkb25seVxuICAgKi9cbiAgc3RhdGljIGdldCBzaGFyZWQoKSB7XG4gICAgaWYgKCFfVGlja2VyLl9zaGFyZWQpIHtcbiAgICAgIGNvbnN0IHNoYXJlZCA9IF9UaWNrZXIuX3NoYXJlZCA9IG5ldyBfVGlja2VyKCk7XG4gICAgICBzaGFyZWQuYXV0b1N0YXJ0ID0gdHJ1ZTtcbiAgICAgIHNoYXJlZC5fcHJvdGVjdGVkID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIF9UaWNrZXIuX3NoYXJlZDtcbiAgfVxuICAvKipcbiAgICogVGhlIHN5c3RlbSB0aWNrZXIgaW5zdGFuY2UgdXNlZCBieSB7QGxpbmsgUHJlcGFyZUJhc2V9IGZvciBjb3JlIHRpbWluZ1xuICAgKiBmdW5jdGlvbmFsaXR5IHRoYXQgc2hvdWxkbid0IHVzdWFsbHkgbmVlZCB0byBiZSBwYXVzZWQsIHVubGlrZSB0aGUgYHNoYXJlZGBcbiAgICogdGlja2VyIHdoaWNoIGRyaXZlcyB2aXN1YWwgYW5pbWF0aW9ucyBhbmQgcmVuZGVyaW5nIHdoaWNoIG1heSB3YW50IHRvIGJlIHBhdXNlZC5cbiAgICpcbiAgICogVGhlIHByb3BlcnR5IHtAbGluayBUaWNrZXIjYXV0b1N0YXJ0fGF1dG9TdGFydH0gaXMgc2V0IHRvIGB0cnVlYCBmb3IgdGhpcyBpbnN0YW5jZS5cbiAgICogQHR5cGUge1RpY2tlcn1cbiAgICogQHJlYWRvbmx5XG4gICAqIEBhZHZhbmNlZFxuICAgKi9cbiAgc3RhdGljIGdldCBzeXN0ZW0oKSB7XG4gICAgaWYgKCFfVGlja2VyLl9zeXN0ZW0pIHtcbiAgICAgIGNvbnN0IHN5c3RlbSA9IF9UaWNrZXIuX3N5c3RlbSA9IG5ldyBfVGlja2VyKCk7XG4gICAgICBzeXN0ZW0uYXV0b1N0YXJ0ID0gdHJ1ZTtcbiAgICAgIHN5c3RlbS5fcHJvdGVjdGVkID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIF9UaWNrZXIuX3N5c3RlbTtcbiAgfVxufTtcbi8qKlxuICogVGFyZ2V0IGZyYW1lIHJhdGUgaW4gZnJhbWVzIHBlciBtaWxsaXNlY29uZC5cbiAqIFVzZWQgZm9yIGNvbnZlcnRpbmcgZGVsdGFUaW1lIHRvIGEgc2NhbGFyIHRpbWUgZGVsdGEuXG4gKiBAZXhhbXBsZVxuICogYGBgdHNcbiAqIC8vIERlZmF1bHQgaXMgMC4wNiAoNjAgRlBTKVxuICogY29uc29sZS5sb2coVGlja2VyLnRhcmdldEZQTVMpOyAvLyAwLjA2XG4gKlxuICogLy8gQ2FsY3VsYXRlIHRhcmdldCBmcmFtZSBkdXJhdGlvblxuICogY29uc3QgZnJhbWVEdXJhdGlvbiA9IDEgLyBUaWNrZXIudGFyZ2V0RlBNUzsgLy8g4omIIDE2LjY3bXNcbiAqXG4gKiAvLyBVc2UgaW4gY3VzdG9tIHRpbWluZyBjYWxjdWxhdGlvbnNcbiAqIGNvbnN0IGRlbHRhVGltZSA9IGVsYXBzZWRNUyAqIFRpY2tlci50YXJnZXRGUE1TO1xuICogYGBgXG4gKiBAcmVtYXJrc1xuICogLSBEZWZhdWx0IGlzIDAuMDYgKGVxdWl2YWxlbnQgdG8gNjAgRlBTKVxuICogLSBVc2VkIGluIGRlbHRhVGltZSBjYWxjdWxhdGlvbnNcbiAqIC0gQWZmZWN0cyBhbGwgdGlja2VyIGluc3RhbmNlc1xuICogQGRlZmF1bHQgMC4wNlxuICogQHNlZSB7QGxpbmsgVGlja2VyI2RlbHRhVGltZX0gRm9yIHRpbWUgc2NhbGluZ1xuICogQHNlZSB7QGxpbmsgVGlja2VyI0ZQU30gRm9yIGFjdHVhbCBmcmFtZSByYXRlXG4gKi9cbl9UaWNrZXIudGFyZ2V0RlBNUyA9IDAuMDY7XG5sZXQgVGlja2VyID0gX1RpY2tlcjtcblxuZXhwb3J0IHsgVGlja2VyIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1UaWNrZXIubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBibGVuZE1vZGVJZHMgPSB7XG4gIG5vcm1hbDogMCxcbiAgYWRkOiAxLFxuICBtdWx0aXBseTogMixcbiAgc2NyZWVuOiAzLFxuICBvdmVybGF5OiA0LFxuICBlcmFzZTogNSxcbiAgXCJub3JtYWwtbnBtXCI6IDYsXG4gIFwiYWRkLW5wbVwiOiA3LFxuICBcInNjcmVlbi1ucG1cIjogOCxcbiAgbWluOiA5LFxuICBtYXg6IDEwXG59O1xuY29uc3QgU1RBVEVfQklUUyA9IHtcbiAgQkxFTkQ6IDAsXG4gIE9GRlNFVDogMSxcbiAgQ1VMTElORzogMixcbiAgREVQVEhfVEVTVDogMyxcbiAgV0lORElORzogNCxcbiAgREVQVEhfTUFTSzogNVxufTtcbmNvbnN0IHsgQkxFTkQsIE9GRlNFVCwgQ1VMTElORywgREVQVEhfVEVTVCwgV0lORElORywgREVQVEhfTUFTSyB9ID0gU1RBVEVfQklUUztcbmNvbnN0IF9TdGF0ZSA9IGNsYXNzIF9TdGF0ZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuZGF0YSA9IDA7XG4gICAgdGhpcy5ibGVuZE1vZGUgPSBcIm5vcm1hbFwiO1xuICAgIHRoaXMucG9seWdvbk9mZnNldCA9IDA7XG4gICAgdGhpcy5ibGVuZCA9IHRydWU7XG4gICAgdGhpcy5kZXB0aE1hc2sgPSB0cnVlO1xuICB9XG4gIC8qKlxuICAgKiBBY3RpdmF0ZXMgYmxlbmRpbmcgb2YgdGhlIGNvbXB1dGVkIGZyYWdtZW50IGNvbG9yIHZhbHVlcy5cbiAgICogQGRlZmF1bHQgdHJ1ZVxuICAgKi9cbiAgZ2V0IGJsZW5kKCkge1xuICAgIHJldHVybiAhISh0aGlzLmRhdGEgJiAxIDw8IEJMRU5EKTtcbiAgfVxuICBzZXQgYmxlbmQodmFsdWUpIHtcbiAgICBpZiAoISEodGhpcy5kYXRhICYgMSA8PCBCTEVORCkgIT09IHZhbHVlKSB7XG4gICAgICB0aGlzLmRhdGEgXj0gMSA8PCBCTEVORDtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIEFjdGl2YXRlcyBhZGRpbmcgYW4gb2Zmc2V0IHRvIGRlcHRoIHZhbHVlcyBvZiBwb2x5Z29uJ3MgZnJhZ21lbnRzXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBnZXQgb2Zmc2V0cygpIHtcbiAgICByZXR1cm4gISEodGhpcy5kYXRhICYgMSA8PCBPRkZTRVQpO1xuICB9XG4gIHNldCBvZmZzZXRzKHZhbHVlKSB7XG4gICAgaWYgKCEhKHRoaXMuZGF0YSAmIDEgPDwgT0ZGU0VUKSAhPT0gdmFsdWUpIHtcbiAgICAgIHRoaXMuZGF0YSBePSAxIDw8IE9GRlNFVDtcbiAgICB9XG4gIH1cbiAgLyoqIFRoZSBjdWxsaW5nIHNldHRpbmdzIGZvciB0aGlzIHN0YXRlIG5vbmUgLSBObyBjdWxsaW5nIGJhY2sgLSBCYWNrIGZhY2UgY3VsbGluZyBmcm9udCAtIEZyb250IGZhY2UgY3VsbGluZyAqL1xuICBzZXQgY3VsbE1vZGUodmFsdWUpIHtcbiAgICBpZiAodmFsdWUgPT09IFwibm9uZVwiKSB7XG4gICAgICB0aGlzLmN1bGxpbmcgPSBmYWxzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5jdWxsaW5nID0gdHJ1ZTtcbiAgICB0aGlzLmNsb2Nrd2lzZUZyb250RmFjZSA9IHZhbHVlID09PSBcImZyb250XCI7XG4gIH1cbiAgZ2V0IGN1bGxNb2RlKCkge1xuICAgIGlmICghdGhpcy5jdWxsaW5nKSB7XG4gICAgICByZXR1cm4gXCJub25lXCI7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmNsb2Nrd2lzZUZyb250RmFjZSA/IFwiZnJvbnRcIiA6IFwiYmFja1wiO1xuICB9XG4gIC8qKlxuICAgKiBBY3RpdmF0ZXMgY3VsbGluZyBvZiBwb2x5Z29ucy5cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGdldCBjdWxsaW5nKCkge1xuICAgIHJldHVybiAhISh0aGlzLmRhdGEgJiAxIDw8IENVTExJTkcpO1xuICB9XG4gIHNldCBjdWxsaW5nKHZhbHVlKSB7XG4gICAgaWYgKCEhKHRoaXMuZGF0YSAmIDEgPDwgQ1VMTElORykgIT09IHZhbHVlKSB7XG4gICAgICB0aGlzLmRhdGEgXj0gMSA8PCBDVUxMSU5HO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogQWN0aXZhdGVzIGRlcHRoIGNvbXBhcmlzb25zIGFuZCB1cGRhdGVzIHRvIHRoZSBkZXB0aCBidWZmZXIuXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBnZXQgZGVwdGhUZXN0KCkge1xuICAgIHJldHVybiAhISh0aGlzLmRhdGEgJiAxIDw8IERFUFRIX1RFU1QpO1xuICB9XG4gIHNldCBkZXB0aFRlc3QodmFsdWUpIHtcbiAgICBpZiAoISEodGhpcy5kYXRhICYgMSA8PCBERVBUSF9URVNUKSAhPT0gdmFsdWUpIHtcbiAgICAgIHRoaXMuZGF0YSBePSAxIDw8IERFUFRIX1RFU1Q7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBFbmFibGVzIG9yIGRpc2FibGVzIHdyaXRpbmcgdG8gdGhlIGRlcHRoIGJ1ZmZlci5cbiAgICogQGRlZmF1bHQgdHJ1ZVxuICAgKi9cbiAgZ2V0IGRlcHRoTWFzaygpIHtcbiAgICByZXR1cm4gISEodGhpcy5kYXRhICYgMSA8PCBERVBUSF9NQVNLKTtcbiAgfVxuICBzZXQgZGVwdGhNYXNrKHZhbHVlKSB7XG4gICAgaWYgKCEhKHRoaXMuZGF0YSAmIDEgPDwgREVQVEhfTUFTSykgIT09IHZhbHVlKSB7XG4gICAgICB0aGlzLmRhdGEgXj0gMSA8PCBERVBUSF9NQVNLO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogU3BlY2lmaWVzIHdoZXRoZXIgb3Igbm90IGZyb250IG9yIGJhY2stZmFjaW5nIHBvbHlnb25zIGNhbiBiZSBjdWxsZWQuXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBnZXQgY2xvY2t3aXNlRnJvbnRGYWNlKCkge1xuICAgIHJldHVybiAhISh0aGlzLmRhdGEgJiAxIDw8IFdJTkRJTkcpO1xuICB9XG4gIHNldCBjbG9ja3dpc2VGcm9udEZhY2UodmFsdWUpIHtcbiAgICBpZiAoISEodGhpcy5kYXRhICYgMSA8PCBXSU5ESU5HKSAhPT0gdmFsdWUpIHtcbiAgICAgIHRoaXMuZGF0YSBePSAxIDw8IFdJTkRJTkc7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBUaGUgYmxlbmQgbW9kZSB0byBiZSBhcHBsaWVkIHdoZW4gdGhpcyBzdGF0ZSBpcyBzZXQuIEFwcGx5IGEgdmFsdWUgb2YgYG5vcm1hbGAgdG8gcmVzZXQgdGhlIGJsZW5kIG1vZGUuXG4gICAqIFNldHRpbmcgdGhpcyBtb2RlIHRvIGFueXRoaW5nIG90aGVyIHRoYW4gTk9fQkxFTkQgd2lsbCBhdXRvbWF0aWNhbGx5IHN3aXRjaCBibGVuZGluZyBvbi5cbiAgICogQGRlZmF1bHQgJ25vcm1hbCdcbiAgICovXG4gIGdldCBibGVuZE1vZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2JsZW5kTW9kZTtcbiAgfVxuICBzZXQgYmxlbmRNb2RlKHZhbHVlKSB7XG4gICAgdGhpcy5ibGVuZCA9IHZhbHVlICE9PSBcIm5vbmVcIjtcbiAgICB0aGlzLl9ibGVuZE1vZGUgPSB2YWx1ZTtcbiAgICB0aGlzLl9ibGVuZE1vZGVJZCA9IGJsZW5kTW9kZUlkc1t2YWx1ZV0gfHwgMDtcbiAgfVxuICAvKipcbiAgICogVGhlIHBvbHlnb24gb2Zmc2V0LiBTZXR0aW5nIHRoaXMgcHJvcGVydHkgdG8gYW55dGhpbmcgb3RoZXIgdGhhbiAwIHdpbGwgYXV0b21hdGljYWxseSBlbmFibGUgcG9seWdvbiBvZmZzZXQgZmlsbC5cbiAgICogQGRlZmF1bHQgMFxuICAgKi9cbiAgZ2V0IHBvbHlnb25PZmZzZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BvbHlnb25PZmZzZXQ7XG4gIH1cbiAgc2V0IHBvbHlnb25PZmZzZXQodmFsdWUpIHtcbiAgICB0aGlzLm9mZnNldHMgPSAhIXZhbHVlO1xuICAgIHRoaXMuX3BvbHlnb25PZmZzZXQgPSB2YWx1ZTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYFtwaXhpLmpzL2NvcmU6U3RhdGUgYmxlbmRNb2RlPSR7dGhpcy5ibGVuZE1vZGV9IGNsb2Nrd2lzZUZyb250RmFjZT0ke3RoaXMuY2xvY2t3aXNlRnJvbnRGYWNlfSBjdWxsaW5nPSR7dGhpcy5jdWxsaW5nfSBkZXB0aE1hc2s9JHt0aGlzLmRlcHRoTWFza30gcG9seWdvbk9mZnNldD0ke3RoaXMucG9seWdvbk9mZnNldH1dYDtcbiAgfVxuICAvKipcbiAgICogQSBxdWlja2x5IGdldHRpbmcgYW4gaW5zdGFuY2Ugb2YgYSBTdGF0ZSB0aGF0IGlzIGNvbmZpZ3VyZWQgZm9yIDJkIHJlbmRlcmluZy5cbiAgICogQHJldHVybnMgYSBuZXcgU3RhdGUgd2l0aCB2YWx1ZXMgc2V0IGZvciAyZCByZW5kZXJpbmdcbiAgICovXG4gIHN0YXRpYyBmb3IyZCgpIHtcbiAgICBjb25zdCBzdGF0ZSA9IG5ldyBfU3RhdGUoKTtcbiAgICBzdGF0ZS5kZXB0aFRlc3QgPSBmYWxzZTtcbiAgICBzdGF0ZS5kZXB0aE1hc2sgPSBmYWxzZTtcbiAgICBzdGF0ZS5ibGVuZCA9IHRydWU7XG4gICAgcmV0dXJuIHN0YXRlO1xuICB9XG59O1xuX1N0YXRlLmRlZmF1bHQyZCA9IF9TdGF0ZS5mb3IyZCgpO1xubGV0IFN0YXRlID0gX1N0YXRlO1xuXG5leHBvcnQgeyBTVEFURV9CSVRTLCBTdGF0ZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9U3RhdGUubWpzLm1hcFxuIiwiaW1wb3J0IHsgR2xQcm9ncmFtIH0gZnJvbSAnLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9nbC9zaGFkZXIvR2xQcm9ncmFtLm1qcyc7XG5pbXBvcnQgeyBHcHVQcm9ncmFtIH0gZnJvbSAnLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9ncHUvc2hhZGVyL0dwdVByb2dyYW0ubWpzJztcbmltcG9ydCB7IFNoYWRlciB9IGZyb20gJy4uL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3NoYWRlci9TaGFkZXIubWpzJztcbmltcG9ydCB7IFN0YXRlIH0gZnJvbSAnLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvc3RhdGUvU3RhdGUubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBfRmlsdGVyID0gY2xhc3MgX0ZpbHRlciBleHRlbmRzIFNoYWRlciB7XG4gIC8qKlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvcHRpb25hbCBwYXJhbWV0ZXJzIG9mIHRoaXMgZmlsdGVyLlxuICAgKi9cbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSB7IC4uLl9GaWx0ZXIuZGVmYXVsdE9wdGlvbnMsIC4uLm9wdGlvbnMgfTtcbiAgICBzdXBlcihvcHRpb25zKTtcbiAgICAvKiogSWYgZW5hYmxlZCBpcyB0cnVlIHRoZSBmaWx0ZXIgaXMgYXBwbGllZCwgaWYgZmFsc2UgaXQgd2lsbCBub3QuICovXG4gICAgdGhpcy5lbmFibGVkID0gdHJ1ZTtcbiAgICAvKipcbiAgICAgKiBUaGUgZ3B1IHN0YXRlIHRoZSBmaWx0ZXIgcmVxdWlyZXMgdG8gcmVuZGVyLlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX3N0YXRlID0gU3RhdGUuZm9yMmQoKTtcbiAgICB0aGlzLmJsZW5kTW9kZSA9IG9wdGlvbnMuYmxlbmRNb2RlO1xuICAgIHRoaXMucGFkZGluZyA9IG9wdGlvbnMucGFkZGluZztcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMuYW50aWFsaWFzID09PSBcImJvb2xlYW5cIikge1xuICAgICAgdGhpcy5hbnRpYWxpYXMgPSBvcHRpb25zLmFudGlhbGlhcyA/IFwib25cIiA6IFwib2ZmXCI7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuYW50aWFsaWFzID0gb3B0aW9ucy5hbnRpYWxpYXM7XG4gICAgfVxuICAgIHRoaXMucmVzb2x1dGlvbiA9IG9wdGlvbnMucmVzb2x1dGlvbjtcbiAgICB0aGlzLmJsZW5kUmVxdWlyZWQgPSBvcHRpb25zLmJsZW5kUmVxdWlyZWQ7XG4gICAgdGhpcy5jbGlwVG9WaWV3cG9ydCA9IG9wdGlvbnMuY2xpcFRvVmlld3BvcnQ7XG4gICAgdGhpcy5hZGRSZXNvdXJjZShcInVUZXh0dXJlXCIsIDAsIDEpO1xuICAgIGlmIChvcHRpb25zLmJsZW5kUmVxdWlyZWQpIHtcbiAgICAgIHRoaXMuYWRkUmVzb3VyY2UoXCJ1QmFja1RleHR1cmVcIiwgMCwgMyk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBBcHBsaWVzIHRoZSBmaWx0ZXJcbiAgICogQHBhcmFtIGZpbHRlck1hbmFnZXIgLSBUaGUgcmVuZGVyZXIgdG8gcmV0cmlldmUgdGhlIGZpbHRlciBmcm9tXG4gICAqIEBwYXJhbSBpbnB1dCAtIFRoZSBpbnB1dCByZW5kZXIgdGFyZ2V0LlxuICAgKiBAcGFyYW0gb3V0cHV0IC0gVGhlIHRhcmdldCB0byBvdXRwdXQgdG8uXG4gICAqIEBwYXJhbSBjbGVhck1vZGUgLSBTaG91bGQgdGhlIG91dHB1dCBiZSBjbGVhcmVkIGJlZm9yZSByZW5kZXJpbmcgdG8gaXRcbiAgICovXG4gIGFwcGx5KGZpbHRlck1hbmFnZXIsIGlucHV0LCBvdXRwdXQsIGNsZWFyTW9kZSkge1xuICAgIGZpbHRlck1hbmFnZXIuYXBwbHlGaWx0ZXIodGhpcywgaW5wdXQsIG91dHB1dCwgY2xlYXJNb2RlKTtcbiAgfVxuICAvKipcbiAgICogR2V0IHRoZSBibGVuZCBtb2RlIG9mIHRoZSBmaWx0ZXIuXG4gICAqIEBkZWZhdWx0IFwibm9ybWFsXCJcbiAgICovXG4gIGdldCBibGVuZE1vZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3N0YXRlLmJsZW5kTW9kZTtcbiAgfVxuICAvKiogU2V0cyB0aGUgYmxlbmQgbW9kZSBvZiB0aGUgZmlsdGVyLiAqL1xuICBzZXQgYmxlbmRNb2RlKHZhbHVlKSB7XG4gICAgdGhpcy5fc3RhdGUuYmxlbmRNb2RlID0gdmFsdWU7XG4gIH1cbiAgLyoqXG4gICAqIEEgc2hvcnQgaGFuZCBmdW5jdGlvbiB0byBjcmVhdGUgYSBmaWx0ZXIgYmFzZWQgb2YgYSB2ZXJ0ZXggYW5kIGZyYWdtZW50IHNoYWRlciBzcmMuXG4gICAqIEBwYXJhbSBvcHRpb25zXG4gICAqIEByZXR1cm5zIEEgc2hpbnkgbmV3IFBpeGlKUyBmaWx0ZXIhXG4gICAqL1xuICBzdGF0aWMgZnJvbShvcHRpb25zKSB7XG4gICAgY29uc3QgeyBncHUsIGdsLCAuLi5yZXN0IH0gPSBvcHRpb25zO1xuICAgIGxldCBncHVQcm9ncmFtO1xuICAgIGxldCBnbFByb2dyYW07XG4gICAgaWYgKGdwdSkge1xuICAgICAgZ3B1UHJvZ3JhbSA9IEdwdVByb2dyYW0uZnJvbShncHUpO1xuICAgIH1cbiAgICBpZiAoZ2wpIHtcbiAgICAgIGdsUHJvZ3JhbSA9IEdsUHJvZ3JhbS5mcm9tKGdsKTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBfRmlsdGVyKHtcbiAgICAgIGdwdVByb2dyYW0sXG4gICAgICBnbFByb2dyYW0sXG4gICAgICAuLi5yZXN0XG4gICAgfSk7XG4gIH1cbn07XG4vKiogVGhlIGRlZmF1bHQgZmlsdGVyIHNldHRpbmdzICovXG5fRmlsdGVyLmRlZmF1bHRPcHRpb25zID0ge1xuICBibGVuZE1vZGU6IFwibm9ybWFsXCIsXG4gIHJlc29sdXRpb246IDEsXG4gIHBhZGRpbmc6IDAsXG4gIGFudGlhbGlhczogXCJvZmZcIixcbiAgYmxlbmRSZXF1aXJlZDogZmFsc2UsXG4gIGNsaXBUb1ZpZXdwb3J0OiB0cnVlXG59O1xubGV0IEZpbHRlciA9IF9GaWx0ZXI7XG5cbmV4cG9ydCB7IEZpbHRlciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9RmlsdGVyLm1qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7QUFDQSxJQUFNLGtCQUFOLE1BQU0sZ0JBQWdCOzs7Ozs7O0NBT3BCLFlBQVksVUFBVSxHQUFHLEdBQUc7RUFDMUIsS0FBSyxLQUFLLEtBQUs7RUFDZixLQUFLLEtBQUssS0FBSztFQUNmLEtBQUssWUFBWTtDQUNuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F1QkEsTUFBTSxVQUFVO0VBQ2QsT0FBTyxJQUFJLGdCQUFnQixZQUFZLEtBQUssV0FBVyxLQUFLLElBQUksS0FBSyxFQUFFO0NBQ3pFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9CQSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUc7RUFDaEIsSUFBSSxLQUFLLE9BQU8sS0FBSyxLQUFLLE9BQU8sR0FBRztHQUNsQyxLQUFLLEtBQUs7R0FDVixLQUFLLEtBQUs7R0FDVixLQUFLLFVBQVUsVUFBVSxJQUFJO0VBQy9CO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3QkEsU0FBUyxHQUFHO0VBQ1YsSUFBSSxLQUFLLE9BQU8sRUFBRSxLQUFLLEtBQUssT0FBTyxFQUFFLEdBQUc7R0FDdEMsS0FBSyxLQUFLLEVBQUU7R0FDWixLQUFLLEtBQUssRUFBRTtHQUNaLEtBQUssVUFBVSxVQUFVLElBQUk7RUFDL0I7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7OztDQWVBLE9BQU8sR0FBRztFQUNSLEVBQUUsSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFO0VBQ3RCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlCQSxPQUFPLEdBQUc7RUFDUixPQUFPLEVBQUUsTUFBTSxLQUFLLE1BQU0sRUFBRSxNQUFNLEtBQUs7Q0FDekM7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxtQ0FBbUMsS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLFNBQVMsS0FBSyxVQUFVO0NBQ3pGOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxJQUFJLElBQUk7RUFDTixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksRUFBRSxPQUFPO0VBQ1gsSUFBSSxLQUFLLE9BQU8sT0FBTztHQUNyQixLQUFLLEtBQUs7R0FDVixLQUFLLFVBQVUsVUFBVSxJQUFJO0VBQy9CO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7OztDQWVBLElBQUksSUFBSTtFQUNOLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxFQUFFLE9BQU87RUFDWCxJQUFJLEtBQUssT0FBTyxPQUFPO0dBQ3JCLEtBQUssS0FBSztHQUNWLEtBQUssVUFBVSxVQUFVLElBQUk7RUFDL0I7Q0FDRjtBQUNGOzs7QUM3TEEsU0FBUyxpQkFBaUIsUUFBUSxRQUFRLFNBQVM7Q0FDakQsTUFBTSxFQUFFLE9BQU8sV0FBVyxRQUFRO0NBQ2xDLE1BQU0sT0FBTyxRQUFRO0NBQ3JCLElBQUksTUFBTTtFQUNSLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sZUFBZSxLQUFLO0VBQzFCLE9BQU8sT0FBTyxLQUFLLElBQUksT0FBTyxLQUFLO0VBQ25DLE9BQU8sT0FBTyxPQUFPLE9BQU87RUFDNUIsT0FBTyxPQUFPLEtBQUssSUFBSSxPQUFPLEtBQUs7RUFDbkMsT0FBTyxPQUFPLE9BQU8sT0FBTztDQUM5QixPQUFPO0VBQ0wsT0FBTyxPQUFPLENBQUMsT0FBTyxLQUFLO0VBQzNCLE9BQU8sT0FBTyxPQUFPLE9BQU87RUFDNUIsT0FBTyxPQUFPLENBQUMsT0FBTyxLQUFLO0VBQzNCLE9BQU8sT0FBTyxPQUFPLE9BQU87Q0FDOUI7QUFDRjs7O0FDaEJBLElBQU0sZUFBZTtDQUNuQixVQUFVO0NBQ1YsVUFBVTtDQUNWLGtCQUFrQjtBQUNwQjs7O0FDRkEsSUFBTSxzQkFBc0I7Q0FDMUIsSUFBSSxvQkFBb0I7RUFDdEIsT0FBTyxDQUFDLENBQUMsS0FBSyxhQUFhO0NBQzdCO0NBQ0EsZUFBZSxLQUFLO0VBQ2xCLElBQUksT0FBTyxRQUFRLGFBQWEsUUFBUSxPQUN0QyxLQUFLLG1CQUFtQjtPQUNuQjtHQUNMLEtBQUssa0JBQWtCO0dBQ3ZCLEtBQUssWUFBWSxxQkFBcUIsUUFBUSxPQUFPLENBQUMsSUFBSSxHQUFHO0VBQy9EO0NBQ0Y7Q0FDQSxxQkFBcUI7RUFDbkIsS0FBSyxhQUFhLG1CQUFtQjtDQUN2QztDQUNBLElBQUksZ0JBQWdCO0VBQ2xCLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxjQUFjLEtBQUs7RUFDckIsWUFBWSxVQUFVLDBEQUEwRDtFQUNoRixLQUFLLGVBQWUsR0FBRztDQUN6QjtBQUNGOzs7QUN4QkEsU0FBUyxZQUFZLEtBQUssVUFBVSxhQUFhO0NBQy9DLE1BQU0sU0FBUyxJQUFJO0NBQ25CLElBQUk7Q0FDSixJQUFJLFlBQVksVUFBVSxnQkFBZ0IsR0FDeEM7Q0FFRixjQUFjLFdBQVcsY0FBYyxTQUFTLFNBQVMsV0FBVztDQUNwRSxNQUFNLE1BQU0sU0FBUztDQUNyQixLQUFLLElBQUksVUFBVSxJQUFJLEtBQUssRUFBRSxHQUM1QixJQUFJLEtBQUssSUFBSSxJQUFJO0NBRW5CLElBQUksU0FBUztBQUNmOzs7QUNUQSxJQUFNLHNCQUFzQjtDQUMxQixlQUFlO0NBQ2YsZUFBZSxhQUFhLEdBQUcsVUFBVTtFQUN2QyxNQUFNLE1BQU0sWUFBWSxLQUFLLFNBQVM7RUFDdEMsTUFBTSxRQUFRLE1BQU07RUFDcEIsTUFBTSxVQUFVLENBQUM7RUFDakIsSUFBSSxRQUFRLEtBQUssU0FBUyxLQUFLO0dBQzdCLEtBQUssSUFBSSxJQUFJLE1BQU0sR0FBRyxLQUFLLFlBQVksS0FBSztJQUMxQyxNQUFNLFFBQVEsS0FBSyxTQUFTO0lBQzVCLElBQUksQ0FBQyxPQUFPO0lBQ1osUUFBUSxLQUFLLEtBQUs7SUFDbEIsTUFBTSxTQUFTO0dBQ2pCO0dBQ0EsWUFBWSxLQUFLLFVBQVUsWUFBWSxHQUFHO0dBQzFDLE1BQU0sY0FBYyxLQUFLLGVBQWUsS0FBSztHQUM3QyxJQUFJLGFBQ0YsWUFBWSxlQUFlLE9BQU87R0FFcEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxFQUFFLEdBQUc7SUFDdkMsTUFBTSxRQUFRLFFBQVE7SUFDdEIsTUFBTSxtQkFBbUIsT0FBTyxLQUFLO0lBQ3JDLEtBQUssS0FBSyxnQkFBZ0IsT0FBTyxNQUFNLENBQUM7SUFDeEMsUUFBUSxFQUFFLENBQUMsS0FBSyxXQUFXLElBQUk7R0FDakM7R0FDQSxJQUFJLFFBQVEsU0FBUyxHQUNuQixLQUFLO0dBRVAsT0FBTztFQUNULE9BQU8sSUFBSSxVQUFVLEtBQUssS0FBSyxTQUFTLFdBQVcsR0FDakQsT0FBTztFQUVULE1BQU0sSUFBSSxXQUFXLGtFQUFrRTtDQUN6RjtDQUNBLGNBQWMsT0FBTztFQUNuQixNQUFNLFFBQVEsS0FBSyxXQUFXLEtBQUs7RUFDbkMsT0FBTyxLQUFLLFlBQVksS0FBSztDQUMvQjtDQUNBLFdBQVcsT0FBTztFQUNoQixJQUFJLFFBQVEsS0FBSyxTQUFTLEtBQUssU0FBUyxRQUN0QyxNQUFNLElBQUksTUFBTSxzQkFBc0IsTUFBTSxrQkFBa0I7RUFFaEUsT0FBTyxLQUFLLFNBQVM7Q0FDdkI7Q0FDQSxjQUFjLE9BQU8sT0FBTztFQUMxQixJQUFJLFFBQVEsS0FBSyxTQUFTLEtBQUssU0FBUyxRQUN0QyxNQUFNLElBQUksTUFBTSxhQUFhLE1BQU0sNkJBQTZCLEtBQUssU0FBUyxRQUFRO0VBRXhGLEtBQUssY0FBYyxLQUFLO0VBQ3hCLEtBQUssV0FBVyxPQUFPLEtBQUs7Q0FDOUI7Q0FDQSxjQUFjLE9BQU87RUFDbkIsTUFBTSxRQUFRLEtBQUssU0FBUyxRQUFRLEtBQUs7RUFDekMsSUFBSSxVQUFVLElBQ1osTUFBTSxJQUFJLE1BQU0sc0RBQXNEO0VBRXhFLE9BQU87Q0FDVDtDQUNBLFdBQVcsT0FBTyxPQUFPO0VBQ3ZCLElBQUksQ0FBQyxLQUFLLGVBQ1IsWUFBWSxRQUFRLHVFQUF1RTtFQUU3RixNQUFNLEVBQUUsYUFBYTtFQUNyQixJQUFJLFFBQVEsS0FBSyxRQUFRLFNBQVMsUUFDaEMsTUFBTSxJQUFJLE1BQU0sR0FBRyxNQUFNLHdCQUF3QixNQUFNLDZCQUE2QixTQUFTLFFBQVE7RUFFdkcsTUFBTSxhQUFhLE1BQU0sV0FBVztFQUNwQyxJQUFJLE1BQU0sUUFBUTtHQUNoQixNQUFNLGVBQWUsTUFBTSxPQUFPLFNBQVMsUUFBUSxLQUFLO0dBQ3hELElBQUksWUFBWTtJQUNkLElBQUksaUJBQWlCLE9BQ25CLE9BQU87SUFFVCxNQUFNLE9BQU8sU0FBUyxPQUFPLGNBQWMsQ0FBQztHQUM5QyxPQUNFLE1BQU0saUJBQWlCO0VBRTNCO0VBQ0EsSUFBSSxVQUFVLFNBQVMsUUFDckIsU0FBUyxLQUFLLEtBQUs7T0FFbkIsU0FBUyxPQUFPLE9BQU8sR0FBRyxLQUFLO0VBRWpDLE1BQU0sY0FBYyxLQUFLLGVBQWUsS0FBSztFQUM3QyxJQUFJLEtBQUssa0JBQWtCLEtBQUssWUFBWTtFQUM1QyxJQUFJLFlBQVk7R0FDZCxJQUFJLGFBQ0YsWUFBWSxxQkFBcUI7R0FFbkMsT0FBTztFQUNUO0VBQ0EsTUFBTSxTQUFTO0VBQ2YsTUFBTSxZQUFZO0VBQ2xCLE1BQU0sZUFBZTtFQUNyQixJQUFJLGFBQ0YsWUFBWSxTQUFTLEtBQUs7RUFFNUIsS0FBSyxLQUFLLGNBQWMsT0FBTyxNQUFNLEtBQUs7RUFDMUMsTUFBTSxLQUFLLFNBQVMsSUFBSTtFQUN4QixPQUFPO0NBQ1Q7Q0FDQSxhQUFhLE9BQU8sUUFBUTtFQUMxQixJQUFJLFVBQVUsUUFDWjtFQUVGLE1BQU0sU0FBUyxLQUFLLGNBQWMsS0FBSztFQUN2QyxNQUFNLFNBQVMsS0FBSyxjQUFjLE1BQU07RUFDeEMsS0FBSyxTQUFTLFVBQVU7RUFDeEIsS0FBSyxTQUFTLFVBQVU7RUFDeEIsTUFBTSxjQUFjLEtBQUssZUFBZSxLQUFLO0VBQzdDLElBQUksYUFDRixZQUFZLHFCQUFxQjtFQUVuQyxLQUFLO0NBQ1A7Q0FDQSxtQkFBbUI7RUFDakIsS0FBSyxRQUFRLFlBQVksSUFBSTtDQUMvQjtDQUNBLGNBQWMsR0FBRyxPQUFPO0VBQ3RCLElBQUksTUFBTSxXQUFXLEdBQ25CLE9BQU8sS0FBSyxnQkFBZ0IsTUFBTSxJQUFJLEtBQUssU0FBUyxNQUFNO0VBRTVELE1BQU0sU0FBUyxNQUFNLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxTQUFTLE1BQU0sQ0FBQztFQUNsRSxPQUFPLE1BQU07Q0FDZjtDQUNBLGdCQUFnQixPQUFPLE9BQU87RUFDNUIsSUFBSSxNQUFNLFdBQVcsTUFBTTtHQUN6QixLQUFLLGNBQWMsT0FBTyxLQUFLO0dBQy9CLE9BQU87RUFDVDtFQUNBLE1BQU0sV0FBVyxNQUFNLGVBQWUsTUFBTTtFQUM1QyxNQUFNLGlCQUFpQjtFQUN2QixLQUFLLFdBQVcsT0FBTyxLQUFLO0VBQzVCLE1BQU0sWUFBWSxLQUFLLGVBQWUsTUFBTTtFQUM1QyxVQUFVLE9BQU87RUFDakIsU0FBUyxRQUFRLFNBQVM7RUFDMUIsTUFBTSxjQUFjLFFBQVE7RUFDNUIsT0FBTztDQUNUO0NBQ0EsYUFBYSxVQUFVLFVBQVU7RUFDL0IsU0FBUyxxQkFBcUI7RUFDOUIsS0FBSyxXQUFXLFVBQVUsS0FBSyxjQUFjLFFBQVEsQ0FBQztFQUN0RCxTQUFTLGNBQWMsU0FBUyxjQUFjO0VBQzlDLFNBQVMscUJBQXFCO0VBQzlCLEtBQUssWUFBWSxRQUFRO0NBQzNCO0FBQ0Y7OztBQ3BKQSxJQUFNLDBCQUEwQjtDQUM5QixtQkFBbUIsZ0JBQWdCLFVBQVUsY0FBYztFQUN6RCxJQUFJLEtBQUsscUJBQXFCLEtBQUssc0JBQXNCLGdCQUFnQixLQUFLLHNCQUFzQixLQUFLLENBQUMsS0FBSyxnQkFBZ0I7RUFDL0gsSUFBSSxLQUFLLGtCQUNQLEtBQUssYUFBYTtFQUVwQixJQUFJLEtBQUssVUFDUCxLQUFLLHlCQUF5QixnQkFBZ0IsVUFBVSxZQUFZO09BQy9ELElBQUksS0FBSyxhQUNkLFNBQVMsWUFBWSxZQUFZLGVBQWUsS0FBSyxhQUFhLGNBQWM7T0FFaEYsS0FBSyw4QkFBOEIsZ0JBQWdCLFVBQVUsWUFBWTtDQUU3RTtDQUNBLHlCQUF5QixnQkFBZ0IsVUFBVSxjQUFjO0VBQy9ELE1BQU0sV0FBVyxLQUFLO0VBQ3RCLE1BQU0sU0FBUyxTQUFTO0VBQ3hCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQzFCLFNBQVMsRUFBRSxDQUFDLG1CQUFtQixnQkFBZ0IsVUFBVSxZQUFZO0NBRXpFO0NBQ0EsOEJBQThCLGdCQUFnQixVQUFVLGNBQWM7RUFDcEUsTUFBTSxFQUFFLGdCQUFnQjtFQUN4QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLFFBQVEsS0FBSztHQUM1QyxNQUFNLFNBQVMsS0FBSyxRQUFRO0dBRTVCLFlBRHlCLE9BQU8sS0FDNUIsQ0FBQyxLQUFLLFFBQVEsTUFBTSxjQUFjO0VBQ3hDO0VBQ0EsS0FBSyx5QkFBeUIsZ0JBQWdCLFVBQVUsWUFBWTtFQUNwRSxLQUFLLElBQUksSUFBSSxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ2pELE1BQU0sU0FBUyxLQUFLLFFBQVE7R0FFNUIsWUFEeUIsT0FBTyxLQUM1QixDQUFDLElBQUksUUFBUSxNQUFNLGNBQWM7RUFDdkM7Q0FDRjtBQUNGOzs7QUNuQ0EsSUFBTSxlQUFOLE1BQW1CO0NBQ2pCLGNBQWM7O0VBRVosS0FBSyxPQUFPOztFQUVaLEtBQUssV0FBVztDQUNsQjtDQUNBLFVBQVU7RUFDUixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLFFBQVEsS0FDdkMsS0FBSyxRQUFRLEVBQUUsQ0FBQyxRQUFRO0VBRTFCLEtBQUssVUFBVTtFQUNmLEtBQUssYUFBYTtDQUNwQjtBQUNGOzs7QUNYQSxJQUFNLHlCQUFOLE1BQTZCO0NBQzNCLGNBQWM7O0VBRVosS0FBSyxpQkFBaUIsQ0FBQztFQUN2QixLQUFLLFNBQVMsQ0FBQztFQUNmLEtBQUssZUFBZTtDQUN0QjtDQUNBLE9BQU87RUFDTCxJQUFJLEtBQUssY0FBYztFQUN2QixLQUFLLGVBQWU7RUFDcEIsS0FBSyxlQUFlLFNBQVMsU0FBUztHQUNwQyxLQUFLLElBQUk7SUFDUCxNQUFNLEtBQUs7SUFDWCxXQUFXO0dBQ2IsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLElBQUksTUFBTTtFQUNSLEtBQUssT0FBTyxLQUFLLElBQUk7Q0FDdkI7Q0FDQSxjQUFjLE1BQU07RUFDbEIsSUFBSSxDQUFDLEtBQUssY0FBYyxLQUFLLEtBQUs7RUFDbEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssT0FBTyxRQUFRLEtBQUs7R0FDM0MsTUFBTSxPQUFPLEtBQUssT0FBTztHQUN6QixJQUFJLEtBQUssS0FBSyxJQUFJLEdBQ2hCLE9BQU8sUUFBUSxJQUFJLEtBQUssV0FBVyxJQUFJO0VBRTNDO0VBQ0EsT0FBTztDQUNUO0NBQ0EsaUJBQWlCLFFBQVE7RUFDdkIsUUFBUSxPQUFPLE1BQU07Q0FDdkI7QUFDRjtBQUNBLElBQU0sb0JBQW9CLElBQUksdUJBQXVCO0FBQ3JELFdBQVcsYUFBYSxjQUFjLFlBQVksa0JBQWtCLGNBQWM7OztBQ25DbEYsSUFBTSxlQUFlO0NBQ25CLGFBQWE7Q0FDYixjQUFjO0VBQ1osU0FBUztFQUNULFNBQVM7Q0FDWDtDQUNBLGVBQWU7Q0FDZixTQUFTLENBQUM7Q0FDViwwQkFBMEI7RUFDeEIsTUFBTSxjQUFjLEtBQUssZUFBZSxLQUFLO0VBQzdDLElBQUksYUFDRixZQUFZLHFCQUFxQjtDQUVyQztDQUNBLFVBQVUsUUFBUTtFQUVoQixJQURjLEtBQUssUUFBUSxRQUFRLE1BQzNCLE1BQU0sSUFBSTtFQUNsQixLQUFLLFFBQVEsS0FBSyxNQUFNO0VBQ3hCLEtBQUssUUFBUSxNQUFNLEdBQUcsTUFBTSxFQUFFLFdBQVcsRUFBRSxRQUFRO0VBQ25ELEtBQUssd0JBQXdCO0VBQzdCLEtBQUssZ0JBQWdCO0NBQ3ZCO0NBQ0EsYUFBYSxRQUFRO0VBQ25CLE1BQU0sUUFBUSxLQUFLLFFBQVEsUUFBUSxNQUFNO0VBQ3pDLElBQUksVUFBVSxJQUFJO0VBQ2xCLEtBQUssUUFBUSxPQUFPLE9BQU8sQ0FBQztFQUM1QixLQUFLLHdCQUF3QjtFQUM3QixLQUFLLGdCQUFnQjtDQUN2QjtDQUNBLElBQUksS0FBSyxPQUFPO0VBQ2QsTUFBTSxTQUFTLEtBQUs7RUFDcEIsSUFBSSxRQUFRLFNBQVMsT0FBTztFQUM1QixJQUFJLFFBQVE7R0FDVixLQUFLLGFBQWEsTUFBTTtHQUN4QixrQkFBa0IsaUJBQWlCLE1BQU07R0FDekMsS0FBSyxjQUFjO0VBQ3JCO0VBQ0EsSUFBSSxVQUFVLFFBQVEsVUFBVSxLQUFLLEdBQUc7RUFDeEMsS0FBSyxjQUFjLGtCQUFrQixjQUFjLEtBQUs7RUFDeEQsS0FBSyxVQUFVLEtBQUssV0FBVztDQUNqQztDQUNBLElBQUksT0FBTztFQUNULE9BQU8sS0FBSyxhQUFhO0NBQzNCO0NBQ0EsUUFBUSxTQUFTO0VBQ2YsS0FBSyxlQUFlO0dBQ2xCLEdBQUcsS0FBSztHQUNSLEdBQUc7RUFDTDtFQUNBLElBQUksUUFBUSxNQUNWLEtBQUssT0FBTyxRQUFRO0VBRXRCLEtBQUssd0JBQXdCO0NBQy9CO0NBQ0EsSUFBSSxRQUFRLE9BQU87RUFDakIsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQUssT0FBTyxRQUFRLENBQUMsS0FBSztFQUNsRCxNQUFNLFNBQVMsS0FBSyxrQkFBa0IsS0FBSyxnQkFBZ0IsSUFBSSxhQUFhO0VBQzVFLFFBQVE7RUFDUixNQUFNLGFBQWEsT0FBTyxTQUFTO0VBRW5DLE1BQU0sWUFBWSxlQURDLE9BQU8sU0FBUyxTQUFTO0VBRTVDLFFBQVEsTUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLE1BQU0sQ0FBQyxJQUFJO0VBQ2hELE9BQU8sVUFBVSxPQUFPLE9BQU8sS0FBSztFQUNwQyxJQUFJLFdBQVc7R0FDYixJQUFJLFlBQ0YsS0FBSyxVQUFVLE1BQU07UUFDaEI7SUFDTCxLQUFLLGFBQWEsTUFBTTtJQUN4QixPQUFPLFVBQVUsU0FBUztHQUM1QjtFQUNGO0NBQ0Y7Q0FDQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUssZUFBZTtDQUM3QjtDQUNBLElBQUksV0FBVyxPQUFPO0VBQ3BCLEtBQUssa0JBQWtCLEtBQUssZ0JBQWdCLElBQUksYUFBYTtFQUM3RCxLQUFLLGNBQWMsYUFBYTtDQUNsQztDQUNBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBSyxlQUFlO0NBQzdCO0FBQ0Y7OztBQ25GQSxJQUFNLFlBQVk7Q0FDaEIsT0FBTztDQUNQLElBQUksT0FBTztFQUNULFlBQVksUUFBUSx1RUFBdUU7RUFDM0YsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLEtBQUssT0FBTztFQUNkLFlBQVksUUFBUSx1RUFBdUU7RUFDM0YsS0FBSyxRQUFRO0NBQ2Y7Q0FDQSxlQUFlLE1BQU0sT0FBTyxPQUFPO0VBQ2pDLE9BQU8sS0FBSyxnQkFBZ0IsTUFBTSxJQUFJO0NBQ3hDO0NBQ0EsZ0JBQWdCLE9BQU8sT0FBTyxPQUFPO0VBQ25DLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztHQUN4QyxNQUFNLFFBQVEsU0FBUztHQUN2QixJQUFJLE1BQU0sVUFBVSxTQUFTLGlCQUFpQixVQUFVLE1BQU0sS0FBSyxNQUFNLEtBQUssR0FBRyxPQUFPO0VBQzFGO0VBQ0EsSUFBSSxNQUNGLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztHQUV4QyxNQUFNLFFBRFEsU0FBUyxFQUNKLENBQUMsZ0JBQWdCLE9BQU8sSUFBSTtHQUMvQyxJQUFJLE9BQ0YsT0FBTztFQUVYO0VBRUYsT0FBTztDQUNUO0NBQ0EsbUJBQW1CLE9BQU8sT0FBTyxPQUFPLE1BQU0sQ0FBQyxHQUFHO0VBQ2hELE1BQU0sV0FBVyxLQUFLO0VBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztHQUN4QyxNQUFNLFFBQVEsU0FBUztHQUN2QixJQUFJLE1BQU0sVUFBVSxTQUFTLGlCQUFpQixVQUFVLE1BQU0sS0FBSyxNQUFNLEtBQUssR0FDNUUsSUFBSSxLQUFLLEtBQUs7RUFFbEI7RUFDQSxJQUFJLE1BQ0YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUNuQyxTQUFTLEVBQUUsQ0FBQyxtQkFBbUIsT0FBTyxNQUFNLEdBQUc7RUFHbkQsT0FBTztDQUNUO0FBQ0Y7OztBQzNDQSxJQUFNLGFBQWEsUUFBUSxRQUFRLE1BQU07QUFDekMsSUFBTSxhQUFhLFFBQVEsUUFBUSxNQUFNOzs7QUNEekMsSUFBTUEsZUFBYSxJQUFJLE9BQU87QUFDOUIsSUFBTSwyQkFBMkI7Q0FDL0Isb0JBQW9CLG9CQUFvQixRQUFRO0VBQzlDLFdBQVcsU0FBUyxJQUFJLE9BQU87RUFDL0IsT0FBTyxNQUFNO0VBQ2IsS0FBSywwQkFBMEIsQ0FBQyxDQUFDLG9CQUFvQixRQUFRLEtBQUssaUJBQWlCO0VBQ25GLElBQUksQ0FBQyxPQUFPLFNBQ1YsT0FBTyxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFFdkIsTUFBTSxjQUFjLEtBQUssZUFBZSxLQUFLO0VBQzdDLE9BQU8sWUFBWSxZQUFZLGNBQWM7RUFDN0MsT0FBTztDQUNUO0NBQ0EsMEJBQTBCLG9CQUFvQixRQUFRLGNBQWM7RUFDbEUsSUFBSSxjQUFjO0VBQ2xCLElBQUksc0JBQXNCLEtBQUsscUJBQXFCLEtBQUssc0JBQXNCLGNBQWM7RUFDN0YsSUFBSSxLQUFLLHVCQUF1QixLQUFLLENBQUMsS0FBSyxZQUN6QztFQUVGLE1BQU0sZ0JBQWdCLENBQUMsQ0FBQyxLQUFLLFFBQVE7RUFDckMsSUFBSSxLQUFLLGVBQWUsZUFDdEIsY0FBYyxXQUFXLElBQUksQ0FBQyxDQUFDLE1BQU07RUFFdkMsSUFBSSxLQUFLLFlBQ1AsT0FBTyxRQUFRLEtBQUssWUFBWSxLQUFLLGNBQWM7T0FDOUM7R0FDTCxJQUFJLEtBQUssY0FBYztJQUNyQixNQUFNLGFBQWEsS0FBSztJQUN4QixZQUFZLFNBQ1YsV0FBVyxNQUNYLFdBQVcsTUFDWCxXQUFXLE1BQ1gsV0FBVyxNQUNYLEtBQUssY0FDUDtHQUNGO0dBQ0EsTUFBTSxXQUFXLEtBQUs7R0FDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUNuQyxTQUFTLEVBQUUsQ0FBQywwQkFBMEIsb0JBQW9CLGFBQWEsWUFBWTtFQUV2RjtFQUNBLElBQUksZUFBZTtHQUNqQixJQUFJLFdBQVc7R0FDZixNQUFNLGNBQWMsS0FBSyxlQUFlLEtBQUs7R0FDN0MsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxRQUFRLEtBQ3ZDLElBQUksS0FBSyxRQUFRLEVBQUUsQ0FBQyxXQUFXO0lBQzdCLElBQUksQ0FBQyxVQUFVO0tBQ2IsV0FBVztLQUNYLFlBQVksWUFBWSxZQUFZLGNBQWM7SUFDcEQ7SUFDQSxLQUFLLFFBQVEsRUFBRSxDQUFDLFVBQVUsYUFBYSxJQUFJO0dBQzdDO0dBRUYsSUFBSSxVQUNGLFlBQVksWUFBWSxZQUFZLGVBQWUsT0FBT0EsWUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDO0dBRWhGLE9BQU8sVUFBVSxXQUFXO0dBQzVCLFdBQVcsT0FBTyxXQUFXO0VBQy9CLE9BQU8sSUFBSSxLQUFLLGFBQWE7R0FDM0IsT0FBTyxVQUFVLGFBQWEsS0FBSyxzQkFBc0I7R0FDekQsV0FBVyxPQUFPLFdBQVc7RUFDL0I7Q0FDRjtBQUNGOzs7QUNoRUEsU0FBUyxnQkFBZ0IsUUFBUSxxQkFBcUIsUUFBUTtDQUM1RCxPQUFPLE1BQU07Q0FDYixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksT0FBTyxRQUFRO0VBQ2pCLElBQUksQ0FBQyxxQkFBcUI7R0FDeEIsZUFBZSxXQUFXLElBQUksQ0FBQyxDQUFDLFNBQVM7R0FDekMsa0JBQWtCLHlCQUF5QixRQUFRLFlBQVk7RUFDakUsT0FDRSxrQkFBa0IsT0FBTyxPQUFPO0NBRXBDLE9BQ0Usa0JBQWtCLE9BQU87Q0FFM0IsaUJBQWlCLFFBQVEsUUFBUSxpQkFBaUIsbUJBQW1CO0NBQ3JFLElBQUksY0FDRixXQUFXLE9BQU8sWUFBWTtDQUVoQyxJQUFJLENBQUMsT0FBTyxTQUNWLE9BQU8sSUFBSSxHQUFHLEdBQUcsR0FBRyxDQUFDO0NBRXZCLE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLFFBQVEsUUFBUSxpQkFBaUIscUJBQXFCO0NBQzlFLElBQUksQ0FBQyxPQUFPLFdBQVcsQ0FBQyxPQUFPLFlBQVk7Q0FDM0MsSUFBSTtDQUNKLElBQUksQ0FBQyxxQkFBcUI7RUFDeEIsT0FBTyxxQkFBcUI7RUFDNUIsaUJBQWlCLFdBQVcsSUFBSTtFQUNoQyxlQUFlLFdBQVcsT0FBTyxnQkFBZ0IsZUFBZTtDQUNsRSxPQUNFLGlCQUFpQixPQUFPO0NBRTFCLE1BQU0sZUFBZTtDQUNyQixNQUFNLGlCQUFpQixDQUFDLENBQUMsT0FBTyxRQUFRO0NBQ3hDLElBQUksZ0JBQ0YsU0FBUyxXQUFXLElBQUksQ0FBQyxDQUFDLE1BQU07Q0FFbEMsSUFBSSxPQUFPLFlBQ1QsT0FBTyxRQUFRLE9BQU8sWUFBWSxjQUFjO01BQzNDO0VBQ0wsTUFBTSxtQkFBbUIsT0FBTztFQUNoQyxJQUFJLG9CQUFvQixDQUFDLGlCQUFpQixRQUFRLEdBQUc7R0FDbkQsT0FBTyxTQUFTO0dBQ2hCLE9BQU8sVUFBVSxnQkFBZ0I7RUFDbkM7RUFDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxTQUFTLFFBQVEsS0FDMUMsaUJBQWlCLE9BQU8sU0FBUyxJQUFJLFFBQVEsZ0JBQWdCLG1CQUFtQjtDQUVwRjtDQUNBLElBQUksZ0JBQWdCO0VBQ2xCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsUUFBUSxLQUN6QyxPQUFPLFFBQVEsRUFBRSxDQUFDLFlBQVksTUFBTTtFQUV0QyxhQUFhLFVBQVUsUUFBUSxPQUFPLFFBQVE7RUFDOUMsV0FBVyxPQUFPLE1BQU07Q0FDMUI7Q0FDQSxJQUFJLENBQUMscUJBQ0gsV0FBVyxPQUFPLGNBQWM7QUFFcEM7QUFDQSxTQUFTLHlCQUF5QixRQUFRLGlCQUFpQjtDQUN6RCxNQUFNLFNBQVMsT0FBTztDQUN0QixJQUFJLFFBQVE7RUFDVix5QkFBeUIsUUFBUSxlQUFlO0VBQ2hELE9BQU8scUJBQXFCO0VBQzVCLGdCQUFnQixPQUFPLE9BQU8sY0FBYztDQUM5QztDQUNBLE9BQU87QUFDVDs7O0FDdEVBLElBQU0sWUFBWTtBQUNsQixTQUFTLGVBQWUsZUFBZSxnQkFBZ0I7Q0FDckQsSUFBSSxrQkFBa0IsV0FDcEIsT0FBTztDQUVULElBQUksbUJBQW1CLFdBQ3JCLE9BQU87Q0FFVCxPQUFPLGtCQUFrQixlQUFlLGNBQWM7QUFDeEQ7OztBQ05BLFNBQVMsUUFBUSxPQUFPO0NBQ3RCLFNBQVMsUUFBUSxRQUFRLE9BQU8sUUFBUSxVQUFVLFNBQVMsS0FBSztBQUNsRTtBQUNBLElBQU0saUJBQWlCO0NBQ3JCLGVBQWUsWUFBWTtFQUN6QixJQUFJLFlBQVk7R0FDZCxJQUFJLEtBQUssYUFDUCxPQUFPLEtBQUssWUFBWTtHQUUxQixJQUFJLEtBQUssbUJBQ1AsT0FBTyxLQUFLLGtCQUFrQixhQUFhLEtBQUs7R0FFbEQsT0FBTyxLQUFLO0VBQ2Q7RUFDQSxJQUFJLFFBQVEsS0FBSztFQUNqQixJQUFJLFVBQVUsS0FBSztFQUNuQixPQUFPLFNBQVM7R0FDZCxTQUFTLFFBQVE7R0FDakIsVUFBVSxRQUFRO0VBQ3BCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsbUJBQW1CLFNBQVMsSUFBSSxPQUFPLEdBQUcsWUFBWTtFQUNwRCxJQUFJLFlBQ0YsT0FBTyxPQUFPLFNBQVMsS0FBSyxjQUFjO0VBRTVDLEtBQUsscUJBQXFCO0VBQzFCLE1BQU0sa0JBQWtCLHlCQUF5QixNQUFNLFdBQVcsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDO0VBQ2xGLE9BQU8sV0FBVyxLQUFLLGdCQUFnQixlQUFlO0VBQ3RELFdBQVcsT0FBTyxlQUFlO0VBQ2pDLE9BQU87Q0FDVDtDQUNBLGNBQWMsWUFBWTtFQUN4QixJQUFJLFlBQVk7R0FDZCxJQUFJLEtBQUssYUFDUCxPQUFPLFFBQVEsS0FBSyxZQUFZLFVBQVU7R0FFNUMsSUFBSSxLQUFLLG1CQUNQLE9BQU8sUUFDTCxlQUFlLEtBQUssWUFBWSxLQUFLLGtCQUFrQixVQUFVLENBQ25FO0dBRUYsT0FBTyxLQUFLO0VBQ2Q7RUFDQSxJQUFJLFFBQVEsS0FBSztFQUNqQixJQUFJLFNBQVMsS0FBSztFQUNsQixPQUFPLFFBQVE7R0FDYixRQUFRLGVBQWUsT0FBTyxPQUFPLFVBQVU7R0FDL0MsU0FBUyxPQUFPO0VBQ2xCO0VBQ0EsT0FBTyxRQUFRLEtBQUs7Q0FDdEI7QUFDRjs7O0FDdERBLFNBQVMsZUFBZSxRQUFRLFFBQVEsZ0JBQWdCO0NBQ3RELE9BQU8sTUFBTTtDQUNiLG1CQUFtQixpQkFBaUIsT0FBTztDQUMzQyxnQkFBZ0IsUUFBUSxRQUFRLGdCQUFnQixRQUFRLElBQUk7Q0FDNUQsSUFBSSxDQUFDLE9BQU8sU0FDVixPQUFPLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQztDQUV2QixPQUFPO0FBQ1Q7QUFDQSxTQUFTLGdCQUFnQixRQUFRLFFBQVEsaUJBQWlCLGVBQWUsUUFBUTtDQUMvRSxJQUFJO0NBQ0osSUFBSSxDQUFDLFFBQVE7RUFDWCxJQUFJLENBQUMsT0FBTyxXQUFXLENBQUMsT0FBTyxZQUFZO0VBQzNDLE9BQU8scUJBQXFCO0VBQzVCLE1BQU0saUJBQWlCLE9BQU87RUFDOUIsb0JBQW9CLFdBQVcsSUFBSTtFQUNuQyxrQkFBa0IsV0FBVyxnQkFBZ0IsZUFBZTtDQUM5RCxPQUFPO0VBQ0wsb0JBQW9CLFdBQVcsSUFBSTtFQUNuQyxvQkFBb0IsZ0JBQWdCLE9BQU8saUJBQWlCO0NBQzlEO0NBQ0EsTUFBTSxlQUFlO0NBQ3JCLE1BQU0saUJBQWlCLENBQUMsQ0FBQyxPQUFPLFFBQVE7Q0FDeEMsSUFBSSxnQkFDRixTQUFTLFdBQVcsSUFBSSxDQUFDLENBQUMsTUFBTTtDQUVsQyxJQUFJLE9BQU8sWUFDVCxPQUFPLFFBQVEsT0FBTyxZQUFZLGlCQUFpQjtNQUM5QztFQUNMLElBQUksT0FBTyxjQUFjO0dBQ3ZCLE9BQU8sU0FBUztHQUNoQixPQUFPLFVBQVUsT0FBTyxNQUFNO0VBQ2hDO0VBQ0EsTUFBTSxXQUFXLE9BQU87RUFDeEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUNuQyxnQkFBZ0IsU0FBUyxJQUFJLFFBQVEsbUJBQW1CLGVBQWUsS0FBSztDQUVoRjtDQUNBLElBQUksZ0JBQWdCO0VBQ2xCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsUUFBUSxLQUN6QyxPQUFPLFFBQVEsRUFBRSxDQUFDLGlCQUFpQixRQUFRLGFBQWE7RUFFMUQsYUFBYSxVQUFVLFFBQVEsT0FBTyxRQUFRO0VBQzlDLFdBQVcsT0FBTyxNQUFNO0NBQzFCO0NBQ0EsV0FBVyxPQUFPLGlCQUFpQjtBQUNyQzs7O0FDakRBLFNBQVMsdUJBQXVCLFdBQVcsY0FBYztDQUN2RCxNQUFNLFdBQVcsVUFBVTtDQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7RUFDeEMsTUFBTSxRQUFRLFNBQVM7RUFDdkIsTUFBTSxNQUFNLE1BQU07RUFDbEIsTUFBTSxhQUFhLE1BQU0scUJBQXFCLFVBQVUsS0FBSyxNQUFNLDBCQUEwQjtFQUM3RixNQUFNLFFBQVEsYUFBYTtFQUMzQixJQUFJLGFBQWEsS0FBSyxXQUFXLE9BQU8sYUFBYSxLQUFLLFFBQVEsT0FBTyxXQUFXO0dBQ2xGLGFBQWEsS0FBSyxhQUFhLFNBQVM7R0FDeEMsYUFBYSxLQUFLLGFBQWEsUUFBUSxLQUFLO0dBQzVDLGFBQWEsWUFBWTtFQUMzQjtFQUNBLGFBQWEsUUFBUSxRQUFRO0VBQzdCLElBQUksTUFBTSxTQUFTLFFBQ2pCLHVCQUF1QixPQUFPLFlBQVk7Q0FFOUM7Q0FDQSxPQUFPLGFBQWE7QUFDdEI7OztBQ1pBLElBQU0sYUFBYSxJQUFJLE9BQU87QUFDOUIsSUFBTSxlQUFlO0NBQ25CLHFCQUFxQjtDQUNyQix1QkFBdUI7Q0FDdkIsVUFBVSxPQUFPLFlBQVk7RUFDM0IsTUFBTSxPQUFPLEtBQUssS0FBSyxLQUFLLE1BQU0sQ0FBQyxLQUFLO0VBQ3hDLElBQUksZUFBZSxHQUNqQixLQUFLLE1BQU0sSUFBSSxRQUFRLGFBQWE7T0FFcEMsS0FBSyxNQUFNLElBQUk7Q0FFbkI7Q0FDQSxXQUFXLE9BQU8sYUFBYTtFQUM3QixNQUFNLE9BQU8sS0FBSyxLQUFLLEtBQUssTUFBTSxDQUFDLEtBQUs7RUFDeEMsSUFBSSxnQkFBZ0IsR0FDbEIsS0FBSyxNQUFNLElBQUksUUFBUSxjQUFjO09BRXJDLEtBQUssTUFBTSxJQUFJO0NBRW5CO0NBQ0EsaUJBQWlCO0VBQ2YsSUFBSSxDQUFDLEtBQUssdUJBQ1IsS0FBSyx3QkFBd0I7R0FDM0IsTUFBTSxDQUFDO0dBQ1AsT0FBTztHQUNQLFdBQVc7R0FDWCxhQUFhLElBQUksT0FBTztFQUMxQjtFQUVGLE1BQU0sdUJBQXVCLEtBQUs7RUFDbEMscUJBQXFCLFFBQVE7RUFDN0IscUJBQXFCLFlBQVk7RUFDakMsSUFBSSxxQkFBcUIsS0FBSyxPQUFPLEtBQUssb0JBQW9CO0dBQzVELHFCQUFxQixZQUFZO0dBQ2pDLHFCQUFxQixLQUFLLEtBQUssS0FBSztFQUN0QztFQUNBLHVCQUF1QixNQUFNLG9CQUFvQjtFQUNqRCxJQUFJLHFCQUFxQixXQUN2QixlQUFlLE1BQU0scUJBQXFCLGFBQWEsVUFBVTtFQUVuRSxPQUFPLHFCQUFxQjtDQUM5QjtDQUNBLFVBQVUsWUFBWSxRQUFRO0VBQzVCLE9BQU8sZ0JBQWdCLE1BQU0sWUFBWSxVQUFVLElBQUksT0FBTyxDQUFDO0NBQ2pFO0FBQ0Y7OztBQ25EQSxJQUFNLGdCQUFnQjtDQUNwQixXQUFXO0NBQ1gsSUFBSSxTQUFTLE1BQU07RUFDakIsTUFBTSxjQUFjLEtBQUssZUFBZSxLQUFLO0VBQzdDLElBQUksQ0FBQyxNQUFNO0dBQ1QsSUFBSSxLQUFLLFdBQ1AsYUFBYSxlQUFlLElBQUk7R0FFbEMsS0FBSyxZQUFZO0dBQ2pCO0VBQ0Y7RUFDQSxJQUFJLENBQUMsS0FBSyxXQUNSLGFBQWEsWUFBWSxJQUFJO0VBRS9CLEtBQUssWUFBWTtDQUNuQjtDQUNBLElBQUksV0FBVztFQUNiLE9BQU8sS0FBSztDQUNkO0FBQ0Y7OztBQ25CQSxJQUFNLFlBQVk7Q0FDaEIsU0FBUztDQUNULFdBQVc7Q0FDWCxrQkFBa0I7Q0FDbEIsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLE9BQU8sT0FBTztFQUNoQixJQUFJLEtBQUssWUFBWSxPQUFPO0VBQzVCLEtBQUssVUFBVTtFQUNmLEtBQUsscUJBQXFCO0NBQzVCO0NBQ0EsdUJBQXVCO0VBQ3JCLElBQUksS0FBSyxRQUFRO0dBQ2YsS0FBSyxPQUFPLG1CQUFtQjtHQUMvQixLQUFLLE9BQU8sWUFBWTtFQUMxQjtFQUNBLElBQUksS0FBSyxtQkFDUCxLQUFLLGtCQUFrQixxQkFBcUI7Q0FFaEQ7Q0FDQSxlQUFlO0VBQ2IsSUFBSSxDQUFDLEtBQUssV0FBVztFQUNyQixLQUFLLFlBQVk7RUFDakIsS0FBSyxTQUFTLEtBQUssWUFBWTtDQUNqQztBQUNGO0FBQ0EsU0FBUyxhQUFhLEdBQUcsR0FBRztDQUMxQixPQUFPLEVBQUUsVUFBVSxFQUFFO0FBQ3ZCOzs7QUMxQkEsSUFBTSxxQkFBcUI7Q0FDekIsa0JBQWtCLFFBQVEsSUFBSSxNQUFNLEdBQUcsYUFBYSxPQUFPO0VBQ3pELElBQUksS0FBSyxRQUNQLEtBQUssT0FBTyxTQUFTLEtBQUssV0FBVyxPQUFPLFVBQVU7T0FDakQ7R0FDTCxNQUFNLElBQUksS0FBSyxVQUFVO0dBQ3pCLE1BQU0sSUFBSSxLQUFLLFVBQVU7RUFDM0I7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLFVBQVUsT0FBTyxhQUFhLE9BQU87RUFDNUMsTUFBTSxlQUFlLEtBQUssbUJBQW1CLFdBQVcsSUFBSSxHQUFHLFVBQVU7RUFDekUsUUFBUSxhQUFhLE1BQU0sVUFBVSxLQUFLO0VBQzFDLFdBQVcsT0FBTyxZQUFZO0VBQzlCLE9BQU87Q0FDVDtDQUNBLFFBQVEsVUFBVSxNQUFNLE9BQU8sWUFBWTtFQUN6QyxJQUFJLE1BQ0YsV0FBVyxLQUFLLFNBQVMsVUFBVSxPQUFPLFVBQVU7RUFFdEQsTUFBTSxlQUFlLEtBQUssbUJBQW1CLFdBQVcsSUFBSSxHQUFHLFVBQVU7RUFDekUsUUFBUSxhQUFhLGFBQWEsVUFBVSxLQUFLO0VBQ2pELFdBQVcsT0FBTyxZQUFZO0VBQzlCLE9BQU87Q0FDVDtBQUNGOzs7QUNuQkEsSUFBSSxRQUFRO0FBQ1osSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxXQUFXO0FBQ2pCLElBQU0sWUFBWTtBQUNsQixJQUFNLFlBQTRCLHVCQUFPLE9BQU8sSUFBSTtBQUNwRCxJQUFJLGVBQWU7QUFDbkIsU0FBUyxTQUFTLFFBQVE7Q0FDeEIsTUFBTSxLQUFLLFVBQVU7Q0FDckIsSUFBSSxPQUFPLEtBQUssR0FBRyxPQUFPO0NBQzFCLE9BQU8sVUFBVSxVQUFVO0FBQzdCO0FBQ0EsU0FBUyxVQUFVLE9BQU8sUUFBUSxXQUFXLHFCQUFxQixRQUFRLFdBQVc7Q0FHbkYsUUFGZ0IsU0FBUyxPQUFPLFVBQVUsT0FBTyxzQkFBc0IsSUFBSSxNQUFNLE1BQU0sWUFBWSxJQUFJLE1BQ3pGLGNBQWMsWUFBWSxJQUFJLEtBQ3BCLFdBQVcsU0FBUyxNQUFNLElBQUk7QUFDeEQ7QUFDQSxJQUFNLG1CQUFOLE1BQXVCOzs7OztDQUtyQixZQUFZLGdCQUFnQjs7RUFFMUIsS0FBSywyQkFBMkIsSUFBSSxJQUFJOztFQUV4QyxLQUFLLFdBQTJCLHVCQUFPLE9BQU8sSUFBSTs7RUFFbEQsS0FBSyxhQUE2Qix1QkFBTyxPQUFPLElBQUk7O0VBRXBELEtBQUssV0FBVyxJQUFJLG1CQUFtQjtFQUN2QyxLQUFLLG9CQUFvQjtFQUN6QixLQUFLLGlCQUFpQixrQkFBa0IsQ0FBQztDQUMzQzs7Ozs7Q0FLQSxJQUFJLGVBQWU7RUFDakIsWUFBWSxTQUFTLDJIQUEySDtFQUNoSixJQUFJLENBQUMsS0FBSyxlQUFlLEtBQUssZ0JBQWdCLElBQUksYUFBYSxLQUFLLGNBQWM7RUFDbEYsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLGFBQWEsT0FBTztFQUN0QixZQUFZLFNBQVMsMkhBQTJIO0VBQ2hKLEtBQUssZ0JBQWdCO0NBQ3ZCOzs7Ozs7Q0FNQSxJQUFJLG1CQUFtQjtFQUNyQixZQUFZLFNBQVMsdUhBQXVIO0VBQzVJLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxpQkFBaUIsT0FBTztFQUMxQixZQUFZLFNBQVMsdUhBQXVIO0VBQzVJLEtBQUssb0JBQW9CO0NBQzNCO0NBQ0EsY0FBYyxHQUFHLE1BQU07RUFDckIsSUFBSSxVQUFVLEtBQUs7RUFDbkIsSUFBSSxPQUFPLFlBQVksVUFBVTtHQUMvQixZQUFZLFNBQVMsMkhBQTJIO0dBQ2hKLFVBQVU7SUFDUixPQUFPO0lBQ1AsUUFBUSxLQUFLO0lBQ2IsV0FBVyxLQUFLLE1BQU07SUFDdEIscUJBQXFCLEtBQUssTUFBTTtHQUNsQztFQUNGO0VBQ0EsTUFBTSxTQUFTLFFBQVEsVUFBVSxLQUFLLGVBQWUsVUFBVSxjQUFjLGVBQWU7RUFDNUYsTUFBTSxZQUFZLFFBQVEsYUFBYSxLQUFLLGVBQWUsYUFBYSxhQUFhLGVBQWU7RUFDcEcsTUFBTSxnQkFBZ0IsSUFBSSxjQUFjO0dBQ3RDLEdBQUcsS0FBSztHQUNSLE9BQU8sUUFBUTtHQUNmLFFBQVEsUUFBUTtHQUNoQixZQUFZO0dBQ1osV0FBVyxRQUFRLGFBQWE7R0FDaEMsb0JBQW9CO0dBQ3BCLHFCQUFxQixRQUFRLHVCQUF1QjtHQUNwRDtHQUNBO0VBQ0YsQ0FBQztFQUNELE9BQU8sSUFBSSxRQUFRO0dBQ2pCLFFBQVE7R0FDUixPQUFPLGVBQWU7RUFDeEIsQ0FBQztDQUNIO0NBQ0Esa0JBQWtCLEdBQUcsTUFBTTtFQUN6QixJQUFJLFVBQVUsS0FBSztFQUNuQixJQUFJLE9BQU8sWUFBWSxVQUFVO0dBQy9CLFlBQVksU0FBUywySUFBMkk7R0FDaEssVUFBVTtJQUNSLE9BQU87SUFDUCxRQUFRLEtBQUs7SUFDYixZQUFZLEtBQUssTUFBTTtJQUN2QixXQUFXLEtBQUssTUFBTTtJQUN0QixxQkFBcUIsS0FBSyxNQUFNO0dBQ2xDO0VBQ0Y7RUFDQSxNQUFNLGFBQWEsUUFBUTtFQUMzQixNQUFNLGNBQWMsUUFBUTtFQUM1QixNQUFNLGFBQWEsUUFBUSxjQUFjO0VBQ3pDLE1BQU0sWUFBWSxRQUFRLGFBQWE7RUFDdkMsTUFBTSxzQkFBc0IsUUFBUSx1QkFBdUI7RUFDM0QsTUFBTSxTQUFTLFFBQVEsVUFBVSxLQUFLLGVBQWUsVUFBVSxjQUFjLGVBQWU7RUFDNUYsTUFBTSxZQUFZLFFBQVEsYUFBYSxLQUFLLGVBQWUsYUFBYSxhQUFhLGVBQWU7RUFDcEcsTUFBTSxFQUFFLE9BQU8sY0FBYyxRQUFRLGtCQUFrQixLQUFLLGVBQzFELFlBQ0EsYUFDQSxVQUNGO0VBQ0EsSUFBSSxlQUFlLG1CQUFtQixnQkFBZ0IsaUJBQ3BELEtBQUssZ0JBQWdCLGFBQWEsR0FBRyxjQUFjLHNCQUFzQixnQkFBZ0IsZ0VBQWdFO0VBRTNKLE1BQU0sTUFBTSxVQUFVLGNBQWMsZUFBZSxXQUFXLHFCQUFxQixRQUFRLFNBQVM7RUFDcEcsSUFBSSxTQUFTLEtBQUssU0FBUyxJQUFJLEdBQUc7RUFDbEMsSUFBSSxDQUFDLFFBQVE7R0FDWCxTQUFTLENBQUM7R0FDVixLQUFLLFNBQVMsSUFBSSxLQUFLLE1BQU07RUFDL0I7RUFDQSxJQUFJLFVBQVUsT0FBTyxJQUFJO0VBQ3pCLElBQUksQ0FBQyxTQUFTO0dBQ1osVUFBVSxLQUFLLGNBQWM7SUFDM0IsT0FBTztJQUNQLFFBQVE7SUFDUjtJQUNBO0lBQ0E7SUFDQTtHQUNGLENBQUM7R0FDRCxLQUFLLFdBQVcsUUFBUSxPQUFPLFFBQVEsT0FBTztFQUNoRDtFQUNBLFFBQVEsT0FBTyxjQUFjO0VBQzdCLFFBQVEsT0FBTyxRQUFRLGVBQWU7RUFDdEMsUUFBUSxPQUFPLFNBQVMsZ0JBQWdCO0VBQ3hDLFFBQVEsT0FBTyxhQUFhO0VBQzVCLFFBQVEsT0FBTyxjQUFjO0VBQzdCLFFBQVEsTUFBTSxJQUFJO0VBQ2xCLFFBQVEsTUFBTSxJQUFJO0VBQ2xCLFFBQVEsTUFBTSxRQUFRO0VBQ3RCLFFBQVEsTUFBTSxTQUFTO0VBQ3ZCLFFBQVEsVUFBVTtFQUNsQixLQUFLLFNBQVMsUUFBUSxPQUFPO0VBQzdCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxlQUFlLFlBQVksYUFBYSxhQUFhLEdBQUc7RUFDdEQsTUFBTSxhQUFhLEtBQUssS0FBSyxhQUFhLGFBQWEsSUFBSTtFQUMzRCxNQUFNLGNBQWMsS0FBSyxLQUFLLGNBQWMsYUFBYSxJQUFJO0VBQzdELE1BQU0sV0FBVyxTQUFTLFVBQVU7RUFDcEMsTUFBTSxjQUFjLEtBQUssU0FBUyxnQkFBZ0IsVUFBVTtFQUM1RCxNQUFNLFlBQVksU0FBUyxXQUFXO0VBQ3RDLE1BQU0sZUFBZSxLQUFLLFNBQVMsaUJBQWlCLFdBQVc7RUFDL0QsT0FBTztHQUNMLE9BQU8sZ0JBQWdCLEtBQUssSUFBSSxLQUFLLElBQUksYUFBYSxRQUFRLElBQUk7R0FDbEUsUUFBUSxpQkFBaUIsS0FBSyxJQUFJLEtBQUssSUFBSSxjQUFjLFNBQVMsSUFBSTtFQUN4RTtDQUNGOzs7Ozs7Ozs7OztDQVdBLG1CQUFtQixTQUFTLFlBQVksT0FBTztFQUM3QyxNQUFNLFNBQVMsUUFBUTtFQUN2QixPQUFPLEtBQUssa0JBQWtCO0dBQzVCLE9BQU8sUUFBUTtHQUNmLFFBQVEsUUFBUTtHQUNoQixZQUFZLE9BQU87R0FDbkI7RUFDRixDQUFDO0NBQ0g7Ozs7Ozs7Ozs7OztDQVlBLGNBQWMsZUFBZSxhQUFhLE9BQU87RUFDL0MsTUFBTSxNQUFNLGNBQWM7RUFDMUIsTUFBTSxNQUFNLEtBQUssU0FBUztFQUMxQixJQUFJLFFBQVEsS0FBSyxHQUFHO0dBQ2xCLEtBQUssK0ZBQStGO0dBQ3BHO0VBQ0Y7RUFDQSxNQUFNLFlBQVksS0FBSyxXQUFXO0VBQ2xDLElBQUksY0FBYyxjQUFjLE9BQU8sVUFBVSxXQUMvQyxjQUFjLE9BQU8sUUFBUTtFQUUvQixNQUFNLFdBQVcsS0FBSyxTQUFTLElBQUksR0FBRztFQUN0QyxJQUFJLENBQUMsVUFBVTtHQUNiLE9BQU8sS0FBSyxTQUFTO0dBQ3JCLE9BQU8sS0FBSyxXQUFXO0dBQ3ZCLGNBQWMsUUFBUSxJQUFJO0dBQzFCO0VBQ0Y7RUFDQSxTQUFTLEtBQUssYUFBYTtDQUM3Qjs7Ozs7Ozs7Ozs7O0NBWUEsY0FBYyxhQUFhLFlBQVksYUFBYTtFQUNsRCxJQUFJLENBQUMsS0FBSyxTQUFTLElBQUksYUFBYSxZQUFZLFdBQVcsR0FBRztFQUM5RCxLQUFLLHFCQUFxQjtDQUM1Qjs7Ozs7OztDQU9BLGFBQWEsYUFBYTtFQUN4QixJQUFJLENBQUMsS0FBSyxTQUFTLE9BQU8sV0FBVyxHQUFHO0VBQ3hDLEtBQUsscUJBQXFCO0NBQzVCOzs7OztDQUtBLHVCQUF1QjtFQUNyQixLQUFLLE1BQU0sQ0FBQyxLQUFLLGFBQWEsS0FBSyxVQUFVO0dBQzNDLE1BQU0sU0FBUyxRQUFRO0dBQ3ZCLE1BQU0sUUFBUSxXQUFXO0dBQ3pCLE1BQU0sU0FBUyxXQUFXLElBQUk7R0FDOUIsS0FBSyxPQUFPLEtBQUssS0FBSyxLQUFLLFNBQVMsU0FBUyxLQUFLLE9BQU8sT0FBTyxNQUFNLEtBQUssS0FBSyxTQUFTLFVBQVUsTUFBTSxJQUFJO0dBQzdHLEtBQUssY0FBYyxVQUFVLElBQUk7R0FDakMsS0FBSyxTQUFTLE9BQU8sR0FBRztFQUMxQjtDQUNGOzs7Ozs7Q0FNQSxjQUFjLFVBQVUsU0FBUztFQUMvQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7R0FDeEMsTUFBTSxVQUFVLFNBQVM7R0FDekIsT0FBTyxLQUFLLFNBQVMsUUFBUTtHQUM3QixPQUFPLEtBQUssV0FBVyxRQUFRO0dBQy9CLElBQUksU0FBUyxRQUFRLFFBQVEsSUFBSTtFQUNuQztDQUNGOzs7OztDQUtBLE1BQU0saUJBQWlCO0VBQ3JCLEtBQUssTUFBTSxZQUFZLEtBQUssU0FBUyxPQUFPLEdBQzFDLEtBQUssY0FBYyxVQUFVLG9CQUFvQixLQUFLO0VBRXhELEtBQUssU0FBUyxNQUFNO0NBQ3RCO0FBQ0Y7QUFDQSxJQUFNLGNBQWMsSUFBSSxpQkFBaUI7QUFDekMsdUJBQXVCLFNBQVMsV0FBVzs7O0FDbFMzQyxJQUFNLGNBQU4sTUFBa0I7Q0FDaEIsY0FBYztFQUNaLEtBQUssZUFBZTtFQUNwQixLQUFLLE9BQU87RUFDWixLQUFLLFlBQVk7RUFDakIsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxzQkFBc0IsQ0FBQztFQUM1QixLQUFLLGlCQUFpQixJQUFJLE9BQU87RUFDakMsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssYUFBYTtFQUVsQixLQUFLLG1CQUFtQyx1QkFBTyxPQUFPLElBQUk7RUFDMUQsS0FBSyxhQUFhO0VBQ2xCLEtBQUssU0FBUztFQUVkLEtBQUssOEJBQThCO0dBQUUsTUFBTSxDQUFDO0dBQUcsT0FBTztFQUFFO0VBRXhELEtBQUsscUJBQXFCO0VBQzFCLEtBQUssaUJBQWlCLElBQUksZUFBZTtFQUN6QyxLQUFLLHNCQUFzQixDQUFDOzs7OztFQUs1QixLQUFLLHFCQUFxQjs7Ozs7RUFLMUIsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxlQUFlO0NBQ3RCO0NBQ0EsS0FBSyxNQUFNO0VBQ1QsS0FBSyxPQUFPO0VBQ1osSUFBSSxLQUFLLFdBQVcsS0FBSyxZQUFZLElBQUk7RUFDekMsS0FBSyxZQUFZO0VBQ2pCLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztHQUN4QyxNQUFNLFFBQVEsU0FBUztHQUN2QixNQUFNLGVBQWU7R0FDckIsS0FBSyxTQUFTLEtBQUs7RUFDckI7Q0FDRjtDQUNBLHFCQUFxQixVQUFVLENBQUMsR0FBRztFQUNqQyxLQUFLLGlCQUFpQjtFQUN0QixLQUFLLG9CQUFvQjtFQUN6QixLQUFLLHFCQUFxQjtDQUM1QjtDQUNBLHdCQUF3QjtFQUN0QixLQUFLLG9CQUFvQjtFQUN6QixJQUFJLEtBQUssU0FBUztHQUNoQixZQUFZLGNBQWMsS0FBSyxPQUFPO0dBQ3RDLEtBQUssVUFBVTtFQUNqQjtDQUNGO0NBQ0EscUJBQXFCO0VBQ25CLEtBQUsscUJBQXFCO0VBQzFCLE1BQU0sZUFBZSxLQUFLO0VBQzFCLElBQUksZ0JBQWdCLENBQUMsYUFBYSxvQkFDaEMsYUFBYSxtQkFBbUI7Q0FFcEM7Q0FDQSxRQUFRO0VBQ04sS0FBSyxvQkFBb0IsU0FBUztFQUNsQyxLQUFLLE1BQU0sS0FBSyxLQUFLLGtCQUFrQjtHQUNyQyxNQUFNLGtCQUFrQixLQUFLLGlCQUFpQjtHQUM5QyxnQkFBZ0IsS0FBSyxLQUFLLElBQUk7R0FDOUIsZ0JBQWdCLFFBQVE7RUFDMUI7RUFDQSxLQUFLLDRCQUE0QixRQUFRO0VBQ3pDLEtBQUssNEJBQTRCLEtBQUssS0FBSyxJQUFJO0VBQy9DLEtBQUssT0FBTztFQUNaLEtBQUssYUFBYTtFQUNsQixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLG9CQUFvQixTQUFTO0VBQ2xDLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssc0JBQXNCO0NBQzdCO0NBQ0EsSUFBSSxpQkFBaUI7RUFDbkIsT0FBTyxLQUFLLEtBQUs7Q0FDbkI7Q0FDQSxvQkFBb0Isa0JBQWtCO0VBQ3BDLElBQUksaUJBQWlCLG1CQUNuQixpQkFBaUIsa0JBQWtCLHdCQUF3QixnQkFBZ0I7RUFFN0UsaUJBQWlCLG9CQUFvQjtFQUNyQyxLQUFLLG9CQUFvQixLQUFLLGdCQUFnQjtDQUNoRDtDQUNBLHdCQUF3QixrQkFBa0I7RUFDeEMsTUFBTSxRQUFRLEtBQUssb0JBQW9CLFFBQVEsZ0JBQWdCO0VBQy9ELElBQUksUUFBUSxJQUNWLEtBQUssb0JBQW9CLE9BQU8sT0FBTyxDQUFDO0VBRTFDLGlCQUFpQixvQkFBb0I7Q0FDdkM7Q0FDQSxTQUFTLE9BQU87RUFDZCxLQUFLLHFCQUFxQjtFQUMxQixNQUFNLG9CQUFvQjtFQUMxQixNQUFNLGFBQWE7RUFDbkIsSUFBSSxNQUFNLFdBQVcsS0FBSyxNQUN4QixNQUFNLDJCQUEyQjtPQUVqQyxNQUFNLDJCQUEyQixNQUFNLE9BQU8sMkJBQTJCO0VBRTNFLE1BQU0sWUFBWTtFQUNsQixLQUFLLGNBQWMsS0FBSztFQUN4QixJQUFJLE1BQU0sYUFBYTtHQUNyQixLQUFLLG9CQUFvQixNQUFNLFdBQVc7R0FDMUM7RUFDRjtFQUNBLElBQUksTUFBTSxXQUFXLEtBQUssWUFBWSxLQUFLO0VBQzNDLE1BQU0sV0FBVyxNQUFNO0VBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FDbkMsS0FBSyxTQUFTLFNBQVMsRUFBRTtDQUU3QjtDQUNBLFlBQVksT0FBTztFQUNqQixLQUFLLHFCQUFxQjtFQUMxQixJQUFJLE1BQU0sV0FDSjtPQUFBLENBQUMsTUFBTSxhQUNULEtBQUssZUFBZSxLQUFLO0VBQUE7RUFHN0IsTUFBTSxvQkFBb0I7RUFDMUIsSUFBSSxNQUFNLGFBQWE7R0FDckIsS0FBSyx3QkFBd0IsTUFBTSxXQUFXO0dBQzlDO0VBQ0Y7RUFDQSxNQUFNLFdBQVcsTUFBTTtFQUN2QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQ25DLEtBQUssWUFBWSxTQUFTLEVBQUU7Q0FFaEM7Q0FDQSxlQUFlLFVBQVU7RUFDdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUNuQyxLQUFLLFlBQVksU0FBUyxFQUFFO0NBRWhDO0NBQ0EsY0FBYyxPQUFPO0VBQ25CLElBQUksbUJBQW1CLEtBQUssaUJBQWlCLE1BQU07RUFDbkQsSUFBSSxDQUFDLGtCQUNILG1CQUFtQixLQUFLLGlCQUFpQixNQUFNLDRCQUE0QjtHQUN6RSxPQUFPO0dBQ1AsTUFBTSxDQUFDO0VBQ1Q7RUFFRixpQkFBaUIsS0FBSyxpQkFBaUIsV0FBVztDQUNwRDtDQUNBLGlCQUFpQixZQUFZO0VBQzNCLElBQUksV0FBVyxzQkFBc0IsR0FBRztFQUN4QyxLQUFLLGVBQWUsWUFBWSxXQUFXLGFBQWEsQ0FBQyxpQkFBaUIsVUFBVTtFQUNwRixXQUFXLGdCQUFnQjtDQUM3QjtDQUNBLGtCQUFrQixPQUFPO0VBQ3ZCLEtBQUssNEJBQTRCLEtBQUssS0FBSyw0QkFBNEIsV0FBVztDQUNwRjtDQUNBLElBQUksZUFBZTtFQUNqQixPQUFPLEtBQUssS0FBSyx1QkFBdUIsS0FBSyxLQUFLLGFBQWE7Q0FDakU7Ozs7OztDQU1BLFlBQVksV0FBVztFQUNyQixJQUFJLEtBQUssb0JBQW9CLFFBQVEsU0FBUyxNQUFNLElBQ2xELEtBQUssb0JBQW9CLEtBQUssU0FBUztDQUUzQztDQUNBLGVBQWUsV0FBVztFQUN4QixNQUFNLE1BQU0sS0FBSyxvQkFBb0IsUUFBUSxTQUFTO0VBQ3RELElBQUksUUFBUSxJQUFJLEtBQUssb0JBQW9CLE9BQU8sS0FBSyxDQUFDO0NBQ3hEO0NBQ0EsWUFBWSxVQUFVO0VBQ3BCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLG9CQUFvQixRQUFRLEtBQ25ELEtBQUssb0JBQW9CLEVBQUUsQ0FBQyxVQUFVLFFBQVE7Q0FFbEQ7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxzQkFBc0I7RUFDM0IsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxPQUFPO0VBQ1osS0FBSyw4QkFBOEI7RUFDbkMsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxzQkFBc0I7RUFDM0IsS0FBSyxzQkFBc0I7RUFDM0IsS0FBSyxnQkFBZ0IsUUFBUTtFQUM3QixLQUFLLGlCQUFpQjtDQUN4QjtDQUNBLFlBQVksTUFBTSxDQUFDLEdBQUc7RUFDcEIsTUFBTSxXQUFXLEtBQUssS0FBSztFQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQ25DLEtBQUssYUFBYSxTQUFTLElBQUksR0FBRztFQUVwQyxPQUFPO0NBQ1Q7Q0FDQSxhQUFhLFdBQVcsTUFBTSxDQUFDLEdBQUc7RUFDaEMsSUFBSSxLQUFLLFNBQVM7RUFDbEIsSUFBSSxVQUFVLGFBQWEsT0FBTztFQUNsQyxNQUFNLFdBQVcsVUFBVTtFQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQ25DLEtBQUssYUFBYSxTQUFTLElBQUksR0FBRztFQUVwQyxPQUFPO0NBQ1Q7Q0FDQSxxQkFBcUI7RUFDbkIsS0FBSyxlQUFlO0NBQ3RCOzs7OztDQUtBLElBQUksd0JBQXdCO0VBQzFCLEtBQUssS0FBSyxlQUFlLE9BQU8sR0FBRyxPQUFPLEtBQUs7RUFDL0MsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSywyQkFBMkIsS0FBSyx5QkFBeUIsSUFBSSxPQUFPO0VBQ3pFLE9BQU8sS0FBSyx1QkFBdUIsU0FBUyxLQUFLLGNBQWMsQ0FBQyxDQUFDLE9BQU87Q0FDMUU7Ozs7O0NBS0EsSUFBSSxnQ0FBZ0M7RUFDbEMsS0FBSyxLQUFLLGVBQWUsT0FBTyxHQUFHLE9BQU8sS0FBSztFQUMvQyxLQUFLLGdCQUFnQjtFQUNyQixLQUFLLG1DQUFtQyxLQUFLLGlDQUFpQyxJQUFJLE9BQU87RUFDekYsT0FBTyxLQUFLLCtCQUErQixTQUFTLEtBQUsscUJBQXFCLENBQUMsQ0FBQyxVQUM5RSxDQUFDLEtBQUssZUFBZSxHQUNyQixDQUFDLEtBQUssZUFBZSxDQUN2QjtDQUNGOzs7Ozs7Q0FNQSxJQUFJLGdDQUFnQztFQUNsQyxLQUFLLEtBQUssZUFBZSxPQUFPLEdBQUcsT0FBTyxLQUFLO0VBQy9DLEtBQUssZ0JBQWdCO0VBQ3JCLE1BQU0sdUJBQXVCLEtBQUs7RUFDbEMsSUFBSSxzQkFBc0I7R0FDeEIsS0FBSyxtQ0FBbUMsS0FBSyxpQ0FBaUMsSUFBSSxPQUFPO0dBQ3pGLE9BQU8sS0FBSywrQkFBK0IsU0FBUyxLQUFLLGNBQWMsQ0FBQyxDQUFDLFFBQVEscUJBQXFCLHFCQUFxQixDQUFDLENBQUMsVUFDM0gsQ0FBQyxxQkFBcUIsZUFBZSxHQUNyQyxDQUFDLHFCQUFxQixlQUFlLENBQ3ZDO0VBQ0Y7RUFDQSxPQUFPLEtBQUs7Q0FDZDs7Ozs7OztDQU9BLElBQUksd0JBQXdCO0VBQzFCLElBQUksS0FBSyxtQkFDUCxPQUFPLEtBQUs7RUFFZCxJQUFJLENBQUMsS0FBSyxrQ0FBa0MsT0FBTztFQUNuRCxPQUFPLEtBQUssaUNBQWlDO0NBQy9DO0FBQ0Y7OztBQzNRQSxTQUFTLGlCQUFpQixRQUFRLFNBQVMsU0FBUyxDQUFDLEdBQUc7Q0FDdEQsS0FBSyxNQUFNLE9BQU8sU0FDaEIsSUFBSSxDQUFDLE9BQU8sUUFBUSxRQUFRLFNBQVMsS0FBSyxHQUN4QyxPQUFPLE9BQU8sUUFBUTtBQUc1Qjs7O0FDbUJBLElBQU0sY0FBYyxJQUFJLGdCQUFnQixJQUFJO0FBQzVDLElBQU0sZUFBZSxJQUFJLGdCQUFnQixJQUFJO0FBQzdDLElBQU0sZUFBZSxJQUFJLGdCQUFnQixNQUFNLEdBQUcsQ0FBQztBQUNuRCxJQUFNLGdCQUFnQixJQUFJLGdCQUFnQixJQUFJO0FBQzlDLElBQU0sZUFBZTtBQUNyQixJQUFNLGVBQWU7QUFDckIsSUFBTSxpQkFBaUI7QUFDdkIsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxZQUFOLE1BQU0sa0JBQWtCQyxzQkFBYTtDQUNuQyxZQUFZLFVBQVUsQ0FBQyxHQUFHO0VBQ3hCLE1BQU07Ozs7O0VBS04sS0FBSyxNQUFNLElBQUksWUFBWTs7RUFFM0IsS0FBSyxlQUFlOztFQUdwQixLQUFLLGNBQWM7O0VBR25CLEtBQUssb0JBQW9COztFQUd6QixLQUFLLHlCQUF5Qjs7RUFLOUIsS0FBSyxZQUFZOztFQUdqQixLQUFLLGdCQUFnQjs7RUFJckIsS0FBSywyQkFBMkI7Ozs7Ozs7Ozs7Ozs7OztFQWVoQyxLQUFLLFdBQVcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFvQmpCLEtBQUssU0FBUzs7RUFJZCxLQUFLLGlCQUFpQjs7RUFFdEIsS0FBSyxhQUFhOztFQUVsQixLQUFLLFdBQVc7Ozs7Ozs7RUFPaEIsS0FBSyxvQkFBb0I7O0VBS3pCLEtBQUssYUFBYTs7Ozs7Ozs7Ozs7Ozs7RUFjbEIsS0FBSyxpQkFBaUIsSUFBSSxPQUFPOzs7Ozs7OztFQVFqQyxLQUFLLHlCQUF5QixJQUFJLE9BQU87Ozs7Ozs7OztFQVN6QyxLQUFLLGlCQUFpQixLQUFLOzs7Ozs7Ozs7Ozs7O0VBYTNCLEtBQUssWUFBWTs7Ozs7RUFNakIsS0FBSyxZQUFZLElBQUksZ0JBQWdCLE1BQU0sR0FBRyxDQUFDOzs7OztFQUsvQyxLQUFLLFNBQVM7Ozs7O0VBS2QsS0FBSyxTQUFTOzs7Ozs7RUFNZCxLQUFLLFVBQVU7Ozs7O0VBS2YsS0FBSyxRQUFROzs7Ozs7RUFNYixLQUFLLE1BQU07Ozs7OztFQU1YLEtBQUssTUFBTTs7Ozs7O0VBTVgsS0FBSyxNQUFNOzs7Ozs7RUFNWCxLQUFLLE1BQU07Ozs7O0VBS1gsS0FBSyxZQUFZOztFQUlqQixLQUFLLGFBQWE7O0VBRWxCLEtBQUssYUFBYTs7RUFFbEIsS0FBSyxhQUFhOztFQUdsQixLQUFLLGFBQWE7O0VBR2xCLEtBQUssa0JBQWtCOztFQUl2QixLQUFLLGlCQUFpQjs7RUFFdEIsS0FBSyxpQkFBaUI7Ozs7Ozs7O0VBWXRCLEtBQUsscUJBQXFCOztFQUcxQixLQUFLLHNCQUFzQjs7Ozs7O0VBTTNCLEtBQUssMEJBQTBCOzs7Ozs7RUFNL0IsS0FBSyxxQkFBcUI7Ozs7O0VBSzFCLEtBQUssNkJBQTZCO0VBQ2xDLEtBQUssVUFBVSxDQUFDO0VBQ2hCLGlCQUFpQixNQUFNLFNBQVM7R0FDOUIsVUFBVTtHQUNWLFFBQVE7R0FDUixTQUFTO0VBQ1gsQ0FBQztFQUNELFFBQVEsVUFBVSxTQUFTLFVBQVUsS0FBSyxTQUFTLEtBQUssQ0FBQztFQUN6RCxRQUFRLFFBQVEsU0FBUyxJQUFJO0NBQy9COzs7Ozs7Q0FNQSxPQUFPLE1BQU0sUUFBUTtFQUNuQixZQUFZLFNBQVMscUVBQXFFO0VBQzFGLFdBQVcsTUFBTSxXQUFXLE1BQU07Q0FDcEM7Ozs7OztDQU9BLElBQUksYUFBYSxPQUFPO0VBQ3RCLEtBQUsscUJBQXFCLFNBQVMsS0FBSztFQUN4QyxLQUFLLDBCQUEwQixRQUFRO0NBQ3pDOztDQUVBLElBQUksZUFBZTtFQUNqQixPQUFPLEtBQUssMEJBQTBCLFFBQVEsS0FBSyxxQkFBcUIsU0FBUztDQUNuRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLFNBQVMsR0FBRyxVQUFVO0VBQ3BCLElBQUksQ0FBQyxLQUFLLGVBQ1IsWUFBWSxRQUFRLHFFQUFxRTtFQUUzRixJQUFJLFNBQVMsU0FBUyxHQUFHO0dBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FDbkMsS0FBSyxTQUFTLFNBQVMsRUFBRTtHQUUzQixPQUFPLFNBQVM7RUFDbEI7RUFDQSxNQUFNLFFBQVEsU0FBUztFQUN2QixNQUFNLGNBQWMsS0FBSyxlQUFlLEtBQUs7RUFDN0MsSUFBSSxNQUFNLFdBQVcsTUFBTTtHQUN6QixLQUFLLFNBQVMsT0FBTyxLQUFLLFNBQVMsUUFBUSxLQUFLLEdBQUcsQ0FBQztHQUNwRCxLQUFLLFNBQVMsS0FBSyxLQUFLO0dBQ3hCLElBQUksYUFDRixZQUFZLHFCQUFxQjtHQUVuQyxPQUFPO0VBQ1Q7RUFDQSxJQUFJLE1BQU0sUUFDUixNQUFNLE9BQU8sWUFBWSxLQUFLO0VBRWhDLEtBQUssU0FBUyxLQUFLLEtBQUs7RUFDeEIsSUFBSSxLQUFLLGtCQUFrQixLQUFLLFlBQVk7RUFDNUMsTUFBTSxTQUFTO0VBQ2YsTUFBTSxZQUFZO0VBQ2xCLE1BQU0sZUFBZTtFQUNyQixJQUFJLGFBQ0YsWUFBWSxTQUFTLEtBQUs7RUFFNUIsS0FBSyxLQUFLLGNBQWMsT0FBTyxNQUFNLEtBQUssU0FBUyxTQUFTLENBQUM7RUFDN0QsTUFBTSxLQUFLLFNBQVMsSUFBSTtFQUN4QixLQUFLO0VBQ0wsSUFBSSxNQUFNLFlBQVksR0FDcEIsTUFBTSxxQkFBcUI7RUFFN0IsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsWUFBWSxHQUFHLFVBQVU7RUFDdkIsSUFBSSxTQUFTLFNBQVMsR0FBRztHQUN2QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQ25DLEtBQUssWUFBWSxTQUFTLEVBQUU7R0FFOUIsT0FBTyxTQUFTO0VBQ2xCO0VBQ0EsTUFBTSxRQUFRLFNBQVM7RUFDdkIsTUFBTSxRQUFRLEtBQUssU0FBUyxRQUFRLEtBQUs7RUFDekMsSUFBSSxRQUFRLElBQUk7R0FDZCxLQUFLO0dBQ0wsS0FBSyxTQUFTLE9BQU8sT0FBTyxDQUFDO0dBQzdCLElBQUksS0FBSyxhQUNQLEtBQUssWUFBWSxZQUFZLEtBQUs7UUFDN0IsSUFBSSxLQUFLLG1CQUNkLEtBQUssa0JBQWtCLFlBQVksS0FBSztHQUUxQyxJQUFJLE1BQU0sbUJBQ1IsTUFBTSxrQkFBa0IsT0FBTyxLQUFLO0dBRXRDLE1BQU0sU0FBUztHQUNmLEtBQUssS0FBSyxnQkFBZ0IsT0FBTyxNQUFNLEtBQUs7R0FDNUMsTUFBTSxLQUFLLFdBQVcsSUFBSTtFQUM1QjtFQUNBLE9BQU87Q0FDVDs7Q0FFQSxVQUFVLE9BQU87RUFDZixJQUFJLE9BQ0U7T0FBQSxVQUFVLEtBQUssT0FDakIsS0FBSyxZQUFZO0VBQUE7RUFHckIsS0FBSztFQUNMLElBQUksS0FBSyxXQUFXO0VBQ3BCLEtBQUssWUFBWTtFQUNqQixJQUFJLEtBQUssbUJBQ1AsS0FBSyxrQkFBa0IsY0FBYyxJQUFJO0NBRTdDO0NBQ0EsSUFBSSxjQUFjLE9BQU87RUFDdkIsSUFBSSxDQUFDLENBQUMsS0FBSyxnQkFBZ0IsT0FBTztFQUNsQyxJQUFJLE9BQ0YsS0FBSyxrQkFBa0I7T0FFdkIsS0FBSyxtQkFBbUI7Q0FFNUI7Ozs7OztDQU1BLElBQUksZ0JBQWdCO0VBQ2xCLE9BQU8sQ0FBQyxDQUFDLEtBQUs7Q0FDaEI7Ozs7Ozs7Q0FPQSxvQkFBb0I7RUFDbEIsSUFBSSxLQUFLLGFBQWE7RUFDdEIsTUFBTSxvQkFBb0IsS0FBSztFQUMvQixtQkFBbUIsWUFBWSxJQUFJO0VBQ25DLEtBQUssY0FBYyxRQUFRLElBQUksYUFBYSxJQUFJO0VBQ2hELEtBQUssaUJBQWlCLE9BQU87RUFDN0IsbUJBQW1CLFNBQVMsSUFBSTtFQUNoQyxLQUFLLGdCQUFnQjtDQUN2Qjs7Ozs7Q0FLQSxxQkFBcUI7RUFDbkIsSUFBSSxDQUFDLEtBQUssYUFBYTtFQUN2QixNQUFNLG9CQUFvQixLQUFLO0VBQy9CLG1CQUFtQixZQUFZLElBQUk7RUFDbkMsUUFBUSxPQUFPLEtBQUssV0FBVztFQUMvQixLQUFLLGNBQWM7RUFDbkIsS0FBSyxpQkFBaUIsS0FBSztFQUMzQixtQkFBbUIsU0FBUyxJQUFJO0VBQ2hDLEtBQUssZ0JBQWdCO0NBQ3ZCOztDQUVBLGtCQUFrQjtFQUNoQixLQUFLLFdBQVcsQ0FBQyxLQUFLLGVBQWUsS0FBSyxRQUFRLFdBQVc7Q0FDL0Q7Ozs7Ozs7Ozs7Ozs7O0NBY0EsSUFBSSxpQkFBaUI7RUFDbkIsS0FBSyxvQkFBb0IsS0FBSyxrQkFBa0IsSUFBSSxPQUFPO0VBQzNELElBQUksS0FBSyxhQUNQLEtBQUssZ0JBQWdCLFNBQVMsS0FBSyxZQUFZLGNBQWM7T0FDeEQsSUFBSSxLQUFLLG1CQUNkLEtBQUssZ0JBQWdCLFdBQVcsS0FBSyx3QkFBd0IsS0FBSyxrQkFBa0IsY0FBYztFQUVwRyxPQUFPLEtBQUs7Q0FDZDs7Ozs7Ozs7Ozs7Q0FXQSxJQUFJLElBQUk7RUFDTixPQUFPLEtBQUssVUFBVTtDQUN4QjtDQUNBLElBQUksRUFBRSxPQUFPO0VBQ1gsS0FBSyxVQUFVLElBQUk7Q0FDckI7Ozs7Ozs7Ozs7O0NBV0EsSUFBSSxJQUFJO0VBQ04sT0FBTyxLQUFLLFVBQVU7Q0FDeEI7Q0FDQSxJQUFJLEVBQUUsT0FBTztFQUNYLEtBQUssVUFBVSxJQUFJO0NBQ3JCOzs7Ozs7Ozs7Ozs7O0NBYUEsSUFBSSxXQUFXO0VBQ2IsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFNBQVMsT0FBTztFQUNsQixLQUFLLFVBQVUsU0FBUyxLQUFLO0NBQy9COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3QkEsSUFBSSxXQUFXO0VBQ2IsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFNBQVMsT0FBTztFQUNsQixJQUFJLEtBQUssY0FBYyxPQUFPO0dBQzVCLEtBQUssWUFBWTtHQUNqQixLQUFLLFVBQVUsS0FBSyxLQUFLO0VBQzNCO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLElBQUksUUFBUTtFQUNWLE9BQU8sS0FBSyxXQUFXO0NBQ3pCO0NBQ0EsSUFBSSxNQUFNLE9BQU87RUFDZixLQUFLLFdBQVcsUUFBUTtDQUMxQjs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxJQUFJLFFBQVE7RUFDVixJQUFJLEtBQUssV0FBVyxjQUNsQixLQUFLLFNBQVMsSUFBSSxnQkFBZ0IsTUFBTSxHQUFHLENBQUM7RUFFOUMsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLE1BQU0sT0FBTztFQUNmLElBQUksS0FBSyxXQUFXLGNBQWM7R0FDaEMsS0FBSyxTQUFTLElBQUksZ0JBQWdCLE1BQU0sR0FBRyxDQUFDO0dBQzVDLElBQUksS0FBSyxZQUFZLGVBQ25CLEtBQUssbUlBQW1JO0VBRTVJO0VBQ0EsT0FBTyxVQUFVLFdBQVcsS0FBSyxPQUFPLElBQUksS0FBSyxJQUFJLEtBQUssT0FBTyxTQUFTLEtBQUs7Q0FDakY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQThCQSxJQUFJLE9BQU87RUFDVCxJQUFJLEtBQUssVUFBVSxhQUNqQixLQUFLLFFBQVEsSUFBSSxnQkFBZ0IsTUFBTSxHQUFHLENBQUM7RUFFN0MsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLEtBQUssT0FBTztFQUNkLElBQUksS0FBSyxVQUFVLGFBQ2pCLEtBQUssUUFBUSxJQUFJLGdCQUFnQixNQUFNLEdBQUcsQ0FBQztFQUU3QyxLQUFLLE1BQU0sU0FBUyxLQUFLO0NBQzNCOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLElBQUksUUFBUTtFQUNWLElBQUksS0FBSyxXQUFXLGNBQ2xCLEtBQUssU0FBUyxJQUFJLGdCQUFnQixNQUFNLEdBQUcsQ0FBQztFQUU5QyxPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksTUFBTSxPQUFPO0VBQ2YsSUFBSSxLQUFLLFdBQVcsY0FDbEIsS0FBSyxTQUFTLElBQUksZ0JBQWdCLE1BQU0sR0FBRyxDQUFDO0VBRTlDLElBQUksT0FBTyxVQUFVLFVBQ25CLFFBQVEsV0FBVyxLQUFLO0VBRTFCLE9BQU8sVUFBVSxXQUFXLEtBQUssT0FBTyxJQUFJLEtBQUssSUFBSSxLQUFLLE9BQU8sU0FBUyxLQUFLO0NBQ2pGOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxJQUFJLFNBQVM7RUFDWCxJQUFJLEtBQUssWUFBWSxlQUNuQixLQUFLLFVBQVUsSUFBSSxnQkFBZ0IsTUFBTSxHQUFHLENBQUM7RUFFL0MsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLE9BQU8sT0FBTztFQUNoQixJQUFJLEtBQUssWUFBWSxlQUFlO0dBQ2xDLEtBQUssVUFBVSxJQUFJLGdCQUFnQixNQUFNLEdBQUcsQ0FBQztHQUM3QyxJQUFJLEtBQUssV0FBVyxjQUNsQixLQUFLLG1JQUFtSTtFQUU1STtFQUNBLE9BQU8sVUFBVSxXQUFXLEtBQUssUUFBUSxJQUFJLEtBQUssSUFBSSxLQUFLLFFBQVEsU0FBUyxLQUFLO0NBQ25GOzs7Ozs7Ozs7Ozs7OztDQWNBLElBQUksUUFBUTtFQUNWLE9BQU8sS0FBSyxJQUFJLEtBQUssTUFBTSxJQUFJLEtBQUssZUFBZSxDQUFDLENBQUMsS0FBSztDQUM1RDtDQUNBLElBQUksTUFBTSxPQUFPO0VBQ2YsTUFBTSxhQUFhLEtBQUssZUFBZSxDQUFDLENBQUM7RUFDekMsS0FBSyxVQUFVLE9BQU8sVUFBVTtDQUNsQzs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUssSUFBSSxLQUFLLE1BQU0sSUFBSSxLQUFLLGVBQWUsQ0FBQyxDQUFDLE1BQU07Q0FDN0Q7Q0FDQSxJQUFJLE9BQU8sT0FBTztFQUNoQixNQUFNLGNBQWMsS0FBSyxlQUFlLENBQUMsQ0FBQztFQUMxQyxLQUFLLFdBQVcsT0FBTyxXQUFXO0NBQ3BDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsUUFBUSxLQUFLO0VBQ1gsSUFBSSxDQUFDLEtBQ0gsTUFBTSxDQUFDO0VBRVQsTUFBTSxTQUFTLEtBQUssZUFBZTtFQUNuQyxJQUFJLFFBQVEsS0FBSyxJQUFJLEtBQUssTUFBTSxJQUFJLE9BQU8sS0FBSztFQUNoRCxJQUFJLFNBQVMsS0FBSyxJQUFJLEtBQUssTUFBTSxJQUFJLE9BQU8sTUFBTTtFQUNsRCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7OztDQWVBLFFBQVEsT0FBTyxRQUFRO0VBQ3JCLE1BQU0sT0FBTyxLQUFLLGVBQWU7RUFDakMsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM3QixTQUFTLE1BQU0sVUFBVSxNQUFNO0dBQy9CLFFBQVEsTUFBTTtFQUNoQixPQUNFLFdBQVcsU0FBUztFQUV0QixVQUFVLEtBQUssS0FBSyxLQUFLLFVBQVUsT0FBTyxLQUFLLEtBQUs7RUFDcEQsV0FBVyxLQUFLLEtBQUssS0FBSyxXQUFXLFFBQVEsS0FBSyxNQUFNO0NBQzFEOztDQUVBLGNBQWM7RUFDWixNQUFNLFdBQVcsS0FBSztFQUN0QixNQUFNLE9BQU8sS0FBSztFQUNsQixLQUFLLE1BQU0sS0FBSyxJQUFJLFdBQVcsS0FBSyxFQUFFO0VBQ3RDLEtBQUssTUFBTSxLQUFLLElBQUksV0FBVyxLQUFLLEVBQUU7RUFDdEMsS0FBSyxNQUFNLENBQUMsS0FBSyxJQUFJLFdBQVcsS0FBSyxFQUFFO0VBQ3ZDLEtBQUssTUFBTSxLQUFLLElBQUksV0FBVyxLQUFLLEVBQUU7Q0FDeEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTBDQSxnQkFBZ0IsTUFBTTtFQUNwQixLQUFLLFNBQVMsSUFDWixPQUFPLEtBQUssTUFBTSxXQUFXLEtBQUssSUFBSSxLQUFLLFNBQVMsR0FDcEQsT0FBTyxLQUFLLE1BQU0sV0FBVyxLQUFLLElBQUksS0FBSyxTQUFTLENBQ3REO0VBQ0EsS0FBSyxNQUFNLElBQ1QsT0FBTyxLQUFLLFdBQVcsV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNLEdBQzNELE9BQU8sS0FBSyxXQUFXLFdBQVcsS0FBSyxTQUFTLEtBQUssTUFBTSxDQUM3RDtFQUNBLEtBQUssV0FBVyxPQUFPLEtBQUssYUFBYSxXQUFXLEtBQUssV0FBVyxLQUFLO0VBQ3pFLEtBQUssS0FBSyxJQUNSLE9BQU8sS0FBSyxVQUFVLFdBQVcsS0FBSyxRQUFRLEtBQUssS0FBSyxHQUN4RCxPQUFPLEtBQUssVUFBVSxXQUFXLEtBQUssUUFBUSxLQUFLLEtBQUssQ0FDMUQ7RUFDQSxLQUFLLE1BQU0sSUFDVCxPQUFPLEtBQUssV0FBVyxXQUFXLEtBQUssU0FBUyxLQUFLLE1BQU0sR0FDM0QsT0FBTyxLQUFLLFdBQVcsV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNLENBQzdEO0VBQ0EsS0FBSyxPQUFPLElBQ1YsT0FBTyxLQUFLLFlBQVksV0FBVyxLQUFLLFVBQVUsS0FBSyxPQUFPLEdBQzlELE9BQU8sS0FBSyxZQUFZLFdBQVcsS0FBSyxVQUFVLEtBQUssT0FBTyxDQUNoRTtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTRCQSxjQUFjLFFBQVE7RUFDcEIsT0FBTyxVQUFVLElBQUk7Q0FDdkI7O0NBRUEsdUJBQXVCO0VBQ3JCLE1BQU0seUJBQXlCLEtBQUs7RUFDcEMsSUFBSSxLQUFLLCtCQUErQix3QkFBd0I7RUFDaEUsS0FBSyw2QkFBNkI7RUFDbEMsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsTUFBTSxTQUFTLEtBQUs7RUFDcEIsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxLQUFLLE1BQU07RUFDakIsTUFBTSxLQUFLLE1BQU07RUFDakIsTUFBTSxLQUFLLE1BQU07RUFDakIsTUFBTSxLQUFLLE1BQU07RUFDakIsTUFBTSxLQUFLLENBQUMsT0FBTztFQUNuQixNQUFNLEtBQUssQ0FBQyxPQUFPO0VBQ25CLEdBQUcsSUFBSSxLQUFLLE1BQU07RUFDbEIsR0FBRyxJQUFJLEtBQUssTUFBTTtFQUNsQixHQUFHLElBQUksS0FBSyxNQUFNO0VBQ2xCLEdBQUcsSUFBSSxLQUFLLE1BQU07RUFDbEIsR0FBRyxLQUFLLFNBQVMsTUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUcsTUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUcsS0FBSztFQUMxRSxHQUFHLEtBQUssU0FBUyxNQUFNLEtBQUssR0FBRyxJQUFJLEtBQUssR0FBRyxNQUFNLEtBQUssR0FBRyxJQUFJLEtBQUssR0FBRyxLQUFLO0NBQzVFO0NBRUEsSUFBSSxNQUFNLE9BQU87RUFDZixJQUFJLFVBQVUsS0FBSyxZQUFZO0VBQy9CLEtBQUssYUFBYTtFQUNsQixLQUFLLGdCQUFBO0VBQ0wsS0FBSyxVQUFVO0NBQ2pCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9CQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksS0FBSyxPQUFPO0VBRWQsTUFBTSxNQURZLE1BQU0sT0FBTyxTQUFTLFNBQVMsUUFDN0IsQ0FBQyxDQUFDLFlBQVk7RUFDbEMsSUFBSSxRQUFRLEtBQUssWUFBWTtFQUM3QixLQUFLLGFBQWE7RUFDbEIsS0FBSyxnQkFBQTtFQUNMLEtBQUssVUFBVTtDQUNqQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLElBQUksT0FBTztFQUNULE9BQU8sUUFBUSxLQUFLLFVBQVU7Q0FDaEM7Q0FFQSxJQUFJLFVBQVUsT0FBTztFQUNuQixJQUFJLEtBQUssbUJBQW1CLE9BQU87RUFDbkMsSUFBSSxLQUFLLG1CQUNQLEtBQUssa0JBQWtCLHFCQUFxQjtFQUU5QyxLQUFLLGdCQUFBO0VBQ0wsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxVQUFVO0NBQ2pCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9CQSxJQUFJLFlBQVk7RUFDZCxPQUFPLEtBQUs7Q0FDZDs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxJQUFJLFVBQVU7RUFDWixPQUFPLENBQUMsRUFBRSxLQUFLLHFCQUFxQjtDQUN0QztDQUNBLElBQUksUUFBUSxPQUFPO0VBQ2pCLE1BQU0sY0FBYyxRQUFRLElBQUk7RUFDaEMsS0FBSyxLQUFLLHFCQUFxQixPQUFPLGFBQWE7RUFDbkQsSUFBSSxLQUFLLG1CQUNQLEtBQUssa0JBQWtCLHFCQUFxQjtFQUU5QyxLQUFLLGdCQUFBO0VBQ0wsS0FBSyxzQkFBc0I7RUFDM0IsS0FBSyxVQUFVO0VBQ2YsS0FBSyxLQUFLLGtCQUFrQixLQUFLO0NBQ25DOztDQUVBLElBQUksU0FBUztFQUNYLE9BQU8sRUFBRSxLQUFLLHFCQUFxQjtDQUNyQzs7Q0FFQSxJQUFJLE9BQU8sT0FBTztFQUNoQixNQUFNLGNBQWMsUUFBUSxJQUFJO0VBQ2hDLEtBQUssS0FBSyxxQkFBcUIsT0FBTyxhQUFhO0VBQ25ELElBQUksS0FBSyxtQkFDUCxLQUFLLGtCQUFrQixxQkFBcUI7RUFFOUMsS0FBSyxnQkFBQTtFQUNMLEtBQUssc0JBQXNCO0VBQzNCLEtBQUssVUFBVTtDQUNqQjs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsSUFBSSxhQUFhO0VBQ2YsT0FBTyxDQUFDLEVBQUUsS0FBSyxxQkFBcUI7Q0FDdEM7Q0FDQSxJQUFJLFdBQVcsT0FBTztFQUNwQixNQUFNLGNBQWMsUUFBUSxJQUFJO0VBQ2hDLEtBQUssS0FBSyxxQkFBcUIsT0FBTyxhQUFhO0VBQ25ELEtBQUssZ0JBQUE7RUFDTCxLQUFLLHNCQUFzQjtFQUMzQixJQUFJLEtBQUssbUJBQ1AsS0FBSyxrQkFBa0IscUJBQXFCO0VBRTlDLEtBQUssVUFBVTtDQUNqQjs7Ozs7Q0FLQSxJQUFJLGVBQWU7RUFDakIsT0FBTyxLQUFLLHVCQUF1QixLQUFLLEtBQUssYUFBYTtDQUM1RDs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxRQUFRLFVBQVUsT0FBTztFQUN2QixJQUFJLEtBQUssV0FBVztFQUNwQixLQUFLLFlBQVk7RUFDakIsSUFBSTtFQUNKLElBQUksS0FBSyxTQUFTLFFBQ2hCLGNBQWMsS0FBSyxlQUFlLEdBQUcsS0FBSyxTQUFTLE1BQU07RUFFM0QsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxjQUFjO0VBQ25CLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssVUFBVTtFQUNmLEtBQUssWUFBWTtFQUNqQixLQUFLLFNBQVM7RUFDZCxLQUFLLFNBQVM7RUFDZCxLQUFLLFVBQVU7RUFDZixLQUFLLFFBQVE7RUFDYixLQUFLLEtBQUssYUFBYSxJQUFJO0VBQzNCLEtBQUssbUJBQW1CO0VBRXhCLEtBRHdCLE9BQU8sWUFBWSxZQUFZLFVBQVUsU0FBUyxhQUNuRCxhQUNyQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxRQUFRLEVBQUUsR0FDeEMsWUFBWSxFQUFFLENBQUMsUUFBUSxPQUFPO0VBR2xDLEtBQUssYUFBYSxRQUFRO0VBQzFCLEtBQUssY0FBYztDQUNyQjtBQUNGO0FBQ0EsV0FBVyxNQUNULFdBQ0EscUJBQ0EsMEJBQ0Esb0JBQ0EsZUFDQSxjQUNBLGNBQ0EsV0FDQSxXQUNBLGNBQ0EscUJBQ0EsZ0JBQ0EsdUJBQ0Y7OztBQ25wQ0EsSUFBTSxnQkFBTixjQUE0QixVQUFVO0NBQ3BDLFlBQVksU0FBUztFQUNuQixNQUFNLE9BQU87O0VBRWIsS0FBSyxZQUFZOztFQUVqQixLQUFLLGdCQUFnQjs7RUFFckIsS0FBSyxlQUFlOztFQUVwQixLQUFLLFlBQVk7O0VBRWpCLEtBQUssV0FBMkIsdUJBQU8sT0FBTyxJQUFJOztFQUVsRCxLQUFLLHFCQUFxQjs7RUFFMUIsS0FBSyxjQUFjO0VBQ25CLEtBQUssVUFBVSxJQUFJLE9BQU8sR0FBRyxHQUFHLEdBQUcsQ0FBQztFQUNwQyxLQUFLLGVBQWU7RUFDcEIsS0FBSyxxQkFBcUIsUUFBUSxzQkFBc0I7Q0FDMUQ7Ozs7Ozs7Ozs7Ozs7O0NBY0EsSUFBSSxTQUFTO0VBQ1gsSUFBSSxDQUFDLEtBQUssY0FBYyxPQUFPLEtBQUs7RUFDcEMsS0FBSyxhQUFhO0VBQ2xCLEtBQUssZUFBZTtFQUNwQixPQUFPLEtBQUs7Q0FDZDs7Ozs7Ozs7OztDQVVBLElBQUksY0FBYztFQUNoQixPQUFPLENBQUMsQ0FBQyxLQUFLO0NBQ2hCO0NBQ0EsSUFBSSxZQUFZLE9BQU87RUFDckIsS0FBSyxlQUFlLFFBQVEsSUFBSTtDQUNsQzs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxjQUFjLE9BQU87RUFDbkIsTUFBTSxTQUFTLEtBQUs7RUFDcEIsTUFBTSxFQUFFLEdBQUcsTUFBTTtFQUNqQixPQUFPLEtBQUssT0FBTyxRQUFRLEtBQUssT0FBTyxRQUFRLEtBQUssT0FBTyxRQUFRLEtBQUssT0FBTztDQUNqRjs7Q0FFQSxlQUFlO0VBQ2IsS0FBSztFQUNMLEtBQUssZUFBZTtFQUNwQixJQUFJLEtBQUssZUFBZTtFQUN4QixLQUFLLGdCQUFnQjtFQUNyQixNQUFNLGNBQWMsS0FBSyxlQUFlLEtBQUs7RUFDN0MsSUFBSSxhQUNGLFlBQVksa0JBQWtCLElBQUk7Q0FFdEM7O0NBRUEsU0FBUztFQUNQLEtBQUssS0FBSyxVQUFVLElBQUk7RUFDeEIsS0FBSyxNQUFNLE9BQU8sS0FBSyxVQUNyQixLQUFLLFNBQVMsSUFBSSxFQUFFLFFBQVE7RUFFOUIsS0FBSyxXQUEyQix1QkFBTyxPQUFPLElBQUk7RUFDbEQsS0FBSyxhQUFhO0NBQ3BCO0NBQ0EsUUFBUSxTQUFTO0VBQ2YsS0FBSyxPQUFPO0VBQ1osTUFBTSxRQUFRLE9BQU87RUFDckIsS0FBSyxVQUFVO0NBQ2pCOzs7Ozs7OztDQVFBLHlCQUF5QixnQkFBZ0IsVUFBVSxjQUFjO0VBQy9ELE1BQU0sRUFBRSxnQkFBZ0I7RUFDeEIsWUFBWSxVQUFVLGNBQWMsTUFBTSxLQUFLLGdCQUFnQixjQUFjO0VBRTdFLE1BQU0sT0FBT0MsWUFBRyxLQUFLO0VBQ3JCLElBQUksTUFBTSxlQUNSLEtBQUssY0FBYyxNQUFNLGNBQWM7RUFFekMsS0FBSyxnQkFBZ0I7RUFDckIsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxTQUFTLFNBQVM7RUFDeEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FDMUIsU0FBUyxFQUFFLENBQUMsbUJBQW1CLGdCQUFnQixVQUFVLFlBQVk7RUFFdkUsWUFBWSxVQUFVLGFBQWEsY0FBYztDQUNuRDtBQUNGOzs7QUN4SEEsSUFBTSxTQUFOLE1BQU0sZUFBZSxjQUFjOzs7O0NBSWpDLFlBQVksVUFBVSxRQUFRLE9BQU87RUFDbkMsSUFBSSxtQkFBbUIsU0FDckIsVUFBVSxFQUFFLFNBQVMsUUFBUTtFQUUvQixNQUFNLEVBQUUsVUFBVSxRQUFRLE9BQU8sUUFBUSxhQUFhLE9BQU8sUUFBUSxHQUFHLFNBQVM7RUFDakYsTUFBTTtHQUNKLE9BQU87R0FDUCxHQUFHO0VBQ0wsQ0FBQzs7RUFFRCxLQUFLLGVBQWU7O0VBRXBCLEtBQUssVUFBVTtFQUNmLEtBQUssZ0JBQWdCO0dBQUUsTUFBTTtHQUFHLE1BQU07R0FBRyxNQUFNO0dBQUcsTUFBTTtFQUFFO0VBQzFELEtBQUssVUFBVSxJQUFJLGdCQUNqQixFQUNFLGlCQUFpQjtHQUNmLEtBQUssYUFBYTtFQUNwQixFQUNGLENBQ0Y7RUFDQSxJQUFJLFFBQ0YsS0FBSyxTQUFTO09BQ1QsSUFBSSxRQUFRLGVBQ2pCLEtBQUssU0FBUyxRQUFRO0VBRXhCLEtBQUssVUFBVTtFQUNmLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssY0FBYyxlQUFlO0VBQ2xDLElBQUksVUFBVSxLQUFLLEdBQUcsS0FBSyxRQUFRO0VBQ25DLElBQUksV0FBVyxLQUFLLEdBQUcsS0FBSyxTQUFTO0NBQ3ZDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXVCQSxPQUFPLEtBQUssUUFBUSxZQUFZLE9BQU87RUFDckMsSUFBSSxrQkFBa0IsU0FDcEIsT0FBTyxJQUFJLE9BQU8sTUFBTTtFQUUxQixPQUFPLElBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxTQUFTLENBQUM7Q0FDbkQ7Q0FDQSxJQUFJLFFBQVEsT0FBTztFQUNqQixVQUFVLFFBQVEsUUFBUTtFQUMxQixNQUFNLGlCQUFpQixLQUFLO0VBQzVCLElBQUksbUJBQW1CLE9BQU87RUFDOUIsSUFBSSxrQkFBa0IsZUFBZSxTQUFTLGVBQWUsSUFBSSxVQUFVLEtBQUssY0FBYyxJQUFJO0VBQ2xHLElBQUksTUFBTSxTQUFTLE1BQU0sR0FBRyxVQUFVLEtBQUssY0FBYyxJQUFJO0VBQzdELEtBQUssV0FBVztFQUNoQixJQUFJLEtBQUssUUFDUCxLQUFLLFVBQVUsS0FBSyxRQUFRLEtBQUssU0FBUyxLQUFLLEtBQUs7RUFFdEQsSUFBSSxLQUFLLFNBQ1AsS0FBSyxXQUFXLEtBQUssU0FBUyxLQUFLLFNBQVMsS0FBSyxNQUFNO0VBRXpELEtBQUssYUFBYTtDQUNwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBd0JBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSztDQUNkOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLElBQUksZUFBZTtFQUNqQixpQkFBaUIsS0FBSyxlQUFlLEtBQUssU0FBUyxLQUFLLFFBQVE7RUFDaEUsT0FBTyxLQUFLO0NBQ2Q7Ozs7O0NBS0EsSUFBSSxlQUFlO0VBQ2pCLFlBQVksU0FBUyw4REFBOEQ7RUFDbkYsT0FBTyxLQUFLO0NBQ2Q7O0NBRUEsZUFBZTtFQUNiLE1BQU0sU0FBUyxLQUFLO0VBQ3BCLE1BQU0sVUFBVSxLQUFLO0VBQ3JCLE1BQU0sU0FBUyxLQUFLO0VBQ3BCLE1BQU0sRUFBRSxPQUFPLFdBQVcsUUFBUTtFQUNsQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLEtBQUs7RUFDM0IsT0FBTyxPQUFPLE9BQU8sT0FBTztFQUM1QixPQUFPLE9BQU8sQ0FBQyxPQUFPLEtBQUs7RUFDM0IsT0FBTyxPQUFPLE9BQU8sT0FBTztDQUM5Qjs7Ozs7Ozs7OztDQVVBLFFBQVEsVUFBVSxPQUFPO0VBQ3ZCLE1BQU0sUUFBUSxPQUFPO0VBRXJCLElBRHVCLE9BQU8sWUFBWSxZQUFZLFVBQVUsU0FBUyxTQUNyRDtHQUNsQixNQUFNLHVCQUF1QixPQUFPLFlBQVksWUFBWSxVQUFVLFNBQVM7R0FDL0UsS0FBSyxTQUFTLFFBQVEsb0JBQW9CO0VBQzVDO0VBQ0EsS0FBSyxXQUFXO0VBQ2hCLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssVUFBVTtFQUNmLEtBQUssVUFBVTtDQUNqQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtDQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksT0FBTyxPQUFPO0VBQ2hCLE9BQU8sVUFBVSxXQUFXLEtBQUssUUFBUSxJQUFJLEtBQUssSUFBSSxLQUFLLFFBQVEsU0FBUyxLQUFLO0NBQ25GOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLElBQUksS0FBSyxNQUFNLENBQUMsSUFBSSxLQUFLLFNBQVMsS0FBSztDQUNyRDtDQUNBLElBQUksTUFBTSxPQUFPO0VBQ2YsS0FBSyxVQUFVLE9BQU8sS0FBSyxTQUFTLEtBQUssS0FBSztFQUM5QyxLQUFLLFNBQVM7Q0FDaEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUssSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFJLEtBQUssU0FBUyxLQUFLO0NBQ3JEO0NBQ0EsSUFBSSxPQUFPLE9BQU87RUFDaEIsS0FBSyxXQUFXLE9BQU8sS0FBSyxTQUFTLEtBQUssTUFBTTtFQUNoRCxLQUFLLFVBQVU7Q0FDakI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCQSxRQUFRLEtBQUs7RUFDWCxRQUFRLE1BQU0sQ0FBQztFQUNmLElBQUksUUFBUSxLQUFLLElBQUksS0FBSyxNQUFNLENBQUMsSUFBSSxLQUFLLFNBQVMsS0FBSztFQUN4RCxJQUFJLFNBQVMsS0FBSyxJQUFJLEtBQUssTUFBTSxDQUFDLElBQUksS0FBSyxTQUFTLEtBQUs7RUFDekQsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBK0JBLFFBQVEsT0FBTyxRQUFRO0VBQ3JCLElBQUksT0FBTyxVQUFVLFVBQVU7R0FDN0IsU0FBUyxNQUFNLFVBQVUsTUFBTTtHQUMvQixRQUFRLE1BQU07RUFDaEIsT0FDRSxXQUFXLFNBQVM7RUFFdEIsVUFBVSxLQUFLLEtBQUssS0FBSyxVQUFVLE9BQU8sS0FBSyxTQUFTLEtBQUssS0FBSztFQUNsRSxXQUFXLEtBQUssS0FBSyxLQUFLLFdBQVcsUUFBUSxLQUFLLFNBQVMsS0FBSyxNQUFNO0NBQ3hFO0FBQ0Y7OztBQ3JVQSxJQUFNLGVBQU4sY0FBMkIsY0FBYztDQUN2QyxZQUFZLFNBQVM7RUFDbkIsSUFBSSxDQUFDLFFBQVEsVUFDWCxRQUFRLFdBQVcsV0FBVyxJQUFJLENBQUMsQ0FBQyxhQUFhO0VBRW5ELElBQUksQ0FBQyxRQUFRLE9BQU87R0FDbEIsUUFBUSxRQUFRLFFBQVEsU0FBUztHQUNqQyxJQUFJLENBQUMsUUFBUSxhQUNYLFFBQVEsU0FBUyxRQUFRO0VBRTdCO0VBQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUTtHQUNuQixRQUFRLFNBQVMsUUFBUSxTQUFTO0dBQ2xDLElBQUksQ0FBQyxRQUFRLGFBQ1gsUUFBUSxVQUFVLFFBQVE7RUFFOUI7RUFDQSxNQUFNLE9BQU87RUFDYixLQUFLLGlCQUFpQjtFQUN0QixLQUFLLGNBQWMsUUFBUTtFQUMzQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxjQUFjLENBQUMsQ0FBQyxRQUFRO0NBQy9CO0NBQ0EsZUFBZTtFQUNiLElBQUksS0FBSyxlQUFlLFdBQVcsS0FBSyxVQUFVO0dBQ2hELEtBQUssU0FBUyxNQUFNLFFBQVEsR0FBRyxLQUFLLE1BQU07R0FDMUMsS0FBSyxTQUFTLE1BQU0sU0FBUyxHQUFHLEtBQUssT0FBTztFQUM5QztFQUNBLElBQUksS0FBSyxTQUFTLFVBQVUsS0FBSyxjQUFjLEtBQUssU0FBUyxXQUFXLEtBQUssYUFBYTtHQUN4RixLQUFLLFNBQVMsUUFBUSxLQUFLO0dBQzNCLEtBQUssU0FBUyxTQUFTLEtBQUs7RUFDOUI7Q0FDRjtDQUNBLE9BQU8sUUFBUSxLQUFLLE9BQU8sU0FBUyxLQUFLLFFBQVEsYUFBYSxLQUFLLGFBQWE7RUFDOUUsTUFBTSxZQUFZLE1BQU0sT0FBTyxPQUFPLFFBQVEsVUFBVTtFQUN4RCxJQUFJLFdBQ0YsS0FBSyxhQUFhO0VBRXBCLE9BQU87Q0FDVDtDQUNBLE9BQU8sS0FBSyxVQUFVO0VBQ3BCLE9BQU8sV0FBVyxxQkFBcUIsb0JBQW9CLHFCQUFxQixXQUFXLG1CQUFtQixvQkFBb0I7Q0FDcEk7Ozs7OztDQU1BLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSyxlQUFlLEtBQUssYUFBYSxLQUFLLFNBQVMsV0FBVyxJQUFJO0NBQzVFO0FBQ0Y7QUFDQSxhQUFhLFlBQVksY0FBYzs7O0FDeER2QyxJQUFJLGtCQUFrQyxrQkFBRSxxQkFBcUI7Q0FDM0QsaUJBQWlCLGlCQUFpQixpQkFBaUIsTUFBTTtDQUN6RCxpQkFBaUIsaUJBQWlCLFVBQVUsTUFBTTtDQUNsRCxpQkFBaUIsaUJBQWlCLFlBQVksS0FBSztDQUNuRCxpQkFBaUIsaUJBQWlCLFNBQVMsT0FBTztDQUNsRCxpQkFBaUIsaUJBQWlCLGFBQWEsT0FBTztDQUN0RCxPQUFPO0FBQ1QsRUFBQSxDQUFHLG1CQUFtQixDQUFDLENBQUM7OztBQ1B4QixJQUFNLGlCQUFOLE1BQXFCOzs7Ozs7Ozs7Q0FTbkIsWUFBWSxJQUFJLFVBQVUsTUFBTSxXQUFXLEdBQUcsT0FBTyxPQUFPOztFQUUxRCxLQUFLLE9BQU87O0VBRVosS0FBSyxXQUFXOztFQUVoQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxNQUFNO0VBQ1gsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVztFQUNoQixLQUFLLFFBQVE7Q0FDZjs7Ozs7OztDQU9BLE1BQU0sSUFBSSxVQUFVLE1BQU07RUFDeEIsT0FBTyxLQUFLLFFBQVEsTUFBTSxLQUFLLGFBQWE7Q0FDOUM7Ozs7OztDQU1BLEtBQUssUUFBUTtFQUNYLElBQUksS0FBSyxLQUFLO0dBQ1osSUFBSSxLQUFLLFVBQ1AsS0FBSyxJQUFJLEtBQUssS0FBSyxVQUFVLE1BQU07UUFFbkMsS0FBSyxJQUFJLE1BQU07RUFFbkI7RUFDQSxNQUFNLFdBQVcsS0FBSztFQUN0QixJQUFJLEtBQUssT0FDUCxLQUFLLFFBQVEsSUFBSTtFQUVuQixJQUFJLEtBQUssWUFDUCxLQUFLLE9BQU87RUFFZCxPQUFPO0NBQ1Q7Ozs7O0NBS0EsUUFBUSxVQUFVO0VBQ2hCLEtBQUssV0FBVztFQUNoQixJQUFJLFNBQVMsTUFDWCxTQUFTLEtBQUssV0FBVztFQUUzQixLQUFLLE9BQU8sU0FBUztFQUNyQixTQUFTLE9BQU87Q0FDbEI7Ozs7Ozs7Q0FPQSxRQUFRLE9BQU8sT0FBTztFQUNwQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxNQUFNO0VBQ1gsS0FBSyxXQUFXO0VBQ2hCLElBQUksS0FBSyxVQUNQLEtBQUssU0FBUyxPQUFPLEtBQUs7RUFFNUIsSUFBSSxLQUFLLE1BQ1AsS0FBSyxLQUFLLFdBQVcsS0FBSztFQUU1QixNQUFNLFdBQVcsS0FBSztFQUN0QixLQUFLLE9BQU8sT0FBTyxPQUFPO0VBQzFCLEtBQUssV0FBVztFQUNoQixPQUFPO0NBQ1Q7QUFDRjs7O0FDbEZBLElBQU0sVUFBVSxNQUFNLFFBQVE7Q0FDNUIsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBd0JaLEtBQUssWUFBWTs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFpQmpCLEtBQUssWUFBWTs7Ozs7Ozs7Ozs7Ozs7O0VBZWpCLEtBQUssV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFvQmhCLEtBQUssUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBcUJiLEtBQUssVUFBVTs7RUFFZixLQUFLLGFBQWE7Ozs7O0VBS2xCLEtBQUssZ0JBQWdCOzs7OztFQUtyQixLQUFLLGdCQUFnQjs7RUFFckIsS0FBSyxhQUFhOztFQUVsQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxRQUFRLElBQUksZUFBZSxNQUFNLE1BQU0sUUFBUTtFQUNwRCxLQUFLLFVBQVUsSUFBSSxRQUFRO0VBQzNCLEtBQUssWUFBWSxJQUFJLFFBQVE7RUFDN0IsS0FBSyxTQUFTLFNBQVM7R0FDckIsS0FBSyxhQUFhO0dBQ2xCLElBQUksS0FBSyxTQUFTO0lBQ2hCLEtBQUssT0FBTyxJQUFJO0lBQ2hCLElBQUksS0FBSyxXQUFXLEtBQUssZUFBZSxRQUFRLEtBQUssTUFBTSxNQUN6RCxLQUFLLGFBQWEsc0JBQXNCLEtBQUssS0FBSztHQUV0RDtFQUNGO0NBQ0Y7Ozs7OztDQU1BLG1CQUFtQjtFQUNqQixJQUFJLEtBQUssZUFBZSxRQUFRLEtBQUssTUFBTSxNQUFNO0dBQy9DLEtBQUssV0FBVyxZQUFZLElBQUk7R0FDaEMsS0FBSyxhQUFhLEtBQUs7R0FDdkIsS0FBSyxhQUFhLHNCQUFzQixLQUFLLEtBQUs7RUFDcEQ7Q0FDRjs7Q0FFQSxrQkFBa0I7RUFDaEIsSUFBSSxLQUFLLGVBQWUsTUFBTTtHQUM1QixxQkFBcUIsS0FBSyxVQUFVO0dBQ3BDLEtBQUssYUFBYTtFQUNwQjtDQUNGOzs7Ozs7Ozs7Q0FTQSxtQkFBbUI7RUFDakIsSUFBSSxLQUFLLFNBQ1AsS0FBSyxpQkFBaUI7T0FDakIsSUFBSSxLQUFLLFdBQ2QsS0FBSyxNQUFNO0NBRWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCQSxJQUFJLElBQUksU0FBUyxXQUFXLGdCQUFnQixRQUFRO0VBQ2xELE9BQU8sS0FBSyxhQUFhLElBQUksZUFBZSxJQUFJLFNBQVMsUUFBUSxDQUFDO0NBQ3BFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvQ0EsUUFBUSxJQUFJLFNBQVMsV0FBVyxnQkFBZ0IsUUFBUTtFQUN0RCxPQUFPLEtBQUssYUFBYSxJQUFJLGVBQWUsSUFBSSxTQUFTLFVBQVUsSUFBSSxDQUFDO0NBQzFFOzs7Ozs7Ozs7Q0FTQSxhQUFhLFVBQVU7RUFDckIsSUFBSSxVQUFVLEtBQUssTUFBTTtFQUN6QixJQUFJLFdBQVcsS0FBSztFQUNwQixJQUFJLENBQUMsU0FDSCxTQUFTLFFBQVEsUUFBUTtPQUNwQjtHQUNMLE9BQU8sU0FBUztJQUNkLElBQUksU0FBUyxXQUFXLFFBQVEsVUFBVTtLQUN4QyxTQUFTLFFBQVEsUUFBUTtLQUN6QjtJQUNGO0lBQ0EsV0FBVztJQUNYLFVBQVUsUUFBUTtHQUNwQjtHQUNBLElBQUksQ0FBQyxTQUFTLFVBQ1osU0FBUyxRQUFRLFFBQVE7RUFFN0I7RUFDQSxLQUFLLGlCQUFpQjtFQUN0QixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQ0EsT0FBTyxJQUFJLFNBQVM7RUFDbEIsSUFBSSxXQUFXLEtBQUssTUFBTTtFQUMxQixPQUFPLFVBQ0wsSUFBSSxTQUFTLE1BQU0sSUFBSSxPQUFPLEdBQzVCLFdBQVcsU0FBUyxRQUFRO09BRTVCLFdBQVcsU0FBUztFQUd4QixJQUFJLENBQUMsS0FBSyxNQUFNLE1BQ2QsS0FBSyxnQkFBZ0I7RUFFdkIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0JBLElBQUksUUFBUTtFQUNWLElBQUksQ0FBQyxLQUFLLE9BQ1IsT0FBTztFQUVULElBQUksUUFBUTtFQUNaLElBQUksVUFBVSxLQUFLO0VBQ25CLE9BQU8sVUFBVSxRQUFRLE1BQ3ZCO0VBRUYsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLFFBQVE7RUFDTixJQUFJLENBQUMsS0FBSyxTQUFTO0dBQ2pCLEtBQUssVUFBVTtHQUNmLEtBQUssaUJBQWlCO0VBQ3hCO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Q0FhQSxPQUFPO0VBQ0wsSUFBSSxLQUFLLFNBQVM7R0FDaEIsS0FBSyxVQUFVO0dBQ2YsS0FBSyxnQkFBZ0I7RUFDdkI7Q0FDRjs7Ozs7Ozs7Ozs7OztDQWFBLFVBQVU7RUFDUixJQUFJLENBQUMsS0FBSyxZQUFZO0dBQ3BCLEtBQUssS0FBSztHQUNWLElBQUksV0FBVyxLQUFLLE1BQU07R0FDMUIsT0FBTyxVQUNMLFdBQVcsU0FBUyxRQUFRLElBQUk7R0FFbEMsS0FBSyxNQUFNLFFBQVE7R0FDbkIsS0FBSyxRQUFRO0VBQ2Y7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBd0JBLE9BQU8sY0FBYyxZQUFZLElBQUksR0FBRztFQUN0QyxJQUFJO0VBQ0osSUFBSSxjQUFjLEtBQUssVUFBVTtHQUMvQixZQUFZLEtBQUssWUFBWSxjQUFjLEtBQUs7R0FDaEQsSUFBSSxZQUFZLEtBQUssZUFDbkIsWUFBWSxLQUFLO0dBRW5CLGFBQWEsS0FBSztHQUNsQixJQUFJLEtBQUssZUFBZTtJQUN0QixNQUFNLFFBQVEsY0FBYyxLQUFLLGFBQWE7SUFDOUMsSUFBSSxRQUFRLEtBQUssZUFDZjtJQUVGLEtBQUssYUFBYSxjQUFjLFFBQVEsS0FBSztHQUMvQztHQUNBLEtBQUssVUFBVTtHQUNmLEtBQUssWUFBWSxLQUFLLFVBQVUsUUFBUTtHQUN4QyxNQUFNLE9BQU8sS0FBSztHQUNsQixJQUFJLFdBQVcsS0FBSztHQUNwQixPQUFPLFVBQ0wsV0FBVyxTQUFTLEtBQUssSUFBSTtHQUUvQixJQUFJLENBQUMsS0FBSyxNQUNSLEtBQUssZ0JBQWdCO0VBRXpCLE9BQ0UsS0FBSyxZQUFZLEtBQUssVUFBVSxLQUFLLFlBQVk7RUFFbkQsS0FBSyxXQUFXO0NBQ2xCOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLElBQUksTUFBTTtFQUNSLE9BQU8sTUFBTSxLQUFLO0NBQ3BCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNEJBLElBQUksU0FBUztFQUNYLE9BQU8sTUFBTSxLQUFLO0NBQ3BCO0NBQ0EsSUFBSSxPQUFPLEtBQUs7RUFDZCxNQUFNLFVBQVUsS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLEdBQUcsSUFBSSxLQUFLLFFBQVEsVUFBVTtFQUNuRSxLQUFLLGdCQUFnQixJQUFJO0VBQ3pCLElBQUksS0FBSyxpQkFBaUIsTUFBTSxLQUFLLFFBQ25DLEtBQUssU0FBUztDQUVsQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkJBLElBQUksU0FBUztFQUNYLElBQUksS0FBSyxlQUNQLE9BQU8sS0FBSyxNQUFNLE1BQU0sS0FBSyxhQUFhO0VBRTVDLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTyxLQUFLO0VBQ2QsSUFBSSxRQUFRLEdBQ1YsS0FBSyxnQkFBZ0I7T0FDaEI7R0FDTCxJQUFJLE1BQU0sS0FBSyxRQUNiLEtBQUssU0FBUztHQUVoQixLQUFLLGdCQUFnQixLQUFLLE1BQU07RUFDbEM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0E0Q0EsV0FBVyxTQUFTO0VBQ2xCLElBQUksQ0FBQyxRQUFRLFNBQVM7R0FDcEIsTUFBTSxTQUFTLFFBQVEsVUFBVSxJQUFJLFFBQVE7R0FDN0MsT0FBTyxZQUFZO0dBQ25CLE9BQU8sYUFBYTtFQUN0QjtFQUNBLE9BQU8sUUFBUTtDQUNqQjs7Ozs7Ozs7Ozs7Q0FXQSxXQUFXLFNBQVM7RUFDbEIsSUFBSSxDQUFDLFFBQVEsU0FBUztHQUNwQixNQUFNLFNBQVMsUUFBUSxVQUFVLElBQUksUUFBUTtHQUM3QyxPQUFPLFlBQVk7R0FDbkIsT0FBTyxhQUFhO0VBQ3RCO0VBQ0EsT0FBTyxRQUFRO0NBQ2pCO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUJBLFFBQVEsYUFBYTtBQUNyQixJQUFJLFNBQVM7OztBQy9uQmIsSUFBTSxlQUFlO0NBQ25CLFFBQVE7Q0FDUixLQUFLO0NBQ0wsVUFBVTtDQUNWLFFBQVE7Q0FDUixTQUFTO0NBQ1QsT0FBTztDQUNQLGNBQWM7Q0FDZCxXQUFXO0NBQ1gsY0FBYztDQUNkLEtBQUs7Q0FDTCxLQUFLO0FBQ1A7QUFDQSxJQUFNLGFBQWE7Q0FDakIsT0FBTztDQUNQLFFBQVE7Q0FDUixTQUFTO0NBQ1QsWUFBWTtDQUNaLFNBQVM7Q0FDVCxZQUFZO0FBQ2Q7QUFDQSxJQUFNLEVBQUUsT0FBTyxRQUFRLFNBQVMsWUFBWSxTQUFTLGVBQWU7QUFDcEUsSUFBTSxTQUFTLE1BQU0sT0FBTztDQUMxQixjQUFjO0VBQ1osS0FBSyxPQUFPO0VBQ1osS0FBSyxZQUFZO0VBQ2pCLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssUUFBUTtFQUNiLEtBQUssWUFBWTtDQUNuQjs7Ozs7Q0FLQSxJQUFJLFFBQVE7RUFDVixPQUFPLENBQUMsRUFBRSxLQUFLLE9BQU8sS0FBSztDQUM3QjtDQUNBLElBQUksTUFBTSxPQUFPO0VBQ2YsSUFBSSxDQUFDLEVBQUUsS0FBSyxPQUFPLEtBQUssV0FBVyxPQUNqQyxLQUFLLFFBQVEsS0FBSztDQUV0Qjs7Ozs7Q0FLQSxJQUFJLFVBQVU7RUFDWixPQUFPLENBQUMsRUFBRSxLQUFLLE9BQU8sS0FBSztDQUM3QjtDQUNBLElBQUksUUFBUSxPQUFPO0VBQ2pCLElBQUksQ0FBQyxFQUFFLEtBQUssT0FBTyxLQUFLLFlBQVksT0FDbEMsS0FBSyxRQUFRLEtBQUs7Q0FFdEI7O0NBRUEsSUFBSSxTQUFTLE9BQU87RUFDbEIsSUFBSSxVQUFVLFFBQVE7R0FDcEIsS0FBSyxVQUFVO0dBQ2Y7RUFDRjtFQUNBLEtBQUssVUFBVTtFQUNmLEtBQUsscUJBQXFCLFVBQVU7Q0FDdEM7Q0FDQSxJQUFJLFdBQVc7RUFDYixJQUFJLENBQUMsS0FBSyxTQUNSLE9BQU87RUFFVCxPQUFPLEtBQUsscUJBQXFCLFVBQVU7Q0FDN0M7Ozs7O0NBS0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxDQUFDLEVBQUUsS0FBSyxPQUFPLEtBQUs7Q0FDN0I7Q0FDQSxJQUFJLFFBQVEsT0FBTztFQUNqQixJQUFJLENBQUMsRUFBRSxLQUFLLE9BQU8sS0FBSyxhQUFhLE9BQ25DLEtBQUssUUFBUSxLQUFLO0NBRXRCOzs7OztDQUtBLElBQUksWUFBWTtFQUNkLE9BQU8sQ0FBQyxFQUFFLEtBQUssT0FBTyxLQUFLO0NBQzdCO0NBQ0EsSUFBSSxVQUFVLE9BQU87RUFDbkIsSUFBSSxDQUFDLEVBQUUsS0FBSyxPQUFPLEtBQUssZ0JBQWdCLE9BQ3RDLEtBQUssUUFBUSxLQUFLO0NBRXRCOzs7OztDQUtBLElBQUksWUFBWTtFQUNkLE9BQU8sQ0FBQyxFQUFFLEtBQUssT0FBTyxLQUFLO0NBQzdCO0NBQ0EsSUFBSSxVQUFVLE9BQU87RUFDbkIsSUFBSSxDQUFDLEVBQUUsS0FBSyxPQUFPLEtBQUssZ0JBQWdCLE9BQ3RDLEtBQUssUUFBUSxLQUFLO0NBRXRCOzs7OztDQUtBLElBQUkscUJBQXFCO0VBQ3ZCLE9BQU8sQ0FBQyxFQUFFLEtBQUssT0FBTyxLQUFLO0NBQzdCO0NBQ0EsSUFBSSxtQkFBbUIsT0FBTztFQUM1QixJQUFJLENBQUMsRUFBRSxLQUFLLE9BQU8sS0FBSyxhQUFhLE9BQ25DLEtBQUssUUFBUSxLQUFLO0NBRXRCOzs7Ozs7Q0FNQSxJQUFJLFlBQVk7RUFDZCxPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksVUFBVSxPQUFPO0VBQ25CLEtBQUssUUFBUSxVQUFVO0VBQ3ZCLEtBQUssYUFBYTtFQUNsQixLQUFLLGVBQWUsYUFBYSxVQUFVO0NBQzdDOzs7OztDQUtBLElBQUksZ0JBQWdCO0VBQ2xCLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxjQUFjLE9BQU87RUFDdkIsS0FBSyxVQUFVLENBQUMsQ0FBQztFQUNqQixLQUFLLGlCQUFpQjtDQUN4QjtDQUNBLFdBQVc7RUFDVCxPQUFPLGlDQUFpQyxLQUFLLFVBQVUsc0JBQXNCLEtBQUssbUJBQW1CLFdBQVcsS0FBSyxRQUFRLGFBQWEsS0FBSyxVQUFVLGlCQUFpQixLQUFLLGNBQWM7Q0FDL0w7Ozs7O0NBS0EsT0FBTyxRQUFRO0VBQ2IsTUFBTSxRQUFRLElBQUksT0FBTztFQUN6QixNQUFNLFlBQVk7RUFDbEIsTUFBTSxZQUFZO0VBQ2xCLE1BQU0sUUFBUTtFQUNkLE9BQU87Q0FDVDtBQUNGO0FBQ0EsT0FBTyxZQUFZLE9BQU8sTUFBTTtBQUNoQyxJQUFJLFFBQVE7OztBQ3hKWixJQUFNLFVBQVUsTUFBTSxnQkFBZ0IsT0FBTzs7OztDQUkzQyxZQUFZLFNBQVM7RUFDbkIsVUFBVTtHQUFFLEdBQUcsUUFBUTtHQUFnQixHQUFHO0VBQVE7RUFDbEQsTUFBTSxPQUFPOztFQUViLEtBQUssVUFBVTs7Ozs7RUFLZixLQUFLLFNBQVMsTUFBTSxNQUFNO0VBQzFCLEtBQUssWUFBWSxRQUFRO0VBQ3pCLEtBQUssVUFBVSxRQUFRO0VBQ3ZCLElBQUksT0FBTyxRQUFRLGNBQWMsV0FDL0IsS0FBSyxZQUFZLFFBQVEsWUFBWSxPQUFPO09BRTVDLEtBQUssWUFBWSxRQUFRO0VBRTNCLEtBQUssYUFBYSxRQUFRO0VBQzFCLEtBQUssZ0JBQWdCLFFBQVE7RUFDN0IsS0FBSyxpQkFBaUIsUUFBUTtFQUM5QixLQUFLLFlBQVksWUFBWSxHQUFHLENBQUM7RUFDakMsSUFBSSxRQUFRLGVBQ1YsS0FBSyxZQUFZLGdCQUFnQixHQUFHLENBQUM7Q0FFekM7Ozs7Ozs7O0NBUUEsTUFBTSxlQUFlLE9BQU8sUUFBUSxXQUFXO0VBQzdDLGNBQWMsWUFBWSxNQUFNLE9BQU8sUUFBUSxTQUFTO0NBQzFEOzs7OztDQUtBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOztDQUVBLElBQUksVUFBVSxPQUFPO0VBQ25CLEtBQUssT0FBTyxZQUFZO0NBQzFCOzs7Ozs7Q0FNQSxPQUFPLEtBQUssU0FBUztFQUNuQixNQUFNLEVBQUUsS0FBSyxJQUFJLEdBQUcsU0FBUztFQUM3QixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUksS0FDRixhQUFhLFdBQVcsS0FBSyxHQUFHO0VBRWxDLElBQUksSUFDRixZQUFZLFVBQVUsS0FBSyxFQUFFO0VBRS9CLE9BQU8sSUFBSSxRQUFRO0dBQ2pCO0dBQ0E7R0FDQSxHQUFHO0VBQ0wsQ0FBQztDQUNIO0FBQ0Y7O0FBRUEsUUFBUSxpQkFBaUI7Q0FDdkIsV0FBVztDQUNYLFlBQVk7Q0FDWixTQUFTO0NBQ1QsV0FBVztDQUNYLGVBQWU7Q0FDZixnQkFBZ0I7QUFDbEI7QUFDQSxJQUFJLFNBQVMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzM119