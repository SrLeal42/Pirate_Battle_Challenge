import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/GameCanvas.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameCanvas.module.css"
const __vite__css = "._container_rnely_1 {\r\n    position: relative;\r\n    width: 100%;\r\n    height: 100%;\r\n    font-family: 'Inter', system-ui, sans-serif;\r\n}\r\n\r\n._canvasWrapper_rnely_15 canvas {\r\n    max-width: 100vw;\r\n    max-height: 100vh;\r\n    object-fit: contain;\r\n}\r\n\r\n._portraitWarning_rnely_27 {\r\n    display: none;\r\n}\r\n\r\n@media screen and (hover: none) and (pointer: coarse) and (orientation: portrait) {\r\n    ._portraitWarning_rnely_27 {\r\n        display: flex;\r\n        position: fixed;\r\n        inset: 0;\r\n        background-color: #0f172a;\r\n        z-index: 9999;\r\n        flex-direction: column;\r\n        justify-content: center;\r\n        align-items: center;\r\n        color: #fde047;\r\n        font-size: 1.5rem;\r\n        text-align: center;\r\n        padding: 2rem;\r\n        font-weight: 900;\r\n        text-transform: uppercase;\r\n        text-shadow: 2px 2px 0px #000;\r\n    }\r\n\r\n    ._rotateIcon_rnely_73 {\r\n        width: 120px;\r\n        height: 120px;\r\n        margin-bottom: 2rem;\r\n        filter: drop-shadow(2px 2px 0px #000);\r\n        animation: _tilt_rnely_1 2s infinite ease-in-out;\r\n    }\r\n}\r\n\r\n@keyframes _tilt_rnely_1 {\r\n    0% {\r\n        transform: rotate(0deg);\r\n    }\r\n\r\n    50% {\r\n        transform: rotate(-90deg);\r\n    }\r\n\r\n    100% {\r\n        transform: rotate(0deg);\r\n    }\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const container = "_container_rnely_1";
export const canvasWrapper = "_canvasWrapper_rnely_15";
export const portraitWarning = "_portraitWarning_rnely_27";
export const rotateIcon = "_rotateIcon_rnely_73";
export const tilt = "_tilt_rnely_1";
export default {
	container: container,
	canvasWrapper: canvasWrapper,
	portraitWarning: portraitWarning,
	rotateIcon: rotateIcon,
	tilt: tilt
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))