import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/GameCanvas.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import { GameRuntime } from "/src/runtime/gameRuntime.ts";
import { useGameStore, RuntimeStateEnum } from "/src/stores/gameStore.ts";
import { completeMatch } from "/src/features/matches/matchService.ts";
import { StartScreen } from "/src/ui/components/StartScreen.tsx";
import { HUD } from "/src/ui/components/HUD.tsx";
import { GameOverScreen } from "/src/ui/components/GameOverScreen.tsx";
import { PauseScreen } from "/src/ui/components/PauseScreen.tsx";
import { LoadingScreen } from "/src/ui/components/LoadingScreen.tsx";
import { GameAnnouncer } from "/src/ui/components/GameAnnouncer.tsx";
import styles from "/src/ui/components/GameCanvas.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameCanvas.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
export const GameCanvas = () => {
	_s();
	const containerRef = useRef(null);
	const runtimeRef = useRef(null);
	const runtimeState = useGameStore((state) => state.runtimeState);
	const isBooting = runtimeState === RuntimeStateEnum.Idle || runtimeState === RuntimeStateEnum.Loading || runtimeState === RuntimeStateEnum.Error;
	useEffect(() => {
		if (!containerRef.current) return;
		const runtime = new GameRuntime(containerRef.current);
		runtime.onMatchEnd = completeMatch;
		runtimeRef.current = runtime;
		void runtime.init();
		return () => {
			runtime.destroy();
			runtimeRef.current = null;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: styles.container,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.portraitWarning,
				children: [
					/* @__PURE__ */ _jsxDEV("img", {
						src: "/assets/png/default/ui/controls/icon_restart.png",
						className: styles.rotateIcon,
						alt: "Rotate"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Please rotate your device" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						style: {
							fontSize: "1rem",
							color: "white",
							marginTop: "1rem",
							textShadow: "none"
						},
						children: "Pirate Battle is best played in landscape mode"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				ref: containerRef,
				className: styles.canvasWrapper
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 13
			}, this),
			runtimeState === RuntimeStateEnum.Ready && /* @__PURE__ */ _jsxDEV(StartScreen, { onStart: () => {
				const s = useGameStore.getState();
				runtimeRef.current?.start(s.sessionTime, s.spawnInterval);
			} }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 17
			}, this),
			isBooting && /* @__PURE__ */ _jsxDEV(LoadingScreen, { onRetry: () => void runtimeRef.current?.retry() }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 27
			}, this),
			runtimeState === RuntimeStateEnum.Playing && /* @__PURE__ */ _jsxDEV(HUD, { onPause: () => runtimeRef.current?.pause() }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 17
			}, this),
			runtimeState === RuntimeStateEnum.Ended && /* @__PURE__ */ _jsxDEV(GameOverScreen, {
				onRestart: () => runtimeRef.current?.restart(),
				onQuit: () => runtimeRef.current?.quitToMenu()
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 17
			}, this),
			runtimeState === RuntimeStateEnum.Paused && /* @__PURE__ */ _jsxDEV(PauseScreen, {
				onResume: () => runtimeRef.current?.resume(),
				onQuit: () => runtimeRef.current?.quitToMenu()
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV(GameAnnouncer, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 9
	}, this);
};
_s(GameCanvas, "A1SNVg16gPwTKtAPEPldfORsGHE=", false, function() {
	return [useGameStore];
});
_c = GameCanvas;
var _c;
$RefreshReg$(_c, "GameCanvas");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/GameCanvas.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameCanvas.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameCanvas.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameCanvas.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsY0FBYztBQUN6QyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGNBQWMsd0JBQXdCO0FBRS9DLFNBQVMscUJBQXFCO0FBRTlCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsV0FBVztBQUNwQixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHFCQUFxQjtBQUU5QixPQUFPLFlBQVk7Ozs7QUFPbkIsT0FBTyxNQUFNLG1CQUE4Qzs7Q0FDdkQsTUFBTSxlQUFlLE9BQXVCLElBQUk7Q0FDaEQsTUFBTSxhQUFhLE9BQTJCLElBQUk7Q0FFbEQsTUFBTSxlQUFlLGNBQWMsVUFBVSxNQUFNLFlBQVk7Q0FFL0QsTUFBTSxZQUFZLGlCQUFpQixpQkFBaUIsUUFDN0MsaUJBQWlCLGlCQUFpQixXQUNsQyxpQkFBaUIsaUJBQWlCO0NBR3pDLGdCQUFnQjtFQUNaLElBQUksQ0FBQyxhQUFhLFNBQVM7RUFFM0IsTUFBTSxVQUFVLElBQUksWUFBWSxhQUFhLE9BQU87RUFDcEQsUUFBUSxhQUFhO0VBQ3JCLFdBQVcsVUFBVTtFQUVyQixLQUFLLFFBQVEsS0FBSztFQUVsQixhQUFhO0dBQ1QsUUFBUSxRQUFRO0dBQ2hCLFdBQVcsVUFBVTtFQUN6QjtDQUNKLEdBQUcsQ0FBQyxDQUFDO0NBRUwsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVyxPQUFPO1lBQXZCO0dBRUksd0JBQUMsT0FBRDtJQUFLLFdBQVcsT0FBTztjQUF2QjtLQUNJLHdCQUFDLE9BQUQ7TUFBSyxLQUFJO01BQW1ELFdBQVcsT0FBTztNQUFZLEtBQUk7S0FBVTs7Ozs7S0FDeEcsd0JBQUMsS0FBRCxZQUFHLDRCQUE0Qjs7Ozs7S0FDL0Isd0JBQUMsUUFBRDtNQUFNLE9BQU87T0FBRSxVQUFVO09BQVEsT0FBTztPQUFTLFdBQVc7T0FBUSxZQUFZO01BQU87Z0JBQUc7S0FFcEY7Ozs7O0lBQ0w7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxLQUFLO0lBQWMsV0FBVyxPQUFPO0dBQWdCOzs7OztHQUV6RCxpQkFBaUIsaUJBQWlCLFNBQy9CLHdCQUFDLGFBQUQsRUFDSSxlQUFlO0lBQ1gsTUFBTSxJQUFJLGFBQWEsU0FBUztJQUNoQyxXQUFXLFNBQVMsTUFBTSxFQUFFLGFBQWEsRUFBRSxhQUFhO0dBQzVELEVBQ0g7Ozs7O0dBR0osYUFBYSx3QkFBQyxlQUFELEVBQWUsZUFBZSxLQUFLLFdBQVcsU0FBUyxNQUFNLEVBQUk7Ozs7O0dBRTlFLGlCQUFpQixpQkFBaUIsV0FDL0Isd0JBQUMsS0FBRCxFQUFLLGVBQWUsV0FBVyxTQUFTLE1BQU0sRUFBSTs7Ozs7R0FHckQsaUJBQWlCLGlCQUFpQixTQUMvQix3QkFBQyxnQkFBRDtJQUNJLGlCQUFpQixXQUFXLFNBQVMsUUFBUTtJQUM3QyxjQUFjLFdBQVcsU0FBUyxXQUFXO0dBQ2hEOzs7OztHQUdKLGlCQUFpQixpQkFBaUIsVUFDL0Isd0JBQUMsYUFBRDtJQUNJLGdCQUFnQixXQUFXLFNBQVMsT0FBTztJQUMzQyxjQUFjLFdBQVcsU0FBUyxXQUFXO0dBQ2hEOzs7OztHQUdMLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7O0VBRWY7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkdhbWVDYW52YXMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgR2FtZVJ1bnRpbWUgfSBmcm9tICcuLi8uLi9ydW50aW1lL2dhbWVSdW50aW1lJztcclxuaW1wb3J0IHsgdXNlR2FtZVN0b3JlLCBSdW50aW1lU3RhdGVFbnVtIH0gZnJvbSAnLi4vLi4vc3RvcmVzL2dhbWVTdG9yZSc7XHJcblxyXG5pbXBvcnQgeyBjb21wbGV0ZU1hdGNoIH0gZnJvbSAnLi4vLi4vZmVhdHVyZXMvbWF0Y2hlcy9tYXRjaFNlcnZpY2UnO1xyXG5cclxuaW1wb3J0IHsgU3RhcnRTY3JlZW4gfSBmcm9tICcuL1N0YXJ0U2NyZWVuJztcclxuaW1wb3J0IHsgSFVEIH0gZnJvbSAnLi9IVUQnO1xyXG5pbXBvcnQgeyBHYW1lT3ZlclNjcmVlbiB9IGZyb20gJy4vR2FtZU92ZXJTY3JlZW4nO1xyXG5pbXBvcnQgeyBQYXVzZVNjcmVlbiB9IGZyb20gJy4vUGF1c2VTY3JlZW4nO1xyXG5pbXBvcnQgeyBMb2FkaW5nU2NyZWVuIH0gZnJvbSAnLi9Mb2FkaW5nU2NyZWVuJztcclxuaW1wb3J0IHsgR2FtZUFubm91bmNlciB9IGZyb20gJy4vR2FtZUFubm91bmNlcic7XHJcblxyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4vR2FtZUNhbnZhcy5tb2R1bGUuY3NzJztcclxuXHJcbmludGVyZmFjZSBHYW1lQ2FudmFzUHJvcHMge1xyXG4gICAgc2Vzc2lvblRpbWU/OiBudW1iZXI7XHJcbiAgICBzcGF3bkludGVydmFsPzogbnVtYmVyO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgR2FtZUNhbnZhczogUmVhY3QuRkM8R2FtZUNhbnZhc1Byb3BzPiA9ICgpID0+IHtcclxuICAgIGNvbnN0IGNvbnRhaW5lclJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XHJcbiAgICBjb25zdCBydW50aW1lUmVmID0gdXNlUmVmPEdhbWVSdW50aW1lIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gICAgY29uc3QgcnVudGltZVN0YXRlID0gdXNlR2FtZVN0b3JlKChzdGF0ZSkgPT4gc3RhdGUucnVudGltZVN0YXRlKTtcclxuXHJcbiAgICBjb25zdCBpc0Jvb3RpbmcgPSBydW50aW1lU3RhdGUgPT09IFJ1bnRpbWVTdGF0ZUVudW0uSWRsZVxyXG4gICAgICAgIHx8IHJ1bnRpbWVTdGF0ZSA9PT0gUnVudGltZVN0YXRlRW51bS5Mb2FkaW5nXHJcbiAgICAgICAgfHwgcnVudGltZVN0YXRlID09PSBSdW50aW1lU3RhdGVFbnVtLkVycm9yO1xyXG5cclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGlmICghY29udGFpbmVyUmVmLmN1cnJlbnQpIHJldHVybjtcclxuXHJcbiAgICAgICAgY29uc3QgcnVudGltZSA9IG5ldyBHYW1lUnVudGltZShjb250YWluZXJSZWYuY3VycmVudCk7XHJcbiAgICAgICAgcnVudGltZS5vbk1hdGNoRW5kID0gY29tcGxldGVNYXRjaDtcclxuICAgICAgICBydW50aW1lUmVmLmN1cnJlbnQgPSBydW50aW1lO1xyXG5cclxuICAgICAgICB2b2lkIHJ1bnRpbWUuaW5pdCgpO1xyXG5cclxuICAgICAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICAgICAgICBydW50aW1lLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgcnVudGltZVJlZi5jdXJyZW50ID0gbnVsbDtcclxuICAgICAgICB9O1xyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5wb3J0cmFpdFdhcm5pbmd9PlxyXG4gICAgICAgICAgICAgICAgPGltZyBzcmM9XCIvYXNzZXRzL3BuZy9kZWZhdWx0L3VpL2NvbnRyb2xzL2ljb25fcmVzdGFydC5wbmdcIiBjbGFzc05hbWU9e3N0eWxlcy5yb3RhdGVJY29ufSBhbHQ9XCJSb3RhdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHA+UGxlYXNlIHJvdGF0ZSB5b3VyIGRldmljZTwvcD5cclxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMXJlbScsIGNvbG9yOiAnd2hpdGUnLCBtYXJnaW5Ub3A6ICcxcmVtJywgdGV4dFNoYWRvdzogJ25vbmUnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIFBpcmF0ZSBCYXR0bGUgaXMgYmVzdCBwbGF5ZWQgaW4gbGFuZHNjYXBlIG1vZGVcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IHJlZj17Y29udGFpbmVyUmVmfSBjbGFzc05hbWU9e3N0eWxlcy5jYW52YXNXcmFwcGVyfSAvPlxyXG5cclxuICAgICAgICAgICAge3J1bnRpbWVTdGF0ZSA9PT0gUnVudGltZVN0YXRlRW51bS5SZWFkeSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8U3RhcnRTY3JlZW5cclxuICAgICAgICAgICAgICAgICAgICBvblN0YXJ0PXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHMgPSB1c2VHYW1lU3RvcmUuZ2V0U3RhdGUoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcnVudGltZVJlZi5jdXJyZW50Py5zdGFydChzLnNlc3Npb25UaW1lLCBzLnNwYXduSW50ZXJ2YWwpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge2lzQm9vdGluZyAmJiA8TG9hZGluZ1NjcmVlbiBvblJldHJ5PXsoKSA9PiB2b2lkIHJ1bnRpbWVSZWYuY3VycmVudD8ucmV0cnkoKX0gLz59XHJcblxyXG4gICAgICAgICAgICB7cnVudGltZVN0YXRlID09PSBSdW50aW1lU3RhdGVFbnVtLlBsYXlpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEhVRCBvblBhdXNlPXsoKSA9PiBydW50aW1lUmVmLmN1cnJlbnQ/LnBhdXNlKCl9IC8+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7cnVudGltZVN0YXRlID09PSBSdW50aW1lU3RhdGVFbnVtLkVuZGVkICYmIChcclxuICAgICAgICAgICAgICAgIDxHYW1lT3ZlclNjcmVlblxyXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdGFydD17KCkgPT4gcnVudGltZVJlZi5jdXJyZW50Py5yZXN0YXJ0KCl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25RdWl0PXsoKSA9PiBydW50aW1lUmVmLmN1cnJlbnQ/LnF1aXRUb01lbnUoKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7cnVudGltZVN0YXRlID09PSBSdW50aW1lU3RhdGVFbnVtLlBhdXNlZCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8UGF1c2VTY3JlZW5cclxuICAgICAgICAgICAgICAgICAgICBvblJlc3VtZT17KCkgPT4gcnVudGltZVJlZi5jdXJyZW50Py5yZXN1bWUoKX1cclxuICAgICAgICAgICAgICAgICAgICBvblF1aXQ9eygpID0+IHJ1bnRpbWVSZWYuY3VycmVudD8ucXVpdFRvTWVudSgpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxHYW1lQW5ub3VuY2VyIC8+XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufTtcclxuIl19