import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/StartScreen.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useId = __vite__cjsImport0_react["useId"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import styles from "/src/ui/components/StartScreen.module.css";
import { useGameStore } from "/src/stores/gameStore.ts";
import { STORAGE_KEYS } from "/src/core/config.ts";
import { OptionsScreen } from "/src/ui/components/OptionsScreen.tsx";
import { LeaderboardScreen } from "/src/ui/components/LeaderboardScreen.tsx";
import { ControlsGuide } from "/src/ui/components/ControlsGuide.tsx";
import { END_REASON_LABEL, formatDuration } from "/src/ui/format.ts";
import { usePendingMatches } from "/src/features/matches/hooks.ts";
import { pendingQueue } from "/src/features/matches/storage.ts";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/StartScreen.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
export const MenuViewEnum = {
	Main: "main",
	Options: "options",
	Controls: "controls",
	Ranking: "ranking",
	History: "history"
};
export const StartScreen = ({ onStart }) => {
	_s();
	const [username, setUsername] = useState(() => localStorage.getItem(STORAGE_KEYS.playerName) ?? "");
	const [view, setView] = useState(MenuViewEnum.Main);
	const pending = usePendingMatches();
	const lastMatch = useGameStore((s) => s.lastMatch);
	const nameInputId = useId();
	const lastMatchTitleId = useId();
	useEffect(() => {
		pendingQueue.requestSync();
	}, []);
	const handleSubmit = (e) => {
		e.preventDefault();
		const usernameTrim = username.trim();
		if (usernameTrim.length > 0) {
			localStorage.setItem(STORAGE_KEYS.playerName, usernameTrim);
			useGameStore.setState({ username: usernameTrim });
			onStart();
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: styles.overlay,
		children: [
			view === MenuViewEnum.Options && /* @__PURE__ */ _jsxDEV(OptionsScreen, { onClose: () => setView(MenuViewEnum.Main) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 17
			}, this),
			view === MenuViewEnum.Controls && /* @__PURE__ */ _jsxDEV(ControlsGuide, { onClose: () => setView(MenuViewEnum.Main) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 17
			}, this),
			(view === MenuViewEnum.Ranking || view === MenuViewEnum.History) && /* @__PURE__ */ _jsxDEV(LeaderboardScreen, {
				initialTab: view === MenuViewEnum.Ranking ? "ranking" : "history",
				onClose: () => setView(MenuViewEnum.Main)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 17
			}, this),
			view === MenuViewEnum.Main && /* @__PURE__ */ _jsxDEV("div", {
				className: `${styles.card} responsive-card`,
				children: [
					/* @__PURE__ */ _jsxDEV("img", {
						src: "/assets/png/default/ui/menu/title_pirate_battle.png",
						alt: "Pirate Battle",
						className: styles.titleImage
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSubmit,
						className: styles.form,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: styles.inputWrapper,
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: styles.label,
								htmlFor: nameInputId,
								children: "Captain's Name"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								id: nameInputId,
								type: "text",
								className: styles.input,
								placeholder: "Type your name...",
								value: username,
								onChange: (e) => setUsername(e.target.value),
								maxLength: 24,
								required: true,
								autoFocus: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: styles.buttonGroup,
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: styles.button,
								children: "Play"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 29
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: styles.buttonSecondary,
								onClick: () => setView(MenuViewEnum.Options),
								children: "Options"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: styles.footerButtons,
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: styles.smallButton,
								onClick: () => setView(MenuViewEnum.Controls),
								children: "Controls"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: styles.smallButton,
								onClick: () => setView(MenuViewEnum.Ranking),
								children: "Ranking"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: styles.smallButton,
								onClick: () => setView(MenuViewEnum.History),
								children: "History"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 21
					}, this),
					lastMatch && /* @__PURE__ */ _jsxDEV("section", {
						className: styles.lastMatch,
						"aria-labelledby": lastMatchTitleId,
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							id: lastMatchTitleId,
							className: styles.lastMatchTitle,
							children: "Last match"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("dl", {
							className: styles.lastMatchDetails,
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Score" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: lastMatch.score }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 126,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Time played" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: formatDuration(lastMatch.durationMs) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 33
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Reason" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 37
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: END_REASON_LABEL[lastMatch.endReason] }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 37
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 33
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 25
					}, this),
					pending.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: styles.pendingNotice,
						role: "status",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: [
							pending.length,
							" match",
							pending.length > 1 ? "es" : "",
							" waiting to sync"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: styles.smallButton,
							onClick: pendingQueue.requestSync,
							children: "Retry"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 25
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 9
	}, this);
};
_s(StartScreen, "RRO4rdeoM55ls7JqIYuNIzkH8Uw=", false, function() {
	return [usePendingMatches, useGameStore];
});
_c = StartScreen;
var _c;
$RefreshReg$(_c, "StartScreen");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/StartScreen.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/StartScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/StartScreen.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/StartScreen.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsT0FBTyxnQkFBZ0I7QUFDbEQsT0FBTyxZQUFZO0FBRW5CLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9CO0FBRTdCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsa0JBQWtCLHNCQUFzQjtBQUVqRCxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLG9CQUFvQjs7OztBQUU3QixPQUFPLE1BQU0sZUFBZTtDQUN4QixNQUFNO0NBQ04sU0FBUztDQUNULFVBQVU7Q0FDVixTQUFTO0NBQ1QsU0FBUztBQUNiO0FBVUEsT0FBTyxNQUFNLGVBQTJDLEVBQUUsY0FBYzs7Q0FDcEUsTUFBTSxDQUFDLFVBQVUsZUFBZSxlQUFlLGFBQWEsUUFBUSxhQUFhLFVBQVUsS0FBSyxFQUFFO0NBQ2xHLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBbUIsYUFBYSxJQUFJO0NBRTVELE1BQU0sVUFBVSxrQkFBa0I7Q0FDbEMsTUFBTSxZQUFZLGNBQWMsTUFBTSxFQUFFLFNBQVM7Q0FDakQsTUFBTSxjQUFjLE1BQU07Q0FDMUIsTUFBTSxtQkFBbUIsTUFBTTtDQUUvQixnQkFBZ0I7RUFDWixhQUFhLFlBQVk7Q0FDN0IsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLGdCQUFnQixNQUF1QjtFQUN6QyxFQUFFLGVBQWU7RUFFakIsTUFBTSxlQUFlLFNBQVMsS0FBSztFQUVuQyxJQUFJLGFBQWEsU0FBUyxHQUFHO0dBQ3pCLGFBQWEsUUFBUSxhQUFhLFlBQVksWUFBWTtHQUMxRCxhQUFhLFNBQVMsRUFBRSxVQUFVLGFBQWEsQ0FBQztHQUNoRCxRQUFRO0VBQ1o7Q0FFSjtDQUVBLE9BRUksd0JBQUMsT0FBRDtFQUFLLFdBQVcsT0FBTztZQUF2QjtHQUVLLFNBQVMsYUFBYSxXQUNuQix3QkFBQyxlQUFELEVBQWUsZUFBZSxRQUFRLGFBQWEsSUFBSSxFQUFJOzs7OztHQUc5RCxTQUFTLGFBQWEsWUFDbkIsd0JBQUMsZUFBRCxFQUFlLGVBQWUsUUFBUSxhQUFhLElBQUksRUFBSTs7Ozs7SUFHN0QsU0FBUyxhQUFhLFdBQVcsU0FBUyxhQUFhLFlBQ3JELHdCQUFDLG1CQUFEO0lBQ0ksWUFBWSxTQUFTLGFBQWEsVUFBVSxZQUFZO0lBQ3hELGVBQWUsUUFBUSxhQUFhLElBQUk7R0FDM0M7Ozs7O0dBR0osU0FBUyxhQUFhLFFBQ25CLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLEdBQUcsT0FBTyxLQUFLO2NBQS9CO0tBQ0ksd0JBQUMsT0FBRDtNQUNJLEtBQUk7TUFDSixLQUFJO01BQ0osV0FBVyxPQUFPO0tBQ3JCOzs7OztLQUVELHdCQUFDLFFBQUQ7TUFBTSxVQUFVO01BQWMsV0FBVyxPQUFPO2dCQUFoRCxDQUNJLHdCQUFDLE9BQUQ7T0FBSyxXQUFXLE9BQU87aUJBQXZCLENBQ0ksd0JBQUMsU0FBRDtRQUFPLFdBQVcsT0FBTztRQUFPLFNBQVM7a0JBQWE7T0FBcUI7Ozs7aUJBQzNFLHdCQUFDLFNBQUQ7UUFDSSxJQUFJO1FBQ0osTUFBSztRQUNMLFdBQVcsT0FBTztRQUNsQixhQUFZO1FBQ1osT0FBTztRQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1FBQzNDLFdBQVc7UUFDWDtRQUNBO09BQ0g7Ozs7ZUFDQTs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVcsT0FBTztpQkFBdkIsQ0FDSSx3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFdBQVcsT0FBTztrQkFBUTtPQUV4Qzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFdBQVcsT0FBTztRQUFpQixlQUFlLFFBQVEsYUFBYSxPQUFPO2tCQUFHO09BRS9GOzs7O2VBQ1A7Ozs7O2NBQ0g7Ozs7OztLQUVOLHdCQUFDLE9BQUQ7TUFBSyxXQUFXLE9BQU87Z0JBQXZCO09BQ0ksd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxXQUFXLE9BQU87UUFBYSxlQUFlLFFBQVEsYUFBYSxRQUFRO2tCQUFHO09BRTVGOzs7OztPQUNSLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsV0FBVyxPQUFPO1FBQWEsZUFBZSxRQUFRLGFBQWEsT0FBTztrQkFBRztPQUUzRjs7Ozs7T0FDUix3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLFdBQVcsT0FBTztRQUFhLGVBQWUsUUFBUSxhQUFhLE9BQU87a0JBQUc7T0FFM0Y7Ozs7O01BQ1A7Ozs7OztLQUVKLGFBQ0csd0JBQUMsV0FBRDtNQUFTLFdBQVcsT0FBTztNQUFXLG1CQUFpQjtnQkFBdkQsQ0FDSSx3QkFBQyxNQUFEO09BQUksSUFBSTtPQUFrQixXQUFXLE9BQU87aUJBQWdCO01BQWM7Ozs7Z0JBQzFFLHdCQUFDLE1BQUQ7T0FBSSxXQUFXLE9BQU87aUJBQXRCO1FBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQsWUFBSSxRQUFTOzs7O2tCQUNiLHdCQUFDLE1BQUQsWUFBSyxVQUFVLE1BQVU7Ozs7Z0JBQ3hCOzs7OztRQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFELFlBQUksY0FBZTs7OztrQkFDbkIsd0JBQUMsTUFBRCxZQUFLLGVBQWUsVUFBVSxVQUFVLEVBQU07Ozs7Z0JBQzdDOzs7OztRQUNMLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFELFlBQUksU0FBVTs7OztrQkFDZCx3QkFBQyxNQUFELFlBQUssaUJBQWlCLFVBQVUsV0FBZTs7OztnQkFDOUM7Ozs7O09BQ0w7Ozs7O2NBQ0M7Ozs7OztLQUdaLFFBQVEsU0FBUyxLQUNkLHdCQUFDLE9BQUQ7TUFBSyxXQUFXLE9BQU87TUFBZSxNQUFLO2dCQUEzQyxDQUNJLHdCQUFDLFFBQUQ7T0FDSyxRQUFRO09BQU87T0FBTyxRQUFRLFNBQVMsSUFBSSxPQUFPO09BQUc7TUFDcEQ7Ozs7Z0JBQ04sd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFXLE9BQU87T0FBYSxTQUFTLGFBQWE7aUJBQWE7TUFFaEY7Ozs7Y0FDUDs7Ozs7O0lBR1I7Ozs7OztFQUdSOzs7Ozs7QUFJYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTdGFydFNjcmVlbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlSWQsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4vU3RhcnRTY3JlZW4ubW9kdWxlLmNzcyc7XHJcblxyXG5pbXBvcnQgeyB1c2VHYW1lU3RvcmUgfSBmcm9tICcuLi8uLi9zdG9yZXMvZ2FtZVN0b3JlJztcclxuaW1wb3J0IHsgU1RPUkFHRV9LRVlTIH0gZnJvbSAnLi4vLi4vY29yZS9jb25maWcnO1xyXG5cclxuaW1wb3J0IHsgT3B0aW9uc1NjcmVlbiB9IGZyb20gJy4vT3B0aW9uc1NjcmVlbic7XHJcbmltcG9ydCB7IExlYWRlcmJvYXJkU2NyZWVuIH0gZnJvbSAnLi9MZWFkZXJib2FyZFNjcmVlbic7XHJcbmltcG9ydCB7IENvbnRyb2xzR3VpZGUgfSBmcm9tICcuL0NvbnRyb2xzR3VpZGUnO1xyXG5pbXBvcnQgeyBFTkRfUkVBU09OX0xBQkVMLCBmb3JtYXREdXJhdGlvbiB9IGZyb20gJy4uL2Zvcm1hdCc7XHJcblxyXG5pbXBvcnQgeyB1c2VQZW5kaW5nTWF0Y2hlcyB9IGZyb20gJy4uLy4uL2ZlYXR1cmVzL21hdGNoZXMvaG9va3MnO1xyXG5pbXBvcnQgeyBwZW5kaW5nUXVldWUgfSBmcm9tICcuLi8uLi9mZWF0dXJlcy9tYXRjaGVzL3N0b3JhZ2UnO1xyXG5cclxuZXhwb3J0IGNvbnN0IE1lbnVWaWV3RW51bSA9IHtcclxuICAgIE1haW46ICdtYWluJyxcclxuICAgIE9wdGlvbnM6ICdvcHRpb25zJyxcclxuICAgIENvbnRyb2xzOiAnY29udHJvbHMnLFxyXG4gICAgUmFua2luZzogJ3JhbmtpbmcnLFxyXG4gICAgSGlzdG9yeTogJ2hpc3RvcnknLFxyXG59IGFzIGNvbnN0O1xyXG5cclxuXHJcbmV4cG9ydCB0eXBlIE1lbnVWaWV3ID0gdHlwZW9mIE1lbnVWaWV3RW51bVtrZXlvZiB0eXBlb2YgTWVudVZpZXdFbnVtXTtcclxuXHJcblxyXG5pbnRlcmZhY2UgU3RhcnRTY3JlZW5Qcm9wcyB7XHJcbiAgICBvblN0YXJ0OiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgU3RhcnRTY3JlZW46IFJlYWN0LkZDPFN0YXJ0U2NyZWVuUHJvcHM+ID0gKHsgb25TdGFydCB9KSA9PiB7XHJcbiAgICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCgpID0+IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFNUT1JBR0VfS0VZUy5wbGF5ZXJOYW1lKSA/PyAnJyk7XHJcbiAgICBjb25zdCBbdmlldywgc2V0Vmlld10gPSB1c2VTdGF0ZTxNZW51Vmlldz4oTWVudVZpZXdFbnVtLk1haW4pO1xyXG5cclxuICAgIGNvbnN0IHBlbmRpbmcgPSB1c2VQZW5kaW5nTWF0Y2hlcygpO1xyXG4gICAgY29uc3QgbGFzdE1hdGNoID0gdXNlR2FtZVN0b3JlKChzKSA9PiBzLmxhc3RNYXRjaCk7XHJcbiAgICBjb25zdCBuYW1lSW5wdXRJZCA9IHVzZUlkKCk7XHJcbiAgICBjb25zdCBsYXN0TWF0Y2hUaXRsZUlkID0gdXNlSWQoKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIHBlbmRpbmdRdWV1ZS5yZXF1ZXN0U3luYygpOyAvLyByZXRyeSB3aGVuIHJldHVybmluZyB0byB0aGUgbWVudVxyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHVzZXJuYW1lVHJpbSA9IHVzZXJuYW1lLnRyaW0oKTtcclxuXHJcbiAgICAgICAgaWYgKHVzZXJuYW1lVHJpbS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFNUT1JBR0VfS0VZUy5wbGF5ZXJOYW1lLCB1c2VybmFtZVRyaW0pO1xyXG4gICAgICAgICAgICB1c2VHYW1lU3RvcmUuc2V0U3RhdGUoeyB1c2VybmFtZTogdXNlcm5hbWVUcmltIH0pO1xyXG4gICAgICAgICAgICBvblN0YXJ0KCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5vdmVybGF5fT5cclxuXHJcbiAgICAgICAgICAgIHt2aWV3ID09PSBNZW51Vmlld0VudW0uT3B0aW9ucyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8T3B0aW9uc1NjcmVlbiBvbkNsb3NlPXsoKSA9PiBzZXRWaWV3KE1lbnVWaWV3RW51bS5NYWluKX0gLz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHt2aWV3ID09PSBNZW51Vmlld0VudW0uQ29udHJvbHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgPENvbnRyb2xzR3VpZGUgb25DbG9zZT17KCkgPT4gc2V0VmlldyhNZW51Vmlld0VudW0uTWFpbil9IC8+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7KHZpZXcgPT09IE1lbnVWaWV3RW51bS5SYW5raW5nIHx8IHZpZXcgPT09IE1lbnVWaWV3RW51bS5IaXN0b3J5KSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8TGVhZGVyYm9hcmRTY3JlZW5cclxuICAgICAgICAgICAgICAgICAgICBpbml0aWFsVGFiPXt2aWV3ID09PSBNZW51Vmlld0VudW0uUmFua2luZyA/ICdyYW5raW5nJyA6ICdoaXN0b3J5J31cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRWaWV3KE1lbnVWaWV3RW51bS5NYWluKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7dmlldyA9PT0gTWVudVZpZXdFbnVtLk1haW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake3N0eWxlcy5jYXJkfSByZXNwb25zaXZlLWNhcmRgfSA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzcmM9XCIvYXNzZXRzL3BuZy9kZWZhdWx0L3VpL21lbnUvdGl0bGVfcGlyYXRlX2JhdHRsZS5wbmdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJQaXJhdGUgQmF0dGxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMudGl0bGVJbWFnZX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9e3N0eWxlcy5mb3JtfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5pbnB1dFdyYXBwZXJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT17c3R5bGVzLmxhYmVsfSBodG1sRm9yPXtuYW1lSW5wdXRJZH0+Q2FwdGFpbidzIE5hbWU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e25hbWVJbnB1dElkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5pbnB1dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlR5cGUgeW91ciBuYW1lLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VybmFtZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXsyNH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmJ1dHRvbkdyb3VwfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT17c3R5bGVzLmJ1dHRvbn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGxheVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e3N0eWxlcy5idXR0b25TZWNvbmRhcnl9IG9uQ2xpY2s9eygpID0+IHNldFZpZXcoTWVudVZpZXdFbnVtLk9wdGlvbnMpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPcHRpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmZvb3RlckJ1dHRvbnN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e3N0eWxlcy5zbWFsbEJ1dHRvbn0gb25DbGljaz17KCkgPT4gc2V0VmlldyhNZW51Vmlld0VudW0uQ29udHJvbHMpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbnRyb2xzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9e3N0eWxlcy5zbWFsbEJ1dHRvbn0gb25DbGljaz17KCkgPT4gc2V0VmlldyhNZW51Vmlld0VudW0uUmFua2luZyl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmFua2luZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPXtzdHlsZXMuc21hbGxCdXR0b259IG9uQ2xpY2s9eygpID0+IHNldFZpZXcoTWVudVZpZXdFbnVtLkhpc3RvcnkpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEhpc3RvcnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtsYXN0TWF0Y2ggJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9e3N0eWxlcy5sYXN0TWF0Y2h9IGFyaWEtbGFiZWxsZWRieT17bGFzdE1hdGNoVGl0bGVJZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgaWQ9e2xhc3RNYXRjaFRpdGxlSWR9IGNsYXNzTmFtZT17c3R5bGVzLmxhc3RNYXRjaFRpdGxlfT5MYXN0IG1hdGNoPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9e3N0eWxlcy5sYXN0TWF0Y2hEZXRhaWxzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZHQ+U2NvcmU8L2R0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGQ+e2xhc3RNYXRjaC5zY29yZX08L2RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkdD5UaW1lIHBsYXllZDwvZHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkZD57Zm9ybWF0RHVyYXRpb24obGFzdE1hdGNoLmR1cmF0aW9uTXMpfTwvZGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGR0PlJlYXNvbjwvZHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkZD57RU5EX1JFQVNPTl9MQUJFTFtsYXN0TWF0Y2guZW5kUmVhc29uXX08L2RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnBlbmRpbmdOb3RpY2V9IHJvbGU9XCJzdGF0dXNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nLmxlbmd0aH0gbWF0Y2h7cGVuZGluZy5sZW5ndGggPiAxID8gJ2VzJyA6ICcnfSB3YWl0aW5nIHRvIHN5bmNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17c3R5bGVzLnNtYWxsQnV0dG9ufSBvbkNsaWNrPXtwZW5kaW5nUXVldWUucmVxdWVzdFN5bmN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJldHJ5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgKTtcclxuXHJcbn07XHJcbiJdfQ==