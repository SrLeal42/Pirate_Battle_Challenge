//#region node_modules/uuid/dist/max.js
var max_default = "ffffffff-ffff-ffff-ffff-ffffffffffff";
//#endregion
//#region node_modules/uuid/dist/nil.js
var nil_default = "00000000-0000-0000-0000-000000000000";
//#endregion
//#region node_modules/uuid/dist/regex.js
var regex_default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/i;
//#endregion
//#region node_modules/uuid/dist/validate.js
function validate(uuid) {
	return typeof uuid === "string" && regex_default.test(uuid);
}
//#endregion
//#region node_modules/uuid/dist/parse.js
function parse(uuid) {
	if (!validate(uuid)) throw TypeError("Invalid UUID");
	let v;
	return Uint8Array.of((v = parseInt(uuid.slice(0, 8), 16)) >>> 24, v >>> 16 & 255, v >>> 8 & 255, v & 255, (v = parseInt(uuid.slice(9, 13), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(14, 18), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(19, 23), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(24, 36), 16)) / 1099511627776 & 255, v / 4294967296 & 255, v >>> 24 & 255, v >>> 16 & 255, v >>> 8 & 255, v & 255);
}
//#endregion
//#region node_modules/uuid/dist/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) byteToHex.push((i + 256).toString(16).slice(1));
function unsafeStringify(arr, offset = 0) {
	return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}
function stringify(arr, offset = 0) {
	const uuid = unsafeStringify(arr, offset);
	if (!validate(uuid)) throw TypeError("Stringified UUID is invalid");
	return uuid;
}
//#endregion
//#region node_modules/uuid/dist/rng.js
var rnds8 = /* @__PURE__ */ new Uint8Array(16);
function rng() {
	return crypto.getRandomValues(rnds8);
}
//#endregion
//#region node_modules/uuid/dist/v1.js
var _state$1 = {};
function v1(options, buf, offset) {
	let bytes;
	const isV6 = options?._v6 ?? false;
	if (options) {
		const optionsKeys = Object.keys(options);
		if (optionsKeys.length === 1 && optionsKeys[0] === "_v6") options = void 0;
	}
	if (options) bytes = v1Bytes(options.random ?? options.rng?.() ?? rng(), options.msecs, options.nsecs, options.clockseq, options.node, buf, offset);
	else {
		const now = Date.now();
		const rnds = rng();
		updateV1State(_state$1, now, rnds);
		bytes = v1Bytes(rnds, _state$1.msecs, _state$1.nsecs, isV6 ? void 0 : _state$1.clockseq, isV6 ? void 0 : _state$1.node, buf, offset);
	}
	return buf ?? unsafeStringify(bytes);
}
function updateV1State(state, now, rnds) {
	state.msecs ??= -Infinity;
	state.nsecs ??= 0;
	if (now === state.msecs) {
		state.nsecs++;
		if (state.nsecs >= 1e4) {
			state.node = void 0;
			state.nsecs = 0;
		}
	} else if (now > state.msecs) state.nsecs = 0;
	else if (now < state.msecs) state.node = void 0;
	if (!state.node) {
		state.node = rnds.slice(10, 16);
		state.node[0] |= 1;
		state.clockseq = (rnds[8] << 8 | rnds[9]) & 16383;
	}
	state.msecs = now;
	return state;
}
function v1Bytes(rnds, msecs, nsecs, clockseq, node, buf, offset = 0) {
	if (rnds.length < 16) throw new Error("Random bytes length must be >= 16");
	if (!buf) {
		buf = /* @__PURE__ */ new Uint8Array(16);
		offset = 0;
	} else if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
	msecs ??= Date.now();
	nsecs ??= 0;
	clockseq ??= (rnds[8] << 8 | rnds[9]) & 16383;
	if (node == null) {
		node = rnds.slice(10, 16);
		node[0] |= 1;
	}
	msecs += 0xb1d069b5400;
	const t = (msecs & 268435455) * 1e4 + nsecs;
	const tl = t >>> 0;
	buf[offset++] = tl >>> 24 & 255;
	buf[offset++] = tl >>> 16 & 255;
	buf[offset++] = tl >>> 8 & 255;
	buf[offset++] = tl & 255;
	const tmh = (msecs / 268435456 | 0) * 625 + (t / 4294967296 | 0) & 268435455;
	buf[offset++] = tmh >>> 8 & 255;
	buf[offset++] = tmh & 255;
	buf[offset++] = tmh >>> 24 & 15 | 16;
	buf[offset++] = tmh >>> 16 & 255;
	buf[offset++] = clockseq >>> 8 | 128;
	buf[offset++] = clockseq & 255;
	for (let n = 0; n < 6; ++n) buf[offset++] = node[n];
	return buf;
}
//#endregion
//#region node_modules/uuid/dist/v1ToV6.js
function v1ToV6(uuid) {
	const v6Bytes = _v1ToV6(typeof uuid === "string" ? parse(uuid) : uuid);
	return typeof uuid === "string" ? unsafeStringify(v6Bytes) : v6Bytes;
}
function _v1ToV6(v1Bytes) {
	return Uint8Array.of((v1Bytes[6] & 15) << 4 | v1Bytes[7] >> 4 & 15, (v1Bytes[7] & 15) << 4 | (v1Bytes[4] & 240) >> 4, (v1Bytes[4] & 15) << 4 | (v1Bytes[5] & 240) >> 4, (v1Bytes[5] & 15) << 4 | (v1Bytes[0] & 240) >> 4, (v1Bytes[0] & 15) << 4 | (v1Bytes[1] & 240) >> 4, (v1Bytes[1] & 15) << 4 | (v1Bytes[2] & 240) >> 4, 96 | v1Bytes[2] & 15, v1Bytes[3], v1Bytes[8], v1Bytes[9], v1Bytes[10], v1Bytes[11], v1Bytes[12], v1Bytes[13], v1Bytes[14], v1Bytes[15]);
}
//#endregion
//#region node_modules/uuid/dist/md5.js
function md5(bytes) {
	return uint32ToUint8(wordsToMd5(uint8ToUint32(bytes), bytes.length * 8));
}
function uint32ToUint8(input) {
	const bytes = new Uint8Array(input.length * 4);
	for (let i = 0; i < input.length * 4; i++) bytes[i] = input[i >> 2] >>> i % 4 * 8 & 255;
	return bytes;
}
function getOutputLength(inputLength8) {
	return (inputLength8 + 64 >>> 9 << 4) + 14 + 1;
}
function wordsToMd5(x, len) {
	const xpad = new Uint32Array(getOutputLength(len)).fill(0);
	xpad.set(x);
	xpad[len >> 5] |= 128 << len % 32;
	xpad[xpad.length - 1] = len;
	x = xpad;
	let a = 1732584193;
	let b = -271733879;
	let c = -1732584194;
	let d = 271733878;
	for (let i = 0; i < x.length; i += 16) {
		const olda = a;
		const oldb = b;
		const oldc = c;
		const oldd = d;
		a = md5ff(a, b, c, d, x[i], 7, -680876936);
		d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
		c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
		b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
		a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
		d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
		c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
		b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
		a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
		d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
		c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
		b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
		a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
		d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
		c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
		b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
		a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
		d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
		c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
		b = md5gg(b, c, d, a, x[i], 20, -373897302);
		a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
		d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
		c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
		b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
		a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
		d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
		c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
		b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
		a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
		d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
		c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
		b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
		a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
		d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
		c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
		b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
		a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
		d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
		c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
		b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
		a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
		d = md5hh(d, a, b, c, x[i], 11, -358537222);
		c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
		b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
		a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
		d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
		c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
		b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
		a = md5ii(a, b, c, d, x[i], 6, -198630844);
		d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
		c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
		b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
		a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
		d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
		c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
		b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
		a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
		d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
		c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
		b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
		a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
		d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
		c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
		b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
		a = safeAdd(a, olda);
		b = safeAdd(b, oldb);
		c = safeAdd(c, oldc);
		d = safeAdd(d, oldd);
	}
	return Uint32Array.of(a, b, c, d);
}
function uint8ToUint32(input) {
	if (input.length === 0) return /* @__PURE__ */ new Uint32Array();
	const output = new Uint32Array(getOutputLength(input.length * 8)).fill(0);
	for (let i = 0; i < input.length; i++) output[i >> 2] |= (input[i] & 255) << i % 4 * 8;
	return output;
}
function safeAdd(x, y) {
	const lsw = (x & 65535) + (y & 65535);
	return (x >> 16) + (y >> 16) + (lsw >> 16) << 16 | lsw & 65535;
}
function bitRotateLeft(num, cnt) {
	return num << cnt | num >>> 32 - cnt;
}
function md5cmn(q, a, b, x, s, t) {
	return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}
function md5ff(a, b, c, d, x, s, t) {
	return md5cmn(b & c | ~b & d, a, b, x, s, t);
}
function md5gg(a, b, c, d, x, s, t) {
	return md5cmn(b & d | c & ~d, a, b, x, s, t);
}
function md5hh(a, b, c, d, x, s, t) {
	return md5cmn(b ^ c ^ d, a, b, x, s, t);
}
function md5ii(a, b, c, d, x, s, t) {
	return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}
//#endregion
//#region node_modules/uuid/dist/v35.js
function stringToBytes(str) {
	str = unescape(encodeURIComponent(str));
	const bytes = new Uint8Array(str.length);
	for (let i = 0; i < str.length; ++i) bytes[i] = str.charCodeAt(i);
	return bytes;
}
var DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
var URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
function v35(version, hash, value, namespace, buf, offset) {
	const valueBytes = typeof value === "string" ? stringToBytes(value) : value;
	const namespaceBytes = typeof namespace === "string" ? parse(namespace) : namespace;
	if (typeof namespace === "string") namespace = parse(namespace);
	if (namespace?.length !== 16) throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
	let bytes = new Uint8Array(16 + valueBytes.length);
	bytes.set(namespaceBytes);
	bytes.set(valueBytes, namespaceBytes.length);
	bytes = hash(bytes);
	bytes[6] = bytes[6] & 15 | version;
	bytes[8] = bytes[8] & 63 | 128;
	if (buf) {
		offset ??= 0;
		if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
		for (let i = 0; i < 16; ++i) buf[offset + i] = bytes[i];
		return buf;
	}
	return unsafeStringify(bytes);
}
//#endregion
//#region node_modules/uuid/dist/v3.js
function v3(value, namespace, buf, offset) {
	return v35(48, md5, value, namespace, buf, offset);
}
v3.DNS = DNS;
v3.URL = URL;
//#endregion
//#region node_modules/uuid/dist/v4.js
function v4(options, buf, offset) {
	if (!buf && !options && crypto.randomUUID) return crypto.randomUUID();
	return _v4(options, buf, offset);
}
function _v4(options, buf, offset) {
	options = options || {};
	const rnds = options.random ?? options.rng?.() ?? rng();
	if (rnds.length < 16) throw new Error("Random bytes length must be >= 16");
	rnds[6] = rnds[6] & 15 | 64;
	rnds[8] = rnds[8] & 63 | 128;
	if (buf) {
		offset = offset || 0;
		if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
		for (let i = 0; i < 16; ++i) buf[offset + i] = rnds[i];
		return buf;
	}
	return unsafeStringify(rnds);
}
//#endregion
//#region node_modules/uuid/dist/sha1.js
function f(s, x, y, z) {
	switch (s) {
		case 0: return x & y ^ ~x & z;
		case 1: return x ^ y ^ z;
		case 2: return x & y ^ x & z ^ y & z;
		case 3: return x ^ y ^ z;
	}
}
function ROTL(x, n) {
	return x << n | x >>> 32 - n;
}
function sha1(bytes) {
	const K = [
		1518500249,
		1859775393,
		2400959708,
		3395469782
	];
	const H = [
		1732584193,
		4023233417,
		2562383102,
		271733878,
		3285377520
	];
	const newBytes = new Uint8Array(bytes.length + 1);
	newBytes.set(bytes);
	newBytes[bytes.length] = 128;
	bytes = newBytes;
	const l = bytes.length / 4 + 2;
	const N = Math.ceil(l / 16);
	const M = new Array(N);
	for (let i = 0; i < N; ++i) {
		const arr = /* @__PURE__ */ new Uint32Array(16);
		for (let j = 0; j < 16; ++j) arr[j] = bytes[i * 64 + j * 4] << 24 | bytes[i * 64 + j * 4 + 1] << 16 | bytes[i * 64 + j * 4 + 2] << 8 | bytes[i * 64 + j * 4 + 3];
		M[i] = arr;
	}
	M[N - 1][14] = (bytes.length - 1) * 8 / 2 ** 32;
	M[N - 1][14] = Math.floor(M[N - 1][14]);
	M[N - 1][15] = (bytes.length - 1) * 8 & 4294967295;
	for (let i = 0; i < N; ++i) {
		const W = /* @__PURE__ */ new Uint32Array(80);
		for (let t = 0; t < 16; ++t) W[t] = M[i][t];
		for (let t = 16; t < 80; ++t) W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
		let a = H[0];
		let b = H[1];
		let c = H[2];
		let d = H[3];
		let e = H[4];
		for (let t = 0; t < 80; ++t) {
			const s = Math.floor(t / 20);
			const T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t] >>> 0;
			e = d;
			d = c;
			c = ROTL(b, 30) >>> 0;
			b = a;
			a = T;
		}
		H[0] = H[0] + a >>> 0;
		H[1] = H[1] + b >>> 0;
		H[2] = H[2] + c >>> 0;
		H[3] = H[3] + d >>> 0;
		H[4] = H[4] + e >>> 0;
	}
	return Uint8Array.of(H[0] >> 24, H[0] >> 16, H[0] >> 8, H[0], H[1] >> 24, H[1] >> 16, H[1] >> 8, H[1], H[2] >> 24, H[2] >> 16, H[2] >> 8, H[2], H[3] >> 24, H[3] >> 16, H[3] >> 8, H[3], H[4] >> 24, H[4] >> 16, H[4] >> 8, H[4]);
}
//#endregion
//#region node_modules/uuid/dist/v5.js
function v5(value, namespace, buf, offset) {
	return v35(80, sha1, value, namespace, buf, offset);
}
v5.DNS = DNS;
v5.URL = URL;
//#endregion
//#region node_modules/uuid/dist/v6.js
function v6(options, buf, offset) {
	options ??= {};
	offset ??= 0;
	let bytes = v1({
		...options,
		_v6: true
	}, /* @__PURE__ */ new Uint8Array(16));
	bytes = v1ToV6(bytes);
	if (buf) {
		if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
		for (let i = 0; i < 16; i++) buf[offset + i] = bytes[i];
		return buf;
	}
	return unsafeStringify(bytes);
}
//#endregion
//#region node_modules/uuid/dist/v6ToV1.js
function v6ToV1(uuid) {
	const v1Bytes = _v6ToV1(typeof uuid === "string" ? parse(uuid) : uuid);
	return typeof uuid === "string" ? unsafeStringify(v1Bytes) : v1Bytes;
}
function _v6ToV1(v6Bytes) {
	return Uint8Array.of((v6Bytes[3] & 15) << 4 | v6Bytes[4] >> 4 & 15, (v6Bytes[4] & 15) << 4 | (v6Bytes[5] & 240) >> 4, (v6Bytes[5] & 15) << 4 | v6Bytes[6] & 15, v6Bytes[7], (v6Bytes[1] & 15) << 4 | (v6Bytes[2] & 240) >> 4, (v6Bytes[2] & 15) << 4 | (v6Bytes[3] & 240) >> 4, 16 | (v6Bytes[0] & 240) >> 4, (v6Bytes[0] & 15) << 4 | (v6Bytes[1] & 240) >> 4, v6Bytes[8], v6Bytes[9], v6Bytes[10], v6Bytes[11], v6Bytes[12], v6Bytes[13], v6Bytes[14], v6Bytes[15]);
}
//#endregion
//#region node_modules/uuid/dist/v7.js
var _state = {};
function v7(options, buf, offset) {
	let bytes;
	if (options) bytes = v7Bytes(options.random ?? options.rng?.() ?? rng(), options.msecs, options.seq, buf, offset);
	else {
		const now = Date.now();
		const rnds = rng();
		updateV7State(_state, now, rnds);
		bytes = v7Bytes(rnds, _state.msecs, _state.seq, buf, offset);
	}
	return buf ?? unsafeStringify(bytes);
}
function updateV7State(state, now, rnds) {
	state.msecs ??= -Infinity;
	state.seq ??= 0;
	if (now > state.msecs) {
		state.seq = v7Sequence(rnds);
		state.msecs = now;
	} else {
		state.seq = state.seq + 1 | 0;
		if (state.seq === 0) state.msecs++;
	}
	return state;
}
function v7Bytes(rnds, msecs, seq, buf, offset = 0) {
	if (rnds.length < 16) throw new Error("Random bytes length must be >= 16");
	if (!buf) {
		buf = /* @__PURE__ */ new Uint8Array(16);
		offset = 0;
	} else if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
	msecs ??= Date.now();
	seq ??= v7Sequence(rnds);
	buf[offset++] = msecs / 1099511627776 & 255;
	buf[offset++] = msecs / 4294967296 & 255;
	buf[offset++] = msecs / 16777216 & 255;
	buf[offset++] = msecs / 65536 & 255;
	buf[offset++] = msecs / 256 & 255;
	buf[offset++] = msecs & 255;
	buf[offset++] = 112 | seq >>> 28 & 15;
	buf[offset++] = seq >>> 20 & 255;
	buf[offset++] = 128 | seq >>> 14 & 63;
	buf[offset++] = seq >>> 6 & 255;
	buf[offset++] = seq << 2 & 255 | rnds[10] & 3;
	buf[offset++] = rnds[11];
	buf[offset++] = rnds[12];
	buf[offset++] = rnds[13];
	buf[offset++] = rnds[14];
	buf[offset++] = rnds[15];
	return buf;
}
function v7Sequence(rnds) {
	return (rnds[6] & 127) << 24 | rnds[7] << 16 | rnds[8] << 8 | rnds[9];
}
//#endregion
//#region node_modules/uuid/dist/version.js
function version(uuid) {
	if (!validate(uuid)) throw TypeError("Invalid UUID");
	return parseInt(uuid.slice(14, 15), 16);
}
//#endregion
export { max_default as MAX, nil_default as NIL, parse, stringify, v1, v1ToV6, v3, v4, v5, v6, v6ToV1, v7, validate, version };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXVpZC5qcyIsIm5hbWVzIjpbIlJFR0VYIiwiX3N0YXRlIl0sInNvdXJjZXMiOlsiLi4vLi4vdXVpZC9kaXN0L21heC5qcyIsIi4uLy4uL3V1aWQvZGlzdC9uaWwuanMiLCIuLi8uLi91dWlkL2Rpc3QvcmVnZXguanMiLCIuLi8uLi91dWlkL2Rpc3QvdmFsaWRhdGUuanMiLCIuLi8uLi91dWlkL2Rpc3QvcGFyc2UuanMiLCIuLi8uLi91dWlkL2Rpc3Qvc3RyaW5naWZ5LmpzIiwiLi4vLi4vdXVpZC9kaXN0L3JuZy5qcyIsIi4uLy4uL3V1aWQvZGlzdC92MS5qcyIsIi4uLy4uL3V1aWQvZGlzdC92MVRvVjYuanMiLCIuLi8uLi91dWlkL2Rpc3QvbWQ1LmpzIiwiLi4vLi4vdXVpZC9kaXN0L3YzNS5qcyIsIi4uLy4uL3V1aWQvZGlzdC92My5qcyIsIi4uLy4uL3V1aWQvZGlzdC92NC5qcyIsIi4uLy4uL3V1aWQvZGlzdC9zaGExLmpzIiwiLi4vLi4vdXVpZC9kaXN0L3Y1LmpzIiwiLi4vLi4vdXVpZC9kaXN0L3Y2LmpzIiwiLi4vLi4vdXVpZC9kaXN0L3Y2VG9WMS5qcyIsIi4uLy4uL3V1aWQvZGlzdC92Ny5qcyIsIi4uLy4uL3V1aWQvZGlzdC92ZXJzaW9uLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0ICdmZmZmZmZmZi1mZmZmLWZmZmYtZmZmZi1mZmZmZmZmZmZmZmYnO1xuIiwiZXhwb3J0IGRlZmF1bHQgJzAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMCc7XG4iLCJleHBvcnQgZGVmYXVsdCAvXig/OlswLTlhLWZdezh9LVswLTlhLWZdezR9LVsxLThdWzAtOWEtZl17M30tWzg5YWJdWzAtOWEtZl17M30tWzAtOWEtZl17MTJ9fDAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMHxmZmZmZmZmZi1mZmZmLWZmZmYtZmZmZi1mZmZmZmZmZmZmZmYpJC9pO1xuIiwiaW1wb3J0IFJFR0VYIGZyb20gJy4vcmVnZXguanMnO1xuZnVuY3Rpb24gdmFsaWRhdGUodXVpZCkge1xuICAgIHJldHVybiB0eXBlb2YgdXVpZCA9PT0gJ3N0cmluZycgJiYgUkVHRVgudGVzdCh1dWlkKTtcbn1cbmV4cG9ydCBkZWZhdWx0IHZhbGlkYXRlO1xuIiwiaW1wb3J0IHZhbGlkYXRlIGZyb20gJy4vdmFsaWRhdGUuanMnO1xuZnVuY3Rpb24gcGFyc2UodXVpZCkge1xuICAgIGlmICghdmFsaWRhdGUodXVpZCkpIHtcbiAgICAgICAgdGhyb3cgVHlwZUVycm9yKCdJbnZhbGlkIFVVSUQnKTtcbiAgICB9XG4gICAgbGV0IHY7XG4gICAgcmV0dXJuIFVpbnQ4QXJyYXkub2YoKHYgPSBwYXJzZUludCh1dWlkLnNsaWNlKDAsIDgpLCAxNikpID4+PiAyNCwgKHYgPj4+IDE2KSAmIDB4ZmYsICh2ID4+PiA4KSAmIDB4ZmYsIHYgJiAweGZmLCAodiA9IHBhcnNlSW50KHV1aWQuc2xpY2UoOSwgMTMpLCAxNikpID4+PiA4LCB2ICYgMHhmZiwgKHYgPSBwYXJzZUludCh1dWlkLnNsaWNlKDE0LCAxOCksIDE2KSkgPj4+IDgsIHYgJiAweGZmLCAodiA9IHBhcnNlSW50KHV1aWQuc2xpY2UoMTksIDIzKSwgMTYpKSA+Pj4gOCwgdiAmIDB4ZmYsICgodiA9IHBhcnNlSW50KHV1aWQuc2xpY2UoMjQsIDM2KSwgMTYpKSAvIDB4MTAwMDAwMDAwMDApICYgMHhmZiwgKHYgLyAweDEwMDAwMDAwMCkgJiAweGZmLCAodiA+Pj4gMjQpICYgMHhmZiwgKHYgPj4+IDE2KSAmIDB4ZmYsICh2ID4+PiA4KSAmIDB4ZmYsIHYgJiAweGZmKTtcbn1cbmV4cG9ydCBkZWZhdWx0IHBhcnNlO1xuIiwiaW1wb3J0IHZhbGlkYXRlIGZyb20gJy4vdmFsaWRhdGUuanMnO1xuY29uc3QgYnl0ZVRvSGV4ID0gW107XG5mb3IgKGxldCBpID0gMDsgaSA8IDI1NjsgKytpKSB7XG4gICAgYnl0ZVRvSGV4LnB1c2goKGkgKyAweDEwMCkudG9TdHJpbmcoMTYpLnNsaWNlKDEpKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB1bnNhZmVTdHJpbmdpZnkoYXJyLCBvZmZzZXQgPSAwKSB7XG4gICAgcmV0dXJuIChieXRlVG9IZXhbYXJyW29mZnNldCArIDBdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMV1dICtcbiAgICAgICAgYnl0ZVRvSGV4W2FycltvZmZzZXQgKyAyXV0gK1xuICAgICAgICBieXRlVG9IZXhbYXJyW29mZnNldCArIDNdXSArXG4gICAgICAgICctJyArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgNF1dICtcbiAgICAgICAgYnl0ZVRvSGV4W2FycltvZmZzZXQgKyA1XV0gK1xuICAgICAgICAnLScgK1xuICAgICAgICBieXRlVG9IZXhbYXJyW29mZnNldCArIDZdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgN11dICtcbiAgICAgICAgJy0nICtcbiAgICAgICAgYnl0ZVRvSGV4W2FycltvZmZzZXQgKyA4XV0gK1xuICAgICAgICBieXRlVG9IZXhbYXJyW29mZnNldCArIDldXSArXG4gICAgICAgICctJyArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTBdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTFdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTJdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTNdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTRdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTVdXSkudG9Mb3dlckNhc2UoKTtcbn1cbmZ1bmN0aW9uIHN0cmluZ2lmeShhcnIsIG9mZnNldCA9IDApIHtcbiAgICBjb25zdCB1dWlkID0gdW5zYWZlU3RyaW5naWZ5KGFyciwgb2Zmc2V0KTtcbiAgICBpZiAoIXZhbGlkYXRlKHV1aWQpKSB7XG4gICAgICAgIHRocm93IFR5cGVFcnJvcignU3RyaW5naWZpZWQgVVVJRCBpcyBpbnZhbGlkJyk7XG4gICAgfVxuICAgIHJldHVybiB1dWlkO1xufVxuZXhwb3J0IGRlZmF1bHQgc3RyaW5naWZ5O1xuIiwiY29uc3Qgcm5kczggPSBuZXcgVWludDhBcnJheSgxNik7XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBybmcoKSB7XG4gICAgcmV0dXJuIGNyeXB0by5nZXRSYW5kb21WYWx1ZXMocm5kczgpO1xufVxuIiwiaW1wb3J0IHJuZyBmcm9tICcuL3JuZy5qcyc7XG5pbXBvcnQgeyB1bnNhZmVTdHJpbmdpZnkgfSBmcm9tICcuL3N0cmluZ2lmeS5qcyc7XG5jb25zdCBfc3RhdGUgPSB7fTtcbmZ1bmN0aW9uIHYxKG9wdGlvbnMsIGJ1Ziwgb2Zmc2V0KSB7XG4gICAgbGV0IGJ5dGVzO1xuICAgIGNvbnN0IGlzVjYgPSBvcHRpb25zPy5fdjYgPz8gZmFsc2U7XG4gICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3Qgb3B0aW9uc0tleXMgPSBPYmplY3Qua2V5cyhvcHRpb25zKTtcbiAgICAgICAgaWYgKG9wdGlvbnNLZXlzLmxlbmd0aCA9PT0gMSAmJiBvcHRpb25zS2V5c1swXSA9PT0gJ192NicpIHtcbiAgICAgICAgICAgIG9wdGlvbnMgPSB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgICAgYnl0ZXMgPSB2MUJ5dGVzKG9wdGlvbnMucmFuZG9tID8/IG9wdGlvbnMucm5nPy4oKSA/PyBybmcoKSwgb3B0aW9ucy5tc2Vjcywgb3B0aW9ucy5uc2Vjcywgb3B0aW9ucy5jbG9ja3NlcSwgb3B0aW9ucy5ub2RlLCBidWYsIG9mZnNldCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgICAgICBjb25zdCBybmRzID0gcm5nKCk7XG4gICAgICAgIHVwZGF0ZVYxU3RhdGUoX3N0YXRlLCBub3csIHJuZHMpO1xuICAgICAgICBieXRlcyA9IHYxQnl0ZXMocm5kcywgX3N0YXRlLm1zZWNzLCBfc3RhdGUubnNlY3MsIGlzVjYgPyB1bmRlZmluZWQgOiBfc3RhdGUuY2xvY2tzZXEsIGlzVjYgPyB1bmRlZmluZWQgOiBfc3RhdGUubm9kZSwgYnVmLCBvZmZzZXQpO1xuICAgIH1cbiAgICByZXR1cm4gYnVmID8/IHVuc2FmZVN0cmluZ2lmeShieXRlcyk7XG59XG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlVjFTdGF0ZShzdGF0ZSwgbm93LCBybmRzKSB7XG4gICAgc3RhdGUubXNlY3MgPz89IC1JbmZpbml0eTtcbiAgICBzdGF0ZS5uc2VjcyA/Pz0gMDtcbiAgICBpZiAobm93ID09PSBzdGF0ZS5tc2Vjcykge1xuICAgICAgICBzdGF0ZS5uc2VjcysrO1xuICAgICAgICBpZiAoc3RhdGUubnNlY3MgPj0gMTAwMDApIHtcbiAgICAgICAgICAgIHN0YXRlLm5vZGUgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICBzdGF0ZS5uc2VjcyA9IDA7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSBpZiAobm93ID4gc3RhdGUubXNlY3MpIHtcbiAgICAgICAgc3RhdGUubnNlY3MgPSAwO1xuICAgIH1cbiAgICBlbHNlIGlmIChub3cgPCBzdGF0ZS5tc2Vjcykge1xuICAgICAgICBzdGF0ZS5ub2RlID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAoIXN0YXRlLm5vZGUpIHtcbiAgICAgICAgc3RhdGUubm9kZSA9IHJuZHMuc2xpY2UoMTAsIDE2KTtcbiAgICAgICAgc3RhdGUubm9kZVswXSB8PSAweDAxO1xuICAgICAgICBzdGF0ZS5jbG9ja3NlcSA9ICgocm5kc1s4XSA8PCA4KSB8IHJuZHNbOV0pICYgMHgzZmZmO1xuICAgIH1cbiAgICBzdGF0ZS5tc2VjcyA9IG5vdztcbiAgICByZXR1cm4gc3RhdGU7XG59XG5mdW5jdGlvbiB2MUJ5dGVzKHJuZHMsIG1zZWNzLCBuc2VjcywgY2xvY2tzZXEsIG5vZGUsIGJ1Ziwgb2Zmc2V0ID0gMCkge1xuICAgIGlmIChybmRzLmxlbmd0aCA8IDE2KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignUmFuZG9tIGJ5dGVzIGxlbmd0aCBtdXN0IGJlID49IDE2Jyk7XG4gICAgfVxuICAgIGlmICghYnVmKSB7XG4gICAgICAgIGJ1ZiA9IG5ldyBVaW50OEFycmF5KDE2KTtcbiAgICAgICAgb2Zmc2V0ID0gMDtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGlmIChvZmZzZXQgPCAwIHx8IG9mZnNldCArIDE2ID4gYnVmLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYFVVSUQgYnl0ZSByYW5nZSAke29mZnNldH06JHtvZmZzZXQgKyAxNX0gaXMgb3V0IG9mIGJ1ZmZlciBib3VuZHNgKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBtc2VjcyA/Pz0gRGF0ZS5ub3coKTtcbiAgICBuc2VjcyA/Pz0gMDtcbiAgICBjbG9ja3NlcSA/Pz0gKChybmRzWzhdIDw8IDgpIHwgcm5kc1s5XSkgJiAweDNmZmY7XG4gICAgaWYgKG5vZGUgPT0gbnVsbCkge1xuICAgICAgICBub2RlID0gcm5kcy5zbGljZSgxMCwgMTYpO1xuICAgICAgICBub2RlWzBdIHw9IDB4MDE7XG4gICAgfVxuICAgIG1zZWNzICs9IDEyMjE5MjkyODAwMDAwO1xuICAgIGNvbnN0IHQgPSAobXNlY3MgJiAweGZmZmZmZmYpICogMTAwMDAgKyBuc2VjcztcbiAgICBjb25zdCB0bCA9IHQgPj4+IDA7XG4gICAgYnVmW29mZnNldCsrXSA9ICh0bCA+Pj4gMjQpICYgMHhmZjtcbiAgICBidWZbb2Zmc2V0KytdID0gKHRsID4+PiAxNikgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAodGwgPj4+IDgpICYgMHhmZjtcbiAgICBidWZbb2Zmc2V0KytdID0gdGwgJiAweGZmO1xuICAgIGNvbnN0IHRtaCA9ICgoKG1zZWNzIC8gMHgxMDAwMDAwMCkgfCAwKSAqIDYyNSArICgodCAvIDB4MTAwMDAwMDAwKSB8IDApKSAmIDB4ZmZmZmZmZjtcbiAgICBidWZbb2Zmc2V0KytdID0gKHRtaCA+Pj4gOCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSB0bWggJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAoKHRtaCA+Pj4gMjQpICYgMHhmKSB8IDB4MTA7XG4gICAgYnVmW29mZnNldCsrXSA9ICh0bWggPj4+IDE2KSAmIDB4ZmY7XG4gICAgYnVmW29mZnNldCsrXSA9IChjbG9ja3NlcSA+Pj4gOCkgfCAweDgwO1xuICAgIGJ1ZltvZmZzZXQrK10gPSBjbG9ja3NlcSAmIDB4ZmY7XG4gICAgZm9yIChsZXQgbiA9IDA7IG4gPCA2OyArK24pIHtcbiAgICAgICAgYnVmW29mZnNldCsrXSA9IG5vZGVbbl07XG4gICAgfVxuICAgIHJldHVybiBidWY7XG59XG5leHBvcnQgZGVmYXVsdCB2MTtcbiIsImltcG9ydCBwYXJzZSBmcm9tICcuL3BhcnNlLmpzJztcbmltcG9ydCB7IHVuc2FmZVN0cmluZ2lmeSB9IGZyb20gJy4vc3RyaW5naWZ5LmpzJztcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHYxVG9WNih1dWlkKSB7XG4gICAgY29uc3QgdjFCeXRlcyA9IHR5cGVvZiB1dWlkID09PSAnc3RyaW5nJyA/IHBhcnNlKHV1aWQpIDogdXVpZDtcbiAgICBjb25zdCB2NkJ5dGVzID0gX3YxVG9WNih2MUJ5dGVzKTtcbiAgICByZXR1cm4gdHlwZW9mIHV1aWQgPT09ICdzdHJpbmcnID8gdW5zYWZlU3RyaW5naWZ5KHY2Qnl0ZXMpIDogdjZCeXRlcztcbn1cbmZ1bmN0aW9uIF92MVRvVjYodjFCeXRlcykge1xuICAgIHJldHVybiBVaW50OEFycmF5Lm9mKCgodjFCeXRlc1s2XSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzddID4+IDQpICYgMHgwZiksICgodjFCeXRlc1s3XSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzRdICYgMHhmMCkgPj4gNCksICgodjFCeXRlc1s0XSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzVdICYgMHhmMCkgPj4gNCksICgodjFCeXRlc1s1XSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzBdICYgMHhmMCkgPj4gNCksICgodjFCeXRlc1swXSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzFdICYgMHhmMCkgPj4gNCksICgodjFCeXRlc1sxXSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzJdICYgMHhmMCkgPj4gNCksIDB4NjAgfCAodjFCeXRlc1syXSAmIDB4MGYpLCB2MUJ5dGVzWzNdLCB2MUJ5dGVzWzhdLCB2MUJ5dGVzWzldLCB2MUJ5dGVzWzEwXSwgdjFCeXRlc1sxMV0sIHYxQnl0ZXNbMTJdLCB2MUJ5dGVzWzEzXSwgdjFCeXRlc1sxNF0sIHYxQnl0ZXNbMTVdKTtcbn1cbiIsImZ1bmN0aW9uIG1kNShieXRlcykge1xuICAgIGNvbnN0IHdvcmRzID0gdWludDhUb1VpbnQzMihieXRlcyk7XG4gICAgY29uc3QgbWQ1Qnl0ZXMgPSB3b3Jkc1RvTWQ1KHdvcmRzLCBieXRlcy5sZW5ndGggKiA4KTtcbiAgICByZXR1cm4gdWludDMyVG9VaW50OChtZDVCeXRlcyk7XG59XG5mdW5jdGlvbiB1aW50MzJUb1VpbnQ4KGlucHV0KSB7XG4gICAgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShpbnB1dC5sZW5ndGggKiA0KTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlucHV0Lmxlbmd0aCAqIDQ7IGkrKykge1xuICAgICAgICBieXRlc1tpXSA9IChpbnB1dFtpID4+IDJdID4+PiAoKGkgJSA0KSAqIDgpKSAmIDB4ZmY7XG4gICAgfVxuICAgIHJldHVybiBieXRlcztcbn1cbmZ1bmN0aW9uIGdldE91dHB1dExlbmd0aChpbnB1dExlbmd0aDgpIHtcbiAgICByZXR1cm4gKCgoaW5wdXRMZW5ndGg4ICsgNjQpID4+PiA5KSA8PCA0KSArIDE0ICsgMTtcbn1cbmZ1bmN0aW9uIHdvcmRzVG9NZDUoeCwgbGVuKSB7XG4gICAgY29uc3QgeHBhZCA9IG5ldyBVaW50MzJBcnJheShnZXRPdXRwdXRMZW5ndGgobGVuKSkuZmlsbCgwKTtcbiAgICB4cGFkLnNldCh4KTtcbiAgICB4cGFkW2xlbiA+PiA1XSB8PSAweDgwIDw8IChsZW4gJSAzMik7XG4gICAgeHBhZFt4cGFkLmxlbmd0aCAtIDFdID0gbGVuO1xuICAgIHggPSB4cGFkO1xuICAgIGxldCBhID0gMTczMjU4NDE5MztcbiAgICBsZXQgYiA9IC0yNzE3MzM4Nzk7XG4gICAgbGV0IGMgPSAtMTczMjU4NDE5NDtcbiAgICBsZXQgZCA9IDI3MTczMzg3ODtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHgubGVuZ3RoOyBpICs9IDE2KSB7XG4gICAgICAgIGNvbnN0IG9sZGEgPSBhO1xuICAgICAgICBjb25zdCBvbGRiID0gYjtcbiAgICAgICAgY29uc3Qgb2xkYyA9IGM7XG4gICAgICAgIGNvbnN0IG9sZGQgPSBkO1xuICAgICAgICBhID0gbWQ1ZmYoYSwgYiwgYywgZCwgeFtpXSwgNywgLTY4MDg3NjkzNik7XG4gICAgICAgIGQgPSBtZDVmZihkLCBhLCBiLCBjLCB4W2kgKyAxXSwgMTIsIC0zODk1NjQ1ODYpO1xuICAgICAgICBjID0gbWQ1ZmYoYywgZCwgYSwgYiwgeFtpICsgMl0sIDE3LCA2MDYxMDU4MTkpO1xuICAgICAgICBiID0gbWQ1ZmYoYiwgYywgZCwgYSwgeFtpICsgM10sIDIyLCAtMTA0NDUyNTMzMCk7XG4gICAgICAgIGEgPSBtZDVmZihhLCBiLCBjLCBkLCB4W2kgKyA0XSwgNywgLTE3NjQxODg5Nyk7XG4gICAgICAgIGQgPSBtZDVmZihkLCBhLCBiLCBjLCB4W2kgKyA1XSwgMTIsIDEyMDAwODA0MjYpO1xuICAgICAgICBjID0gbWQ1ZmYoYywgZCwgYSwgYiwgeFtpICsgNl0sIDE3LCAtMTQ3MzIzMTM0MSk7XG4gICAgICAgIGIgPSBtZDVmZihiLCBjLCBkLCBhLCB4W2kgKyA3XSwgMjIsIC00NTcwNTk4Myk7XG4gICAgICAgIGEgPSBtZDVmZihhLCBiLCBjLCBkLCB4W2kgKyA4XSwgNywgMTc3MDAzNTQxNik7XG4gICAgICAgIGQgPSBtZDVmZihkLCBhLCBiLCBjLCB4W2kgKyA5XSwgMTIsIC0xOTU4NDE0NDE3KTtcbiAgICAgICAgYyA9IG1kNWZmKGMsIGQsIGEsIGIsIHhbaSArIDEwXSwgMTcsIC00MjA2Myk7XG4gICAgICAgIGIgPSBtZDVmZihiLCBjLCBkLCBhLCB4W2kgKyAxMV0sIDIyLCAtMTk5MDQwNDE2Mik7XG4gICAgICAgIGEgPSBtZDVmZihhLCBiLCBjLCBkLCB4W2kgKyAxMl0sIDcsIDE4MDQ2MDM2ODIpO1xuICAgICAgICBkID0gbWQ1ZmYoZCwgYSwgYiwgYywgeFtpICsgMTNdLCAxMiwgLTQwMzQxMTAxKTtcbiAgICAgICAgYyA9IG1kNWZmKGMsIGQsIGEsIGIsIHhbaSArIDE0XSwgMTcsIC0xNTAyMDAyMjkwKTtcbiAgICAgICAgYiA9IG1kNWZmKGIsIGMsIGQsIGEsIHhbaSArIDE1XSwgMjIsIDEyMzY1MzUzMjkpO1xuICAgICAgICBhID0gbWQ1Z2coYSwgYiwgYywgZCwgeFtpICsgMV0sIDUsIC0xNjU3OTY1MTApO1xuICAgICAgICBkID0gbWQ1Z2coZCwgYSwgYiwgYywgeFtpICsgNl0sIDksIC0xMDY5NTAxNjMyKTtcbiAgICAgICAgYyA9IG1kNWdnKGMsIGQsIGEsIGIsIHhbaSArIDExXSwgMTQsIDY0MzcxNzcxMyk7XG4gICAgICAgIGIgPSBtZDVnZyhiLCBjLCBkLCBhLCB4W2ldLCAyMCwgLTM3Mzg5NzMwMik7XG4gICAgICAgIGEgPSBtZDVnZyhhLCBiLCBjLCBkLCB4W2kgKyA1XSwgNSwgLTcwMTU1ODY5MSk7XG4gICAgICAgIGQgPSBtZDVnZyhkLCBhLCBiLCBjLCB4W2kgKyAxMF0sIDksIDM4MDE2MDgzKTtcbiAgICAgICAgYyA9IG1kNWdnKGMsIGQsIGEsIGIsIHhbaSArIDE1XSwgMTQsIC02NjA0NzgzMzUpO1xuICAgICAgICBiID0gbWQ1Z2coYiwgYywgZCwgYSwgeFtpICsgNF0sIDIwLCAtNDA1NTM3ODQ4KTtcbiAgICAgICAgYSA9IG1kNWdnKGEsIGIsIGMsIGQsIHhbaSArIDldLCA1LCA1Njg0NDY0MzgpO1xuICAgICAgICBkID0gbWQ1Z2coZCwgYSwgYiwgYywgeFtpICsgMTRdLCA5LCAtMTAxOTgwMzY5MCk7XG4gICAgICAgIGMgPSBtZDVnZyhjLCBkLCBhLCBiLCB4W2kgKyAzXSwgMTQsIC0xODczNjM5NjEpO1xuICAgICAgICBiID0gbWQ1Z2coYiwgYywgZCwgYSwgeFtpICsgOF0sIDIwLCAxMTYzNTMxNTAxKTtcbiAgICAgICAgYSA9IG1kNWdnKGEsIGIsIGMsIGQsIHhbaSArIDEzXSwgNSwgLTE0NDQ2ODE0NjcpO1xuICAgICAgICBkID0gbWQ1Z2coZCwgYSwgYiwgYywgeFtpICsgMl0sIDksIC01MTQwMzc4NCk7XG4gICAgICAgIGMgPSBtZDVnZyhjLCBkLCBhLCBiLCB4W2kgKyA3XSwgMTQsIDE3MzUzMjg0NzMpO1xuICAgICAgICBiID0gbWQ1Z2coYiwgYywgZCwgYSwgeFtpICsgMTJdLCAyMCwgLTE5MjY2MDc3MzQpO1xuICAgICAgICBhID0gbWQ1aGgoYSwgYiwgYywgZCwgeFtpICsgNV0sIDQsIC0zNzg1NTgpO1xuICAgICAgICBkID0gbWQ1aGgoZCwgYSwgYiwgYywgeFtpICsgOF0sIDExLCAtMjAyMjU3NDQ2Myk7XG4gICAgICAgIGMgPSBtZDVoaChjLCBkLCBhLCBiLCB4W2kgKyAxMV0sIDE2LCAxODM5MDMwNTYyKTtcbiAgICAgICAgYiA9IG1kNWhoKGIsIGMsIGQsIGEsIHhbaSArIDE0XSwgMjMsIC0zNTMwOTU1Nik7XG4gICAgICAgIGEgPSBtZDVoaChhLCBiLCBjLCBkLCB4W2kgKyAxXSwgNCwgLTE1MzA5OTIwNjApO1xuICAgICAgICBkID0gbWQ1aGgoZCwgYSwgYiwgYywgeFtpICsgNF0sIDExLCAxMjcyODkzMzUzKTtcbiAgICAgICAgYyA9IG1kNWhoKGMsIGQsIGEsIGIsIHhbaSArIDddLCAxNiwgLTE1NTQ5NzYzMik7XG4gICAgICAgIGIgPSBtZDVoaChiLCBjLCBkLCBhLCB4W2kgKyAxMF0sIDIzLCAtMTA5NDczMDY0MCk7XG4gICAgICAgIGEgPSBtZDVoaChhLCBiLCBjLCBkLCB4W2kgKyAxM10sIDQsIDY4MTI3OTE3NCk7XG4gICAgICAgIGQgPSBtZDVoaChkLCBhLCBiLCBjLCB4W2ldLCAxMSwgLTM1ODUzNzIyMik7XG4gICAgICAgIGMgPSBtZDVoaChjLCBkLCBhLCBiLCB4W2kgKyAzXSwgMTYsIC03MjI1MjE5NzkpO1xuICAgICAgICBiID0gbWQ1aGgoYiwgYywgZCwgYSwgeFtpICsgNl0sIDIzLCA3NjAyOTE4OSk7XG4gICAgICAgIGEgPSBtZDVoaChhLCBiLCBjLCBkLCB4W2kgKyA5XSwgNCwgLTY0MDM2NDQ4Nyk7XG4gICAgICAgIGQgPSBtZDVoaChkLCBhLCBiLCBjLCB4W2kgKyAxMl0sIDExLCAtNDIxODE1ODM1KTtcbiAgICAgICAgYyA9IG1kNWhoKGMsIGQsIGEsIGIsIHhbaSArIDE1XSwgMTYsIDUzMDc0MjUyMCk7XG4gICAgICAgIGIgPSBtZDVoaChiLCBjLCBkLCBhLCB4W2kgKyAyXSwgMjMsIC05OTUzMzg2NTEpO1xuICAgICAgICBhID0gbWQ1aWkoYSwgYiwgYywgZCwgeFtpXSwgNiwgLTE5ODYzMDg0NCk7XG4gICAgICAgIGQgPSBtZDVpaShkLCBhLCBiLCBjLCB4W2kgKyA3XSwgMTAsIDExMjY4OTE0MTUpO1xuICAgICAgICBjID0gbWQ1aWkoYywgZCwgYSwgYiwgeFtpICsgMTRdLCAxNSwgLTE0MTYzNTQ5MDUpO1xuICAgICAgICBiID0gbWQ1aWkoYiwgYywgZCwgYSwgeFtpICsgNV0sIDIxLCAtNTc0MzQwNTUpO1xuICAgICAgICBhID0gbWQ1aWkoYSwgYiwgYywgZCwgeFtpICsgMTJdLCA2LCAxNzAwNDg1NTcxKTtcbiAgICAgICAgZCA9IG1kNWlpKGQsIGEsIGIsIGMsIHhbaSArIDNdLCAxMCwgLTE4OTQ5ODY2MDYpO1xuICAgICAgICBjID0gbWQ1aWkoYywgZCwgYSwgYiwgeFtpICsgMTBdLCAxNSwgLTEwNTE1MjMpO1xuICAgICAgICBiID0gbWQ1aWkoYiwgYywgZCwgYSwgeFtpICsgMV0sIDIxLCAtMjA1NDkyMjc5OSk7XG4gICAgICAgIGEgPSBtZDVpaShhLCBiLCBjLCBkLCB4W2kgKyA4XSwgNiwgMTg3MzMxMzM1OSk7XG4gICAgICAgIGQgPSBtZDVpaShkLCBhLCBiLCBjLCB4W2kgKyAxNV0sIDEwLCAtMzA2MTE3NDQpO1xuICAgICAgICBjID0gbWQ1aWkoYywgZCwgYSwgYiwgeFtpICsgNl0sIDE1LCAtMTU2MDE5ODM4MCk7XG4gICAgICAgIGIgPSBtZDVpaShiLCBjLCBkLCBhLCB4W2kgKyAxM10sIDIxLCAxMzA5MTUxNjQ5KTtcbiAgICAgICAgYSA9IG1kNWlpKGEsIGIsIGMsIGQsIHhbaSArIDRdLCA2LCAtMTQ1NTIzMDcwKTtcbiAgICAgICAgZCA9IG1kNWlpKGQsIGEsIGIsIGMsIHhbaSArIDExXSwgMTAsIC0xMTIwMjEwMzc5KTtcbiAgICAgICAgYyA9IG1kNWlpKGMsIGQsIGEsIGIsIHhbaSArIDJdLCAxNSwgNzE4Nzg3MjU5KTtcbiAgICAgICAgYiA9IG1kNWlpKGIsIGMsIGQsIGEsIHhbaSArIDldLCAyMSwgLTM0MzQ4NTU1MSk7XG4gICAgICAgIGEgPSBzYWZlQWRkKGEsIG9sZGEpO1xuICAgICAgICBiID0gc2FmZUFkZChiLCBvbGRiKTtcbiAgICAgICAgYyA9IHNhZmVBZGQoYywgb2xkYyk7XG4gICAgICAgIGQgPSBzYWZlQWRkKGQsIG9sZGQpO1xuICAgIH1cbiAgICByZXR1cm4gVWludDMyQXJyYXkub2YoYSwgYiwgYywgZCk7XG59XG5mdW5jdGlvbiB1aW50OFRvVWludDMyKGlucHV0KSB7XG4gICAgaWYgKGlucHV0Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gbmV3IFVpbnQzMkFycmF5KCk7XG4gICAgfVxuICAgIGNvbnN0IG91dHB1dCA9IG5ldyBVaW50MzJBcnJheShnZXRPdXRwdXRMZW5ndGgoaW5wdXQubGVuZ3RoICogOCkpLmZpbGwoMCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnB1dC5sZW5ndGg7IGkrKykge1xuICAgICAgICBvdXRwdXRbaSA+PiAyXSB8PSAoaW5wdXRbaV0gJiAweGZmKSA8PCAoKGkgJSA0KSAqIDgpO1xuICAgIH1cbiAgICByZXR1cm4gb3V0cHV0O1xufVxuZnVuY3Rpb24gc2FmZUFkZCh4LCB5KSB7XG4gICAgY29uc3QgbHN3ID0gKHggJiAweGZmZmYpICsgKHkgJiAweGZmZmYpO1xuICAgIGNvbnN0IG1zdyA9ICh4ID4+IDE2KSArICh5ID4+IDE2KSArIChsc3cgPj4gMTYpO1xuICAgIHJldHVybiAobXN3IDw8IDE2KSB8IChsc3cgJiAweGZmZmYpO1xufVxuZnVuY3Rpb24gYml0Um90YXRlTGVmdChudW0sIGNudCkge1xuICAgIHJldHVybiAobnVtIDw8IGNudCkgfCAobnVtID4+PiAoMzIgLSBjbnQpKTtcbn1cbmZ1bmN0aW9uIG1kNWNtbihxLCBhLCBiLCB4LCBzLCB0KSB7XG4gICAgcmV0dXJuIHNhZmVBZGQoYml0Um90YXRlTGVmdChzYWZlQWRkKHNhZmVBZGQoYSwgcSksIHNhZmVBZGQoeCwgdCkpLCBzKSwgYik7XG59XG5mdW5jdGlvbiBtZDVmZihhLCBiLCBjLCBkLCB4LCBzLCB0KSB7XG4gICAgcmV0dXJuIG1kNWNtbigoYiAmIGMpIHwgKH5iICYgZCksIGEsIGIsIHgsIHMsIHQpO1xufVxuZnVuY3Rpb24gbWQ1Z2coYSwgYiwgYywgZCwgeCwgcywgdCkge1xuICAgIHJldHVybiBtZDVjbW4oKGIgJiBkKSB8IChjICYgfmQpLCBhLCBiLCB4LCBzLCB0KTtcbn1cbmZ1bmN0aW9uIG1kNWhoKGEsIGIsIGMsIGQsIHgsIHMsIHQpIHtcbiAgICByZXR1cm4gbWQ1Y21uKGIgXiBjIF4gZCwgYSwgYiwgeCwgcywgdCk7XG59XG5mdW5jdGlvbiBtZDVpaShhLCBiLCBjLCBkLCB4LCBzLCB0KSB7XG4gICAgcmV0dXJuIG1kNWNtbihjIF4gKGIgfCB+ZCksIGEsIGIsIHgsIHMsIHQpO1xufVxuZXhwb3J0IGRlZmF1bHQgbWQ1O1xuIiwiaW1wb3J0IHBhcnNlIGZyb20gJy4vcGFyc2UuanMnO1xuaW1wb3J0IHsgdW5zYWZlU3RyaW5naWZ5IH0gZnJvbSAnLi9zdHJpbmdpZnkuanMnO1xuZXhwb3J0IGZ1bmN0aW9uIHN0cmluZ1RvQnl0ZXMoc3RyKSB7XG4gICAgc3RyID0gdW5lc2NhcGUoZW5jb2RlVVJJQ29tcG9uZW50KHN0cikpO1xuICAgIGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoc3RyLmxlbmd0aCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgYnl0ZXNbaV0gPSBzdHIuY2hhckNvZGVBdChpKTtcbiAgICB9XG4gICAgcmV0dXJuIGJ5dGVzO1xufVxuZXhwb3J0IGNvbnN0IEROUyA9ICc2YmE3YjgxMC05ZGFkLTExZDEtODBiNC0wMGMwNGZkNDMwYzgnO1xuZXhwb3J0IGNvbnN0IFVSTCA9ICc2YmE3YjgxMS05ZGFkLTExZDEtODBiNC0wMGMwNGZkNDMwYzgnO1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gdjM1KHZlcnNpb24sIGhhc2gsIHZhbHVlLCBuYW1lc3BhY2UsIGJ1Ziwgb2Zmc2V0KSB7XG4gICAgY29uc3QgdmFsdWVCeXRlcyA9IHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgPyBzdHJpbmdUb0J5dGVzKHZhbHVlKSA6IHZhbHVlO1xuICAgIGNvbnN0IG5hbWVzcGFjZUJ5dGVzID0gdHlwZW9mIG5hbWVzcGFjZSA9PT0gJ3N0cmluZycgPyBwYXJzZShuYW1lc3BhY2UpIDogbmFtZXNwYWNlO1xuICAgIGlmICh0eXBlb2YgbmFtZXNwYWNlID09PSAnc3RyaW5nJykge1xuICAgICAgICBuYW1lc3BhY2UgPSBwYXJzZShuYW1lc3BhY2UpO1xuICAgIH1cbiAgICBpZiAobmFtZXNwYWNlPy5sZW5ndGggIT09IDE2KSB7XG4gICAgICAgIHRocm93IFR5cGVFcnJvcignTmFtZXNwYWNlIG11c3QgYmUgYXJyYXktbGlrZSAoMTYgaXRlcmFibGUgaW50ZWdlciB2YWx1ZXMsIDAtMjU1KScpO1xuICAgIH1cbiAgICBsZXQgYnl0ZXMgPSBuZXcgVWludDhBcnJheSgxNiArIHZhbHVlQnl0ZXMubGVuZ3RoKTtcbiAgICBieXRlcy5zZXQobmFtZXNwYWNlQnl0ZXMpO1xuICAgIGJ5dGVzLnNldCh2YWx1ZUJ5dGVzLCBuYW1lc3BhY2VCeXRlcy5sZW5ndGgpO1xuICAgIGJ5dGVzID0gaGFzaChieXRlcyk7XG4gICAgYnl0ZXNbNl0gPSAoYnl0ZXNbNl0gJiAweDBmKSB8IHZlcnNpb247XG4gICAgYnl0ZXNbOF0gPSAoYnl0ZXNbOF0gJiAweDNmKSB8IDB4ODA7XG4gICAgaWYgKGJ1Zikge1xuICAgICAgICBvZmZzZXQgPz89IDA7XG4gICAgICAgIGlmIChvZmZzZXQgPCAwIHx8IG9mZnNldCArIDE2ID4gYnVmLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYFVVSUQgYnl0ZSByYW5nZSAke29mZnNldH06JHtvZmZzZXQgKyAxNX0gaXMgb3V0IG9mIGJ1ZmZlciBib3VuZHNgKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDE2OyArK2kpIHtcbiAgICAgICAgICAgIGJ1ZltvZmZzZXQgKyBpXSA9IGJ5dGVzW2ldO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBidWY7XG4gICAgfVxuICAgIHJldHVybiB1bnNhZmVTdHJpbmdpZnkoYnl0ZXMpO1xufVxuIiwiaW1wb3J0IG1kNSBmcm9tICcuL21kNS5qcyc7XG5pbXBvcnQgdjM1LCB7IEROUywgVVJMIH0gZnJvbSAnLi92MzUuanMnO1xuZXhwb3J0IHsgRE5TLCBVUkwgfSBmcm9tICcuL3YzNS5qcyc7XG5mdW5jdGlvbiB2Myh2YWx1ZSwgbmFtZXNwYWNlLCBidWYsIG9mZnNldCkge1xuICAgIHJldHVybiB2MzUoMHgzMCwgbWQ1LCB2YWx1ZSwgbmFtZXNwYWNlLCBidWYsIG9mZnNldCk7XG59XG52My5ETlMgPSBETlM7XG52My5VUkwgPSBVUkw7XG5leHBvcnQgZGVmYXVsdCB2MztcbiIsImltcG9ydCBybmcgZnJvbSAnLi9ybmcuanMnO1xuaW1wb3J0IHsgdW5zYWZlU3RyaW5naWZ5IH0gZnJvbSAnLi9zdHJpbmdpZnkuanMnO1xuZnVuY3Rpb24gdjQob3B0aW9ucywgYnVmLCBvZmZzZXQpIHtcbiAgICBpZiAoIWJ1ZiAmJiAhb3B0aW9ucyAmJiBjcnlwdG8ucmFuZG9tVVVJRCkge1xuICAgICAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICB9XG4gICAgcmV0dXJuIF92NChvcHRpb25zLCBidWYsIG9mZnNldCk7XG59XG5mdW5jdGlvbiBfdjQob3B0aW9ucywgYnVmLCBvZmZzZXQpIHtcbiAgICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgICBjb25zdCBybmRzID0gb3B0aW9ucy5yYW5kb20gPz8gb3B0aW9ucy5ybmc/LigpID8/IHJuZygpO1xuICAgIGlmIChybmRzLmxlbmd0aCA8IDE2KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignUmFuZG9tIGJ5dGVzIGxlbmd0aCBtdXN0IGJlID49IDE2Jyk7XG4gICAgfVxuICAgIHJuZHNbNl0gPSAocm5kc1s2XSAmIDB4MGYpIHwgMHg0MDtcbiAgICBybmRzWzhdID0gKHJuZHNbOF0gJiAweDNmKSB8IDB4ODA7XG4gICAgaWYgKGJ1Zikge1xuICAgICAgICBvZmZzZXQgPSBvZmZzZXQgfHwgMDtcbiAgICAgICAgaWYgKG9mZnNldCA8IDAgfHwgb2Zmc2V0ICsgMTYgPiBidWYubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihgVVVJRCBieXRlIHJhbmdlICR7b2Zmc2V0fToke29mZnNldCArIDE1fSBpcyBvdXQgb2YgYnVmZmVyIGJvdW5kc2ApO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMTY7ICsraSkge1xuICAgICAgICAgICAgYnVmW29mZnNldCArIGldID0gcm5kc1tpXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYnVmO1xuICAgIH1cbiAgICByZXR1cm4gdW5zYWZlU3RyaW5naWZ5KHJuZHMpO1xufVxuZXhwb3J0IGRlZmF1bHQgdjQ7XG4iLCJmdW5jdGlvbiBmKHMsIHgsIHksIHopIHtcbiAgICBzd2l0Y2ggKHMpIHtcbiAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgcmV0dXJuICh4ICYgeSkgXiAofnggJiB6KTtcbiAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgcmV0dXJuIHggXiB5IF4gejtcbiAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgcmV0dXJuICh4ICYgeSkgXiAoeCAmIHopIF4gKHkgJiB6KTtcbiAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgcmV0dXJuIHggXiB5IF4gejtcbiAgICB9XG59XG5mdW5jdGlvbiBST1RMKHgsIG4pIHtcbiAgICByZXR1cm4gKHggPDwgbikgfCAoeCA+Pj4gKDMyIC0gbikpO1xufVxuZnVuY3Rpb24gc2hhMShieXRlcykge1xuICAgIGNvbnN0IEsgPSBbMHg1YTgyNzk5OSwgMHg2ZWQ5ZWJhMSwgMHg4ZjFiYmNkYywgMHhjYTYyYzFkNl07XG4gICAgY29uc3QgSCA9IFsweDY3NDUyMzAxLCAweGVmY2RhYjg5LCAweDk4YmFkY2ZlLCAweDEwMzI1NDc2LCAweGMzZDJlMWYwXTtcbiAgICBjb25zdCBuZXdCeXRlcyA9IG5ldyBVaW50OEFycmF5KGJ5dGVzLmxlbmd0aCArIDEpO1xuICAgIG5ld0J5dGVzLnNldChieXRlcyk7XG4gICAgbmV3Qnl0ZXNbYnl0ZXMubGVuZ3RoXSA9IDB4ODA7XG4gICAgYnl0ZXMgPSBuZXdCeXRlcztcbiAgICBjb25zdCBsID0gYnl0ZXMubGVuZ3RoIC8gNCArIDI7XG4gICAgY29uc3QgTiA9IE1hdGguY2VpbChsIC8gMTYpO1xuICAgIGNvbnN0IE0gPSBuZXcgQXJyYXkoTik7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBOOyArK2kpIHtcbiAgICAgICAgY29uc3QgYXJyID0gbmV3IFVpbnQzMkFycmF5KDE2KTtcbiAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCAxNjsgKytqKSB7XG4gICAgICAgICAgICBhcnJbal0gPVxuICAgICAgICAgICAgICAgIChieXRlc1tpICogNjQgKyBqICogNF0gPDwgMjQpIHxcbiAgICAgICAgICAgICAgICAgICAgKGJ5dGVzW2kgKiA2NCArIGogKiA0ICsgMV0gPDwgMTYpIHxcbiAgICAgICAgICAgICAgICAgICAgKGJ5dGVzW2kgKiA2NCArIGogKiA0ICsgMl0gPDwgOCkgfFxuICAgICAgICAgICAgICAgICAgICBieXRlc1tpICogNjQgKyBqICogNCArIDNdO1xuICAgICAgICB9XG4gICAgICAgIE1baV0gPSBhcnI7XG4gICAgfVxuICAgIE1bTiAtIDFdWzE0XSA9ICgoYnl0ZXMubGVuZ3RoIC0gMSkgKiA4KSAvIDIgKiogMzI7XG4gICAgTVtOIC0gMV1bMTRdID0gTWF0aC5mbG9vcihNW04gLSAxXVsxNF0pO1xuICAgIE1bTiAtIDFdWzE1XSA9ICgoYnl0ZXMubGVuZ3RoIC0gMSkgKiA4KSAmIDB4ZmZmZmZmZmY7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBOOyArK2kpIHtcbiAgICAgICAgY29uc3QgVyA9IG5ldyBVaW50MzJBcnJheSg4MCk7XG4gICAgICAgIGZvciAobGV0IHQgPSAwOyB0IDwgMTY7ICsrdCkge1xuICAgICAgICAgICAgV1t0XSA9IE1baV1bdF07XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgdCA9IDE2OyB0IDwgODA7ICsrdCkge1xuICAgICAgICAgICAgV1t0XSA9IFJPVEwoV1t0IC0gM10gXiBXW3QgLSA4XSBeIFdbdCAtIDE0XSBeIFdbdCAtIDE2XSwgMSk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGEgPSBIWzBdO1xuICAgICAgICBsZXQgYiA9IEhbMV07XG4gICAgICAgIGxldCBjID0gSFsyXTtcbiAgICAgICAgbGV0IGQgPSBIWzNdO1xuICAgICAgICBsZXQgZSA9IEhbNF07XG4gICAgICAgIGZvciAobGV0IHQgPSAwOyB0IDwgODA7ICsrdCkge1xuICAgICAgICAgICAgY29uc3QgcyA9IE1hdGguZmxvb3IodCAvIDIwKTtcbiAgICAgICAgICAgIGNvbnN0IFQgPSAoUk9UTChhLCA1KSArIGYocywgYiwgYywgZCkgKyBlICsgS1tzXSArIFdbdF0pID4+PiAwO1xuICAgICAgICAgICAgZSA9IGQ7XG4gICAgICAgICAgICBkID0gYztcbiAgICAgICAgICAgIGMgPSBST1RMKGIsIDMwKSA+Pj4gMDtcbiAgICAgICAgICAgIGIgPSBhO1xuICAgICAgICAgICAgYSA9IFQ7XG4gICAgICAgIH1cbiAgICAgICAgSFswXSA9IChIWzBdICsgYSkgPj4+IDA7XG4gICAgICAgIEhbMV0gPSAoSFsxXSArIGIpID4+PiAwO1xuICAgICAgICBIWzJdID0gKEhbMl0gKyBjKSA+Pj4gMDtcbiAgICAgICAgSFszXSA9IChIWzNdICsgZCkgPj4+IDA7XG4gICAgICAgIEhbNF0gPSAoSFs0XSArIGUpID4+PiAwO1xuICAgIH1cbiAgICByZXR1cm4gVWludDhBcnJheS5vZihIWzBdID4+IDI0LCBIWzBdID4+IDE2LCBIWzBdID4+IDgsIEhbMF0sIEhbMV0gPj4gMjQsIEhbMV0gPj4gMTYsIEhbMV0gPj4gOCwgSFsxXSwgSFsyXSA+PiAyNCwgSFsyXSA+PiAxNiwgSFsyXSA+PiA4LCBIWzJdLCBIWzNdID4+IDI0LCBIWzNdID4+IDE2LCBIWzNdID4+IDgsIEhbM10sIEhbNF0gPj4gMjQsIEhbNF0gPj4gMTYsIEhbNF0gPj4gOCwgSFs0XSk7XG59XG5leHBvcnQgZGVmYXVsdCBzaGExO1xuIiwiaW1wb3J0IHNoYTEgZnJvbSAnLi9zaGExLmpzJztcbmltcG9ydCB2MzUsIHsgRE5TLCBVUkwgfSBmcm9tICcuL3YzNS5qcyc7XG5leHBvcnQgeyBETlMsIFVSTCB9IGZyb20gJy4vdjM1LmpzJztcbmZ1bmN0aW9uIHY1KHZhbHVlLCBuYW1lc3BhY2UsIGJ1Ziwgb2Zmc2V0KSB7XG4gICAgcmV0dXJuIHYzNSgweDUwLCBzaGExLCB2YWx1ZSwgbmFtZXNwYWNlLCBidWYsIG9mZnNldCk7XG59XG52NS5ETlMgPSBETlM7XG52NS5VUkwgPSBVUkw7XG5leHBvcnQgZGVmYXVsdCB2NTtcbiIsImltcG9ydCB7IHVuc2FmZVN0cmluZ2lmeSB9IGZyb20gJy4vc3RyaW5naWZ5LmpzJztcbmltcG9ydCB2MSBmcm9tICcuL3YxLmpzJztcbmltcG9ydCB2MVRvVjYgZnJvbSAnLi92MVRvVjYuanMnO1xuZnVuY3Rpb24gdjYob3B0aW9ucywgYnVmLCBvZmZzZXQpIHtcbiAgICBvcHRpb25zID8/PSB7fTtcbiAgICBvZmZzZXQgPz89IDA7XG4gICAgbGV0IGJ5dGVzID0gdjEoeyAuLi5vcHRpb25zLCBfdjY6IHRydWUgfSwgbmV3IFVpbnQ4QXJyYXkoMTYpKTtcbiAgICBieXRlcyA9IHYxVG9WNihieXRlcyk7XG4gICAgaWYgKGJ1Zikge1xuICAgICAgICBpZiAob2Zmc2V0IDwgMCB8fCBvZmZzZXQgKyAxNiA+IGJ1Zi5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKGBVVUlEIGJ5dGUgcmFuZ2UgJHtvZmZzZXR9OiR7b2Zmc2V0ICsgMTV9IGlzIG91dCBvZiBidWZmZXIgYm91bmRzYCk7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAxNjsgaSsrKSB7XG4gICAgICAgICAgICBidWZbb2Zmc2V0ICsgaV0gPSBieXRlc1tpXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYnVmO1xuICAgIH1cbiAgICByZXR1cm4gdW5zYWZlU3RyaW5naWZ5KGJ5dGVzKTtcbn1cbmV4cG9ydCBkZWZhdWx0IHY2O1xuIiwiaW1wb3J0IHBhcnNlIGZyb20gJy4vcGFyc2UuanMnO1xuaW1wb3J0IHsgdW5zYWZlU3RyaW5naWZ5IH0gZnJvbSAnLi9zdHJpbmdpZnkuanMnO1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gdjZUb1YxKHV1aWQpIHtcbiAgICBjb25zdCB2NkJ5dGVzID0gdHlwZW9mIHV1aWQgPT09ICdzdHJpbmcnID8gcGFyc2UodXVpZCkgOiB1dWlkO1xuICAgIGNvbnN0IHYxQnl0ZXMgPSBfdjZUb1YxKHY2Qnl0ZXMpO1xuICAgIHJldHVybiB0eXBlb2YgdXVpZCA9PT0gJ3N0cmluZycgPyB1bnNhZmVTdHJpbmdpZnkodjFCeXRlcykgOiB2MUJ5dGVzO1xufVxuZnVuY3Rpb24gX3Y2VG9WMSh2NkJ5dGVzKSB7XG4gICAgcmV0dXJuIFVpbnQ4QXJyYXkub2YoKCh2NkJ5dGVzWzNdICYgMHgwZikgPDwgNCkgfCAoKHY2Qnl0ZXNbNF0gPj4gNCkgJiAweDBmKSwgKCh2NkJ5dGVzWzRdICYgMHgwZikgPDwgNCkgfCAoKHY2Qnl0ZXNbNV0gJiAweGYwKSA+PiA0KSwgKCh2NkJ5dGVzWzVdICYgMHgwZikgPDwgNCkgfCAodjZCeXRlc1s2XSAmIDB4MGYpLCB2NkJ5dGVzWzddLCAoKHY2Qnl0ZXNbMV0gJiAweDBmKSA8PCA0KSB8ICgodjZCeXRlc1syXSAmIDB4ZjApID4+IDQpLCAoKHY2Qnl0ZXNbMl0gJiAweDBmKSA8PCA0KSB8ICgodjZCeXRlc1szXSAmIDB4ZjApID4+IDQpLCAweDEwIHwgKCh2NkJ5dGVzWzBdICYgMHhmMCkgPj4gNCksICgodjZCeXRlc1swXSAmIDB4MGYpIDw8IDQpIHwgKCh2NkJ5dGVzWzFdICYgMHhmMCkgPj4gNCksIHY2Qnl0ZXNbOF0sIHY2Qnl0ZXNbOV0sIHY2Qnl0ZXNbMTBdLCB2NkJ5dGVzWzExXSwgdjZCeXRlc1sxMl0sIHY2Qnl0ZXNbMTNdLCB2NkJ5dGVzWzE0XSwgdjZCeXRlc1sxNV0pO1xufVxuIiwiaW1wb3J0IHJuZyBmcm9tICcuL3JuZy5qcyc7XG5pbXBvcnQgeyB1bnNhZmVTdHJpbmdpZnkgfSBmcm9tICcuL3N0cmluZ2lmeS5qcyc7XG5jb25zdCBfc3RhdGUgPSB7fTtcbmZ1bmN0aW9uIHY3KG9wdGlvbnMsIGJ1Ziwgb2Zmc2V0KSB7XG4gICAgbGV0IGJ5dGVzO1xuICAgIGlmIChvcHRpb25zKSB7XG4gICAgICAgIGJ5dGVzID0gdjdCeXRlcyhvcHRpb25zLnJhbmRvbSA/PyBvcHRpb25zLnJuZz8uKCkgPz8gcm5nKCksIG9wdGlvbnMubXNlY3MsIG9wdGlvbnMuc2VxLCBidWYsIG9mZnNldCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgICAgICBjb25zdCBybmRzID0gcm5nKCk7XG4gICAgICAgIHVwZGF0ZVY3U3RhdGUoX3N0YXRlLCBub3csIHJuZHMpO1xuICAgICAgICBieXRlcyA9IHY3Qnl0ZXMocm5kcywgX3N0YXRlLm1zZWNzLCBfc3RhdGUuc2VxLCBidWYsIG9mZnNldCk7XG4gICAgfVxuICAgIHJldHVybiBidWYgPz8gdW5zYWZlU3RyaW5naWZ5KGJ5dGVzKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVWN1N0YXRlKHN0YXRlLCBub3csIHJuZHMpIHtcbiAgICBzdGF0ZS5tc2VjcyA/Pz0gLUluZmluaXR5O1xuICAgIHN0YXRlLnNlcSA/Pz0gMDtcbiAgICBpZiAobm93ID4gc3RhdGUubXNlY3MpIHtcbiAgICAgICAgc3RhdGUuc2VxID0gdjdTZXF1ZW5jZShybmRzKTtcbiAgICAgICAgc3RhdGUubXNlY3MgPSBub3c7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBzdGF0ZS5zZXEgPSAoc3RhdGUuc2VxICsgMSkgfCAwO1xuICAgICAgICBpZiAoc3RhdGUuc2VxID09PSAwKSB7XG4gICAgICAgICAgICBzdGF0ZS5tc2VjcysrO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdGF0ZTtcbn1cbmZ1bmN0aW9uIHY3Qnl0ZXMocm5kcywgbXNlY3MsIHNlcSwgYnVmLCBvZmZzZXQgPSAwKSB7XG4gICAgaWYgKHJuZHMubGVuZ3RoIDwgMTYpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdSYW5kb20gYnl0ZXMgbGVuZ3RoIG11c3QgYmUgPj0gMTYnKTtcbiAgICB9XG4gICAgaWYgKCFidWYpIHtcbiAgICAgICAgYnVmID0gbmV3IFVpbnQ4QXJyYXkoMTYpO1xuICAgICAgICBvZmZzZXQgPSAwO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgaWYgKG9mZnNldCA8IDAgfHwgb2Zmc2V0ICsgMTYgPiBidWYubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihgVVVJRCBieXRlIHJhbmdlICR7b2Zmc2V0fToke29mZnNldCArIDE1fSBpcyBvdXQgb2YgYnVmZmVyIGJvdW5kc2ApO1xuICAgICAgICB9XG4gICAgfVxuICAgIG1zZWNzID8/PSBEYXRlLm5vdygpO1xuICAgIHNlcSA/Pz0gdjdTZXF1ZW5jZShybmRzKTtcbiAgICBidWZbb2Zmc2V0KytdID0gKG1zZWNzIC8gMHgxMDAwMDAwMDAwMCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAobXNlY3MgLyAweDEwMDAwMDAwMCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAobXNlY3MgLyAweDEwMDAwMDApICYgMHhmZjtcbiAgICBidWZbb2Zmc2V0KytdID0gKG1zZWNzIC8gMHgxMDAwMCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAobXNlY3MgLyAweDEwMCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSBtc2VjcyAmIDB4ZmY7XG4gICAgYnVmW29mZnNldCsrXSA9IDB4NzAgfCAoKHNlcSA+Pj4gMjgpICYgMHgwZik7XG4gICAgYnVmW29mZnNldCsrXSA9IChzZXEgPj4+IDIwKSAmIDB4ZmY7XG4gICAgYnVmW29mZnNldCsrXSA9IDB4ODAgfCAoKHNlcSA+Pj4gMTQpICYgMHgzZik7XG4gICAgYnVmW29mZnNldCsrXSA9IChzZXEgPj4+IDYpICYgMHhmZjtcbiAgICBidWZbb2Zmc2V0KytdID0gKChzZXEgPDwgMikgJiAweGZmKSB8IChybmRzWzEwXSAmIDB4MDMpO1xuICAgIGJ1ZltvZmZzZXQrK10gPSBybmRzWzExXTtcbiAgICBidWZbb2Zmc2V0KytdID0gcm5kc1sxMl07XG4gICAgYnVmW29mZnNldCsrXSA9IHJuZHNbMTNdO1xuICAgIGJ1ZltvZmZzZXQrK10gPSBybmRzWzE0XTtcbiAgICBidWZbb2Zmc2V0KytdID0gcm5kc1sxNV07XG4gICAgcmV0dXJuIGJ1Zjtcbn1cbmZ1bmN0aW9uIHY3U2VxdWVuY2Uocm5kcykge1xuICAgIHJldHVybiAoKHJuZHNbNl0gJiAweDdmKSA8PCAyNCkgfCAocm5kc1s3XSA8PCAxNikgfCAocm5kc1s4XSA8PCA4KSB8IHJuZHNbOV07XG59XG5leHBvcnQgZGVmYXVsdCB2NztcbiIsImltcG9ydCB2YWxpZGF0ZSBmcm9tICcuL3ZhbGlkYXRlLmpzJztcbmZ1bmN0aW9uIHZlcnNpb24odXVpZCkge1xuICAgIGlmICghdmFsaWRhdGUodXVpZCkpIHtcbiAgICAgICAgdGhyb3cgVHlwZUVycm9yKCdJbnZhbGlkIFVVSUQnKTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcnNlSW50KHV1aWQuc2xpY2UoMTQsIDE1KSwgMTYpO1xufVxuZXhwb3J0IGRlZmF1bHQgdmVyc2lvbjtcbiJdLCJtYXBwaW5ncyI6IjtBQUFBLElBQUEsY0FBZTs7O0FDQWYsSUFBQSxjQUFlOzs7QUNBZixJQUFBLGdCQUFlOzs7QUNDZixTQUFTLFNBQVMsTUFBTTtDQUNwQixPQUFPLE9BQU8sU0FBUyxZQUFZQSxjQUFNLEtBQUssSUFBSTtBQUN0RDs7O0FDRkEsU0FBUyxNQUFNLE1BQU07Q0FDakIsSUFBSSxDQUFDLFNBQVMsSUFBSSxHQUNkLE1BQU0sVUFBVSxjQUFjO0NBRWxDLElBQUk7Q0FDSixPQUFPLFdBQVcsSUFBSSxJQUFJLFNBQVMsS0FBSyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsT0FBTyxJQUFLLE1BQU0sS0FBTSxLQUFPLE1BQU0sSUFBSyxLQUFNLElBQUksTUFBTyxJQUFJLFNBQVMsS0FBSyxNQUFNLEdBQUcsRUFBRSxHQUFHLEVBQUUsT0FBTyxHQUFHLElBQUksTUFBTyxJQUFJLFNBQVMsS0FBSyxNQUFNLElBQUksRUFBRSxHQUFHLEVBQUUsT0FBTyxHQUFHLElBQUksTUFBTyxJQUFJLFNBQVMsS0FBSyxNQUFNLElBQUksRUFBRSxHQUFHLEVBQUUsT0FBTyxHQUFHLElBQUksTUFBUSxJQUFJLFNBQVMsS0FBSyxNQUFNLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxnQkFBaUIsS0FBTyxJQUFJLGFBQWUsS0FBTyxNQUFNLEtBQU0sS0FBTyxNQUFNLEtBQU0sS0FBTyxNQUFNLElBQUssS0FBTSxJQUFJLEdBQUk7QUFDdmI7OztBQ05BLElBQU0sWUFBWSxDQUFDO0FBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEVBQUUsR0FDdkIsVUFBVSxNQUFNLElBQUksSUFBQSxDQUFPLFNBQVMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFFcEQsU0FBZ0IsZ0JBQWdCLEtBQUssU0FBUyxHQUFHO0NBQzdDLFFBQVEsVUFBVSxJQUFJLFNBQVMsTUFDM0IsVUFBVSxJQUFJLFNBQVMsTUFDdkIsVUFBVSxJQUFJLFNBQVMsTUFDdkIsVUFBVSxJQUFJLFNBQVMsTUFDdkIsTUFDQSxVQUFVLElBQUksU0FBUyxNQUN2QixVQUFVLElBQUksU0FBUyxNQUN2QixNQUNBLFVBQVUsSUFBSSxTQUFTLE1BQ3ZCLFVBQVUsSUFBSSxTQUFTLE1BQ3ZCLE1BQ0EsVUFBVSxJQUFJLFNBQVMsTUFDdkIsVUFBVSxJQUFJLFNBQVMsTUFDdkIsTUFDQSxVQUFVLElBQUksU0FBUyxPQUN2QixVQUFVLElBQUksU0FBUyxPQUN2QixVQUFVLElBQUksU0FBUyxPQUN2QixVQUFVLElBQUksU0FBUyxPQUN2QixVQUFVLElBQUksU0FBUyxPQUN2QixVQUFVLElBQUksU0FBUyxLQUFBLENBQU0sWUFBWTtBQUNqRDtBQUNBLFNBQVMsVUFBVSxLQUFLLFNBQVMsR0FBRztDQUNoQyxNQUFNLE9BQU8sZ0JBQWdCLEtBQUssTUFBTTtDQUN4QyxJQUFJLENBQUMsU0FBUyxJQUFJLEdBQ2QsTUFBTSxVQUFVLDZCQUE2QjtDQUVqRCxPQUFPO0FBQ1g7OztBQ2pDQSxJQUFNLHdCQUFRLElBQUksV0FBVyxFQUFFO0FBQy9CLFNBQXdCLE1BQU07Q0FDMUIsT0FBTyxPQUFPLGdCQUFnQixLQUFLO0FBQ3ZDOzs7QUNEQSxJQUFNQyxXQUFTLENBQUM7QUFDaEIsU0FBUyxHQUFHLFNBQVMsS0FBSyxRQUFRO0NBQzlCLElBQUk7Q0FDSixNQUFNLE9BQU8sU0FBUyxPQUFPO0NBQzdCLElBQUksU0FBUztFQUNULE1BQU0sY0FBYyxPQUFPLEtBQUssT0FBTztFQUN2QyxJQUFJLFlBQVksV0FBVyxLQUFLLFlBQVksT0FBTyxPQUMvQyxVQUFVLEtBQUE7Q0FFbEI7Q0FDQSxJQUFJLFNBQ0EsUUFBUSxRQUFRLFFBQVEsVUFBVSxRQUFRLE1BQU0sS0FBSyxJQUFJLEdBQUcsUUFBUSxPQUFPLFFBQVEsT0FBTyxRQUFRLFVBQVUsUUFBUSxNQUFNLEtBQUssTUFBTTtNQUVwSTtFQUNELE1BQU0sTUFBTSxLQUFLLElBQUk7RUFDckIsTUFBTSxPQUFPLElBQUk7RUFDakIsY0FBY0EsVUFBUSxLQUFLLElBQUk7RUFDL0IsUUFBUSxRQUFRLE1BQU1BLFNBQU8sT0FBT0EsU0FBTyxPQUFPLE9BQU8sS0FBQSxJQUFZQSxTQUFPLFVBQVUsT0FBTyxLQUFBLElBQVlBLFNBQU8sTUFBTSxLQUFLLE1BQU07Q0FDckk7Q0FDQSxPQUFPLE9BQU8sZ0JBQWdCLEtBQUs7QUFDdkM7QUFDQSxTQUFnQixjQUFjLE9BQU8sS0FBSyxNQUFNO0NBQzVDLE1BQU0sVUFBVTtDQUNoQixNQUFNLFVBQVU7Q0FDaEIsSUFBSSxRQUFRLE1BQU0sT0FBTztFQUNyQixNQUFNO0VBQ04sSUFBSSxNQUFNLFNBQVMsS0FBTztHQUN0QixNQUFNLE9BQU8sS0FBQTtHQUNiLE1BQU0sUUFBUTtFQUNsQjtDQUNKLE9BQ0ssSUFBSSxNQUFNLE1BQU0sT0FDakIsTUFBTSxRQUFRO01BRWIsSUFBSSxNQUFNLE1BQU0sT0FDakIsTUFBTSxPQUFPLEtBQUE7Q0FFakIsSUFBSSxDQUFDLE1BQU0sTUFBTTtFQUNiLE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxFQUFFO0VBQzlCLE1BQU0sS0FBSyxNQUFNO0VBQ2pCLE1BQU0sWUFBYSxLQUFLLE1BQU0sSUFBSyxLQUFLLE1BQU07Q0FDbEQ7Q0FDQSxNQUFNLFFBQVE7Q0FDZCxPQUFPO0FBQ1g7QUFDQSxTQUFTLFFBQVEsTUFBTSxPQUFPLE9BQU8sVUFBVSxNQUFNLEtBQUssU0FBUyxHQUFHO0NBQ2xFLElBQUksS0FBSyxTQUFTLElBQ2QsTUFBTSxJQUFJLE1BQU0sbUNBQW1DO0NBRXZELElBQUksQ0FBQyxLQUFLO0VBQ04sc0JBQU0sSUFBSSxXQUFXLEVBQUU7RUFDdkIsU0FBUztDQUNiLE9BRUksSUFBSSxTQUFTLEtBQUssU0FBUyxLQUFLLElBQUksUUFDaEMsTUFBTSxJQUFJLFdBQVcsbUJBQW1CLE9BQU8sR0FBRyxTQUFTLEdBQUcseUJBQXlCO0NBRy9GLFVBQVUsS0FBSyxJQUFJO0NBQ25CLFVBQVU7Q0FDVixjQUFlLEtBQUssTUFBTSxJQUFLLEtBQUssTUFBTTtDQUMxQyxJQUFJLFFBQVEsTUFBTTtFQUNkLE9BQU8sS0FBSyxNQUFNLElBQUksRUFBRTtFQUN4QixLQUFLLE1BQU07Q0FDZjtDQUNBLFNBQVM7Q0FDVCxNQUFNLEtBQUssUUFBUSxhQUFhLE1BQVE7Q0FDeEMsTUFBTSxLQUFLLE1BQU07Q0FDakIsSUFBSSxZQUFhLE9BQU8sS0FBTTtDQUM5QixJQUFJLFlBQWEsT0FBTyxLQUFNO0NBQzlCLElBQUksWUFBYSxPQUFPLElBQUs7Q0FDN0IsSUFBSSxZQUFZLEtBQUs7Q0FDckIsTUFBTSxPQUFTLFFBQVEsWUFBYyxLQUFLLE9BQVEsSUFBSSxhQUFlLEtBQU07Q0FDM0UsSUFBSSxZQUFhLFFBQVEsSUFBSztDQUM5QixJQUFJLFlBQVksTUFBTTtDQUN0QixJQUFJLFlBQWMsUUFBUSxLQUFNLEtBQU87Q0FDdkMsSUFBSSxZQUFhLFFBQVEsS0FBTTtDQUMvQixJQUFJLFlBQWEsYUFBYSxJQUFLO0NBQ25DLElBQUksWUFBWSxXQUFXO0NBQzNCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FDckIsSUFBSSxZQUFZLEtBQUs7Q0FFekIsT0FBTztBQUNYOzs7QUNuRkEsU0FBd0IsT0FBTyxNQUFNO0NBRWpDLE1BQU0sVUFBVSxRQURBLE9BQU8sU0FBUyxXQUFXLE1BQU0sSUFBSSxJQUFJLElBQzFCO0NBQy9CLE9BQU8sT0FBTyxTQUFTLFdBQVcsZ0JBQWdCLE9BQU8sSUFBSTtBQUNqRTtBQUNBLFNBQVMsUUFBUSxTQUFTO0NBQ3RCLE9BQU8sV0FBVyxJQUFLLFFBQVEsS0FBSyxPQUFTLElBQU8sUUFBUSxNQUFNLElBQUssS0FBUyxRQUFRLEtBQUssT0FBUyxLQUFPLFFBQVEsS0FBSyxRQUFTLElBQU0sUUFBUSxLQUFLLE9BQVMsS0FBTyxRQUFRLEtBQUssUUFBUyxJQUFNLFFBQVEsS0FBSyxPQUFTLEtBQU8sUUFBUSxLQUFLLFFBQVMsSUFBTSxRQUFRLEtBQUssT0FBUyxLQUFPLFFBQVEsS0FBSyxRQUFTLElBQU0sUUFBUSxLQUFLLE9BQVMsS0FBTyxRQUFRLEtBQUssUUFBUyxHQUFJLEtBQVEsUUFBUSxLQUFLLElBQU8sUUFBUSxJQUFJLFFBQVEsSUFBSSxRQUFRLElBQUksUUFBUSxLQUFLLFFBQVEsS0FBSyxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVEsS0FBSyxRQUFRLEdBQUc7QUFDM2Y7OztBQ1RBLFNBQVMsSUFBSSxPQUFPO0NBR2hCLE9BQU8sY0FEVSxXQURILGNBQWMsS0FDSSxHQUFHLE1BQU0sU0FBUyxDQUN0QixDQUFDO0FBQ2pDO0FBQ0EsU0FBUyxjQUFjLE9BQU87Q0FDMUIsTUFBTSxRQUFRLElBQUksV0FBVyxNQUFNLFNBQVMsQ0FBQztDQUM3QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxTQUFTLEdBQUcsS0FDbEMsTUFBTSxLQUFNLE1BQU0sS0FBSyxPQUFTLElBQUksSUFBSyxJQUFNO0NBRW5ELE9BQU87QUFDWDtBQUNBLFNBQVMsZ0JBQWdCLGNBQWM7Q0FDbkMsUUFBVSxlQUFlLE9BQVEsS0FBTSxLQUFLLEtBQUs7QUFDckQ7QUFDQSxTQUFTLFdBQVcsR0FBRyxLQUFLO0NBQ3hCLE1BQU0sT0FBTyxJQUFJLFlBQVksZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0NBQ3pELEtBQUssSUFBSSxDQUFDO0NBQ1YsS0FBSyxPQUFPLE1BQU0sT0FBUyxNQUFNO0NBQ2pDLEtBQUssS0FBSyxTQUFTLEtBQUs7Q0FDeEIsSUFBSTtDQUNKLElBQUksSUFBSTtDQUNSLElBQUksSUFBSTtDQUNSLElBQUksSUFBSTtDQUNSLElBQUksSUFBSTtDQUNSLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSyxJQUFJO0VBQ25DLE1BQU0sT0FBTztFQUNiLE1BQU0sT0FBTztFQUNiLE1BQU0sT0FBTztFQUNiLE1BQU0sT0FBTztFQUNiLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxHQUFHLFVBQVU7RUFDekMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxVQUFVO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksU0FBUztFQUM3QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFdBQVc7RUFDL0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksR0FBRyxVQUFVO0VBQzdDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksVUFBVTtFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFdBQVc7RUFDL0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxTQUFTO0VBQzdDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLEdBQUcsVUFBVTtFQUM3QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFdBQVc7RUFDL0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxNQUFNO0VBQzNDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksV0FBVztFQUNoRCxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxHQUFHLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxTQUFTO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksV0FBVztFQUNoRCxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLFVBQVU7RUFDL0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksR0FBRyxVQUFVO0VBQzdDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLEdBQUcsV0FBVztFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLFNBQVM7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksVUFBVTtFQUMxQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxHQUFHLFVBQVU7RUFDN0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssR0FBRyxRQUFRO0VBQzVDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksVUFBVTtFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksR0FBRyxTQUFTO0VBQzVDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLEdBQUcsV0FBVztFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxVQUFVO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLEdBQUcsV0FBVztFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxHQUFHLFNBQVM7RUFDNUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxVQUFVO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksV0FBVztFQUNoRCxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxHQUFHLE9BQU87RUFDMUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxXQUFXO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksVUFBVTtFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLFNBQVM7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksR0FBRyxXQUFXO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksVUFBVTtFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxXQUFXO0VBQ2hELElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLEdBQUcsU0FBUztFQUM3QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxVQUFVO0VBQzFDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksVUFBVTtFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFFBQVE7RUFDNUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksR0FBRyxVQUFVO0VBQzdDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksVUFBVTtFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLFNBQVM7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxVQUFVO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxHQUFHLFVBQVU7RUFDekMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxVQUFVO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksV0FBVztFQUNoRCxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFNBQVM7RUFDN0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssR0FBRyxVQUFVO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksV0FBVztFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLFFBQVE7RUFDN0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxXQUFXO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLEdBQUcsVUFBVTtFQUM3QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLFNBQVM7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxXQUFXO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksVUFBVTtFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxHQUFHLFVBQVU7RUFDN0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxXQUFXO0VBQ2hELElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksU0FBUztFQUM3QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDOUMsSUFBSSxRQUFRLEdBQUcsSUFBSTtFQUNuQixJQUFJLFFBQVEsR0FBRyxJQUFJO0VBQ25CLElBQUksUUFBUSxHQUFHLElBQUk7RUFDbkIsSUFBSSxRQUFRLEdBQUcsSUFBSTtDQUN2QjtDQUNBLE9BQU8sWUFBWSxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDcEM7QUFDQSxTQUFTLGNBQWMsT0FBTztDQUMxQixJQUFJLE1BQU0sV0FBVyxHQUNqQix1QkFBTyxJQUFJLFlBQVk7Q0FFM0IsTUFBTSxTQUFTLElBQUksWUFBWSxnQkFBZ0IsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0NBQ3hFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FDOUIsT0FBTyxLQUFLLE9BQU8sTUFBTSxLQUFLLFFBQVcsSUFBSSxJQUFLO0NBRXRELE9BQU87QUFDWDtBQUNBLFNBQVMsUUFBUSxHQUFHLEdBQUc7Q0FDbkIsTUFBTSxPQUFPLElBQUksVUFBVyxJQUFJO0NBRWhDLFFBRGEsS0FBSyxPQUFPLEtBQUssT0FBTyxPQUFPLE9BQzdCLEtBQU8sTUFBTTtBQUNoQztBQUNBLFNBQVMsY0FBYyxLQUFLLEtBQUs7Q0FDN0IsT0FBUSxPQUFPLE1BQVEsUUFBUyxLQUFLO0FBQ3pDO0FBQ0EsU0FBUyxPQUFPLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQzlCLE9BQU8sUUFBUSxjQUFjLFFBQVEsUUFBUSxHQUFHLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDN0U7QUFDQSxTQUFTLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUNoQyxPQUFPLE9BQVEsSUFBSSxJQUFNLENBQUMsSUFBSSxHQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUNuRDtBQUNBLFNBQVMsTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ2hDLE9BQU8sT0FBUSxJQUFJLElBQU0sSUFBSSxDQUFDLEdBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQ25EO0FBQ0EsU0FBUyxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDaEMsT0FBTyxPQUFPLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUMxQztBQUNBLFNBQVMsTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ2hDLE9BQU8sT0FBTyxLQUFLLElBQUksQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUM3Qzs7O0FDbklBLFNBQWdCLGNBQWMsS0FBSztDQUMvQixNQUFNLFNBQVMsbUJBQW1CLEdBQUcsQ0FBQztDQUN0QyxNQUFNLFFBQVEsSUFBSSxXQUFXLElBQUksTUFBTTtDQUN2QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEVBQUUsR0FDOUIsTUFBTSxLQUFLLElBQUksV0FBVyxDQUFDO0NBRS9CLE9BQU87QUFDWDtBQUNBLElBQWEsTUFBTTtBQUNuQixJQUFhLE1BQU07QUFDbkIsU0FBd0IsSUFBSSxTQUFTLE1BQU0sT0FBTyxXQUFXLEtBQUssUUFBUTtDQUN0RSxNQUFNLGFBQWEsT0FBTyxVQUFVLFdBQVcsY0FBYyxLQUFLLElBQUk7Q0FDdEUsTUFBTSxpQkFBaUIsT0FBTyxjQUFjLFdBQVcsTUFBTSxTQUFTLElBQUk7Q0FDMUUsSUFBSSxPQUFPLGNBQWMsVUFDckIsWUFBWSxNQUFNLFNBQVM7Q0FFL0IsSUFBSSxXQUFXLFdBQVcsSUFDdEIsTUFBTSxVQUFVLGtFQUFrRTtDQUV0RixJQUFJLFFBQVEsSUFBSSxXQUFXLEtBQUssV0FBVyxNQUFNO0NBQ2pELE1BQU0sSUFBSSxjQUFjO0NBQ3hCLE1BQU0sSUFBSSxZQUFZLGVBQWUsTUFBTTtDQUMzQyxRQUFRLEtBQUssS0FBSztDQUNsQixNQUFNLEtBQU0sTUFBTSxLQUFLLEtBQVE7Q0FDL0IsTUFBTSxLQUFNLE1BQU0sS0FBSyxLQUFRO0NBQy9CLElBQUksS0FBSztFQUNMLFdBQVc7RUFDWCxJQUFJLFNBQVMsS0FBSyxTQUFTLEtBQUssSUFBSSxRQUNoQyxNQUFNLElBQUksV0FBVyxtQkFBbUIsT0FBTyxHQUFHLFNBQVMsR0FBRyx5QkFBeUI7RUFFM0YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxHQUN0QixJQUFJLFNBQVMsS0FBSyxNQUFNO0VBRTVCLE9BQU87Q0FDWDtDQUNBLE9BQU8sZ0JBQWdCLEtBQUs7QUFDaEM7OztBQ25DQSxTQUFTLEdBQUcsT0FBTyxXQUFXLEtBQUssUUFBUTtDQUN2QyxPQUFPLElBQUksSUFBTSxLQUFLLE9BQU8sV0FBVyxLQUFLLE1BQU07QUFDdkQ7QUFDQSxHQUFHLE1BQU07QUFDVCxHQUFHLE1BQU07OztBQ0xULFNBQVMsR0FBRyxTQUFTLEtBQUssUUFBUTtDQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsT0FBTyxZQUMzQixPQUFPLE9BQU8sV0FBVztDQUU3QixPQUFPLElBQUksU0FBUyxLQUFLLE1BQU07QUFDbkM7QUFDQSxTQUFTLElBQUksU0FBUyxLQUFLLFFBQVE7Q0FDL0IsVUFBVSxXQUFXLENBQUM7Q0FDdEIsTUFBTSxPQUFPLFFBQVEsVUFBVSxRQUFRLE1BQU0sS0FBSyxJQUFJO0NBQ3RELElBQUksS0FBSyxTQUFTLElBQ2QsTUFBTSxJQUFJLE1BQU0sbUNBQW1DO0NBRXZELEtBQUssS0FBTSxLQUFLLEtBQUssS0FBUTtDQUM3QixLQUFLLEtBQU0sS0FBSyxLQUFLLEtBQVE7Q0FDN0IsSUFBSSxLQUFLO0VBQ0wsU0FBUyxVQUFVO0VBQ25CLElBQUksU0FBUyxLQUFLLFNBQVMsS0FBSyxJQUFJLFFBQ2hDLE1BQU0sSUFBSSxXQUFXLG1CQUFtQixPQUFPLEdBQUcsU0FBUyxHQUFHLHlCQUF5QjtFQUUzRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLEdBQ3RCLElBQUksU0FBUyxLQUFLLEtBQUs7RUFFM0IsT0FBTztDQUNYO0NBQ0EsT0FBTyxnQkFBZ0IsSUFBSTtBQUMvQjs7O0FDM0JBLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ25CLFFBQVEsR0FBUjtFQUNJLEtBQUssR0FDRCxPQUFRLElBQUksSUFBTSxDQUFDLElBQUk7RUFDM0IsS0FBSyxHQUNELE9BQU8sSUFBSSxJQUFJO0VBQ25CLEtBQUssR0FDRCxPQUFRLElBQUksSUFBTSxJQUFJLElBQU0sSUFBSTtFQUNwQyxLQUFLLEdBQ0QsT0FBTyxJQUFJLElBQUk7Q0FDdkI7QUFDSjtBQUNBLFNBQVMsS0FBSyxHQUFHLEdBQUc7Q0FDaEIsT0FBUSxLQUFLLElBQU0sTUFBTyxLQUFLO0FBQ25DO0FBQ0EsU0FBUyxLQUFLLE9BQU87Q0FDakIsTUFBTSxJQUFJO0VBQUM7RUFBWTtFQUFZO0VBQVk7Q0FBVTtDQUN6RCxNQUFNLElBQUk7RUFBQztFQUFZO0VBQVk7RUFBWTtFQUFZO0NBQVU7Q0FDckUsTUFBTSxXQUFXLElBQUksV0FBVyxNQUFNLFNBQVMsQ0FBQztDQUNoRCxTQUFTLElBQUksS0FBSztDQUNsQixTQUFTLE1BQU0sVUFBVTtDQUN6QixRQUFRO0NBQ1IsTUFBTSxJQUFJLE1BQU0sU0FBUyxJQUFJO0NBQzdCLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFO0NBQzFCLE1BQU0sSUFBSSxJQUFJLE1BQU0sQ0FBQztDQUNyQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUc7RUFDeEIsTUFBTSxzQkFBTSxJQUFJLFlBQVksRUFBRTtFQUM5QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLEdBQ3RCLElBQUksS0FDQyxNQUFNLElBQUksS0FBSyxJQUFJLE1BQU0sS0FDckIsTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sS0FDN0IsTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFDOUIsTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJO0VBRW5DLEVBQUUsS0FBSztDQUNYO0NBQ0EsRUFBRSxJQUFJLEVBQUUsQ0FBQyxPQUFRLE1BQU0sU0FBUyxLQUFLLElBQUssS0FBSztDQUMvQyxFQUFFLElBQUksRUFBRSxDQUFDLE1BQU0sS0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsR0FBRztDQUN0QyxFQUFFLElBQUksRUFBRSxDQUFDLE9BQVEsTUFBTSxTQUFTLEtBQUssSUFBSztDQUMxQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUc7RUFDeEIsTUFBTSxvQkFBSSxJQUFJLFlBQVksRUFBRTtFQUM1QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLEdBQ3RCLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztFQUVoQixLQUFLLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLEdBQ3ZCLEVBQUUsS0FBSyxLQUFLLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSSxLQUFLLENBQUM7RUFFOUQsSUFBSSxJQUFJLEVBQUU7RUFDVixJQUFJLElBQUksRUFBRTtFQUNWLElBQUksSUFBSSxFQUFFO0VBQ1YsSUFBSSxJQUFJLEVBQUU7RUFDVixJQUFJLElBQUksRUFBRTtFQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsR0FBRztHQUN6QixNQUFNLElBQUksS0FBSyxNQUFNLElBQUksRUFBRTtHQUMzQixNQUFNLElBQUssS0FBSyxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQVE7R0FDN0QsSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJLEtBQUssR0FBRyxFQUFFLE1BQU07R0FDcEIsSUFBSTtHQUNKLElBQUk7RUFDUjtFQUNBLEVBQUUsS0FBTSxFQUFFLEtBQUssTUFBTztFQUN0QixFQUFFLEtBQU0sRUFBRSxLQUFLLE1BQU87RUFDdEIsRUFBRSxLQUFNLEVBQUUsS0FBSyxNQUFPO0VBQ3RCLEVBQUUsS0FBTSxFQUFFLEtBQUssTUFBTztFQUN0QixFQUFFLEtBQU0sRUFBRSxLQUFLLE1BQU87Q0FDMUI7Q0FDQSxPQUFPLFdBQVcsR0FBRyxFQUFFLE1BQU0sSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFLE1BQU0sR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFLE1BQU0sR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLEdBQUcsRUFBRSxFQUFFO0FBQ3BPOzs7QUNqRUEsU0FBUyxHQUFHLE9BQU8sV0FBVyxLQUFLLFFBQVE7Q0FDdkMsT0FBTyxJQUFJLElBQU0sTUFBTSxPQUFPLFdBQVcsS0FBSyxNQUFNO0FBQ3hEO0FBQ0EsR0FBRyxNQUFNO0FBQ1QsR0FBRyxNQUFNOzs7QUNKVCxTQUFTLEdBQUcsU0FBUyxLQUFLLFFBQVE7Q0FDOUIsWUFBWSxDQUFDO0NBQ2IsV0FBVztDQUNYLElBQUksUUFBUSxHQUFHO0VBQUUsR0FBRztFQUFTLEtBQUs7Q0FBSyxtQkFBRyxJQUFJLFdBQVcsRUFBRSxDQUFDO0NBQzVELFFBQVEsT0FBTyxLQUFLO0NBQ3BCLElBQUksS0FBSztFQUNMLElBQUksU0FBUyxLQUFLLFNBQVMsS0FBSyxJQUFJLFFBQ2hDLE1BQU0sSUFBSSxXQUFXLG1CQUFtQixPQUFPLEdBQUcsU0FBUyxHQUFHLHlCQUF5QjtFQUUzRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUNwQixJQUFJLFNBQVMsS0FBSyxNQUFNO0VBRTVCLE9BQU87Q0FDWDtDQUNBLE9BQU8sZ0JBQWdCLEtBQUs7QUFDaEM7OztBQ2hCQSxTQUF3QixPQUFPLE1BQU07Q0FFakMsTUFBTSxVQUFVLFFBREEsT0FBTyxTQUFTLFdBQVcsTUFBTSxJQUFJLElBQUksSUFDMUI7Q0FDL0IsT0FBTyxPQUFPLFNBQVMsV0FBVyxnQkFBZ0IsT0FBTyxJQUFJO0FBQ2pFO0FBQ0EsU0FBUyxRQUFRLFNBQVM7Q0FDdEIsT0FBTyxXQUFXLElBQUssUUFBUSxLQUFLLE9BQVMsSUFBTyxRQUFRLE1BQU0sSUFBSyxLQUFTLFFBQVEsS0FBSyxPQUFTLEtBQU8sUUFBUSxLQUFLLFFBQVMsSUFBTSxRQUFRLEtBQUssT0FBUyxJQUFNLFFBQVEsS0FBSyxJQUFPLFFBQVEsS0FBTSxRQUFRLEtBQUssT0FBUyxLQUFPLFFBQVEsS0FBSyxRQUFTLElBQU0sUUFBUSxLQUFLLE9BQVMsS0FBTyxRQUFRLEtBQUssUUFBUyxHQUFJLE1BQVMsUUFBUSxLQUFLLFFBQVMsSUFBTSxRQUFRLEtBQUssT0FBUyxLQUFPLFFBQVEsS0FBSyxRQUFTLEdBQUksUUFBUSxJQUFJLFFBQVEsSUFBSSxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVEsS0FBSyxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVEsR0FBRztBQUMzZjs7O0FDUEEsSUFBTSxTQUFTLENBQUM7QUFDaEIsU0FBUyxHQUFHLFNBQVMsS0FBSyxRQUFRO0NBQzlCLElBQUk7Q0FDSixJQUFJLFNBQ0EsUUFBUSxRQUFRLFFBQVEsVUFBVSxRQUFRLE1BQU0sS0FBSyxJQUFJLEdBQUcsUUFBUSxPQUFPLFFBQVEsS0FBSyxLQUFLLE1BQU07TUFFbEc7RUFDRCxNQUFNLE1BQU0sS0FBSyxJQUFJO0VBQ3JCLE1BQU0sT0FBTyxJQUFJO0VBQ2pCLGNBQWMsUUFBUSxLQUFLLElBQUk7RUFDL0IsUUFBUSxRQUFRLE1BQU0sT0FBTyxPQUFPLE9BQU8sS0FBSyxLQUFLLE1BQU07Q0FDL0Q7Q0FDQSxPQUFPLE9BQU8sZ0JBQWdCLEtBQUs7QUFDdkM7QUFDQSxTQUFnQixjQUFjLE9BQU8sS0FBSyxNQUFNO0NBQzVDLE1BQU0sVUFBVTtDQUNoQixNQUFNLFFBQVE7Q0FDZCxJQUFJLE1BQU0sTUFBTSxPQUFPO0VBQ25CLE1BQU0sTUFBTSxXQUFXLElBQUk7RUFDM0IsTUFBTSxRQUFRO0NBQ2xCLE9BQ0s7RUFDRCxNQUFNLE1BQU8sTUFBTSxNQUFNLElBQUs7RUFDOUIsSUFBSSxNQUFNLFFBQVEsR0FDZCxNQUFNO0NBRWQ7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLFFBQVEsTUFBTSxPQUFPLEtBQUssS0FBSyxTQUFTLEdBQUc7Q0FDaEQsSUFBSSxLQUFLLFNBQVMsSUFDZCxNQUFNLElBQUksTUFBTSxtQ0FBbUM7Q0FFdkQsSUFBSSxDQUFDLEtBQUs7RUFDTixzQkFBTSxJQUFJLFdBQVcsRUFBRTtFQUN2QixTQUFTO0NBQ2IsT0FFSSxJQUFJLFNBQVMsS0FBSyxTQUFTLEtBQUssSUFBSSxRQUNoQyxNQUFNLElBQUksV0FBVyxtQkFBbUIsT0FBTyxHQUFHLFNBQVMsR0FBRyx5QkFBeUI7Q0FHL0YsVUFBVSxLQUFLLElBQUk7Q0FDbkIsUUFBUSxXQUFXLElBQUk7Q0FDdkIsSUFBSSxZQUFhLFFBQVEsZ0JBQWlCO0NBQzFDLElBQUksWUFBYSxRQUFRLGFBQWU7Q0FDeEMsSUFBSSxZQUFhLFFBQVEsV0FBYTtDQUN0QyxJQUFJLFlBQWEsUUFBUSxRQUFXO0NBQ3BDLElBQUksWUFBYSxRQUFRLE1BQVM7Q0FDbEMsSUFBSSxZQUFZLFFBQVE7Q0FDeEIsSUFBSSxZQUFZLE1BQVMsUUFBUSxLQUFNO0NBQ3ZDLElBQUksWUFBYSxRQUFRLEtBQU07Q0FDL0IsSUFBSSxZQUFZLE1BQVMsUUFBUSxLQUFNO0NBQ3ZDLElBQUksWUFBYSxRQUFRLElBQUs7Q0FDOUIsSUFBSSxZQUFjLE9BQU8sSUFBSyxNQUFTLEtBQUssTUFBTTtDQUNsRCxJQUFJLFlBQVksS0FBSztDQUNyQixJQUFJLFlBQVksS0FBSztDQUNyQixJQUFJLFlBQVksS0FBSztDQUNyQixJQUFJLFlBQVksS0FBSztDQUNyQixJQUFJLFlBQVksS0FBSztDQUNyQixPQUFPO0FBQ1g7QUFDQSxTQUFTLFdBQVcsTUFBTTtDQUN0QixRQUFTLEtBQUssS0FBSyxRQUFTLEtBQU8sS0FBSyxNQUFNLEtBQU8sS0FBSyxNQUFNLElBQUssS0FBSztBQUM5RTs7O0FDakVBLFNBQVMsUUFBUSxNQUFNO0NBQ25CLElBQUksQ0FBQyxTQUFTLElBQUksR0FDZCxNQUFNLFVBQVUsY0FBYztDQUVsQyxPQUFPLFNBQVMsS0FBSyxNQUFNLElBQUksRUFBRSxHQUFHLEVBQUU7QUFDMUMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOF19