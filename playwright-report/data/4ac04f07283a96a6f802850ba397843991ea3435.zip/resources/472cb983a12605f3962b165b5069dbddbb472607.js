import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/LoadingScreen.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LoadingScreen.module.css"
const __vite__css = "._overlay_1f8fg_1 {\r\n    position: absolute;\r\n    inset: 0;\r\n    z-index: 20;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    background: radial-gradient(circle at center, rgba(15, 23, 42, 0.55), rgba(2, 6, 23, 0.92));\r\n}\r\n\r\n._card_1f8fg_21 {\r\n    background-image: url('/assets/png/default/ui/menu/panel_menu.png');\r\n    background-size: 100% 100%;\r\n    width: 460px;\r\n    max-width: 92vw;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    gap: 1.5rem;\r\n    padding: 3rem;\r\n    box-sizing: border-box;\r\n}\r\n\r\n._title_1f8fg_47 {\r\n    width: 100%;\r\n    filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.5));\r\n}\r\n\r\n._progress_1f8fg_57 {\r\n    width: 100%;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    gap: 0.5rem;\r\n}\r\n\r\n._label_1f8fg_73 {\r\n    color: #fde047;\r\n    font-weight: 800;\r\n    text-transform: uppercase;\r\n    letter-spacing: 0.08em;\r\n    text-shadow: 2px 2px 0 #000;\r\n    animation: _pulse_1f8fg_1 1.4s ease-in-out infinite;\r\n}\r\n\r\n._error_1f8fg_91 {\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    gap: 0.75rem;\r\n    text-align: center;\r\n}\r\n\r\n._errorTitle_1f8fg_107 {\r\n    margin: 0;\r\n    color: #fca5a5;\r\n    font-size: 1.25rem;\r\n    font-weight: 900;\r\n    text-shadow: 2px 2px 0 #000;\r\n}\r\n\r\n._errorDetail_1f8fg_123 {\r\n    margin: 0;\r\n    color: #e2e8f0;\r\n    font-size: 0.9rem;\r\n}\r\n\r\n._retryButton_1f8fg_135 {\r\n    background: url('/assets/png/default/ui/menu/button_primary_normal.png') center / 100% 100% no-repeat transparent;\r\n    border: none;\r\n    width: 220px;\r\n    height: 70px;\r\n    color: #fff;\r\n    font-size: 1.2rem;\r\n    font-weight: 900;\r\n    text-transform: uppercase;\r\n    text-shadow: 0 2px 0 rgba(0, 0, 0, 0.5);\r\n    cursor: pointer;\r\n}\r\n\r\n._retryButton_1f8fg_135:hover {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_hover.png');\r\n}\r\n\r\n._retryButton_1f8fg_135:active {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_pressed.png');\r\n}\r\n\r\n@keyframes _pulse_1f8fg_1 {\r\n    50% {\r\n        opacity: 0.55;\r\n    }\r\n}\r\n\r\n@media (prefers-reduced-motion: reduce) {\r\n    ._label_1f8fg_73 {\r\n        animation: none;\r\n    }\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const overlay = "_overlay_1f8fg_1";
export const card = "_card_1f8fg_21";
export const title = "_title_1f8fg_47";
export const progress = "_progress_1f8fg_57";
export const label = "_label_1f8fg_73";
export const pulse = "_pulse_1f8fg_1";
export const error = "_error_1f8fg_91";
export const errorTitle = "_errorTitle_1f8fg_107";
export const errorDetail = "_errorDetail_1f8fg_123";
export const retryButton = "_retryButton_1f8fg_135";
export default {
	overlay: overlay,
	card: card,
	title: title,
	progress: progress,
	label: label,
	pulse: pulse,
	error: error,
	errorTitle: errorTitle,
	errorDetail: errorDetail,
	retryButton: retryButton
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))