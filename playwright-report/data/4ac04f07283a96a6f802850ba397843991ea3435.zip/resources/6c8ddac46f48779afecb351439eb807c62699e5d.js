import { RNG } from "/src/core/rng.ts";
import { vAdd, vSub, vScale, vNorm, vLen, vDist, createOBB, polyVsPoly, circleVsPoly } from "/src/core/geometry.ts";
// --- Simulation ---
export class Simulation {
	state;
	events = [];
	rng;
	arena;
	config;
	session;
	spawnTimer;
	nextId = 0;
	constructor(config, arena, seed, sessionTimeSec, spawnIntervalSec) {
		this.config = config;
		this.arena = arena;
		this.rng = new RNG(seed);
		this.session = {
			sessionTimeMs: sessionTimeSec * 1e3,
			spawnIntervalMs: spawnIntervalSec * 1e3
		};
		this.spawnTimer = this.session.spawnIntervalMs;
		this.state = {
			timeRemaining: this.session.sessionTimeMs,
			score: 0,
			player: {
				id: "player",
				position: {
					x: arena.width / 2,
					y: arena.height / 2
				},
				rotation: 0,
				health: config.playerMaxHealth,
				cooldowns: {
					front: 0,
					left: 0,
					right: 0
				},
				isDead: false
			},
			enemies: [],
			projectiles: [],
			isGameOver: false,
			endReason: null
		};
	}
	genId() {
		return `e${this.nextId++}`;
	}
	// ========== Public API ==========
	step(dt, input) {
		if (this.state.isGameOver) return;
		this.advanceTimers(dt);
		this.applyPlayerInput(dt, input);
		this.spawnEnemies();
		this.updateAI(dt);
		this.fireWeapons(input);
		this.integrateMovement(dt);
		this.resolveCollisions();
		this.processDeathsAndScoring();
		this.cleanup();
		this.checkMatchEnd();
	}
	getState() {
		return this.state;
	}
	drainEvents() {
		const drained = this.events;
		this.events = [];
		return drained;
	}
	// ========== Systems ==========
	advanceTimers(dt) {
		this.state.timeRemaining -= dt;
		const cd = this.state.player.cooldowns;
		cd.front = Math.max(0, cd.front - dt);
		cd.left = Math.max(0, cd.left - dt);
		cd.right = Math.max(0, cd.right - dt);
		for (const enemy of this.state.enemies) {
			if (!enemy.isDead) {
				enemy.cooldown = Math.max(0, enemy.cooldown - dt);
			}
		}
		this.spawnTimer = Math.max(0, this.spawnTimer - dt);
	}
	applyPlayerInput(dt, input) {
		const p = this.state.player;
		if (p.isDead) return;
		const dtSec = dt / 1e3;
		if (input.turnLeft) p.rotation -= this.config.playerTurnSpeed * dtSec;
		if (input.turnRight) p.rotation += this.config.playerTurnSpeed * dtSec;
		if (input.thrust) {
			p.position.x += Math.cos(p.rotation) * this.config.playerMoveSpeed * dtSec;
			p.position.y += Math.sin(p.rotation) * this.config.playerMoveSpeed * dtSec;
		}
	}
	spawnEnemies() {
		if (this.spawnTimer > 0) return;
		const aliveCount = this.state.enemies.filter((e) => !e.isDead).length;
		if (aliveCount >= this.config.maxAliveEnemies) return;
		this.spawnTimer = this.session.spawnIntervalMs;
		const pos = this.findSpawnPosition();
		if (!pos) return;
		const totalWeight = this.config.chaserWeight + this.config.shooterWeight;
		const type = this.rng.random() * totalWeight < this.config.chaserWeight ? "chaser" : "shooter";
		const isChaser = type === "chaser";
		const enemy = {
			id: this.genId(),
			type,
			position: pos,
			rotation: Math.atan2(this.state.player.position.y - pos.y, this.state.player.position.x - pos.x),
			health: isChaser ? this.config.chaserHealth : this.config.shooterHealth,
			cooldown: this.config.spawnGracePeriod,
			isDead: false
		};
		this.state.enemies.push(enemy);
	}
	findSpawnPosition() {
		const margin = this.config.spawnEdgeMargin;
		const { width, height } = this.arena;
		for (let i = 0; i < this.config.spawnMaxAttempts; i++) {
			let x, y;
			const side = Math.floor(this.rng.random() * 4);
			switch (side) {
				case 0:
					x = this.rng.range(margin, width - margin);
					y = margin;
					break;
				case 1:
					x = this.rng.range(margin, width - margin);
					y = height - margin;
					break;
				case 2:
					x = margin;
					y = this.rng.range(margin, height - margin);
					break;
				default:
					x = width - margin;
					y = this.rng.range(margin, height - margin);
					break;
			}
			const pos = {
				x,
				y
			};
			if (vDist(pos, this.state.player.position) < this.config.minSpawnDistance) continue;
			const spawnCircle = {
				pos,
				radius: this.config.spawnCheckRadius
			};
			let blocked = false;
			for (const island of this.arena.islands) {
				if (circleVsPoly(spawnCircle, island.polygon).collided) {
					blocked = true;
					break;
				}
			}
			if (blocked) continue;
			return pos;
		}
		return null;
	}
	updateAI(dt) {
		const dtSec = dt / 1e3;
		const playerPos = this.state.player.position;
		for (const enemy of this.state.enemies) {
			if (enemy.isDead) continue;
			const toPlayer = vSub(playerPos, enemy.position);
			const targetAngle = Math.atan2(toPlayer.y, toPlayer.x);
			const turnSpeed = enemy.type === "chaser" ? this.config.chaserTurnSpeed : this.config.shooterTurnSpeed;
			enemy.rotation = this.rotateToward(enemy.rotation, targetAngle, turnSpeed * dtSec);
			const dist = vLen(toPlayer);
			const speed = enemy.type === "chaser" ? this.config.chaserSpeed : this.config.shooterSpeed;
			if (enemy.type === "shooter" && dist <= this.config.shooterAttackRange) {
				// In range: stop moving, fire if aligned
				const angleDiff = Math.abs(this.normalizeAngle(targetAngle - enemy.rotation));
				if (angleDiff < this.config.shooterAimTolerance && enemy.cooldown <= 0) {
					this.fireEnemyProjectile(enemy);
				}
			} else {
				// Move forward
				enemy.position.x += Math.cos(enemy.rotation) * speed * dtSec;
				enemy.position.y += Math.sin(enemy.rotation) * speed * dtSec;
			}
		}
	}
	rotateToward(current, target, maxStep) {
		const diff = this.normalizeAngle(target - current);
		if (Math.abs(diff) <= maxStep) return target;
		return current + Math.sign(diff) * maxStep;
	}
	normalizeAngle(a) {
		while (a > Math.PI) a -= 2 * Math.PI;
		while (a < -Math.PI) a += 2 * Math.PI;
		return a;
	}
	fireWeapons(input) {
		const p = this.state.player;
		if (p.isDead) return;
		// Front: 1 projectile
		if (input.fireFront && p.cooldowns.front <= 0) {
			const dir = {
				x: Math.cos(p.rotation),
				y: Math.sin(p.rotation)
			};
			this.createProjectile(p.id, p.position, dir);
			p.cooldowns.front = this.config.cooldownFront;
			this.events.push({
				type: "shotFired",
				projectileId: `p${this.nextId}`,
				ownerId: p.id
			});
		}
		// Left broadside: 3 projectiles
		if (input.fireLeft && p.cooldowns.left <= 0) {
			const leftDir = {
				x: Math.cos(p.rotation - Math.PI / 2),
				y: Math.sin(p.rotation - Math.PI / 2)
			};
			this.fireBroadside(p, leftDir);
			p.cooldowns.left = this.config.cooldownSide;
		}
		// Right broadside: 3 projectiles
		if (input.fireRight && p.cooldowns.right <= 0) {
			const rightDir = {
				x: Math.cos(p.rotation + Math.PI / 2),
				y: Math.sin(p.rotation + Math.PI / 2)
			};
			this.fireBroadside(p, rightDir);
			p.cooldowns.right = this.config.cooldownSide;
		}
	}
	fireBroadside(player, dir) {
		const forward = {
			x: Math.cos(player.rotation),
			y: Math.sin(player.rotation)
		};
		const offsets = this.config.broadsideOffsets;
		for (const offset of offsets) {
			const origin = vAdd(player.position, vScale(forward, offset));
			this.createProjectile(player.id, origin, dir);
		}
		this.events.push({
			type: "shotFired",
			projectileId: "broadside",
			ownerId: player.id
		});
	}
	fireEnemyProjectile(enemy) {
		const dir = {
			x: Math.cos(enemy.rotation),
			y: Math.sin(enemy.rotation)
		};
		this.createProjectile(enemy.id, enemy.position, dir);
		enemy.cooldown = this.config.shooterCooldown;
		this.events.push({
			type: "shotFired",
			projectileId: `p${this.nextId}`,
			ownerId: enemy.id
		});
	}
	createProjectile(ownerId, origin, dir) {
		const normalized = vNorm(dir);
		this.state.projectiles.push({
			id: this.genId(),
			ownerId,
			position: { ...origin },
			velocity: vScale(normalized, this.config.projectileSpeed),
			damage: this.config.projectileDamage,
			lifeTime: this.config.projectileLifeTime
		});
	}
	integrateMovement(dt) {
		const dtSec = dt / 1e3;
		for (const proj of this.state.projectiles) {
			proj.position.x += proj.velocity.x * dtSec;
			proj.position.y += proj.velocity.y * dtSec;
			proj.lifeTime -= dt;
		}
	}
	resolveCollisions() {
		const s = this.state;
		// --- Ships vs arena bounds ---
		this.clampToArena(s.player.position, this.config.playerHitboxWidth / 2);
		for (const enemy of s.enemies) {
			if (!enemy.isDead) this.clampToArena(enemy.position, this.config.enemyHitboxWidth / 2);
		}
		// --- Player vs islands (OBB slide) ---
		const playerOBB = createOBB(s.player.position, this.config.playerHitboxWidth, this.config.playerHitboxHeight, s.player.rotation);
		for (const island of this.arena.islands) {
			const r = polyVsPoly(playerOBB, island.polygon);
			if (r.collided && r.mtv) {
				s.player.position.x -= r.mtv.x;
				s.player.position.y -= r.mtv.y;
			}
		}
		// --- Enemies vs islands ---
		for (const enemy of s.enemies) {
			if (enemy.isDead) continue;
			const obb = createOBB(enemy.position, this.config.enemyHitboxWidth, this.config.enemyHitboxHeight, enemy.rotation);
			for (const island of this.arena.islands) {
				const r = polyVsPoly(obb, island.polygon);
				if (r.collided && r.mtv) {
					enemy.position.x -= r.mtv.x;
					enemy.position.y -= r.mtv.y;
				}
			}
		}
		// --- Projectiles vs bounds + islands ---
		for (const proj of s.projectiles) {
			if (proj.lifeTime <= 0) continue;
			if (proj.position.x < 0 || proj.position.x > this.arena.width || proj.position.y < 0 || proj.position.y > this.arena.height) {
				proj.lifeTime = 0;
				continue;
			}
			const circle = {
				pos: proj.position,
				radius: this.config.projectileRadius
			};
			for (const island of this.arena.islands) {
				if (circleVsPoly(circle, island.polygon).collided) {
					proj.lifeTime = 0;
					break;
				}
			}
		}
		// --- Player projectiles vs enemies ---
		for (const proj of s.projectiles) {
			if (proj.lifeTime <= 0 || proj.ownerId !== "player") continue;
			const pc = {
				pos: proj.position,
				radius: this.config.projectileRadius
			};
			for (const enemy of s.enemies) {
				if (enemy.isDead) continue;
				const obb = createOBB(enemy.position, this.config.enemyHitboxWidth, this.config.enemyHitboxHeight, enemy.rotation);
				if (circleVsPoly(pc, obb).collided) {
					enemy.health -= proj.damage;
					proj.lifeTime = 0;
					this.events.push({
						type: "projectileHit",
						projectileId: proj.id,
						targetId: enemy.id
					});
					break;
				}
			}
		}
		// --- Enemy projectiles vs player ---
		if (!s.player.isDead) {
			const pOBB = createOBB(s.player.position, this.config.playerHitboxWidth, this.config.playerHitboxHeight, s.player.rotation);
			for (const proj of s.projectiles) {
				if (proj.lifeTime <= 0 || proj.ownerId === "player") continue;
				const pc = {
					pos: proj.position,
					radius: this.config.projectileRadius
				};
				if (circleVsPoly(pc, pOBB).collided) {
					s.player.health -= proj.damage;
					proj.lifeTime = 0;
					this.events.push({
						type: "playerDamaged",
						amount: proj.damage
					});
					this.events.push({
						type: "projectileHit",
						projectileId: proj.id,
						targetId: "player"
					});
				}
			}
		}
		// --- Chaser collision with player ---
		if (!s.player.isDead) {
			const pOBB = createOBB(s.player.position, this.config.playerHitboxWidth, this.config.playerHitboxHeight, s.player.rotation);
			for (const enemy of s.enemies) {
				if (enemy.isDead || enemy.type !== "chaser" || enemy.health <= 0) continue;
				const obb = createOBB(enemy.position, this.config.enemyHitboxWidth, this.config.enemyHitboxHeight, enemy.rotation);
				if (polyVsPoly(pOBB, obb).collided) {
					s.player.health -= this.config.chaserCollisionDamage;
					enemy.health = 0;
					enemy.killedByCollision = true;
					this.events.push({
						type: "playerDamaged",
						amount: this.config.chaserCollisionDamage
					});
				}
			}
		}
	}
	clampToArena(pos, margin) {
		pos.x = Math.max(margin, Math.min(this.arena.width - margin, pos.x));
		pos.y = Math.max(margin, Math.min(this.arena.height - margin, pos.y));
	}
	processDeathsAndScoring() {
		const s = this.state;
		if (!s.player.isDead && s.player.health <= 0) {
			s.player.isDead = true;
			s.player.health = 0;
			this.events.push({
				type: "shipDestroyed",
				shipId: "player",
				isPlayer: true
			});
		}
		// Enemies killed by projectiles (chasers killed by collision already handled)
		for (const enemy of s.enemies) {
			if (!enemy.isDead && enemy.health <= 0) {
				enemy.isDead = true;
				enemy.health = 0;
				this.events.push({
					type: "shipDestroyed",
					shipId: enemy.id,
					isPlayer: false
				});
				// Only score kills from player projectiles, not chaser self-destruct
				if (!enemy.killedByCollision) {
					s.score += 1;
					this.events.push({
						type: "scoreChanged",
						newScore: s.score
					});
				}
			}
		}
	}
	cleanup() {
		this.state.projectiles = this.state.projectiles.filter((p) => p.lifeTime > 0);
		this.state.enemies = this.state.enemies.filter((e) => !e.isDead);
	}
	checkMatchEnd() {
		const s = this.state;
		// player_died takes precedence over time_up in the same tick
		if (s.player.isDead) {
			s.isGameOver = true;
			s.endReason = "player_died";
			this.events.push({
				type: "matchEnded",
				reason: "player_died"
			});
		} else if (s.timeRemaining <= 0) {
			s.timeRemaining = 0;
			s.isGameOver = true;
			s.endReason = "time_up";
			this.events.push({
				type: "matchEnded",
				reason: "time_up"
			});
		}
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBS0EsU0FBUyxXQUFXO0FBQ3BCLFNBQ0ksTUFBTSxNQUFNLFFBQVEsT0FBTyxNQUFNLE9BQ2pDLFdBQVcsWUFBWSxvQkFFcEI7O0FBS1AsT0FBTyxNQUFNLFdBQVc7Q0FFcEIsQUFBUTtDQUVSLEFBQVEsU0FBc0IsQ0FBQztDQUMvQixBQUFRO0NBRVIsQUFBUTtDQUVSLEFBQVE7Q0FFUixBQUFRO0NBQ1IsQUFBUTtDQUNSLEFBQVEsU0FBUztDQUVqQixZQUNJLFFBQ0EsT0FDQSxNQUNBLGdCQUNBLGtCQUNGO0VBQ0UsS0FBSyxTQUFTO0VBQ2QsS0FBSyxRQUFRO0VBQ2IsS0FBSyxNQUFNLElBQUksSUFBSSxJQUFJO0VBQ3ZCLEtBQUssVUFBVTtHQUNYLGVBQWUsaUJBQWlCO0dBQ2hDLGlCQUFpQixtQkFBbUI7RUFDeEM7RUFDQSxLQUFLLGFBQWEsS0FBSyxRQUFRO0VBRS9CLEtBQUssUUFBUTtHQUNULGVBQWUsS0FBSyxRQUFRO0dBQzVCLE9BQU87R0FDUCxRQUFRO0lBQ0osSUFBSTtJQUNKLFVBQVU7S0FBRSxHQUFHLE1BQU0sUUFBUTtLQUFHLEdBQUcsTUFBTSxTQUFTO0lBQUU7SUFDcEQsVUFBVTtJQUNWLFFBQVEsT0FBTztJQUNmLFdBQVc7S0FBRSxPQUFPO0tBQUcsTUFBTTtLQUFHLE9BQU87SUFBRTtJQUN6QyxRQUFRO0dBQ1o7R0FDQSxTQUFTLENBQUM7R0FDVixhQUFhLENBQUM7R0FDZCxZQUFZO0dBQ1osV0FBVztFQUNmO0NBQ0o7Q0FFQSxBQUFRLFFBQWdCO0VBQ3BCLE9BQU8sSUFBSSxLQUFLO0NBQ3BCOztDQUlBLEtBQUssSUFBWSxPQUF5QjtFQUN0QyxJQUFJLEtBQUssTUFBTSxZQUFZO0VBRTNCLEtBQUssY0FBYyxFQUFFO0VBQ3JCLEtBQUssaUJBQWlCLElBQUksS0FBSztFQUMvQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxTQUFTLEVBQUU7RUFDaEIsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxrQkFBa0IsRUFBRTtFQUN6QixLQUFLLGtCQUFrQjtFQUN2QixLQUFLLHdCQUF3QjtFQUM3QixLQUFLLFFBQVE7RUFDYixLQUFLLGNBQWM7Q0FDdkI7Q0FFQSxXQUFnQztFQUM1QixPQUFPLEtBQUs7Q0FDaEI7Q0FFQSxjQUEyQjtFQUN2QixNQUFNLFVBQVUsS0FBSztFQUNyQixLQUFLLFNBQVMsQ0FBQztFQUNmLE9BQU87Q0FDWDs7Q0FJQSxBQUFRLGNBQWMsSUFBa0I7RUFDcEMsS0FBSyxNQUFNLGlCQUFpQjtFQUU1QixNQUFNLEtBQUssS0FBSyxNQUFNLE9BQU87RUFDN0IsR0FBRyxRQUFRLEtBQUssSUFBSSxHQUFHLEdBQUcsUUFBUSxFQUFFO0VBQ3BDLEdBQUcsT0FBTyxLQUFLLElBQUksR0FBRyxHQUFHLE9BQU8sRUFBRTtFQUNsQyxHQUFHLFFBQVEsS0FBSyxJQUFJLEdBQUcsR0FBRyxRQUFRLEVBQUU7RUFFcEMsS0FBSyxNQUFNLFNBQVMsS0FBSyxNQUFNLFNBQVM7R0FDcEMsSUFBSSxDQUFDLE1BQU0sUUFBUTtJQUNmLE1BQU0sV0FBVyxLQUFLLElBQUksR0FBRyxNQUFNLFdBQVcsRUFBRTtHQUNwRDtFQUNKO0VBRUEsS0FBSyxhQUFhLEtBQUssSUFBSSxHQUFHLEtBQUssYUFBYSxFQUFFO0NBQ3REO0NBRUEsQUFBUSxpQkFBaUIsSUFBWSxPQUF5QjtFQUMxRCxNQUFNLElBQUksS0FBSyxNQUFNO0VBQ3JCLElBQUksRUFBRSxRQUFRO0VBRWQsTUFBTSxRQUFRLEtBQUs7RUFDbkIsSUFBSSxNQUFNLFVBQVUsRUFBRSxZQUFZLEtBQUssT0FBTyxrQkFBa0I7RUFDaEUsSUFBSSxNQUFNLFdBQVcsRUFBRSxZQUFZLEtBQUssT0FBTyxrQkFBa0I7RUFFakUsSUFBSSxNQUFNLFFBQVE7R0FDZCxFQUFFLFNBQVMsS0FBSyxLQUFLLElBQUksRUFBRSxRQUFRLElBQUksS0FBSyxPQUFPLGtCQUFrQjtHQUNyRSxFQUFFLFNBQVMsS0FBSyxLQUFLLElBQUksRUFBRSxRQUFRLElBQUksS0FBSyxPQUFPLGtCQUFrQjtFQUN6RTtDQUNKO0NBRUEsQUFBUSxlQUFxQjtFQUN6QixJQUFJLEtBQUssYUFBYSxHQUFHO0VBRXpCLE1BQU0sYUFBYSxLQUFLLE1BQU0sUUFBUSxRQUFPLE1BQUssQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0VBQzdELElBQUksY0FBYyxLQUFLLE9BQU8saUJBQWlCO0VBRS9DLEtBQUssYUFBYSxLQUFLLFFBQVE7RUFFL0IsTUFBTSxNQUFNLEtBQUssa0JBQWtCO0VBQ25DLElBQUksQ0FBQyxLQUFLO0VBRVYsTUFBTSxjQUFjLEtBQUssT0FBTyxlQUFlLEtBQUssT0FBTztFQUMzRCxNQUFNLE9BQWtCLEtBQUssSUFBSSxPQUFPLElBQUksY0FBYyxLQUFLLE9BQU8sZUFBZSxXQUFXO0VBQ2hHLE1BQU0sV0FBVyxTQUFTO0VBRTFCLE1BQU0sUUFBb0I7R0FDdEIsSUFBSSxLQUFLLE1BQU07R0FDZjtHQUNBLFVBQVU7R0FDVixVQUFVLEtBQUssTUFDWCxLQUFLLE1BQU0sT0FBTyxTQUFTLElBQUksSUFBSSxHQUNuQyxLQUFLLE1BQU0sT0FBTyxTQUFTLElBQUksSUFBSSxDQUN2QztHQUNBLFFBQVEsV0FBVyxLQUFLLE9BQU8sZUFBZSxLQUFLLE9BQU87R0FDMUQsVUFBVSxLQUFLLE9BQU87R0FDdEIsUUFBUTtFQUNaO0VBRUEsS0FBSyxNQUFNLFFBQVEsS0FBSyxLQUFLO0NBQ2pDO0NBRUEsQUFBUSxvQkFBb0M7RUFDeEMsTUFBTSxTQUFTLEtBQUssT0FBTztFQUMzQixNQUFNLEVBQUUsT0FBTyxXQUFXLEtBQUs7RUFFL0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssT0FBTyxrQkFBa0IsS0FBSztHQUNuRCxJQUFJLEdBQVc7R0FDZixNQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssSUFBSSxPQUFPLElBQUksQ0FBQztHQUM3QyxRQUFRLE1BQVI7SUFDSSxLQUFLO0tBQUcsSUFBSSxLQUFLLElBQUksTUFBTSxRQUFRLFFBQVEsTUFBTTtLQUFHLElBQUk7S0FBUTtJQUNoRSxLQUFLO0tBQUcsSUFBSSxLQUFLLElBQUksTUFBTSxRQUFRLFFBQVEsTUFBTTtLQUFHLElBQUksU0FBUztLQUFRO0lBQ3pFLEtBQUs7S0FBRyxJQUFJO0tBQVEsSUFBSSxLQUFLLElBQUksTUFBTSxRQUFRLFNBQVMsTUFBTTtLQUFHO0lBQ2pFO0tBQVMsSUFBSSxRQUFRO0tBQVEsSUFBSSxLQUFLLElBQUksTUFBTSxRQUFRLFNBQVMsTUFBTTtLQUFHO0dBQzlFO0dBRUEsTUFBTSxNQUFNO0lBQUU7SUFBRztHQUFFO0dBQ25CLElBQUksTUFBTSxLQUFLLEtBQUssTUFBTSxPQUFPLFFBQVEsSUFBSSxLQUFLLE9BQU8sa0JBQWtCO0dBRTNFLE1BQU0sY0FBc0I7SUFBRTtJQUFLLFFBQVEsS0FBSyxPQUFPO0dBQWlCO0dBQ3hFLElBQUksVUFBVTtHQUNkLEtBQUssTUFBTSxVQUFVLEtBQUssTUFBTSxTQUFTO0lBQ3JDLElBQUksYUFBYSxhQUFhLE9BQU8sT0FBTyxDQUFDLENBQUMsVUFBVTtLQUNwRCxVQUFVO0tBQ1Y7SUFDSjtHQUNKO0dBQ0EsSUFBSSxTQUFTO0dBRWIsT0FBTztFQUNYO0VBQ0EsT0FBTztDQUNYO0NBRUEsQUFBUSxTQUFTLElBQWtCO0VBQy9CLE1BQU0sUUFBUSxLQUFLO0VBQ25CLE1BQU0sWUFBWSxLQUFLLE1BQU0sT0FBTztFQUVwQyxLQUFLLE1BQU0sU0FBUyxLQUFLLE1BQU0sU0FBUztHQUNwQyxJQUFJLE1BQU0sUUFBUTtHQUVsQixNQUFNLFdBQVcsS0FBSyxXQUFXLE1BQU0sUUFBUTtHQUMvQyxNQUFNLGNBQWMsS0FBSyxNQUFNLFNBQVMsR0FBRyxTQUFTLENBQUM7R0FDckQsTUFBTSxZQUFZLE1BQU0sU0FBUyxXQUMzQixLQUFLLE9BQU8sa0JBQ1osS0FBSyxPQUFPO0dBRWxCLE1BQU0sV0FBVyxLQUFLLGFBQWEsTUFBTSxVQUFVLGFBQWEsWUFBWSxLQUFLO0dBRWpGLE1BQU0sT0FBTyxLQUFLLFFBQVE7R0FDMUIsTUFBTSxRQUFRLE1BQU0sU0FBUyxXQUFXLEtBQUssT0FBTyxjQUFjLEtBQUssT0FBTztHQUU5RSxJQUFJLE1BQU0sU0FBUyxhQUFhLFFBQVEsS0FBSyxPQUFPLG9CQUFvQjs7SUFFcEUsTUFBTSxZQUFZLEtBQUssSUFBSSxLQUFLLGVBQWUsY0FBYyxNQUFNLFFBQVEsQ0FBQztJQUM1RSxJQUFJLFlBQVksS0FBSyxPQUFPLHVCQUF1QixNQUFNLFlBQVksR0FBRztLQUNwRSxLQUFLLG9CQUFvQixLQUFLO0lBQ2xDO0dBQ0osT0FBTzs7SUFFSCxNQUFNLFNBQVMsS0FBSyxLQUFLLElBQUksTUFBTSxRQUFRLElBQUksUUFBUTtJQUN2RCxNQUFNLFNBQVMsS0FBSyxLQUFLLElBQUksTUFBTSxRQUFRLElBQUksUUFBUTtHQUMzRDtFQUVKO0NBRUo7Q0FFQSxBQUFRLGFBQWEsU0FBaUIsUUFBZ0IsU0FBeUI7RUFDM0UsTUFBTSxPQUFPLEtBQUssZUFBZSxTQUFTLE9BQU87RUFDakQsSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLFNBQVMsT0FBTztFQUN0QyxPQUFPLFVBQVUsS0FBSyxLQUFLLElBQUksSUFBSTtDQUN2QztDQUVBLEFBQVEsZUFBZSxHQUFtQjtFQUN0QyxPQUFPLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLO0VBQ2xDLE9BQU8sSUFBSSxDQUFDLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSztFQUNuQyxPQUFPO0NBQ1g7Q0FFQSxBQUFRLFlBQVksT0FBeUI7RUFDekMsTUFBTSxJQUFJLEtBQUssTUFBTTtFQUNyQixJQUFJLEVBQUUsUUFBUTs7RUFHZCxJQUFJLE1BQU0sYUFBYSxFQUFFLFVBQVUsU0FBUyxHQUFHO0dBQzNDLE1BQU0sTUFBTTtJQUFFLEdBQUcsS0FBSyxJQUFJLEVBQUUsUUFBUTtJQUFHLEdBQUcsS0FBSyxJQUFJLEVBQUUsUUFBUTtHQUFFO0dBQy9ELEtBQUssaUJBQWlCLEVBQUUsSUFBSSxFQUFFLFVBQVUsR0FBRztHQUMzQyxFQUFFLFVBQVUsUUFBUSxLQUFLLE9BQU87R0FDaEMsS0FBSyxPQUFPLEtBQUs7SUFBRSxNQUFNO0lBQWEsY0FBYyxJQUFJLEtBQUs7SUFBVSxTQUFTLEVBQUU7R0FBRyxDQUFDO0VBQzFGOztFQUdBLElBQUksTUFBTSxZQUFZLEVBQUUsVUFBVSxRQUFRLEdBQUc7R0FDekMsTUFBTSxVQUFVO0lBQUUsR0FBRyxLQUFLLElBQUksRUFBRSxXQUFXLEtBQUssS0FBSyxDQUFDO0lBQUcsR0FBRyxLQUFLLElBQUksRUFBRSxXQUFXLEtBQUssS0FBSyxDQUFDO0dBQUU7R0FDL0YsS0FBSyxjQUFjLEdBQUcsT0FBTztHQUM3QixFQUFFLFVBQVUsT0FBTyxLQUFLLE9BQU87RUFDbkM7O0VBR0EsSUFBSSxNQUFNLGFBQWEsRUFBRSxVQUFVLFNBQVMsR0FBRztHQUMzQyxNQUFNLFdBQVc7SUFBRSxHQUFHLEtBQUssSUFBSSxFQUFFLFdBQVcsS0FBSyxLQUFLLENBQUM7SUFBRyxHQUFHLEtBQUssSUFBSSxFQUFFLFdBQVcsS0FBSyxLQUFLLENBQUM7R0FBRTtHQUNoRyxLQUFLLGNBQWMsR0FBRyxRQUFRO0dBQzlCLEVBQUUsVUFBVSxRQUFRLEtBQUssT0FBTztFQUNwQztDQUVKO0NBRUEsQUFBUSxjQUFjLFFBQXFCLEtBQW9CO0VBQzNELE1BQU0sVUFBVTtHQUFFLEdBQUcsS0FBSyxJQUFJLE9BQU8sUUFBUTtHQUFHLEdBQUcsS0FBSyxJQUFJLE9BQU8sUUFBUTtFQUFFO0VBQzdFLE1BQU0sVUFBVSxLQUFLLE9BQU87RUFFNUIsS0FBSyxNQUFNLFVBQVUsU0FBUztHQUMxQixNQUFNLFNBQVMsS0FBSyxPQUFPLFVBQVUsT0FBTyxTQUFTLE1BQU0sQ0FBQztHQUM1RCxLQUFLLGlCQUFpQixPQUFPLElBQUksUUFBUSxHQUFHO0VBQ2hEO0VBRUEsS0FBSyxPQUFPLEtBQUs7R0FBRSxNQUFNO0dBQWEsY0FBYztHQUFhLFNBQVMsT0FBTztFQUFHLENBQUM7Q0FDekY7Q0FFQSxBQUFRLG9CQUFvQixPQUF5QjtFQUNqRCxNQUFNLE1BQU07R0FBRSxHQUFHLEtBQUssSUFBSSxNQUFNLFFBQVE7R0FBRyxHQUFHLEtBQUssSUFBSSxNQUFNLFFBQVE7RUFBRTtFQUN2RSxLQUFLLGlCQUFpQixNQUFNLElBQUksTUFBTSxVQUFVLEdBQUc7RUFDbkQsTUFBTSxXQUFXLEtBQUssT0FBTztFQUM3QixLQUFLLE9BQU8sS0FBSztHQUFFLE1BQU07R0FBYSxjQUFjLElBQUksS0FBSztHQUFVLFNBQVMsTUFBTTtFQUFHLENBQUM7Q0FDOUY7Q0FFQSxBQUFRLGlCQUFpQixTQUFpQixRQUFpQixLQUFvQjtFQUMzRSxNQUFNLGFBQWEsTUFBTSxHQUFHO0VBQzVCLEtBQUssTUFBTSxZQUFZLEtBQUs7R0FDeEIsSUFBSSxLQUFLLE1BQU07R0FDZjtHQUNBLFVBQVUsRUFBRSxHQUFHLE9BQU87R0FDdEIsVUFBVSxPQUFPLFlBQVksS0FBSyxPQUFPLGVBQWU7R0FDeEQsUUFBUSxLQUFLLE9BQU87R0FDcEIsVUFBVSxLQUFLLE9BQU87RUFDMUIsQ0FBQztDQUNMO0NBRUEsQUFBUSxrQkFBa0IsSUFBa0I7RUFDeEMsTUFBTSxRQUFRLEtBQUs7RUFDbkIsS0FBSyxNQUFNLFFBQVEsS0FBSyxNQUFNLGFBQWE7R0FDdkMsS0FBSyxTQUFTLEtBQUssS0FBSyxTQUFTLElBQUk7R0FDckMsS0FBSyxTQUFTLEtBQUssS0FBSyxTQUFTLElBQUk7R0FDckMsS0FBSyxZQUFZO0VBQ3JCO0NBQ0o7Q0FFQSxBQUFRLG9CQUEwQjtFQUM5QixNQUFNLElBQUksS0FBSzs7RUFHZixLQUFLLGFBQWEsRUFBRSxPQUFPLFVBQVUsS0FBSyxPQUFPLG9CQUFvQixDQUFDO0VBQ3RFLEtBQUssTUFBTSxTQUFTLEVBQUUsU0FBUztHQUMzQixJQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssYUFBYSxNQUFNLFVBQVUsS0FBSyxPQUFPLG1CQUFtQixDQUFDO0VBQ3pGOztFQUdBLE1BQU0sWUFBWSxVQUFVLEVBQUUsT0FBTyxVQUFVLEtBQUssT0FBTyxtQkFBbUIsS0FBSyxPQUFPLG9CQUFvQixFQUFFLE9BQU8sUUFBUTtFQUMvSCxLQUFLLE1BQU0sVUFBVSxLQUFLLE1BQU0sU0FBUztHQUNyQyxNQUFNLElBQUksV0FBVyxXQUFXLE9BQU8sT0FBTztHQUM5QyxJQUFJLEVBQUUsWUFBWSxFQUFFLEtBQUs7SUFDckIsRUFBRSxPQUFPLFNBQVMsS0FBSyxFQUFFLElBQUk7SUFDN0IsRUFBRSxPQUFPLFNBQVMsS0FBSyxFQUFFLElBQUk7R0FDakM7RUFDSjs7RUFHQSxLQUFLLE1BQU0sU0FBUyxFQUFFLFNBQVM7R0FDM0IsSUFBSSxNQUFNLFFBQVE7R0FDbEIsTUFBTSxNQUFNLFVBQVUsTUFBTSxVQUFVLEtBQUssT0FBTyxrQkFBa0IsS0FBSyxPQUFPLG1CQUFtQixNQUFNLFFBQVE7R0FDakgsS0FBSyxNQUFNLFVBQVUsS0FBSyxNQUFNLFNBQVM7SUFDckMsTUFBTSxJQUFJLFdBQVcsS0FBSyxPQUFPLE9BQU87SUFDeEMsSUFBSSxFQUFFLFlBQVksRUFBRSxLQUFLO0tBQ3JCLE1BQU0sU0FBUyxLQUFLLEVBQUUsSUFBSTtLQUMxQixNQUFNLFNBQVMsS0FBSyxFQUFFLElBQUk7SUFDOUI7R0FDSjtFQUNKOztFQUdBLEtBQUssTUFBTSxRQUFRLEVBQUUsYUFBYTtHQUM5QixJQUFJLEtBQUssWUFBWSxHQUFHO0dBQ3hCLElBQUksS0FBSyxTQUFTLElBQUksS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLE1BQU0sU0FDcEQsS0FBSyxTQUFTLElBQUksS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUTtJQUM1RCxLQUFLLFdBQVc7SUFDaEI7R0FDSjtHQUNBLE1BQU0sU0FBaUI7SUFBRSxLQUFLLEtBQUs7SUFBVSxRQUFRLEtBQUssT0FBTztHQUFpQjtHQUNsRixLQUFLLE1BQU0sVUFBVSxLQUFLLE1BQU0sU0FBUztJQUNyQyxJQUFJLGFBQWEsUUFBUSxPQUFPLE9BQU8sQ0FBQyxDQUFDLFVBQVU7S0FDL0MsS0FBSyxXQUFXO0tBQ2hCO0lBQ0o7R0FDSjtFQUNKOztFQUdBLEtBQUssTUFBTSxRQUFRLEVBQUUsYUFBYTtHQUM5QixJQUFJLEtBQUssWUFBWSxLQUFLLEtBQUssWUFBWSxVQUFVO0dBQ3JELE1BQU0sS0FBYTtJQUFFLEtBQUssS0FBSztJQUFVLFFBQVEsS0FBSyxPQUFPO0dBQWlCO0dBQzlFLEtBQUssTUFBTSxTQUFTLEVBQUUsU0FBUztJQUMzQixJQUFJLE1BQU0sUUFBUTtJQUNsQixNQUFNLE1BQU0sVUFBVSxNQUFNLFVBQVUsS0FBSyxPQUFPLGtCQUFrQixLQUFLLE9BQU8sbUJBQW1CLE1BQU0sUUFBUTtJQUNqSCxJQUFJLGFBQWEsSUFBSSxHQUFHLENBQUMsQ0FBQyxVQUFVO0tBQ2hDLE1BQU0sVUFBVSxLQUFLO0tBQ3JCLEtBQUssV0FBVztLQUNoQixLQUFLLE9BQU8sS0FBSztNQUFFLE1BQU07TUFBaUIsY0FBYyxLQUFLO01BQUksVUFBVSxNQUFNO0tBQUcsQ0FBQztLQUNyRjtJQUNKO0dBQ0o7RUFDSjs7RUFHQSxJQUFJLENBQUMsRUFBRSxPQUFPLFFBQVE7R0FFbEIsTUFBTSxPQUFPLFVBQVUsRUFBRSxPQUFPLFVBQVUsS0FBSyxPQUFPLG1CQUFtQixLQUFLLE9BQU8sb0JBQW9CLEVBQUUsT0FBTyxRQUFRO0dBQzFILEtBQUssTUFBTSxRQUFRLEVBQUUsYUFBYTtJQUM5QixJQUFJLEtBQUssWUFBWSxLQUFLLEtBQUssWUFBWSxVQUFVO0lBQ3JELE1BQU0sS0FBYTtLQUFFLEtBQUssS0FBSztLQUFVLFFBQVEsS0FBSyxPQUFPO0lBQWlCO0lBQzlFLElBQUksYUFBYSxJQUFJLElBQUksQ0FBQyxDQUFDLFVBQVU7S0FDakMsRUFBRSxPQUFPLFVBQVUsS0FBSztLQUN4QixLQUFLLFdBQVc7S0FDaEIsS0FBSyxPQUFPLEtBQUs7TUFBRSxNQUFNO01BQWlCLFFBQVEsS0FBSztLQUFPLENBQUM7S0FDL0QsS0FBSyxPQUFPLEtBQUs7TUFBRSxNQUFNO01BQWlCLGNBQWMsS0FBSztNQUFJLFVBQVU7S0FBUyxDQUFDO0lBQ3pGO0dBQ0o7RUFFSjs7RUFHQSxJQUFJLENBQUMsRUFBRSxPQUFPLFFBQVE7R0FFbEIsTUFBTSxPQUFPLFVBQVUsRUFBRSxPQUFPLFVBQVUsS0FBSyxPQUFPLG1CQUFtQixLQUFLLE9BQU8sb0JBQW9CLEVBQUUsT0FBTyxRQUFRO0dBQzFILEtBQUssTUFBTSxTQUFTLEVBQUUsU0FBUztJQUMzQixJQUFJLE1BQU0sVUFBVSxNQUFNLFNBQVMsWUFBWSxNQUFNLFVBQVUsR0FBRztJQUNsRSxNQUFNLE1BQU0sVUFBVSxNQUFNLFVBQVUsS0FBSyxPQUFPLGtCQUFrQixLQUFLLE9BQU8sbUJBQW1CLE1BQU0sUUFBUTtJQUNqSCxJQUFJLFdBQVcsTUFBTSxHQUFHLENBQUMsQ0FBQyxVQUFVO0tBQ2hDLEVBQUUsT0FBTyxVQUFVLEtBQUssT0FBTztLQUMvQixNQUFNLFNBQVM7S0FDZixNQUFNLG9CQUFvQjtLQUMxQixLQUFLLE9BQU8sS0FBSztNQUFFLE1BQU07TUFBaUIsUUFBUSxLQUFLLE9BQU87S0FBc0IsQ0FBQztJQUN6RjtHQUNKO0VBRUo7Q0FFSjtDQUVBLEFBQVEsYUFBYSxLQUFjLFFBQXNCO0VBQ3JELElBQUksSUFBSSxLQUFLLElBQUksUUFBUSxLQUFLLElBQUksS0FBSyxNQUFNLFFBQVEsUUFBUSxJQUFJLENBQUMsQ0FBQztFQUNuRSxJQUFJLElBQUksS0FBSyxJQUFJLFFBQVEsS0FBSyxJQUFJLEtBQUssTUFBTSxTQUFTLFFBQVEsSUFBSSxDQUFDLENBQUM7Q0FDeEU7Q0FFQSxBQUFRLDBCQUFnQztFQUNwQyxNQUFNLElBQUksS0FBSztFQUVmLElBQUksQ0FBQyxFQUFFLE9BQU8sVUFBVSxFQUFFLE9BQU8sVUFBVSxHQUFHO0dBQzFDLEVBQUUsT0FBTyxTQUFTO0dBQ2xCLEVBQUUsT0FBTyxTQUFTO0dBQ2xCLEtBQUssT0FBTyxLQUFLO0lBQUUsTUFBTTtJQUFpQixRQUFRO0lBQVUsVUFBVTtHQUFLLENBQUM7RUFDaEY7O0VBR0EsS0FBSyxNQUFNLFNBQVMsRUFBRSxTQUFTO0dBQzNCLElBQUksQ0FBQyxNQUFNLFVBQVUsTUFBTSxVQUFVLEdBQUc7SUFDcEMsTUFBTSxTQUFTO0lBQ2YsTUFBTSxTQUFTO0lBQ2YsS0FBSyxPQUFPLEtBQUs7S0FBRSxNQUFNO0tBQWlCLFFBQVEsTUFBTTtLQUFJLFVBQVU7SUFBTSxDQUFDOztJQUU3RSxJQUFJLENBQUMsTUFBTSxtQkFBbUI7S0FDMUIsRUFBRSxTQUFTO0tBQ1gsS0FBSyxPQUFPLEtBQUs7TUFBRSxNQUFNO01BQWdCLFVBQVUsRUFBRTtLQUFNLENBQUM7SUFDaEU7R0FDSjtFQUNKO0NBRUo7Q0FFQSxBQUFRLFVBQWdCO0VBQ3BCLEtBQUssTUFBTSxjQUFjLEtBQUssTUFBTSxZQUFZLFFBQU8sTUFBSyxFQUFFLFdBQVcsQ0FBQztFQUMxRSxLQUFLLE1BQU0sVUFBVSxLQUFLLE1BQU0sUUFBUSxRQUFPLE1BQUssQ0FBQyxFQUFFLE1BQU07Q0FDakU7Q0FFQSxBQUFRLGdCQUFzQjtFQUMxQixNQUFNLElBQUksS0FBSzs7RUFFZixJQUFJLEVBQUUsT0FBTyxRQUFRO0dBQ2pCLEVBQUUsYUFBYTtHQUNmLEVBQUUsWUFBWTtHQUNkLEtBQUssT0FBTyxLQUFLO0lBQUUsTUFBTTtJQUFjLFFBQVE7R0FBYyxDQUFDO0VBQ2xFLE9BQU8sSUFBSSxFQUFFLGlCQUFpQixHQUFHO0dBQzdCLEVBQUUsZ0JBQWdCO0dBQ2xCLEVBQUUsYUFBYTtHQUNmLEVBQUUsWUFBWTtHQUNkLEtBQUssT0FBTyxLQUFLO0lBQUUsTUFBTTtJQUFjLFFBQVE7R0FBVSxDQUFDO0VBQzlEO0NBQ0o7QUFFSiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzaW11bGF0aW9uLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHtcclxuICAgIEdhbWVTdGF0ZSwgR2FtZUV2ZW50LCBJbnB1dFN0YXRlLCBQbGF5ZXJTdGF0ZSxcclxuICAgIEVuZW15U3RhdGUsIEVuZW15VHlwZSwgVmVjdG9yMiwgR2FtZUNvbmZpZyxcclxuICAgIEFyZW5hRGVmLCBTZXNzaW9uQ29uZmlnLFxyXG59IGZyb20gJy4vdHlwZXMnO1xyXG5pbXBvcnQgeyBSTkcgfSBmcm9tICcuL3JuZyc7XHJcbmltcG9ydCB7XHJcbiAgICB2QWRkLCB2U3ViLCB2U2NhbGUsIHZOb3JtLCB2TGVuLCB2RGlzdCxcclxuICAgIGNyZWF0ZU9CQiwgcG9seVZzUG9seSwgY2lyY2xlVnNQb2x5LFxyXG4gICAgdHlwZSBDaXJjbGUsXHJcbn0gZnJvbSAnLi9nZW9tZXRyeSc7XHJcblxyXG5cclxuLy8gLS0tIFNpbXVsYXRpb24gLS0tXHJcblxyXG5leHBvcnQgY2xhc3MgU2ltdWxhdGlvbiB7XHJcblxyXG4gICAgcHJpdmF0ZSBzdGF0ZTogR2FtZVN0YXRlO1xyXG5cclxuICAgIHByaXZhdGUgZXZlbnRzOiBHYW1lRXZlbnRbXSA9IFtdO1xyXG4gICAgcHJpdmF0ZSBybmc6IFJORztcclxuXHJcbiAgICBwcml2YXRlIGFyZW5hOiBBcmVuYURlZjtcclxuXHJcbiAgICBwcml2YXRlIGNvbmZpZzogR2FtZUNvbmZpZztcclxuXHJcbiAgICBwcml2YXRlIHNlc3Npb246IFNlc3Npb25Db25maWc7XHJcbiAgICBwcml2YXRlIHNwYXduVGltZXI6IG51bWJlcjtcclxuICAgIHByaXZhdGUgbmV4dElkID0gMDtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBjb25maWc6IEdhbWVDb25maWcsXHJcbiAgICAgICAgYXJlbmE6IEFyZW5hRGVmLFxyXG4gICAgICAgIHNlZWQ6IG51bWJlcixcclxuICAgICAgICBzZXNzaW9uVGltZVNlYzogbnVtYmVyLFxyXG4gICAgICAgIHNwYXduSW50ZXJ2YWxTZWM6IG51bWJlcixcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gY29uZmlnO1xyXG4gICAgICAgIHRoaXMuYXJlbmEgPSBhcmVuYTtcclxuICAgICAgICB0aGlzLnJuZyA9IG5ldyBSTkcoc2VlZCk7XHJcbiAgICAgICAgdGhpcy5zZXNzaW9uID0ge1xyXG4gICAgICAgICAgICBzZXNzaW9uVGltZU1zOiBzZXNzaW9uVGltZVNlYyAqIDEwMDAsXHJcbiAgICAgICAgICAgIHNwYXduSW50ZXJ2YWxNczogc3Bhd25JbnRlcnZhbFNlYyAqIDEwMDAsXHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLnNwYXduVGltZXIgPSB0aGlzLnNlc3Npb24uc3Bhd25JbnRlcnZhbE1zO1xyXG5cclxuICAgICAgICB0aGlzLnN0YXRlID0ge1xyXG4gICAgICAgICAgICB0aW1lUmVtYWluaW5nOiB0aGlzLnNlc3Npb24uc2Vzc2lvblRpbWVNcyxcclxuICAgICAgICAgICAgc2NvcmU6IDAsXHJcbiAgICAgICAgICAgIHBsYXllcjoge1xyXG4gICAgICAgICAgICAgICAgaWQ6ICdwbGF5ZXInLFxyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHsgeDogYXJlbmEud2lkdGggLyAyLCB5OiBhcmVuYS5oZWlnaHQgLyAyIH0sXHJcbiAgICAgICAgICAgICAgICByb3RhdGlvbjogMCxcclxuICAgICAgICAgICAgICAgIGhlYWx0aDogY29uZmlnLnBsYXllck1heEhlYWx0aCxcclxuICAgICAgICAgICAgICAgIGNvb2xkb3duczogeyBmcm9udDogMCwgbGVmdDogMCwgcmlnaHQ6IDAgfSxcclxuICAgICAgICAgICAgICAgIGlzRGVhZDogZmFsc2UsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGVuZW1pZXM6IFtdLFxyXG4gICAgICAgICAgICBwcm9qZWN0aWxlczogW10sXHJcbiAgICAgICAgICAgIGlzR2FtZU92ZXI6IGZhbHNlLFxyXG4gICAgICAgICAgICBlbmRSZWFzb246IG51bGwsXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGdlbklkKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIGBlJHt0aGlzLm5leHRJZCsrfWA7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PSBQdWJsaWMgQVBJID09PT09PT09PT1cclxuXHJcbiAgICBzdGVwKGR0OiBudW1iZXIsIGlucHV0OiBJbnB1dFN0YXRlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuc3RhdGUuaXNHYW1lT3ZlcikgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmFkdmFuY2VUaW1lcnMoZHQpO1xyXG4gICAgICAgIHRoaXMuYXBwbHlQbGF5ZXJJbnB1dChkdCwgaW5wdXQpO1xyXG4gICAgICAgIHRoaXMuc3Bhd25FbmVtaWVzKCk7XHJcbiAgICAgICAgdGhpcy51cGRhdGVBSShkdCk7XHJcbiAgICAgICAgdGhpcy5maXJlV2VhcG9ucyhpbnB1dCk7XHJcbiAgICAgICAgdGhpcy5pbnRlZ3JhdGVNb3ZlbWVudChkdCk7XHJcbiAgICAgICAgdGhpcy5yZXNvbHZlQ29sbGlzaW9ucygpO1xyXG4gICAgICAgIHRoaXMucHJvY2Vzc0RlYXRoc0FuZFNjb3JpbmcoKTtcclxuICAgICAgICB0aGlzLmNsZWFudXAoKTtcclxuICAgICAgICB0aGlzLmNoZWNrTWF0Y2hFbmQoKTtcclxuICAgIH1cclxuXHJcbiAgICBnZXRTdGF0ZSgpOiBSZWFkb25seTxHYW1lU3RhdGU+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5zdGF0ZTtcclxuICAgIH1cclxuXHJcbiAgICBkcmFpbkV2ZW50cygpOiBHYW1lRXZlbnRbXSB7XHJcbiAgICAgICAgY29uc3QgZHJhaW5lZCA9IHRoaXMuZXZlbnRzO1xyXG4gICAgICAgIHRoaXMuZXZlbnRzID0gW107XHJcbiAgICAgICAgcmV0dXJuIGRyYWluZWQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PSBTeXN0ZW1zID09PT09PT09PT1cclxuXHJcbiAgICBwcml2YXRlIGFkdmFuY2VUaW1lcnMoZHQ6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuc3RhdGUudGltZVJlbWFpbmluZyAtPSBkdDtcclxuXHJcbiAgICAgICAgY29uc3QgY2QgPSB0aGlzLnN0YXRlLnBsYXllci5jb29sZG93bnM7XHJcbiAgICAgICAgY2QuZnJvbnQgPSBNYXRoLm1heCgwLCBjZC5mcm9udCAtIGR0KTtcclxuICAgICAgICBjZC5sZWZ0ID0gTWF0aC5tYXgoMCwgY2QubGVmdCAtIGR0KTtcclxuICAgICAgICBjZC5yaWdodCA9IE1hdGgubWF4KDAsIGNkLnJpZ2h0IC0gZHQpO1xyXG5cclxuICAgICAgICBmb3IgKGNvbnN0IGVuZW15IG9mIHRoaXMuc3RhdGUuZW5lbWllcykge1xyXG4gICAgICAgICAgICBpZiAoIWVuZW15LmlzRGVhZCkge1xyXG4gICAgICAgICAgICAgICAgZW5lbXkuY29vbGRvd24gPSBNYXRoLm1heCgwLCBlbmVteS5jb29sZG93biAtIGR0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5zcGF3blRpbWVyID0gTWF0aC5tYXgoMCwgdGhpcy5zcGF3blRpbWVyIC0gZHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgYXBwbHlQbGF5ZXJJbnB1dChkdDogbnVtYmVyLCBpbnB1dDogSW5wdXRTdGF0ZSk6IHZvaWQge1xyXG4gICAgICAgIGNvbnN0IHAgPSB0aGlzLnN0YXRlLnBsYXllcjtcclxuICAgICAgICBpZiAocC5pc0RlYWQpIHJldHVybjtcclxuXHJcbiAgICAgICAgY29uc3QgZHRTZWMgPSBkdCAvIDEwMDA7XHJcbiAgICAgICAgaWYgKGlucHV0LnR1cm5MZWZ0KSBwLnJvdGF0aW9uIC09IHRoaXMuY29uZmlnLnBsYXllclR1cm5TcGVlZCAqIGR0U2VjO1xyXG4gICAgICAgIGlmIChpbnB1dC50dXJuUmlnaHQpIHAucm90YXRpb24gKz0gdGhpcy5jb25maWcucGxheWVyVHVyblNwZWVkICogZHRTZWM7XHJcblxyXG4gICAgICAgIGlmIChpbnB1dC50aHJ1c3QpIHtcclxuICAgICAgICAgICAgcC5wb3NpdGlvbi54ICs9IE1hdGguY29zKHAucm90YXRpb24pICogdGhpcy5jb25maWcucGxheWVyTW92ZVNwZWVkICogZHRTZWM7XHJcbiAgICAgICAgICAgIHAucG9zaXRpb24ueSArPSBNYXRoLnNpbihwLnJvdGF0aW9uKSAqIHRoaXMuY29uZmlnLnBsYXllck1vdmVTcGVlZCAqIGR0U2VjO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHNwYXduRW5lbWllcygpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5zcGF3blRpbWVyID4gMCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBjb25zdCBhbGl2ZUNvdW50ID0gdGhpcy5zdGF0ZS5lbmVtaWVzLmZpbHRlcihlID0+ICFlLmlzRGVhZCkubGVuZ3RoO1xyXG4gICAgICAgIGlmIChhbGl2ZUNvdW50ID49IHRoaXMuY29uZmlnLm1heEFsaXZlRW5lbWllcykgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLnNwYXduVGltZXIgPSB0aGlzLnNlc3Npb24uc3Bhd25JbnRlcnZhbE1zO1xyXG5cclxuICAgICAgICBjb25zdCBwb3MgPSB0aGlzLmZpbmRTcGF3blBvc2l0aW9uKCk7XHJcbiAgICAgICAgaWYgKCFwb3MpIHJldHVybjtcclxuXHJcbiAgICAgICAgY29uc3QgdG90YWxXZWlnaHQgPSB0aGlzLmNvbmZpZy5jaGFzZXJXZWlnaHQgKyB0aGlzLmNvbmZpZy5zaG9vdGVyV2VpZ2h0O1xyXG4gICAgICAgIGNvbnN0IHR5cGU6IEVuZW15VHlwZSA9IHRoaXMucm5nLnJhbmRvbSgpICogdG90YWxXZWlnaHQgPCB0aGlzLmNvbmZpZy5jaGFzZXJXZWlnaHQgPyAnY2hhc2VyJyA6ICdzaG9vdGVyJztcclxuICAgICAgICBjb25zdCBpc0NoYXNlciA9IHR5cGUgPT09ICdjaGFzZXInO1xyXG5cclxuICAgICAgICBjb25zdCBlbmVteTogRW5lbXlTdGF0ZSA9IHtcclxuICAgICAgICAgICAgaWQ6IHRoaXMuZ2VuSWQoKSxcclxuICAgICAgICAgICAgdHlwZSxcclxuICAgICAgICAgICAgcG9zaXRpb246IHBvcyxcclxuICAgICAgICAgICAgcm90YXRpb246IE1hdGguYXRhbjIoXHJcbiAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLnBsYXllci5wb3NpdGlvbi55IC0gcG9zLnksXHJcbiAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLnBsYXllci5wb3NpdGlvbi54IC0gcG9zLngsXHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIGhlYWx0aDogaXNDaGFzZXIgPyB0aGlzLmNvbmZpZy5jaGFzZXJIZWFsdGggOiB0aGlzLmNvbmZpZy5zaG9vdGVySGVhbHRoLFxyXG4gICAgICAgICAgICBjb29sZG93bjogdGhpcy5jb25maWcuc3Bhd25HcmFjZVBlcmlvZCwgLy8gR3JhY2UgcGVyaW9kIG9uIHNwYXduXHJcbiAgICAgICAgICAgIGlzRGVhZDogZmFsc2UsXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5zdGF0ZS5lbmVtaWVzLnB1c2goZW5lbXkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZmluZFNwYXduUG9zaXRpb24oKTogVmVjdG9yMiB8IG51bGwge1xyXG4gICAgICAgIGNvbnN0IG1hcmdpbiA9IHRoaXMuY29uZmlnLnNwYXduRWRnZU1hcmdpbjtcclxuICAgICAgICBjb25zdCB7IHdpZHRoLCBoZWlnaHQgfSA9IHRoaXMuYXJlbmE7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5jb25maWcuc3Bhd25NYXhBdHRlbXB0czsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCB4OiBudW1iZXIsIHk6IG51bWJlcjtcclxuICAgICAgICAgICAgY29uc3Qgc2lkZSA9IE1hdGguZmxvb3IodGhpcy5ybmcucmFuZG9tKCkgKiA0KTtcclxuICAgICAgICAgICAgc3dpdGNoIChzaWRlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IHggPSB0aGlzLnJuZy5yYW5nZShtYXJnaW4sIHdpZHRoIC0gbWFyZ2luKTsgeSA9IG1hcmdpbjsgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDE6IHggPSB0aGlzLnJuZy5yYW5nZShtYXJnaW4sIHdpZHRoIC0gbWFyZ2luKTsgeSA9IGhlaWdodCAtIG1hcmdpbjsgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6IHggPSBtYXJnaW47IHkgPSB0aGlzLnJuZy5yYW5nZShtYXJnaW4sIGhlaWdodCAtIG1hcmdpbik7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDogeCA9IHdpZHRoIC0gbWFyZ2luOyB5ID0gdGhpcy5ybmcucmFuZ2UobWFyZ2luLCBoZWlnaHQgLSBtYXJnaW4pOyBicmVhaztcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgY29uc3QgcG9zID0geyB4LCB5IH07XHJcbiAgICAgICAgICAgIGlmICh2RGlzdChwb3MsIHRoaXMuc3RhdGUucGxheWVyLnBvc2l0aW9uKSA8IHRoaXMuY29uZmlnLm1pblNwYXduRGlzdGFuY2UpIGNvbnRpbnVlO1xyXG5cclxuICAgICAgICAgICAgY29uc3Qgc3Bhd25DaXJjbGU6IENpcmNsZSA9IHsgcG9zLCByYWRpdXM6IHRoaXMuY29uZmlnLnNwYXduQ2hlY2tSYWRpdXMgfTtcclxuICAgICAgICAgICAgbGV0IGJsb2NrZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgZm9yIChjb25zdCBpc2xhbmQgb2YgdGhpcy5hcmVuYS5pc2xhbmRzKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY2lyY2xlVnNQb2x5KHNwYXduQ2lyY2xlLCBpc2xhbmQucG9seWdvbikuY29sbGlkZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBibG9ja2VkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoYmxvY2tlZCkgY29udGludWU7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gcG9zO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHVwZGF0ZUFJKGR0OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBkdFNlYyA9IGR0IC8gMTAwMDtcclxuICAgICAgICBjb25zdCBwbGF5ZXJQb3MgPSB0aGlzLnN0YXRlLnBsYXllci5wb3NpdGlvbjtcclxuXHJcbiAgICAgICAgZm9yIChjb25zdCBlbmVteSBvZiB0aGlzLnN0YXRlLmVuZW1pZXMpIHtcclxuICAgICAgICAgICAgaWYgKGVuZW15LmlzRGVhZCkgY29udGludWU7XHJcblxyXG4gICAgICAgICAgICBjb25zdCB0b1BsYXllciA9IHZTdWIocGxheWVyUG9zLCBlbmVteS5wb3NpdGlvbik7XHJcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldEFuZ2xlID0gTWF0aC5hdGFuMih0b1BsYXllci55LCB0b1BsYXllci54KTtcclxuICAgICAgICAgICAgY29uc3QgdHVyblNwZWVkID0gZW5lbXkudHlwZSA9PT0gJ2NoYXNlcidcclxuICAgICAgICAgICAgICAgID8gdGhpcy5jb25maWcuY2hhc2VyVHVyblNwZWVkXHJcbiAgICAgICAgICAgICAgICA6IHRoaXMuY29uZmlnLnNob290ZXJUdXJuU3BlZWQ7XHJcblxyXG4gICAgICAgICAgICBlbmVteS5yb3RhdGlvbiA9IHRoaXMucm90YXRlVG93YXJkKGVuZW15LnJvdGF0aW9uLCB0YXJnZXRBbmdsZSwgdHVyblNwZWVkICogZHRTZWMpO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgZGlzdCA9IHZMZW4odG9QbGF5ZXIpO1xyXG4gICAgICAgICAgICBjb25zdCBzcGVlZCA9IGVuZW15LnR5cGUgPT09ICdjaGFzZXInID8gdGhpcy5jb25maWcuY2hhc2VyU3BlZWQgOiB0aGlzLmNvbmZpZy5zaG9vdGVyU3BlZWQ7XHJcblxyXG4gICAgICAgICAgICBpZiAoZW5lbXkudHlwZSA9PT0gJ3Nob290ZXInICYmIGRpc3QgPD0gdGhpcy5jb25maWcuc2hvb3RlckF0dGFja1JhbmdlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBJbiByYW5nZTogc3RvcCBtb3ZpbmcsIGZpcmUgaWYgYWxpZ25lZFxyXG4gICAgICAgICAgICAgICAgY29uc3QgYW5nbGVEaWZmID0gTWF0aC5hYnModGhpcy5ub3JtYWxpemVBbmdsZSh0YXJnZXRBbmdsZSAtIGVuZW15LnJvdGF0aW9uKSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoYW5nbGVEaWZmIDwgdGhpcy5jb25maWcuc2hvb3RlckFpbVRvbGVyYW5jZSAmJiBlbmVteS5jb29sZG93biA8PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5maXJlRW5lbXlQcm9qZWN0aWxlKGVuZW15KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIE1vdmUgZm9yd2FyZFxyXG4gICAgICAgICAgICAgICAgZW5lbXkucG9zaXRpb24ueCArPSBNYXRoLmNvcyhlbmVteS5yb3RhdGlvbikgKiBzcGVlZCAqIGR0U2VjO1xyXG4gICAgICAgICAgICAgICAgZW5lbXkucG9zaXRpb24ueSArPSBNYXRoLnNpbihlbmVteS5yb3RhdGlvbikgKiBzcGVlZCAqIGR0U2VjO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSByb3RhdGVUb3dhcmQoY3VycmVudDogbnVtYmVyLCB0YXJnZXQ6IG51bWJlciwgbWF4U3RlcDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBjb25zdCBkaWZmID0gdGhpcy5ub3JtYWxpemVBbmdsZSh0YXJnZXQgLSBjdXJyZW50KTtcclxuICAgICAgICBpZiAoTWF0aC5hYnMoZGlmZikgPD0gbWF4U3RlcCkgcmV0dXJuIHRhcmdldDtcclxuICAgICAgICByZXR1cm4gY3VycmVudCArIE1hdGguc2lnbihkaWZmKSAqIG1heFN0ZXA7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBub3JtYWxpemVBbmdsZShhOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHdoaWxlIChhID4gTWF0aC5QSSkgYSAtPSAyICogTWF0aC5QSTtcclxuICAgICAgICB3aGlsZSAoYSA8IC1NYXRoLlBJKSBhICs9IDIgKiBNYXRoLlBJO1xyXG4gICAgICAgIHJldHVybiBhO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZmlyZVdlYXBvbnMoaW5wdXQ6IElucHV0U3RhdGUpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBwID0gdGhpcy5zdGF0ZS5wbGF5ZXI7XHJcbiAgICAgICAgaWYgKHAuaXNEZWFkKSByZXR1cm47XHJcblxyXG4gICAgICAgIC8vIEZyb250OiAxIHByb2plY3RpbGVcclxuICAgICAgICBpZiAoaW5wdXQuZmlyZUZyb250ICYmIHAuY29vbGRvd25zLmZyb250IDw9IDApIHtcclxuICAgICAgICAgICAgY29uc3QgZGlyID0geyB4OiBNYXRoLmNvcyhwLnJvdGF0aW9uKSwgeTogTWF0aC5zaW4ocC5yb3RhdGlvbikgfTtcclxuICAgICAgICAgICAgdGhpcy5jcmVhdGVQcm9qZWN0aWxlKHAuaWQsIHAucG9zaXRpb24sIGRpcik7XHJcbiAgICAgICAgICAgIHAuY29vbGRvd25zLmZyb250ID0gdGhpcy5jb25maWcuY29vbGRvd25Gcm9udDtcclxuICAgICAgICAgICAgdGhpcy5ldmVudHMucHVzaCh7IHR5cGU6ICdzaG90RmlyZWQnLCBwcm9qZWN0aWxlSWQ6IGBwJHt0aGlzLm5leHRJZH1gLCBvd25lcklkOiBwLmlkIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gTGVmdCBicm9hZHNpZGU6IDMgcHJvamVjdGlsZXNcclxuICAgICAgICBpZiAoaW5wdXQuZmlyZUxlZnQgJiYgcC5jb29sZG93bnMubGVmdCA8PSAwKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGxlZnREaXIgPSB7IHg6IE1hdGguY29zKHAucm90YXRpb24gLSBNYXRoLlBJIC8gMiksIHk6IE1hdGguc2luKHAucm90YXRpb24gLSBNYXRoLlBJIC8gMikgfTtcclxuICAgICAgICAgICAgdGhpcy5maXJlQnJvYWRzaWRlKHAsIGxlZnREaXIpO1xyXG4gICAgICAgICAgICBwLmNvb2xkb3ducy5sZWZ0ID0gdGhpcy5jb25maWcuY29vbGRvd25TaWRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gUmlnaHQgYnJvYWRzaWRlOiAzIHByb2plY3RpbGVzXHJcbiAgICAgICAgaWYgKGlucHV0LmZpcmVSaWdodCAmJiBwLmNvb2xkb3ducy5yaWdodCA8PSAwKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJpZ2h0RGlyID0geyB4OiBNYXRoLmNvcyhwLnJvdGF0aW9uICsgTWF0aC5QSSAvIDIpLCB5OiBNYXRoLnNpbihwLnJvdGF0aW9uICsgTWF0aC5QSSAvIDIpIH07XHJcbiAgICAgICAgICAgIHRoaXMuZmlyZUJyb2Fkc2lkZShwLCByaWdodERpcik7XHJcbiAgICAgICAgICAgIHAuY29vbGRvd25zLnJpZ2h0ID0gdGhpcy5jb25maWcuY29vbGRvd25TaWRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBmaXJlQnJvYWRzaWRlKHBsYXllcjogUGxheWVyU3RhdGUsIGRpcjogVmVjdG9yMik6IHZvaWQge1xyXG4gICAgICAgIGNvbnN0IGZvcndhcmQgPSB7IHg6IE1hdGguY29zKHBsYXllci5yb3RhdGlvbiksIHk6IE1hdGguc2luKHBsYXllci5yb3RhdGlvbikgfTtcclxuICAgICAgICBjb25zdCBvZmZzZXRzID0gdGhpcy5jb25maWcuYnJvYWRzaWRlT2Zmc2V0czsgLy8gT2Zmc2V0IGFsb25nIGh1bGwgbGVuZ3RoXHJcblxyXG4gICAgICAgIGZvciAoY29uc3Qgb2Zmc2V0IG9mIG9mZnNldHMpIHtcclxuICAgICAgICAgICAgY29uc3Qgb3JpZ2luID0gdkFkZChwbGF5ZXIucG9zaXRpb24sIHZTY2FsZShmb3J3YXJkLCBvZmZzZXQpKTtcclxuICAgICAgICAgICAgdGhpcy5jcmVhdGVQcm9qZWN0aWxlKHBsYXllci5pZCwgb3JpZ2luLCBkaXIpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5ldmVudHMucHVzaCh7IHR5cGU6ICdzaG90RmlyZWQnLCBwcm9qZWN0aWxlSWQ6ICdicm9hZHNpZGUnLCBvd25lcklkOiBwbGF5ZXIuaWQgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBmaXJlRW5lbXlQcm9qZWN0aWxlKGVuZW15OiBFbmVteVN0YXRlKTogdm9pZCB7XHJcbiAgICAgICAgY29uc3QgZGlyID0geyB4OiBNYXRoLmNvcyhlbmVteS5yb3RhdGlvbiksIHk6IE1hdGguc2luKGVuZW15LnJvdGF0aW9uKSB9O1xyXG4gICAgICAgIHRoaXMuY3JlYXRlUHJvamVjdGlsZShlbmVteS5pZCwgZW5lbXkucG9zaXRpb24sIGRpcik7XHJcbiAgICAgICAgZW5lbXkuY29vbGRvd24gPSB0aGlzLmNvbmZpZy5zaG9vdGVyQ29vbGRvd247XHJcbiAgICAgICAgdGhpcy5ldmVudHMucHVzaCh7IHR5cGU6ICdzaG90RmlyZWQnLCBwcm9qZWN0aWxlSWQ6IGBwJHt0aGlzLm5leHRJZH1gLCBvd25lcklkOiBlbmVteS5pZCB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNyZWF0ZVByb2plY3RpbGUob3duZXJJZDogc3RyaW5nLCBvcmlnaW46IFZlY3RvcjIsIGRpcjogVmVjdG9yMik6IHZvaWQge1xyXG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSB2Tm9ybShkaXIpO1xyXG4gICAgICAgIHRoaXMuc3RhdGUucHJvamVjdGlsZXMucHVzaCh7XHJcbiAgICAgICAgICAgIGlkOiB0aGlzLmdlbklkKCksXHJcbiAgICAgICAgICAgIG93bmVySWQsXHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiB7IC4uLm9yaWdpbiB9LFxyXG4gICAgICAgICAgICB2ZWxvY2l0eTogdlNjYWxlKG5vcm1hbGl6ZWQsIHRoaXMuY29uZmlnLnByb2plY3RpbGVTcGVlZCksXHJcbiAgICAgICAgICAgIGRhbWFnZTogdGhpcy5jb25maWcucHJvamVjdGlsZURhbWFnZSxcclxuICAgICAgICAgICAgbGlmZVRpbWU6IHRoaXMuY29uZmlnLnByb2plY3RpbGVMaWZlVGltZSxcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGludGVncmF0ZU1vdmVtZW50KGR0OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBkdFNlYyA9IGR0IC8gMTAwMDtcclxuICAgICAgICBmb3IgKGNvbnN0IHByb2ogb2YgdGhpcy5zdGF0ZS5wcm9qZWN0aWxlcykge1xyXG4gICAgICAgICAgICBwcm9qLnBvc2l0aW9uLnggKz0gcHJvai52ZWxvY2l0eS54ICogZHRTZWM7XHJcbiAgICAgICAgICAgIHByb2oucG9zaXRpb24ueSArPSBwcm9qLnZlbG9jaXR5LnkgKiBkdFNlYztcclxuICAgICAgICAgICAgcHJvai5saWZlVGltZSAtPSBkdDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSByZXNvbHZlQ29sbGlzaW9ucygpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBzID0gdGhpcy5zdGF0ZTtcclxuXHJcbiAgICAgICAgLy8gLS0tIFNoaXBzIHZzIGFyZW5hIGJvdW5kcyAtLS1cclxuICAgICAgICB0aGlzLmNsYW1wVG9BcmVuYShzLnBsYXllci5wb3NpdGlvbiwgdGhpcy5jb25maWcucGxheWVySGl0Ym94V2lkdGggLyAyKTtcclxuICAgICAgICBmb3IgKGNvbnN0IGVuZW15IG9mIHMuZW5lbWllcykge1xyXG4gICAgICAgICAgICBpZiAoIWVuZW15LmlzRGVhZCkgdGhpcy5jbGFtcFRvQXJlbmEoZW5lbXkucG9zaXRpb24sIHRoaXMuY29uZmlnLmVuZW15SGl0Ym94V2lkdGggLyAyKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIC0tLSBQbGF5ZXIgdnMgaXNsYW5kcyAoT0JCIHNsaWRlKSAtLS1cclxuICAgICAgICBjb25zdCBwbGF5ZXJPQkIgPSBjcmVhdGVPQkIocy5wbGF5ZXIucG9zaXRpb24sIHRoaXMuY29uZmlnLnBsYXllckhpdGJveFdpZHRoLCB0aGlzLmNvbmZpZy5wbGF5ZXJIaXRib3hIZWlnaHQsIHMucGxheWVyLnJvdGF0aW9uKVxyXG4gICAgICAgIGZvciAoY29uc3QgaXNsYW5kIG9mIHRoaXMuYXJlbmEuaXNsYW5kcykge1xyXG4gICAgICAgICAgICBjb25zdCByID0gcG9seVZzUG9seShwbGF5ZXJPQkIsIGlzbGFuZC5wb2x5Z29uKTtcclxuICAgICAgICAgICAgaWYgKHIuY29sbGlkZWQgJiYgci5tdHYpIHtcclxuICAgICAgICAgICAgICAgIHMucGxheWVyLnBvc2l0aW9uLnggLT0gci5tdHYueDtcclxuICAgICAgICAgICAgICAgIHMucGxheWVyLnBvc2l0aW9uLnkgLT0gci5tdHYueTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gLS0tIEVuZW1pZXMgdnMgaXNsYW5kcyAtLS1cclxuICAgICAgICBmb3IgKGNvbnN0IGVuZW15IG9mIHMuZW5lbWllcykge1xyXG4gICAgICAgICAgICBpZiAoZW5lbXkuaXNEZWFkKSBjb250aW51ZTtcclxuICAgICAgICAgICAgY29uc3Qgb2JiID0gY3JlYXRlT0JCKGVuZW15LnBvc2l0aW9uLCB0aGlzLmNvbmZpZy5lbmVteUhpdGJveFdpZHRoLCB0aGlzLmNvbmZpZy5lbmVteUhpdGJveEhlaWdodCwgZW5lbXkucm90YXRpb24pO1xyXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGlzbGFuZCBvZiB0aGlzLmFyZW5hLmlzbGFuZHMpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHIgPSBwb2x5VnNQb2x5KG9iYiwgaXNsYW5kLnBvbHlnb24pO1xyXG4gICAgICAgICAgICAgICAgaWYgKHIuY29sbGlkZWQgJiYgci5tdHYpIHtcclxuICAgICAgICAgICAgICAgICAgICBlbmVteS5wb3NpdGlvbi54IC09IHIubXR2Lng7XHJcbiAgICAgICAgICAgICAgICAgICAgZW5lbXkucG9zaXRpb24ueSAtPSByLm10di55O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyAtLS0gUHJvamVjdGlsZXMgdnMgYm91bmRzICsgaXNsYW5kcyAtLS1cclxuICAgICAgICBmb3IgKGNvbnN0IHByb2ogb2Ygcy5wcm9qZWN0aWxlcykge1xyXG4gICAgICAgICAgICBpZiAocHJvai5saWZlVGltZSA8PSAwKSBjb250aW51ZTtcclxuICAgICAgICAgICAgaWYgKHByb2oucG9zaXRpb24ueCA8IDAgfHwgcHJvai5wb3NpdGlvbi54ID4gdGhpcy5hcmVuYS53aWR0aCB8fFxyXG4gICAgICAgICAgICAgICAgcHJvai5wb3NpdGlvbi55IDwgMCB8fCBwcm9qLnBvc2l0aW9uLnkgPiB0aGlzLmFyZW5hLmhlaWdodCkge1xyXG4gICAgICAgICAgICAgICAgcHJvai5saWZlVGltZSA9IDA7XHJcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCBjaXJjbGU6IENpcmNsZSA9IHsgcG9zOiBwcm9qLnBvc2l0aW9uLCByYWRpdXM6IHRoaXMuY29uZmlnLnByb2plY3RpbGVSYWRpdXMgfTtcclxuICAgICAgICAgICAgZm9yIChjb25zdCBpc2xhbmQgb2YgdGhpcy5hcmVuYS5pc2xhbmRzKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY2lyY2xlVnNQb2x5KGNpcmNsZSwgaXNsYW5kLnBvbHlnb24pLmNvbGxpZGVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJvai5saWZlVGltZSA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIC0tLSBQbGF5ZXIgcHJvamVjdGlsZXMgdnMgZW5lbWllcyAtLS1cclxuICAgICAgICBmb3IgKGNvbnN0IHByb2ogb2Ygcy5wcm9qZWN0aWxlcykge1xyXG4gICAgICAgICAgICBpZiAocHJvai5saWZlVGltZSA8PSAwIHx8IHByb2oub3duZXJJZCAhPT0gJ3BsYXllcicpIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICBjb25zdCBwYzogQ2lyY2xlID0geyBwb3M6IHByb2oucG9zaXRpb24sIHJhZGl1czogdGhpcy5jb25maWcucHJvamVjdGlsZVJhZGl1cyB9O1xyXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGVuZW15IG9mIHMuZW5lbWllcykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGVuZW15LmlzRGVhZCkgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBvYmIgPSBjcmVhdGVPQkIoZW5lbXkucG9zaXRpb24sIHRoaXMuY29uZmlnLmVuZW15SGl0Ym94V2lkdGgsIHRoaXMuY29uZmlnLmVuZW15SGl0Ym94SGVpZ2h0LCBlbmVteS5yb3RhdGlvbik7XHJcbiAgICAgICAgICAgICAgICBpZiAoY2lyY2xlVnNQb2x5KHBjLCBvYmIpLmNvbGxpZGVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZW5lbXkuaGVhbHRoIC09IHByb2ouZGFtYWdlO1xyXG4gICAgICAgICAgICAgICAgICAgIHByb2oubGlmZVRpbWUgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZXZlbnRzLnB1c2goeyB0eXBlOiAncHJvamVjdGlsZUhpdCcsIHByb2plY3RpbGVJZDogcHJvai5pZCwgdGFyZ2V0SWQ6IGVuZW15LmlkIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyAtLS0gRW5lbXkgcHJvamVjdGlsZXMgdnMgcGxheWVyIC0tLVxyXG4gICAgICAgIGlmICghcy5wbGF5ZXIuaXNEZWFkKSB7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBwT0JCID0gY3JlYXRlT0JCKHMucGxheWVyLnBvc2l0aW9uLCB0aGlzLmNvbmZpZy5wbGF5ZXJIaXRib3hXaWR0aCwgdGhpcy5jb25maWcucGxheWVySGl0Ym94SGVpZ2h0LCBzLnBsYXllci5yb3RhdGlvbik7XHJcbiAgICAgICAgICAgIGZvciAoY29uc3QgcHJvaiBvZiBzLnByb2plY3RpbGVzKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAocHJvai5saWZlVGltZSA8PSAwIHx8IHByb2oub3duZXJJZCA9PT0gJ3BsYXllcicpIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcGM6IENpcmNsZSA9IHsgcG9zOiBwcm9qLnBvc2l0aW9uLCByYWRpdXM6IHRoaXMuY29uZmlnLnByb2plY3RpbGVSYWRpdXMgfTtcclxuICAgICAgICAgICAgICAgIGlmIChjaXJjbGVWc1BvbHkocGMsIHBPQkIpLmNvbGxpZGVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcy5wbGF5ZXIuaGVhbHRoIC09IHByb2ouZGFtYWdlO1xyXG4gICAgICAgICAgICAgICAgICAgIHByb2oubGlmZVRpbWUgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZXZlbnRzLnB1c2goeyB0eXBlOiAncGxheWVyRGFtYWdlZCcsIGFtb3VudDogcHJvai5kYW1hZ2UgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ldmVudHMucHVzaCh7IHR5cGU6ICdwcm9qZWN0aWxlSGl0JywgcHJvamVjdGlsZUlkOiBwcm9qLmlkLCB0YXJnZXRJZDogJ3BsYXllcicgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyAtLS0gQ2hhc2VyIGNvbGxpc2lvbiB3aXRoIHBsYXllciAtLS1cclxuICAgICAgICBpZiAoIXMucGxheWVyLmlzRGVhZCkge1xyXG5cclxuICAgICAgICAgICAgY29uc3QgcE9CQiA9IGNyZWF0ZU9CQihzLnBsYXllci5wb3NpdGlvbiwgdGhpcy5jb25maWcucGxheWVySGl0Ym94V2lkdGgsIHRoaXMuY29uZmlnLnBsYXllckhpdGJveEhlaWdodCwgcy5wbGF5ZXIucm90YXRpb24pO1xyXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGVuZW15IG9mIHMuZW5lbWllcykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGVuZW15LmlzRGVhZCB8fCBlbmVteS50eXBlICE9PSAnY2hhc2VyJyB8fCBlbmVteS5oZWFsdGggPD0gMCkgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBvYmIgPSBjcmVhdGVPQkIoZW5lbXkucG9zaXRpb24sIHRoaXMuY29uZmlnLmVuZW15SGl0Ym94V2lkdGgsIHRoaXMuY29uZmlnLmVuZW15SGl0Ym94SGVpZ2h0LCBlbmVteS5yb3RhdGlvbik7XHJcbiAgICAgICAgICAgICAgICBpZiAocG9seVZzUG9seShwT0JCLCBvYmIpLmNvbGxpZGVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcy5wbGF5ZXIuaGVhbHRoIC09IHRoaXMuY29uZmlnLmNoYXNlckNvbGxpc2lvbkRhbWFnZTtcclxuICAgICAgICAgICAgICAgICAgICBlbmVteS5oZWFsdGggPSAwOyAvLyBXaWxsIGJlIHByb2Nlc3NlZCBpbiBwcm9jZXNzRGVhdGhzQW5kU2NvcmluZ1xyXG4gICAgICAgICAgICAgICAgICAgIGVuZW15LmtpbGxlZEJ5Q29sbGlzaW9uID0gdHJ1ZTsgLy8gTm8gc2NvcmUgZm9yIHNlbGYtZGVzdHJ1Y3RcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmV2ZW50cy5wdXNoKHsgdHlwZTogJ3BsYXllckRhbWFnZWQnLCBhbW91bnQ6IHRoaXMuY29uZmlnLmNoYXNlckNvbGxpc2lvbkRhbWFnZSB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgY2xhbXBUb0FyZW5hKHBvczogVmVjdG9yMiwgbWFyZ2luOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBwb3MueCA9IE1hdGgubWF4KG1hcmdpbiwgTWF0aC5taW4odGhpcy5hcmVuYS53aWR0aCAtIG1hcmdpbiwgcG9zLngpKTtcclxuICAgICAgICBwb3MueSA9IE1hdGgubWF4KG1hcmdpbiwgTWF0aC5taW4odGhpcy5hcmVuYS5oZWlnaHQgLSBtYXJnaW4sIHBvcy55KSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBwcm9jZXNzRGVhdGhzQW5kU2NvcmluZygpOiB2b2lkIHtcclxuICAgICAgICBjb25zdCBzID0gdGhpcy5zdGF0ZTtcclxuXHJcbiAgICAgICAgaWYgKCFzLnBsYXllci5pc0RlYWQgJiYgcy5wbGF5ZXIuaGVhbHRoIDw9IDApIHtcclxuICAgICAgICAgICAgcy5wbGF5ZXIuaXNEZWFkID0gdHJ1ZTtcclxuICAgICAgICAgICAgcy5wbGF5ZXIuaGVhbHRoID0gMDtcclxuICAgICAgICAgICAgdGhpcy5ldmVudHMucHVzaCh7IHR5cGU6ICdzaGlwRGVzdHJveWVkJywgc2hpcElkOiAncGxheWVyJywgaXNQbGF5ZXI6IHRydWUgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBFbmVtaWVzIGtpbGxlZCBieSBwcm9qZWN0aWxlcyAoY2hhc2VycyBraWxsZWQgYnkgY29sbGlzaW9uIGFscmVhZHkgaGFuZGxlZClcclxuICAgICAgICBmb3IgKGNvbnN0IGVuZW15IG9mIHMuZW5lbWllcykge1xyXG4gICAgICAgICAgICBpZiAoIWVuZW15LmlzRGVhZCAmJiBlbmVteS5oZWFsdGggPD0gMCkge1xyXG4gICAgICAgICAgICAgICAgZW5lbXkuaXNEZWFkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGVuZW15LmhlYWx0aCA9IDA7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmV2ZW50cy5wdXNoKHsgdHlwZTogJ3NoaXBEZXN0cm95ZWQnLCBzaGlwSWQ6IGVuZW15LmlkLCBpc1BsYXllcjogZmFsc2UgfSk7XHJcbiAgICAgICAgICAgICAgICAvLyBPbmx5IHNjb3JlIGtpbGxzIGZyb20gcGxheWVyIHByb2plY3RpbGVzLCBub3QgY2hhc2VyIHNlbGYtZGVzdHJ1Y3RcclxuICAgICAgICAgICAgICAgIGlmICghZW5lbXkua2lsbGVkQnlDb2xsaXNpb24pIHtcclxuICAgICAgICAgICAgICAgICAgICBzLnNjb3JlICs9IDE7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ldmVudHMucHVzaCh7IHR5cGU6ICdzY29yZUNoYW5nZWQnLCBuZXdTY29yZTogcy5zY29yZSB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBjbGVhbnVwKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuc3RhdGUucHJvamVjdGlsZXMgPSB0aGlzLnN0YXRlLnByb2plY3RpbGVzLmZpbHRlcihwID0+IHAubGlmZVRpbWUgPiAwKTtcclxuICAgICAgICB0aGlzLnN0YXRlLmVuZW1pZXMgPSB0aGlzLnN0YXRlLmVuZW1pZXMuZmlsdGVyKGUgPT4gIWUuaXNEZWFkKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNoZWNrTWF0Y2hFbmQoKTogdm9pZCB7XHJcbiAgICAgICAgY29uc3QgcyA9IHRoaXMuc3RhdGU7XHJcbiAgICAgICAgLy8gcGxheWVyX2RpZWQgdGFrZXMgcHJlY2VkZW5jZSBvdmVyIHRpbWVfdXAgaW4gdGhlIHNhbWUgdGlja1xyXG4gICAgICAgIGlmIChzLnBsYXllci5pc0RlYWQpIHtcclxuICAgICAgICAgICAgcy5pc0dhbWVPdmVyID0gdHJ1ZTtcclxuICAgICAgICAgICAgcy5lbmRSZWFzb24gPSAncGxheWVyX2RpZWQnO1xyXG4gICAgICAgICAgICB0aGlzLmV2ZW50cy5wdXNoKHsgdHlwZTogJ21hdGNoRW5kZWQnLCByZWFzb246ICdwbGF5ZXJfZGllZCcgfSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChzLnRpbWVSZW1haW5pbmcgPD0gMCkge1xyXG4gICAgICAgICAgICBzLnRpbWVSZW1haW5pbmcgPSAwO1xyXG4gICAgICAgICAgICBzLmlzR2FtZU92ZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICBzLmVuZFJlYXNvbiA9ICd0aW1lX3VwJztcclxuICAgICAgICAgICAgdGhpcy5ldmVudHMucHVzaCh7IHR5cGU6ICdtYXRjaEVuZGVkJywgcmVhc29uOiAndGltZV91cCcgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=