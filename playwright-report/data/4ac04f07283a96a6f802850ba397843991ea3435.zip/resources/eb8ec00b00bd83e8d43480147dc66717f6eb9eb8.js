import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/GameOverScreen.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import { useGameStore } from "/src/stores/gameStore.ts";
import { useMatchSyncStatus } from "/src/features/matches/hooks.ts";
import { pendingQueue } from "/src/features/matches/storage.ts";
import { API_CONFIG } from "/src/core/config.ts";
import { useDialog } from "/src/ui/hooks/useDialog.ts";
import { END_REASON_LABEL, formatDuration } from "/src/ui/format.ts";
import styles from "/src/ui/components/GameOverScreen.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameOverScreen.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
function syncMessage(status) {
	switch (status.kind) {
		case "saving": return status.retry > 0 ? `Saving your score... (retry ${status.retry}/${API_CONFIG.submitRetries})` : "Saving your score...";
		case "saved": return "Score saved to Leaderboard!";
		case "pending": return `Couldn't save your score (${status.lastError ?? "unknown error"}). It's stored locally and will be sent automatically.`;
		case "idle": return "";
	}
}
export const GameOverScreen = ({ onRestart, onQuit }) => {
	_s();
	const lastMatch = useGameStore((s) => s.lastMatch);
	const sync = useMatchSyncStatus(lastMatch?.id ?? null);
	const dialogRef = useDialog(true);
	if (!lastMatch) return null;
	const isVictory = lastMatch.endReason === "time_up";
	const title = isVictory ? "Victory!" : "Game Over";
	const subtitle = isVictory ? "You survived the challenge!" : "Your ship was destroyed!";
	const scoreClass = isVictory ? styles.scoreVictory : styles.scoreDefeat;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: styles.overlay,
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: `${styles.card} responsive-card`,
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "gameover-title",
			ref: dialogRef,
			tabIndex: -1,
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					id: "gameover-title",
					className: styles.title,
					children: title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: styles.subtitle,
					children: subtitle
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: styles.scoreWrapper,
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: styles.scoreLabel,
						children: "Final Score"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: `${styles.scoreValue} ${scoreClass}`,
						children: lastMatch.score
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("dl", {
					className: styles.details,
					children: [
						/* @__PURE__ */ _jsxDEV("dt", { children: "Time played" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("dd", { children: formatDuration(lastMatch.durationMs) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("dt", { children: "Reason" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 21
						}, this),
						/* @__PURE__ */ _jsxDEV("dd", { children: END_REASON_LABEL[lastMatch.endReason] }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: styles.statusMessage,
					role: "status",
					"aria-live": "polite",
					children: syncMessage(sync)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: styles.buttonGroup,
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							className: styles.button,
							onClick: onRestart,
							children: "Play Again"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 21
						}, this),
						sync.kind === "pending" && /* @__PURE__ */ _jsxDEV("button", {
							className: styles.secondaryButton,
							onClick: pendingQueue.requestSync,
							children: "Retry Save"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 25
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: styles.secondaryButton,
							onClick: onQuit,
							children: "Main Menu"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 9
	}, this);
};
_s(GameOverScreen, "D/jZ0eXbETNZ7i8W3BX7tG/jbKU=", false, function() {
	return [
		useGameStore,
		useMatchSyncStatus,
		useDialog
	];
});
_c = GameOverScreen;
var _c;
$RefreshReg$(_c, "GameOverScreen");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/GameOverScreen.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameOverScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameOverScreen.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameOverScreen.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsMEJBQWdEO0FBQ3pELFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsa0JBQWtCO0FBRTNCLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsa0JBQWtCLHNCQUFzQjtBQUVqRCxPQUFPLFlBQVk7Ozs7QUFPbkIsU0FBUyxZQUFZLFFBQWlDO0NBQ2xELFFBQVEsT0FBTyxNQUFmO0VBQ0ksS0FBSyxVQUNELE9BQU8sT0FBTyxRQUFRLElBQ2hCLCtCQUErQixPQUFPLE1BQU0sR0FBRyxXQUFXLGNBQWMsS0FDeEU7RUFDVixLQUFLLFNBQ0QsT0FBTztFQUNYLEtBQUssV0FDRCxPQUFPLDZCQUE2QixPQUFPLGFBQWEsZ0JBQWdCO0VBQzVFLEtBQUssUUFDRCxPQUFPO0NBQ2Y7QUFDSjtBQUVBLE9BQU8sTUFBTSxrQkFBaUQsRUFBRSxXQUFXLGFBQWE7O0NBQ3BGLE1BQU0sWUFBWSxjQUFjLE1BQU0sRUFBRSxTQUFTO0NBQ2pELE1BQU0sT0FBTyxtQkFBbUIsV0FBVyxNQUFNLElBQUk7Q0FFckQsTUFBTSxZQUFZLFVBQVUsSUFBSTtDQUVoQyxJQUFJLENBQUMsV0FBVyxPQUFPO0NBRXZCLE1BQU0sWUFBWSxVQUFVLGNBQWM7Q0FDMUMsTUFBTSxRQUFRLFlBQVksYUFBYTtDQUN2QyxNQUFNLFdBQVcsWUFBWSxnQ0FBZ0M7Q0FDN0QsTUFBTSxhQUFhLFlBQVksT0FBTyxlQUFlLE9BQU87Q0FFNUQsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVyxPQUFPO1lBQ25CLHdCQUFDLE9BQUQ7R0FDSSxXQUFXLEdBQUcsT0FBTyxLQUFLO0dBQzFCLE1BQUs7R0FDTCxjQUFXO0dBQ1gsbUJBQWdCO0dBQ2hCLEtBQUs7R0FDTCxVQUFVLENBQUM7YUFOZjtJQVFJLHdCQUFDLE1BQUQ7S0FBSSxJQUFHO0tBQWlCLFdBQVcsT0FBTztlQUFRO0lBQVU7Ozs7O0lBQzVELHdCQUFDLFFBQUQ7S0FBTSxXQUFXLE9BQU87ZUFBVztJQUFlOzs7OztJQUVsRCx3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO2VBQXZCLENBQ0ksd0JBQUMsUUFBRDtNQUFNLFdBQVcsT0FBTztnQkFBWTtLQUFpQjs7OztlQUNyRCx3QkFBQyxRQUFEO01BQU0sV0FBVyxHQUFHLE9BQU8sV0FBVyxHQUFHO2dCQUFlLFVBQVU7S0FBWTs7OzthQUM3RTs7Ozs7O0lBRUwsd0JBQUMsTUFBRDtLQUFJLFdBQVcsT0FBTztlQUF0QjtNQUNJLHdCQUFDLE1BQUQsWUFBSSxjQUFlOzs7OztNQUNuQix3QkFBQyxNQUFELFlBQUssZUFBZSxVQUFVLFVBQVUsRUFBTTs7Ozs7TUFDOUMsd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7O01BQ2Qsd0JBQUMsTUFBRCxZQUFLLGlCQUFpQixVQUFVLFdBQWU7Ozs7O0tBQy9DOzs7Ozs7SUFFSix3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO0tBQWUsTUFBSztLQUFTLGFBQVU7ZUFDekQsWUFBWSxJQUFJO0lBQ2hCOzs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLE9BQU87ZUFBdkI7TUFDSSx3QkFBQyxVQUFEO09BQVEsV0FBVyxPQUFPO09BQVEsU0FBUztpQkFBVztNQUFrQjs7Ozs7TUFDdkUsS0FBSyxTQUFTLGFBQ1gsd0JBQUMsVUFBRDtPQUFRLFdBQVcsT0FBTztPQUFpQixTQUFTLGFBQWE7aUJBQWE7TUFFdEU7Ozs7O01BRVosd0JBQUMsVUFBRDtPQUFRLFdBQVcsT0FBTztPQUFpQixTQUFTO2lCQUFRO01BQWlCOzs7OztLQUM1RTs7Ozs7O0dBRUo7Ozs7OztDQUNKOzs7OztBQUdiIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkdhbWVPdmVyU2NyZWVuLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuaW1wb3J0IHsgdXNlR2FtZVN0b3JlIH0gZnJvbSAnLi4vLi4vc3RvcmVzL2dhbWVTdG9yZSc7XHJcbmltcG9ydCB7IHVzZU1hdGNoU3luY1N0YXR1cywgdHlwZSBNYXRjaFN5bmNTdGF0dXMgfSBmcm9tICcuLi8uLi9mZWF0dXJlcy9tYXRjaGVzL2hvb2tzJztcclxuaW1wb3J0IHsgcGVuZGluZ1F1ZXVlIH0gZnJvbSAnLi4vLi4vZmVhdHVyZXMvbWF0Y2hlcy9zdG9yYWdlJztcclxuaW1wb3J0IHsgQVBJX0NPTkZJRyB9IGZyb20gJy4uLy4uL2NvcmUvY29uZmlnJztcclxuXHJcbmltcG9ydCB7IHVzZURpYWxvZyB9IGZyb20gJy4uL2hvb2tzL3VzZURpYWxvZyc7XHJcbmltcG9ydCB7IEVORF9SRUFTT05fTEFCRUwsIGZvcm1hdER1cmF0aW9uIH0gZnJvbSAnLi4vZm9ybWF0JztcclxuXHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi9HYW1lT3ZlclNjcmVlbi5tb2R1bGUuY3NzJztcclxuXHJcbmludGVyZmFjZSBHYW1lT3ZlclNjcmVlblByb3BzIHtcclxuICAgIG9uUmVzdGFydDogKCkgPT4gdm9pZDtcclxuICAgIG9uUXVpdDogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZnVuY3Rpb24gc3luY01lc3NhZ2Uoc3RhdHVzOiBNYXRjaFN5bmNTdGF0dXMpOiBzdHJpbmcge1xyXG4gICAgc3dpdGNoIChzdGF0dXMua2luZCkge1xyXG4gICAgICAgIGNhc2UgJ3NhdmluZyc6XHJcbiAgICAgICAgICAgIHJldHVybiBzdGF0dXMucmV0cnkgPiAwXHJcbiAgICAgICAgICAgICAgICA/IGBTYXZpbmcgeW91ciBzY29yZS4uLiAocmV0cnkgJHtzdGF0dXMucmV0cnl9LyR7QVBJX0NPTkZJRy5zdWJtaXRSZXRyaWVzfSlgXHJcbiAgICAgICAgICAgICAgICA6ICdTYXZpbmcgeW91ciBzY29yZS4uLic7XHJcbiAgICAgICAgY2FzZSAnc2F2ZWQnOlxyXG4gICAgICAgICAgICByZXR1cm4gJ1Njb3JlIHNhdmVkIHRvIExlYWRlcmJvYXJkISc7XHJcbiAgICAgICAgY2FzZSAncGVuZGluZyc6XHJcbiAgICAgICAgICAgIHJldHVybiBgQ291bGRuJ3Qgc2F2ZSB5b3VyIHNjb3JlICgke3N0YXR1cy5sYXN0RXJyb3IgPz8gJ3Vua25vd24gZXJyb3InfSkuIEl0J3Mgc3RvcmVkIGxvY2FsbHkgYW5kIHdpbGwgYmUgc2VudCBhdXRvbWF0aWNhbGx5LmA7XHJcbiAgICAgICAgY2FzZSAnaWRsZSc6XHJcbiAgICAgICAgICAgIHJldHVybiAnJztcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IEdhbWVPdmVyU2NyZWVuOiBSZWFjdC5GQzxHYW1lT3ZlclNjcmVlblByb3BzPiA9ICh7IG9uUmVzdGFydCwgb25RdWl0IH0pID0+IHtcclxuICAgIGNvbnN0IGxhc3RNYXRjaCA9IHVzZUdhbWVTdG9yZSgocykgPT4gcy5sYXN0TWF0Y2gpO1xyXG4gICAgY29uc3Qgc3luYyA9IHVzZU1hdGNoU3luY1N0YXR1cyhsYXN0TWF0Y2g/LmlkID8/IG51bGwpO1xyXG5cclxuICAgIGNvbnN0IGRpYWxvZ1JlZiA9IHVzZURpYWxvZyh0cnVlKTtcclxuXHJcbiAgICBpZiAoIWxhc3RNYXRjaCkgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgY29uc3QgaXNWaWN0b3J5ID0gbGFzdE1hdGNoLmVuZFJlYXNvbiA9PT0gJ3RpbWVfdXAnO1xyXG4gICAgY29uc3QgdGl0bGUgPSBpc1ZpY3RvcnkgPyAnVmljdG9yeSEnIDogJ0dhbWUgT3Zlcic7XHJcbiAgICBjb25zdCBzdWJ0aXRsZSA9IGlzVmljdG9yeSA/ICdZb3Ugc3Vydml2ZWQgdGhlIGNoYWxsZW5nZSEnIDogJ1lvdXIgc2hpcCB3YXMgZGVzdHJveWVkISc7XHJcbiAgICBjb25zdCBzY29yZUNsYXNzID0gaXNWaWN0b3J5ID8gc3R5bGVzLnNjb3JlVmljdG9yeSA6IHN0eWxlcy5zY29yZURlZmVhdDtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMub3ZlcmxheX0+XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7c3R5bGVzLmNhcmR9IHJlc3BvbnNpdmUtY2FyZGB9XHJcbiAgICAgICAgICAgICAgICByb2xlPVwiZGlhbG9nXCJcclxuICAgICAgICAgICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWxsZWRieT1cImdhbWVvdmVyLXRpdGxlXCJcclxuICAgICAgICAgICAgICAgIHJlZj17ZGlhbG9nUmVmfVxyXG4gICAgICAgICAgICAgICAgdGFiSW5kZXg9ey0xfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8aDEgaWQ9XCJnYW1lb3Zlci10aXRsZVwiIGNsYXNzTmFtZT17c3R5bGVzLnRpdGxlfT57dGl0bGV9PC9oMT5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17c3R5bGVzLnN1YnRpdGxlfT57c3VidGl0bGV9PC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuc2NvcmVXcmFwcGVyfT5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3N0eWxlcy5zY29yZUxhYmVsfT5GaW5hbCBTY29yZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake3N0eWxlcy5zY29yZVZhbHVlfSAke3Njb3JlQ2xhc3N9YH0+e2xhc3RNYXRjaC5zY29yZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPXtzdHlsZXMuZGV0YWlsc30+XHJcbiAgICAgICAgICAgICAgICAgICAgPGR0PlRpbWUgcGxheWVkPC9kdD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGQ+e2Zvcm1hdER1cmF0aW9uKGxhc3RNYXRjaC5kdXJhdGlvbk1zKX08L2RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkdD5SZWFzb248L2R0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkZD57RU5EX1JFQVNPTl9MQUJFTFtsYXN0TWF0Y2guZW5kUmVhc29uXX08L2RkPlxyXG4gICAgICAgICAgICAgICAgPC9kbD5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnN0YXR1c01lc3NhZ2V9IHJvbGU9XCJzdGF0dXNcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICB7c3luY01lc3NhZ2Uoc3luYyl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmJ1dHRvbkdyb3VwfT5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17c3R5bGVzLmJ1dHRvbn0gb25DbGljaz17b25SZXN0YXJ0fT5QbGF5IEFnYWluPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAge3N5bmMua2luZCA9PT0gJ3BlbmRpbmcnICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9e3N0eWxlcy5zZWNvbmRhcnlCdXR0b259IG9uQ2xpY2s9e3BlbmRpbmdRdWV1ZS5yZXF1ZXN0U3luY30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXRyeSBTYXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9e3N0eWxlcy5zZWNvbmRhcnlCdXR0b259IG9uQ2xpY2s9e29uUXVpdH0+TWFpbiBNZW51PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuXHJcbn07XHJcbiJdfQ==