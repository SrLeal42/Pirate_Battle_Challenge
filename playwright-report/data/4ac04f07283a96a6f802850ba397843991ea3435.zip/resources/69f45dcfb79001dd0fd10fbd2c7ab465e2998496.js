import { H as warn, V as GlobalResourceRegistry, _t as ExtensionType, c as Shader, ct as uid, f as UniformGroup, g as GpuProgram, j as getTestContext, nt as deprecation, o as Buffer, r as Geometry, s as BufferUsage, w as GlProgram } from "/node_modules/.vite/deps/CanvasPool-BcIVNj8Y.js?v=43418a0e";
//#region node_modules/pixi.js/lib/utils/data/ViewableBuffer.mjs
var ViewableBuffer = class {
	constructor(sizeOrBuffer) {
		if (typeof sizeOrBuffer === "number") this.rawBinaryData = new ArrayBuffer(sizeOrBuffer);
		else if (sizeOrBuffer instanceof Uint8Array) this.rawBinaryData = sizeOrBuffer.buffer;
		else this.rawBinaryData = sizeOrBuffer;
		this.uint32View = new Uint32Array(this.rawBinaryData);
		this.float32View = new Float32Array(this.rawBinaryData);
		this.size = this.rawBinaryData.byteLength;
	}
	/** View on the raw binary data as a `Int8Array`. */
	get int8View() {
		if (!this._int8View) this._int8View = new Int8Array(this.rawBinaryData);
		return this._int8View;
	}
	/** View on the raw binary data as a `Uint8Array`. */
	get uint8View() {
		if (!this._uint8View) this._uint8View = new Uint8Array(this.rawBinaryData);
		return this._uint8View;
	}
	/**  View on the raw binary data as a `Int16Array`. */
	get int16View() {
		if (!this._int16View) this._int16View = new Int16Array(this.rawBinaryData);
		return this._int16View;
	}
	/** View on the raw binary data as a `Int32Array`. */
	get int32View() {
		if (!this._int32View) this._int32View = new Int32Array(this.rawBinaryData);
		return this._int32View;
	}
	/** View on the raw binary data as a `Float64Array`. */
	get float64View() {
		if (!this._float64Array) this._float64Array = new Float64Array(this.rawBinaryData);
		return this._float64Array;
	}
	/** View on the raw binary data as a `BigUint64Array`. */
	get bigUint64View() {
		if (!this._bigUint64Array) this._bigUint64Array = new BigUint64Array(this.rawBinaryData);
		return this._bigUint64Array;
	}
	/**
	* Returns the view of the given type.
	* @param type - One of `int8`, `uint8`, `int16`,
	*    `uint16`, `int32`, `uint32`, and `float32`.
	* @returns - typed array of given type
	*/
	view(type) {
		return this[`${type}View`];
	}
	/** Destroys all buffer references. Do not use after calling this. */
	destroy() {
		this.rawBinaryData = null;
		this.uint32View = null;
		this.float32View = null;
		this.uint16View = null;
		this._int8View = null;
		this._uint8View = null;
		this._int16View = null;
		this._int32View = null;
		this._float64Array = null;
		this._bigUint64Array = null;
	}
	/**
	* Returns the size of the given type in bytes.
	* @param type - One of `int8`, `uint8`, `int16`,
	*   `uint16`, `int32`, `uint32`, and `float32`.
	* @returns - size of the type in bytes
	*/
	static sizeOf(type) {
		switch (type) {
			case "int8":
			case "uint8": return 1;
			case "int16":
			case "uint16": return 2;
			case "int32":
			case "uint32":
			case "float32": return 4;
			default: throw new Error(`${type} isn't a valid view type`);
		}
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/buffer/utils/fastCopy.mjs
function fastCopy(sourceBuffer, destinationBuffer, sourceOffset, byteLength) {
	sourceOffset ?? (sourceOffset = 0);
	byteLength ?? (byteLength = Math.min(sourceBuffer.byteLength - sourceOffset, destinationBuffer.byteLength));
	if (!(sourceOffset & 7) && !(byteLength & 7)) {
		const len = byteLength / 8;
		new Float64Array(destinationBuffer, 0, len).set(new Float64Array(sourceBuffer, sourceOffset, len));
	} else if (!(sourceOffset & 3) && !(byteLength & 3)) {
		const len = byteLength / 4;
		new Float32Array(destinationBuffer, 0, len).set(new Float32Array(sourceBuffer, sourceOffset, len));
	} else new Uint8Array(destinationBuffer).set(new Uint8Array(sourceBuffer, sourceOffset, byteLength));
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/state/const.mjs
var BLEND_TO_NPM = {
	normal: "normal-npm",
	add: "add-npm",
	screen: "screen-npm"
};
var STENCIL_MODES = /* @__PURE__ */ ((STENCIL_MODES2) => {
	STENCIL_MODES2[STENCIL_MODES2["DISABLED"] = 0] = "DISABLED";
	STENCIL_MODES2[STENCIL_MODES2["RENDERING_MASK_ADD"] = 1] = "RENDERING_MASK_ADD";
	STENCIL_MODES2[STENCIL_MODES2["MASK_ACTIVE"] = 2] = "MASK_ACTIVE";
	STENCIL_MODES2[STENCIL_MODES2["INVERSE_MASK_ACTIVE"] = 3] = "INVERSE_MASK_ACTIVE";
	STENCIL_MODES2[STENCIL_MODES2["RENDERING_MASK_REMOVE"] = 4] = "RENDERING_MASK_REMOVE";
	STENCIL_MODES2[STENCIL_MODES2["NONE"] = 5] = "NONE";
	return STENCIL_MODES2;
})(STENCIL_MODES || {});
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/state/getAdjustedBlendModeBlend.mjs
function getAdjustedBlendModeBlend(blendMode, textureSource) {
	if (textureSource.alphaMode === "no-premultiply-alpha") return BLEND_TO_NPM[blendMode] || blendMode;
	return blendMode;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/gl/utils/checkMaxIfStatementsInShader.mjs
var fragTemplate = [
	"precision mediump float;",
	"void main(void){",
	"float test = 0.1;",
	"%forloop%",
	"gl_FragColor = vec4(0.0);",
	"}"
].join("\n");
function generateIfTestSrc(maxIfs) {
	let src = "";
	for (let i = 0; i < maxIfs; ++i) {
		if (i > 0) src += "\nelse ";
		if (i < maxIfs - 1) src += `if(test == ${i}.0){}`;
	}
	return src;
}
function checkMaxIfStatementsInShader(maxIfs, gl) {
	if (maxIfs === 0) throw new Error("Invalid value of `0` passed to `checkMaxIfStatementsInShader`");
	const shader = gl.createShader(gl.FRAGMENT_SHADER);
	try {
		while (true) {
			const fragmentSrc = fragTemplate.replace(/%forloop%/gi, generateIfTestSrc(maxIfs));
			gl.shaderSource(shader, fragmentSrc);
			gl.compileShader(shader);
			if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) maxIfs = maxIfs / 2 | 0;
			else break;
		}
	} finally {
		gl.deleteShader(shader);
	}
	return maxIfs;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/gl/utils/maxRecommendedTextures.mjs
var maxTexturesPerBatchCache = null;
function getMaxTexturesPerBatch() {
	if (maxTexturesPerBatchCache) return maxTexturesPerBatchCache;
	const gl = getTestContext();
	maxTexturesPerBatchCache = gl.getParameter(gl.MAX_TEXTURE_IMAGE_UNITS);
	maxTexturesPerBatchCache = checkMaxIfStatementsInShader(maxTexturesPerBatchCache, gl);
	gl.getExtension("WEBGL_lose_context")?.loseContext();
	return maxTexturesPerBatchCache;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/shared/BatchTextureArray.mjs
var BatchTextureArray = class {
	constructor() {
		/** Respective locations for textures. */
		this.ids = /* @__PURE__ */ Object.create(null);
		this.textures = [];
		this.count = 0;
	}
	/** Clear the textures and their locations. */
	clear() {
		for (let i = 0; i < this.count; i++) {
			const t = this.textures[i];
			this.textures[i] = null;
			this.ids[t.uid] = null;
		}
		this.count = 0;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/shared/Batcher.mjs
var Batch = class {
	constructor() {
		this.renderPipeId = "batch";
		this.action = "startBatch";
		this.start = 0;
		this.size = 0;
		this.textures = new BatchTextureArray();
		this.blendMode = "normal";
		this.topology = "triangle-strip";
		this.canBundle = true;
	}
	destroy() {
		this.textures = null;
		this.gpuBindGroup = null;
		this.bindGroup = null;
		this.batcher = null;
		this.elements = null;
	}
};
var batchPool = [];
var batchPoolIndex = 0;
GlobalResourceRegistry.register({ clear: () => {
	if (batchPool.length > 0) {
		for (const item of batchPool) if (item) item.destroy();
	}
	batchPool.length = 0;
	batchPoolIndex = 0;
} });
function getBatchFromPool() {
	return batchPoolIndex > 0 ? batchPool[--batchPoolIndex] : new Batch();
}
function returnBatchToPool(batch) {
	batch.elements = null;
	batchPool[batchPoolIndex++] = batch;
}
var BATCH_TICK = 0;
var _Batcher = class _Batcher {
	constructor(options) {
		/** unique id for this batcher */
		this.uid = uid("batcher");
		/** Indicates whether the batch data has been modified and needs updating. */
		this.dirty = true;
		/** The current index of the batch being processed. */
		this.batchIndex = 0;
		/** An array of all batches created during the current rendering process. */
		this.batches = [];
		this._elements = [];
		options = {
			..._Batcher.defaultOptions,
			...options
		};
		if (!options.maxTextures) {
			deprecation("v8.8.0", "maxTextures is a required option for Batcher now, please pass it in the options");
			options.maxTextures = getMaxTexturesPerBatch();
		}
		const { maxTextures, attributesInitialSize, indicesInitialSize } = options;
		this.attributeBuffer = new ViewableBuffer(attributesInitialSize * 4);
		this.indexBuffer = new Uint16Array(indicesInitialSize);
		this.maxTextures = maxTextures;
	}
	begin() {
		this.elementSize = 0;
		this.elementStart = 0;
		this.indexSize = 0;
		this.attributeSize = 0;
		for (let i = 0; i < this.batchIndex; i++) returnBatchToPool(this.batches[i]);
		this.batchIndex = 0;
		this._batchIndexStart = 0;
		this._batchIndexSize = 0;
		this.dirty = true;
	}
	add(batchableObject) {
		this._elements[this.elementSize++] = batchableObject;
		batchableObject._indexStart = this.indexSize;
		batchableObject._attributeStart = this.attributeSize;
		batchableObject._batcher = this;
		this.indexSize += batchableObject.indexSize;
		this.attributeSize += batchableObject.attributeSize * this.vertexSize;
	}
	checkAndUpdateTexture(batchableObject, texture) {
		const textureId = batchableObject._batch.textures.ids[texture._source.uid];
		if (!textureId && textureId !== 0) return false;
		batchableObject._textureId = textureId;
		batchableObject.texture = texture;
		return true;
	}
	updateElement(batchableObject) {
		this.dirty = true;
		const attributeBuffer = this.attributeBuffer;
		if (batchableObject.packAsQuad) this.packQuadAttributes(batchableObject, attributeBuffer.float32View, attributeBuffer.uint32View, batchableObject._attributeStart, batchableObject._textureId);
		else this.packAttributes(batchableObject, attributeBuffer.float32View, attributeBuffer.uint32View, batchableObject._attributeStart, batchableObject._textureId);
	}
	/**
	* breaks the batcher. This happens when a batch gets too big,
	* or we need to switch to a different type of rendering (a filter for example)
	* @param instructionSet
	*/
	break(instructionSet) {
		const elements = this._elements;
		if (!elements[this.elementStart]) return;
		let batch = getBatchFromPool();
		let textureBatch = batch.textures;
		textureBatch.clear();
		const firstElement = elements[this.elementStart];
		let blendMode = getAdjustedBlendModeBlend(firstElement.blendMode, firstElement.texture._source);
		let topology = firstElement.topology;
		if (this.attributeSize * 4 > this.attributeBuffer.size) this._resizeAttributeBuffer(this.attributeSize * 4);
		if (this.indexSize > this.indexBuffer.length) this._resizeIndexBuffer(this.indexSize);
		const f32 = this.attributeBuffer.float32View;
		const u32 = this.attributeBuffer.uint32View;
		const indexBuffer = this.indexBuffer;
		let size = this._batchIndexSize;
		let start = this._batchIndexStart;
		let action = "startBatch";
		let batchElements = [];
		const maxTextures = this.maxTextures;
		for (let i = this.elementStart; i < this.elementSize; ++i) {
			const element = elements[i];
			elements[i] = null;
			const source = element.texture._source;
			const adjustedBlendMode = getAdjustedBlendModeBlend(element.blendMode, source);
			const breakRequired = blendMode !== adjustedBlendMode || topology !== element.topology;
			if (source._batchTick === BATCH_TICK && !breakRequired) {
				element._textureId = source._textureBindLocation;
				size += element.indexSize;
				if (element.packAsQuad) {
					this.packQuadAttributes(element, f32, u32, element._attributeStart, element._textureId);
					this.packQuadIndex(indexBuffer, element._indexStart, element._attributeStart / this.vertexSize);
				} else {
					this.packAttributes(element, f32, u32, element._attributeStart, element._textureId);
					this.packIndex(element, indexBuffer, element._indexStart, element._attributeStart / this.vertexSize);
				}
				element._batch = batch;
				batchElements.push(element);
				continue;
			}
			source._batchTick = BATCH_TICK;
			if (textureBatch.count >= maxTextures || breakRequired) {
				this._finishBatch(batch, start, size - start, textureBatch, blendMode, topology, instructionSet, action, batchElements);
				action = "renderBatch";
				start = size;
				blendMode = adjustedBlendMode;
				topology = element.topology;
				batch = getBatchFromPool();
				textureBatch = batch.textures;
				textureBatch.clear();
				batchElements = [];
				++BATCH_TICK;
			}
			element._textureId = source._textureBindLocation = textureBatch.count;
			textureBatch.ids[source.uid] = textureBatch.count;
			textureBatch.textures[textureBatch.count++] = source;
			element._batch = batch;
			batchElements.push(element);
			size += element.indexSize;
			if (element.packAsQuad) {
				this.packQuadAttributes(element, f32, u32, element._attributeStart, element._textureId);
				this.packQuadIndex(indexBuffer, element._indexStart, element._attributeStart / this.vertexSize);
			} else {
				this.packAttributes(element, f32, u32, element._attributeStart, element._textureId);
				this.packIndex(element, indexBuffer, element._indexStart, element._attributeStart / this.vertexSize);
			}
		}
		if (textureBatch.count > 0) {
			this._finishBatch(batch, start, size - start, textureBatch, blendMode, topology, instructionSet, action, batchElements);
			start = size;
			++BATCH_TICK;
		}
		this.elementStart = this.elementSize;
		this._batchIndexStart = start;
		this._batchIndexSize = size;
	}
	_finishBatch(batch, indexStart, indexSize, textureBatch, blendMode, topology, instructionSet, action, elements) {
		batch.gpuBindGroup = null;
		batch.bindGroup = null;
		batch.action = action;
		batch.batcher = this;
		batch.textures = textureBatch;
		batch.blendMode = blendMode;
		batch.topology = topology;
		batch.start = indexStart;
		batch.size = indexSize;
		batch.elements = elements;
		++BATCH_TICK;
		this.batches[this.batchIndex++] = batch;
		instructionSet.add(batch);
	}
	finish(instructionSet) {
		this.break(instructionSet);
	}
	/**
	* Resizes the attribute buffer to the given size (1 = 1 float32)
	* @param size - the size in vertices to ensure (not bytes!)
	*/
	ensureAttributeBuffer(size) {
		if (size * 4 <= this.attributeBuffer.size) return;
		this._resizeAttributeBuffer(size * 4);
	}
	/**
	* Resizes the index buffer to the given size (1 = 1 float32)
	* @param size - the size in vertices to ensure (not bytes!)
	*/
	ensureIndexBuffer(size) {
		if (size <= this.indexBuffer.length) return;
		this._resizeIndexBuffer(size);
	}
	_resizeAttributeBuffer(size) {
		const newArrayBuffer = new ViewableBuffer(Math.max(size, this.attributeBuffer.size * 2));
		fastCopy(this.attributeBuffer.rawBinaryData, newArrayBuffer.rawBinaryData);
		this.attributeBuffer = newArrayBuffer;
	}
	_resizeIndexBuffer(size) {
		const indexBuffer = this.indexBuffer;
		let newSize = Math.max(size, indexBuffer.length * 1.5);
		newSize += newSize % 2;
		const newIndexBuffer = newSize > 65535 ? new Uint32Array(newSize) : new Uint16Array(newSize);
		if (newIndexBuffer.BYTES_PER_ELEMENT !== indexBuffer.BYTES_PER_ELEMENT) for (let i = 0; i < indexBuffer.length; i++) newIndexBuffer[i] = indexBuffer[i];
		else fastCopy(indexBuffer.buffer, newIndexBuffer.buffer);
		this.indexBuffer = newIndexBuffer;
	}
	packQuadIndex(indexBuffer, index, indicesOffset) {
		indexBuffer[index] = indicesOffset + 0;
		indexBuffer[index + 1] = indicesOffset + 1;
		indexBuffer[index + 2] = indicesOffset + 2;
		indexBuffer[index + 3] = indicesOffset + 0;
		indexBuffer[index + 4] = indicesOffset + 2;
		indexBuffer[index + 5] = indicesOffset + 3;
	}
	packIndex(element, indexBuffer, index, indicesOffset) {
		const indices = element.indices;
		const size = element.indexSize;
		const indexOffset = element.indexOffset;
		const attributeOffset = element.attributeOffset;
		for (let i = 0; i < size; i++) indexBuffer[index++] = indicesOffset + indices[i + indexOffset] - attributeOffset;
	}
	/**
	* Destroys the batch and its resources.
	* @param options - destruction options
	* @param options.shader - whether to destroy the associated shader
	*/
	destroy(options = {}) {
		if (this.batches === null) return;
		for (let i = 0; i < this.batchIndex; i++) returnBatchToPool(this.batches[i]);
		this.batches = null;
		this.geometry.destroy(true);
		this.geometry = null;
		if (options.shader) {
			this.shader?.destroy();
			this.shader = null;
		}
		for (let i = 0; i < this._elements.length; i++) if (this._elements[i]) this._elements[i]._batch = null;
		this._elements = null;
		this.indexBuffer = null;
		this.attributeBuffer.destroy();
		this.attributeBuffer = null;
	}
};
_Batcher.defaultOptions = {
	maxTextures: null,
	attributesInitialSize: 4,
	indicesInitialSize: 6
};
var Batcher = _Batcher;
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/shared/BatchGeometry.mjs
var placeHolderBufferData = /* @__PURE__ */ new Float32Array(1);
var placeHolderIndexData = /* @__PURE__ */ new Uint32Array(1);
var BatchGeometry = class extends Geometry {
	constructor() {
		const attributeBuffer = new Buffer({
			data: placeHolderBufferData,
			label: "attribute-batch-buffer",
			usage: BufferUsage.VERTEX | BufferUsage.COPY_DST,
			shrinkToFit: false
		});
		const indexBuffer = new Buffer({
			data: placeHolderIndexData,
			label: "index-batch-buffer",
			usage: BufferUsage.INDEX | BufferUsage.COPY_DST,
			shrinkToFit: false
		});
		const stride = 24;
		super({
			attributes: {
				aPosition: {
					buffer: attributeBuffer,
					format: "float32x2",
					stride,
					offset: 0
				},
				aUV: {
					buffer: attributeBuffer,
					format: "float32x2",
					stride,
					offset: 8
				},
				aColor: {
					buffer: attributeBuffer,
					format: "unorm8x4",
					stride,
					offset: 16
				},
				aTextureIdAndRound: {
					buffer: attributeBuffer,
					format: "uint16x2",
					stride,
					offset: 20
				}
			},
			indexBuffer
		});
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/addBits.mjs
function addBits(srcParts, parts, name) {
	if (srcParts) for (const i in srcParts) {
		const part = parts[i.toLocaleLowerCase()];
		if (part) {
			let sanitisedPart = srcParts[i];
			if (i === "header") sanitisedPart = sanitisedPart.replace(/@in\s+[^;]+;\s*/g, "").replace(/@out\s+[^;]+;\s*/g, "");
			if (name) part.push(`//----${name}----//`);
			part.push(sanitisedPart);
		} else warn(`${i} placement hook does not exist in shader`);
	}
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/compileHooks.mjs
var findHooksRx = /\{\{(.*?)\}\}/g;
function compileHooks(programSrc) {
	const parts = {};
	(programSrc.match(findHooksRx)?.map((hook) => hook.replace(/[{()}]/g, "")) ?? []).forEach((hook) => {
		parts[hook] = [];
	});
	return parts;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/compileInputs.mjs
function extractInputs(fragmentSource, out) {
	let match;
	const regex = /@in\s+([^;]+);/g;
	while ((match = regex.exec(fragmentSource)) !== null) out.push(match[1]);
}
function compileInputs(fragments, template, sort = false) {
	const results = [];
	extractInputs(template, results);
	fragments.forEach((fragment) => {
		if (fragment.header) extractInputs(fragment.header, results);
	});
	const mainInput = results;
	if (sort) mainInput.sort();
	const finalString = mainInput.map((inValue, i) => `       @location(${i}) ${inValue},`).join("\n");
	let cleanedString = template.replace(/@in\s+[^;]+;\s*/g, "");
	cleanedString = cleanedString.replace("{{in}}", `
${finalString}
`);
	return cleanedString;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/compileOutputs.mjs
function extractOutputs(fragmentSource, out) {
	let match;
	const regex = /@out\s+([^;]+);/g;
	while ((match = regex.exec(fragmentSource)) !== null) out.push(match[1]);
}
function extractVariableName(value) {
	const match = /\b(\w+)\s*:/g.exec(value);
	return match ? match[1] : "";
}
function stripVariable(value) {
	return value.replace(/@.*?\s+/g, "");
}
function compileOutputs(fragments, template) {
	const results = [];
	extractOutputs(template, results);
	fragments.forEach((fragment) => {
		if (fragment.header) extractOutputs(fragment.header, results);
	});
	let index = 0;
	const mainStruct = results.sort().map((inValue) => {
		if (inValue.indexOf("builtin") > -1) return inValue;
		return `@location(${index++}) ${inValue}`;
	}).join(",\n");
	const mainStart = results.sort().map((inValue) => `       var ${stripVariable(inValue)};`).join("\n");
	const mainEnd = `return VSOutput(
            ${results.sort().map((inValue) => ` ${extractVariableName(inValue)}`).join(",\n")});`;
	let compiledCode = template.replace(/@out\s+[^;]+;\s*/g, "");
	compiledCode = compiledCode.replace("{{struct}}", `
${mainStruct}
`);
	compiledCode = compiledCode.replace("{{start}}", `
${mainStart}
`);
	compiledCode = compiledCode.replace("{{return}}", `
${mainEnd}
`);
	return compiledCode;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/utils/injectBits.mjs
function injectBits(templateSrc, fragmentParts) {
	let out = templateSrc;
	for (const i in fragmentParts) {
		const parts = fragmentParts[i];
		if (parts.join("\n").length) out = out.replace(`{{${i}}}`, `//-----${i} START-----//
${parts.join("\n")}
//----${i} FINISH----//`);
		else out = out.replace(`{{${i}}}`, "");
	}
	return out;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compiler/compileHighShader.mjs
var cacheMap = /* @__PURE__ */ Object.create(null);
var bitCacheMap = /* @__PURE__ */ new Map();
var CACHE_UID = 0;
function compileHighShader({ template, bits }) {
	const cacheId = generateCacheId(template, bits);
	if (cacheMap[cacheId]) return cacheMap[cacheId];
	const { vertex, fragment } = compileInputsAndOutputs(template, bits);
	cacheMap[cacheId] = compileBits(vertex, fragment, bits);
	return cacheMap[cacheId];
}
function compileHighShaderGl({ template, bits }) {
	const cacheId = generateCacheId(template, bits);
	if (cacheMap[cacheId]) return cacheMap[cacheId];
	cacheMap[cacheId] = compileBits(template.vertex, template.fragment, bits);
	return cacheMap[cacheId];
}
function compileInputsAndOutputs(template, bits) {
	const vertexFragments = bits.map((shaderBit) => shaderBit.vertex).filter((v) => !!v);
	const fragmentFragments = bits.map((shaderBit) => shaderBit.fragment).filter((v) => !!v);
	let compiledVertex = compileInputs(vertexFragments, template.vertex, true);
	compiledVertex = compileOutputs(vertexFragments, compiledVertex);
	const compiledFragment = compileInputs(fragmentFragments, template.fragment, true);
	return {
		vertex: compiledVertex,
		fragment: compiledFragment
	};
}
function generateCacheId(template, bits) {
	return bits.map((highFragment) => {
		if (!bitCacheMap.has(highFragment)) bitCacheMap.set(highFragment, CACHE_UID++);
		return bitCacheMap.get(highFragment);
	}).sort((a, b) => a - b).join("-") + template.vertex + template.fragment;
}
function compileBits(vertex, fragment, bits) {
	const vertexParts = compileHooks(vertex);
	const fragmentParts = compileHooks(fragment);
	bits.forEach((shaderBit) => {
		addBits(shaderBit.vertex, vertexParts, shaderBit.name);
		addBits(shaderBit.fragment, fragmentParts, shaderBit.name);
	});
	return {
		vertex: injectBits(vertex, vertexParts),
		fragment: injectBits(fragment, fragmentParts)
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/defaultProgramTemplate.mjs
var vertexGPUTemplate = `
    @in aPosition: vec2<f32>;
    @in aUV: vec2<f32>;

    @out @builtin(position) vPosition: vec4<f32>;
    @out vUV : vec2<f32>;
    @out vColor : vec4<f32>;

    {{header}}

    struct VSOutput {
        {{struct}}
    };

    @vertex
    fn main( {{in}} ) -> VSOutput {

        var worldTransformMatrix = globalUniforms.uWorldTransformMatrix;
        var modelMatrix = mat3x3<f32>(
            1.0, 0.0, 0.0,
            0.0, 1.0, 0.0,
            0.0, 0.0, 1.0
          );
        var position = aPosition;
        var uv = aUV;

        {{start}}

        vColor = vec4<f32>(1., 1., 1., 1.);

        {{main}}

        vUV = uv;

        var modelViewProjectionMatrix = globalUniforms.uProjectionMatrix * worldTransformMatrix * modelMatrix;

        vPosition =  vec4<f32>((modelViewProjectionMatrix *  vec3<f32>(position, 1.0)).xy, 0.0, 1.0);

        vColor *= globalUniforms.uWorldColorAlpha;

        {{end}}

        {{return}}
    };
`;
var fragmentGPUTemplate = `
    @in vUV : vec2<f32>;
    @in vColor : vec4<f32>;

    {{header}}

    @fragment
    fn main(
        {{in}}
      ) -> @location(0) vec4<f32> {

        {{start}}

        var outColor:vec4<f32>;

        {{main}}

        var finalColor:vec4<f32> = outColor * vColor;

        {{end}}

        return finalColor;
      };
`;
var vertexGlTemplate = `
    in vec2 aPosition;
    in vec2 aUV;

    out vec4 vColor;
    out vec2 vUV;

    {{header}}

    void main(void){

        mat3 worldTransformMatrix = uWorldTransformMatrix;
        mat3 modelMatrix = mat3(
            1.0, 0.0, 0.0,
            0.0, 1.0, 0.0,
            0.0, 0.0, 1.0
          );
        vec2 position = aPosition;
        vec2 uv = aUV;

        {{start}}

        vColor = vec4(1.);

        {{main}}

        vUV = uv;

        mat3 modelViewProjectionMatrix = uProjectionMatrix * worldTransformMatrix * modelMatrix;

        gl_Position = vec4((modelViewProjectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);

        vColor *= uWorldColorAlpha;

        {{end}}
    }
`;
var fragmentGlTemplate = `

    in vec4 vColor;
    in vec2 vUV;

    out vec4 finalColor;

    {{header}}

    void main(void) {

        {{start}}

        vec4 outColor;

        {{main}}

        finalColor = outColor * vColor;

        {{end}}
    }
`;
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/shader-bits/globalUniformsBit.mjs
var globalUniformsBit = {
	name: "global-uniforms-bit",
	vertex: { header: `
        struct GlobalUniforms {
            uProjectionMatrix:mat3x3<f32>,
            uWorldTransformMatrix:mat3x3<f32>,
            uWorldColorAlpha: vec4<f32>,
            uResolution: vec2<f32>,
        }

        @group(0) @binding(0) var<uniform> globalUniforms : GlobalUniforms;
        ` }
};
var globalUniformsUBOBitGl = {
	name: "global-uniforms-ubo-bit",
	vertex: { header: `
          uniform globalUniforms {
            mat3 uProjectionMatrix;
            mat3 uWorldTransformMatrix;
            vec4 uWorldColorAlpha;
            vec2 uResolution;
          };
        ` }
};
var globalUniformsBitGl = {
	name: "global-uniforms-bit",
	vertex: { header: `
          uniform mat3 uProjectionMatrix;
          uniform mat3 uWorldTransformMatrix;
          uniform vec4 uWorldColorAlpha;
          uniform vec2 uResolution;
        ` }
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/compileHighShaderToProgram.mjs
function compileHighShaderGpuProgram({ bits, name }) {
	const source = compileHighShader({
		template: {
			fragment: fragmentGPUTemplate,
			vertex: vertexGPUTemplate
		},
		bits: [globalUniformsBit, ...bits]
	});
	return GpuProgram.from({
		name,
		vertex: {
			source: source.vertex,
			entryPoint: "main"
		},
		fragment: {
			source: source.fragment,
			entryPoint: "main"
		}
	});
}
function compileHighShaderGlProgram({ bits, name }) {
	return new GlProgram({
		name,
		...compileHighShaderGl({
			template: {
				vertex: vertexGlTemplate,
				fragment: fragmentGlTemplate
			},
			bits: [globalUniformsBitGl, ...bits]
		})
	});
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/shader-bits/colorBit.mjs
var colorBit = {
	name: "color-bit",
	vertex: {
		header: `
            @in aColor: vec4<f32>;
        `,
		main: `
            vColor *= vec4<f32>(aColor.rgb * aColor.a, aColor.a);
        `
	}
};
var colorBitGl = {
	name: "color-bit",
	vertex: {
		header: `
            in vec4 aColor;
        `,
		main: `
            vColor *= vec4(aColor.rgb * aColor.a, aColor.a);
        `
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/shader-bits/generateTextureBatchBit.mjs
var textureBatchBitGpuCache = {};
function generateBindingSrc(maxTextures) {
	const src = [];
	if (maxTextures === 1) {
		src.push("@group(1) @binding(0) var textureSource1: texture_2d<f32>;");
		src.push("@group(1) @binding(1) var textureSampler1: sampler;");
	} else {
		let bindingIndex = 0;
		for (let i = 0; i < maxTextures; i++) {
			src.push(`@group(1) @binding(${bindingIndex++}) var textureSource${i + 1}: texture_2d<f32>;`);
			src.push(`@group(1) @binding(${bindingIndex++}) var textureSampler${i + 1}: sampler;`);
		}
	}
	return src.join("\n");
}
function generateSampleSrc(maxTextures) {
	const src = [];
	if (maxTextures === 1) src.push("outColor = textureSampleGrad(textureSource1, textureSampler1, vUV, uvDx, uvDy);");
	else {
		src.push("switch vTextureId {");
		for (let i = 0; i < maxTextures; i++) {
			if (i === maxTextures - 1) src.push(`  default:{`);
			else src.push(`  case ${i}:{`);
			src.push(`      outColor = textureSampleGrad(textureSource${i + 1}, textureSampler${i + 1}, vUV, uvDx, uvDy);`);
			src.push(`      break;}`);
		}
		src.push(`}`);
	}
	return src.join("\n");
}
function generateTextureBatchBit(maxTextures) {
	if (!textureBatchBitGpuCache[maxTextures]) textureBatchBitGpuCache[maxTextures] = {
		name: "texture-batch-bit",
		vertex: {
			header: `
                @in aTextureIdAndRound: vec2<u32>;
                @out @interpolate(flat) vTextureId : u32;
            `,
			main: `
                vTextureId = aTextureIdAndRound.y;
            `,
			end: `
                if(aTextureIdAndRound.x == 1)
                {
                    vPosition = vec4<f32>(roundPixels(vPosition.xy, globalUniforms.uResolution), vPosition.zw);
                }
            `
		},
		fragment: {
			header: `
                @in @interpolate(flat) vTextureId: u32;

                ${generateBindingSrc(maxTextures)}
            `,
			main: `
                var uvDx = dpdx(vUV);
                var uvDy = dpdy(vUV);

                ${generateSampleSrc(maxTextures)}
            `
		}
	};
	return textureBatchBitGpuCache[maxTextures];
}
var textureBatchBitGlCache = {};
function generateSampleGlSrc(maxTextures) {
	const src = [];
	for (let i = 0; i < maxTextures; i++) {
		if (i > 0) src.push("else");
		if (i < maxTextures - 1) src.push(`if(vTextureId < ${i}.5)`);
		src.push("{");
		src.push(`	outColor = texture(uTextures[${i}], vUV);`);
		src.push("}");
	}
	return src.join("\n");
}
function generateTextureBatchBitGl(maxTextures) {
	if (!textureBatchBitGlCache[maxTextures]) textureBatchBitGlCache[maxTextures] = {
		name: "texture-batch-bit",
		vertex: {
			header: `
                in vec2 aTextureIdAndRound;
                out float vTextureId;

            `,
			main: `
                vTextureId = aTextureIdAndRound.y;
            `,
			end: `
                if(aTextureIdAndRound.x == 1.)
                {
                    gl_Position.xy = roundPixels(gl_Position.xy, uResolution);
                }
            `
		},
		fragment: {
			header: `
                in float vTextureId;

                uniform sampler2D uTextures[${maxTextures}];

            `,
			main: `

                ${generateSampleGlSrc(maxTextures)}
            `
		}
	};
	return textureBatchBitGlCache[maxTextures];
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/shader-bits/roundPixelsBit.mjs
var roundPixelsBit = {
	name: "round-pixels-bit",
	vertex: { header: `
            fn roundPixels(position: vec2<f32>, targetSize: vec2<f32>) -> vec2<f32>
            {
                return (floor(((position * 0.5 + 0.5) * targetSize) + 0.5) / targetSize) * 2.0 - 1.0;
            }
        ` }
};
var roundPixelsBitGl = {
	name: "round-pixels-bit",
	vertex: { header: `
            vec2 roundPixels(vec2 position, vec2 targetSize)
            {
                return (floor(((position * 0.5 + 0.5) * targetSize) + 0.5) / targetSize) * 2.0 - 1.0;
            }
        ` }
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/getBatchSamplersUniformGroup.mjs
var batchSamplersUniformGroupHash = {};
function getBatchSamplersUniformGroup(maxTextures) {
	let batchSamplersUniformGroup = batchSamplersUniformGroupHash[maxTextures];
	if (batchSamplersUniformGroup) return batchSamplersUniformGroup;
	const sampleValues = new Int32Array(maxTextures);
	for (let i = 0; i < maxTextures; i++) sampleValues[i] = i;
	batchSamplersUniformGroup = batchSamplersUniformGroupHash[maxTextures] = new UniformGroup({ uTextures: {
		value: sampleValues,
		type: `i32`,
		size: maxTextures
	} }, { isStatic: true });
	return batchSamplersUniformGroup;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/shared/DefaultShader.mjs
var DefaultShader = class extends Shader {
	constructor(maxTextures) {
		const glProgram = compileHighShaderGlProgram({
			name: "batch",
			bits: [
				colorBitGl,
				generateTextureBatchBitGl(maxTextures),
				roundPixelsBitGl
			]
		});
		const gpuProgram = compileHighShaderGpuProgram({
			name: "batch",
			bits: [
				colorBit,
				generateTextureBatchBit(maxTextures),
				roundPixelsBit
			]
		});
		super({
			glProgram,
			gpuProgram,
			resources: { batchSamplers: getBatchSamplersUniformGroup(maxTextures) }
		});
		this.maxTextures = maxTextures;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/shared/DefaultBatcher.mjs
var defaultShader = null;
var _DefaultBatcher = class _DefaultBatcher extends Batcher {
	constructor(options) {
		super(options);
		this.geometry = new BatchGeometry();
		this.name = _DefaultBatcher.extension.name;
		/** The size of one attribute. 1 = 32 bit. x, y, u, v, color, textureIdAndRound -> total = 6 */
		this.vertexSize = 6;
		defaultShader ?? (defaultShader = new DefaultShader(options.maxTextures));
		this.shader = defaultShader;
	}
	/**
	* Packs the attributes of a DefaultBatchableMeshElement into the provided views.
	* @param element - The DefaultBatchableMeshElement to pack.
	* @param float32View - The Float32Array view to pack into.
	* @param uint32View - The Uint32Array view to pack into.
	* @param index - The starting index in the views.
	* @param textureId - The texture ID to use.
	*/
	packAttributes(element, float32View, uint32View, index, textureId) {
		const textureIdAndRound = textureId << 16 | element.roundPixels & 65535;
		const wt = element.transform;
		const a = wt.a;
		const b = wt.b;
		const c = wt.c;
		const d = wt.d;
		const tx = wt.tx;
		const ty = wt.ty;
		const { positions, uvs } = element;
		const argb = element.color;
		const offset = element.attributeOffset;
		const end = offset + element.attributeSize;
		for (let i = offset; i < end; i++) {
			const i2 = i * 2;
			const x = positions[i2];
			const y = positions[i2 + 1];
			float32View[index++] = a * x + c * y + tx;
			float32View[index++] = d * y + b * x + ty;
			float32View[index++] = uvs[i2];
			float32View[index++] = uvs[i2 + 1];
			uint32View[index++] = argb;
			uint32View[index++] = textureIdAndRound;
		}
	}
	/**
	* Packs the attributes of a DefaultBatchableQuadElement into the provided views.
	* @param element - The DefaultBatchableQuadElement to pack.
	* @param float32View - The Float32Array view to pack into.
	* @param uint32View - The Uint32Array view to pack into.
	* @param index - The starting index in the views.
	* @param textureId - The texture ID to use.
	*/
	packQuadAttributes(element, float32View, uint32View, index, textureId) {
		const texture = element.texture;
		const wt = element.transform;
		const a = wt.a;
		const b = wt.b;
		const c = wt.c;
		const d = wt.d;
		const tx = wt.tx;
		const ty = wt.ty;
		const bounds = element.bounds;
		const w0 = bounds.maxX;
		const w1 = bounds.minX;
		const h0 = bounds.maxY;
		const h1 = bounds.minY;
		const uvs = texture.uvs;
		const argb = element.color;
		const textureIdAndRound = textureId << 16 | element.roundPixels & 65535;
		float32View[index + 0] = a * w1 + c * h1 + tx;
		float32View[index + 1] = d * h1 + b * w1 + ty;
		float32View[index + 2] = uvs.x0;
		float32View[index + 3] = uvs.y0;
		uint32View[index + 4] = argb;
		uint32View[index + 5] = textureIdAndRound;
		float32View[index + 6] = a * w0 + c * h1 + tx;
		float32View[index + 7] = d * h1 + b * w0 + ty;
		float32View[index + 8] = uvs.x1;
		float32View[index + 9] = uvs.y1;
		uint32View[index + 10] = argb;
		uint32View[index + 11] = textureIdAndRound;
		float32View[index + 12] = a * w0 + c * h0 + tx;
		float32View[index + 13] = d * h0 + b * w0 + ty;
		float32View[index + 14] = uvs.x2;
		float32View[index + 15] = uvs.y2;
		uint32View[index + 16] = argb;
		uint32View[index + 17] = textureIdAndRound;
		float32View[index + 18] = a * w1 + c * h0 + tx;
		float32View[index + 19] = d * h0 + b * w1 + ty;
		float32View[index + 20] = uvs.x3;
		float32View[index + 21] = uvs.y3;
		uint32View[index + 22] = argb;
		uint32View[index + 23] = textureIdAndRound;
	}
	/**
	* Updates the maximum number of textures that can be used in the shader.
	* @param maxTextures - The maximum number of textures that can be used in the shader.
	* @internal
	*/
	_updateMaxTextures(maxTextures) {
		if (this.shader.maxTextures === maxTextures) return;
		defaultShader = new DefaultShader(maxTextures);
		this.shader = defaultShader;
	}
	destroy() {
		this.shader = null;
		super.destroy();
	}
};
/** @ignore */
_DefaultBatcher.extension = {
	type: [ExtensionType.Batcher],
	name: "default"
};
var DefaultBatcher = _DefaultBatcher;
//#endregion
//#region node_modules/pixi.js/lib/utils/data/GCManagedHash.mjs
var GCManagedHash = class {
	constructor(options) {
		this.items = /* @__PURE__ */ Object.create(null);
		const { renderer, type, onUnload, priority, name } = options;
		this._renderer = renderer;
		renderer.gc.addResourceHash(this, "items", type, priority ?? 0);
		this._onUnload = onUnload;
		this.name = name;
	}
	/**
	* Add an item to the hash. No-op if already added.
	* @param item
	* @returns true if the item was added, false if it was already in the hash
	*/
	add(item) {
		if (this.items[item.uid]) return false;
		this.items[item.uid] = item;
		item.once("unload", this.remove, this);
		item._gcLastUsed = this._renderer.gc.now;
		return true;
	}
	remove(item, ...args) {
		if (!this.items[item.uid]) return;
		const gpuData = item._gpuData[this._renderer.uid];
		if (!gpuData) return;
		this._onUnload?.(item, ...args);
		item.off("unload", this.remove, this);
		gpuData.destroy();
		item._gpuData[this._renderer.uid] = null;
		this.items[item.uid] = null;
	}
	removeAll(...args) {
		Object.values(this.items).forEach((item) => item && this.remove(item, ...args));
	}
	destroy(...args) {
		this.removeAll(...args);
		this.items = /* @__PURE__ */ Object.create(null);
		this._renderer = null;
		this._onUnload = null;
	}
};
//#endregion
export { BatchTextureArray as A, compileOutputs as C, BatchGeometry as D, addBits as E, STENCIL_MODES as F, fastCopy as I, ViewableBuffer as L, checkMaxIfStatementsInShader as M, getAdjustedBlendModeBlend as N, Batch as O, BLEND_TO_NPM as P, injectBits as S, compileHooks as T, fragmentGlTemplate as _, roundPixelsBit as a, compileHighShader as b, generateTextureBatchBitGl as c, compileHighShaderGlProgram as d, compileHighShaderGpuProgram as f, fragmentGPUTemplate as g, globalUniformsUBOBitGl as h, getBatchSamplersUniformGroup as i, getMaxTexturesPerBatch as j, Batcher as k, colorBit as l, globalUniformsBitGl as m, DefaultBatcher as n, roundPixelsBitGl as o, globalUniformsBit as p, DefaultShader as r, generateTextureBatchBit as s, GCManagedHash as t, colorBitGl as u, vertexGPUTemplate as v, compileInputs as w, compileHighShaderGl as x, vertexGlTemplate as y };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR0NNYW5hZ2VkSGFzaC1CbEVMUE1kSS5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi9waXhpLmpzL2xpYi91dGlscy9kYXRhL1ZpZXdhYmxlQnVmZmVyLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL2J1ZmZlci91dGlscy9mYXN0Q29weS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9zdGF0ZS9jb25zdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9zdGF0ZS9nZXRBZGp1c3RlZEJsZW5kTW9kZUJsZW5kLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9iYXRjaGVyL2dsL3V0aWxzL2NoZWNrTWF4SWZTdGF0ZW1lbnRzSW5TaGFkZXIubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2JhdGNoZXIvZ2wvdXRpbHMvbWF4UmVjb21tZW5kZWRUZXh0dXJlcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvYmF0Y2hlci9zaGFyZWQvQmF0Y2hUZXh0dXJlQXJyYXkubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2JhdGNoZXIvc2hhcmVkL0JhdGNoZXIubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2JhdGNoZXIvc2hhcmVkL0JhdGNoR2VvbWV0cnkubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2hpZ2gtc2hhZGVyL2NvbXBpbGVyL3V0aWxzL2FkZEJpdHMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2hpZ2gtc2hhZGVyL2NvbXBpbGVyL3V0aWxzL2NvbXBpbGVIb29rcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvaGlnaC1zaGFkZXIvY29tcGlsZXIvdXRpbHMvY29tcGlsZUlucHV0cy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvaGlnaC1zaGFkZXIvY29tcGlsZXIvdXRpbHMvY29tcGlsZU91dHB1dHMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2hpZ2gtc2hhZGVyL2NvbXBpbGVyL3V0aWxzL2luamVjdEJpdHMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2hpZ2gtc2hhZGVyL2NvbXBpbGVyL2NvbXBpbGVIaWdoU2hhZGVyLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9oaWdoLXNoYWRlci9kZWZhdWx0UHJvZ3JhbVRlbXBsYXRlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9oaWdoLXNoYWRlci9zaGFkZXItYml0cy9nbG9iYWxVbmlmb3Jtc0JpdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvaGlnaC1zaGFkZXIvY29tcGlsZUhpZ2hTaGFkZXJUb1Byb2dyYW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2hpZ2gtc2hhZGVyL3NoYWRlci1iaXRzL2NvbG9yQml0Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9oaWdoLXNoYWRlci9zaGFkZXItYml0cy9nZW5lcmF0ZVRleHR1cmVCYXRjaEJpdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvaGlnaC1zaGFkZXIvc2hhZGVyLWJpdHMvcm91bmRQaXhlbHNCaXQubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9nbC9zaGFkZXIvZ2V0QmF0Y2hTYW1wbGVyc1VuaWZvcm1Hcm91cC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvYmF0Y2hlci9zaGFyZWQvRGVmYXVsdFNoYWRlci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvYmF0Y2hlci9zaGFyZWQvRGVmYXVsdEJhdGNoZXIubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvdXRpbHMvZGF0YS9HQ01hbmFnZWRIYXNoLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbmNsYXNzIFZpZXdhYmxlQnVmZmVyIHtcbiAgY29uc3RydWN0b3Ioc2l6ZU9yQnVmZmVyKSB7XG4gICAgaWYgKHR5cGVvZiBzaXplT3JCdWZmZXIgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgIHRoaXMucmF3QmluYXJ5RGF0YSA9IG5ldyBBcnJheUJ1ZmZlcihzaXplT3JCdWZmZXIpO1xuICAgIH0gZWxzZSBpZiAoc2l6ZU9yQnVmZmVyIGluc3RhbmNlb2YgVWludDhBcnJheSkge1xuICAgICAgdGhpcy5yYXdCaW5hcnlEYXRhID0gc2l6ZU9yQnVmZmVyLmJ1ZmZlcjtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5yYXdCaW5hcnlEYXRhID0gc2l6ZU9yQnVmZmVyO1xuICAgIH1cbiAgICB0aGlzLnVpbnQzMlZpZXcgPSBuZXcgVWludDMyQXJyYXkodGhpcy5yYXdCaW5hcnlEYXRhKTtcbiAgICB0aGlzLmZsb2F0MzJWaWV3ID0gbmV3IEZsb2F0MzJBcnJheSh0aGlzLnJhd0JpbmFyeURhdGEpO1xuICAgIHRoaXMuc2l6ZSA9IHRoaXMucmF3QmluYXJ5RGF0YS5ieXRlTGVuZ3RoO1xuICB9XG4gIC8qKiBWaWV3IG9uIHRoZSByYXcgYmluYXJ5IGRhdGEgYXMgYSBgSW50OEFycmF5YC4gKi9cbiAgZ2V0IGludDhWaWV3KCkge1xuICAgIGlmICghdGhpcy5faW50OFZpZXcpIHtcbiAgICAgIHRoaXMuX2ludDhWaWV3ID0gbmV3IEludDhBcnJheSh0aGlzLnJhd0JpbmFyeURhdGEpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5faW50OFZpZXc7XG4gIH1cbiAgLyoqIFZpZXcgb24gdGhlIHJhdyBiaW5hcnkgZGF0YSBhcyBhIGBVaW50OEFycmF5YC4gKi9cbiAgZ2V0IHVpbnQ4VmlldygpIHtcbiAgICBpZiAoIXRoaXMuX3VpbnQ4Vmlldykge1xuICAgICAgdGhpcy5fdWludDhWaWV3ID0gbmV3IFVpbnQ4QXJyYXkodGhpcy5yYXdCaW5hcnlEYXRhKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX3VpbnQ4VmlldztcbiAgfVxuICAvKiogIFZpZXcgb24gdGhlIHJhdyBiaW5hcnkgZGF0YSBhcyBhIGBJbnQxNkFycmF5YC4gKi9cbiAgZ2V0IGludDE2VmlldygpIHtcbiAgICBpZiAoIXRoaXMuX2ludDE2Vmlldykge1xuICAgICAgdGhpcy5faW50MTZWaWV3ID0gbmV3IEludDE2QXJyYXkodGhpcy5yYXdCaW5hcnlEYXRhKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2ludDE2VmlldztcbiAgfVxuICAvKiogVmlldyBvbiB0aGUgcmF3IGJpbmFyeSBkYXRhIGFzIGEgYEludDMyQXJyYXlgLiAqL1xuICBnZXQgaW50MzJWaWV3KCkge1xuICAgIGlmICghdGhpcy5faW50MzJWaWV3KSB7XG4gICAgICB0aGlzLl9pbnQzMlZpZXcgPSBuZXcgSW50MzJBcnJheSh0aGlzLnJhd0JpbmFyeURhdGEpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5faW50MzJWaWV3O1xuICB9XG4gIC8qKiBWaWV3IG9uIHRoZSByYXcgYmluYXJ5IGRhdGEgYXMgYSBgRmxvYXQ2NEFycmF5YC4gKi9cbiAgZ2V0IGZsb2F0NjRWaWV3KCkge1xuICAgIGlmICghdGhpcy5fZmxvYXQ2NEFycmF5KSB7XG4gICAgICB0aGlzLl9mbG9hdDY0QXJyYXkgPSBuZXcgRmxvYXQ2NEFycmF5KHRoaXMucmF3QmluYXJ5RGF0YSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9mbG9hdDY0QXJyYXk7XG4gIH1cbiAgLyoqIFZpZXcgb24gdGhlIHJhdyBiaW5hcnkgZGF0YSBhcyBhIGBCaWdVaW50NjRBcnJheWAuICovXG4gIGdldCBiaWdVaW50NjRWaWV3KCkge1xuICAgIGlmICghdGhpcy5fYmlnVWludDY0QXJyYXkpIHtcbiAgICAgIHRoaXMuX2JpZ1VpbnQ2NEFycmF5ID0gbmV3IEJpZ1VpbnQ2NEFycmF5KHRoaXMucmF3QmluYXJ5RGF0YSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9iaWdVaW50NjRBcnJheTtcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgdmlldyBvZiB0aGUgZ2l2ZW4gdHlwZS5cbiAgICogQHBhcmFtIHR5cGUgLSBPbmUgb2YgYGludDhgLCBgdWludDhgLCBgaW50MTZgLFxuICAgKiAgICBgdWludDE2YCwgYGludDMyYCwgYHVpbnQzMmAsIGFuZCBgZmxvYXQzMmAuXG4gICAqIEByZXR1cm5zIC0gdHlwZWQgYXJyYXkgb2YgZ2l2ZW4gdHlwZVxuICAgKi9cbiAgdmlldyh0eXBlKSB7XG4gICAgcmV0dXJuIHRoaXNbYCR7dHlwZX1WaWV3YF07XG4gIH1cbiAgLyoqIERlc3Ryb3lzIGFsbCBidWZmZXIgcmVmZXJlbmNlcy4gRG8gbm90IHVzZSBhZnRlciBjYWxsaW5nIHRoaXMuICovXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5yYXdCaW5hcnlEYXRhID0gbnVsbDtcbiAgICB0aGlzLnVpbnQzMlZpZXcgPSBudWxsO1xuICAgIHRoaXMuZmxvYXQzMlZpZXcgPSBudWxsO1xuICAgIHRoaXMudWludDE2VmlldyA9IG51bGw7XG4gICAgdGhpcy5faW50OFZpZXcgPSBudWxsO1xuICAgIHRoaXMuX3VpbnQ4VmlldyA9IG51bGw7XG4gICAgdGhpcy5faW50MTZWaWV3ID0gbnVsbDtcbiAgICB0aGlzLl9pbnQzMlZpZXcgPSBudWxsO1xuICAgIHRoaXMuX2Zsb2F0NjRBcnJheSA9IG51bGw7XG4gICAgdGhpcy5fYmlnVWludDY0QXJyYXkgPSBudWxsO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBzaXplIG9mIHRoZSBnaXZlbiB0eXBlIGluIGJ5dGVzLlxuICAgKiBAcGFyYW0gdHlwZSAtIE9uZSBvZiBgaW50OGAsIGB1aW50OGAsIGBpbnQxNmAsXG4gICAqICAgYHVpbnQxNmAsIGBpbnQzMmAsIGB1aW50MzJgLCBhbmQgYGZsb2F0MzJgLlxuICAgKiBAcmV0dXJucyAtIHNpemUgb2YgdGhlIHR5cGUgaW4gYnl0ZXNcbiAgICovXG4gIHN0YXRpYyBzaXplT2YodHlwZSkge1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSBcImludDhcIjpcbiAgICAgIGNhc2UgXCJ1aW50OFwiOlxuICAgICAgICByZXR1cm4gMTtcbiAgICAgIGNhc2UgXCJpbnQxNlwiOlxuICAgICAgY2FzZSBcInVpbnQxNlwiOlxuICAgICAgICByZXR1cm4gMjtcbiAgICAgIGNhc2UgXCJpbnQzMlwiOlxuICAgICAgY2FzZSBcInVpbnQzMlwiOlxuICAgICAgY2FzZSBcImZsb2F0MzJcIjpcbiAgICAgICAgcmV0dXJuIDQ7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dHlwZX0gaXNuJ3QgYSB2YWxpZCB2aWV3IHR5cGVgKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IHsgVmlld2FibGVCdWZmZXIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVZpZXdhYmxlQnVmZmVyLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gZmFzdENvcHkoc291cmNlQnVmZmVyLCBkZXN0aW5hdGlvbkJ1ZmZlciwgc291cmNlT2Zmc2V0LCBieXRlTGVuZ3RoKSB7XG4gIHNvdXJjZU9mZnNldCA/PyAoc291cmNlT2Zmc2V0ID0gMCk7XG4gIGJ5dGVMZW5ndGggPz8gKGJ5dGVMZW5ndGggPSBNYXRoLm1pbihzb3VyY2VCdWZmZXIuYnl0ZUxlbmd0aCAtIHNvdXJjZU9mZnNldCwgZGVzdGluYXRpb25CdWZmZXIuYnl0ZUxlbmd0aCkpO1xuICBpZiAoIShzb3VyY2VPZmZzZXQgJiA3KSAmJiAhKGJ5dGVMZW5ndGggJiA3KSkge1xuICAgIGNvbnN0IGxlbiA9IGJ5dGVMZW5ndGggLyA4O1xuICAgIG5ldyBGbG9hdDY0QXJyYXkoZGVzdGluYXRpb25CdWZmZXIsIDAsIGxlbikuc2V0KG5ldyBGbG9hdDY0QXJyYXkoc291cmNlQnVmZmVyLCBzb3VyY2VPZmZzZXQsIGxlbikpO1xuICB9IGVsc2UgaWYgKCEoc291cmNlT2Zmc2V0ICYgMykgJiYgIShieXRlTGVuZ3RoICYgMykpIHtcbiAgICBjb25zdCBsZW4gPSBieXRlTGVuZ3RoIC8gNDtcbiAgICBuZXcgRmxvYXQzMkFycmF5KGRlc3RpbmF0aW9uQnVmZmVyLCAwLCBsZW4pLnNldChuZXcgRmxvYXQzMkFycmF5KHNvdXJjZUJ1ZmZlciwgc291cmNlT2Zmc2V0LCBsZW4pKTtcbiAgfSBlbHNlIHtcbiAgICBuZXcgVWludDhBcnJheShkZXN0aW5hdGlvbkJ1ZmZlcikuc2V0KG5ldyBVaW50OEFycmF5KHNvdXJjZUJ1ZmZlciwgc291cmNlT2Zmc2V0LCBieXRlTGVuZ3RoKSk7XG4gIH1cbn1cblxuZXhwb3J0IHsgZmFzdENvcHkgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZhc3RDb3B5Lm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY29uc3QgQkxFTkRfVE9fTlBNID0ge1xuICBub3JtYWw6IFwibm9ybWFsLW5wbVwiLFxuICBhZGQ6IFwiYWRkLW5wbVwiLFxuICBzY3JlZW46IFwic2NyZWVuLW5wbVwiXG59O1xudmFyIFNURU5DSUxfTU9ERVMgPSAvKiBAX19QVVJFX18gKi8gKChTVEVOQ0lMX01PREVTMikgPT4ge1xuICBTVEVOQ0lMX01PREVTMltTVEVOQ0lMX01PREVTMltcIkRJU0FCTEVEXCJdID0gMF0gPSBcIkRJU0FCTEVEXCI7XG4gIFNURU5DSUxfTU9ERVMyW1NURU5DSUxfTU9ERVMyW1wiUkVOREVSSU5HX01BU0tfQUREXCJdID0gMV0gPSBcIlJFTkRFUklOR19NQVNLX0FERFwiO1xuICBTVEVOQ0lMX01PREVTMltTVEVOQ0lMX01PREVTMltcIk1BU0tfQUNUSVZFXCJdID0gMl0gPSBcIk1BU0tfQUNUSVZFXCI7XG4gIFNURU5DSUxfTU9ERVMyW1NURU5DSUxfTU9ERVMyW1wiSU5WRVJTRV9NQVNLX0FDVElWRVwiXSA9IDNdID0gXCJJTlZFUlNFX01BU0tfQUNUSVZFXCI7XG4gIFNURU5DSUxfTU9ERVMyW1NURU5DSUxfTU9ERVMyW1wiUkVOREVSSU5HX01BU0tfUkVNT1ZFXCJdID0gNF0gPSBcIlJFTkRFUklOR19NQVNLX1JFTU9WRVwiO1xuICBTVEVOQ0lMX01PREVTMltTVEVOQ0lMX01PREVTMltcIk5PTkVcIl0gPSA1XSA9IFwiTk9ORVwiO1xuICByZXR1cm4gU1RFTkNJTF9NT0RFUzI7XG59KShTVEVOQ0lMX01PREVTIHx8IHt9KTtcblxuZXhwb3J0IHsgQkxFTkRfVE9fTlBNLCBTVEVOQ0lMX01PREVTIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb25zdC5tanMubWFwXG4iLCJpbXBvcnQgeyBCTEVORF9UT19OUE0gfSBmcm9tICcuL2NvbnN0Lm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gZ2V0QWRqdXN0ZWRCbGVuZE1vZGVCbGVuZChibGVuZE1vZGUsIHRleHR1cmVTb3VyY2UpIHtcbiAgaWYgKHRleHR1cmVTb3VyY2UuYWxwaGFNb2RlID09PSBcIm5vLXByZW11bHRpcGx5LWFscGhhXCIpIHtcbiAgICByZXR1cm4gQkxFTkRfVE9fTlBNW2JsZW5kTW9kZV0gfHwgYmxlbmRNb2RlO1xuICB9XG4gIHJldHVybiBibGVuZE1vZGU7XG59XG5cbmV4cG9ydCB7IGdldEFkanVzdGVkQmxlbmRNb2RlQmxlbmQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdldEFkanVzdGVkQmxlbmRNb2RlQmxlbmQubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBmcmFnVGVtcGxhdGUgPSBbXG4gIFwicHJlY2lzaW9uIG1lZGl1bXAgZmxvYXQ7XCIsXG4gIFwidm9pZCBtYWluKHZvaWQpe1wiLFxuICBcImZsb2F0IHRlc3QgPSAwLjE7XCIsXG4gIFwiJWZvcmxvb3AlXCIsXG4gIFwiZ2xfRnJhZ0NvbG9yID0gdmVjNCgwLjApO1wiLFxuICBcIn1cIlxuXS5qb2luKFwiXFxuXCIpO1xuZnVuY3Rpb24gZ2VuZXJhdGVJZlRlc3RTcmMobWF4SWZzKSB7XG4gIGxldCBzcmMgPSBcIlwiO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG1heElmczsgKytpKSB7XG4gICAgaWYgKGkgPiAwKSB7XG4gICAgICBzcmMgKz0gXCJcXG5lbHNlIFwiO1xuICAgIH1cbiAgICBpZiAoaSA8IG1heElmcyAtIDEpIHtcbiAgICAgIHNyYyArPSBgaWYodGVzdCA9PSAke2l9LjApe31gO1xuICAgIH1cbiAgfVxuICByZXR1cm4gc3JjO1xufVxuZnVuY3Rpb24gY2hlY2tNYXhJZlN0YXRlbWVudHNJblNoYWRlcihtYXhJZnMsIGdsKSB7XG4gIGlmIChtYXhJZnMgPT09IDApIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHZhbHVlIG9mIGAwYCBwYXNzZWQgdG8gYGNoZWNrTWF4SWZTdGF0ZW1lbnRzSW5TaGFkZXJgXCIpO1xuICB9XG4gIGNvbnN0IHNoYWRlciA9IGdsLmNyZWF0ZVNoYWRlcihnbC5GUkFHTUVOVF9TSEFERVIpO1xuICB0cnkge1xuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICBjb25zdCBmcmFnbWVudFNyYyA9IGZyYWdUZW1wbGF0ZS5yZXBsYWNlKC8lZm9ybG9vcCUvZ2ksIGdlbmVyYXRlSWZUZXN0U3JjKG1heElmcykpO1xuICAgICAgZ2wuc2hhZGVyU291cmNlKHNoYWRlciwgZnJhZ21lbnRTcmMpO1xuICAgICAgZ2wuY29tcGlsZVNoYWRlcihzaGFkZXIpO1xuICAgICAgaWYgKCFnbC5nZXRTaGFkZXJQYXJhbWV0ZXIoc2hhZGVyLCBnbC5DT01QSUxFX1NUQVRVUykpIHtcbiAgICAgICAgbWF4SWZzID0gbWF4SWZzIC8gMiB8IDA7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH0gZmluYWxseSB7XG4gICAgZ2wuZGVsZXRlU2hhZGVyKHNoYWRlcik7XG4gIH1cbiAgcmV0dXJuIG1heElmcztcbn1cblxuZXhwb3J0IHsgY2hlY2tNYXhJZlN0YXRlbWVudHNJblNoYWRlciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y2hlY2tNYXhJZlN0YXRlbWVudHNJblNoYWRlci5tanMubWFwXG4iLCJpbXBvcnQgeyBnZXRUZXN0Q29udGV4dCB9IGZyb20gJy4uLy4uLy4uL3JlbmRlcmVycy9nbC9zaGFkZXIvcHJvZ3JhbS9nZXRUZXN0Q29udGV4dC5tanMnO1xuaW1wb3J0IHsgY2hlY2tNYXhJZlN0YXRlbWVudHNJblNoYWRlciB9IGZyb20gJy4vY2hlY2tNYXhJZlN0YXRlbWVudHNJblNoYWRlci5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmxldCBtYXhUZXh0dXJlc1BlckJhdGNoQ2FjaGUgPSBudWxsO1xuZnVuY3Rpb24gZ2V0TWF4VGV4dHVyZXNQZXJCYXRjaCgpIHtcbiAgaWYgKG1heFRleHR1cmVzUGVyQmF0Y2hDYWNoZSkgcmV0dXJuIG1heFRleHR1cmVzUGVyQmF0Y2hDYWNoZTtcbiAgY29uc3QgZ2wgPSBnZXRUZXN0Q29udGV4dCgpO1xuICBtYXhUZXh0dXJlc1BlckJhdGNoQ2FjaGUgPSBnbC5nZXRQYXJhbWV0ZXIoZ2wuTUFYX1RFWFRVUkVfSU1BR0VfVU5JVFMpO1xuICBtYXhUZXh0dXJlc1BlckJhdGNoQ2FjaGUgPSBjaGVja01heElmU3RhdGVtZW50c0luU2hhZGVyKFxuICAgIG1heFRleHR1cmVzUGVyQmF0Y2hDYWNoZSxcbiAgICBnbFxuICApO1xuICBnbC5nZXRFeHRlbnNpb24oXCJXRUJHTF9sb3NlX2NvbnRleHRcIik/Lmxvc2VDb250ZXh0KCk7XG4gIHJldHVybiBtYXhUZXh0dXJlc1BlckJhdGNoQ2FjaGU7XG59XG5cbmV4cG9ydCB7IGdldE1heFRleHR1cmVzUGVyQmF0Y2ggfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1heFJlY29tbWVuZGVkVGV4dHVyZXMubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBCYXRjaFRleHR1cmVBcnJheSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIC8qKiBSZXNwZWN0aXZlIGxvY2F0aW9ucyBmb3IgdGV4dHVyZXMuICovXG4gICAgdGhpcy5pZHMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB0aGlzLnRleHR1cmVzID0gW107XG4gICAgdGhpcy5jb3VudCA9IDA7XG4gIH1cbiAgLyoqIENsZWFyIHRoZSB0ZXh0dXJlcyBhbmQgdGhlaXIgbG9jYXRpb25zLiAqL1xuICBjbGVhcigpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuY291bnQ7IGkrKykge1xuICAgICAgY29uc3QgdCA9IHRoaXMudGV4dHVyZXNbaV07XG4gICAgICB0aGlzLnRleHR1cmVzW2ldID0gbnVsbDtcbiAgICAgIHRoaXMuaWRzW3QudWlkXSA9IG51bGw7XG4gICAgfVxuICAgIHRoaXMuY291bnQgPSAwO1xuICB9XG59XG5cbmV4cG9ydCB7IEJhdGNoVGV4dHVyZUFycmF5IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1CYXRjaFRleHR1cmVBcnJheS5tanMubWFwXG4iLCJpbXBvcnQgeyB1aWQgfSBmcm9tICcuLi8uLi8uLi91dGlscy9kYXRhL3VpZC5tanMnO1xuaW1wb3J0IHsgVmlld2FibGVCdWZmZXIgfSBmcm9tICcuLi8uLi8uLi91dGlscy9kYXRhL1ZpZXdhYmxlQnVmZmVyLm1qcyc7XG5pbXBvcnQgeyBkZXByZWNhdGlvbiB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2xvZ2dpbmcvZGVwcmVjYXRpb24ubWpzJztcbmltcG9ydCB7IEdsb2JhbFJlc291cmNlUmVnaXN0cnkgfSBmcm9tICcuLi8uLi8uLi91dGlscy9wb29sL0dsb2JhbFJlc291cmNlUmVnaXN0cnkubWpzJztcbmltcG9ydCB7IGZhc3RDb3B5IH0gZnJvbSAnLi4vLi4vcmVuZGVyZXJzL3NoYXJlZC9idWZmZXIvdXRpbHMvZmFzdENvcHkubWpzJztcbmltcG9ydCB7IGdldEFkanVzdGVkQmxlbmRNb2RlQmxlbmQgfSBmcm9tICcuLi8uLi9yZW5kZXJlcnMvc2hhcmVkL3N0YXRlL2dldEFkanVzdGVkQmxlbmRNb2RlQmxlbmQubWpzJztcbmltcG9ydCB7IGdldE1heFRleHR1cmVzUGVyQmF0Y2ggfSBmcm9tICcuLi9nbC91dGlscy9tYXhSZWNvbW1lbmRlZFRleHR1cmVzLm1qcyc7XG5pbXBvcnQgeyBCYXRjaFRleHR1cmVBcnJheSB9IGZyb20gJy4vQmF0Y2hUZXh0dXJlQXJyYXkubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBCYXRjaCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMucmVuZGVyUGlwZUlkID0gXCJiYXRjaFwiO1xuICAgIHRoaXMuYWN0aW9uID0gXCJzdGFydEJhdGNoXCI7XG4gICAgLy8gVE9ETyAtIGV2ZW50dWFsbHkgdGhpcyBjb3VsZCBiZSB1c2VmdWwgZm9yIGZsYWdnaW5nIGJhdGNoZXMgYXMgZGlydHkgYW5kIHRoZW4gb25seSByZWJ1aWxkaW5nIHRob3NlIG9uZXNcbiAgICAvLyBwdWJsaWMgZWxlbWVudFN0YXJ0ID0gMDtcbiAgICAvLyBwdWJsaWMgZWxlbWVudFNpemUgPSAwO1xuICAgIC8vIGZvciBkcmF3aW5nLi5cbiAgICB0aGlzLnN0YXJ0ID0gMDtcbiAgICB0aGlzLnNpemUgPSAwO1xuICAgIHRoaXMudGV4dHVyZXMgPSBuZXcgQmF0Y2hUZXh0dXJlQXJyYXkoKTtcbiAgICB0aGlzLmJsZW5kTW9kZSA9IFwibm9ybWFsXCI7XG4gICAgdGhpcy50b3BvbG9neSA9IFwidHJpYW5nbGUtc3RyaXBcIjtcbiAgICB0aGlzLmNhbkJ1bmRsZSA9IHRydWU7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLnRleHR1cmVzID0gbnVsbDtcbiAgICB0aGlzLmdwdUJpbmRHcm91cCA9IG51bGw7XG4gICAgdGhpcy5iaW5kR3JvdXAgPSBudWxsO1xuICAgIHRoaXMuYmF0Y2hlciA9IG51bGw7XG4gICAgdGhpcy5lbGVtZW50cyA9IG51bGw7XG4gIH1cbn1cbmNvbnN0IGJhdGNoUG9vbCA9IFtdO1xubGV0IGJhdGNoUG9vbEluZGV4ID0gMDtcbkdsb2JhbFJlc291cmNlUmVnaXN0cnkucmVnaXN0ZXIoe1xuICBjbGVhcjogKCkgPT4ge1xuICAgIGlmIChiYXRjaFBvb2wubGVuZ3RoID4gMCkge1xuICAgICAgZm9yIChjb25zdCBpdGVtIG9mIGJhdGNoUG9vbCkge1xuICAgICAgICBpZiAoaXRlbSkgaXRlbS5kZXN0cm95KCk7XG4gICAgICB9XG4gICAgfVxuICAgIGJhdGNoUG9vbC5sZW5ndGggPSAwO1xuICAgIGJhdGNoUG9vbEluZGV4ID0gMDtcbiAgfVxufSk7XG5mdW5jdGlvbiBnZXRCYXRjaEZyb21Qb29sKCkge1xuICByZXR1cm4gYmF0Y2hQb29sSW5kZXggPiAwID8gYmF0Y2hQb29sWy0tYmF0Y2hQb29sSW5kZXhdIDogbmV3IEJhdGNoKCk7XG59XG5mdW5jdGlvbiByZXR1cm5CYXRjaFRvUG9vbChiYXRjaCkge1xuICBiYXRjaC5lbGVtZW50cyA9IG51bGw7XG4gIGJhdGNoUG9vbFtiYXRjaFBvb2xJbmRleCsrXSA9IGJhdGNoO1xufVxubGV0IEJBVENIX1RJQ0sgPSAwO1xuY29uc3QgX0JhdGNoZXIgPSBjbGFzcyBfQmF0Y2hlciB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAvKiogdW5pcXVlIGlkIGZvciB0aGlzIGJhdGNoZXIgKi9cbiAgICB0aGlzLnVpZCA9IHVpZChcImJhdGNoZXJcIik7XG4gICAgLyoqIEluZGljYXRlcyB3aGV0aGVyIHRoZSBiYXRjaCBkYXRhIGhhcyBiZWVuIG1vZGlmaWVkIGFuZCBuZWVkcyB1cGRhdGluZy4gKi9cbiAgICB0aGlzLmRpcnR5ID0gdHJ1ZTtcbiAgICAvKiogVGhlIGN1cnJlbnQgaW5kZXggb2YgdGhlIGJhdGNoIGJlaW5nIHByb2Nlc3NlZC4gKi9cbiAgICB0aGlzLmJhdGNoSW5kZXggPSAwO1xuICAgIC8qKiBBbiBhcnJheSBvZiBhbGwgYmF0Y2hlcyBjcmVhdGVkIGR1cmluZyB0aGUgY3VycmVudCByZW5kZXJpbmcgcHJvY2Vzcy4gKi9cbiAgICB0aGlzLmJhdGNoZXMgPSBbXTtcbiAgICB0aGlzLl9lbGVtZW50cyA9IFtdO1xuICAgIG9wdGlvbnMgPSB7IC4uLl9CYXRjaGVyLmRlZmF1bHRPcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgaWYgKCFvcHRpb25zLm1heFRleHR1cmVzKSB7XG4gICAgICBkZXByZWNhdGlvbihcInY4LjguMFwiLCBcIm1heFRleHR1cmVzIGlzIGEgcmVxdWlyZWQgb3B0aW9uIGZvciBCYXRjaGVyIG5vdywgcGxlYXNlIHBhc3MgaXQgaW4gdGhlIG9wdGlvbnNcIik7XG4gICAgICBvcHRpb25zLm1heFRleHR1cmVzID0gZ2V0TWF4VGV4dHVyZXNQZXJCYXRjaCgpO1xuICAgIH1cbiAgICBjb25zdCB7IG1heFRleHR1cmVzLCBhdHRyaWJ1dGVzSW5pdGlhbFNpemUsIGluZGljZXNJbml0aWFsU2l6ZSB9ID0gb3B0aW9ucztcbiAgICB0aGlzLmF0dHJpYnV0ZUJ1ZmZlciA9IG5ldyBWaWV3YWJsZUJ1ZmZlcihhdHRyaWJ1dGVzSW5pdGlhbFNpemUgKiA0KTtcbiAgICB0aGlzLmluZGV4QnVmZmVyID0gbmV3IFVpbnQxNkFycmF5KGluZGljZXNJbml0aWFsU2l6ZSk7XG4gICAgdGhpcy5tYXhUZXh0dXJlcyA9IG1heFRleHR1cmVzO1xuICB9XG4gIGJlZ2luKCkge1xuICAgIHRoaXMuZWxlbWVudFNpemUgPSAwO1xuICAgIHRoaXMuZWxlbWVudFN0YXJ0ID0gMDtcbiAgICB0aGlzLmluZGV4U2l6ZSA9IDA7XG4gICAgdGhpcy5hdHRyaWJ1dGVTaXplID0gMDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuYmF0Y2hJbmRleDsgaSsrKSB7XG4gICAgICByZXR1cm5CYXRjaFRvUG9vbCh0aGlzLmJhdGNoZXNbaV0pO1xuICAgIH1cbiAgICB0aGlzLmJhdGNoSW5kZXggPSAwO1xuICAgIHRoaXMuX2JhdGNoSW5kZXhTdGFydCA9IDA7XG4gICAgdGhpcy5fYmF0Y2hJbmRleFNpemUgPSAwO1xuICAgIHRoaXMuZGlydHkgPSB0cnVlO1xuICB9XG4gIGFkZChiYXRjaGFibGVPYmplY3QpIHtcbiAgICB0aGlzLl9lbGVtZW50c1t0aGlzLmVsZW1lbnRTaXplKytdID0gYmF0Y2hhYmxlT2JqZWN0O1xuICAgIGJhdGNoYWJsZU9iamVjdC5faW5kZXhTdGFydCA9IHRoaXMuaW5kZXhTaXplO1xuICAgIGJhdGNoYWJsZU9iamVjdC5fYXR0cmlidXRlU3RhcnQgPSB0aGlzLmF0dHJpYnV0ZVNpemU7XG4gICAgYmF0Y2hhYmxlT2JqZWN0Ll9iYXRjaGVyID0gdGhpcztcbiAgICB0aGlzLmluZGV4U2l6ZSArPSBiYXRjaGFibGVPYmplY3QuaW5kZXhTaXplO1xuICAgIHRoaXMuYXR0cmlidXRlU2l6ZSArPSBiYXRjaGFibGVPYmplY3QuYXR0cmlidXRlU2l6ZSAqIHRoaXMudmVydGV4U2l6ZTtcbiAgfVxuICBjaGVja0FuZFVwZGF0ZVRleHR1cmUoYmF0Y2hhYmxlT2JqZWN0LCB0ZXh0dXJlKSB7XG4gICAgY29uc3QgdGV4dHVyZUlkID0gYmF0Y2hhYmxlT2JqZWN0Ll9iYXRjaC50ZXh0dXJlcy5pZHNbdGV4dHVyZS5fc291cmNlLnVpZF07XG4gICAgaWYgKCF0ZXh0dXJlSWQgJiYgdGV4dHVyZUlkICE9PSAwKSByZXR1cm4gZmFsc2U7XG4gICAgYmF0Y2hhYmxlT2JqZWN0Ll90ZXh0dXJlSWQgPSB0ZXh0dXJlSWQ7XG4gICAgYmF0Y2hhYmxlT2JqZWN0LnRleHR1cmUgPSB0ZXh0dXJlO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHVwZGF0ZUVsZW1lbnQoYmF0Y2hhYmxlT2JqZWN0KSB7XG4gICAgdGhpcy5kaXJ0eSA9IHRydWU7XG4gICAgY29uc3QgYXR0cmlidXRlQnVmZmVyID0gdGhpcy5hdHRyaWJ1dGVCdWZmZXI7XG4gICAgaWYgKGJhdGNoYWJsZU9iamVjdC5wYWNrQXNRdWFkKSB7XG4gICAgICB0aGlzLnBhY2tRdWFkQXR0cmlidXRlcyhcbiAgICAgICAgYmF0Y2hhYmxlT2JqZWN0LFxuICAgICAgICBhdHRyaWJ1dGVCdWZmZXIuZmxvYXQzMlZpZXcsXG4gICAgICAgIGF0dHJpYnV0ZUJ1ZmZlci51aW50MzJWaWV3LFxuICAgICAgICBiYXRjaGFibGVPYmplY3QuX2F0dHJpYnV0ZVN0YXJ0LFxuICAgICAgICBiYXRjaGFibGVPYmplY3QuX3RleHR1cmVJZFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5wYWNrQXR0cmlidXRlcyhcbiAgICAgICAgYmF0Y2hhYmxlT2JqZWN0LFxuICAgICAgICBhdHRyaWJ1dGVCdWZmZXIuZmxvYXQzMlZpZXcsXG4gICAgICAgIGF0dHJpYnV0ZUJ1ZmZlci51aW50MzJWaWV3LFxuICAgICAgICBiYXRjaGFibGVPYmplY3QuX2F0dHJpYnV0ZVN0YXJ0LFxuICAgICAgICBiYXRjaGFibGVPYmplY3QuX3RleHR1cmVJZFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIGJyZWFrcyB0aGUgYmF0Y2hlci4gVGhpcyBoYXBwZW5zIHdoZW4gYSBiYXRjaCBnZXRzIHRvbyBiaWcsXG4gICAqIG9yIHdlIG5lZWQgdG8gc3dpdGNoIHRvIGEgZGlmZmVyZW50IHR5cGUgb2YgcmVuZGVyaW5nIChhIGZpbHRlciBmb3IgZXhhbXBsZSlcbiAgICogQHBhcmFtIGluc3RydWN0aW9uU2V0XG4gICAqL1xuICBicmVhayhpbnN0cnVjdGlvblNldCkge1xuICAgIGNvbnN0IGVsZW1lbnRzID0gdGhpcy5fZWxlbWVudHM7XG4gICAgaWYgKCFlbGVtZW50c1t0aGlzLmVsZW1lbnRTdGFydF0pIHJldHVybjtcbiAgICBsZXQgYmF0Y2ggPSBnZXRCYXRjaEZyb21Qb29sKCk7XG4gICAgbGV0IHRleHR1cmVCYXRjaCA9IGJhdGNoLnRleHR1cmVzO1xuICAgIHRleHR1cmVCYXRjaC5jbGVhcigpO1xuICAgIGNvbnN0IGZpcnN0RWxlbWVudCA9IGVsZW1lbnRzW3RoaXMuZWxlbWVudFN0YXJ0XTtcbiAgICBsZXQgYmxlbmRNb2RlID0gZ2V0QWRqdXN0ZWRCbGVuZE1vZGVCbGVuZChmaXJzdEVsZW1lbnQuYmxlbmRNb2RlLCBmaXJzdEVsZW1lbnQudGV4dHVyZS5fc291cmNlKTtcbiAgICBsZXQgdG9wb2xvZ3kgPSBmaXJzdEVsZW1lbnQudG9wb2xvZ3k7XG4gICAgaWYgKHRoaXMuYXR0cmlidXRlU2l6ZSAqIDQgPiB0aGlzLmF0dHJpYnV0ZUJ1ZmZlci5zaXplKSB7XG4gICAgICB0aGlzLl9yZXNpemVBdHRyaWJ1dGVCdWZmZXIodGhpcy5hdHRyaWJ1dGVTaXplICogNCk7XG4gICAgfVxuICAgIGlmICh0aGlzLmluZGV4U2l6ZSA+IHRoaXMuaW5kZXhCdWZmZXIubGVuZ3RoKSB7XG4gICAgICB0aGlzLl9yZXNpemVJbmRleEJ1ZmZlcih0aGlzLmluZGV4U2l6ZSk7XG4gICAgfVxuICAgIGNvbnN0IGYzMiA9IHRoaXMuYXR0cmlidXRlQnVmZmVyLmZsb2F0MzJWaWV3O1xuICAgIGNvbnN0IHUzMiA9IHRoaXMuYXR0cmlidXRlQnVmZmVyLnVpbnQzMlZpZXc7XG4gICAgY29uc3QgaW5kZXhCdWZmZXIgPSB0aGlzLmluZGV4QnVmZmVyO1xuICAgIGxldCBzaXplID0gdGhpcy5fYmF0Y2hJbmRleFNpemU7XG4gICAgbGV0IHN0YXJ0ID0gdGhpcy5fYmF0Y2hJbmRleFN0YXJ0O1xuICAgIGxldCBhY3Rpb24gPSBcInN0YXJ0QmF0Y2hcIjtcbiAgICBsZXQgYmF0Y2hFbGVtZW50cyA9IFtdO1xuICAgIGNvbnN0IG1heFRleHR1cmVzID0gdGhpcy5tYXhUZXh0dXJlcztcbiAgICBmb3IgKGxldCBpID0gdGhpcy5lbGVtZW50U3RhcnQ7IGkgPCB0aGlzLmVsZW1lbnRTaXplOyArK2kpIHtcbiAgICAgIGNvbnN0IGVsZW1lbnQgPSBlbGVtZW50c1tpXTtcbiAgICAgIGVsZW1lbnRzW2ldID0gbnVsbDtcbiAgICAgIGNvbnN0IHRleHR1cmUgPSBlbGVtZW50LnRleHR1cmU7XG4gICAgICBjb25zdCBzb3VyY2UgPSB0ZXh0dXJlLl9zb3VyY2U7XG4gICAgICBjb25zdCBhZGp1c3RlZEJsZW5kTW9kZSA9IGdldEFkanVzdGVkQmxlbmRNb2RlQmxlbmQoZWxlbWVudC5ibGVuZE1vZGUsIHNvdXJjZSk7XG4gICAgICBjb25zdCBicmVha1JlcXVpcmVkID0gYmxlbmRNb2RlICE9PSBhZGp1c3RlZEJsZW5kTW9kZSB8fCB0b3BvbG9neSAhPT0gZWxlbWVudC50b3BvbG9neTtcbiAgICAgIGlmIChzb3VyY2UuX2JhdGNoVGljayA9PT0gQkFUQ0hfVElDSyAmJiAhYnJlYWtSZXF1aXJlZCkge1xuICAgICAgICBlbGVtZW50Ll90ZXh0dXJlSWQgPSBzb3VyY2UuX3RleHR1cmVCaW5kTG9jYXRpb247XG4gICAgICAgIHNpemUgKz0gZWxlbWVudC5pbmRleFNpemU7XG4gICAgICAgIGlmIChlbGVtZW50LnBhY2tBc1F1YWQpIHtcbiAgICAgICAgICB0aGlzLnBhY2tRdWFkQXR0cmlidXRlcyhcbiAgICAgICAgICAgIGVsZW1lbnQsXG4gICAgICAgICAgICBmMzIsXG4gICAgICAgICAgICB1MzIsXG4gICAgICAgICAgICBlbGVtZW50Ll9hdHRyaWJ1dGVTdGFydCxcbiAgICAgICAgICAgIGVsZW1lbnQuX3RleHR1cmVJZFxuICAgICAgICAgICk7XG4gICAgICAgICAgdGhpcy5wYWNrUXVhZEluZGV4KFxuICAgICAgICAgICAgaW5kZXhCdWZmZXIsXG4gICAgICAgICAgICBlbGVtZW50Ll9pbmRleFN0YXJ0LFxuICAgICAgICAgICAgZWxlbWVudC5fYXR0cmlidXRlU3RhcnQgLyB0aGlzLnZlcnRleFNpemVcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMucGFja0F0dHJpYnV0ZXMoXG4gICAgICAgICAgICBlbGVtZW50LFxuICAgICAgICAgICAgZjMyLFxuICAgICAgICAgICAgdTMyLFxuICAgICAgICAgICAgZWxlbWVudC5fYXR0cmlidXRlU3RhcnQsXG4gICAgICAgICAgICBlbGVtZW50Ll90ZXh0dXJlSWRcbiAgICAgICAgICApO1xuICAgICAgICAgIHRoaXMucGFja0luZGV4KFxuICAgICAgICAgICAgZWxlbWVudCxcbiAgICAgICAgICAgIGluZGV4QnVmZmVyLFxuICAgICAgICAgICAgZWxlbWVudC5faW5kZXhTdGFydCxcbiAgICAgICAgICAgIGVsZW1lbnQuX2F0dHJpYnV0ZVN0YXJ0IC8gdGhpcy52ZXJ0ZXhTaXplXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBlbGVtZW50Ll9iYXRjaCA9IGJhdGNoO1xuICAgICAgICBiYXRjaEVsZW1lbnRzLnB1c2goZWxlbWVudCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgc291cmNlLl9iYXRjaFRpY2sgPSBCQVRDSF9USUNLO1xuICAgICAgaWYgKHRleHR1cmVCYXRjaC5jb3VudCA+PSBtYXhUZXh0dXJlcyB8fCBicmVha1JlcXVpcmVkKSB7XG4gICAgICAgIHRoaXMuX2ZpbmlzaEJhdGNoKFxuICAgICAgICAgIGJhdGNoLFxuICAgICAgICAgIHN0YXJ0LFxuICAgICAgICAgIHNpemUgLSBzdGFydCxcbiAgICAgICAgICB0ZXh0dXJlQmF0Y2gsXG4gICAgICAgICAgYmxlbmRNb2RlLFxuICAgICAgICAgIHRvcG9sb2d5LFxuICAgICAgICAgIGluc3RydWN0aW9uU2V0LFxuICAgICAgICAgIGFjdGlvbixcbiAgICAgICAgICBiYXRjaEVsZW1lbnRzXG4gICAgICAgICk7XG4gICAgICAgIGFjdGlvbiA9IFwicmVuZGVyQmF0Y2hcIjtcbiAgICAgICAgc3RhcnQgPSBzaXplO1xuICAgICAgICBibGVuZE1vZGUgPSBhZGp1c3RlZEJsZW5kTW9kZTtcbiAgICAgICAgdG9wb2xvZ3kgPSBlbGVtZW50LnRvcG9sb2d5O1xuICAgICAgICBiYXRjaCA9IGdldEJhdGNoRnJvbVBvb2woKTtcbiAgICAgICAgdGV4dHVyZUJhdGNoID0gYmF0Y2gudGV4dHVyZXM7XG4gICAgICAgIHRleHR1cmVCYXRjaC5jbGVhcigpO1xuICAgICAgICBiYXRjaEVsZW1lbnRzID0gW107XG4gICAgICAgICsrQkFUQ0hfVElDSztcbiAgICAgIH1cbiAgICAgIGVsZW1lbnQuX3RleHR1cmVJZCA9IHNvdXJjZS5fdGV4dHVyZUJpbmRMb2NhdGlvbiA9IHRleHR1cmVCYXRjaC5jb3VudDtcbiAgICAgIHRleHR1cmVCYXRjaC5pZHNbc291cmNlLnVpZF0gPSB0ZXh0dXJlQmF0Y2guY291bnQ7XG4gICAgICB0ZXh0dXJlQmF0Y2gudGV4dHVyZXNbdGV4dHVyZUJhdGNoLmNvdW50KytdID0gc291cmNlO1xuICAgICAgZWxlbWVudC5fYmF0Y2ggPSBiYXRjaDtcbiAgICAgIGJhdGNoRWxlbWVudHMucHVzaChlbGVtZW50KTtcbiAgICAgIHNpemUgKz0gZWxlbWVudC5pbmRleFNpemU7XG4gICAgICBpZiAoZWxlbWVudC5wYWNrQXNRdWFkKSB7XG4gICAgICAgIHRoaXMucGFja1F1YWRBdHRyaWJ1dGVzKFxuICAgICAgICAgIGVsZW1lbnQsXG4gICAgICAgICAgZjMyLFxuICAgICAgICAgIHUzMixcbiAgICAgICAgICBlbGVtZW50Ll9hdHRyaWJ1dGVTdGFydCxcbiAgICAgICAgICBlbGVtZW50Ll90ZXh0dXJlSWRcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5wYWNrUXVhZEluZGV4KFxuICAgICAgICAgIGluZGV4QnVmZmVyLFxuICAgICAgICAgIGVsZW1lbnQuX2luZGV4U3RhcnQsXG4gICAgICAgICAgZWxlbWVudC5fYXR0cmlidXRlU3RhcnQgLyB0aGlzLnZlcnRleFNpemVcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMucGFja0F0dHJpYnV0ZXMoXG4gICAgICAgICAgZWxlbWVudCxcbiAgICAgICAgICBmMzIsXG4gICAgICAgICAgdTMyLFxuICAgICAgICAgIGVsZW1lbnQuX2F0dHJpYnV0ZVN0YXJ0LFxuICAgICAgICAgIGVsZW1lbnQuX3RleHR1cmVJZFxuICAgICAgICApO1xuICAgICAgICB0aGlzLnBhY2tJbmRleChcbiAgICAgICAgICBlbGVtZW50LFxuICAgICAgICAgIGluZGV4QnVmZmVyLFxuICAgICAgICAgIGVsZW1lbnQuX2luZGV4U3RhcnQsXG4gICAgICAgICAgZWxlbWVudC5fYXR0cmlidXRlU3RhcnQgLyB0aGlzLnZlcnRleFNpemVcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHRleHR1cmVCYXRjaC5jb3VudCA+IDApIHtcbiAgICAgIHRoaXMuX2ZpbmlzaEJhdGNoKFxuICAgICAgICBiYXRjaCxcbiAgICAgICAgc3RhcnQsXG4gICAgICAgIHNpemUgLSBzdGFydCxcbiAgICAgICAgdGV4dHVyZUJhdGNoLFxuICAgICAgICBibGVuZE1vZGUsXG4gICAgICAgIHRvcG9sb2d5LFxuICAgICAgICBpbnN0cnVjdGlvblNldCxcbiAgICAgICAgYWN0aW9uLFxuICAgICAgICBiYXRjaEVsZW1lbnRzXG4gICAgICApO1xuICAgICAgc3RhcnQgPSBzaXplO1xuICAgICAgKytCQVRDSF9USUNLO1xuICAgIH1cbiAgICB0aGlzLmVsZW1lbnRTdGFydCA9IHRoaXMuZWxlbWVudFNpemU7XG4gICAgdGhpcy5fYmF0Y2hJbmRleFN0YXJ0ID0gc3RhcnQ7XG4gICAgdGhpcy5fYmF0Y2hJbmRleFNpemUgPSBzaXplO1xuICB9XG4gIF9maW5pc2hCYXRjaChiYXRjaCwgaW5kZXhTdGFydCwgaW5kZXhTaXplLCB0ZXh0dXJlQmF0Y2gsIGJsZW5kTW9kZSwgdG9wb2xvZ3ksIGluc3RydWN0aW9uU2V0LCBhY3Rpb24sIGVsZW1lbnRzKSB7XG4gICAgYmF0Y2guZ3B1QmluZEdyb3VwID0gbnVsbDtcbiAgICBiYXRjaC5iaW5kR3JvdXAgPSBudWxsO1xuICAgIGJhdGNoLmFjdGlvbiA9IGFjdGlvbjtcbiAgICBiYXRjaC5iYXRjaGVyID0gdGhpcztcbiAgICBiYXRjaC50ZXh0dXJlcyA9IHRleHR1cmVCYXRjaDtcbiAgICBiYXRjaC5ibGVuZE1vZGUgPSBibGVuZE1vZGU7XG4gICAgYmF0Y2gudG9wb2xvZ3kgPSB0b3BvbG9neTtcbiAgICBiYXRjaC5zdGFydCA9IGluZGV4U3RhcnQ7XG4gICAgYmF0Y2guc2l6ZSA9IGluZGV4U2l6ZTtcbiAgICBiYXRjaC5lbGVtZW50cyA9IGVsZW1lbnRzO1xuICAgICsrQkFUQ0hfVElDSztcbiAgICB0aGlzLmJhdGNoZXNbdGhpcy5iYXRjaEluZGV4KytdID0gYmF0Y2g7XG4gICAgaW5zdHJ1Y3Rpb25TZXQuYWRkKGJhdGNoKTtcbiAgfVxuICBmaW5pc2goaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICB0aGlzLmJyZWFrKGluc3RydWN0aW9uU2V0KTtcbiAgfVxuICAvKipcbiAgICogUmVzaXplcyB0aGUgYXR0cmlidXRlIGJ1ZmZlciB0byB0aGUgZ2l2ZW4gc2l6ZSAoMSA9IDEgZmxvYXQzMilcbiAgICogQHBhcmFtIHNpemUgLSB0aGUgc2l6ZSBpbiB2ZXJ0aWNlcyB0byBlbnN1cmUgKG5vdCBieXRlcyEpXG4gICAqL1xuICBlbnN1cmVBdHRyaWJ1dGVCdWZmZXIoc2l6ZSkge1xuICAgIGlmIChzaXplICogNCA8PSB0aGlzLmF0dHJpYnV0ZUJ1ZmZlci5zaXplKSByZXR1cm47XG4gICAgdGhpcy5fcmVzaXplQXR0cmlidXRlQnVmZmVyKHNpemUgKiA0KTtcbiAgfVxuICAvKipcbiAgICogUmVzaXplcyB0aGUgaW5kZXggYnVmZmVyIHRvIHRoZSBnaXZlbiBzaXplICgxID0gMSBmbG9hdDMyKVxuICAgKiBAcGFyYW0gc2l6ZSAtIHRoZSBzaXplIGluIHZlcnRpY2VzIHRvIGVuc3VyZSAobm90IGJ5dGVzISlcbiAgICovXG4gIGVuc3VyZUluZGV4QnVmZmVyKHNpemUpIHtcbiAgICBpZiAoc2l6ZSA8PSB0aGlzLmluZGV4QnVmZmVyLmxlbmd0aCkgcmV0dXJuO1xuICAgIHRoaXMuX3Jlc2l6ZUluZGV4QnVmZmVyKHNpemUpO1xuICB9XG4gIF9yZXNpemVBdHRyaWJ1dGVCdWZmZXIoc2l6ZSkge1xuICAgIGNvbnN0IG5ld1NpemUgPSBNYXRoLm1heChzaXplLCB0aGlzLmF0dHJpYnV0ZUJ1ZmZlci5zaXplICogMik7XG4gICAgY29uc3QgbmV3QXJyYXlCdWZmZXIgPSBuZXcgVmlld2FibGVCdWZmZXIobmV3U2l6ZSk7XG4gICAgZmFzdENvcHkodGhpcy5hdHRyaWJ1dGVCdWZmZXIucmF3QmluYXJ5RGF0YSwgbmV3QXJyYXlCdWZmZXIucmF3QmluYXJ5RGF0YSk7XG4gICAgdGhpcy5hdHRyaWJ1dGVCdWZmZXIgPSBuZXdBcnJheUJ1ZmZlcjtcbiAgfVxuICBfcmVzaXplSW5kZXhCdWZmZXIoc2l6ZSkge1xuICAgIGNvbnN0IGluZGV4QnVmZmVyID0gdGhpcy5pbmRleEJ1ZmZlcjtcbiAgICBsZXQgbmV3U2l6ZSA9IE1hdGgubWF4KHNpemUsIGluZGV4QnVmZmVyLmxlbmd0aCAqIDEuNSk7XG4gICAgbmV3U2l6ZSArPSBuZXdTaXplICUgMjtcbiAgICBjb25zdCBuZXdJbmRleEJ1ZmZlciA9IG5ld1NpemUgPiA2NTUzNSA/IG5ldyBVaW50MzJBcnJheShuZXdTaXplKSA6IG5ldyBVaW50MTZBcnJheShuZXdTaXplKTtcbiAgICBpZiAobmV3SW5kZXhCdWZmZXIuQllURVNfUEVSX0VMRU1FTlQgIT09IGluZGV4QnVmZmVyLkJZVEVTX1BFUl9FTEVNRU5UKSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGluZGV4QnVmZmVyLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIG5ld0luZGV4QnVmZmVyW2ldID0gaW5kZXhCdWZmZXJbaV07XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGZhc3RDb3B5KGluZGV4QnVmZmVyLmJ1ZmZlciwgbmV3SW5kZXhCdWZmZXIuYnVmZmVyKTtcbiAgICB9XG4gICAgdGhpcy5pbmRleEJ1ZmZlciA9IG5ld0luZGV4QnVmZmVyO1xuICB9XG4gIHBhY2tRdWFkSW5kZXgoaW5kZXhCdWZmZXIsIGluZGV4LCBpbmRpY2VzT2Zmc2V0KSB7XG4gICAgaW5kZXhCdWZmZXJbaW5kZXhdID0gaW5kaWNlc09mZnNldCArIDA7XG4gICAgaW5kZXhCdWZmZXJbaW5kZXggKyAxXSA9IGluZGljZXNPZmZzZXQgKyAxO1xuICAgIGluZGV4QnVmZmVyW2luZGV4ICsgMl0gPSBpbmRpY2VzT2Zmc2V0ICsgMjtcbiAgICBpbmRleEJ1ZmZlcltpbmRleCArIDNdID0gaW5kaWNlc09mZnNldCArIDA7XG4gICAgaW5kZXhCdWZmZXJbaW5kZXggKyA0XSA9IGluZGljZXNPZmZzZXQgKyAyO1xuICAgIGluZGV4QnVmZmVyW2luZGV4ICsgNV0gPSBpbmRpY2VzT2Zmc2V0ICsgMztcbiAgfVxuICBwYWNrSW5kZXgoZWxlbWVudCwgaW5kZXhCdWZmZXIsIGluZGV4LCBpbmRpY2VzT2Zmc2V0KSB7XG4gICAgY29uc3QgaW5kaWNlcyA9IGVsZW1lbnQuaW5kaWNlcztcbiAgICBjb25zdCBzaXplID0gZWxlbWVudC5pbmRleFNpemU7XG4gICAgY29uc3QgaW5kZXhPZmZzZXQgPSBlbGVtZW50LmluZGV4T2Zmc2V0O1xuICAgIGNvbnN0IGF0dHJpYnV0ZU9mZnNldCA9IGVsZW1lbnQuYXR0cmlidXRlT2Zmc2V0O1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2l6ZTsgaSsrKSB7XG4gICAgICBpbmRleEJ1ZmZlcltpbmRleCsrXSA9IGluZGljZXNPZmZzZXQgKyBpbmRpY2VzW2kgKyBpbmRleE9mZnNldF0gLSBhdHRyaWJ1dGVPZmZzZXQ7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBEZXN0cm95cyB0aGUgYmF0Y2ggYW5kIGl0cyByZXNvdXJjZXMuXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gZGVzdHJ1Y3Rpb24gb3B0aW9uc1xuICAgKiBAcGFyYW0gb3B0aW9ucy5zaGFkZXIgLSB3aGV0aGVyIHRvIGRlc3Ryb3kgdGhlIGFzc29jaWF0ZWQgc2hhZGVyXG4gICAqL1xuICBkZXN0cm95KG9wdGlvbnMgPSB7fSkge1xuICAgIGlmICh0aGlzLmJhdGNoZXMgPT09IG51bGwpIHJldHVybjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuYmF0Y2hJbmRleDsgaSsrKSB7XG4gICAgICByZXR1cm5CYXRjaFRvUG9vbCh0aGlzLmJhdGNoZXNbaV0pO1xuICAgIH1cbiAgICB0aGlzLmJhdGNoZXMgPSBudWxsO1xuICAgIHRoaXMuZ2VvbWV0cnkuZGVzdHJveSh0cnVlKTtcbiAgICB0aGlzLmdlb21ldHJ5ID0gbnVsbDtcbiAgICBpZiAob3B0aW9ucy5zaGFkZXIpIHtcbiAgICAgIHRoaXMuc2hhZGVyPy5kZXN0cm95KCk7XG4gICAgICB0aGlzLnNoYWRlciA9IG51bGw7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5fZWxlbWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmICh0aGlzLl9lbGVtZW50c1tpXSkgdGhpcy5fZWxlbWVudHNbaV0uX2JhdGNoID0gbnVsbDtcbiAgICB9XG4gICAgdGhpcy5fZWxlbWVudHMgPSBudWxsO1xuICAgIHRoaXMuaW5kZXhCdWZmZXIgPSBudWxsO1xuICAgIHRoaXMuYXR0cmlidXRlQnVmZmVyLmRlc3Ryb3koKTtcbiAgICB0aGlzLmF0dHJpYnV0ZUJ1ZmZlciA9IG51bGw7XG4gIH1cbn07XG5fQmF0Y2hlci5kZWZhdWx0T3B0aW9ucyA9IHtcbiAgbWF4VGV4dHVyZXM6IG51bGwsXG4gIGF0dHJpYnV0ZXNJbml0aWFsU2l6ZTogNCxcbiAgaW5kaWNlc0luaXRpYWxTaXplOiA2XG59O1xubGV0IEJhdGNoZXIgPSBfQmF0Y2hlcjtcblxuZXhwb3J0IHsgQmF0Y2gsIEJhdGNoZXIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUJhdGNoZXIubWpzLm1hcFxuIiwiaW1wb3J0IHsgQnVmZmVyIH0gZnJvbSAnLi4vLi4vcmVuZGVyZXJzL3NoYXJlZC9idWZmZXIvQnVmZmVyLm1qcyc7XG5pbXBvcnQgeyBCdWZmZXJVc2FnZSB9IGZyb20gJy4uLy4uL3JlbmRlcmVycy9zaGFyZWQvYnVmZmVyL2NvbnN0Lm1qcyc7XG5pbXBvcnQgeyBHZW9tZXRyeSB9IGZyb20gJy4uLy4uL3JlbmRlcmVycy9zaGFyZWQvZ2VvbWV0cnkvR2VvbWV0cnkubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBwbGFjZUhvbGRlckJ1ZmZlckRhdGEgPSBuZXcgRmxvYXQzMkFycmF5KDEpO1xuY29uc3QgcGxhY2VIb2xkZXJJbmRleERhdGEgPSBuZXcgVWludDMyQXJyYXkoMSk7XG5jbGFzcyBCYXRjaEdlb21ldHJ5IGV4dGVuZHMgR2VvbWV0cnkge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBjb25zdCB2ZXJ0ZXhTaXplID0gNjtcbiAgICBjb25zdCBhdHRyaWJ1dGVCdWZmZXIgPSBuZXcgQnVmZmVyKHtcbiAgICAgIGRhdGE6IHBsYWNlSG9sZGVyQnVmZmVyRGF0YSxcbiAgICAgIGxhYmVsOiBcImF0dHJpYnV0ZS1iYXRjaC1idWZmZXJcIixcbiAgICAgIHVzYWdlOiBCdWZmZXJVc2FnZS5WRVJURVggfCBCdWZmZXJVc2FnZS5DT1BZX0RTVCxcbiAgICAgIHNocmlua1RvRml0OiBmYWxzZVxuICAgIH0pO1xuICAgIGNvbnN0IGluZGV4QnVmZmVyID0gbmV3IEJ1ZmZlcih7XG4gICAgICBkYXRhOiBwbGFjZUhvbGRlckluZGV4RGF0YSxcbiAgICAgIGxhYmVsOiBcImluZGV4LWJhdGNoLWJ1ZmZlclwiLFxuICAgICAgdXNhZ2U6IEJ1ZmZlclVzYWdlLklOREVYIHwgQnVmZmVyVXNhZ2UuQ09QWV9EU1QsXG4gICAgICAvLyB8IEJ1ZmZlclVzYWdlLlNUQVRJQyxcbiAgICAgIHNocmlua1RvRml0OiBmYWxzZVxuICAgIH0pO1xuICAgIGNvbnN0IHN0cmlkZSA9IHZlcnRleFNpemUgKiA0O1xuICAgIHN1cGVyKHtcbiAgICAgIGF0dHJpYnV0ZXM6IHtcbiAgICAgICAgYVBvc2l0aW9uOiB7XG4gICAgICAgICAgYnVmZmVyOiBhdHRyaWJ1dGVCdWZmZXIsXG4gICAgICAgICAgZm9ybWF0OiBcImZsb2F0MzJ4MlwiLFxuICAgICAgICAgIHN0cmlkZSxcbiAgICAgICAgICBvZmZzZXQ6IDBcbiAgICAgICAgfSxcbiAgICAgICAgYVVWOiB7XG4gICAgICAgICAgYnVmZmVyOiBhdHRyaWJ1dGVCdWZmZXIsXG4gICAgICAgICAgZm9ybWF0OiBcImZsb2F0MzJ4MlwiLFxuICAgICAgICAgIHN0cmlkZSxcbiAgICAgICAgICBvZmZzZXQ6IDIgKiA0XG4gICAgICAgIH0sXG4gICAgICAgIGFDb2xvcjoge1xuICAgICAgICAgIGJ1ZmZlcjogYXR0cmlidXRlQnVmZmVyLFxuICAgICAgICAgIGZvcm1hdDogXCJ1bm9ybTh4NFwiLFxuICAgICAgICAgIHN0cmlkZSxcbiAgICAgICAgICBvZmZzZXQ6IDQgKiA0XG4gICAgICAgIH0sXG4gICAgICAgIGFUZXh0dXJlSWRBbmRSb3VuZDoge1xuICAgICAgICAgIGJ1ZmZlcjogYXR0cmlidXRlQnVmZmVyLFxuICAgICAgICAgIGZvcm1hdDogXCJ1aW50MTZ4MlwiLFxuICAgICAgICAgIHN0cmlkZSxcbiAgICAgICAgICBvZmZzZXQ6IDUgKiA0XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBpbmRleEJ1ZmZlclxuICAgIH0pO1xuICB9XG59XG5cbmV4cG9ydCB7IEJhdGNoR2VvbWV0cnkgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUJhdGNoR2VvbWV0cnkubWpzLm1hcFxuIiwiaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2xvZ2dpbmcvd2Fybi5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGFkZEJpdHMoc3JjUGFydHMsIHBhcnRzLCBuYW1lKSB7XG4gIGlmIChzcmNQYXJ0cykge1xuICAgIGZvciAoY29uc3QgaSBpbiBzcmNQYXJ0cykge1xuICAgICAgY29uc3QgaWQgPSBpLnRvTG9jYWxlTG93ZXJDYXNlKCk7XG4gICAgICBjb25zdCBwYXJ0ID0gcGFydHNbaWRdO1xuICAgICAgaWYgKHBhcnQpIHtcbiAgICAgICAgbGV0IHNhbml0aXNlZFBhcnQgPSBzcmNQYXJ0c1tpXTtcbiAgICAgICAgaWYgKGkgPT09IFwiaGVhZGVyXCIpIHtcbiAgICAgICAgICBzYW5pdGlzZWRQYXJ0ID0gc2FuaXRpc2VkUGFydC5yZXBsYWNlKC9AaW5cXHMrW147XSs7XFxzKi9nLCBcIlwiKS5yZXBsYWNlKC9Ab3V0XFxzK1teO10rO1xccyovZywgXCJcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG5hbWUpIHtcbiAgICAgICAgICBwYXJ0LnB1c2goYC8vLS0tLSR7bmFtZX0tLS0tLy9gKTtcbiAgICAgICAgfVxuICAgICAgICBwYXJ0LnB1c2goc2FuaXRpc2VkUGFydCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB3YXJuKGAke2l9IHBsYWNlbWVudCBob29rIGRvZXMgbm90IGV4aXN0IGluIHNoYWRlcmApO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgeyBhZGRCaXRzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1hZGRCaXRzLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY29uc3QgZmluZEhvb2tzUnggPSAvXFx7XFx7KC4qPylcXH1cXH0vZztcbmZ1bmN0aW9uIGNvbXBpbGVIb29rcyhwcm9ncmFtU3JjKSB7XG4gIGNvbnN0IHBhcnRzID0ge307XG4gIGNvbnN0IHBhcnRNYXRjaGVzID0gcHJvZ3JhbVNyYy5tYXRjaChmaW5kSG9va3NSeCk/Lm1hcCgoaG9vaykgPT4gaG9vay5yZXBsYWNlKC9beygpfV0vZywgXCJcIikpID8/IFtdO1xuICBwYXJ0TWF0Y2hlcy5mb3JFYWNoKChob29rKSA9PiB7XG4gICAgcGFydHNbaG9va10gPSBbXTtcbiAgfSk7XG4gIHJldHVybiBwYXJ0cztcbn1cblxuZXhwb3J0IHsgY29tcGlsZUhvb2tzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb21waWxlSG9va3MubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBleHRyYWN0SW5wdXRzKGZyYWdtZW50U291cmNlLCBvdXQpIHtcbiAgbGV0IG1hdGNoO1xuICBjb25zdCByZWdleCA9IC9AaW5cXHMrKFteO10rKTsvZztcbiAgd2hpbGUgKChtYXRjaCA9IHJlZ2V4LmV4ZWMoZnJhZ21lbnRTb3VyY2UpKSAhPT0gbnVsbCkge1xuICAgIG91dC5wdXNoKG1hdGNoWzFdKTtcbiAgfVxufVxuZnVuY3Rpb24gY29tcGlsZUlucHV0cyhmcmFnbWVudHMsIHRlbXBsYXRlLCBzb3J0ID0gZmFsc2UpIHtcbiAgY29uc3QgcmVzdWx0cyA9IFtdO1xuICBleHRyYWN0SW5wdXRzKHRlbXBsYXRlLCByZXN1bHRzKTtcbiAgZnJhZ21lbnRzLmZvckVhY2goKGZyYWdtZW50KSA9PiB7XG4gICAgaWYgKGZyYWdtZW50LmhlYWRlcikge1xuICAgICAgZXh0cmFjdElucHV0cyhmcmFnbWVudC5oZWFkZXIsIHJlc3VsdHMpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IG1haW5JbnB1dCA9IHJlc3VsdHM7XG4gIGlmIChzb3J0KSB7XG4gICAgbWFpbklucHV0LnNvcnQoKTtcbiAgfVxuICBjb25zdCBmaW5hbFN0cmluZyA9IG1haW5JbnB1dC5tYXAoKGluVmFsdWUsIGkpID0+IGAgICAgICAgQGxvY2F0aW9uKCR7aX0pICR7aW5WYWx1ZX0sYCkuam9pbihcIlxcblwiKTtcbiAgbGV0IGNsZWFuZWRTdHJpbmcgPSB0ZW1wbGF0ZS5yZXBsYWNlKC9AaW5cXHMrW147XSs7XFxzKi9nLCBcIlwiKTtcbiAgY2xlYW5lZFN0cmluZyA9IGNsZWFuZWRTdHJpbmcucmVwbGFjZShcInt7aW59fVwiLCBgXG4ke2ZpbmFsU3RyaW5nfVxuYCk7XG4gIHJldHVybiBjbGVhbmVkU3RyaW5nO1xufVxuXG5leHBvcnQgeyBjb21waWxlSW5wdXRzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb21waWxlSW5wdXRzLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gZXh0cmFjdE91dHB1dHMoZnJhZ21lbnRTb3VyY2UsIG91dCkge1xuICBsZXQgbWF0Y2g7XG4gIGNvbnN0IHJlZ2V4ID0gL0BvdXRcXHMrKFteO10rKTsvZztcbiAgd2hpbGUgKChtYXRjaCA9IHJlZ2V4LmV4ZWMoZnJhZ21lbnRTb3VyY2UpKSAhPT0gbnVsbCkge1xuICAgIG91dC5wdXNoKG1hdGNoWzFdKTtcbiAgfVxufVxuZnVuY3Rpb24gZXh0cmFjdFZhcmlhYmxlTmFtZSh2YWx1ZSkge1xuICBjb25zdCByZWdleCA9IC9cXGIoXFx3KylcXHMqOi9nO1xuICBjb25zdCBtYXRjaCA9IHJlZ2V4LmV4ZWModmFsdWUpO1xuICByZXR1cm4gbWF0Y2ggPyBtYXRjaFsxXSA6IFwiXCI7XG59XG5mdW5jdGlvbiBzdHJpcFZhcmlhYmxlKHZhbHVlKSB7XG4gIGNvbnN0IHJlZ2V4ID0gL0AuKj9cXHMrL2c7XG4gIHJldHVybiB2YWx1ZS5yZXBsYWNlKHJlZ2V4LCBcIlwiKTtcbn1cbmZ1bmN0aW9uIGNvbXBpbGVPdXRwdXRzKGZyYWdtZW50cywgdGVtcGxhdGUpIHtcbiAgY29uc3QgcmVzdWx0cyA9IFtdO1xuICBleHRyYWN0T3V0cHV0cyh0ZW1wbGF0ZSwgcmVzdWx0cyk7XG4gIGZyYWdtZW50cy5mb3JFYWNoKChmcmFnbWVudCkgPT4ge1xuICAgIGlmIChmcmFnbWVudC5oZWFkZXIpIHtcbiAgICAgIGV4dHJhY3RPdXRwdXRzKGZyYWdtZW50LmhlYWRlciwgcmVzdWx0cyk7XG4gICAgfVxuICB9KTtcbiAgbGV0IGluZGV4ID0gMDtcbiAgY29uc3QgbWFpblN0cnVjdCA9IHJlc3VsdHMuc29ydCgpLm1hcCgoaW5WYWx1ZSkgPT4ge1xuICAgIGlmIChpblZhbHVlLmluZGV4T2YoXCJidWlsdGluXCIpID4gLTEpIHtcbiAgICAgIHJldHVybiBpblZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gYEBsb2NhdGlvbigke2luZGV4Kyt9KSAke2luVmFsdWV9YDtcbiAgfSkuam9pbihcIixcXG5cIik7XG4gIGNvbnN0IG1haW5TdGFydCA9IHJlc3VsdHMuc29ydCgpLm1hcCgoaW5WYWx1ZSkgPT4gYCAgICAgICB2YXIgJHtzdHJpcFZhcmlhYmxlKGluVmFsdWUpfTtgKS5qb2luKFwiXFxuXCIpO1xuICBjb25zdCBtYWluRW5kID0gYHJldHVybiBWU091dHB1dChcbiAgICAgICAgICAgICR7cmVzdWx0cy5zb3J0KCkubWFwKChpblZhbHVlKSA9PiBgICR7ZXh0cmFjdFZhcmlhYmxlTmFtZShpblZhbHVlKX1gKS5qb2luKFwiLFxcblwiKX0pO2A7XG4gIGxldCBjb21waWxlZENvZGUgPSB0ZW1wbGF0ZS5yZXBsYWNlKC9Ab3V0XFxzK1teO10rO1xccyovZywgXCJcIik7XG4gIGNvbXBpbGVkQ29kZSA9IGNvbXBpbGVkQ29kZS5yZXBsYWNlKFwie3tzdHJ1Y3R9fVwiLCBgXG4ke21haW5TdHJ1Y3R9XG5gKTtcbiAgY29tcGlsZWRDb2RlID0gY29tcGlsZWRDb2RlLnJlcGxhY2UoXCJ7e3N0YXJ0fX1cIiwgYFxuJHttYWluU3RhcnR9XG5gKTtcbiAgY29tcGlsZWRDb2RlID0gY29tcGlsZWRDb2RlLnJlcGxhY2UoXCJ7e3JldHVybn19XCIsIGBcbiR7bWFpbkVuZH1cbmApO1xuICByZXR1cm4gY29tcGlsZWRDb2RlO1xufVxuXG5leHBvcnQgeyBjb21waWxlT3V0cHV0cyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29tcGlsZU91dHB1dHMubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBpbmplY3RCaXRzKHRlbXBsYXRlU3JjLCBmcmFnbWVudFBhcnRzKSB7XG4gIGxldCBvdXQgPSB0ZW1wbGF0ZVNyYztcbiAgZm9yIChjb25zdCBpIGluIGZyYWdtZW50UGFydHMpIHtcbiAgICBjb25zdCBwYXJ0cyA9IGZyYWdtZW50UGFydHNbaV07XG4gICAgY29uc3QgdG9JbmplY3QgPSBwYXJ0cy5qb2luKFwiXFxuXCIpO1xuICAgIGlmICh0b0luamVjdC5sZW5ndGgpIHtcbiAgICAgIG91dCA9IG91dC5yZXBsYWNlKGB7eyR7aX19fWAsIGAvLy0tLS0tJHtpfSBTVEFSVC0tLS0tLy9cbiR7cGFydHMuam9pbihcIlxcblwiKX1cbi8vLS0tLSR7aX0gRklOSVNILS0tLS8vYCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG91dCA9IG91dC5yZXBsYWNlKGB7eyR7aX19fWAsIFwiXCIpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5leHBvcnQgeyBpbmplY3RCaXRzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmplY3RCaXRzLm1qcy5tYXBcbiIsImltcG9ydCB7IGFkZEJpdHMgfSBmcm9tICcuL3V0aWxzL2FkZEJpdHMubWpzJztcbmltcG9ydCB7IGNvbXBpbGVIb29rcyB9IGZyb20gJy4vdXRpbHMvY29tcGlsZUhvb2tzLm1qcyc7XG5pbXBvcnQgeyBjb21waWxlSW5wdXRzIH0gZnJvbSAnLi91dGlscy9jb21waWxlSW5wdXRzLm1qcyc7XG5pbXBvcnQgeyBjb21waWxlT3V0cHV0cyB9IGZyb20gJy4vdXRpbHMvY29tcGlsZU91dHB1dHMubWpzJztcbmltcG9ydCB7IGluamVjdEJpdHMgfSBmcm9tICcuL3V0aWxzL2luamVjdEJpdHMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBjYWNoZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuY29uc3QgYml0Q2FjaGVNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xubGV0IENBQ0hFX1VJRCA9IDA7XG5mdW5jdGlvbiBjb21waWxlSGlnaFNoYWRlcih7XG4gIHRlbXBsYXRlLFxuICBiaXRzXG59KSB7XG4gIGNvbnN0IGNhY2hlSWQgPSBnZW5lcmF0ZUNhY2hlSWQodGVtcGxhdGUsIGJpdHMpO1xuICBpZiAoY2FjaGVNYXBbY2FjaGVJZF0pIHJldHVybiBjYWNoZU1hcFtjYWNoZUlkXTtcbiAgY29uc3QgeyB2ZXJ0ZXgsIGZyYWdtZW50IH0gPSBjb21waWxlSW5wdXRzQW5kT3V0cHV0cyh0ZW1wbGF0ZSwgYml0cyk7XG4gIGNhY2hlTWFwW2NhY2hlSWRdID0gY29tcGlsZUJpdHModmVydGV4LCBmcmFnbWVudCwgYml0cyk7XG4gIHJldHVybiBjYWNoZU1hcFtjYWNoZUlkXTtcbn1cbmZ1bmN0aW9uIGNvbXBpbGVIaWdoU2hhZGVyR2woe1xuICB0ZW1wbGF0ZSxcbiAgYml0c1xufSkge1xuICBjb25zdCBjYWNoZUlkID0gZ2VuZXJhdGVDYWNoZUlkKHRlbXBsYXRlLCBiaXRzKTtcbiAgaWYgKGNhY2hlTWFwW2NhY2hlSWRdKSByZXR1cm4gY2FjaGVNYXBbY2FjaGVJZF07XG4gIGNhY2hlTWFwW2NhY2hlSWRdID0gY29tcGlsZUJpdHModGVtcGxhdGUudmVydGV4LCB0ZW1wbGF0ZS5mcmFnbWVudCwgYml0cyk7XG4gIHJldHVybiBjYWNoZU1hcFtjYWNoZUlkXTtcbn1cbmZ1bmN0aW9uIGNvbXBpbGVJbnB1dHNBbmRPdXRwdXRzKHRlbXBsYXRlLCBiaXRzKSB7XG4gIGNvbnN0IHZlcnRleEZyYWdtZW50cyA9IGJpdHMubWFwKChzaGFkZXJCaXQpID0+IHNoYWRlckJpdC52ZXJ0ZXgpLmZpbHRlcigodikgPT4gISF2KTtcbiAgY29uc3QgZnJhZ21lbnRGcmFnbWVudHMgPSBiaXRzLm1hcCgoc2hhZGVyQml0KSA9PiBzaGFkZXJCaXQuZnJhZ21lbnQpLmZpbHRlcigodikgPT4gISF2KTtcbiAgbGV0IGNvbXBpbGVkVmVydGV4ID0gY29tcGlsZUlucHV0cyh2ZXJ0ZXhGcmFnbWVudHMsIHRlbXBsYXRlLnZlcnRleCwgdHJ1ZSk7XG4gIGNvbXBpbGVkVmVydGV4ID0gY29tcGlsZU91dHB1dHModmVydGV4RnJhZ21lbnRzLCBjb21waWxlZFZlcnRleCk7XG4gIGNvbnN0IGNvbXBpbGVkRnJhZ21lbnQgPSBjb21waWxlSW5wdXRzKGZyYWdtZW50RnJhZ21lbnRzLCB0ZW1wbGF0ZS5mcmFnbWVudCwgdHJ1ZSk7XG4gIHJldHVybiB7XG4gICAgdmVydGV4OiBjb21waWxlZFZlcnRleCxcbiAgICBmcmFnbWVudDogY29tcGlsZWRGcmFnbWVudFxuICB9O1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVDYWNoZUlkKHRlbXBsYXRlLCBiaXRzKSB7XG4gIHJldHVybiBiaXRzLm1hcCgoaGlnaEZyYWdtZW50KSA9PiB7XG4gICAgaWYgKCFiaXRDYWNoZU1hcC5oYXMoaGlnaEZyYWdtZW50KSkge1xuICAgICAgYml0Q2FjaGVNYXAuc2V0KGhpZ2hGcmFnbWVudCwgQ0FDSEVfVUlEKyspO1xuICAgIH1cbiAgICByZXR1cm4gYml0Q2FjaGVNYXAuZ2V0KGhpZ2hGcmFnbWVudCk7XG4gIH0pLnNvcnQoKGEsIGIpID0+IGEgLSBiKS5qb2luKFwiLVwiKSArIHRlbXBsYXRlLnZlcnRleCArIHRlbXBsYXRlLmZyYWdtZW50O1xufVxuZnVuY3Rpb24gY29tcGlsZUJpdHModmVydGV4LCBmcmFnbWVudCwgYml0cykge1xuICBjb25zdCB2ZXJ0ZXhQYXJ0cyA9IGNvbXBpbGVIb29rcyh2ZXJ0ZXgpO1xuICBjb25zdCBmcmFnbWVudFBhcnRzID0gY29tcGlsZUhvb2tzKGZyYWdtZW50KTtcbiAgYml0cy5mb3JFYWNoKChzaGFkZXJCaXQpID0+IHtcbiAgICBhZGRCaXRzKHNoYWRlckJpdC52ZXJ0ZXgsIHZlcnRleFBhcnRzLCBzaGFkZXJCaXQubmFtZSk7XG4gICAgYWRkQml0cyhzaGFkZXJCaXQuZnJhZ21lbnQsIGZyYWdtZW50UGFydHMsIHNoYWRlckJpdC5uYW1lKTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgdmVydGV4OiBpbmplY3RCaXRzKHZlcnRleCwgdmVydGV4UGFydHMpLFxuICAgIGZyYWdtZW50OiBpbmplY3RCaXRzKGZyYWdtZW50LCBmcmFnbWVudFBhcnRzKVxuICB9O1xufVxuXG5leHBvcnQgeyBjb21waWxlSGlnaFNoYWRlciwgY29tcGlsZUhpZ2hTaGFkZXJHbCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29tcGlsZUhpZ2hTaGFkZXIubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCB2ZXJ0ZXhHUFVUZW1wbGF0ZSA9IChcbiAgLyogd2dzbCAqL1xuICBgXG4gICAgQGluIGFQb3NpdGlvbjogdmVjMjxmMzI+O1xuICAgIEBpbiBhVVY6IHZlYzI8ZjMyPjtcblxuICAgIEBvdXQgQGJ1aWx0aW4ocG9zaXRpb24pIHZQb3NpdGlvbjogdmVjNDxmMzI+O1xuICAgIEBvdXQgdlVWIDogdmVjMjxmMzI+O1xuICAgIEBvdXQgdkNvbG9yIDogdmVjNDxmMzI+O1xuXG4gICAge3toZWFkZXJ9fVxuXG4gICAgc3RydWN0IFZTT3V0cHV0IHtcbiAgICAgICAge3tzdHJ1Y3R9fVxuICAgIH07XG5cbiAgICBAdmVydGV4XG4gICAgZm4gbWFpbigge3tpbn19ICkgLT4gVlNPdXRwdXQge1xuXG4gICAgICAgIHZhciB3b3JsZFRyYW5zZm9ybU1hdHJpeCA9IGdsb2JhbFVuaWZvcm1zLnVXb3JsZFRyYW5zZm9ybU1hdHJpeDtcbiAgICAgICAgdmFyIG1vZGVsTWF0cml4ID0gbWF0M3gzPGYzMj4oXG4gICAgICAgICAgICAxLjAsIDAuMCwgMC4wLFxuICAgICAgICAgICAgMC4wLCAxLjAsIDAuMCxcbiAgICAgICAgICAgIDAuMCwgMC4wLCAxLjBcbiAgICAgICAgICApO1xuICAgICAgICB2YXIgcG9zaXRpb24gPSBhUG9zaXRpb247XG4gICAgICAgIHZhciB1diA9IGFVVjtcblxuICAgICAgICB7e3N0YXJ0fX1cblxuICAgICAgICB2Q29sb3IgPSB2ZWM0PGYzMj4oMS4sIDEuLCAxLiwgMS4pO1xuXG4gICAgICAgIHt7bWFpbn19XG5cbiAgICAgICAgdlVWID0gdXY7XG5cbiAgICAgICAgdmFyIG1vZGVsVmlld1Byb2plY3Rpb25NYXRyaXggPSBnbG9iYWxVbmlmb3Jtcy51UHJvamVjdGlvbk1hdHJpeCAqIHdvcmxkVHJhbnNmb3JtTWF0cml4ICogbW9kZWxNYXRyaXg7XG5cbiAgICAgICAgdlBvc2l0aW9uID0gIHZlYzQ8ZjMyPigobW9kZWxWaWV3UHJvamVjdGlvbk1hdHJpeCAqICB2ZWMzPGYzMj4ocG9zaXRpb24sIDEuMCkpLnh5LCAwLjAsIDEuMCk7XG5cbiAgICAgICAgdkNvbG9yICo9IGdsb2JhbFVuaWZvcm1zLnVXb3JsZENvbG9yQWxwaGE7XG5cbiAgICAgICAge3tlbmR9fVxuXG4gICAgICAgIHt7cmV0dXJufX1cbiAgICB9O1xuYFxuKTtcbmNvbnN0IGZyYWdtZW50R1BVVGVtcGxhdGUgPSAoXG4gIC8qIHdnc2wgKi9cbiAgYFxuICAgIEBpbiB2VVYgOiB2ZWMyPGYzMj47XG4gICAgQGluIHZDb2xvciA6IHZlYzQ8ZjMyPjtcblxuICAgIHt7aGVhZGVyfX1cblxuICAgIEBmcmFnbWVudFxuICAgIGZuIG1haW4oXG4gICAgICAgIHt7aW59fVxuICAgICAgKSAtPiBAbG9jYXRpb24oMCkgdmVjNDxmMzI+IHtcblxuICAgICAgICB7e3N0YXJ0fX1cblxuICAgICAgICB2YXIgb3V0Q29sb3I6dmVjNDxmMzI+O1xuXG4gICAgICAgIHt7bWFpbn19XG5cbiAgICAgICAgdmFyIGZpbmFsQ29sb3I6dmVjNDxmMzI+ID0gb3V0Q29sb3IgKiB2Q29sb3I7XG5cbiAgICAgICAge3tlbmR9fVxuXG4gICAgICAgIHJldHVybiBmaW5hbENvbG9yO1xuICAgICAgfTtcbmBcbik7XG5jb25zdCB2ZXJ0ZXhHbFRlbXBsYXRlID0gKFxuICAvKiBnbHNsICovXG4gIGBcbiAgICBpbiB2ZWMyIGFQb3NpdGlvbjtcbiAgICBpbiB2ZWMyIGFVVjtcblxuICAgIG91dCB2ZWM0IHZDb2xvcjtcbiAgICBvdXQgdmVjMiB2VVY7XG5cbiAgICB7e2hlYWRlcn19XG5cbiAgICB2b2lkIG1haW4odm9pZCl7XG5cbiAgICAgICAgbWF0MyB3b3JsZFRyYW5zZm9ybU1hdHJpeCA9IHVXb3JsZFRyYW5zZm9ybU1hdHJpeDtcbiAgICAgICAgbWF0MyBtb2RlbE1hdHJpeCA9IG1hdDMoXG4gICAgICAgICAgICAxLjAsIDAuMCwgMC4wLFxuICAgICAgICAgICAgMC4wLCAxLjAsIDAuMCxcbiAgICAgICAgICAgIDAuMCwgMC4wLCAxLjBcbiAgICAgICAgICApO1xuICAgICAgICB2ZWMyIHBvc2l0aW9uID0gYVBvc2l0aW9uO1xuICAgICAgICB2ZWMyIHV2ID0gYVVWO1xuXG4gICAgICAgIHt7c3RhcnR9fVxuXG4gICAgICAgIHZDb2xvciA9IHZlYzQoMS4pO1xuXG4gICAgICAgIHt7bWFpbn19XG5cbiAgICAgICAgdlVWID0gdXY7XG5cbiAgICAgICAgbWF0MyBtb2RlbFZpZXdQcm9qZWN0aW9uTWF0cml4ID0gdVByb2plY3Rpb25NYXRyaXggKiB3b3JsZFRyYW5zZm9ybU1hdHJpeCAqIG1vZGVsTWF0cml4O1xuXG4gICAgICAgIGdsX1Bvc2l0aW9uID0gdmVjNCgobW9kZWxWaWV3UHJvamVjdGlvbk1hdHJpeCAqIHZlYzMocG9zaXRpb24sIDEuMCkpLnh5LCAwLjAsIDEuMCk7XG5cbiAgICAgICAgdkNvbG9yICo9IHVXb3JsZENvbG9yQWxwaGE7XG5cbiAgICAgICAge3tlbmR9fVxuICAgIH1cbmBcbik7XG5jb25zdCBmcmFnbWVudEdsVGVtcGxhdGUgPSAoXG4gIC8qIGdsc2wgKi9cbiAgYFxuXG4gICAgaW4gdmVjNCB2Q29sb3I7XG4gICAgaW4gdmVjMiB2VVY7XG5cbiAgICBvdXQgdmVjNCBmaW5hbENvbG9yO1xuXG4gICAge3toZWFkZXJ9fVxuXG4gICAgdm9pZCBtYWluKHZvaWQpIHtcblxuICAgICAgICB7e3N0YXJ0fX1cblxuICAgICAgICB2ZWM0IG91dENvbG9yO1xuXG4gICAgICAgIHt7bWFpbn19XG5cbiAgICAgICAgZmluYWxDb2xvciA9IG91dENvbG9yICogdkNvbG9yO1xuXG4gICAgICAgIHt7ZW5kfX1cbiAgICB9XG5gXG4pO1xuXG5leHBvcnQgeyBmcmFnbWVudEdQVVRlbXBsYXRlLCBmcmFnbWVudEdsVGVtcGxhdGUsIHZlcnRleEdQVVRlbXBsYXRlLCB2ZXJ0ZXhHbFRlbXBsYXRlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1kZWZhdWx0UHJvZ3JhbVRlbXBsYXRlLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY29uc3QgZ2xvYmFsVW5pZm9ybXNCaXQgPSB7XG4gIG5hbWU6IFwiZ2xvYmFsLXVuaWZvcm1zLWJpdFwiLFxuICB2ZXJ0ZXg6IHtcbiAgICBoZWFkZXI6IChcbiAgICAgIC8qIHdnc2wgKi9cbiAgICAgIGBcbiAgICAgICAgc3RydWN0IEdsb2JhbFVuaWZvcm1zIHtcbiAgICAgICAgICAgIHVQcm9qZWN0aW9uTWF0cml4Om1hdDN4MzxmMzI+LFxuICAgICAgICAgICAgdVdvcmxkVHJhbnNmb3JtTWF0cml4Om1hdDN4MzxmMzI+LFxuICAgICAgICAgICAgdVdvcmxkQ29sb3JBbHBoYTogdmVjNDxmMzI+LFxuICAgICAgICAgICAgdVJlc29sdXRpb246IHZlYzI8ZjMyPixcbiAgICAgICAgfVxuXG4gICAgICAgIEBncm91cCgwKSBAYmluZGluZygwKSB2YXI8dW5pZm9ybT4gZ2xvYmFsVW5pZm9ybXMgOiBHbG9iYWxVbmlmb3JtcztcbiAgICAgICAgYFxuICAgIClcbiAgfVxufTtcbmNvbnN0IGdsb2JhbFVuaWZvcm1zVUJPQml0R2wgPSB7XG4gIG5hbWU6IFwiZ2xvYmFsLXVuaWZvcm1zLXViby1iaXRcIixcbiAgdmVydGV4OiB7XG4gICAgaGVhZGVyOiAoXG4gICAgICAvKiBnbHNsICovXG4gICAgICBgXG4gICAgICAgICAgdW5pZm9ybSBnbG9iYWxVbmlmb3JtcyB7XG4gICAgICAgICAgICBtYXQzIHVQcm9qZWN0aW9uTWF0cml4O1xuICAgICAgICAgICAgbWF0MyB1V29ybGRUcmFuc2Zvcm1NYXRyaXg7XG4gICAgICAgICAgICB2ZWM0IHVXb3JsZENvbG9yQWxwaGE7XG4gICAgICAgICAgICB2ZWMyIHVSZXNvbHV0aW9uO1xuICAgICAgICAgIH07XG4gICAgICAgIGBcbiAgICApXG4gIH1cbn07XG5jb25zdCBnbG9iYWxVbmlmb3Jtc0JpdEdsID0ge1xuICBuYW1lOiBcImdsb2JhbC11bmlmb3Jtcy1iaXRcIixcbiAgdmVydGV4OiB7XG4gICAgaGVhZGVyOiAoXG4gICAgICAvKiBnbHNsICovXG4gICAgICBgXG4gICAgICAgICAgdW5pZm9ybSBtYXQzIHVQcm9qZWN0aW9uTWF0cml4O1xuICAgICAgICAgIHVuaWZvcm0gbWF0MyB1V29ybGRUcmFuc2Zvcm1NYXRyaXg7XG4gICAgICAgICAgdW5pZm9ybSB2ZWM0IHVXb3JsZENvbG9yQWxwaGE7XG4gICAgICAgICAgdW5pZm9ybSB2ZWMyIHVSZXNvbHV0aW9uO1xuICAgICAgICBgXG4gICAgKVxuICB9XG59O1xuXG5leHBvcnQgeyBnbG9iYWxVbmlmb3Jtc0JpdCwgZ2xvYmFsVW5pZm9ybXNCaXRHbCwgZ2xvYmFsVW5pZm9ybXNVQk9CaXRHbCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Z2xvYmFsVW5pZm9ybXNCaXQubWpzLm1hcFxuIiwiaW1wb3J0IHsgR2xQcm9ncmFtIH0gZnJvbSAnLi4vcmVuZGVyZXJzL2dsL3NoYWRlci9HbFByb2dyYW0ubWpzJztcbmltcG9ydCB7IEdwdVByb2dyYW0gfSBmcm9tICcuLi9yZW5kZXJlcnMvZ3B1L3NoYWRlci9HcHVQcm9ncmFtLm1qcyc7XG5pbXBvcnQgeyBjb21waWxlSGlnaFNoYWRlciwgY29tcGlsZUhpZ2hTaGFkZXJHbCB9IGZyb20gJy4vY29tcGlsZXIvY29tcGlsZUhpZ2hTaGFkZXIubWpzJztcbmltcG9ydCB7IHZlcnRleEdQVVRlbXBsYXRlLCBmcmFnbWVudEdQVVRlbXBsYXRlLCBmcmFnbWVudEdsVGVtcGxhdGUsIHZlcnRleEdsVGVtcGxhdGUgfSBmcm9tICcuL2RlZmF1bHRQcm9ncmFtVGVtcGxhdGUubWpzJztcbmltcG9ydCB7IGdsb2JhbFVuaWZvcm1zQml0LCBnbG9iYWxVbmlmb3Jtc0JpdEdsIH0gZnJvbSAnLi9zaGFkZXItYml0cy9nbG9iYWxVbmlmb3Jtc0JpdC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGNvbXBpbGVIaWdoU2hhZGVyR3B1UHJvZ3JhbSh7IGJpdHMsIG5hbWUgfSkge1xuICBjb25zdCBzb3VyY2UgPSBjb21waWxlSGlnaFNoYWRlcih7XG4gICAgdGVtcGxhdGU6IHtcbiAgICAgIGZyYWdtZW50OiBmcmFnbWVudEdQVVRlbXBsYXRlLFxuICAgICAgdmVydGV4OiB2ZXJ0ZXhHUFVUZW1wbGF0ZVxuICAgIH0sXG4gICAgYml0czogW1xuICAgICAgZ2xvYmFsVW5pZm9ybXNCaXQsXG4gICAgICAuLi5iaXRzXG4gICAgXVxuICB9KTtcbiAgcmV0dXJuIEdwdVByb2dyYW0uZnJvbSh7XG4gICAgbmFtZSxcbiAgICB2ZXJ0ZXg6IHtcbiAgICAgIHNvdXJjZTogc291cmNlLnZlcnRleCxcbiAgICAgIGVudHJ5UG9pbnQ6IFwibWFpblwiXG4gICAgfSxcbiAgICBmcmFnbWVudDoge1xuICAgICAgc291cmNlOiBzb3VyY2UuZnJhZ21lbnQsXG4gICAgICBlbnRyeVBvaW50OiBcIm1haW5cIlxuICAgIH1cbiAgfSk7XG59XG5mdW5jdGlvbiBjb21waWxlSGlnaFNoYWRlckdsUHJvZ3JhbSh7IGJpdHMsIG5hbWUgfSkge1xuICByZXR1cm4gbmV3IEdsUHJvZ3JhbSh7XG4gICAgbmFtZSxcbiAgICAuLi5jb21waWxlSGlnaFNoYWRlckdsKHtcbiAgICAgIHRlbXBsYXRlOiB7XG4gICAgICAgIHZlcnRleDogdmVydGV4R2xUZW1wbGF0ZSxcbiAgICAgICAgZnJhZ21lbnQ6IGZyYWdtZW50R2xUZW1wbGF0ZVxuICAgICAgfSxcbiAgICAgIGJpdHM6IFtcbiAgICAgICAgZ2xvYmFsVW5pZm9ybXNCaXRHbCxcbiAgICAgICAgLi4uYml0c1xuICAgICAgXVxuICAgIH0pXG4gIH0pO1xufVxuXG5leHBvcnQgeyBjb21waWxlSGlnaFNoYWRlckdsUHJvZ3JhbSwgY29tcGlsZUhpZ2hTaGFkZXJHcHVQcm9ncmFtIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb21waWxlSGlnaFNoYWRlclRvUHJvZ3JhbS5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IGNvbG9yQml0ID0ge1xuICBuYW1lOiBcImNvbG9yLWJpdFwiLFxuICB2ZXJ0ZXg6IHtcbiAgICBoZWFkZXI6IChcbiAgICAgIC8qIHdnc2wgKi9cbiAgICAgIGBcbiAgICAgICAgICAgIEBpbiBhQ29sb3I6IHZlYzQ8ZjMyPjtcbiAgICAgICAgYFxuICAgICksXG4gICAgbWFpbjogKFxuICAgICAgLyogd2dzbCAqL1xuICAgICAgYFxuICAgICAgICAgICAgdkNvbG9yICo9IHZlYzQ8ZjMyPihhQ29sb3IucmdiICogYUNvbG9yLmEsIGFDb2xvci5hKTtcbiAgICAgICAgYFxuICAgIClcbiAgfVxufTtcbmNvbnN0IGNvbG9yQml0R2wgPSB7XG4gIG5hbWU6IFwiY29sb3ItYml0XCIsXG4gIHZlcnRleDoge1xuICAgIGhlYWRlcjogKFxuICAgICAgLyogZ2xzbCAqL1xuICAgICAgYFxuICAgICAgICAgICAgaW4gdmVjNCBhQ29sb3I7XG4gICAgICAgIGBcbiAgICApLFxuICAgIG1haW46IChcbiAgICAgIC8qIGdsc2wgKi9cbiAgICAgIGBcbiAgICAgICAgICAgIHZDb2xvciAqPSB2ZWM0KGFDb2xvci5yZ2IgKiBhQ29sb3IuYSwgYUNvbG9yLmEpO1xuICAgICAgICBgXG4gICAgKVxuICB9XG59O1xuXG5leHBvcnQgeyBjb2xvckJpdCwgY29sb3JCaXRHbCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29sb3JCaXQubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCB0ZXh0dXJlQmF0Y2hCaXRHcHVDYWNoZSA9IHt9O1xuZnVuY3Rpb24gZ2VuZXJhdGVCaW5kaW5nU3JjKG1heFRleHR1cmVzKSB7XG4gIGNvbnN0IHNyYyA9IFtdO1xuICBpZiAobWF4VGV4dHVyZXMgPT09IDEpIHtcbiAgICBzcmMucHVzaChcIkBncm91cCgxKSBAYmluZGluZygwKSB2YXIgdGV4dHVyZVNvdXJjZTE6IHRleHR1cmVfMmQ8ZjMyPjtcIik7XG4gICAgc3JjLnB1c2goXCJAZ3JvdXAoMSkgQGJpbmRpbmcoMSkgdmFyIHRleHR1cmVTYW1wbGVyMTogc2FtcGxlcjtcIik7XG4gIH0gZWxzZSB7XG4gICAgbGV0IGJpbmRpbmdJbmRleCA9IDA7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXhUZXh0dXJlczsgaSsrKSB7XG4gICAgICBzcmMucHVzaChgQGdyb3VwKDEpIEBiaW5kaW5nKCR7YmluZGluZ0luZGV4Kyt9KSB2YXIgdGV4dHVyZVNvdXJjZSR7aSArIDF9OiB0ZXh0dXJlXzJkPGYzMj47YCk7XG4gICAgICBzcmMucHVzaChgQGdyb3VwKDEpIEBiaW5kaW5nKCR7YmluZGluZ0luZGV4Kyt9KSB2YXIgdGV4dHVyZVNhbXBsZXIke2kgKyAxfTogc2FtcGxlcjtgKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHNyYy5qb2luKFwiXFxuXCIpO1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVTYW1wbGVTcmMobWF4VGV4dHVyZXMpIHtcbiAgY29uc3Qgc3JjID0gW107XG4gIGlmIChtYXhUZXh0dXJlcyA9PT0gMSkge1xuICAgIHNyYy5wdXNoKFwib3V0Q29sb3IgPSB0ZXh0dXJlU2FtcGxlR3JhZCh0ZXh0dXJlU291cmNlMSwgdGV4dHVyZVNhbXBsZXIxLCB2VVYsIHV2RHgsIHV2RHkpO1wiKTtcbiAgfSBlbHNlIHtcbiAgICBzcmMucHVzaChcInN3aXRjaCB2VGV4dHVyZUlkIHtcIik7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXhUZXh0dXJlczsgaSsrKSB7XG4gICAgICBpZiAoaSA9PT0gbWF4VGV4dHVyZXMgLSAxKSB7XG4gICAgICAgIHNyYy5wdXNoKGAgIGRlZmF1bHQ6e2ApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3JjLnB1c2goYCAgY2FzZSAke2l9OntgKTtcbiAgICAgIH1cbiAgICAgIHNyYy5wdXNoKGAgICAgICBvdXRDb2xvciA9IHRleHR1cmVTYW1wbGVHcmFkKHRleHR1cmVTb3VyY2Uke2kgKyAxfSwgdGV4dHVyZVNhbXBsZXIke2kgKyAxfSwgdlVWLCB1dkR4LCB1dkR5KTtgKTtcbiAgICAgIHNyYy5wdXNoKGAgICAgICBicmVhazt9YCk7XG4gICAgfVxuICAgIHNyYy5wdXNoKGB9YCk7XG4gIH1cbiAgcmV0dXJuIHNyYy5qb2luKFwiXFxuXCIpO1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVUZXh0dXJlQmF0Y2hCaXQobWF4VGV4dHVyZXMpIHtcbiAgaWYgKCF0ZXh0dXJlQmF0Y2hCaXRHcHVDYWNoZVttYXhUZXh0dXJlc10pIHtcbiAgICB0ZXh0dXJlQmF0Y2hCaXRHcHVDYWNoZVttYXhUZXh0dXJlc10gPSB7XG4gICAgICBuYW1lOiBcInRleHR1cmUtYmF0Y2gtYml0XCIsXG4gICAgICB2ZXJ0ZXg6IHtcbiAgICAgICAgaGVhZGVyOiBgXG4gICAgICAgICAgICAgICAgQGluIGFUZXh0dXJlSWRBbmRSb3VuZDogdmVjMjx1MzI+O1xuICAgICAgICAgICAgICAgIEBvdXQgQGludGVycG9sYXRlKGZsYXQpIHZUZXh0dXJlSWQgOiB1MzI7XG4gICAgICAgICAgICBgLFxuICAgICAgICBtYWluOiBgXG4gICAgICAgICAgICAgICAgdlRleHR1cmVJZCA9IGFUZXh0dXJlSWRBbmRSb3VuZC55O1xuICAgICAgICAgICAgYCxcbiAgICAgICAgZW5kOiBgXG4gICAgICAgICAgICAgICAgaWYoYVRleHR1cmVJZEFuZFJvdW5kLnggPT0gMSlcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHZQb3NpdGlvbiA9IHZlYzQ8ZjMyPihyb3VuZFBpeGVscyh2UG9zaXRpb24ueHksIGdsb2JhbFVuaWZvcm1zLnVSZXNvbHV0aW9uKSwgdlBvc2l0aW9uLnp3KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBgXG4gICAgICB9LFxuICAgICAgZnJhZ21lbnQ6IHtcbiAgICAgICAgaGVhZGVyOiBgXG4gICAgICAgICAgICAgICAgQGluIEBpbnRlcnBvbGF0ZShmbGF0KSB2VGV4dHVyZUlkOiB1MzI7XG5cbiAgICAgICAgICAgICAgICAke2dlbmVyYXRlQmluZGluZ1NyYyhtYXhUZXh0dXJlcyl9XG4gICAgICAgICAgICBgLFxuICAgICAgICBtYWluOiBgXG4gICAgICAgICAgICAgICAgdmFyIHV2RHggPSBkcGR4KHZVVik7XG4gICAgICAgICAgICAgICAgdmFyIHV2RHkgPSBkcGR5KHZVVik7XG5cbiAgICAgICAgICAgICAgICAke2dlbmVyYXRlU2FtcGxlU3JjKG1heFRleHR1cmVzKX1cbiAgICAgICAgICAgIGBcbiAgICAgIH1cbiAgICB9O1xuICB9XG4gIHJldHVybiB0ZXh0dXJlQmF0Y2hCaXRHcHVDYWNoZVttYXhUZXh0dXJlc107XG59XG5jb25zdCB0ZXh0dXJlQmF0Y2hCaXRHbENhY2hlID0ge307XG5mdW5jdGlvbiBnZW5lcmF0ZVNhbXBsZUdsU3JjKG1heFRleHR1cmVzKSB7XG4gIGNvbnN0IHNyYyA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG1heFRleHR1cmVzOyBpKyspIHtcbiAgICBpZiAoaSA+IDApIHtcbiAgICAgIHNyYy5wdXNoKFwiZWxzZVwiKTtcbiAgICB9XG4gICAgaWYgKGkgPCBtYXhUZXh0dXJlcyAtIDEpIHtcbiAgICAgIHNyYy5wdXNoKGBpZih2VGV4dHVyZUlkIDwgJHtpfS41KWApO1xuICAgIH1cbiAgICBzcmMucHVzaChcIntcIik7XG4gICAgc3JjLnB1c2goYFx0b3V0Q29sb3IgPSB0ZXh0dXJlKHVUZXh0dXJlc1ske2l9XSwgdlVWKTtgKTtcbiAgICBzcmMucHVzaChcIn1cIik7XG4gIH1cbiAgcmV0dXJuIHNyYy5qb2luKFwiXFxuXCIpO1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVUZXh0dXJlQmF0Y2hCaXRHbChtYXhUZXh0dXJlcykge1xuICBpZiAoIXRleHR1cmVCYXRjaEJpdEdsQ2FjaGVbbWF4VGV4dHVyZXNdKSB7XG4gICAgdGV4dHVyZUJhdGNoQml0R2xDYWNoZVttYXhUZXh0dXJlc10gPSB7XG4gICAgICBuYW1lOiBcInRleHR1cmUtYmF0Y2gtYml0XCIsXG4gICAgICB2ZXJ0ZXg6IHtcbiAgICAgICAgaGVhZGVyOiBgXG4gICAgICAgICAgICAgICAgaW4gdmVjMiBhVGV4dHVyZUlkQW5kUm91bmQ7XG4gICAgICAgICAgICAgICAgb3V0IGZsb2F0IHZUZXh0dXJlSWQ7XG5cbiAgICAgICAgICAgIGAsXG4gICAgICAgIG1haW46IGBcbiAgICAgICAgICAgICAgICB2VGV4dHVyZUlkID0gYVRleHR1cmVJZEFuZFJvdW5kLnk7XG4gICAgICAgICAgICBgLFxuICAgICAgICBlbmQ6IGBcbiAgICAgICAgICAgICAgICBpZihhVGV4dHVyZUlkQW5kUm91bmQueCA9PSAxLilcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGdsX1Bvc2l0aW9uLnh5ID0gcm91bmRQaXhlbHMoZ2xfUG9zaXRpb24ueHksIHVSZXNvbHV0aW9uKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBgXG4gICAgICB9LFxuICAgICAgZnJhZ21lbnQ6IHtcbiAgICAgICAgaGVhZGVyOiBgXG4gICAgICAgICAgICAgICAgaW4gZmxvYXQgdlRleHR1cmVJZDtcblxuICAgICAgICAgICAgICAgIHVuaWZvcm0gc2FtcGxlcjJEIHVUZXh0dXJlc1ske21heFRleHR1cmVzfV07XG5cbiAgICAgICAgICAgIGAsXG4gICAgICAgIG1haW46IGBcblxuICAgICAgICAgICAgICAgICR7Z2VuZXJhdGVTYW1wbGVHbFNyYyhtYXhUZXh0dXJlcyl9XG4gICAgICAgICAgICBgXG4gICAgICB9XG4gICAgfTtcbiAgfVxuICByZXR1cm4gdGV4dHVyZUJhdGNoQml0R2xDYWNoZVttYXhUZXh0dXJlc107XG59XG5cbmV4cG9ydCB7IGdlbmVyYXRlVGV4dHVyZUJhdGNoQml0LCBnZW5lcmF0ZVRleHR1cmVCYXRjaEJpdEdsIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1nZW5lcmF0ZVRleHR1cmVCYXRjaEJpdC5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IHJvdW5kUGl4ZWxzQml0ID0ge1xuICBuYW1lOiBcInJvdW5kLXBpeGVscy1iaXRcIixcbiAgdmVydGV4OiB7XG4gICAgaGVhZGVyOiAoXG4gICAgICAvKiB3Z3NsICovXG4gICAgICBgXG4gICAgICAgICAgICBmbiByb3VuZFBpeGVscyhwb3NpdGlvbjogdmVjMjxmMzI+LCB0YXJnZXRTaXplOiB2ZWMyPGYzMj4pIC0+IHZlYzI8ZjMyPlxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJldHVybiAoZmxvb3IoKChwb3NpdGlvbiAqIDAuNSArIDAuNSkgKiB0YXJnZXRTaXplKSArIDAuNSkgLyB0YXJnZXRTaXplKSAqIDIuMCAtIDEuMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgYFxuICAgIClcbiAgfVxufTtcbmNvbnN0IHJvdW5kUGl4ZWxzQml0R2wgPSB7XG4gIG5hbWU6IFwicm91bmQtcGl4ZWxzLWJpdFwiLFxuICB2ZXJ0ZXg6IHtcbiAgICBoZWFkZXI6IChcbiAgICAgIC8qIGdsc2wgKi9cbiAgICAgIGBcbiAgICAgICAgICAgIHZlYzIgcm91bmRQaXhlbHModmVjMiBwb3NpdGlvbiwgdmVjMiB0YXJnZXRTaXplKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJldHVybiAoZmxvb3IoKChwb3NpdGlvbiAqIDAuNSArIDAuNSkgKiB0YXJnZXRTaXplKSArIDAuNSkgLyB0YXJnZXRTaXplKSAqIDIuMCAtIDEuMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgYFxuICAgIClcbiAgfVxufTtcblxuZXhwb3J0IHsgcm91bmRQaXhlbHNCaXQsIHJvdW5kUGl4ZWxzQml0R2wgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdW5kUGl4ZWxzQml0Lm1qcy5tYXBcbiIsImltcG9ydCB7IFVuaWZvcm1Hcm91cCB9IGZyb20gJy4uLy4uL3NoYXJlZC9zaGFkZXIvVW5pZm9ybUdyb3VwLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgYmF0Y2hTYW1wbGVyc1VuaWZvcm1Hcm91cEhhc2ggPSB7fTtcbmZ1bmN0aW9uIGdldEJhdGNoU2FtcGxlcnNVbmlmb3JtR3JvdXAobWF4VGV4dHVyZXMpIHtcbiAgbGV0IGJhdGNoU2FtcGxlcnNVbmlmb3JtR3JvdXAgPSBiYXRjaFNhbXBsZXJzVW5pZm9ybUdyb3VwSGFzaFttYXhUZXh0dXJlc107XG4gIGlmIChiYXRjaFNhbXBsZXJzVW5pZm9ybUdyb3VwKSByZXR1cm4gYmF0Y2hTYW1wbGVyc1VuaWZvcm1Hcm91cDtcbiAgY29uc3Qgc2FtcGxlVmFsdWVzID0gbmV3IEludDMyQXJyYXkobWF4VGV4dHVyZXMpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG1heFRleHR1cmVzOyBpKyspIHtcbiAgICBzYW1wbGVWYWx1ZXNbaV0gPSBpO1xuICB9XG4gIGJhdGNoU2FtcGxlcnNVbmlmb3JtR3JvdXAgPSBiYXRjaFNhbXBsZXJzVW5pZm9ybUdyb3VwSGFzaFttYXhUZXh0dXJlc10gPSBuZXcgVW5pZm9ybUdyb3VwKHtcbiAgICB1VGV4dHVyZXM6IHsgdmFsdWU6IHNhbXBsZVZhbHVlcywgdHlwZTogYGkzMmAsIHNpemU6IG1heFRleHR1cmVzIH1cbiAgfSwgeyBpc1N0YXRpYzogdHJ1ZSB9KTtcbiAgcmV0dXJuIGJhdGNoU2FtcGxlcnNVbmlmb3JtR3JvdXA7XG59XG5cbmV4cG9ydCB7IGdldEJhdGNoU2FtcGxlcnNVbmlmb3JtR3JvdXAgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdldEJhdGNoU2FtcGxlcnNVbmlmb3JtR3JvdXAubWpzLm1hcFxuIiwiaW1wb3J0IHsgY29tcGlsZUhpZ2hTaGFkZXJHbFByb2dyYW0sIGNvbXBpbGVIaWdoU2hhZGVyR3B1UHJvZ3JhbSB9IGZyb20gJy4uLy4uL2hpZ2gtc2hhZGVyL2NvbXBpbGVIaWdoU2hhZGVyVG9Qcm9ncmFtLm1qcyc7XG5pbXBvcnQgeyBjb2xvckJpdEdsLCBjb2xvckJpdCB9IGZyb20gJy4uLy4uL2hpZ2gtc2hhZGVyL3NoYWRlci1iaXRzL2NvbG9yQml0Lm1qcyc7XG5pbXBvcnQgeyBnZW5lcmF0ZVRleHR1cmVCYXRjaEJpdEdsLCBnZW5lcmF0ZVRleHR1cmVCYXRjaEJpdCB9IGZyb20gJy4uLy4uL2hpZ2gtc2hhZGVyL3NoYWRlci1iaXRzL2dlbmVyYXRlVGV4dHVyZUJhdGNoQml0Lm1qcyc7XG5pbXBvcnQgeyByb3VuZFBpeGVsc0JpdEdsLCByb3VuZFBpeGVsc0JpdCB9IGZyb20gJy4uLy4uL2hpZ2gtc2hhZGVyL3NoYWRlci1iaXRzL3JvdW5kUGl4ZWxzQml0Lm1qcyc7XG5pbXBvcnQgeyBnZXRCYXRjaFNhbXBsZXJzVW5pZm9ybUdyb3VwIH0gZnJvbSAnLi4vLi4vcmVuZGVyZXJzL2dsL3NoYWRlci9nZXRCYXRjaFNhbXBsZXJzVW5pZm9ybUdyb3VwLm1qcyc7XG5pbXBvcnQgeyBTaGFkZXIgfSBmcm9tICcuLi8uLi9yZW5kZXJlcnMvc2hhcmVkL3NoYWRlci9TaGFkZXIubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBEZWZhdWx0U2hhZGVyIGV4dGVuZHMgU2hhZGVyIHtcbiAgY29uc3RydWN0b3IobWF4VGV4dHVyZXMpIHtcbiAgICBjb25zdCBnbFByb2dyYW0gPSBjb21waWxlSGlnaFNoYWRlckdsUHJvZ3JhbSh7XG4gICAgICBuYW1lOiBcImJhdGNoXCIsXG4gICAgICBiaXRzOiBbXG4gICAgICAgIGNvbG9yQml0R2wsXG4gICAgICAgIGdlbmVyYXRlVGV4dHVyZUJhdGNoQml0R2wobWF4VGV4dHVyZXMpLFxuICAgICAgICByb3VuZFBpeGVsc0JpdEdsXG4gICAgICBdXG4gICAgfSk7XG4gICAgY29uc3QgZ3B1UHJvZ3JhbSA9IGNvbXBpbGVIaWdoU2hhZGVyR3B1UHJvZ3JhbSh7XG4gICAgICBuYW1lOiBcImJhdGNoXCIsXG4gICAgICBiaXRzOiBbXG4gICAgICAgIGNvbG9yQml0LFxuICAgICAgICBnZW5lcmF0ZVRleHR1cmVCYXRjaEJpdChtYXhUZXh0dXJlcyksXG4gICAgICAgIHJvdW5kUGl4ZWxzQml0XG4gICAgICBdXG4gICAgfSk7XG4gICAgc3VwZXIoe1xuICAgICAgZ2xQcm9ncmFtLFxuICAgICAgZ3B1UHJvZ3JhbSxcbiAgICAgIHJlc291cmNlczoge1xuICAgICAgICBiYXRjaFNhbXBsZXJzOiBnZXRCYXRjaFNhbXBsZXJzVW5pZm9ybUdyb3VwKG1heFRleHR1cmVzKVxuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMubWF4VGV4dHVyZXMgPSBtYXhUZXh0dXJlcztcbiAgfVxufVxuXG5leHBvcnQgeyBEZWZhdWx0U2hhZGVyIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1EZWZhdWx0U2hhZGVyLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IEJhdGNoZXIgfSBmcm9tICcuL0JhdGNoZXIubWpzJztcbmltcG9ydCB7IEJhdGNoR2VvbWV0cnkgfSBmcm9tICcuL0JhdGNoR2VvbWV0cnkubWpzJztcbmltcG9ydCB7IERlZmF1bHRTaGFkZXIgfSBmcm9tICcuL0RlZmF1bHRTaGFkZXIubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5sZXQgZGVmYXVsdFNoYWRlciA9IG51bGw7XG5jb25zdCBfRGVmYXVsdEJhdGNoZXIgPSBjbGFzcyBfRGVmYXVsdEJhdGNoZXIgZXh0ZW5kcyBCYXRjaGVyIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgIHRoaXMuZ2VvbWV0cnkgPSBuZXcgQmF0Y2hHZW9tZXRyeSgpO1xuICAgIHRoaXMubmFtZSA9IF9EZWZhdWx0QmF0Y2hlci5leHRlbnNpb24ubmFtZTtcbiAgICAvKiogVGhlIHNpemUgb2Ygb25lIGF0dHJpYnV0ZS4gMSA9IDMyIGJpdC4geCwgeSwgdSwgdiwgY29sb3IsIHRleHR1cmVJZEFuZFJvdW5kIC0+IHRvdGFsID0gNiAqL1xuICAgIHRoaXMudmVydGV4U2l6ZSA9IDY7XG4gICAgZGVmYXVsdFNoYWRlciA/PyAoZGVmYXVsdFNoYWRlciA9IG5ldyBEZWZhdWx0U2hhZGVyKG9wdGlvbnMubWF4VGV4dHVyZXMpKTtcbiAgICB0aGlzLnNoYWRlciA9IGRlZmF1bHRTaGFkZXI7XG4gIH1cbiAgLyoqXG4gICAqIFBhY2tzIHRoZSBhdHRyaWJ1dGVzIG9mIGEgRGVmYXVsdEJhdGNoYWJsZU1lc2hFbGVtZW50IGludG8gdGhlIHByb3ZpZGVkIHZpZXdzLlxuICAgKiBAcGFyYW0gZWxlbWVudCAtIFRoZSBEZWZhdWx0QmF0Y2hhYmxlTWVzaEVsZW1lbnQgdG8gcGFjay5cbiAgICogQHBhcmFtIGZsb2F0MzJWaWV3IC0gVGhlIEZsb2F0MzJBcnJheSB2aWV3IHRvIHBhY2sgaW50by5cbiAgICogQHBhcmFtIHVpbnQzMlZpZXcgLSBUaGUgVWludDMyQXJyYXkgdmlldyB0byBwYWNrIGludG8uXG4gICAqIEBwYXJhbSBpbmRleCAtIFRoZSBzdGFydGluZyBpbmRleCBpbiB0aGUgdmlld3MuXG4gICAqIEBwYXJhbSB0ZXh0dXJlSWQgLSBUaGUgdGV4dHVyZSBJRCB0byB1c2UuXG4gICAqL1xuICBwYWNrQXR0cmlidXRlcyhlbGVtZW50LCBmbG9hdDMyVmlldywgdWludDMyVmlldywgaW5kZXgsIHRleHR1cmVJZCkge1xuICAgIGNvbnN0IHRleHR1cmVJZEFuZFJvdW5kID0gdGV4dHVyZUlkIDw8IDE2IHwgZWxlbWVudC5yb3VuZFBpeGVscyAmIDY1NTM1O1xuICAgIGNvbnN0IHd0ID0gZWxlbWVudC50cmFuc2Zvcm07XG4gICAgY29uc3QgYSA9IHd0LmE7XG4gICAgY29uc3QgYiA9IHd0LmI7XG4gICAgY29uc3QgYyA9IHd0LmM7XG4gICAgY29uc3QgZCA9IHd0LmQ7XG4gICAgY29uc3QgdHggPSB3dC50eDtcbiAgICBjb25zdCB0eSA9IHd0LnR5O1xuICAgIGNvbnN0IHsgcG9zaXRpb25zLCB1dnMgfSA9IGVsZW1lbnQ7XG4gICAgY29uc3QgYXJnYiA9IGVsZW1lbnQuY29sb3I7XG4gICAgY29uc3Qgb2Zmc2V0ID0gZWxlbWVudC5hdHRyaWJ1dGVPZmZzZXQ7XG4gICAgY29uc3QgZW5kID0gb2Zmc2V0ICsgZWxlbWVudC5hdHRyaWJ1dGVTaXplO1xuICAgIGZvciAobGV0IGkgPSBvZmZzZXQ7IGkgPCBlbmQ7IGkrKykge1xuICAgICAgY29uc3QgaTIgPSBpICogMjtcbiAgICAgIGNvbnN0IHggPSBwb3NpdGlvbnNbaTJdO1xuICAgICAgY29uc3QgeSA9IHBvc2l0aW9uc1tpMiArIDFdO1xuICAgICAgZmxvYXQzMlZpZXdbaW5kZXgrK10gPSBhICogeCArIGMgKiB5ICsgdHg7XG4gICAgICBmbG9hdDMyVmlld1tpbmRleCsrXSA9IGQgKiB5ICsgYiAqIHggKyB0eTtcbiAgICAgIGZsb2F0MzJWaWV3W2luZGV4KytdID0gdXZzW2kyXTtcbiAgICAgIGZsb2F0MzJWaWV3W2luZGV4KytdID0gdXZzW2kyICsgMV07XG4gICAgICB1aW50MzJWaWV3W2luZGV4KytdID0gYXJnYjtcbiAgICAgIHVpbnQzMlZpZXdbaW5kZXgrK10gPSB0ZXh0dXJlSWRBbmRSb3VuZDtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIFBhY2tzIHRoZSBhdHRyaWJ1dGVzIG9mIGEgRGVmYXVsdEJhdGNoYWJsZVF1YWRFbGVtZW50IGludG8gdGhlIHByb3ZpZGVkIHZpZXdzLlxuICAgKiBAcGFyYW0gZWxlbWVudCAtIFRoZSBEZWZhdWx0QmF0Y2hhYmxlUXVhZEVsZW1lbnQgdG8gcGFjay5cbiAgICogQHBhcmFtIGZsb2F0MzJWaWV3IC0gVGhlIEZsb2F0MzJBcnJheSB2aWV3IHRvIHBhY2sgaW50by5cbiAgICogQHBhcmFtIHVpbnQzMlZpZXcgLSBUaGUgVWludDMyQXJyYXkgdmlldyB0byBwYWNrIGludG8uXG4gICAqIEBwYXJhbSBpbmRleCAtIFRoZSBzdGFydGluZyBpbmRleCBpbiB0aGUgdmlld3MuXG4gICAqIEBwYXJhbSB0ZXh0dXJlSWQgLSBUaGUgdGV4dHVyZSBJRCB0byB1c2UuXG4gICAqL1xuICBwYWNrUXVhZEF0dHJpYnV0ZXMoZWxlbWVudCwgZmxvYXQzMlZpZXcsIHVpbnQzMlZpZXcsIGluZGV4LCB0ZXh0dXJlSWQpIHtcbiAgICBjb25zdCB0ZXh0dXJlID0gZWxlbWVudC50ZXh0dXJlO1xuICAgIGNvbnN0IHd0ID0gZWxlbWVudC50cmFuc2Zvcm07XG4gICAgY29uc3QgYSA9IHd0LmE7XG4gICAgY29uc3QgYiA9IHd0LmI7XG4gICAgY29uc3QgYyA9IHd0LmM7XG4gICAgY29uc3QgZCA9IHd0LmQ7XG4gICAgY29uc3QgdHggPSB3dC50eDtcbiAgICBjb25zdCB0eSA9IHd0LnR5O1xuICAgIGNvbnN0IGJvdW5kcyA9IGVsZW1lbnQuYm91bmRzO1xuICAgIGNvbnN0IHcwID0gYm91bmRzLm1heFg7XG4gICAgY29uc3QgdzEgPSBib3VuZHMubWluWDtcbiAgICBjb25zdCBoMCA9IGJvdW5kcy5tYXhZO1xuICAgIGNvbnN0IGgxID0gYm91bmRzLm1pblk7XG4gICAgY29uc3QgdXZzID0gdGV4dHVyZS51dnM7XG4gICAgY29uc3QgYXJnYiA9IGVsZW1lbnQuY29sb3I7XG4gICAgY29uc3QgdGV4dHVyZUlkQW5kUm91bmQgPSB0ZXh0dXJlSWQgPDwgMTYgfCBlbGVtZW50LnJvdW5kUGl4ZWxzICYgNjU1MzU7XG4gICAgZmxvYXQzMlZpZXdbaW5kZXggKyAwXSA9IGEgKiB3MSArIGMgKiBoMSArIHR4O1xuICAgIGZsb2F0MzJWaWV3W2luZGV4ICsgMV0gPSBkICogaDEgKyBiICogdzEgKyB0eTtcbiAgICBmbG9hdDMyVmlld1tpbmRleCArIDJdID0gdXZzLngwO1xuICAgIGZsb2F0MzJWaWV3W2luZGV4ICsgM10gPSB1dnMueTA7XG4gICAgdWludDMyVmlld1tpbmRleCArIDRdID0gYXJnYjtcbiAgICB1aW50MzJWaWV3W2luZGV4ICsgNV0gPSB0ZXh0dXJlSWRBbmRSb3VuZDtcbiAgICBmbG9hdDMyVmlld1tpbmRleCArIDZdID0gYSAqIHcwICsgYyAqIGgxICsgdHg7XG4gICAgZmxvYXQzMlZpZXdbaW5kZXggKyA3XSA9IGQgKiBoMSArIGIgKiB3MCArIHR5O1xuICAgIGZsb2F0MzJWaWV3W2luZGV4ICsgOF0gPSB1dnMueDE7XG4gICAgZmxvYXQzMlZpZXdbaW5kZXggKyA5XSA9IHV2cy55MTtcbiAgICB1aW50MzJWaWV3W2luZGV4ICsgMTBdID0gYXJnYjtcbiAgICB1aW50MzJWaWV3W2luZGV4ICsgMTFdID0gdGV4dHVyZUlkQW5kUm91bmQ7XG4gICAgZmxvYXQzMlZpZXdbaW5kZXggKyAxMl0gPSBhICogdzAgKyBjICogaDAgKyB0eDtcbiAgICBmbG9hdDMyVmlld1tpbmRleCArIDEzXSA9IGQgKiBoMCArIGIgKiB3MCArIHR5O1xuICAgIGZsb2F0MzJWaWV3W2luZGV4ICsgMTRdID0gdXZzLngyO1xuICAgIGZsb2F0MzJWaWV3W2luZGV4ICsgMTVdID0gdXZzLnkyO1xuICAgIHVpbnQzMlZpZXdbaW5kZXggKyAxNl0gPSBhcmdiO1xuICAgIHVpbnQzMlZpZXdbaW5kZXggKyAxN10gPSB0ZXh0dXJlSWRBbmRSb3VuZDtcbiAgICBmbG9hdDMyVmlld1tpbmRleCArIDE4XSA9IGEgKiB3MSArIGMgKiBoMCArIHR4O1xuICAgIGZsb2F0MzJWaWV3W2luZGV4ICsgMTldID0gZCAqIGgwICsgYiAqIHcxICsgdHk7XG4gICAgZmxvYXQzMlZpZXdbaW5kZXggKyAyMF0gPSB1dnMueDM7XG4gICAgZmxvYXQzMlZpZXdbaW5kZXggKyAyMV0gPSB1dnMueTM7XG4gICAgdWludDMyVmlld1tpbmRleCArIDIyXSA9IGFyZ2I7XG4gICAgdWludDMyVmlld1tpbmRleCArIDIzXSA9IHRleHR1cmVJZEFuZFJvdW5kO1xuICB9XG4gIC8qKlxuICAgKiBVcGRhdGVzIHRoZSBtYXhpbXVtIG51bWJlciBvZiB0ZXh0dXJlcyB0aGF0IGNhbiBiZSB1c2VkIGluIHRoZSBzaGFkZXIuXG4gICAqIEBwYXJhbSBtYXhUZXh0dXJlcyAtIFRoZSBtYXhpbXVtIG51bWJlciBvZiB0ZXh0dXJlcyB0aGF0IGNhbiBiZSB1c2VkIGluIHRoZSBzaGFkZXIuXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgX3VwZGF0ZU1heFRleHR1cmVzKG1heFRleHR1cmVzKSB7XG4gICAgaWYgKHRoaXMuc2hhZGVyLm1heFRleHR1cmVzID09PSBtYXhUZXh0dXJlcykgcmV0dXJuO1xuICAgIGRlZmF1bHRTaGFkZXIgPSBuZXcgRGVmYXVsdFNoYWRlcihtYXhUZXh0dXJlcyk7XG4gICAgdGhpcy5zaGFkZXIgPSBkZWZhdWx0U2hhZGVyO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5zaGFkZXIgPSBudWxsO1xuICAgIHN1cGVyLmRlc3Ryb3koKTtcbiAgfVxufTtcbi8qKiBAaWdub3JlICovXG5fRGVmYXVsdEJhdGNoZXIuZXh0ZW5zaW9uID0ge1xuICB0eXBlOiBbXG4gICAgRXh0ZW5zaW9uVHlwZS5CYXRjaGVyXG4gIF0sXG4gIG5hbWU6IFwiZGVmYXVsdFwiXG59O1xubGV0IERlZmF1bHRCYXRjaGVyID0gX0RlZmF1bHRCYXRjaGVyO1xuXG5leHBvcnQgeyBEZWZhdWx0QmF0Y2hlciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9RGVmYXVsdEJhdGNoZXIubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBHQ01hbmFnZWRIYXNoIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIC8vIEV4cG9zZWQgZGlyZWN0bHkgZm9yIEdDIHN5c3RlbSBhY2Nlc3NcbiAgICB0aGlzLml0ZW1zID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgY29uc3QgeyByZW5kZXJlciwgdHlwZSwgb25VbmxvYWQsIHByaW9yaXR5LCBuYW1lIH0gPSBvcHRpb25zO1xuICAgIHRoaXMuX3JlbmRlcmVyID0gcmVuZGVyZXI7XG4gICAgcmVuZGVyZXIuZ2MuYWRkUmVzb3VyY2VIYXNoKHRoaXMsIFwiaXRlbXNcIiwgdHlwZSwgcHJpb3JpdHkgPz8gMCk7XG4gICAgdGhpcy5fb25VbmxvYWQgPSBvblVubG9hZDtcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICB9XG4gIC8qKlxuICAgKiBBZGQgYW4gaXRlbSB0byB0aGUgaGFzaC4gTm8tb3AgaWYgYWxyZWFkeSBhZGRlZC5cbiAgICogQHBhcmFtIGl0ZW1cbiAgICogQHJldHVybnMgdHJ1ZSBpZiB0aGUgaXRlbSB3YXMgYWRkZWQsIGZhbHNlIGlmIGl0IHdhcyBhbHJlYWR5IGluIHRoZSBoYXNoXG4gICAqL1xuICBhZGQoaXRlbSkge1xuICAgIGlmICh0aGlzLml0ZW1zW2l0ZW0udWlkXSkgcmV0dXJuIGZhbHNlO1xuICAgIHRoaXMuaXRlbXNbaXRlbS51aWRdID0gaXRlbTtcbiAgICBpdGVtLm9uY2UoXCJ1bmxvYWRcIiwgdGhpcy5yZW1vdmUsIHRoaXMpO1xuICAgIGl0ZW0uX2djTGFzdFVzZWQgPSB0aGlzLl9yZW5kZXJlci5nYy5ub3c7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmVtb3ZlKGl0ZW0sIC4uLmFyZ3MpIHtcbiAgICBpZiAoIXRoaXMuaXRlbXNbaXRlbS51aWRdKSByZXR1cm47XG4gICAgY29uc3QgZ3B1RGF0YSA9IGl0ZW0uX2dwdURhdGFbdGhpcy5fcmVuZGVyZXIudWlkXTtcbiAgICBpZiAoIWdwdURhdGEpIHJldHVybjtcbiAgICB0aGlzLl9vblVubG9hZD8uKGl0ZW0sIC4uLmFyZ3MpO1xuICAgIGl0ZW0ub2ZmKFwidW5sb2FkXCIsIHRoaXMucmVtb3ZlLCB0aGlzKTtcbiAgICBncHVEYXRhLmRlc3Ryb3koKTtcbiAgICBpdGVtLl9ncHVEYXRhW3RoaXMuX3JlbmRlcmVyLnVpZF0gPSBudWxsO1xuICAgIHRoaXMuaXRlbXNbaXRlbS51aWRdID0gbnVsbDtcbiAgfVxuICByZW1vdmVBbGwoLi4uYXJncykge1xuICAgIE9iamVjdC52YWx1ZXModGhpcy5pdGVtcykuZm9yRWFjaCgoaXRlbSkgPT4gaXRlbSAmJiB0aGlzLnJlbW92ZShpdGVtLCAuLi5hcmdzKSk7XG4gIH1cbiAgZGVzdHJveSguLi5hcmdzKSB7XG4gICAgdGhpcy5yZW1vdmVBbGwoLi4uYXJncyk7XG4gICAgdGhpcy5pdGVtcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIHRoaXMuX3JlbmRlcmVyID0gbnVsbDtcbiAgICB0aGlzLl9vblVubG9hZCA9IG51bGw7XG4gIH1cbn1cblxuZXhwb3J0IHsgR0NNYW5hZ2VkSGFzaCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9R0NNYW5hZ2VkSGFzaC5tanMubWFwXG4iXSwibWFwcGluZ3MiOiI7O0FBQ0EsSUFBTSxpQkFBTixNQUFxQjtDQUNuQixZQUFZLGNBQWM7RUFDeEIsSUFBSSxPQUFPLGlCQUFpQixVQUMxQixLQUFLLGdCQUFnQixJQUFJLFlBQVksWUFBWTtPQUM1QyxJQUFJLHdCQUF3QixZQUNqQyxLQUFLLGdCQUFnQixhQUFhO09BRWxDLEtBQUssZ0JBQWdCO0VBRXZCLEtBQUssYUFBYSxJQUFJLFlBQVksS0FBSyxhQUFhO0VBQ3BELEtBQUssY0FBYyxJQUFJLGFBQWEsS0FBSyxhQUFhO0VBQ3RELEtBQUssT0FBTyxLQUFLLGNBQWM7Q0FDakM7O0NBRUEsSUFBSSxXQUFXO0VBQ2IsSUFBSSxDQUFDLEtBQUssV0FDUixLQUFLLFlBQVksSUFBSSxVQUFVLEtBQUssYUFBYTtFQUVuRCxPQUFPLEtBQUs7Q0FDZDs7Q0FFQSxJQUFJLFlBQVk7RUFDZCxJQUFJLENBQUMsS0FBSyxZQUNSLEtBQUssYUFBYSxJQUFJLFdBQVcsS0FBSyxhQUFhO0VBRXJELE9BQU8sS0FBSztDQUNkOztDQUVBLElBQUksWUFBWTtFQUNkLElBQUksQ0FBQyxLQUFLLFlBQ1IsS0FBSyxhQUFhLElBQUksV0FBVyxLQUFLLGFBQWE7RUFFckQsT0FBTyxLQUFLO0NBQ2Q7O0NBRUEsSUFBSSxZQUFZO0VBQ2QsSUFBSSxDQUFDLEtBQUssWUFDUixLQUFLLGFBQWEsSUFBSSxXQUFXLEtBQUssYUFBYTtFQUVyRCxPQUFPLEtBQUs7Q0FDZDs7Q0FFQSxJQUFJLGNBQWM7RUFDaEIsSUFBSSxDQUFDLEtBQUssZUFDUixLQUFLLGdCQUFnQixJQUFJLGFBQWEsS0FBSyxhQUFhO0VBRTFELE9BQU8sS0FBSztDQUNkOztDQUVBLElBQUksZ0JBQWdCO0VBQ2xCLElBQUksQ0FBQyxLQUFLLGlCQUNSLEtBQUssa0JBQWtCLElBQUksZUFBZSxLQUFLLGFBQWE7RUFFOUQsT0FBTyxLQUFLO0NBQ2Q7Ozs7Ozs7Q0FPQSxLQUFLLE1BQU07RUFDVCxPQUFPLEtBQUssR0FBRyxLQUFLO0NBQ3RCOztDQUVBLFVBQVU7RUFDUixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxjQUFjO0VBQ25CLEtBQUssYUFBYTtFQUNsQixLQUFLLFlBQVk7RUFDakIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssYUFBYTtFQUNsQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxrQkFBa0I7Q0FDekI7Ozs7Ozs7Q0FPQSxPQUFPLE9BQU8sTUFBTTtFQUNsQixRQUFRLE1BQVI7R0FDRSxLQUFLO0dBQ0wsS0FBSyxTQUNILE9BQU87R0FDVCxLQUFLO0dBQ0wsS0FBSyxVQUNILE9BQU87R0FDVCxLQUFLO0dBQ0wsS0FBSztHQUNMLEtBQUssV0FDSCxPQUFPO0dBQ1QsU0FDRSxNQUFNLElBQUksTUFBTSxHQUFHLEtBQUsseUJBQXlCO0VBQ3JEO0NBQ0Y7QUFDRjs7O0FDbkdBLFNBQVMsU0FBUyxjQUFjLG1CQUFtQixjQUFjLFlBQVk7Q0FDM0UsaUJBQWlCLGVBQWU7Q0FDaEMsZUFBZSxhQUFhLEtBQUssSUFBSSxhQUFhLGFBQWEsY0FBYyxrQkFBa0IsVUFBVTtDQUN6RyxJQUFJLEVBQUUsZUFBZSxNQUFNLEVBQUUsYUFBYSxJQUFJO0VBQzVDLE1BQU0sTUFBTSxhQUFhO0VBQ3pCLElBQUksYUFBYSxtQkFBbUIsR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUksYUFBYSxjQUFjLGNBQWMsR0FBRyxDQUFDO0NBQ25HLE9BQU8sSUFBSSxFQUFFLGVBQWUsTUFBTSxFQUFFLGFBQWEsSUFBSTtFQUNuRCxNQUFNLE1BQU0sYUFBYTtFQUN6QixJQUFJLGFBQWEsbUJBQW1CLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxJQUFJLGFBQWEsY0FBYyxjQUFjLEdBQUcsQ0FBQztDQUNuRyxPQUNFLElBQUksV0FBVyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksSUFBSSxXQUFXLGNBQWMsY0FBYyxVQUFVLENBQUM7QUFFaEc7OztBQ1pBLElBQU0sZUFBZTtDQUNuQixRQUFRO0NBQ1IsS0FBSztDQUNMLFFBQVE7QUFDVjtBQUNBLElBQUksZ0JBQWdDLGtCQUFFLG1CQUFtQjtDQUN2RCxlQUFlLGVBQWUsY0FBYyxLQUFLO0NBQ2pELGVBQWUsZUFBZSx3QkFBd0IsS0FBSztDQUMzRCxlQUFlLGVBQWUsaUJBQWlCLEtBQUs7Q0FDcEQsZUFBZSxlQUFlLHlCQUF5QixLQUFLO0NBQzVELGVBQWUsZUFBZSwyQkFBMkIsS0FBSztDQUM5RCxlQUFlLGVBQWUsVUFBVSxLQUFLO0NBQzdDLE9BQU87QUFDVCxFQUFBLENBQUcsaUJBQWlCLENBQUMsQ0FBQzs7O0FDWHRCLFNBQVMsMEJBQTBCLFdBQVcsZUFBZTtDQUMzRCxJQUFJLGNBQWMsY0FBYyx3QkFDOUIsT0FBTyxhQUFhLGNBQWM7Q0FFcEMsT0FBTztBQUNUOzs7QUNQQSxJQUFNLGVBQWU7Q0FDbkI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0YsQ0FBQyxDQUFDLEtBQUssSUFBSTtBQUNYLFNBQVMsa0JBQWtCLFFBQVE7Q0FDakMsSUFBSSxNQUFNO0NBQ1YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsRUFBRSxHQUFHO0VBQy9CLElBQUksSUFBSSxHQUNOLE9BQU87RUFFVCxJQUFJLElBQUksU0FBUyxHQUNmLE9BQU8sY0FBYyxFQUFFO0NBRTNCO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyw2QkFBNkIsUUFBUSxJQUFJO0NBQ2hELElBQUksV0FBVyxHQUNiLE1BQU0sSUFBSSxNQUFNLCtEQUErRDtDQUVqRixNQUFNLFNBQVMsR0FBRyxhQUFhLEdBQUcsZUFBZTtDQUNqRCxJQUFJO0VBQ0YsT0FBTyxNQUFNO0dBQ1gsTUFBTSxjQUFjLGFBQWEsUUFBUSxlQUFlLGtCQUFrQixNQUFNLENBQUM7R0FDakYsR0FBRyxhQUFhLFFBQVEsV0FBVztHQUNuQyxHQUFHLGNBQWMsTUFBTTtHQUN2QixJQUFJLENBQUMsR0FBRyxtQkFBbUIsUUFBUSxHQUFHLGNBQWMsR0FDbEQsU0FBUyxTQUFTLElBQUk7UUFFdEI7RUFFSjtDQUNGLFVBQVU7RUFDUixHQUFHLGFBQWEsTUFBTTtDQUN4QjtDQUNBLE9BQU87QUFDVDs7O0FDckNBLElBQUksMkJBQTJCO0FBQy9CLFNBQVMseUJBQXlCO0NBQ2hDLElBQUksMEJBQTBCLE9BQU87Q0FDckMsTUFBTSxLQUFLLGVBQWU7Q0FDMUIsMkJBQTJCLEdBQUcsYUFBYSxHQUFHLHVCQUF1QjtDQUNyRSwyQkFBMkIsNkJBQ3pCLDBCQUNBLEVBQ0Y7Q0FDQSxHQUFHLGFBQWEsb0JBQW9CLENBQUMsRUFBRSxZQUFZO0NBQ25ELE9BQU87QUFDVDs7O0FDZEEsSUFBTSxvQkFBTixNQUF3QjtDQUN0QixjQUFjOztFQUVaLEtBQUssTUFBc0IsdUJBQU8sT0FBTyxJQUFJO0VBQzdDLEtBQUssV0FBVyxDQUFDO0VBQ2pCLEtBQUssUUFBUTtDQUNmOztDQUVBLFFBQVE7RUFDTixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxPQUFPLEtBQUs7R0FDbkMsTUFBTSxJQUFJLEtBQUssU0FBUztHQUN4QixLQUFLLFNBQVMsS0FBSztHQUNuQixLQUFLLElBQUksRUFBRSxPQUFPO0VBQ3BCO0VBQ0EsS0FBSyxRQUFRO0NBQ2Y7QUFDRjs7O0FDUEEsSUFBTSxRQUFOLE1BQVk7Q0FDVixjQUFjO0VBQ1osS0FBSyxlQUFlO0VBQ3BCLEtBQUssU0FBUztFQUtkLEtBQUssUUFBUTtFQUNiLEtBQUssT0FBTztFQUNaLEtBQUssV0FBVyxJQUFJLGtCQUFrQjtFQUN0QyxLQUFLLFlBQVk7RUFDakIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssWUFBWTtDQUNuQjtDQUNBLFVBQVU7RUFDUixLQUFLLFdBQVc7RUFDaEIsS0FBSyxlQUFlO0VBQ3BCLEtBQUssWUFBWTtFQUNqQixLQUFLLFVBQVU7RUFDZixLQUFLLFdBQVc7Q0FDbEI7QUFDRjtBQUNBLElBQU0sWUFBWSxDQUFDO0FBQ25CLElBQUksaUJBQWlCO0FBQ3JCLHVCQUF1QixTQUFTLEVBQzlCLGFBQWE7Q0FDWCxJQUFJLFVBQVUsU0FBUyxHQUNoQjtPQUFBLE1BQU0sUUFBUSxXQUNqQixJQUFJLE1BQU0sS0FBSyxRQUFRO0NBQUE7Q0FHM0IsVUFBVSxTQUFTO0NBQ25CLGlCQUFpQjtBQUNuQixFQUNGLENBQUM7QUFDRCxTQUFTLG1CQUFtQjtDQUMxQixPQUFPLGlCQUFpQixJQUFJLFVBQVUsRUFBRSxrQkFBa0IsSUFBSSxNQUFNO0FBQ3RFO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTztDQUNoQyxNQUFNLFdBQVc7Q0FDakIsVUFBVSxvQkFBb0I7QUFDaEM7QUFDQSxJQUFJLGFBQWE7QUFDakIsSUFBTSxXQUFXLE1BQU0sU0FBUztDQUM5QixZQUFZLFNBQVM7O0VBRW5CLEtBQUssTUFBTSxJQUFJLFNBQVM7O0VBRXhCLEtBQUssUUFBUTs7RUFFYixLQUFLLGFBQWE7O0VBRWxCLEtBQUssVUFBVSxDQUFDO0VBQ2hCLEtBQUssWUFBWSxDQUFDO0VBQ2xCLFVBQVU7R0FBRSxHQUFHLFNBQVM7R0FBZ0IsR0FBRztFQUFRO0VBQ25ELElBQUksQ0FBQyxRQUFRLGFBQWE7R0FDeEIsWUFBWSxVQUFVLGlGQUFpRjtHQUN2RyxRQUFRLGNBQWMsdUJBQXVCO0VBQy9DO0VBQ0EsTUFBTSxFQUFFLGFBQWEsdUJBQXVCLHVCQUF1QjtFQUNuRSxLQUFLLGtCQUFrQixJQUFJLGVBQWUsd0JBQXdCLENBQUM7RUFDbkUsS0FBSyxjQUFjLElBQUksWUFBWSxrQkFBa0I7RUFDckQsS0FBSyxjQUFjO0NBQ3JCO0NBQ0EsUUFBUTtFQUNOLEtBQUssY0FBYztFQUNuQixLQUFLLGVBQWU7RUFDcEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFlBQVksS0FDbkMsa0JBQWtCLEtBQUssUUFBUSxFQUFFO0VBRW5DLEtBQUssYUFBYTtFQUNsQixLQUFLLG1CQUFtQjtFQUN4QixLQUFLLGtCQUFrQjtFQUN2QixLQUFLLFFBQVE7Q0FDZjtDQUNBLElBQUksaUJBQWlCO0VBQ25CLEtBQUssVUFBVSxLQUFLLGlCQUFpQjtFQUNyQyxnQkFBZ0IsY0FBYyxLQUFLO0VBQ25DLGdCQUFnQixrQkFBa0IsS0FBSztFQUN2QyxnQkFBZ0IsV0FBVztFQUMzQixLQUFLLGFBQWEsZ0JBQWdCO0VBQ2xDLEtBQUssaUJBQWlCLGdCQUFnQixnQkFBZ0IsS0FBSztDQUM3RDtDQUNBLHNCQUFzQixpQkFBaUIsU0FBUztFQUM5QyxNQUFNLFlBQVksZ0JBQWdCLE9BQU8sU0FBUyxJQUFJLFFBQVEsUUFBUTtFQUN0RSxJQUFJLENBQUMsYUFBYSxjQUFjLEdBQUcsT0FBTztFQUMxQyxnQkFBZ0IsYUFBYTtFQUM3QixnQkFBZ0IsVUFBVTtFQUMxQixPQUFPO0NBQ1Q7Q0FDQSxjQUFjLGlCQUFpQjtFQUM3QixLQUFLLFFBQVE7RUFDYixNQUFNLGtCQUFrQixLQUFLO0VBQzdCLElBQUksZ0JBQWdCLFlBQ2xCLEtBQUssbUJBQ0gsaUJBQ0EsZ0JBQWdCLGFBQ2hCLGdCQUFnQixZQUNoQixnQkFBZ0IsaUJBQ2hCLGdCQUFnQixVQUNsQjtPQUVBLEtBQUssZUFDSCxpQkFDQSxnQkFBZ0IsYUFDaEIsZ0JBQWdCLFlBQ2hCLGdCQUFnQixpQkFDaEIsZ0JBQWdCLFVBQ2xCO0NBRUo7Ozs7OztDQU1BLE1BQU0sZ0JBQWdCO0VBQ3BCLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLElBQUksQ0FBQyxTQUFTLEtBQUssZUFBZTtFQUNsQyxJQUFJLFFBQVEsaUJBQWlCO0VBQzdCLElBQUksZUFBZSxNQUFNO0VBQ3pCLGFBQWEsTUFBTTtFQUNuQixNQUFNLGVBQWUsU0FBUyxLQUFLO0VBQ25DLElBQUksWUFBWSwwQkFBMEIsYUFBYSxXQUFXLGFBQWEsUUFBUSxPQUFPO0VBQzlGLElBQUksV0FBVyxhQUFhO0VBQzVCLElBQUksS0FBSyxnQkFBZ0IsSUFBSSxLQUFLLGdCQUFnQixNQUNoRCxLQUFLLHVCQUF1QixLQUFLLGdCQUFnQixDQUFDO0VBRXBELElBQUksS0FBSyxZQUFZLEtBQUssWUFBWSxRQUNwQyxLQUFLLG1CQUFtQixLQUFLLFNBQVM7RUFFeEMsTUFBTSxNQUFNLEtBQUssZ0JBQWdCO0VBQ2pDLE1BQU0sTUFBTSxLQUFLLGdCQUFnQjtFQUNqQyxNQUFNLGNBQWMsS0FBSztFQUN6QixJQUFJLE9BQU8sS0FBSztFQUNoQixJQUFJLFFBQVEsS0FBSztFQUNqQixJQUFJLFNBQVM7RUFDYixJQUFJLGdCQUFnQixDQUFDO0VBQ3JCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLEtBQUssSUFBSSxJQUFJLEtBQUssY0FBYyxJQUFJLEtBQUssYUFBYSxFQUFFLEdBQUc7R0FDekQsTUFBTSxVQUFVLFNBQVM7R0FDekIsU0FBUyxLQUFLO0dBRWQsTUFBTSxTQURVLFFBQVEsUUFDRDtHQUN2QixNQUFNLG9CQUFvQiwwQkFBMEIsUUFBUSxXQUFXLE1BQU07R0FDN0UsTUFBTSxnQkFBZ0IsY0FBYyxxQkFBcUIsYUFBYSxRQUFRO0dBQzlFLElBQUksT0FBTyxlQUFlLGNBQWMsQ0FBQyxlQUFlO0lBQ3RELFFBQVEsYUFBYSxPQUFPO0lBQzVCLFFBQVEsUUFBUTtJQUNoQixJQUFJLFFBQVEsWUFBWTtLQUN0QixLQUFLLG1CQUNILFNBQ0EsS0FDQSxLQUNBLFFBQVEsaUJBQ1IsUUFBUSxVQUNWO0tBQ0EsS0FBSyxjQUNILGFBQ0EsUUFBUSxhQUNSLFFBQVEsa0JBQWtCLEtBQUssVUFDakM7SUFDRixPQUFPO0tBQ0wsS0FBSyxlQUNILFNBQ0EsS0FDQSxLQUNBLFFBQVEsaUJBQ1IsUUFBUSxVQUNWO0tBQ0EsS0FBSyxVQUNILFNBQ0EsYUFDQSxRQUFRLGFBQ1IsUUFBUSxrQkFBa0IsS0FBSyxVQUNqQztJQUNGO0lBQ0EsUUFBUSxTQUFTO0lBQ2pCLGNBQWMsS0FBSyxPQUFPO0lBQzFCO0dBQ0Y7R0FDQSxPQUFPLGFBQWE7R0FDcEIsSUFBSSxhQUFhLFNBQVMsZUFBZSxlQUFlO0lBQ3RELEtBQUssYUFDSCxPQUNBLE9BQ0EsT0FBTyxPQUNQLGNBQ0EsV0FDQSxVQUNBLGdCQUNBLFFBQ0EsYUFDRjtJQUNBLFNBQVM7SUFDVCxRQUFRO0lBQ1IsWUFBWTtJQUNaLFdBQVcsUUFBUTtJQUNuQixRQUFRLGlCQUFpQjtJQUN6QixlQUFlLE1BQU07SUFDckIsYUFBYSxNQUFNO0lBQ25CLGdCQUFnQixDQUFDO0lBQ2pCLEVBQUU7R0FDSjtHQUNBLFFBQVEsYUFBYSxPQUFPLHVCQUF1QixhQUFhO0dBQ2hFLGFBQWEsSUFBSSxPQUFPLE9BQU8sYUFBYTtHQUM1QyxhQUFhLFNBQVMsYUFBYSxXQUFXO0dBQzlDLFFBQVEsU0FBUztHQUNqQixjQUFjLEtBQUssT0FBTztHQUMxQixRQUFRLFFBQVE7R0FDaEIsSUFBSSxRQUFRLFlBQVk7SUFDdEIsS0FBSyxtQkFDSCxTQUNBLEtBQ0EsS0FDQSxRQUFRLGlCQUNSLFFBQVEsVUFDVjtJQUNBLEtBQUssY0FDSCxhQUNBLFFBQVEsYUFDUixRQUFRLGtCQUFrQixLQUFLLFVBQ2pDO0dBQ0YsT0FBTztJQUNMLEtBQUssZUFDSCxTQUNBLEtBQ0EsS0FDQSxRQUFRLGlCQUNSLFFBQVEsVUFDVjtJQUNBLEtBQUssVUFDSCxTQUNBLGFBQ0EsUUFBUSxhQUNSLFFBQVEsa0JBQWtCLEtBQUssVUFDakM7R0FDRjtFQUNGO0VBQ0EsSUFBSSxhQUFhLFFBQVEsR0FBRztHQUMxQixLQUFLLGFBQ0gsT0FDQSxPQUNBLE9BQU8sT0FDUCxjQUNBLFdBQ0EsVUFDQSxnQkFDQSxRQUNBLGFBQ0Y7R0FDQSxRQUFRO0dBQ1IsRUFBRTtFQUNKO0VBQ0EsS0FBSyxlQUFlLEtBQUs7RUFDekIsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxrQkFBa0I7Q0FDekI7Q0FDQSxhQUFhLE9BQU8sWUFBWSxXQUFXLGNBQWMsV0FBVyxVQUFVLGdCQUFnQixRQUFRLFVBQVU7RUFDOUcsTUFBTSxlQUFlO0VBQ3JCLE1BQU0sWUFBWTtFQUNsQixNQUFNLFNBQVM7RUFDZixNQUFNLFVBQVU7RUFDaEIsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sWUFBWTtFQUNsQixNQUFNLFdBQVc7RUFDakIsTUFBTSxRQUFRO0VBQ2QsTUFBTSxPQUFPO0VBQ2IsTUFBTSxXQUFXO0VBQ2pCLEVBQUU7RUFDRixLQUFLLFFBQVEsS0FBSyxnQkFBZ0I7RUFDbEMsZUFBZSxJQUFJLEtBQUs7Q0FDMUI7Q0FDQSxPQUFPLGdCQUFnQjtFQUNyQixLQUFLLE1BQU0sY0FBYztDQUMzQjs7Ozs7Q0FLQSxzQkFBc0IsTUFBTTtFQUMxQixJQUFJLE9BQU8sS0FBSyxLQUFLLGdCQUFnQixNQUFNO0VBQzNDLEtBQUssdUJBQXVCLE9BQU8sQ0FBQztDQUN0Qzs7Ozs7Q0FLQSxrQkFBa0IsTUFBTTtFQUN0QixJQUFJLFFBQVEsS0FBSyxZQUFZLFFBQVE7RUFDckMsS0FBSyxtQkFBbUIsSUFBSTtDQUM5QjtDQUNBLHVCQUF1QixNQUFNO0VBRTNCLE1BQU0saUJBQWlCLElBQUksZUFEWCxLQUFLLElBQUksTUFBTSxLQUFLLGdCQUFnQixPQUFPLENBQ2pCLENBQU87RUFDakQsU0FBUyxLQUFLLGdCQUFnQixlQUFlLGVBQWUsYUFBYTtFQUN6RSxLQUFLLGtCQUFrQjtDQUN6QjtDQUNBLG1CQUFtQixNQUFNO0VBQ3ZCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLElBQUksVUFBVSxLQUFLLElBQUksTUFBTSxZQUFZLFNBQVMsR0FBRztFQUNyRCxXQUFXLFVBQVU7RUFDckIsTUFBTSxpQkFBaUIsVUFBVSxRQUFRLElBQUksWUFBWSxPQUFPLElBQUksSUFBSSxZQUFZLE9BQU87RUFDM0YsSUFBSSxlQUFlLHNCQUFzQixZQUFZLG1CQUNuRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxRQUFRLEtBQ3RDLGVBQWUsS0FBSyxZQUFZO09BR2xDLFNBQVMsWUFBWSxRQUFRLGVBQWUsTUFBTTtFQUVwRCxLQUFLLGNBQWM7Q0FDckI7Q0FDQSxjQUFjLGFBQWEsT0FBTyxlQUFlO0VBQy9DLFlBQVksU0FBUyxnQkFBZ0I7RUFDckMsWUFBWSxRQUFRLEtBQUssZ0JBQWdCO0VBQ3pDLFlBQVksUUFBUSxLQUFLLGdCQUFnQjtFQUN6QyxZQUFZLFFBQVEsS0FBSyxnQkFBZ0I7RUFDekMsWUFBWSxRQUFRLEtBQUssZ0JBQWdCO0VBQ3pDLFlBQVksUUFBUSxLQUFLLGdCQUFnQjtDQUMzQztDQUNBLFVBQVUsU0FBUyxhQUFhLE9BQU8sZUFBZTtFQUNwRCxNQUFNLFVBQVUsUUFBUTtFQUN4QixNQUFNLE9BQU8sUUFBUTtFQUNyQixNQUFNLGNBQWMsUUFBUTtFQUM1QixNQUFNLGtCQUFrQixRQUFRO0VBQ2hDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQ3hCLFlBQVksV0FBVyxnQkFBZ0IsUUFBUSxJQUFJLGVBQWU7Q0FFdEU7Ozs7OztDQU1BLFFBQVEsVUFBVSxDQUFDLEdBQUc7RUFDcEIsSUFBSSxLQUFLLFlBQVksTUFBTTtFQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxZQUFZLEtBQ25DLGtCQUFrQixLQUFLLFFBQVEsRUFBRTtFQUVuQyxLQUFLLFVBQVU7RUFDZixLQUFLLFNBQVMsUUFBUSxJQUFJO0VBQzFCLEtBQUssV0FBVztFQUNoQixJQUFJLFFBQVEsUUFBUTtHQUNsQixLQUFLLFFBQVEsUUFBUTtHQUNyQixLQUFLLFNBQVM7RUFDaEI7RUFDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxVQUFVLFFBQVEsS0FDekMsSUFBSSxLQUFLLFVBQVUsSUFBSSxLQUFLLFVBQVUsRUFBRSxDQUFDLFNBQVM7RUFFcEQsS0FBSyxZQUFZO0VBQ2pCLEtBQUssY0FBYztFQUNuQixLQUFLLGdCQUFnQixRQUFRO0VBQzdCLEtBQUssa0JBQWtCO0NBQ3pCO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQjtDQUN4QixhQUFhO0NBQ2IsdUJBQXVCO0NBQ3ZCLG9CQUFvQjtBQUN0QjtBQUNBLElBQUksVUFBVTs7O0FDaFhkLElBQU0sd0NBQXdCLElBQUksYUFBYSxDQUFDO0FBQ2hELElBQU0sdUNBQXVCLElBQUksWUFBWSxDQUFDO0FBQzlDLElBQU0sZ0JBQU4sY0FBNEIsU0FBUztDQUNuQyxjQUFjO0VBRVosTUFBTSxrQkFBa0IsSUFBSSxPQUFPO0dBQ2pDLE1BQU07R0FDTixPQUFPO0dBQ1AsT0FBTyxZQUFZLFNBQVMsWUFBWTtHQUN4QyxhQUFhO0VBQ2YsQ0FBQztFQUNELE1BQU0sY0FBYyxJQUFJLE9BQU87R0FDN0IsTUFBTTtHQUNOLE9BQU87R0FDUCxPQUFPLFlBQVksUUFBUSxZQUFZO0dBRXZDLGFBQWE7RUFDZixDQUFDO0VBQ0QsTUFBTSxTQUFTO0VBQ2YsTUFBTTtHQUNKLFlBQVk7SUFDVixXQUFXO0tBQ1QsUUFBUTtLQUNSLFFBQVE7S0FDUjtLQUNBLFFBQVE7SUFDVjtJQUNBLEtBQUs7S0FDSCxRQUFRO0tBQ1IsUUFBUTtLQUNSO0tBQ0EsUUFBUTtJQUNWO0lBQ0EsUUFBUTtLQUNOLFFBQVE7S0FDUixRQUFRO0tBQ1I7S0FDQSxRQUFRO0lBQ1Y7SUFDQSxvQkFBb0I7S0FDbEIsUUFBUTtLQUNSLFFBQVE7S0FDUjtLQUNBLFFBQVE7SUFDVjtHQUNGO0dBQ0E7RUFDRixDQUFDO0NBQ0g7QUFDRjs7O0FDbkRBLFNBQVMsUUFBUSxVQUFVLE9BQU8sTUFBTTtDQUN0QyxJQUFJLFVBQ0YsS0FBSyxNQUFNLEtBQUssVUFBVTtFQUV4QixNQUFNLE9BQU8sTUFERixFQUFFLGtCQUNPO0VBQ3BCLElBQUksTUFBTTtHQUNSLElBQUksZ0JBQWdCLFNBQVM7R0FDN0IsSUFBSSxNQUFNLFVBQ1IsZ0JBQWdCLGNBQWMsUUFBUSxvQkFBb0IsRUFBRSxDQUFDLENBQUMsUUFBUSxxQkFBcUIsRUFBRTtHQUUvRixJQUFJLE1BQ0YsS0FBSyxLQUFLLFNBQVMsS0FBSyxPQUFPO0dBRWpDLEtBQUssS0FBSyxhQUFhO0VBQ3pCLE9BQ0UsS0FBSyxHQUFHLEVBQUUseUNBQXlDO0NBRXZEO0FBRUo7OztBQ3JCQSxJQUFNLGNBQWM7QUFDcEIsU0FBUyxhQUFhLFlBQVk7Q0FDaEMsTUFBTSxRQUFRLENBQUM7Q0FFZixDQURvQixXQUFXLE1BQU0sV0FBVyxDQUFDLEVBQUUsS0FBSyxTQUFTLEtBQUssUUFBUSxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBQSxDQUN0RixTQUFTLFNBQVM7RUFDNUIsTUFBTSxRQUFRLENBQUM7Q0FDakIsQ0FBQztDQUNELE9BQU87QUFDVDs7O0FDUkEsU0FBUyxjQUFjLGdCQUFnQixLQUFLO0NBQzFDLElBQUk7Q0FDSixNQUFNLFFBQVE7Q0FDZCxRQUFRLFFBQVEsTUFBTSxLQUFLLGNBQWMsT0FBTyxNQUM5QyxJQUFJLEtBQUssTUFBTSxFQUFFO0FBRXJCO0FBQ0EsU0FBUyxjQUFjLFdBQVcsVUFBVSxPQUFPLE9BQU87Q0FDeEQsTUFBTSxVQUFVLENBQUM7Q0FDakIsY0FBYyxVQUFVLE9BQU87Q0FDL0IsVUFBVSxTQUFTLGFBQWE7RUFDOUIsSUFBSSxTQUFTLFFBQ1gsY0FBYyxTQUFTLFFBQVEsT0FBTztDQUUxQyxDQUFDO0NBQ0QsTUFBTSxZQUFZO0NBQ2xCLElBQUksTUFDRixVQUFVLEtBQUs7Q0FFakIsTUFBTSxjQUFjLFVBQVUsS0FBSyxTQUFTLE1BQU0sb0JBQW9CLEVBQUUsSUFBSSxRQUFRLEVBQUUsQ0FBQyxDQUFDLEtBQUssSUFBSTtDQUNqRyxJQUFJLGdCQUFnQixTQUFTLFFBQVEsb0JBQW9CLEVBQUU7Q0FDM0QsZ0JBQWdCLGNBQWMsUUFBUSxVQUFVO0VBQ2hELFlBQVk7Q0FDYjtDQUNDLE9BQU87QUFDVDs7O0FDekJBLFNBQVMsZUFBZSxnQkFBZ0IsS0FBSztDQUMzQyxJQUFJO0NBQ0osTUFBTSxRQUFRO0NBQ2QsUUFBUSxRQUFRLE1BQU0sS0FBSyxjQUFjLE9BQU8sTUFDOUMsSUFBSSxLQUFLLE1BQU0sRUFBRTtBQUVyQjtBQUNBLFNBQVMsb0JBQW9CLE9BQU87Q0FFbEMsTUFBTSxRQUFRLGVBQU0sS0FBSyxLQUFLO0NBQzlCLE9BQU8sUUFBUSxNQUFNLEtBQUs7QUFDNUI7QUFDQSxTQUFTLGNBQWMsT0FBTztDQUU1QixPQUFPLE1BQU0sUUFBUSxZQUFPLEVBQUU7QUFDaEM7QUFDQSxTQUFTLGVBQWUsV0FBVyxVQUFVO0NBQzNDLE1BQU0sVUFBVSxDQUFDO0NBQ2pCLGVBQWUsVUFBVSxPQUFPO0NBQ2hDLFVBQVUsU0FBUyxhQUFhO0VBQzlCLElBQUksU0FBUyxRQUNYLGVBQWUsU0FBUyxRQUFRLE9BQU87Q0FFM0MsQ0FBQztDQUNELElBQUksUUFBUTtDQUNaLE1BQU0sYUFBYSxRQUFRLEtBQUssQ0FBQyxDQUFDLEtBQUssWUFBWTtFQUNqRCxJQUFJLFFBQVEsUUFBUSxTQUFTLElBQUksSUFDL0IsT0FBTztFQUVULE9BQU8sYUFBYSxRQUFRLElBQUk7Q0FDbEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLO0NBQ2IsTUFBTSxZQUFZLFFBQVEsS0FBSyxDQUFDLENBQUMsS0FBSyxZQUFZLGNBQWMsY0FBYyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQ3BHLE1BQU0sVUFBVTtjQUNKLFFBQVEsS0FBSyxDQUFDLENBQUMsS0FBSyxZQUFZLElBQUksb0JBQW9CLE9BQU8sR0FBRyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7Q0FDNUYsSUFBSSxlQUFlLFNBQVMsUUFBUSxxQkFBcUIsRUFBRTtDQUMzRCxlQUFlLGFBQWEsUUFBUSxjQUFjO0VBQ2xELFdBQVc7Q0FDWjtDQUNDLGVBQWUsYUFBYSxRQUFRLGFBQWE7RUFDakQsVUFBVTtDQUNYO0NBQ0MsZUFBZSxhQUFhLFFBQVEsY0FBYztFQUNsRCxRQUFRO0NBQ1Q7Q0FDQyxPQUFPO0FBQ1Q7OztBQzdDQSxTQUFTLFdBQVcsYUFBYSxlQUFlO0NBQzlDLElBQUksTUFBTTtDQUNWLEtBQUssTUFBTSxLQUFLLGVBQWU7RUFDN0IsTUFBTSxRQUFRLGNBQWM7RUFFNUIsSUFEaUIsTUFBTSxLQUFLLElBQ2pCLENBQUMsQ0FBQyxRQUNYLE1BQU0sSUFBSSxRQUFRLEtBQUssRUFBRSxLQUFLLFVBQVUsRUFBRTtFQUM5QyxNQUFNLEtBQUssSUFBSSxFQUFFO1FBQ1gsRUFBRSxjQUFjO09BRWxCLE1BQU0sSUFBSSxRQUFRLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FFcEM7Q0FDQSxPQUFPO0FBQ1Q7OztBQ1JBLElBQU0sV0FBMkIsdUJBQU8sT0FBTyxJQUFJO0FBQ25ELElBQU0sOEJBQThCLElBQUksSUFBSTtBQUM1QyxJQUFJLFlBQVk7QUFDaEIsU0FBUyxrQkFBa0IsRUFDekIsVUFDQSxRQUNDO0NBQ0QsTUFBTSxVQUFVLGdCQUFnQixVQUFVLElBQUk7Q0FDOUMsSUFBSSxTQUFTLFVBQVUsT0FBTyxTQUFTO0NBQ3ZDLE1BQU0sRUFBRSxRQUFRLGFBQWEsd0JBQXdCLFVBQVUsSUFBSTtDQUNuRSxTQUFTLFdBQVcsWUFBWSxRQUFRLFVBQVUsSUFBSTtDQUN0RCxPQUFPLFNBQVM7QUFDbEI7QUFDQSxTQUFTLG9CQUFvQixFQUMzQixVQUNBLFFBQ0M7Q0FDRCxNQUFNLFVBQVUsZ0JBQWdCLFVBQVUsSUFBSTtDQUM5QyxJQUFJLFNBQVMsVUFBVSxPQUFPLFNBQVM7Q0FDdkMsU0FBUyxXQUFXLFlBQVksU0FBUyxRQUFRLFNBQVMsVUFBVSxJQUFJO0NBQ3hFLE9BQU8sU0FBUztBQUNsQjtBQUNBLFNBQVMsd0JBQXdCLFVBQVUsTUFBTTtDQUMvQyxNQUFNLGtCQUFrQixLQUFLLEtBQUssY0FBYyxVQUFVLE1BQU0sQ0FBQyxDQUFDLFFBQVEsTUFBTSxDQUFDLENBQUMsQ0FBQztDQUNuRixNQUFNLG9CQUFvQixLQUFLLEtBQUssY0FBYyxVQUFVLFFBQVEsQ0FBQyxDQUFDLFFBQVEsTUFBTSxDQUFDLENBQUMsQ0FBQztDQUN2RixJQUFJLGlCQUFpQixjQUFjLGlCQUFpQixTQUFTLFFBQVEsSUFBSTtDQUN6RSxpQkFBaUIsZUFBZSxpQkFBaUIsY0FBYztDQUMvRCxNQUFNLG1CQUFtQixjQUFjLG1CQUFtQixTQUFTLFVBQVUsSUFBSTtDQUNqRixPQUFPO0VBQ0wsUUFBUTtFQUNSLFVBQVU7Q0FDWjtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsVUFBVSxNQUFNO0NBQ3ZDLE9BQU8sS0FBSyxLQUFLLGlCQUFpQjtFQUNoQyxJQUFJLENBQUMsWUFBWSxJQUFJLFlBQVksR0FDL0IsWUFBWSxJQUFJLGNBQWMsV0FBVztFQUUzQyxPQUFPLFlBQVksSUFBSSxZQUFZO0NBQ3JDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksU0FBUyxTQUFTLFNBQVM7QUFDbEU7QUFDQSxTQUFTLFlBQVksUUFBUSxVQUFVLE1BQU07Q0FDM0MsTUFBTSxjQUFjLGFBQWEsTUFBTTtDQUN2QyxNQUFNLGdCQUFnQixhQUFhLFFBQVE7Q0FDM0MsS0FBSyxTQUFTLGNBQWM7RUFDMUIsUUFBUSxVQUFVLFFBQVEsYUFBYSxVQUFVLElBQUk7RUFDckQsUUFBUSxVQUFVLFVBQVUsZUFBZSxVQUFVLElBQUk7Q0FDM0QsQ0FBQztDQUNELE9BQU87RUFDTCxRQUFRLFdBQVcsUUFBUSxXQUFXO0VBQ3RDLFVBQVUsV0FBVyxVQUFVLGFBQWE7Q0FDOUM7QUFDRjs7O0FDMURBLElBQU0sb0JBRUo7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQThDRixJQUFNLHNCQUVKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF5QkYsSUFBTSxtQkFFSjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXNDRixJQUFNLHFCQUVKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNySEYsSUFBTSxvQkFBb0I7Q0FDeEIsTUFBTTtDQUNOLFFBQVEsRUFDTixRQUVFOzs7Ozs7Ozs7VUFXSjtBQUNGO0FBQ0EsSUFBTSx5QkFBeUI7Q0FDN0IsTUFBTTtDQUNOLFFBQVEsRUFDTixRQUVFOzs7Ozs7O1VBU0o7QUFDRjtBQUNBLElBQU0sc0JBQXNCO0NBQzFCLE1BQU07Q0FDTixRQUFRLEVBQ04sUUFFRTs7Ozs7VUFPSjtBQUNGOzs7QUN6Q0EsU0FBUyw0QkFBNEIsRUFBRSxNQUFNLFFBQVE7Q0FDbkQsTUFBTSxTQUFTLGtCQUFrQjtFQUMvQixVQUFVO0dBQ1IsVUFBVTtHQUNWLFFBQVE7RUFDVjtFQUNBLE1BQU0sQ0FDSixtQkFDQSxHQUFHLElBQ0w7Q0FDRixDQUFDO0NBQ0QsT0FBTyxXQUFXLEtBQUs7RUFDckI7RUFDQSxRQUFRO0dBQ04sUUFBUSxPQUFPO0dBQ2YsWUFBWTtFQUNkO0VBQ0EsVUFBVTtHQUNSLFFBQVEsT0FBTztHQUNmLFlBQVk7RUFDZDtDQUNGLENBQUM7QUFDSDtBQUNBLFNBQVMsMkJBQTJCLEVBQUUsTUFBTSxRQUFRO0NBQ2xELE9BQU8sSUFBSSxVQUFVO0VBQ25CO0VBQ0EsR0FBRyxvQkFBb0I7R0FDckIsVUFBVTtJQUNSLFFBQVE7SUFDUixVQUFVO0dBQ1o7R0FDQSxNQUFNLENBQ0oscUJBQ0EsR0FBRyxJQUNMO0VBQ0YsQ0FBQztDQUNILENBQUM7QUFDSDs7O0FDM0NBLElBQU0sV0FBVztDQUNmLE1BQU07Q0FDTixRQUFRO0VBQ04sUUFFRTs7O0VBSUYsTUFFRTs7O0NBSUo7QUFDRjtBQUNBLElBQU0sYUFBYTtDQUNqQixNQUFNO0NBQ04sUUFBUTtFQUNOLFFBRUU7OztFQUlGLE1BRUU7OztDQUlKO0FBQ0Y7OztBQ2pDQSxJQUFNLDBCQUEwQixDQUFDO0FBQ2pDLFNBQVMsbUJBQW1CLGFBQWE7Q0FDdkMsTUFBTSxNQUFNLENBQUM7Q0FDYixJQUFJLGdCQUFnQixHQUFHO0VBQ3JCLElBQUksS0FBSyw0REFBNEQ7RUFDckUsSUFBSSxLQUFLLHFEQUFxRDtDQUNoRSxPQUFPO0VBQ0wsSUFBSSxlQUFlO0VBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxhQUFhLEtBQUs7R0FDcEMsSUFBSSxLQUFLLHNCQUFzQixlQUFlLHFCQUFxQixJQUFJLEVBQUUsbUJBQW1CO0dBQzVGLElBQUksS0FBSyxzQkFBc0IsZUFBZSxzQkFBc0IsSUFBSSxFQUFFLFdBQVc7RUFDdkY7Q0FDRjtDQUNBLE9BQU8sSUFBSSxLQUFLLElBQUk7QUFDdEI7QUFDQSxTQUFTLGtCQUFrQixhQUFhO0NBQ3RDLE1BQU0sTUFBTSxDQUFDO0NBQ2IsSUFBSSxnQkFBZ0IsR0FDbEIsSUFBSSxLQUFLLGlGQUFpRjtNQUNyRjtFQUNMLElBQUksS0FBSyxxQkFBcUI7RUFDOUIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsS0FBSztHQUNwQyxJQUFJLE1BQU0sY0FBYyxHQUN0QixJQUFJLEtBQUssYUFBYTtRQUV0QixJQUFJLEtBQUssVUFBVSxFQUFFLEdBQUc7R0FFMUIsSUFBSSxLQUFLLG1EQUFtRCxJQUFJLEVBQUUsa0JBQWtCLElBQUksRUFBRSxvQkFBb0I7R0FDOUcsSUFBSSxLQUFLLGVBQWU7RUFDMUI7RUFDQSxJQUFJLEtBQUssR0FBRztDQUNkO0NBQ0EsT0FBTyxJQUFJLEtBQUssSUFBSTtBQUN0QjtBQUNBLFNBQVMsd0JBQXdCLGFBQWE7Q0FDNUMsSUFBSSxDQUFDLHdCQUF3QixjQUMzQix3QkFBd0IsZUFBZTtFQUNyQyxNQUFNO0VBQ04sUUFBUTtHQUNOLFFBQVE7Ozs7R0FJUixNQUFNOzs7R0FHTixLQUFLOzs7Ozs7RUFNUDtFQUNBLFVBQVU7R0FDUixRQUFROzs7a0JBR0UsbUJBQW1CLFdBQVcsRUFBRTs7R0FFMUMsTUFBTTs7OztrQkFJSSxrQkFBa0IsV0FBVyxFQUFFOztFQUUzQztDQUNGO0NBRUYsT0FBTyx3QkFBd0I7QUFDakM7QUFDQSxJQUFNLHlCQUF5QixDQUFDO0FBQ2hDLFNBQVMsb0JBQW9CLGFBQWE7Q0FDeEMsTUFBTSxNQUFNLENBQUM7Q0FDYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxLQUFLO0VBQ3BDLElBQUksSUFBSSxHQUNOLElBQUksS0FBSyxNQUFNO0VBRWpCLElBQUksSUFBSSxjQUFjLEdBQ3BCLElBQUksS0FBSyxtQkFBbUIsRUFBRSxJQUFJO0VBRXBDLElBQUksS0FBSyxHQUFHO0VBQ1osSUFBSSxLQUFLLGlDQUFpQyxFQUFFLFNBQVM7RUFDckQsSUFBSSxLQUFLLEdBQUc7Q0FDZDtDQUNBLE9BQU8sSUFBSSxLQUFLLElBQUk7QUFDdEI7QUFDQSxTQUFTLDBCQUEwQixhQUFhO0NBQzlDLElBQUksQ0FBQyx1QkFBdUIsY0FDMUIsdUJBQXVCLGVBQWU7RUFDcEMsTUFBTTtFQUNOLFFBQVE7R0FDTixRQUFROzs7OztHQUtSLE1BQU07OztHQUdOLEtBQUs7Ozs7OztFQU1QO0VBQ0EsVUFBVTtHQUNSLFFBQVE7Ozs4Q0FHOEIsWUFBWTs7O0dBR2xELE1BQU07O2tCQUVJLG9CQUFvQixXQUFXLEVBQUU7O0VBRTdDO0NBQ0Y7Q0FFRixPQUFPLHVCQUF1QjtBQUNoQzs7O0FDekhBLElBQU0saUJBQWlCO0NBQ3JCLE1BQU07Q0FDTixRQUFRLEVBQ04sUUFFRTs7Ozs7VUFPSjtBQUNGO0FBQ0EsSUFBTSxtQkFBbUI7Q0FDdkIsTUFBTTtDQUNOLFFBQVEsRUFDTixRQUVFOzs7OztVQU9KO0FBQ0Y7OztBQ3pCQSxJQUFNLGdDQUFnQyxDQUFDO0FBQ3ZDLFNBQVMsNkJBQTZCLGFBQWE7Q0FDakQsSUFBSSw0QkFBNEIsOEJBQThCO0NBQzlELElBQUksMkJBQTJCLE9BQU87Q0FDdEMsTUFBTSxlQUFlLElBQUksV0FBVyxXQUFXO0NBQy9DLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxhQUFhLEtBQy9CLGFBQWEsS0FBSztDQUVwQiw0QkFBNEIsOEJBQThCLGVBQWUsSUFBSSxhQUFhLEVBQ3hGLFdBQVc7RUFBRSxPQUFPO0VBQWMsTUFBTTtFQUFPLE1BQU07Q0FBWSxFQUNuRSxHQUFHLEVBQUUsVUFBVSxLQUFLLENBQUM7Q0FDckIsT0FBTztBQUNUOzs7QUNQQSxJQUFNLGdCQUFOLGNBQTRCLE9BQU87Q0FDakMsWUFBWSxhQUFhO0VBQ3ZCLE1BQU0sWUFBWSwyQkFBMkI7R0FDM0MsTUFBTTtHQUNOLE1BQU07SUFDSjtJQUNBLDBCQUEwQixXQUFXO0lBQ3JDO0dBQ0Y7RUFDRixDQUFDO0VBQ0QsTUFBTSxhQUFhLDRCQUE0QjtHQUM3QyxNQUFNO0dBQ04sTUFBTTtJQUNKO0lBQ0Esd0JBQXdCLFdBQVc7SUFDbkM7R0FDRjtFQUNGLENBQUM7RUFDRCxNQUFNO0dBQ0o7R0FDQTtHQUNBLFdBQVcsRUFDVCxlQUFlLDZCQUE2QixXQUFXLEVBQ3pEO0VBQ0YsQ0FBQztFQUNELEtBQUssY0FBYztDQUNyQjtBQUNGOzs7QUM3QkEsSUFBSSxnQkFBZ0I7QUFDcEIsSUFBTSxrQkFBa0IsTUFBTSx3QkFBd0IsUUFBUTtDQUM1RCxZQUFZLFNBQVM7RUFDbkIsTUFBTSxPQUFPO0VBQ2IsS0FBSyxXQUFXLElBQUksY0FBYztFQUNsQyxLQUFLLE9BQU8sZ0JBQWdCLFVBQVU7O0VBRXRDLEtBQUssYUFBYTtFQUNsQixrQkFBa0IsZ0JBQWdCLElBQUksY0FBYyxRQUFRLFdBQVc7RUFDdkUsS0FBSyxTQUFTO0NBQ2hCOzs7Ozs7Ozs7Q0FTQSxlQUFlLFNBQVMsYUFBYSxZQUFZLE9BQU8sV0FBVztFQUNqRSxNQUFNLG9CQUFvQixhQUFhLEtBQUssUUFBUSxjQUFjO0VBQ2xFLE1BQU0sS0FBSyxRQUFRO0VBQ25CLE1BQU0sSUFBSSxHQUFHO0VBQ2IsTUFBTSxJQUFJLEdBQUc7RUFDYixNQUFNLElBQUksR0FBRztFQUNiLE1BQU0sSUFBSSxHQUFHO0VBQ2IsTUFBTSxLQUFLLEdBQUc7RUFDZCxNQUFNLEtBQUssR0FBRztFQUNkLE1BQU0sRUFBRSxXQUFXLFFBQVE7RUFDM0IsTUFBTSxPQUFPLFFBQVE7RUFDckIsTUFBTSxTQUFTLFFBQVE7RUFDdkIsTUFBTSxNQUFNLFNBQVMsUUFBUTtFQUM3QixLQUFLLElBQUksSUFBSSxRQUFRLElBQUksS0FBSyxLQUFLO0dBQ2pDLE1BQU0sS0FBSyxJQUFJO0dBQ2YsTUFBTSxJQUFJLFVBQVU7R0FDcEIsTUFBTSxJQUFJLFVBQVUsS0FBSztHQUN6QixZQUFZLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSTtHQUN2QyxZQUFZLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSTtHQUN2QyxZQUFZLFdBQVcsSUFBSTtHQUMzQixZQUFZLFdBQVcsSUFBSSxLQUFLO0dBQ2hDLFdBQVcsV0FBVztHQUN0QixXQUFXLFdBQVc7RUFDeEI7Q0FDRjs7Ozs7Ozs7O0NBU0EsbUJBQW1CLFNBQVMsYUFBYSxZQUFZLE9BQU8sV0FBVztFQUNyRSxNQUFNLFVBQVUsUUFBUTtFQUN4QixNQUFNLEtBQUssUUFBUTtFQUNuQixNQUFNLElBQUksR0FBRztFQUNiLE1BQU0sSUFBSSxHQUFHO0VBQ2IsTUFBTSxJQUFJLEdBQUc7RUFDYixNQUFNLElBQUksR0FBRztFQUNiLE1BQU0sS0FBSyxHQUFHO0VBQ2QsTUFBTSxLQUFLLEdBQUc7RUFDZCxNQUFNLFNBQVMsUUFBUTtFQUN2QixNQUFNLEtBQUssT0FBTztFQUNsQixNQUFNLEtBQUssT0FBTztFQUNsQixNQUFNLEtBQUssT0FBTztFQUNsQixNQUFNLEtBQUssT0FBTztFQUNsQixNQUFNLE1BQU0sUUFBUTtFQUNwQixNQUFNLE9BQU8sUUFBUTtFQUNyQixNQUFNLG9CQUFvQixhQUFhLEtBQUssUUFBUSxjQUFjO0VBQ2xFLFlBQVksUUFBUSxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUs7RUFDM0MsWUFBWSxRQUFRLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSztFQUMzQyxZQUFZLFFBQVEsS0FBSyxJQUFJO0VBQzdCLFlBQVksUUFBUSxLQUFLLElBQUk7RUFDN0IsV0FBVyxRQUFRLEtBQUs7RUFDeEIsV0FBVyxRQUFRLEtBQUs7RUFDeEIsWUFBWSxRQUFRLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSztFQUMzQyxZQUFZLFFBQVEsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLO0VBQzNDLFlBQVksUUFBUSxLQUFLLElBQUk7RUFDN0IsWUFBWSxRQUFRLEtBQUssSUFBSTtFQUM3QixXQUFXLFFBQVEsTUFBTTtFQUN6QixXQUFXLFFBQVEsTUFBTTtFQUN6QixZQUFZLFFBQVEsTUFBTSxJQUFJLEtBQUssSUFBSSxLQUFLO0VBQzVDLFlBQVksUUFBUSxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUs7RUFDNUMsWUFBWSxRQUFRLE1BQU0sSUFBSTtFQUM5QixZQUFZLFFBQVEsTUFBTSxJQUFJO0VBQzlCLFdBQVcsUUFBUSxNQUFNO0VBQ3pCLFdBQVcsUUFBUSxNQUFNO0VBQ3pCLFlBQVksUUFBUSxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUs7RUFDNUMsWUFBWSxRQUFRLE1BQU0sSUFBSSxLQUFLLElBQUksS0FBSztFQUM1QyxZQUFZLFFBQVEsTUFBTSxJQUFJO0VBQzlCLFlBQVksUUFBUSxNQUFNLElBQUk7RUFDOUIsV0FBVyxRQUFRLE1BQU07RUFDekIsV0FBVyxRQUFRLE1BQU07Q0FDM0I7Ozs7OztDQU1BLG1CQUFtQixhQUFhO0VBQzlCLElBQUksS0FBSyxPQUFPLGdCQUFnQixhQUFhO0VBQzdDLGdCQUFnQixJQUFJLGNBQWMsV0FBVztFQUM3QyxLQUFLLFNBQVM7Q0FDaEI7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxTQUFTO0VBQ2QsTUFBTSxRQUFRO0NBQ2hCO0FBQ0Y7O0FBRUEsZ0JBQWdCLFlBQVk7Q0FDMUIsTUFBTSxDQUNKLGNBQWMsT0FDaEI7Q0FDQSxNQUFNO0FBQ1I7QUFDQSxJQUFJLGlCQUFpQjs7O0FDekhyQixJQUFNLGdCQUFOLE1BQW9CO0NBQ2xCLFlBQVksU0FBUztFQUVuQixLQUFLLFFBQXdCLHVCQUFPLE9BQU8sSUFBSTtFQUMvQyxNQUFNLEVBQUUsVUFBVSxNQUFNLFVBQVUsVUFBVSxTQUFTO0VBQ3JELEtBQUssWUFBWTtFQUNqQixTQUFTLEdBQUcsZ0JBQWdCLE1BQU0sU0FBUyxNQUFNLFlBQVksQ0FBQztFQUM5RCxLQUFLLFlBQVk7RUFDakIsS0FBSyxPQUFPO0NBQ2Q7Ozs7OztDQU1BLElBQUksTUFBTTtFQUNSLElBQUksS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPO0VBQ2pDLEtBQUssTUFBTSxLQUFLLE9BQU87RUFDdkIsS0FBSyxLQUFLLFVBQVUsS0FBSyxRQUFRLElBQUk7RUFDckMsS0FBSyxjQUFjLEtBQUssVUFBVSxHQUFHO0VBQ3JDLE9BQU87Q0FDVDtDQUNBLE9BQU8sTUFBTSxHQUFHLE1BQU07RUFDcEIsSUFBSSxDQUFDLEtBQUssTUFBTSxLQUFLLE1BQU07RUFDM0IsTUFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLFVBQVU7RUFDN0MsSUFBSSxDQUFDLFNBQVM7RUFDZCxLQUFLLFlBQVksTUFBTSxHQUFHLElBQUk7RUFDOUIsS0FBSyxJQUFJLFVBQVUsS0FBSyxRQUFRLElBQUk7RUFDcEMsUUFBUSxRQUFRO0VBQ2hCLEtBQUssU0FBUyxLQUFLLFVBQVUsT0FBTztFQUNwQyxLQUFLLE1BQU0sS0FBSyxPQUFPO0NBQ3pCO0NBQ0EsVUFBVSxHQUFHLE1BQU07RUFDakIsT0FBTyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsU0FBUyxTQUFTLFFBQVEsS0FBSyxPQUFPLE1BQU0sR0FBRyxJQUFJLENBQUM7Q0FDaEY7Q0FDQSxRQUFRLEdBQUcsTUFBTTtFQUNmLEtBQUssVUFBVSxHQUFHLElBQUk7RUFDdEIsS0FBSyxRQUF3Qix1QkFBTyxPQUFPLElBQUk7RUFDL0MsS0FBSyxZQUFZO0VBQ2pCLEtBQUssWUFBWTtDQUNuQjtBQUNGIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTYsMTcsMTgsMTksMjAsMjEsMjIsMjMsMjRdfQ==