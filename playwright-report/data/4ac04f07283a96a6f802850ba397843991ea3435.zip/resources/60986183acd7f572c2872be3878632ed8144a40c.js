import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/PauseScreen.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import styles from "/src/ui/components/PauseScreen.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/PauseScreen.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
export const PauseScreen = ({ onResume, onQuit }) => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: styles.overlay,
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: `${styles.card} responsive-card`,
			children: [/* @__PURE__ */ _jsxDEV("h1", {
				className: styles.title,
				children: "Paused"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 17
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: styles.buttonGroup,
				children: [/* @__PURE__ */ _jsxDEV("button", {
					className: styles.button,
					onClick: onResume,
					children: "Resume"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: styles.secondaryButton,
					onClick: onQuit,
					children: "Main Menu"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 17
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 9
	}, this);
};
_c = PauseScreen;
var _c;
$RefreshReg$(_c, "PauseScreen");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/PauseScreen.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/PauseScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/PauseScreen.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/PauseScreen.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sWUFBWTs7O0FBT25CLE9BQU8sTUFBTSxlQUEyQyxFQUFFLFVBQVUsYUFBYTtDQUM3RSxPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFXLE9BQU87WUFDbkIsd0JBQUMsT0FBRDtHQUFLLFdBQVcsR0FBRyxPQUFPLEtBQUs7YUFBL0IsQ0FDSSx3QkFBQyxNQUFEO0lBQUksV0FBVyxPQUFPO2NBQU87R0FBVTs7OzthQUV2Qyx3QkFBQyxPQUFEO0lBQUssV0FBVyxPQUFPO2NBQXZCLENBQ0ksd0JBQUMsVUFBRDtLQUFRLFdBQVcsT0FBTztLQUFRLFNBQVM7ZUFBVTtJQUU3Qzs7OztjQUNSLHdCQUFDLFVBQUQ7S0FBUSxXQUFXLE9BQU87S0FBaUIsU0FBUztlQUFRO0lBRXBEOzs7O1lBQ1A7Ozs7O1dBQ0o7Ozs7OztDQUNKOzs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBhdXNlU2NyZWVuLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4vUGF1c2VTY3JlZW4ubW9kdWxlLmNzcyc7XHJcblxyXG5pbnRlcmZhY2UgUGF1c2VTY3JlZW5Qcm9wcyB7XHJcbiAgICBvblJlc3VtZTogKCkgPT4gdm9pZDtcclxuICAgIG9uUXVpdDogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IFBhdXNlU2NyZWVuOiBSZWFjdC5GQzxQYXVzZVNjcmVlblByb3BzPiA9ICh7IG9uUmVzdW1lLCBvblF1aXQgfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm92ZXJsYXl9PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7c3R5bGVzLmNhcmR9IHJlc3BvbnNpdmUtY2FyZGB9PlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT17c3R5bGVzLnRpdGxlfT5QYXVzZWQ8L2gxPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuYnV0dG9uR3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPXtzdHlsZXMuYnV0dG9ufSBvbkNsaWNrPXtvblJlc3VtZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlc3VtZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPXtzdHlsZXMuc2Vjb25kYXJ5QnV0dG9ufSBvbkNsaWNrPXtvblF1aXR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBNYWluIE1lbnVcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn07XHJcbiJdfQ==