import { G as Texture, H as warn, I as InstructionSet, L as multiplyHexColors, N as DOMAdapter, R as BigPool, U as Color, W as Bounds, X as definedProps, _t as ExtensionType, ct as uid, dt as Matrix, ft as Point, gt as eventemitter3_default, lt as Rectangle, nt as deprecation, ot as v8_3_4, rt as v8_0_0, vt as extensions } from "/node_modules/.vite/deps/CanvasPool-BcIVNj8Y.js?v=43418a0e";
import { r as ImageSource } from "/node_modules/.vite/deps/canvasUtils-BdSlPf1K.js?v=43418a0e";
import { t as getTextureBatchBindGroup } from "/node_modules/.vite/deps/getTextureBatchBindGroup-DISaQ51W.js?v=43418a0e";
import { n as DefaultBatcher, t as GCManagedHash } from "/node_modules/.vite/deps/GCManagedHash-BlELPMdI.js?v=43418a0e";
//#region node_modules/earcut/src/earcut.js
/**
* A vertex in a circular doubly linked list representing a polygon ring.
* `prev`/`next` are always linked (set immediately after {@link createNode}), so they're typed
* non-null; `prevZ`/`nextZ` are the z-order list links and are null at the ends.
*
* @typedef {object} Node
* @property {number} i vertex index in the coordinates array
* @property {number} x vertex x coordinate
* @property {number} y vertex y coordinate
* @property {Node} prev previous vertex node in the polygon ring
* @property {Node} next next vertex node in the polygon ring
* @property {number} z z-order curve value; doubles as the owning block index during eliminateHoles
* @property {Node | null} prevZ previous node in z-order
* @property {Node | null} nextZ next node in z-order
*/
/** @type {Set<Node>} */
var steiners = /* @__PURE__ */ new Set();
var filteredOut = false;
/**
* Triangulate a polygon given as a flat array of vertex coordinates.
*
* @param {ArrayLike<number>} data flat array of vertex coordinates
* @param {ArrayLike<number> | null} [holeIndices] indices (in vertices, not coordinates) where each hole ring starts
* @param {number} [dim=2] number of coordinates per vertex in `data`
* @returns {number[]} triangles as triplets of vertex indices into `data`
* @example earcut([10,0, 0,50, 60,60, 70,10]); // [1,0,3, 3,2,1]
*/
function earcut$1(data, holeIndices, dim = 2) {
	const hasHoles = holeIndices && holeIndices.length;
	const outerLen = hasHoles ? holeIndices[0] * dim : data.length;
	if (steiners.size) steiners.clear();
	let outerNode = linkedList(data, 0, outerLen, dim, true);
	/** @type {number[]} */
	const triangles = [];
	if (!outerNode || outerNode.next === outerNode.prev) return triangles;
	let minX = 0, minY = 0, invSize = 0;
	if (hasHoles) outerNode = eliminateHoles(data, holeIndices, outerNode, dim);
	if (data.length > 80 * dim) {
		minX = data[0];
		minY = data[1];
		let maxX = minX;
		let maxY = minY;
		for (let i = dim; i < outerLen; i += dim) {
			const x = data[i];
			const y = data[i + 1];
			if (x < minX) minX = x;
			if (y < minY) minY = y;
			if (x > maxX) maxX = x;
			if (y > maxY) maxY = y;
		}
		invSize = Math.max(maxX - minX, maxY - minY);
		invSize = invSize !== 0 ? 32767 / invSize : 0;
	}
	earcutLinked(outerNode, triangles, minX, minY, invSize);
	return triangles;
}
/** @param {ArrayLike<number>} data @param {number} start @param {number} end @param {number} dim @param {boolean} clockwise @returns {Node | null} */
function linkedList(data, start, end, dim, clockwise) {
	/** @type {Node | null} */
	let last = null;
	if (clockwise === signedArea(data, start, end, dim) > 0) for (let i = start; i < end; i += dim) last = insertNode(i / dim | 0, data[i], data[i + 1], last);
	else for (let i = end - dim; i >= start; i -= dim) last = insertNode(i / dim | 0, data[i], data[i + 1], last);
	if (last && equals(last, last.next)) {
		removeNode(last);
		last = last.next;
	}
	return last;
}
/** @param {Node} start @param {Node} [end] @returns {Node} */
function filterPoints(start, end = start) {
	const full = end === start;
	let p = start, again;
	do {
		again = false;
		if (p !== p.next && (steiners.size === 0 || !steiners.has(p)) && (equals(p, p.next) || area(p.prev, p, p.next) === 0)) {
			if (full || p === end) end = p.prev;
			filteredOut = true;
			removeNode(p);
			p = p.prev;
			again = true;
		} else if (full || p !== end) {
			p = p.next;
			again = !full;
		}
	} while (again || p !== end);
	return end;
}
/** @param {Node} ear @param {number[]} triangles @param {number} minX @param {number} minY @param {number} invSize */
function earcutLinked(ear, triangles, minX, minY, invSize) {
	if (invSize) indexCurve(ear, minX, minY, invSize);
	let stop = ear, cured = false;
	while (ear.prev !== ear.next) {
		const prev = ear.prev;
		/** @type {Node} */
		const next = ear.next;
		if (area(prev, ear, next) < 0 && (invSize ? isEarHashed(ear, minX, minY, invSize) : isEar(ear))) {
			triangles.push(prev.i, ear.i, next.i);
			removeNode(ear);
			ear = next;
			stop = next;
			continue;
		}
		ear = next;
		if (ear === stop) {
			filteredOut = false;
			ear = filterPoints(ear);
			if (filteredOut) {
				stop = ear;
				continue;
			}
			if (!cured) {
				ear = cureLocalIntersections(ear, triangles);
				stop = ear;
				cured = true;
				continue;
			}
			splitEarcut(ear, triangles, minX, minY, invSize);
			break;
		}
	}
}
/** @param {Node} ear @returns {boolean} */
function isEar(ear) {
	const a = ear.prev, b = ear, c = ear.next, ax = a.x, bx = b.x, cx = c.x, ay = a.y, by = b.y, cy = c.y, x0 = Math.min(ax, bx, cx), y0 = Math.min(ay, by, cy), x1 = Math.max(ax, bx, cx), y1 = Math.max(ay, by, cy);
	let p = c.next;
	while (p !== a) {
		if (p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1 && !(ax === p.x && ay === p.y) && pointInTriangle(ax, ay, bx, by, cx, cy, p.x, p.y) && area(p.prev, p, p.next) >= 0) return false;
		p = p.next;
	}
	return true;
}
/** @param {Node} ear @param {number} minX @param {number} minY @param {number} invSize @returns {boolean} */
function isEarHashed(ear, minX, minY, invSize) {
	const a = ear.prev, b = ear, c = ear.next, ax = a.x, bx = b.x, cx = c.x, ay = a.y, by = b.y, cy = c.y, x0 = Math.min(ax, bx, cx), y0 = Math.min(ay, by, cy), x1 = Math.max(ax, bx, cx), y1 = Math.max(ay, by, cy), minZ = zOrder(x0, y0, minX, minY, invSize), maxZ = zOrder(x1, y1, minX, minY, invSize);
	let p = ear.prevZ;
	while (p && p.z >= minZ) {
		if (p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1 && p !== c && !(ax === p.x && ay === p.y) && pointInTriangle(ax, ay, bx, by, cx, cy, p.x, p.y) && area(p.prev, p, p.next) >= 0) return false;
		p = p.prevZ;
	}
	let n = ear.nextZ;
	while (n && n.z <= maxZ) {
		if (n.x >= x0 && n.x <= x1 && n.y >= y0 && n.y <= y1 && n !== c && !(ax === n.x && ay === n.y) && pointInTriangle(ax, ay, bx, by, cx, cy, n.x, n.y) && area(n.prev, n, n.next) >= 0) return false;
		n = n.nextZ;
	}
	return true;
}
/** @param {Node} start @param {number[]} triangles @returns {Node} */
function cureLocalIntersections(start, triangles) {
	let p = start;
	let cured = false;
	do {
		const a = p.prev, b = p.next.next;
		if (intersects(a, p, p.next, b, false) && locallyInside(a, b) && locallyInside(b, a)) {
			triangles.push(a.i, p.i, b.i);
			removeNode(p);
			removeNode(p.next);
			p = start = b;
			cured = true;
		}
		p = p.next;
	} while (p !== start);
	return cured ? filterPoints(p) : p;
}
/** @param {Node} start @param {number[]} triangles @param {number} minX @param {number} minY @param {number} invSize */
function splitEarcut(start, triangles, minX, minY, invSize) {
	let a = start;
	do {
		let b = a.next.next;
		while (b !== a.prev) {
			if (a.i !== b.i && isValidDiagonal(a, b)) {
				let c = splitPolygon(a, b);
				a = filterPoints(a, a.next);
				c = filterPoints(c, c.next);
				earcutLinked(a, triangles, minX, minY, invSize);
				earcutLinked(c, triangles, minX, minY, invSize);
				return;
			}
			b = b.next;
		}
		a = a.next;
	} while (a !== start);
}
var indexActive = false;
/** @param {ArrayLike<number>} data @param {ArrayLike<number>} holeIndices @param {Node} outerNode @param {number} dim @returns {Node} */
function eliminateHoles(data, holeIndices, outerNode, dim) {
	const queue = [];
	for (let i = 0, len = holeIndices.length; i < len; i++) {
		const list = linkedList(data, holeIndices[i] * dim, i < len - 1 ? holeIndices[i + 1] * dim : data.length, dim, false);
		if (list === list.next) steiners.add(list);
		queue.push(getLeftmost(list));
	}
	queue.sort(compareXYSlope);
	buildBlockIndex(data.length / dim, holeIndices.length);
	indexSegment(outerNode, outerNode);
	indexActive = true;
	for (let i = 0; i < queue.length; i++) outerNode = eliminateHole(queue[i], outerNode);
	indexActive = false;
	return filterPoints(outerNode);
}
/** @param {Node} a @param {Node} b @returns {number} */
function compareXYSlope(a, b) {
	return a.x - b.x || a.y - b.y || (a.next.y - a.y) / (a.next.x - a.x) - (b.next.y - b.y) / (b.next.x - b.x);
}
/** @param {Node} hole @param {Node} outerNode @returns {Node} */
function eliminateHole(hole, outerNode) {
	const bridge = findHoleBridge(hole, outerNode);
	if (!bridge) return outerNode;
	const bridgeReverse = splitPolygon(bridge, hole);
	const bridge2 = bridgeReverse.next;
	indexSegment(bridge, bridge2.next);
	filterPoints(bridgeReverse, bridgeReverse.next);
	return filterPoints(bridge, bridge.next);
}
var K = 16;
var blockBBox = /* @__PURE__ */ new Float64Array(0);
var numBlocks = 0;
/** @type {Node[]} */
var blockHead = [];
/** @type {Node[]} */
var blockStop = [];
/** @param {number} maxNodes @param {number} numHoles */
function buildBlockIndex(maxNodes, numHoles) {
	const maxBlocks = Math.ceil((maxNodes + 2 * numHoles) / K) + numHoles + 2;
	if (blockBBox.length < maxBlocks * 4) blockBBox = new Float64Array(maxBlocks * 4);
	numBlocks = 0;
}
/** @param {Node} head @param {Node} stop */
function indexSegment(head, stop) {
	let p = head;
	do {
		const b = numBlocks++;
		blockHead[b] = p;
		let minX = p.x, minY = p.y, maxX = p.x, maxY = p.y;
		let k = 0;
		do {
			const c = p.next;
			p.z = b;
			if (c.x < minX) minX = c.x;
			if (c.x > maxX) maxX = c.x;
			if (c.y < minY) minY = c.y;
			if (c.y > maxY) maxY = c.y;
			p = c;
		} while (++k < K && p !== stop);
		blockStop[b] = p;
		const g = b * 4;
		blockBBox[g] = minX;
		blockBBox[g + 1] = minY;
		blockBBox[g + 2] = maxX;
		blockBBox[g + 3] = maxY;
	} while (p !== stop);
}
/** @param {Node} head @param {Node} tail */
function growBlock(head, tail) {
	const g = head.z * 4;
	if (tail.x < blockBBox[g]) blockBBox[g] = tail.x;
	if (tail.y < blockBBox[g + 1]) blockBBox[g + 1] = tail.y;
	if (tail.x > blockBBox[g + 2]) blockBBox[g + 2] = tail.x;
	if (tail.y > blockBBox[g + 3]) blockBBox[g + 3] = tail.y;
}
/** @param {number} b @returns {Node} */
function liveBlockStop(b) {
	let stop = blockStop[b];
	while (stop.prev.next !== stop) stop = stop.next;
	blockStop[b] = stop;
	return stop;
}
/** @param {number} b @returns {Node} */
function liveBlockHead(b) {
	let head = blockHead[b];
	while (head.prev.next !== head) head = head.next;
	blockHead[b] = head;
	return head;
}
/** @param {Node} hole @param {Node} outerNode @returns {Node | null} */
function findHoleBridge(hole, outerNode) {
	let p = outerNode;
	const hx = hole.x;
	const hy = hole.y;
	let qx = -Infinity;
	/** @type {Node | undefined} */
	let m;
	if (equals(hole, p)) return p;
	for (let b = 0, g = 0; b < numBlocks; b++, g += 4) {
		if (hy < blockBBox[g + 1] || hy > blockBBox[g + 3] || blockBBox[g] > hx || blockBBox[g + 2] <= qx) continue;
		const stop = liveBlockStop(b);
		p = liveBlockHead(b);
		do {
			if (p.prev.next === p) {
				if (equals(hole, p.next)) return p.next;
				else if (hy <= p.y && hy >= p.next.y && p.next.y !== p.y) {
					const x = p.x + (hy - p.y) * (p.next.x - p.x) / (p.next.y - p.y);
					if (x <= hx && x > qx) {
						qx = x;
						m = p.x < p.next.x ? p : p.next;
						if (x === hx) return m;
					}
				}
			}
			p = p.next;
		} while (p !== stop);
	}
	if (!m) return null;
	const mx = m.x;
	const my = m.y;
	const tminY = Math.min(hy, my);
	const tmaxY = Math.max(hy, my);
	let tanMin = Infinity;
	for (let b = 0, g = 0; b < numBlocks; b++, g += 4) {
		if (blockBBox[g + 2] < mx || blockBBox[g] > hx || blockBBox[g + 3] < tminY || blockBBox[g + 1] > tmaxY) continue;
		const stop = liveBlockStop(b);
		p = liveBlockHead(b);
		do {
			if (p.prev.next === p && hx >= p.x && p.x >= mx && hx !== p.x && pointInTriangle(hy < my ? hx : qx, hy, mx, my, hy < my ? qx : hx, hy, p.x, p.y)) {
				const tan = Math.abs(hy - p.y) / (hx - p.x);
				if ((locallyInside(p, hole) || p.y === hy && p.next.y === hy && p.next.x > hx) && (tan < tanMin || tan === tanMin && (p.x > m.x || p.x === m.x && sectorContainsSector(m, p)))) {
					m = p;
					tanMin = tan;
				}
			}
			p = p.next;
		} while (p !== stop);
	}
	return m;
}
/** @param {Node} m @param {Node} p @returns {boolean} */
function sectorContainsSector(m, p) {
	return area(m.prev, m, p.prev) < 0 && area(p.next, m, m.next) < 0;
}
/** @type {Node[]} */
var sortArr = [];
/** @type {Node[]} */
var sortBuf = [];
var zArr = /* @__PURE__ */ new Uint32Array(0);
var zBuf = /* @__PURE__ */ new Uint32Array(0);
var counts = /* @__PURE__ */ new Uint32Array(256);
/** @param {Node} start @param {number} minX @param {number} minY @param {number} invSize */
function indexCurve(start, minX, minY, invSize) {
	let p = start;
	let n = 0;
	do {
		p.z = zOrder(p.x, p.y, minX, minY, invSize);
		sortArr[n++] = p;
		p = p.next;
	} while (p !== start);
	sortNodes(n);
	/** @type {Node | null} */
	let prev = null;
	for (let i = 0; i < n; i++) {
		const node = sortArr[i];
		node.prevZ = prev;
		if (prev) prev.nextZ = node;
		prev = node;
	}
	/** @type {Node} */ prev.nextZ = null;
	sortArr.fill(null, 0, n);
	sortBuf.fill(null, 0, n);
}
/** @param {number} n */
function sortNodes(n) {
	if (n <= 32) {
		for (let i = 1; i < n; i++) {
			const node = sortArr[i], z = node.z;
			let j = i - 1;
			while (j >= 0 && sortArr[j].z > z) {
				sortArr[j + 1] = sortArr[j];
				j--;
			}
			sortArr[j + 1] = node;
		}
		return;
	}
	if (zArr.length < n) {
		zArr = new Uint32Array(n);
		zBuf = new Uint32Array(n);
		sortBuf = new Array(n);
	}
	for (let i = 0; i < n; i++) zArr[i] = sortArr[i].z;
	radixPass(n, sortArr, zArr, sortBuf, zBuf, 0);
	radixPass(n, sortBuf, zBuf, sortArr, zArr, 8);
	radixPass(n, sortArr, zArr, sortBuf, zBuf, 16);
	radixPass(n, sortBuf, zBuf, sortArr, zArr, 24);
}
/** @param {number} n @param {Node[]} src @param {Uint32Array} srcZ @param {Node[]} dst @param {Uint32Array} dstZ @param {number} shift */
function radixPass(n, src, srcZ, dst, dstZ, shift) {
	counts.fill(0);
	for (let i = 0; i < n; i++) counts[srcZ[i] >>> shift & 255]++;
	let sum = 0;
	for (let b = 0; b < 256; b++) {
		const c = counts[b];
		counts[b] = sum;
		sum += c;
	}
	for (let i = 0; i < n; i++) {
		const z = srcZ[i];
		const pos = counts[z >>> shift & 255]++;
		dst[pos] = src[i];
		dstZ[pos] = z;
	}
}
/** @param {number} x @param {number} y @param {number} minX @param {number} minY @param {number} invSize @returns {number} */
function zOrder(x, y, minX, minY, invSize) {
	x = (x - minX) * invSize | 0;
	y = (y - minY) * invSize | 0;
	x = (x | x << 8) & 16711935;
	x = (x | x << 4) & 252645135;
	x = (x | x << 2) & 858993459;
	x = (x | x << 1) & 1431655765;
	y = (y | y << 8) & 16711935;
	y = (y | y << 4) & 252645135;
	y = (y | y << 2) & 858993459;
	y = (y | y << 1) & 1431655765;
	return x | y << 1;
}
/** @param {Node} start @returns {Node} */
function getLeftmost(start) {
	let p = start, leftmost = start;
	do {
		if (p.x < leftmost.x || p.x === leftmost.x && p.y < leftmost.y) leftmost = p;
		p = p.next;
	} while (p !== start);
	return leftmost;
}
/** @param {number} ax @param {number} ay @param {number} bx @param {number} by @param {number} cx @param {number} cy @param {number} px @param {number} py @returns {boolean} */
function pointInTriangle(ax, ay, bx, by, cx, cy, px, py) {
	return (cx - px) * (ay - py) >= (ax - px) * (cy - py) && (ax - px) * (by - py) >= (bx - px) * (ay - py) && (bx - px) * (cy - py) >= (cx - px) * (by - py);
}
/** @param {Node} a @param {Node} b @returns {boolean} true when the diagonal is valid */
function isValidDiagonal(a, b) {
	const zeroLength = equals(a, b) && area(a.prev, a, a.next) > 0 && area(b.prev, b, b.next) > 0;
	return a.next.i !== b.i && (zeroLength || locallyInside(a, b) && locallyInside(b, a) && (area(a.prev, a, b.prev) !== 0 || area(a, b.prev, b) !== 0)) && !intersectsPolygon(a, b) && (zeroLength || middleInside(a, b));
}
/** @param {Node} p @param {Node} q @param {Node} r @returns {number} */
function area(p, q, r) {
	return (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
}
/** @param {Node} p1 @param {Node} p2 @returns {boolean} */
function equals(p1, p2) {
	return p1.x === p2.x && p1.y === p2.y;
}
/** @param {Node} p1 @param {Node} q1 @param {Node} p2 @param {Node} q2 @param {boolean} [includeBoundary] @returns {boolean} */
function intersects(p1, q1, p2, q2, includeBoundary = true) {
	const o1 = area(p1, q1, p2);
	const o2 = area(p1, q1, q2);
	const o3 = area(p2, q2, p1);
	const o4 = area(p2, q2, q1);
	if ((o1 > 0 && o2 < 0 || o1 < 0 && o2 > 0) && (o3 > 0 && o4 < 0 || o3 < 0 && o4 > 0)) return true;
	if (!includeBoundary) return false;
	if (o1 === 0 && onSegment(p1, p2, q1)) return true;
	if (o2 === 0 && onSegment(p1, q2, q1)) return true;
	if (o3 === 0 && onSegment(p2, p1, q2)) return true;
	if (o4 === 0 && onSegment(p2, q1, q2)) return true;
	return false;
}
/** @param {Node} p @param {Node} q @param {Node} r @returns {boolean} */
function onSegment(p, q, r) {
	return q.x <= Math.max(p.x, r.x) && q.x >= Math.min(p.x, r.x) && q.y <= Math.max(p.y, r.y) && q.y >= Math.min(p.y, r.y);
}
/** @param {Node} a @param {Node} b @returns {boolean} */
function intersectsPolygon(a, b) {
	const minX = Math.min(a.x, b.x);
	const maxX = Math.max(a.x, b.x);
	const minY = Math.min(a.y, b.y);
	const maxY = Math.max(a.y, b.y);
	let p = a;
	do {
		const n = p.next;
		if (p.x > maxX && n.x > maxX || p.x < minX && n.x < minX || p.y > maxY && n.y > maxY || p.y < minY && n.y < minY) {
			p = n;
			continue;
		}
		if (p.i !== a.i && n.i !== a.i && p.i !== b.i && n.i !== b.i && intersects(p, n, a, b)) return true;
		p = n;
	} while (p !== a);
	return false;
}
/** @param {Node} a @param {Node} b @returns {boolean} */
function locallyInside(a, b) {
	return area(a.prev, a, a.next) < 0 ? area(a, b, a.next) >= 0 && area(a, a.prev, b) >= 0 : area(a, b, a.prev) < 0 || area(a, a.next, b) < 0;
}
/** @param {Node} a @param {Node} b @returns {boolean} */
function middleInside(a, b) {
	let p = a;
	let inside = false;
	const px = (a.x + b.x) / 2;
	const py = (a.y + b.y) / 2;
	do {
		const n = p.next;
		if (p.y > py !== n.y > py && px < (n.x - p.x) * (py - p.y) / (n.y - p.y) + p.x) inside = !inside;
		p = n;
	} while (p !== a);
	return inside;
}
/** @param {Node} a @param {Node} b @returns {Node} */
function splitPolygon(a, b) {
	const a2 = createNode(a.i, a.x, a.y), b2 = createNode(b.i, b.x, b.y), an = a.next, bp = b.prev;
	a.next = b;
	b.prev = a;
	a2.next = an;
	an.prev = a2;
	b2.next = a2;
	a2.prev = b2;
	bp.next = b2;
	b2.prev = bp;
	return b2;
}
/** @param {number} i @param {number} x @param {number} y @param {Node | null} last @returns {Node} */
function insertNode(i, x, y, last) {
	const p = createNode(i, x, y);
	if (!last) {
		p.prev = p;
		p.next = p;
	} else {
		p.next = last.next;
		p.prev = last;
		last.next.prev = p;
		last.next = p;
	}
	return p;
}
/** @param {Node} p */
function removeNode(p) {
	p.next.prev = p.prev;
	p.prev.next = p.next;
	if (p.prevZ) p.prevZ.nextZ = p.nextZ;
	if (p.nextZ) p.nextZ.prevZ = p.prevZ;
	if (indexActive) growBlock(p.prev, p.next);
}
/** @param {number} i @param {number} x @param {number} y @returns {Node} */
function createNode(i, x, y) {
	return {
		i,
		x,
		y,
		prev: null,
		next: null,
		z: 0,
		prevZ: null,
		nextZ: null
	};
}
/** @param {ArrayLike<number>} data @param {number} start @param {number} end @param {number} dim @returns {number} */
function signedArea(data, start, end, dim) {
	let sum = 0;
	for (let i = start, j = end - dim; i < end; i += dim) {
		sum += (data[j] - data[i]) * (data[i + 1] + data[j + 1]);
		j = i;
	}
	return sum;
}
//#endregion
//#region node_modules/pixi.js/lib/utils/utils.mjs
var earcut = earcut$1.default || earcut$1;
//#endregion
//#region node_modules/parse-svg-path/dist/index.mjs
/** Number of numeric arguments each SVG path command expects (lowercase keys). */
var length = {
	a: 7,
	c: 6,
	h: 1,
	l: 2,
	m: 2,
	q: 4,
	s: 4,
	t: 2,
	v: 1,
	z: 0
};
/** Matches a single path command letter followed by its raw argument string. */
var segment = /([astvzqmhlc])([^astvzqmhlc]*)/gi;
/** Matches a single numeric token, including negatives, decimals, and scientific notation. */
var number = /-?[0-9]*\.?[0-9]+(?:e[-+]?\d+)?/gi;
/**
* Parse an SVG path `d` attribute string into an array of commands.
*
* Each command is a tuple of `[letter, ...args]`. Relative commands use
* lowercase letters; absolute commands use uppercase. An implicit `lineto`
* is inserted after the first coordinate pair of a `moveto` with extra args,
* per the SVG spec.
*
* @param path - The raw SVG path data string (e.g. `"M0,0 L10,10 Z"`).
* @returns Array of parsed commands.
* @throws {Error} if a command has fewer arguments than expected.
*/
function parse(path) {
	const data = [];
	path.replace(segment, (_, cmd, args) => {
		let type = cmd.toLowerCase();
		let command = cmd;
		const values = parseValues(args);
		if (type === "m" && values.length > 2) {
			data.push([command, ...values.splice(0, 2)]);
			type = "l";
			command = command === "m" ? "l" : "L";
		}
		while (true) {
			if (values.length === length[type]) {
				data.push([command, ...values]);
				return "";
			}
			if (values.length < length[type]) throw new Error("malformed path data");
			data.push([command, ...values.splice(0, length[type])]);
		}
	});
	return data;
}
/** Extract all numeric tokens from a raw argument string. */
function parseValues(args) {
	const numbers = args.match(number);
	return numbers ? numbers.map(Number) : [];
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/parseSVGPath.mjs
function parseSVGPath(svgPath, path) {
	const commands = parse(svgPath);
	const subpaths = [];
	let currentSubPath = null;
	let lastX = 0;
	let lastY = 0;
	for (let i = 0; i < commands.length; i++) {
		const command = commands[i];
		const type = command[0];
		const data = command;
		switch (type) {
			case "M":
				lastX = data[1];
				lastY = data[2];
				path.moveTo(lastX, lastY);
				break;
			case "m":
				lastX += data[1];
				lastY += data[2];
				path.moveTo(lastX, lastY);
				break;
			case "H":
				lastX = data[1];
				path.lineTo(lastX, lastY);
				break;
			case "h":
				lastX += data[1];
				path.lineTo(lastX, lastY);
				break;
			case "V":
				lastY = data[1];
				path.lineTo(lastX, lastY);
				break;
			case "v":
				lastY += data[1];
				path.lineTo(lastX, lastY);
				break;
			case "L":
				lastX = data[1];
				lastY = data[2];
				path.lineTo(lastX, lastY);
				break;
			case "l":
				lastX += data[1];
				lastY += data[2];
				path.lineTo(lastX, lastY);
				break;
			case "C":
				lastX = data[5];
				lastY = data[6];
				path.bezierCurveTo(data[1], data[2], data[3], data[4], lastX, lastY);
				break;
			case "c":
				path.bezierCurveTo(lastX + data[1], lastY + data[2], lastX + data[3], lastY + data[4], lastX + data[5], lastY + data[6]);
				lastX += data[5];
				lastY += data[6];
				break;
			case "S":
				lastX = data[3];
				lastY = data[4];
				path.bezierCurveToShort(data[1], data[2], lastX, lastY);
				break;
			case "s":
				path.bezierCurveToShort(lastX + data[1], lastY + data[2], lastX + data[3], lastY + data[4]);
				lastX += data[3];
				lastY += data[4];
				break;
			case "Q":
				lastX = data[3];
				lastY = data[4];
				path.quadraticCurveTo(data[1], data[2], lastX, lastY);
				break;
			case "q":
				path.quadraticCurveTo(lastX + data[1], lastY + data[2], lastX + data[3], lastY + data[4]);
				lastX += data[3];
				lastY += data[4];
				break;
			case "T":
				lastX = data[1];
				lastY = data[2];
				path.quadraticCurveToShort(lastX, lastY);
				break;
			case "t":
				lastX += data[1];
				lastY += data[2];
				path.quadraticCurveToShort(lastX, lastY);
				break;
			case "A":
				lastX = data[6];
				lastY = data[7];
				path.arcToSvg(data[1], data[2], data[3], data[4], data[5], lastX, lastY);
				break;
			case "a":
				lastX += data[6];
				lastY += data[7];
				path.arcToSvg(data[1], data[2], data[3], data[4], data[5], lastX, lastY);
				break;
			case "Z":
			case "z":
				path.closePath();
				if (subpaths.length > 0) {
					currentSubPath = subpaths.pop();
					if (currentSubPath) {
						lastX = currentSubPath.startX;
						lastY = currentSubPath.startY;
					} else {
						lastX = 0;
						lastY = 0;
					}
				}
				currentSubPath = null;
				break;
			default: warn(`Unknown SVG path command: ${type}`);
		}
		if (type !== "Z" && type !== "z") {
			if (currentSubPath === null) {
				currentSubPath = {
					startX: lastX,
					startY: lastY
				};
				subpaths.push(currentSubPath);
			}
		}
	}
	return path;
}
//#endregion
//#region node_modules/pixi.js/lib/maths/shapes/Circle.mjs
var Circle = class Circle {
	/**
	* @param x - The X coordinate of the center of this circle
	* @param y - The Y coordinate of the center of this circle
	* @param radius - The radius of the circle
	*/
	constructor(x = 0, y = 0, radius = 0) {
		/**
		* The type of the object, mainly used to avoid `instanceof` checks.
		* @example
		* ```ts
		* // Check shape type
		* const shape = new Circle(0, 0, 50);
		* console.log(shape.type); // 'circle'
		*
		* // Use in type guards
		* if (shape.type === 'circle') {
		*     console.log(shape.radius);
		* }
		* ```
		* @remarks
		* - Used for shape type checking
		* - More efficient than instanceof
		* - Read-only property
		* @readonly
		* @default 'circle'
		* @see {@link SHAPE_PRIMITIVE} For all shape types
		* @see {@link ShapePrimitive} For shape interface
		*/
		this.type = "circle";
		this.x = x;
		this.y = y;
		this.radius = radius;
	}
	/**
	* Creates a clone of this Circle instance.
	* @example
	* ```ts
	* // Basic circle cloning
	* const original = new Circle(100, 100, 50);
	* const copy = original.clone();
	*
	* // Clone and modify
	* const modified = original.clone();
	* modified.radius = 75;
	*
	* // Verify independence
	* console.log(original.radius); // 50
	* console.log(modified.radius); // 75
	* ```
	* @returns A copy of the Circle
	* @see {@link Circle.copyFrom} For copying into existing circle
	* @see {@link Circle.copyTo} For copying to another circle
	*/
	clone() {
		return new Circle(this.x, this.y, this.radius);
	}
	/**
	* Checks whether the x and y coordinates given are contained within this circle.
	*
	* Uses the distance formula to determine if a point is inside the circle's radius.
	*
	* Commonly used for hit testing in PixiJS events and graphics.
	* @example
	* ```ts
	* // Basic containment check
	* const circle = new Circle(100, 100, 50);
	* const isInside = circle.contains(120, 120);
	*
	* // Check mouse position
	* const circle = new Circle(0, 0, 100);
	* container.hitArea = circle;
	* container.on('pointermove', (e) => {
	*     // only called if pointer is within circle
	* });
	* ```
	* @param x - The X coordinate of the point to test
	* @param y - The Y coordinate of the point to test
	* @returns Whether the x/y coordinates are within this Circle
	* @see {@link Circle.strokeContains} For checking stroke intersection
	* @see {@link Circle.getBounds} For getting bounding box
	*/
	contains(x, y) {
		if (this.radius <= 0) return false;
		const r2 = this.radius * this.radius;
		let dx = this.x - x;
		let dy = this.y - y;
		dx *= dx;
		dy *= dy;
		return dx + dy <= r2;
	}
	/**
	* Checks whether the x and y coordinates given are contained within this circle including the stroke.
	* @example
	* ```ts
	* // Basic stroke check
	* const circle = new Circle(100, 100, 50);
	* const isOnStroke = circle.strokeContains(150, 100, 4); // 4px line width
	*
	* // Check with different alignments
	* const innerStroke = circle.strokeContains(150, 100, 4, 1);   // Inside
	* const centerStroke = circle.strokeContains(150, 100, 4, 0.5); // Centered
	* const outerStroke = circle.strokeContains(150, 100, 4, 0);   // Outside
	* ```
	* @param x - The X coordinate of the point to test
	* @param y - The Y coordinate of the point to test
	* @param width - The width of the line to check
	* @param alignment - The alignment of the stroke, 0.5 by default
	* @returns Whether the x/y coordinates are within this Circle's stroke
	* @see {@link Circle.contains} For checking fill containment
	* @see {@link Circle.getBounds} For getting stroke bounds
	*/
	strokeContains(x, y, width, alignment = .5) {
		if (this.radius === 0) return false;
		const dx = this.x - x;
		const dy = this.y - y;
		const radius = this.radius;
		const outerWidth = (1 - alignment) * width;
		const distance = Math.sqrt(dx * dx + dy * dy);
		return distance <= radius + outerWidth && distance > radius - (width - outerWidth);
	}
	/**
	* Returns the framing rectangle of the circle as a Rectangle object.
	* @example
	* ```ts
	* // Basic bounds calculation
	* const circle = new Circle(100, 100, 50);
	* const bounds = circle.getBounds();
	* // bounds: x=50, y=50, width=100, height=100
	*
	* // Reuse existing rectangle
	* const rect = new Rectangle();
	* circle.getBounds(rect);
	* ```
	* @param out - Optional Rectangle object to store the result
	* @returns The framing rectangle
	* @see {@link Rectangle} For rectangle properties
	* @see {@link Circle.contains} For point containment
	*/
	getBounds(out) {
		out || (out = new Rectangle());
		out.x = this.x - this.radius;
		out.y = this.y - this.radius;
		out.width = this.radius * 2;
		out.height = this.radius * 2;
		return out;
	}
	/**
	* Copies another circle to this one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Circle(100, 100, 50);
	* const target = new Circle();
	* target.copyFrom(source);
	* ```
	* @param circle - The circle to copy from
	* @returns Returns itself
	* @see {@link Circle.copyTo} For copying to another circle
	* @see {@link Circle.clone} For creating new circle copy
	*/
	copyFrom(circle) {
		this.x = circle.x;
		this.y = circle.y;
		this.radius = circle.radius;
		return this;
	}
	/**
	* Copies this circle to another one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Circle(100, 100, 50);
	* const target = new Circle();
	* source.copyTo(target);
	* ```
	* @param circle - The circle to copy to
	* @returns Returns given parameter
	* @see {@link Circle.copyFrom} For copying from another circle
	* @see {@link Circle.clone} For creating new circle copy
	*/
	copyTo(circle) {
		circle.copyFrom(this);
		return circle;
	}
	toString() {
		return `[pixi.js/math:Circle x=${this.x} y=${this.y} radius=${this.radius}]`;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/maths/shapes/Ellipse.mjs
var Ellipse = class Ellipse {
	/**
	* @param x - The X coordinate of the center of this ellipse
	* @param y - The Y coordinate of the center of this ellipse
	* @param halfWidth - The half width of this ellipse
	* @param halfHeight - The half height of this ellipse
	*/
	constructor(x = 0, y = 0, halfWidth = 0, halfHeight = 0) {
		/**
		* The type of the object, mainly used to avoid `instanceof` checks
		* @example
		* ```ts
		* // Check shape type
		* const shape = new Ellipse(0, 0, 50, 25);
		* console.log(shape.type); // 'ellipse'
		*
		* // Use in type guards
		* if (shape.type === 'ellipse') {
		*     console.log(shape.halfWidth, shape.halfHeight);
		* }
		* ```
		* @readonly
		* @default 'ellipse'
		* @see {@link SHAPE_PRIMITIVE} For all shape types
		*/
		this.type = "ellipse";
		this.x = x;
		this.y = y;
		this.halfWidth = halfWidth;
		this.halfHeight = halfHeight;
	}
	/**
	* Creates a clone of this Ellipse instance.
	* @example
	* ```ts
	* // Basic cloning
	* const original = new Ellipse(100, 100, 50, 25);
	* const copy = original.clone();
	*
	* // Clone and modify
	* const modified = original.clone();
	* modified.halfWidth *= 2;
	* modified.halfHeight *= 2;
	*
	* // Verify independence
	* console.log(original.halfWidth);  // 50
	* console.log(modified.halfWidth);  // 100
	* ```
	* @returns A copy of the ellipse
	* @see {@link Ellipse.copyFrom} For copying into existing ellipse
	* @see {@link Ellipse.copyTo} For copying to another ellipse
	*/
	clone() {
		return new Ellipse(this.x, this.y, this.halfWidth, this.halfHeight);
	}
	/**
	* Checks whether the x and y coordinates given are contained within this ellipse.
	* Uses normalized coordinates and the ellipse equation to determine containment.
	* @example
	* ```ts
	* // Basic containment check
	* const ellipse = new Ellipse(100, 100, 50, 25);
	* const isInside = ellipse.contains(120, 110);
	* ```
	* @remarks
	* - Uses ellipse equation (x²/a² + y²/b² ≤ 1)
	* - Returns false if dimensions are 0 or negative
	* - Normalized to center (0,0) for calculation
	* @param x - The X coordinate of the point to test
	* @param y - The Y coordinate of the point to test
	* @returns Whether the x/y coords are within this ellipse
	* @see {@link Ellipse.strokeContains} For checking stroke intersection
	* @see {@link Ellipse.getBounds} For getting containing rectangle
	*/
	contains(x, y) {
		if (this.halfWidth <= 0 || this.halfHeight <= 0) return false;
		let normx = (x - this.x) / this.halfWidth;
		let normy = (y - this.y) / this.halfHeight;
		normx *= normx;
		normy *= normy;
		return normx + normy <= 1;
	}
	/**
	* Checks whether the x and y coordinates given are contained within this ellipse including stroke.
	* @example
	* ```ts
	* // Basic stroke check
	* const ellipse = new Ellipse(100, 100, 50, 25);
	* const isOnStroke = ellipse.strokeContains(150, 100, 4); // 4px line width
	*
	* // Check with different alignments
	* const innerStroke = ellipse.strokeContains(150, 100, 4, 1);   // Inside
	* const centerStroke = ellipse.strokeContains(150, 100, 4, 0.5); // Centered
	* const outerStroke = ellipse.strokeContains(150, 100, 4, 0);   // Outside
	* ```
	* @remarks
	* - Uses normalized ellipse equations
	* - Considers stroke alignment
	* - Returns false if dimensions are 0
	* - A stroke wider than the shape covers it entirely, leaving no unstroked interior
	* @param x - The X coordinate of the point to test
	* @param y - The Y coordinate of the point to test
	* @param strokeWidth - The width of the line to check
	* @param alignment - The alignment of the stroke (1 = inner, 0.5 = centered, 0 = outer)
	* @returns Whether the x/y coords are within this ellipse's stroke
	* @see {@link Ellipse.contains} For checking fill containment
	* @see {@link Ellipse.getBounds} For getting stroke bounds
	*/
	strokeContains(x, y, strokeWidth, alignment = .5) {
		const { halfWidth, halfHeight } = this;
		if (halfWidth <= 0 || halfHeight <= 0) return false;
		const strokeOuterWidth = strokeWidth * (1 - alignment);
		const strokeInnerWidth = strokeWidth - strokeOuterWidth;
		const innerHorizontal = halfWidth - strokeInnerWidth;
		const innerVertical = halfHeight - strokeInnerWidth;
		const outerHorizontal = halfWidth + strokeOuterWidth;
		const outerVertical = halfHeight + strokeOuterWidth;
		const normalizedX = x - this.x;
		const normalizedY = y - this.y;
		if (normalizedX * normalizedX / (outerHorizontal * outerHorizontal) + normalizedY * normalizedY / (outerVertical * outerVertical) > 1) return false;
		if (innerHorizontal <= 0 || innerVertical <= 0) return true;
		return normalizedX * normalizedX / (innerHorizontal * innerHorizontal) + normalizedY * normalizedY / (innerVertical * innerVertical) > 1;
	}
	/**
	* Returns the framing rectangle of the ellipse as a Rectangle object.
	* @example
	* ```ts
	* // Basic bounds calculation
	* const ellipse = new Ellipse(100, 100, 50, 25);
	* const bounds = ellipse.getBounds();
	* // bounds: x=50, y=75, width=100, height=50
	*
	* // Reuse existing rectangle
	* const rect = new Rectangle();
	* ellipse.getBounds(rect);
	* ```
	* @remarks
	* - Creates Rectangle if none provided
	* - Top-left is (x-halfWidth, y-halfHeight)
	* - Width is halfWidth * 2
	* - Height is halfHeight * 2
	* @param out - Optional Rectangle object to store the result
	* @returns The framing rectangle
	* @see {@link Rectangle} For rectangle properties
	* @see {@link Ellipse.contains} For checking if a point is inside
	*/
	getBounds(out) {
		out || (out = new Rectangle());
		out.x = this.x - this.halfWidth;
		out.y = this.y - this.halfHeight;
		out.width = this.halfWidth * 2;
		out.height = this.halfHeight * 2;
		return out;
	}
	/**
	* Copies another ellipse to this one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Ellipse(100, 100, 50, 25);
	* const target = new Ellipse();
	* target.copyFrom(source);
	* ```
	* @param ellipse - The ellipse to copy from
	* @returns Returns itself
	* @see {@link Ellipse.copyTo} For copying to another ellipse
	* @see {@link Ellipse.clone} For creating new ellipse copy
	*/
	copyFrom(ellipse) {
		this.x = ellipse.x;
		this.y = ellipse.y;
		this.halfWidth = ellipse.halfWidth;
		this.halfHeight = ellipse.halfHeight;
		return this;
	}
	/**
	* Copies this ellipse to another one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Ellipse(100, 100, 50, 25);
	* const target = new Ellipse();
	* source.copyTo(target);
	* ```
	* @param ellipse - The ellipse to copy to
	* @returns Returns given parameter
	* @see {@link Ellipse.copyFrom} For copying from another ellipse
	* @see {@link Ellipse.clone} For creating new ellipse copy
	*/
	copyTo(ellipse) {
		ellipse.copyFrom(this);
		return ellipse;
	}
	toString() {
		return `[pixi.js/math:Ellipse x=${this.x} y=${this.y} halfWidth=${this.halfWidth} halfHeight=${this.halfHeight}]`;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/maths/misc/getOrientationOfPoints.mjs
function getOrientationOfPoints(points) {
	const m = points.length;
	if (m < 6) return 1;
	let area = 0;
	for (let i = 0, x1 = points[m - 2], y1 = points[m - 1]; i < m; i += 2) {
		const x2 = points[i];
		const y2 = points[i + 1];
		area += (x2 - x1) * (y2 + y1);
		x1 = x2;
		y1 = y2;
	}
	if (area < 0) return -1;
	return 1;
}
//#endregion
//#region node_modules/pixi.js/lib/maths/misc/squaredDistanceToLineSegment.mjs
function squaredDistanceToLineSegment(x, y, x1, y1, x2, y2) {
	const a = x - x1;
	const b = y - y1;
	const c = x2 - x1;
	const d = y2 - y1;
	const dot = a * c + b * d;
	const lenSq = c * c + d * d;
	let param = -1;
	if (lenSq !== 0) param = dot / lenSq;
	let xx;
	let yy;
	if (param < 0) {
		xx = x1;
		yy = y1;
	} else if (param > 1) {
		xx = x2;
		yy = y2;
	} else {
		xx = x1 + param * c;
		yy = y1 + param * d;
	}
	const dx = x - xx;
	const dy = y - yy;
	return dx * dx + dy * dy;
}
//#endregion
//#region node_modules/pixi.js/lib/maths/shapes/Polygon.mjs
var tempRect$2;
var tempRect2;
var Polygon = class Polygon {
	/**
	* @param points - This can be an array of Points
	*  that form the polygon, a flat array of numbers that will be interpreted as [x,y, x,y, ...], or
	*  the arguments passed can be all the points of the polygon e.g.
	*  `new Polygon(new Point(), new Point(), ...)`, or the arguments passed can be flat
	*  x,y values e.g. `new Polygon(x,y, x,y, x,y, ...)` where `x` and `y` are Numbers.
	*/
	constructor(...points) {
		/**
		* The type of the object, mainly used to avoid `instanceof` checks
		* @example
		* ```ts
		* // Check shape type
		* const shape = new Polygon([0, 0, 100, 0, 50, 100]);
		* console.log(shape.type); // 'polygon'
		*
		* // Use in type guards
		* if (shape.type === 'polygon') {
		*     // TypeScript knows this is a Polygon
		*     console.log(shape.points.length);
		* }
		* ```
		* @readonly
		* @default 'polygon'
		* @see {@link SHAPE_PRIMITIVE} For all shape types
		*/
		this.type = "polygon";
		let flat = Array.isArray(points[0]) ? points[0] : points;
		if (typeof flat[0] !== "number") {
			const p = [];
			for (let i = 0, il = flat.length; i < il; i++) p.push(flat[i].x, flat[i].y);
			flat = p;
		}
		this.points = flat;
		this.closePath = true;
	}
	/**
	* Determines whether the polygon's points are arranged in a clockwise direction.
	* Uses the shoelace formula (surveyor's formula) to calculate the signed area.
	*
	* A positive area indicates clockwise winding, while negative indicates counter-clockwise.
	*
	* The formula sums up the cross products of adjacent vertices:
	* For each pair of adjacent points (x1,y1) and (x2,y2), we calculate (x1*y2 - x2*y1)
	* The final sum divided by 2 gives the signed area - positive for clockwise.
	* @example
	* ```ts
	* // Check polygon winding
	* const polygon = new Polygon([0, 0, 100, 0, 50, 100]);
	* console.log(polygon.isClockwise()); // Check direction
	*
	* // Use in path construction
	* const hole = new Polygon([25, 25, 75, 25, 75, 75, 25, 75]);
	* if (hole.isClockwise() === shape.isClockwise()) {
	*     hole.points.reverse(); // Reverse for proper hole winding
	* }
	* ```
	* @returns `true` if the polygon's points are arranged clockwise, `false` if counter-clockwise
	*/
	isClockwise() {
		let area = 0;
		const points = this.points;
		const length = points.length;
		for (let i = 0; i < length; i += 2) {
			const x1 = points[i];
			const y1 = points[i + 1];
			const x2 = points[(i + 2) % length];
			const y2 = points[(i + 3) % length];
			area += (x2 - x1) * (y2 + y1);
		}
		return area < 0;
	}
	/**
	* Checks if this polygon completely contains another polygon.
	* Used for detecting holes in shapes, like when parsing SVG paths.
	* @example
	* ```ts
	* // Basic containment check
	* const outerSquare = new Polygon([0,0, 100,0, 100,100, 0,100]); // A square
	* const innerSquare = new Polygon([25,25, 75,25, 75,75, 25,75]); // A smaller square inside
	*
	* outerSquare.containsPolygon(innerSquare); // Returns true
	* innerSquare.containsPolygon(outerSquare); // Returns false
	* ```
	* @remarks
	* - Uses bounds check for quick rejection
	* - Tests all points for containment
	* @param polygon - The polygon to test for containment
	* @returns True if this polygon completely contains the other polygon
	* @see {@link Polygon.contains} For single point testing
	* @see {@link Polygon.getBounds} For bounds calculation
	*/
	containsPolygon(polygon) {
		const thisBounds = this.getBounds(tempRect$2);
		const otherBounds = polygon.getBounds(tempRect2);
		if (!thisBounds.containsRect(otherBounds)) return false;
		const points = polygon.points;
		for (let i = 0; i < points.length; i += 2) {
			const x = points[i];
			const y = points[i + 1];
			if (!this.contains(x, y)) return false;
		}
		return true;
	}
	/**
	* Creates a clone of this polygon.
	* @example
	* ```ts
	* // Basic cloning
	* const original = new Polygon([0, 0, 100, 0, 50, 100]);
	* const copy = original.clone();
	*
	* // Clone and modify
	* const modified = original.clone();
	* modified.points[0] = 10; // Modify first x coordinate
	* ```
	* @returns A copy of the polygon
	* @see {@link Polygon.copyFrom} For copying into existing polygon
	* @see {@link Polygon.copyTo} For copying to another polygon
	*/
	clone() {
		const points = this.points.slice();
		const polygon = new Polygon(points);
		polygon.closePath = this.closePath;
		return polygon;
	}
	/**
	* Checks whether the x and y coordinates passed to this function are contained within this polygon.
	* Uses raycasting algorithm for point-in-polygon testing.
	* @example
	* ```ts
	* // Basic containment check
	* const polygon = new Polygon([0, 0, 100, 0, 50, 100]);
	* const isInside = polygon.contains(25, 25); // true
	* ```
	* @param x - The X coordinate of the point to test
	* @param y - The Y coordinate of the point to test
	* @returns Whether the x/y coordinates are within this polygon
	* @see {@link Polygon.strokeContains} For checking stroke intersection
	* @see {@link Polygon.containsPolygon} For polygon-in-polygon testing
	*/
	contains(x, y) {
		let inside = false;
		const length = this.points.length / 2;
		for (let i = 0, j = length - 1; i < length; j = i++) {
			const xi = this.points[i * 2];
			const yi = this.points[i * 2 + 1];
			const xj = this.points[j * 2];
			const yj = this.points[j * 2 + 1];
			if (yi > y !== yj > y && x < (xj - xi) * ((y - yi) / (yj - yi)) + xi) inside = !inside;
		}
		return inside;
	}
	/**
	* Checks whether the x and y coordinates given are contained within this polygon including the stroke.
	* @example
	* ```ts
	* // Basic stroke check
	* const polygon = new Polygon([0, 0, 100, 0, 50, 100]);
	* const isOnStroke = polygon.strokeContains(25, 25, 4); // 4px line width
	*
	* // Check with different alignments
	* const innerStroke = polygon.strokeContains(25, 25, 4, 1);   // Inside
	* const centerStroke = polygon.strokeContains(25, 25, 4, 0.5); // Centered
	* const outerStroke = polygon.strokeContains(25, 25, 4, 0);   // Outside
	* ```
	* @param x - The X coordinate of the point to test
	* @param y - The Y coordinate of the point to test
	* @param strokeWidth - The width of the line to check
	* @param alignment - The alignment of the stroke (1 = inner, 0.5 = centered, 0 = outer)
	* @returns Whether the x/y coordinates are within this polygon's stroke
	* @see {@link Polygon.contains} For checking fill containment
	* @see {@link Polygon.getBounds} For getting stroke bounds
	*/
	strokeContains(x, y, strokeWidth, alignment = .5) {
		const { points } = this;
		const outerWidth = strokeWidth * (alignment === .5 ? alignment : (alignment - .5) * getOrientationOfPoints(points) + .5);
		const innerWidth = strokeWidth - outerWidth;
		const outerWidthSquared = outerWidth * outerWidth;
		const innerWidthSquared = innerWidth * innerWidth;
		const iterationLength = points.length - (this.closePath ? 0 : 2);
		for (let i = 0; i < iterationLength; i += 2) {
			const x1 = points[i];
			const y1 = points[i + 1];
			const x2 = points[(i + 2) % points.length];
			const y2 = points[(i + 3) % points.length];
			if (squaredDistanceToLineSegment(x, y, x1, y1, x2, y2) <= (Math.sign((x2 - x1) * (y - y1) - (y2 - y1) * (x - x1)) < 0 ? outerWidthSquared : innerWidthSquared)) return true;
		}
		return false;
	}
	/**
	* Returns the framing rectangle of the polygon as a Rectangle object.
	* @example
	* ```ts
	* // Basic bounds calculation
	* const polygon = new Polygon([0, 0, 100, 0, 50, 100]);
	* const bounds = polygon.getBounds();
	* // bounds: x=0, y=0, width=100, height=100
	*
	* // Reuse existing rectangle
	* const rect = new Rectangle();
	* polygon.getBounds(rect);
	* ```
	* @param out - Optional rectangle to store the result
	* @returns The framing rectangle
	* @see {@link Rectangle} For rectangle properties
	* @see {@link Polygon.contains} For checking if a point is inside
	*/
	getBounds(out) {
		out || (out = new Rectangle());
		const points = this.points;
		let minX = Infinity;
		let maxX = -Infinity;
		let minY = Infinity;
		let maxY = -Infinity;
		for (let i = 0, n = points.length; i < n; i += 2) {
			const x = points[i];
			const y = points[i + 1];
			minX = x < minX ? x : minX;
			maxX = x > maxX ? x : maxX;
			minY = y < minY ? y : minY;
			maxY = y > maxY ? y : maxY;
		}
		out.x = minX;
		out.width = maxX - minX;
		out.y = minY;
		out.height = maxY - minY;
		return out;
	}
	/**
	* Copies another polygon to this one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Polygon([0, 0, 100, 0, 50, 100]);
	* const target = new Polygon();
	* target.copyFrom(source);
	* ```
	* @param polygon - The polygon to copy from
	* @returns Returns itself
	* @see {@link Polygon.copyTo} For copying to another polygon
	* @see {@link Polygon.clone} For creating new polygon copy
	*/
	copyFrom(polygon) {
		this.points = polygon.points.slice();
		this.closePath = polygon.closePath;
		return this;
	}
	/**
	* Copies this polygon to another one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Polygon([0, 0, 100, 0, 50, 100]);
	* const target = new Polygon();
	* source.copyTo(target);
	* ```
	* @param polygon - The polygon to copy to
	* @returns Returns given parameter
	* @see {@link Polygon.copyFrom} For copying from another polygon
	* @see {@link Polygon.clone} For creating new polygon copy
	*/
	copyTo(polygon) {
		polygon.copyFrom(this);
		return polygon;
	}
	toString() {
		return `[pixi.js/math:PolygoncloseStroke=${this.closePath}points=${this.points.reduce((pointsDesc, currentPoint) => `${pointsDesc}, ${currentPoint}`, "")}]`;
	}
	/**
	* Get the last X coordinate of the polygon.
	* @example
	* ```ts
	* // Basic coordinate access
	* const polygon = new Polygon([0, 0, 100, 200, 300, 400]);
	* console.log(polygon.lastX); // 300
	* ```
	* @readonly
	* @returns The x-coordinate of the last vertex
	* @see {@link Polygon.lastY} For last Y coordinate
	* @see {@link Polygon.points} For raw points array
	*/
	get lastX() {
		return this.points[this.points.length - 2];
	}
	/**
	* Get the last Y coordinate of the polygon.
	* @example
	* ```ts
	* // Basic coordinate access
	* const polygon = new Polygon([0, 0, 100, 200, 300, 400]);
	* console.log(polygon.lastY); // 400
	* ```
	* @readonly
	* @returns The y-coordinate of the last vertex
	* @see {@link Polygon.lastX} For last X coordinate
	* @see {@link Polygon.points} For raw points array
	*/
	get lastY() {
		return this.points[this.points.length - 1];
	}
	/**
	* Get the last X coordinate of the polygon.
	* @readonly
	* @deprecated since 8.11.0, use {@link Polygon.lastX} instead.
	*/
	get x() {
		deprecation("8.11.0", "Polygon.lastX is deprecated, please use Polygon.lastX instead.");
		return this.points[this.points.length - 2];
	}
	/**
	* Get the last Y coordinate of the polygon.
	* @readonly
	* @deprecated since 8.11.0, use {@link Polygon.lastY} instead.
	*/
	get y() {
		deprecation("8.11.0", "Polygon.y is deprecated, please use Polygon.lastY instead.");
		return this.points[this.points.length - 1];
	}
	/**
	* Get the first X coordinate of the polygon.
	* @example
	* ```ts
	* // Basic coordinate access
	* const polygon = new Polygon([0, 0, 100, 200, 300, 400]);
	* console.log(polygon.x); // 0
	* ```
	* @readonly
	* @returns The x-coordinate of the first vertex
	* @see {@link Polygon.startY} For first Y coordinate
	* @see {@link Polygon.points} For raw points array
	*/
	get startX() {
		return this.points[0];
	}
	/**
	* Get the first Y coordinate of the polygon.
	* @example
	* ```ts
	* // Basic coordinate access
	* const polygon = new Polygon([0, 0, 100, 200, 300, 400]);
	* console.log(polygon.y); // 0
	* ```
	* @readonly
	* @returns The y-coordinate of the first vertex
	* @see {@link Polygon.startX} For first X coordinate
	* @see {@link Polygon.points} For raw points array
	*/
	get startY() {
		return this.points[1];
	}
};
//#endregion
//#region node_modules/pixi.js/lib/maths/shapes/RoundedRectangle.mjs
var isCornerWithinStroke = (pX, pY, cornerX, cornerY, radius, strokeWidthInner, strokeWidthOuter) => {
	const dx = pX - cornerX;
	const dy = pY - cornerY;
	const distance = Math.sqrt(dx * dx + dy * dy);
	return distance >= radius - strokeWidthInner && distance <= radius + strokeWidthOuter;
};
var RoundedRectangle = class RoundedRectangle {
	/**
	* @param x - The X coordinate of the upper-left corner of the rounded rectangle
	* @param y - The Y coordinate of the upper-left corner of the rounded rectangle
	* @param width - The overall width of this rounded rectangle
	* @param height - The overall height of this rounded rectangle
	* @param radius - Controls the radius of the rounded corners
	*/
	constructor(x = 0, y = 0, width = 0, height = 0, radius = 20) {
		/**
		* The type of the object, mainly used to avoid `instanceof` checks
		* @example
		* ```ts
		* // Check shape type
		* const shape = new RoundedRectangle(0, 0, 100, 100, 20);
		* console.log(shape.type); // 'roundedRectangle'
		*
		* // Use in type guards
		* if (shape.type === 'roundedRectangle') {
		*     console.log(shape.radius);
		* }
		* ```
		* @readonly
		* @default 'roundedRectangle'
		* @see {@link SHAPE_PRIMITIVE} For all shape types
		*/
		this.type = "roundedRectangle";
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.radius = radius;
	}
	/**
	* Returns the framing rectangle of the rounded rectangle as a Rectangle object
	* @example
	* ```ts
	* // Basic bounds calculation
	* const rect = new RoundedRectangle(100, 100, 200, 150, 20);
	* const bounds = rect.getBounds();
	* // bounds: x=100, y=100, width=200, height=150
	*
	* // Reuse existing rectangle
	* const out = new Rectangle();
	* rect.getBounds(out);
	* ```
	* @remarks
	* - Rectangle matches outer dimensions
	* - Ignores corner radius
	* @param out - Optional rectangle to store the result
	* @returns The framing rectangle
	* @see {@link Rectangle} For rectangle properties
	* @see {@link RoundedRectangle.contains} For checking if a point is inside
	*/
	getBounds(out) {
		out || (out = new Rectangle());
		out.x = this.x;
		out.y = this.y;
		out.width = this.width;
		out.height = this.height;
		return out;
	}
	/**
	* Creates a clone of this Rounded Rectangle.
	* @example
	* ```ts
	* // Basic cloning
	* const original = new RoundedRectangle(100, 100, 200, 150, 20);
	* const copy = original.clone();
	*
	* // Clone and modify
	* const modified = original.clone();
	* modified.radius = 30;
	* modified.width *= 2;
	*
	* // Verify independence
	* console.log(original.radius);  // 20
	* console.log(modified.radius);  // 30
	* ```
	* @returns A copy of the rounded rectangle
	* @see {@link RoundedRectangle.copyFrom} For copying into existing rectangle
	* @see {@link RoundedRectangle.copyTo} For copying to another rectangle
	*/
	clone() {
		return new RoundedRectangle(this.x, this.y, this.width, this.height, this.radius);
	}
	/**
	* Copies another rectangle to this one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new RoundedRectangle(100, 100, 200, 150, 20);
	* const target = new RoundedRectangle();
	* target.copyFrom(source);
	*
	* // Chain with other operations
	* const rect = new RoundedRectangle()
	*     .copyFrom(source)
	*     .getBounds(rect);
	* ```
	* @param rectangle - The rectangle to copy from
	* @returns Returns itself
	* @see {@link RoundedRectangle.copyTo} For copying to another rectangle
	* @see {@link RoundedRectangle.clone} For creating new rectangle copy
	*/
	copyFrom(rectangle) {
		this.x = rectangle.x;
		this.y = rectangle.y;
		this.width = rectangle.width;
		this.height = rectangle.height;
		this.radius = rectangle.radius;
		return this;
	}
	/**
	* Copies this rectangle to another one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new RoundedRectangle(100, 100, 200, 150, 20);
	* const target = new RoundedRectangle();
	* source.copyTo(target);
	*
	* // Chain with other operations
	* const result = source
	*     .copyTo(new RoundedRectangle())
	*     .getBounds();
	* ```
	* @param rectangle - The rectangle to copy to
	* @returns Returns given parameter
	* @see {@link RoundedRectangle.copyFrom} For copying from another rectangle
	* @see {@link RoundedRectangle.clone} For creating new rectangle copy
	*/
	copyTo(rectangle) {
		rectangle.copyFrom(this);
		return rectangle;
	}
	/**
	* Checks whether the x and y coordinates given are contained within this Rounded Rectangle
	* @example
	* ```ts
	* // Basic containment check
	* const rect = new RoundedRectangle(100, 100, 200, 150, 20);
	* const isInside = rect.contains(150, 125); // true
	* // Check corner radius
	* const corner = rect.contains(100, 100); // false if within corner curve
	* ```
	* @remarks
	* - Returns false if width/height is 0 or negative
	* - Handles rounded corners with radius check
	* @param x - The X coordinate of the point to test
	* @param y - The Y coordinate of the point to test
	* @returns Whether the x/y coordinates are within this Rounded Rectangle
	* @see {@link RoundedRectangle.strokeContains} For checking stroke intersection
	* @see {@link RoundedRectangle.getBounds} For getting containing rectangle
	*/
	contains(x, y) {
		if (this.width <= 0 || this.height <= 0) return false;
		if (x >= this.x && x <= this.x + this.width) {
			if (y >= this.y && y <= this.y + this.height) {
				const radius = Math.max(0, Math.min(this.radius, Math.min(this.width, this.height) / 2));
				if (y >= this.y + radius && y <= this.y + this.height - radius || x >= this.x + radius && x <= this.x + this.width - radius) return true;
				let dx = x - (this.x + radius);
				let dy = y - (this.y + radius);
				const radius2 = radius * radius;
				if (dx * dx + dy * dy <= radius2) return true;
				dx = x - (this.x + this.width - radius);
				if (dx * dx + dy * dy <= radius2) return true;
				dy = y - (this.y + this.height - radius);
				if (dx * dx + dy * dy <= radius2) return true;
				dx = x - (this.x + radius);
				if (dx * dx + dy * dy <= radius2) return true;
			}
		}
		return false;
	}
	/**
	* Checks whether the x and y coordinates given are contained within this rectangle including the stroke.
	* @example
	* ```ts
	* // Basic stroke check
	* const rect = new RoundedRectangle(100, 100, 200, 150, 20);
	* const isOnStroke = rect.strokeContains(150, 100, 4); // 4px line width
	*
	* // Check with different alignments
	* const innerStroke = rect.strokeContains(150, 100, 4, 1);   // Inside
	* const centerStroke = rect.strokeContains(150, 100, 4, 0.5); // Centered
	* const outerStroke = rect.strokeContains(150, 100, 4, 0);   // Outside
	* ```
	* @param pX - The X coordinate of the point to test
	* @param pY - The Y coordinate of the point to test
	* @param strokeWidth - The width of the line to check
	* @param alignment - The alignment of the stroke (1 = inner, 0.5 = centered, 0 = outer)
	* @returns Whether the x/y coordinates are within this rectangle's stroke
	* @see {@link RoundedRectangle.contains} For checking fill containment
	* @see {@link RoundedRectangle.getBounds} For getting stroke bounds
	*/
	strokeContains(pX, pY, strokeWidth, alignment = .5) {
		const { x, y, width, height, radius } = this;
		const strokeWidthOuter = strokeWidth * (1 - alignment);
		const strokeWidthInner = strokeWidth - strokeWidthOuter;
		const innerX = x + radius;
		const innerY = y + radius;
		const innerWidth = width - radius * 2;
		const innerHeight = height - radius * 2;
		const rightBound = x + width;
		const bottomBound = y + height;
		if ((pX >= x - strokeWidthOuter && pX <= x + strokeWidthInner || pX >= rightBound - strokeWidthInner && pX <= rightBound + strokeWidthOuter) && pY >= innerY && pY <= innerY + innerHeight) return true;
		if ((pY >= y - strokeWidthOuter && pY <= y + strokeWidthInner || pY >= bottomBound - strokeWidthInner && pY <= bottomBound + strokeWidthOuter) && pX >= innerX && pX <= innerX + innerWidth) return true;
		return pX < innerX && pY < innerY && isCornerWithinStroke(pX, pY, innerX, innerY, radius, strokeWidthInner, strokeWidthOuter) || pX > rightBound - radius && pY < innerY && isCornerWithinStroke(pX, pY, rightBound - radius, innerY, radius, strokeWidthInner, strokeWidthOuter) || pX > rightBound - radius && pY > bottomBound - radius && isCornerWithinStroke(pX, pY, rightBound - radius, bottomBound - radius, radius, strokeWidthInner, strokeWidthOuter) || pX < innerX && pY > bottomBound - radius && isCornerWithinStroke(pX, pY, innerX, bottomBound - radius, radius, strokeWidthInner, strokeWidthOuter);
	}
	toString() {
		return `[pixi.js/math:RoundedRectangle x=${this.x} y=${this.y}width=${this.width} height=${this.height} radius=${this.radius}]`;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/utils/buildUvs.mjs
function buildUvs(vertices, verticesStride, verticesOffset, uvs, uvsOffset, uvsStride, size, matrix = null) {
	let index = 0;
	verticesOffset *= verticesStride;
	uvsOffset *= uvsStride;
	const a = matrix.a;
	const b = matrix.b;
	const c = matrix.c;
	const d = matrix.d;
	const tx = matrix.tx;
	const ty = matrix.ty;
	while (index < size) {
		const x = vertices[verticesOffset];
		const y = vertices[verticesOffset + 1];
		uvs[uvsOffset] = a * x + c * y + tx;
		uvs[uvsOffset + 1] = b * x + d * y + ty;
		uvsOffset += uvsStride;
		verticesOffset += verticesStride;
		index++;
	}
}
function buildSimpleUvs(uvs, uvsOffset, uvsStride, size) {
	let index = 0;
	uvsOffset *= uvsStride;
	while (index < size) {
		uvs[uvsOffset] = 0;
		uvs[uvsOffset + 1] = 0;
		uvsOffset += uvsStride;
		index++;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/utils/transformVertices.mjs
function transformVertices(vertices, m, offset, stride, size) {
	const a = m.a;
	const b = m.b;
	const c = m.c;
	const d = m.d;
	const tx = m.tx;
	const ty = m.ty;
	offset || (offset = 0);
	stride || (stride = 2);
	size || (size = vertices.length / stride - offset);
	let index = offset * stride;
	for (let i = 0; i < size; i++) {
		const x = vertices[index];
		const y = vertices[index + 1];
		vertices[index] = a * x + c * y + tx;
		vertices[index + 1] = b * x + d * y + ty;
		index += stride;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/BatchableGraphics.mjs
var identityMatrix = new Matrix();
var BatchableGraphics = class {
	constructor() {
		this.packAsQuad = false;
		this.batcherName = "default";
		this.topology = "triangle-list";
		this.applyTransform = true;
		this.roundPixels = 0;
		this._batcher = null;
		this._batch = null;
	}
	get uvs() {
		return this.geometryData.uvs;
	}
	get positions() {
		return this.geometryData.vertices;
	}
	get indices() {
		return this.geometryData.indices;
	}
	get blendMode() {
		if (this.renderable && this.applyTransform) return this.renderable.groupBlendMode;
		return "normal";
	}
	get color() {
		const rgb = this.baseColor;
		const bgr = rgb >> 16 | rgb & 65280 | (rgb & 255) << 16;
		const renderable = this.renderable;
		if (renderable) return multiplyHexColors(bgr, renderable.groupColor) + (this.alpha * renderable.groupAlpha * 255 << 24);
		return bgr + (this.alpha * 255 << 24);
	}
	get transform() {
		return this.renderable?.groupTransform || identityMatrix;
	}
	copyTo(gpuBuffer) {
		gpuBuffer.indexOffset = this.indexOffset;
		gpuBuffer.indexSize = this.indexSize;
		gpuBuffer.attributeOffset = this.attributeOffset;
		gpuBuffer.attributeSize = this.attributeSize;
		gpuBuffer.baseColor = this.baseColor;
		gpuBuffer.alpha = this.alpha;
		gpuBuffer.texture = this.texture;
		gpuBuffer.geometryData = this.geometryData;
		gpuBuffer.topology = this.topology;
	}
	reset() {
		this.applyTransform = true;
		this.renderable = null;
		this.topology = "triangle-list";
	}
	destroy() {
		this.renderable = null;
		this.texture = null;
		this.geometryData = null;
		this._batcher = null;
		this._batch = null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildCircle.mjs
var buildCircle = {
	extension: {
		type: ExtensionType.ShapeBuilder,
		name: "circle"
	},
	build(shape, points) {
		let x;
		let y;
		let dx;
		let dy;
		let rx;
		let ry;
		if (shape.type === "circle") {
			const circle = shape;
			rx = ry = circle.radius;
			if (rx <= 0) return false;
			x = circle.x;
			y = circle.y;
			dx = dy = 0;
		} else if (shape.type === "ellipse") {
			const ellipse = shape;
			rx = ellipse.halfWidth;
			ry = ellipse.halfHeight;
			if (rx <= 0 || ry <= 0) return false;
			x = ellipse.x;
			y = ellipse.y;
			dx = dy = 0;
		} else {
			const roundedRect = shape;
			const halfWidth = roundedRect.width / 2;
			const halfHeight = roundedRect.height / 2;
			x = roundedRect.x + halfWidth;
			y = roundedRect.y + halfHeight;
			rx = ry = Math.max(0, Math.min(roundedRect.radius, Math.min(halfWidth, halfHeight)));
			dx = halfWidth - rx;
			dy = halfHeight - ry;
		}
		if (dx < 0 || dy < 0) return false;
		const n = Math.ceil(2.3 * Math.sqrt(rx + ry));
		const m = n * 8 + (dx ? 4 : 0) + (dy ? 4 : 0);
		if (m === 0) return false;
		if (n === 0) {
			points[0] = points[6] = x + dx;
			points[1] = points[3] = y + dy;
			points[2] = points[4] = x - dx;
			points[5] = points[7] = y - dy;
			return true;
		}
		let j1 = 0;
		let j2 = n * 4 + (dx ? 2 : 0) + 2;
		let j3 = j2;
		let j4 = m;
		let x0 = dx + rx;
		let y0 = dy;
		let x1 = x + x0;
		let x2 = x - x0;
		let y1 = y + y0;
		points[j1++] = x1;
		points[j1++] = y1;
		points[--j2] = y1;
		points[--j2] = x2;
		if (dy) {
			const y22 = y - y0;
			points[j3++] = x2;
			points[j3++] = y22;
			points[--j4] = y22;
			points[--j4] = x1;
		}
		for (let i = 1; i < n; i++) {
			const a = Math.PI / 2 * (i / n);
			const x02 = dx + Math.cos(a) * rx;
			const y02 = dy + Math.sin(a) * ry;
			const x12 = x + x02;
			const x22 = x - x02;
			const y12 = y + y02;
			const y22 = y - y02;
			points[j1++] = x12;
			points[j1++] = y12;
			points[--j2] = y12;
			points[--j2] = x22;
			points[j3++] = x22;
			points[j3++] = y22;
			points[--j4] = y22;
			points[--j4] = x12;
		}
		x0 = dx;
		y0 = dy + ry;
		x1 = x + x0;
		x2 = x - x0;
		y1 = y + y0;
		const y2 = y - y0;
		points[j1++] = x1;
		points[j1++] = y1;
		points[--j4] = y2;
		points[--j4] = x1;
		if (dx) {
			points[j1++] = x2;
			points[j1++] = y1;
			points[--j4] = y2;
			points[--j4] = x2;
		}
		return true;
	},
	triangulate(points, vertices, verticesStride, verticesOffset, indices, indicesOffset) {
		if (points.length === 0) return;
		let centerX = 0;
		let centerY = 0;
		for (let i = 0; i < points.length; i += 2) {
			centerX += points[i];
			centerY += points[i + 1];
		}
		centerX /= points.length / 2;
		centerY /= points.length / 2;
		let count = verticesOffset;
		vertices[count * verticesStride] = centerX;
		vertices[count * verticesStride + 1] = centerY;
		const centerIndex = count++;
		for (let i = 0; i < points.length; i += 2) {
			vertices[count * verticesStride] = points[i];
			vertices[count * verticesStride + 1] = points[i + 1];
			if (i > 0) {
				indices[indicesOffset++] = count;
				indices[indicesOffset++] = centerIndex;
				indices[indicesOffset++] = count - 1;
			}
			count++;
		}
		indices[indicesOffset++] = centerIndex + 1;
		indices[indicesOffset++] = centerIndex;
		indices[indicesOffset++] = count - 1;
	}
};
var buildEllipse = {
	...buildCircle,
	extension: {
		...buildCircle.extension,
		name: "ellipse"
	}
};
var buildRoundedRectangle = {
	...buildCircle,
	extension: {
		...buildCircle.extension,
		name: "roundedRectangle"
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/const.mjs
var closePointEps = 1e-4;
var curveEps = 1e-4;
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildLine.mjs
function square(x, y, nx, ny, innerWeight, outerWeight, clockwise, verts) {
	const ix = x - nx * innerWeight;
	const iy = y - ny * innerWeight;
	const ox = x + nx * outerWeight;
	const oy = y + ny * outerWeight;
	let exx;
	let eyy;
	if (clockwise) {
		exx = ny;
		eyy = -nx;
	} else {
		exx = -ny;
		eyy = nx;
	}
	const eix = ix + exx;
	const eiy = iy + eyy;
	const eox = ox + exx;
	const eoy = oy + eyy;
	verts.push(eix, eiy);
	verts.push(eox, eoy);
	return 2;
}
function round(cx, cy, sx, sy, ex, ey, verts, clockwise) {
	const cx2p0x = sx - cx;
	const cy2p0y = sy - cy;
	let angle0 = Math.atan2(cx2p0x, cy2p0y);
	let angle1 = Math.atan2(ex - cx, ey - cy);
	if (clockwise && angle0 < angle1) angle0 += Math.PI * 2;
	else if (!clockwise && angle0 > angle1) angle1 += Math.PI * 2;
	let startAngle = angle0;
	const angleDiff = angle1 - angle0;
	const absAngleDiff = Math.abs(angleDiff);
	const radius = Math.sqrt(cx2p0x * cx2p0x + cy2p0y * cy2p0y);
	const segCount = (15 * absAngleDiff * Math.sqrt(radius) / Math.PI >> 0) + 1;
	const angleInc = angleDiff / segCount;
	startAngle += angleInc;
	if (clockwise) {
		verts.push(cx, cy);
		verts.push(sx, sy);
		for (let i = 1, angle = startAngle; i < segCount; i++, angle += angleInc) {
			verts.push(cx, cy);
			verts.push(cx + Math.sin(angle) * radius, cy + Math.cos(angle) * radius);
		}
		verts.push(cx, cy);
		verts.push(ex, ey);
	} else {
		verts.push(sx, sy);
		verts.push(cx, cy);
		for (let i = 1, angle = startAngle; i < segCount; i++, angle += angleInc) {
			verts.push(cx + Math.sin(angle) * radius, cy + Math.cos(angle) * radius);
			verts.push(cx, cy);
		}
		verts.push(ex, ey);
		verts.push(cx, cy);
	}
	return segCount * 2;
}
function buildLine(points, lineStyle, flipAlignment, closed, vertices, indices) {
	const eps = closePointEps;
	if (points.length === 0) return;
	const style = lineStyle;
	let alignment = style.alignment;
	if (lineStyle.alignment !== .5) {
		let orientation = getOrientationOfPoints(points);
		if (flipAlignment) orientation *= -1;
		alignment = (alignment - .5) * orientation + .5;
	}
	const firstPoint = new Point(points[0], points[1]);
	const lastPoint = new Point(points[points.length - 2], points[points.length - 1]);
	const closedShape = closed;
	const closedPath = Math.abs(firstPoint.x - lastPoint.x) < eps && Math.abs(firstPoint.y - lastPoint.y) < eps;
	if (closedShape) {
		points = points.slice();
		if (closedPath) {
			points.pop();
			points.pop();
			lastPoint.set(points[points.length - 2], points[points.length - 1]);
		}
		const midPointX = (firstPoint.x + lastPoint.x) * .5;
		const midPointY = (lastPoint.y + firstPoint.y) * .5;
		points.unshift(midPointX, midPointY);
		points.push(midPointX, midPointY);
	}
	const verts = vertices;
	const length = points.length / 2;
	let indexCount = points.length;
	const indexStart = verts.length / 2;
	const width = style.width / 2;
	const widthSquared = width * width;
	const miterLimitSquared = style.miterLimit * style.miterLimit;
	let x0 = points[0];
	let y0 = points[1];
	let x1 = points[2];
	let y1 = points[3];
	let x2 = 0;
	let y2 = 0;
	let perpX = -(y0 - y1);
	let perpY = x0 - x1;
	let perp1x = 0;
	let perp1y = 0;
	let dist = Math.sqrt(perpX * perpX + perpY * perpY);
	perpX /= dist;
	perpY /= dist;
	perpX *= width;
	perpY *= width;
	const ratio = alignment;
	const innerWeight = (1 - ratio) * 2;
	const outerWeight = ratio * 2;
	if (!closedShape) {
		if (style.cap === "round") indexCount += round(x0 - perpX * (innerWeight - outerWeight) * .5, y0 - perpY * (innerWeight - outerWeight) * .5, x0 - perpX * innerWeight, y0 - perpY * innerWeight, x0 + perpX * outerWeight, y0 + perpY * outerWeight, verts, true) + 2;
		else if (style.cap === "square") indexCount += square(x0, y0, perpX, perpY, innerWeight, outerWeight, true, verts);
	}
	verts.push(x0 - perpX * innerWeight, y0 - perpY * innerWeight);
	verts.push(x0 + perpX * outerWeight, y0 + perpY * outerWeight);
	for (let i = 1; i < length - 1; ++i) {
		x0 = points[(i - 1) * 2];
		y0 = points[(i - 1) * 2 + 1];
		x1 = points[i * 2];
		y1 = points[i * 2 + 1];
		x2 = points[(i + 1) * 2];
		y2 = points[(i + 1) * 2 + 1];
		perpX = -(y0 - y1);
		perpY = x0 - x1;
		dist = Math.sqrt(perpX * perpX + perpY * perpY);
		perpX /= dist;
		perpY /= dist;
		perpX *= width;
		perpY *= width;
		perp1x = -(y1 - y2);
		perp1y = x1 - x2;
		dist = Math.sqrt(perp1x * perp1x + perp1y * perp1y);
		perp1x /= dist;
		perp1y /= dist;
		perp1x *= width;
		perp1y *= width;
		const dx0 = x1 - x0;
		const dy0 = y0 - y1;
		const dx1 = x1 - x2;
		const dy1 = y2 - y1;
		const dot = dx0 * dx1 + dy0 * dy1;
		const cross = dy0 * dx1 - dy1 * dx0;
		const clockwise = cross < 0;
		if (Math.abs(cross) < .001 * Math.abs(dot)) {
			verts.push(x1 - perpX * innerWeight, y1 - perpY * innerWeight);
			verts.push(x1 + perpX * outerWeight, y1 + perpY * outerWeight);
			if (dot >= 0) {
				if (style.join === "round") indexCount += round(x1, y1, x1 - perpX * innerWeight, y1 - perpY * innerWeight, x1 - perp1x * innerWeight, y1 - perp1y * innerWeight, verts, false) + 4;
				else indexCount += 2;
				verts.push(x1 - perp1x * outerWeight, y1 - perp1y * outerWeight);
				verts.push(x1 + perp1x * innerWeight, y1 + perp1y * innerWeight);
			}
			continue;
		}
		const c1 = (-perpX + x0) * (-perpY + y1) - (-perpX + x1) * (-perpY + y0);
		const c2 = (-perp1x + x2) * (-perp1y + y1) - (-perp1x + x1) * (-perp1y + y2);
		const px = (dx0 * c2 - dx1 * c1) / cross;
		const py = (dy1 * c1 - dy0 * c2) / cross;
		const pDist = (px - x1) * (px - x1) + (py - y1) * (py - y1);
		const imx = x1 + (px - x1) * innerWeight;
		const imy = y1 + (py - y1) * innerWeight;
		const omx = x1 - (px - x1) * outerWeight;
		const omy = y1 - (py - y1) * outerWeight;
		const smallerInsideSegmentSq = Math.min(dx0 * dx0 + dy0 * dy0, dx1 * dx1 + dy1 * dy1);
		const insideWeight = clockwise ? innerWeight : outerWeight;
		if (pDist <= smallerInsideSegmentSq + insideWeight * insideWeight * widthSquared) {
			if (style.join === "bevel" || pDist / widthSquared > miterLimitSquared) {
				if (clockwise) {
					verts.push(imx, imy);
					verts.push(x1 + perpX * outerWeight, y1 + perpY * outerWeight);
					verts.push(imx, imy);
					verts.push(x1 + perp1x * outerWeight, y1 + perp1y * outerWeight);
				} else {
					verts.push(x1 - perpX * innerWeight, y1 - perpY * innerWeight);
					verts.push(omx, omy);
					verts.push(x1 - perp1x * innerWeight, y1 - perp1y * innerWeight);
					verts.push(omx, omy);
				}
				indexCount += 2;
			} else if (style.join === "round") {
				if (clockwise) {
					verts.push(imx, imy);
					verts.push(x1 + perpX * outerWeight, y1 + perpY * outerWeight);
					indexCount += round(x1, y1, x1 + perpX * outerWeight, y1 + perpY * outerWeight, x1 + perp1x * outerWeight, y1 + perp1y * outerWeight, verts, true) + 4;
					verts.push(imx, imy);
					verts.push(x1 + perp1x * outerWeight, y1 + perp1y * outerWeight);
				} else {
					verts.push(x1 - perpX * innerWeight, y1 - perpY * innerWeight);
					verts.push(omx, omy);
					indexCount += round(x1, y1, x1 - perpX * innerWeight, y1 - perpY * innerWeight, x1 - perp1x * innerWeight, y1 - perp1y * innerWeight, verts, false) + 4;
					verts.push(x1 - perp1x * innerWeight, y1 - perp1y * innerWeight);
					verts.push(omx, omy);
				}
			} else {
				verts.push(imx, imy);
				verts.push(omx, omy);
			}
		} else {
			verts.push(x1 - perpX * innerWeight, y1 - perpY * innerWeight);
			verts.push(x1 + perpX * outerWeight, y1 + perpY * outerWeight);
			if (style.join === "round") {
				if (clockwise) indexCount += round(x1, y1, x1 + perpX * outerWeight, y1 + perpY * outerWeight, x1 + perp1x * outerWeight, y1 + perp1y * outerWeight, verts, true) + 2;
				else indexCount += round(x1, y1, x1 - perpX * innerWeight, y1 - perpY * innerWeight, x1 - perp1x * innerWeight, y1 - perp1y * innerWeight, verts, false) + 2;
			} else if (style.join === "miter" && pDist / widthSquared <= miterLimitSquared) {
				if (clockwise) {
					verts.push(omx, omy);
					verts.push(omx, omy);
				} else {
					verts.push(imx, imy);
					verts.push(imx, imy);
				}
				indexCount += 2;
			}
			verts.push(x1 - perp1x * innerWeight, y1 - perp1y * innerWeight);
			verts.push(x1 + perp1x * outerWeight, y1 + perp1y * outerWeight);
			indexCount += 2;
		}
	}
	x0 = points[(length - 2) * 2];
	y0 = points[(length - 2) * 2 + 1];
	x1 = points[(length - 1) * 2];
	y1 = points[(length - 1) * 2 + 1];
	perpX = -(y0 - y1);
	perpY = x0 - x1;
	dist = Math.sqrt(perpX * perpX + perpY * perpY);
	perpX /= dist;
	perpY /= dist;
	perpX *= width;
	perpY *= width;
	verts.push(x1 - perpX * innerWeight, y1 - perpY * innerWeight);
	verts.push(x1 + perpX * outerWeight, y1 + perpY * outerWeight);
	if (!closedShape) {
		if (style.cap === "round") indexCount += round(x1 - perpX * (innerWeight - outerWeight) * .5, y1 - perpY * (innerWeight - outerWeight) * .5, x1 - perpX * innerWeight, y1 - perpY * innerWeight, x1 + perpX * outerWeight, y1 + perpY * outerWeight, verts, false) + 2;
		else if (style.cap === "square") indexCount += square(x1, y1, perpX, perpY, innerWeight, outerWeight, false, verts);
	}
	const eps2 = curveEps * curveEps;
	for (let i = indexStart; i < indexCount + indexStart - 2; ++i) {
		x0 = verts[i * 2];
		y0 = verts[i * 2 + 1];
		x1 = verts[(i + 1) * 2];
		y1 = verts[(i + 1) * 2 + 1];
		x2 = verts[(i + 2) * 2];
		y2 = verts[(i + 2) * 2 + 1];
		if (Math.abs(x0 * (y1 - y2) + x1 * (y2 - y0) + x2 * (y0 - y1)) < eps2) continue;
		indices.push(i, i + 1, i + 2);
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildPixelLine.mjs
function buildPixelLine(points, closed, vertices, indices) {
	const eps = closePointEps;
	if (points.length === 0) return;
	const fx = points[0];
	const fy = points[1];
	const lx = points[points.length - 2];
	const ly = points[points.length - 1];
	const closePath = closed || Math.abs(fx - lx) < eps && Math.abs(fy - ly) < eps;
	const verts = vertices;
	const length = points.length / 2;
	const indexStart = verts.length / 2;
	for (let i = 0; i < length; i++) {
		verts.push(points[i * 2]);
		verts.push(points[i * 2 + 1]);
	}
	for (let i = 0; i < length - 1; i++) indices.push(indexStart + i, indexStart + i + 1);
	if (closePath) indices.push(indexStart + length - 1, indexStart);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/triangulateWithHoles.mjs
function triangulateWithHoles(points, holes, vertices, verticesStride, verticesOffset, indices, indicesOffset) {
	const triangles = earcut(points, holes, 2);
	if (!triangles) return;
	for (let i = 0; i < triangles.length; i += 3) {
		indices[indicesOffset++] = triangles[i] + verticesOffset;
		indices[indicesOffset++] = triangles[i + 1] + verticesOffset;
		indices[indicesOffset++] = triangles[i + 2] + verticesOffset;
	}
	let index = verticesOffset * verticesStride;
	for (let i = 0; i < points.length; i += 2) {
		vertices[index] = points[i];
		vertices[index + 1] = points[i + 1];
		index += verticesStride;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildPolygon.mjs
var emptyArray = [];
var buildPolygon = {
	extension: {
		type: ExtensionType.ShapeBuilder,
		name: "polygon"
	},
	build(shape, points) {
		for (let i = 0; i < shape.points.length; i++) points[i] = shape.points[i];
		return true;
	},
	triangulate(points, vertices, verticesStride, verticesOffset, indices, indicesOffset) {
		triangulateWithHoles(points, emptyArray, vertices, verticesStride, verticesOffset, indices, indicesOffset);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildRectangle.mjs
var buildRectangle = {
	extension: {
		type: ExtensionType.ShapeBuilder,
		name: "rectangle"
	},
	build(shape, points) {
		const rectData = shape;
		const x = rectData.x;
		const y = rectData.y;
		const width = rectData.width;
		const height = rectData.height;
		if (!(width > 0 && height > 0)) return false;
		points[0] = x;
		points[1] = y;
		points[2] = x + width;
		points[3] = y;
		points[4] = x + width;
		points[5] = y + height;
		points[6] = x;
		points[7] = y + height;
		return true;
	},
	triangulate(points, vertices, verticesStride, verticesOffset, indices, indicesOffset) {
		let count = 0;
		verticesOffset *= verticesStride;
		vertices[verticesOffset + count] = points[0];
		vertices[verticesOffset + count + 1] = points[1];
		count += verticesStride;
		vertices[verticesOffset + count] = points[2];
		vertices[verticesOffset + count + 1] = points[3];
		count += verticesStride;
		vertices[verticesOffset + count] = points[6];
		vertices[verticesOffset + count + 1] = points[7];
		count += verticesStride;
		vertices[verticesOffset + count] = points[4];
		vertices[verticesOffset + count + 1] = points[5];
		count += verticesStride;
		const verticesIndex = verticesOffset / verticesStride;
		indices[indicesOffset++] = verticesIndex;
		indices[indicesOffset++] = verticesIndex + 1;
		indices[indicesOffset++] = verticesIndex + 2;
		indices[indicesOffset++] = verticesIndex + 1;
		indices[indicesOffset++] = verticesIndex + 3;
		indices[indicesOffset++] = verticesIndex + 2;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildTriangle.mjs
var buildTriangle = {
	extension: {
		type: ExtensionType.ShapeBuilder,
		name: "triangle"
	},
	build(shape, points) {
		points[0] = shape.x;
		points[1] = shape.y;
		points[2] = shape.x2;
		points[3] = shape.y2;
		points[4] = shape.x3;
		points[5] = shape.y3;
		return true;
	},
	triangulate(points, vertices, verticesStride, verticesOffset, indices, indicesOffset) {
		let count = 0;
		verticesOffset *= verticesStride;
		vertices[verticesOffset + count] = points[0];
		vertices[verticesOffset + count + 1] = points[1];
		count += verticesStride;
		vertices[verticesOffset + count] = points[2];
		vertices[verticesOffset + count + 1] = points[3];
		count += verticesStride;
		vertices[verticesOffset + count] = points[4];
		vertices[verticesOffset + count + 1] = points[5];
		const verticesIndex = verticesOffset / verticesStride;
		indices[indicesOffset++] = verticesIndex;
		indices[indicesOffset++] = verticesIndex + 1;
		indices[indicesOffset++] = verticesIndex + 2;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/fill/FillGradient.mjs
var emptyColorStops = [{
	offset: 0,
	color: "white"
}, {
	offset: 1,
	color: "black"
}];
var _FillGradient = class _FillGradient {
	constructor(...args) {
		/**
		* Unique identifier for this gradient instance
		* @internal
		*/
		this.uid = uid("fillGradient");
		/**
		* Internal tick counter to track changes in the gradient.
		* This is used to invalidate the gradient when the texture changes.
		* @internal
		*/
		this._tick = 0;
		/** Type of gradient - currently only supports 'linear' */
		this.type = "linear";
		/** Array of color stops defining the gradient */
		this.colorStops = [];
		let options = ensureGradientOptions(args);
		options = {
			...options.type === "radial" ? _FillGradient.defaultRadialOptions : _FillGradient.defaultLinearOptions,
			...definedProps(options)
		};
		this._textureSize = options.textureSize;
		this._wrapMode = options.wrapMode;
		if (options.type === "radial") {
			this.center = options.center;
			this.outerCenter = options.outerCenter ?? this.center;
			this.innerRadius = options.innerRadius;
			this.outerRadius = options.outerRadius;
			this.scale = options.scale;
			this.rotation = options.rotation;
		} else {
			this.start = options.start;
			this.end = options.end;
		}
		this.textureSpace = options.textureSpace;
		this.type = options.type;
		options.colorStops.forEach((stop) => {
			this.addColorStop(stop.offset, stop.color);
		});
	}
	/**
	* Adds a color stop to the gradient
	* @param offset - Position of the stop (0-1)
	* @param color - Color of the stop
	* @returns This gradient instance for chaining
	*/
	addColorStop(offset, color) {
		this.colorStops.push({
			offset,
			color: Color.shared.setValue(color).toHexa()
		});
		return this;
	}
	/**
	* Builds the internal texture and transform for the gradient.
	* Called automatically when the gradient is first used.
	* @internal
	*/
	buildLinearGradient() {
		if (this.texture) return;
		let { x: x0, y: y0 } = this.start;
		let { x: x1, y: y1 } = this.end;
		let dx = x1 - x0;
		let dy = y1 - y0;
		const flip = dx < 0 || dy < 0;
		if (this._wrapMode === "clamp-to-edge") {
			if (dx < 0) {
				const temp = x0;
				x0 = x1;
				x1 = temp;
				dx *= -1;
			}
			if (dy < 0) {
				const temp = y0;
				y0 = y1;
				y1 = temp;
				dy *= -1;
			}
		}
		const colorStops = this.colorStops.length ? this.colorStops : emptyColorStops;
		const defaultSize = this._textureSize;
		const { canvas, context } = getCanvas(defaultSize, 1);
		const gradient = !flip ? context.createLinearGradient(0, 0, this._textureSize, 0) : context.createLinearGradient(this._textureSize, 0, 0, 0);
		addColorStops(gradient, colorStops);
		context.fillStyle = gradient;
		context.fillRect(0, 0, defaultSize, 1);
		this.texture = new Texture({ source: new ImageSource({
			resource: canvas,
			addressMode: this._wrapMode
		}) });
		const dist = Math.sqrt(dx * dx + dy * dy);
		const angle = Math.atan2(dy, dx);
		const m = new Matrix();
		m.scale(dist / defaultSize, 1);
		m.rotate(angle);
		m.translate(x0, y0);
		if (this.textureSpace === "local") m.scale(defaultSize, defaultSize);
		this.transform = m;
	}
	/**
	* Builds the internal texture and transform for the gradient.
	* Called automatically when the gradient is first used.
	* @internal
	*/
	buildGradient() {
		if (!this.texture) this._tick++;
		if (this.type === "linear") this.buildLinearGradient();
		else this.buildRadialGradient();
	}
	/**
	* Builds the internal texture and transform for the radial gradient.
	* Called automatically when the gradient is first used.
	* @internal
	*/
	buildRadialGradient() {
		if (this.texture) return;
		const colorStops = this.colorStops.length ? this.colorStops : emptyColorStops;
		const defaultSize = this._textureSize;
		const { canvas, context } = getCanvas(defaultSize, defaultSize);
		const { x: x0, y: y0 } = this.center;
		const { x: x1, y: y1 } = this.outerCenter;
		const r0 = this.innerRadius;
		const r1 = this.outerRadius;
		const ox = x1 - r1;
		const oy = y1 - r1;
		const scale = defaultSize / (r1 * 2);
		const cx = (x0 - ox) * scale;
		const cy = (y0 - oy) * scale;
		const gradient = context.createRadialGradient(cx, cy, r0 * scale, (x1 - ox) * scale, (y1 - oy) * scale, r1 * scale);
		addColorStops(gradient, colorStops);
		context.fillStyle = colorStops[colorStops.length - 1].color;
		context.fillRect(0, 0, defaultSize, defaultSize);
		context.fillStyle = gradient;
		context.translate(cx, cy);
		context.rotate(this.rotation);
		context.scale(1, this.scale);
		context.translate(-cx, -cy);
		context.fillRect(0, 0, defaultSize, defaultSize);
		this.texture = new Texture({ source: new ImageSource({
			resource: canvas,
			addressMode: this._wrapMode
		}) });
		const m = new Matrix();
		if (this.textureSpace === "local") m.scale(2 * r1, 2 * r1);
		else m.scale(1 / scale, 1 / scale);
		m.translate(ox, oy);
		this.transform = m;
	}
	/** Destroys the gradient, releasing resources. This will also destroy the internal texture. */
	destroy() {
		this.texture?.destroy(true);
		this.texture = null;
		this.transform = null;
		this.colorStops = [];
		this.start = null;
		this.end = null;
		this.center = null;
		this.outerCenter = null;
	}
	/**
	* Returns a unique key for this gradient instance.
	* This key is used for caching and texture management.
	* @returns {string} Unique key for the gradient
	*/
	get styleKey() {
		return `fill-gradient-${this.uid}-${this._tick}`;
	}
};
/** Default options for creating a gradient fill */
_FillGradient.defaultLinearOptions = {
	start: {
		x: 0,
		y: 0
	},
	end: {
		x: 0,
		y: 1
	},
	colorStops: [],
	textureSpace: "local",
	type: "linear",
	textureSize: 256,
	wrapMode: "clamp-to-edge"
};
/** Default options for creating a radial gradient fill */
_FillGradient.defaultRadialOptions = {
	center: {
		x: .5,
		y: .5
	},
	innerRadius: 0,
	outerRadius: .5,
	colorStops: [],
	scale: 1,
	rotation: 0,
	textureSpace: "local",
	type: "radial",
	textureSize: 256,
	wrapMode: "clamp-to-edge"
};
var FillGradient = _FillGradient;
function addColorStops(gradient, colorStops) {
	for (let i = 0; i < colorStops.length; i++) {
		const stop = colorStops[i];
		gradient.addColorStop(stop.offset, stop.color);
	}
}
function getCanvas(width, height) {
	const canvas = DOMAdapter.get().createCanvas(width, height);
	return {
		canvas,
		context: canvas.getContext("2d")
	};
}
function ensureGradientOptions(args) {
	let options = args[0] ?? {};
	if (typeof options === "number" || args[1]) {
		deprecation("8.5.2", `use options object instead`);
		options = {
			type: "linear",
			start: {
				x: args[0],
				y: args[1]
			},
			end: {
				x: args[2],
				y: args[3]
			},
			textureSpace: args[4],
			textureSize: args[5] ?? FillGradient.defaultLinearOptions.textureSize
		};
	}
	return options;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/generateTextureFillMatrix.mjs
var tempTextureMatrix$1 = new Matrix();
var tempRect$1 = new Rectangle();
var tempUvMatrix = new Matrix();
function generateTextureMatrix(out, style, shape, matrix) {
	const textureMatrix = style.matrix ? out.copyFrom(style.matrix).invert() : out.identity();
	if (style.textureSpace === "local") {
		const bounds = shape.getBounds(tempRect$1);
		if (style.width) bounds.pad(style.width);
		const { x: tx, y: ty } = bounds;
		const sx = 1 / bounds.width;
		const sy = 1 / bounds.height;
		const mTx = -tx * sx;
		const mTy = -ty * sy;
		const a1 = textureMatrix.a;
		const b1 = textureMatrix.b;
		const c1 = textureMatrix.c;
		const d1 = textureMatrix.d;
		textureMatrix.a *= sx;
		textureMatrix.b *= sx;
		textureMatrix.c *= sy;
		textureMatrix.d *= sy;
		textureMatrix.tx = mTx * a1 + mTy * c1 + textureMatrix.tx;
		textureMatrix.ty = mTx * b1 + mTy * d1 + textureMatrix.ty;
	} else if (style.texture.rotate) {
		const { uvs, orig } = style.texture;
		textureMatrix.scale(1 / orig.width, 1 / orig.height);
		textureMatrix.prepend(tempUvMatrix.set(uvs.x1 - uvs.x0, uvs.y1 - uvs.y0, uvs.x3 - uvs.x0, uvs.y3 - uvs.y0, uvs.x0, uvs.y0));
	} else {
		textureMatrix.translate(style.texture.frame.x, style.texture.frame.y);
		textureMatrix.scale(1 / style.texture.source.width, 1 / style.texture.source.height);
	}
	const sourceStyle = style.texture.source.style;
	if (!(style.fill instanceof FillGradient) && sourceStyle.addressMode === "clamp-to-edge") {
		sourceStyle.addressMode = "repeat";
		sourceStyle.update();
	}
	if (matrix) textureMatrix.append(tempTextureMatrix$1.copyFrom(matrix).invert());
	return textureMatrix;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/buildContextBatches.mjs
var shapeBuilders = {};
extensions.handleByMap(ExtensionType.ShapeBuilder, shapeBuilders);
extensions.add(buildRectangle, buildPolygon, buildTriangle, buildCircle, buildEllipse, buildRoundedRectangle);
var tempRect = new Rectangle();
var tempTextureMatrix = new Matrix();
function buildContextBatches(context, gpuContext) {
	const { geometryData, batches } = gpuContext;
	batches.length = 0;
	geometryData.indices.length = 0;
	geometryData.vertices.length = 0;
	geometryData.uvs.length = 0;
	for (let i = 0; i < context.instructions.length; i++) {
		const instruction = context.instructions[i];
		if (instruction.action === "texture") addTextureToGeometryData(instruction.data, batches, geometryData);
		else if (instruction.action === "fill" || instruction.action === "stroke") {
			const isStroke = instruction.action === "stroke";
			const shapePath = instruction.data.path.shapePath;
			const style = instruction.data.style;
			const hole = instruction.data.hole;
			if (isStroke && hole) addShapePathToGeometryData(hole.shapePath, style, true, batches, geometryData);
			if (hole) shapePath.shapePrimitives[shapePath.shapePrimitives.length - 1].holes = hole.shapePath.shapePrimitives;
			addShapePathToGeometryData(shapePath, style, isStroke, batches, geometryData);
		}
	}
}
function addTextureToGeometryData(data, batches, geometryData) {
	const points = [];
	const build = shapeBuilders.rectangle;
	const rect = tempRect;
	rect.x = data.dx;
	rect.y = data.dy;
	rect.width = data.dw;
	rect.height = data.dh;
	const matrix = data.transform;
	if (!build.build(rect, points)) return;
	const { vertices, uvs, indices } = geometryData;
	const indexOffset = indices.length;
	const vertOffset = vertices.length / 2;
	if (matrix) transformVertices(points, matrix);
	build.triangulate(points, vertices, 2, vertOffset, indices, indexOffset);
	const texture = data.image;
	const textureUvs = texture.uvs;
	uvs.push(textureUvs.x0, textureUvs.y0, textureUvs.x1, textureUvs.y1, textureUvs.x3, textureUvs.y3, textureUvs.x2, textureUvs.y2);
	const graphicsBatch = BigPool.get(BatchableGraphics);
	graphicsBatch.indexOffset = indexOffset;
	graphicsBatch.indexSize = indices.length - indexOffset;
	graphicsBatch.attributeOffset = vertOffset;
	graphicsBatch.attributeSize = vertices.length / 2 - vertOffset;
	graphicsBatch.baseColor = data.style;
	graphicsBatch.alpha = data.alpha;
	graphicsBatch.texture = texture;
	graphicsBatch.geometryData = geometryData;
	batches.push(graphicsBatch);
}
function addShapePathToGeometryData(shapePath, style, isStroke, batches, geometryData) {
	const { vertices, uvs, indices } = geometryData;
	shapePath.shapePrimitives.forEach(({ shape, transform: matrix, holes }) => {
		const points = [];
		const build = shapeBuilders[shape.type];
		if (!build.build(shape, points)) return;
		const indexOffset = indices.length;
		const vertOffset = vertices.length / 2;
		let topology = "triangle-list";
		if (matrix) transformVertices(points, matrix);
		if (!isStroke) {
			if (holes) {
				const holeIndices = [];
				const otherPoints = points.slice();
				getHoleArrays(holes).forEach((holePoints) => {
					holeIndices.push(otherPoints.length / 2);
					otherPoints.push(...holePoints);
				});
				triangulateWithHoles(otherPoints, holeIndices, vertices, 2, vertOffset, indices, indexOffset);
			} else build.triangulate(points, vertices, 2, vertOffset, indices, indexOffset);
		} else {
			const close = shape.closePath ?? true;
			const lineStyle = style;
			if (!lineStyle.pixelLine) buildLine(points, lineStyle, false, close, vertices, indices);
			else {
				buildPixelLine(points, close, vertices, indices);
				topology = "line-list";
			}
		}
		const uvsOffset = uvs.length / 2;
		const texture = style.texture;
		if (texture !== Texture.WHITE) {
			const textureMatrix = generateTextureMatrix(tempTextureMatrix, style, shape, matrix);
			buildUvs(vertices, 2, vertOffset, uvs, uvsOffset, 2, vertices.length / 2 - vertOffset, textureMatrix);
		} else buildSimpleUvs(uvs, uvsOffset, 2, vertices.length / 2 - vertOffset);
		const graphicsBatch = BigPool.get(BatchableGraphics);
		graphicsBatch.indexOffset = indexOffset;
		graphicsBatch.indexSize = indices.length - indexOffset;
		graphicsBatch.attributeOffset = vertOffset;
		graphicsBatch.attributeSize = vertices.length / 2 - vertOffset;
		graphicsBatch.baseColor = style.color;
		graphicsBatch.alpha = style.alpha;
		graphicsBatch.texture = texture;
		graphicsBatch.geometryData = geometryData;
		graphicsBatch.topology = topology;
		batches.push(graphicsBatch);
	});
}
function getHoleArrays(holePrimitives) {
	const holeArrays = [];
	for (let k = 0; k < holePrimitives.length; k++) {
		const holePrimitive = holePrimitives[k].shape;
		const holePoints = [];
		if (shapeBuilders[holePrimitive.type].build(holePrimitive, holePoints)) holeArrays.push(holePoints);
	}
	return holeArrays;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/GraphicsContextSystem.mjs
var GpuGraphicsContext = class {
	constructor() {
		this.batches = [];
		this.geometryData = {
			vertices: [],
			uvs: [],
			indices: []
		};
	}
	reset() {
		if (this.batches) this.batches.forEach((batch) => {
			BigPool.return(batch);
		});
		if (this.graphicsData) BigPool.return(this.graphicsData);
		this.isBatchable = false;
		this.context = null;
		this.batches.length = 0;
		this.geometryData.indices.length = 0;
		this.geometryData.vertices.length = 0;
		this.geometryData.uvs.length = 0;
		this.graphicsData = null;
	}
	destroy() {
		this.reset();
		this.batches = null;
		this.geometryData = null;
	}
};
var GraphicsContextRenderData = class {
	constructor() {
		this.instructions = new InstructionSet();
	}
	init(options) {
		const maxTextures = options.maxTextures;
		this.batcher ? this.batcher._updateMaxTextures(maxTextures) : this.batcher = new DefaultBatcher({ maxTextures });
		this.instructions.reset();
	}
	/**
	* @deprecated since version 8.0.0
	* Use `batcher.geometry` instead.
	* @see {Batcher#geometry}
	*/
	get geometry() {
		deprecation(v8_3_4, "GraphicsContextRenderData#geometry is deprecated, please use batcher.geometry instead.");
		return this.batcher.geometry;
	}
	destroy() {
		this.batcher.destroy();
		this.instructions.destroy();
		this.batcher = null;
		this.instructions = null;
	}
};
var _GraphicsContextSystem = class _GraphicsContextSystem {
	constructor(renderer) {
		this._renderer = renderer;
		this._managedContexts = new GCManagedHash({
			renderer,
			type: "resource",
			name: "graphicsContext"
		});
	}
	/**
	* Runner init called, update the default options
	* @ignore
	*/
	init(options) {
		_GraphicsContextSystem.defaultOptions.bezierSmoothness = options?.bezierSmoothness ?? _GraphicsContextSystem.defaultOptions.bezierSmoothness;
	}
	/**
	* Returns the render data for a given GraphicsContext.
	* @param context - The GraphicsContext to get the render data for.
	* @internal
	*/
	getContextRenderData(context) {
		return context._gpuData[this._renderer.uid].graphicsData || this._initContextRenderData(context);
	}
	/**
	* Updates the GPU context for a given GraphicsContext.
	* If the context is dirty, it will rebuild the batches and geometry data.
	* @param context - The GraphicsContext to update.
	* @returns The updated GpuGraphicsContext.
	* @internal
	*/
	updateGpuContext(context) {
		const hasContext = !!context._gpuData[this._renderer.uid];
		const gpuContext = context._gpuData[this._renderer.uid] || this._initContext(context);
		if (context.dirty || !hasContext) {
			if (hasContext) gpuContext.reset();
			buildContextBatches(context, gpuContext);
			const batchMode = context.batchMode;
			if (context.customShader || batchMode === "no-batch") gpuContext.isBatchable = false;
			else if (batchMode === "auto") gpuContext.isBatchable = gpuContext.geometryData.vertices.length < 400;
			else gpuContext.isBatchable = true;
			context.dirty = false;
		}
		return gpuContext;
	}
	/**
	* Returns the GpuGraphicsContext for a given GraphicsContext.
	* If it does not exist, it will initialize a new one.
	* @param context - The GraphicsContext to get the GpuGraphicsContext for.
	* @returns The GpuGraphicsContext for the given GraphicsContext.
	* @internal
	*/
	getGpuContext(context) {
		return context._gpuData[this._renderer.uid] || this._initContext(context);
	}
	_initContextRenderData(context) {
		const graphicsData = BigPool.get(GraphicsContextRenderData, { maxTextures: this._renderer.limits.maxBatchableTextures });
		const gpuContext = context._gpuData[this._renderer.uid];
		const { batches, geometryData } = gpuContext;
		gpuContext.graphicsData = graphicsData;
		const vertexSize = geometryData.vertices.length;
		const indexSize = geometryData.indices.length;
		for (let i = 0; i < batches.length; i++) batches[i].applyTransform = false;
		const batcher = graphicsData.batcher;
		batcher.ensureAttributeBuffer(vertexSize);
		batcher.ensureIndexBuffer(indexSize);
		batcher.begin();
		for (let i = 0; i < batches.length; i++) {
			const batch = batches[i];
			batcher.add(batch);
		}
		batcher.finish(graphicsData.instructions);
		const geometry = batcher.geometry;
		geometry.indexBuffer.setDataWithSize(batcher.indexBuffer, batcher.indexSize, true);
		geometry.buffers[0].setDataWithSize(batcher.attributeBuffer.float32View, batcher.attributeSize, true);
		const drawBatches = batcher.batches;
		for (let i = 0; i < batcher.batchIndex; i++) {
			const batch = drawBatches[i];
			batch.bindGroup = getTextureBatchBindGroup(batch.textures.textures, batch.textures.count, this._renderer.limits.maxBatchableTextures);
		}
		return graphicsData;
	}
	_initContext(context) {
		const gpuContext = new GpuGraphicsContext();
		gpuContext.context = context;
		context._gpuData[this._renderer.uid] = gpuContext;
		this._managedContexts.add(context);
		return gpuContext;
	}
	destroy() {
		this._managedContexts.destroy();
		this._renderer = null;
	}
};
/** @ignore */
_GraphicsContextSystem.extension = {
	type: [ExtensionType.WebGLSystem, ExtensionType.WebGPUSystem],
	name: "graphicsContext"
};
/** The default options for the GraphicsContextSystem. */
_GraphicsContextSystem.defaultOptions = { 
/**
* A value from 0 to 1 that controls the smoothness of bezier curves (the higher the smoother)
* @default 0.5
*/
bezierSmoothness: .5 };
var GraphicsContextSystem = _GraphicsContextSystem;
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildAdaptiveBezier.mjs
var RECURSION_LIMIT$1 = 8;
var FLT_EPSILON$1 = 1.1920929e-7;
var PATH_DISTANCE_EPSILON$1 = 1;
function buildAdaptiveBezier(points, sX, sY, cp1x, cp1y, cp2x, cp2y, eX, eY, smoothness) {
	let distanceTolerance = (PATH_DISTANCE_EPSILON$1 - Math.min(.99, Math.max(0, smoothness ?? GraphicsContextSystem.defaultOptions.bezierSmoothness))) / 1;
	distanceTolerance *= distanceTolerance;
	begin$1(sX, sY, cp1x, cp1y, cp2x, cp2y, eX, eY, points, distanceTolerance);
	return points;
}
function begin$1(sX, sY, cp1x, cp1y, cp2x, cp2y, eX, eY, points, distanceTolerance) {
	recursive$1(sX, sY, cp1x, cp1y, cp2x, cp2y, eX, eY, points, distanceTolerance, 0);
	points.push(eX, eY);
}
function recursive$1(x1, y1, x2, y2, x3, y3, x4, y4, points, distanceTolerance, level) {
	if (level > RECURSION_LIMIT$1) return;
	const x12 = (x1 + x2) / 2;
	const y12 = (y1 + y2) / 2;
	const x23 = (x2 + x3) / 2;
	const y23 = (y2 + y3) / 2;
	const x34 = (x3 + x4) / 2;
	const y34 = (y3 + y4) / 2;
	const x123 = (x12 + x23) / 2;
	const y123 = (y12 + y23) / 2;
	const x234 = (x23 + x34) / 2;
	const y234 = (y23 + y34) / 2;
	const x1234 = (x123 + x234) / 2;
	const y1234 = (y123 + y234) / 2;
	if (level > 0) {
		let dx = x4 - x1;
		let dy = y4 - y1;
		const d2 = Math.abs((x2 - x4) * dy - (y2 - y4) * dx);
		const d3 = Math.abs((x3 - x4) * dy - (y3 - y4) * dx);
		if (d2 > FLT_EPSILON$1 && d3 > FLT_EPSILON$1) {
			if ((d2 + d3) * (d2 + d3) <= distanceTolerance * (dx * dx + dy * dy)) {
				points.push(x1234, y1234);
				return;
			}
		} else if (d2 > FLT_EPSILON$1) {
			if (d2 * d2 <= distanceTolerance * (dx * dx + dy * dy)) {
				points.push(x1234, y1234);
				return;
			}
		} else if (d3 > FLT_EPSILON$1) {
			if (d3 * d3 <= distanceTolerance * (dx * dx + dy * dy)) {
				points.push(x1234, y1234);
				return;
			}
		} else {
			dx = x1234 - (x1 + x4) / 2;
			dy = y1234 - (y1 + y4) / 2;
			if (dx * dx + dy * dy <= distanceTolerance) {
				points.push(x1234, y1234);
				return;
			}
		}
	}
	recursive$1(x1, y1, x12, y12, x123, y123, x1234, y1234, points, distanceTolerance, level + 1);
	recursive$1(x1234, y1234, x234, y234, x34, y34, x4, y4, points, distanceTolerance, level + 1);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildAdaptiveQuadratic.mjs
var RECURSION_LIMIT = 8;
var FLT_EPSILON = 1.1920929e-7;
var PATH_DISTANCE_EPSILON = 1;
function buildAdaptiveQuadratic(points, sX, sY, cp1x, cp1y, eX, eY, smoothness) {
	let distanceTolerance = (PATH_DISTANCE_EPSILON - Math.min(.99, Math.max(0, smoothness ?? GraphicsContextSystem.defaultOptions.bezierSmoothness))) / 1;
	distanceTolerance *= distanceTolerance;
	begin(sX, sY, cp1x, cp1y, eX, eY, points, distanceTolerance);
	return points;
}
function begin(sX, sY, cp1x, cp1y, eX, eY, points, distanceTolerance) {
	recursive(points, sX, sY, cp1x, cp1y, eX, eY, distanceTolerance, 0);
	points.push(eX, eY);
}
function recursive(points, x1, y1, x2, y2, x3, y3, distanceTolerance, level) {
	if (level > RECURSION_LIMIT) return;
	const x12 = (x1 + x2) / 2;
	const y12 = (y1 + y2) / 2;
	const x23 = (x2 + x3) / 2;
	const y23 = (y2 + y3) / 2;
	const x123 = (x12 + x23) / 2;
	const y123 = (y12 + y23) / 2;
	let dx = x3 - x1;
	let dy = y3 - y1;
	const d = Math.abs((x2 - x3) * dy - (y2 - y3) * dx);
	if (d > FLT_EPSILON) {
		if (d * d <= distanceTolerance * (dx * dx + dy * dy)) {
			points.push(x123, y123);
			return;
		}
	} else {
		dx = x123 - (x1 + x3) / 2;
		dy = y123 - (y1 + y3) / 2;
		if (dx * dx + dy * dy <= distanceTolerance) {
			points.push(x123, y123);
			return;
		}
	}
	recursive(points, x1, y1, x12, y12, x123, y123, distanceTolerance, level + 1);
	recursive(points, x123, y123, x23, y23, x3, y3, distanceTolerance, level + 1);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildArc.mjs
function buildArc(points, x, y, radius, start, end, clockwise, steps) {
	let dist = Math.abs(start - end);
	if (!clockwise && start > end) dist = 2 * Math.PI - dist;
	else if (clockwise && end > start) dist = 2 * Math.PI - dist;
	steps || (steps = Math.max(6, Math.floor(6 * Math.pow(radius, 1 / 3) * (dist / Math.PI))));
	steps = Math.max(steps, 3);
	let f = dist / steps;
	let t = start;
	f *= clockwise ? -1 : 1;
	for (let i = 0; i < steps + 1; i++) {
		const cs = Math.cos(t);
		const sn = Math.sin(t);
		const nx = x + cs * radius;
		const ny = y + sn * radius;
		points.push(nx, ny);
		t += f;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildArcTo.mjs
function buildArcTo(points, x1, y1, x2, y2, radius) {
	const fromX = points[points.length - 2];
	const a1 = points[points.length - 1] - y1;
	const b1 = fromX - x1;
	const a2 = y2 - y1;
	const b2 = x2 - x1;
	const mm = Math.abs(a1 * b2 - b1 * a2);
	if (mm < 1e-8 || radius === 0) {
		if (points[points.length - 2] !== x1 || points[points.length - 1] !== y1) points.push(x1, y1);
		return;
	}
	const dd = a1 * a1 + b1 * b1;
	const cc = a2 * a2 + b2 * b2;
	const tt = a1 * a2 + b1 * b2;
	const k1 = radius * Math.sqrt(dd) / mm;
	const k2 = radius * Math.sqrt(cc) / mm;
	const j1 = k1 * tt / dd;
	const j2 = k2 * tt / cc;
	const cx = k1 * b2 + k2 * b1;
	const cy = k1 * a2 + k2 * a1;
	const px = b1 * (k2 + j1);
	const py = a1 * (k2 + j1);
	const qx = b2 * (k1 + j2);
	const qy = a2 * (k1 + j2);
	const startAngle = Math.atan2(py - cy, px - cx);
	const endAngle = Math.atan2(qy - cy, qx - cx);
	buildArc(points, cx + x1, cy + y1, radius, startAngle, endAngle, b1 * a2 > b2 * a1);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/buildCommands/buildArcToSvg.mjs
var TAU = Math.PI * 2;
var out = {
	centerX: 0,
	centerY: 0,
	ang1: 0,
	ang2: 0
};
var mapToEllipse = ({ x, y }, rx, ry, cosPhi, sinPhi, centerX, centerY, out2) => {
	x *= rx;
	y *= ry;
	const xp = cosPhi * x - sinPhi * y;
	const yp = sinPhi * x + cosPhi * y;
	out2.x = xp + centerX;
	out2.y = yp + centerY;
	return out2;
};
function approxUnitArc(ang1, ang2) {
	const a1 = ang2 === -1.5707963267948966 ? -.551915024494 : 4 / 3 * Math.tan(ang2 / 4);
	const a = ang2 === 1.5707963267948966 ? .551915024494 : a1;
	const x1 = Math.cos(ang1);
	const y1 = Math.sin(ang1);
	const x2 = Math.cos(ang1 + ang2);
	const y2 = Math.sin(ang1 + ang2);
	return [
		{
			x: x1 - y1 * a,
			y: y1 + x1 * a
		},
		{
			x: x2 + y2 * a,
			y: y2 - x2 * a
		},
		{
			x: x2,
			y: y2
		}
	];
}
var vectorAngle = (ux, uy, vx, vy) => {
	const sign = ux * vy - uy * vx < 0 ? -1 : 1;
	let dot = ux * vx + uy * vy;
	if (dot > 1) dot = 1;
	if (dot < -1) dot = -1;
	return sign * Math.acos(dot);
};
var getArcCenter = (px, py, cx, cy, rx, ry, largeArcFlag, sweepFlag, sinPhi, cosPhi, pxp, pyp, out2) => {
	const rxSq = Math.pow(rx, 2);
	const rySq = Math.pow(ry, 2);
	const pxpSq = Math.pow(pxp, 2);
	const pypSq = Math.pow(pyp, 2);
	let radicant = rxSq * rySq - rxSq * pypSq - rySq * pxpSq;
	if (radicant < 0) radicant = 0;
	radicant /= rxSq * pypSq + rySq * pxpSq;
	radicant = Math.sqrt(radicant) * (largeArcFlag === sweepFlag ? -1 : 1);
	const centerXp = radicant * rx / ry * pyp;
	const centerYp = radicant * -ry / rx * pxp;
	const centerX = cosPhi * centerXp - sinPhi * centerYp + (px + cx) / 2;
	const centerY = sinPhi * centerXp + cosPhi * centerYp + (py + cy) / 2;
	const vx1 = (pxp - centerXp) / rx;
	const vy1 = (pyp - centerYp) / ry;
	const vx2 = (-pxp - centerXp) / rx;
	const vy2 = (-pyp - centerYp) / ry;
	const ang1 = vectorAngle(1, 0, vx1, vy1);
	let ang2 = vectorAngle(vx1, vy1, vx2, vy2);
	if (sweepFlag === 0 && ang2 > 0) ang2 -= TAU;
	if (sweepFlag === 1 && ang2 < 0) ang2 += TAU;
	out2.centerX = centerX;
	out2.centerY = centerY;
	out2.ang1 = ang1;
	out2.ang2 = ang2;
};
function buildArcToSvg(points, px, py, cx, cy, rx, ry, xAxisRotation = 0, largeArcFlag = 0, sweepFlag = 0) {
	if (rx === 0 || ry === 0) return;
	const sinPhi = Math.sin(xAxisRotation * TAU / 360);
	const cosPhi = Math.cos(xAxisRotation * TAU / 360);
	const pxp = cosPhi * (px - cx) / 2 + sinPhi * (py - cy) / 2;
	const pyp = -sinPhi * (px - cx) / 2 + cosPhi * (py - cy) / 2;
	if (pxp === 0 && pyp === 0) return;
	rx = Math.abs(rx);
	ry = Math.abs(ry);
	const lambda = Math.pow(pxp, 2) / Math.pow(rx, 2) + Math.pow(pyp, 2) / Math.pow(ry, 2);
	if (lambda > 1) {
		rx *= Math.sqrt(lambda);
		ry *= Math.sqrt(lambda);
	}
	getArcCenter(px, py, cx, cy, rx, ry, largeArcFlag, sweepFlag, sinPhi, cosPhi, pxp, pyp, out);
	let { ang1, ang2 } = out;
	const { centerX, centerY } = out;
	let ratio = Math.abs(ang2) / (TAU / 4);
	if (Math.abs(1 - ratio) < 1e-7) ratio = 1;
	const segments = Math.max(Math.ceil(ratio), 1);
	ang2 /= segments;
	let lastX = points[points.length - 2];
	let lastY = points[points.length - 1];
	const outCurvePoint = {
		x: 0,
		y: 0
	};
	for (let i = 0; i < segments; i++) {
		const curve = approxUnitArc(ang1, ang2);
		const { x: x1, y: y1 } = mapToEllipse(curve[0], rx, ry, cosPhi, sinPhi, centerX, centerY, outCurvePoint);
		const { x: x2, y: y2 } = mapToEllipse(curve[1], rx, ry, cosPhi, sinPhi, centerX, centerY, outCurvePoint);
		const { x, y } = mapToEllipse(curve[2], rx, ry, cosPhi, sinPhi, centerX, centerY, outCurvePoint);
		buildAdaptiveBezier(points, lastX, lastY, x1, y1, x2, y2, x, y);
		lastX = x;
		lastY = y;
		ang1 += ang2;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/path/roundShape.mjs
function roundedShapeArc(g, points, radius) {
	const vecFrom = (p, pp) => {
		const x = pp.x - p.x;
		const y = pp.y - p.y;
		const len = Math.sqrt(x * x + y * y);
		return {
			len,
			nx: x / len,
			ny: y / len
		};
	};
	const sharpCorner = (i, p) => {
		if (i === 0) g.moveTo(p.x, p.y);
		else g.lineTo(p.x, p.y);
	};
	let p1 = points[points.length - 1];
	for (let i = 0; i < points.length; i++) {
		const p2 = points[i % points.length];
		const pRadius = p2.radius ?? radius;
		if (pRadius <= 0) {
			sharpCorner(i, p2);
			p1 = p2;
			continue;
		}
		const p3 = points[(i + 1) % points.length];
		const v1 = vecFrom(p2, p1);
		const v2 = vecFrom(p2, p3);
		if (v1.len < 1e-4 || v2.len < 1e-4) {
			sharpCorner(i, p2);
			p1 = p2;
			continue;
		}
		let angle = Math.asin(v1.nx * v2.ny - v1.ny * v2.nx);
		let radDirection = 1;
		let drawDirection = false;
		if (v1.nx * v2.nx - v1.ny * -v2.ny < 0) {
			if (angle < 0) angle = Math.PI + angle;
			else {
				angle = Math.PI - angle;
				radDirection = -1;
				drawDirection = true;
			}
		} else if (angle > 0) {
			radDirection = -1;
			drawDirection = true;
		}
		const halfAngle = angle / 2;
		let cRadius;
		let lenOut = Math.abs(Math.cos(halfAngle) * pRadius / Math.sin(halfAngle));
		if (lenOut > Math.min(v1.len / 2, v2.len / 2)) {
			lenOut = Math.min(v1.len / 2, v2.len / 2);
			cRadius = Math.abs(lenOut * Math.sin(halfAngle) / Math.cos(halfAngle));
		} else cRadius = pRadius;
		const cX = p2.x + v2.nx * lenOut + -v2.ny * cRadius * radDirection;
		const cY = p2.y + v2.ny * lenOut + v2.nx * cRadius * radDirection;
		const startAngle = Math.atan2(v1.ny, v1.nx) + Math.PI / 2 * radDirection;
		const endAngle = Math.atan2(v2.ny, v2.nx) - Math.PI / 2 * radDirection;
		if (i === 0) g.moveTo(cX + Math.cos(startAngle) * cRadius, cY + Math.sin(startAngle) * cRadius);
		g.arc(cX, cY, cRadius, startAngle, endAngle, drawDirection);
		p1 = p2;
	}
}
function roundedShapeQuadraticCurve(g, points, radius, smoothness) {
	const distance = (p1, p2) => Math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2);
	const pointLerp = (p1, p2, t) => ({
		x: p1.x + (p2.x - p1.x) * t,
		y: p1.y + (p2.y - p1.y) * t
	});
	const numPoints = points.length;
	for (let i = 0; i < numPoints; i++) {
		const thisPoint = points[(i + 1) % numPoints];
		const pRadius = thisPoint.radius ?? radius;
		if (pRadius <= 0) {
			if (i === 0) g.moveTo(thisPoint.x, thisPoint.y);
			else g.lineTo(thisPoint.x, thisPoint.y);
			continue;
		}
		const lastPoint = points[i];
		const nextPoint = points[(i + 2) % numPoints];
		const lastEdgeLength = distance(lastPoint, thisPoint);
		let start;
		if (lastEdgeLength < 1e-4) start = thisPoint;
		else start = pointLerp(thisPoint, lastPoint, Math.min(lastEdgeLength / 2, pRadius) / lastEdgeLength);
		const nextEdgeLength = distance(nextPoint, thisPoint);
		let end;
		if (nextEdgeLength < 1e-4) end = thisPoint;
		else end = pointLerp(thisPoint, nextPoint, Math.min(nextEdgeLength / 2, pRadius) / nextEdgeLength);
		if (i === 0) g.moveTo(start.x, start.y);
		else g.lineTo(start.x, start.y);
		g.quadraticCurveTo(thisPoint.x, thisPoint.y, end.x, end.y, smoothness);
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/path/ShapePath.mjs
var tempRectangle = new Rectangle();
var ShapePath = class {
	constructor(graphicsPath2D) {
		/** The list of shape primitives that make up the path. */
		this.shapePrimitives = [];
		this._currentPoly = null;
		this._bounds = new Bounds();
		this._graphicsPath2D = graphicsPath2D;
		this.signed = graphicsPath2D.checkForHoles;
	}
	/**
	* Sets the starting point for a new sub-path. Any subsequent drawing commands are considered part of this path.
	* @param x - The x-coordinate for the starting point.
	* @param y - The y-coordinate for the starting point.
	* @returns The instance of the current object for chaining.
	*/
	moveTo(x, y) {
		this.startPoly(x, y);
		return this;
	}
	/**
	* Connects the current point to a new point with a straight line. This method updates the current path.
	* @param x - The x-coordinate of the new point to connect to.
	* @param y - The y-coordinate of the new point to connect to.
	* @returns The instance of the current object for chaining.
	*/
	lineTo(x, y) {
		this._ensurePoly();
		const points = this._currentPoly.points;
		const fromX = points[points.length - 2];
		const fromY = points[points.length - 1];
		if (fromX !== x || fromY !== y) points.push(x, y);
		return this;
	}
	/**
	* Adds an arc to the path. The arc is centered at (x, y)
	*  position with radius `radius` starting at `startAngle` and ending at `endAngle`.
	* @param x - The x-coordinate of the arc's center.
	* @param y - The y-coordinate of the arc's center.
	* @param radius - The radius of the arc.
	* @param startAngle - The starting angle of the arc, in radians.
	* @param endAngle - The ending angle of the arc, in radians.
	* @param counterclockwise - Specifies whether the arc should be drawn in the anticlockwise direction. False by default.
	* @returns The instance of the current object for chaining.
	*/
	arc(x, y, radius, startAngle, endAngle, counterclockwise) {
		this._ensurePoly(false);
		const points = this._currentPoly.points;
		buildArc(points, x, y, radius, startAngle, endAngle, counterclockwise);
		return this;
	}
	/**
	* Adds an arc to the path with the arc tangent to the line joining two specified points.
	* The arc radius is specified by `radius`.
	* @param x1 - The x-coordinate of the first point.
	* @param y1 - The y-coordinate of the first point.
	* @param x2 - The x-coordinate of the second point.
	* @param y2 - The y-coordinate of the second point.
	* @param radius - The radius of the arc.
	* @returns The instance of the current object for chaining.
	*/
	arcTo(x1, y1, x2, y2, radius) {
		this._ensurePoly();
		const points = this._currentPoly.points;
		buildArcTo(points, x1, y1, x2, y2, radius);
		return this;
	}
	/**
	* Adds an SVG-style arc to the path, allowing for elliptical arcs based on the SVG spec.
	* @param rx - The x-radius of the ellipse.
	* @param ry - The y-radius of the ellipse.
	* @param xAxisRotation - The rotation of the ellipse's x-axis relative
	* to the x-axis of the coordinate system, in degrees.
	* @param largeArcFlag - Determines if the arc should be greater than or less than 180 degrees.
	* @param sweepFlag - Determines if the arc should be swept in a positive angle direction.
	* @param x - The x-coordinate of the arc's end point.
	* @param y - The y-coordinate of the arc's end point.
	* @returns The instance of the current object for chaining.
	*/
	arcToSvg(rx, ry, xAxisRotation, largeArcFlag, sweepFlag, x, y) {
		const points = this._currentPoly.points;
		buildArcToSvg(points, this._currentPoly.lastX, this._currentPoly.lastY, x, y, rx, ry, xAxisRotation, largeArcFlag, sweepFlag);
		return this;
	}
	/**
	* Adds a cubic Bezier curve to the path.
	* It requires three points: the first two are control points and the third one is the end point.
	* The starting point is the last point in the current path.
	* @param cp1x - The x-coordinate of the first control point.
	* @param cp1y - The y-coordinate of the first control point.
	* @param cp2x - The x-coordinate of the second control point.
	* @param cp2y - The y-coordinate of the second control point.
	* @param x - The x-coordinate of the end point.
	* @param y - The y-coordinate of the end point.
	* @param smoothness - Optional parameter to adjust the smoothness of the curve.
	* @returns The instance of the current object for chaining.
	*/
	bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y, smoothness) {
		this._ensurePoly();
		const currentPoly = this._currentPoly;
		buildAdaptiveBezier(this._currentPoly.points, currentPoly.lastX, currentPoly.lastY, cp1x, cp1y, cp2x, cp2y, x, y, smoothness);
		return this;
	}
	/**
	* Adds a quadratic curve to the path. It requires two points: the control point and the end point.
	* The starting point is the last point in the current path.
	* @param cp1x - The x-coordinate of the control point.
	* @param cp1y - The y-coordinate of the control point.
	* @param x - The x-coordinate of the end point.
	* @param y - The y-coordinate of the end point.
	* @param smoothing - Optional parameter to adjust the smoothness of the curve.
	* @returns The instance of the current object for chaining.
	*/
	quadraticCurveTo(cp1x, cp1y, x, y, smoothing) {
		this._ensurePoly();
		const currentPoly = this._currentPoly;
		buildAdaptiveQuadratic(this._currentPoly.points, currentPoly.lastX, currentPoly.lastY, cp1x, cp1y, x, y, smoothing);
		return this;
	}
	/**
	* Closes the current path by drawing a straight line back to the start.
	* If the shape is already closed or there are no points in the path, this method does nothing.
	* @returns The instance of the current object for chaining.
	*/
	closePath() {
		this.endPoly(true);
		return this;
	}
	/**
	* Adds another path to the current path. This method allows for the combination of multiple paths into one.
	* @param path - The `GraphicsPath` object representing the path to add.
	* @param transform - An optional `Matrix` object to apply a transformation to the path before adding it.
	* @returns The instance of the current object for chaining.
	*/
	addPath(path, transform) {
		this.endPoly();
		if (transform && !transform.isIdentity()) {
			path = path.clone(true);
			path.transform(transform);
		}
		const shapePrimitives = this.shapePrimitives;
		const start = shapePrimitives.length;
		for (let i = 0; i < path.instructions.length; i++) {
			const instruction = path.instructions[i];
			this[instruction.action](...instruction.data);
		}
		if (path.checkForHoles && shapePrimitives.length - start > 1) {
			let mainShape = null;
			for (let i = start; i < shapePrimitives.length; i++) {
				const shapePrimitive = shapePrimitives[i];
				if (shapePrimitive.shape.type === "polygon") {
					const polygon = shapePrimitive.shape;
					const mainPolygon = mainShape?.shape;
					if (mainPolygon && mainPolygon.containsPolygon(polygon)) {
						mainShape.holes || (mainShape.holes = []);
						mainShape.holes.push(shapePrimitive);
						shapePrimitives.copyWithin(i, i + 1);
						shapePrimitives.length--;
						i--;
					} else mainShape = shapePrimitive;
				}
			}
		}
		return this;
	}
	/**
	* Finalizes the drawing of the current path. Optionally, it can close the path.
	* @param closePath - A boolean indicating whether to close the path after finishing. False by default.
	*/
	finish(closePath = false) {
		this.endPoly(closePath);
	}
	/**
	* Draws a rectangle shape. This method adds a new rectangle path to the current drawing.
	* @param x - The x-coordinate of the top-left corner of the rectangle.
	* @param y - The y-coordinate of the top-left corner of the rectangle.
	* @param w - The width of the rectangle.
	* @param h - The height of the rectangle.
	* @param transform - An optional `Matrix` object to apply a transformation to the rectangle.
	* @returns The instance of the current object for chaining.
	*/
	rect(x, y, w, h, transform) {
		this.drawShape(new Rectangle(x, y, w, h), transform);
		return this;
	}
	/**
	* Draws a circle shape. This method adds a new circle path to the current drawing.
	* @param x - The x-coordinate of the center of the circle.
	* @param y - The y-coordinate of the center of the circle.
	* @param radius - The radius of the circle.
	* @param transform - An optional `Matrix` object to apply a transformation to the circle.
	* @returns The instance of the current object for chaining.
	*/
	circle(x, y, radius, transform) {
		this.drawShape(new Circle(x, y, radius), transform);
		return this;
	}
	/**
	* Draws a polygon shape. This method allows for the creation of complex polygons by specifying a sequence of points.
	* @param points - An array of numbers, or or an array of PointData objects eg [{x,y}, {x,y}, {x,y}]
	* representing the x and y coordinates of the polygon's vertices, in sequence.
	* @param close - A boolean indicating whether to close the polygon path. True by default.
	* @param transform - An optional `Matrix` object to apply a transformation to the polygon.
	* @returns The instance of the current object for chaining.
	*/
	poly(points, close, transform) {
		const polygon = new Polygon(points);
		polygon.closePath = close;
		this.drawShape(polygon, transform);
		return this;
	}
	/**
	* Draws a regular polygon with a specified number of sides. All sides and angles are equal.
	* @param x - The x-coordinate of the center of the polygon.
	* @param y - The y-coordinate of the center of the polygon.
	* @param radius - The radius of the circumscribed circle of the polygon.
	* @param sides - The number of sides of the polygon. Must be 3 or more.
	* @param rotation - The rotation angle of the polygon, in radians. Zero by default.
	* @param transform - An optional `Matrix` object to apply a transformation to the polygon.
	* @returns The instance of the current object for chaining.
	*/
	regularPoly(x, y, radius, sides, rotation = 0, transform) {
		sides = Math.max(sides | 0, 3);
		const startAngle = -1 * Math.PI / 2 + rotation;
		const delta = Math.PI * 2 / sides;
		const polygon = [];
		for (let i = 0; i < sides; i++) {
			const angle = startAngle - i * delta;
			polygon.push(x + radius * Math.cos(angle), y + radius * Math.sin(angle));
		}
		this.poly(polygon, true, transform);
		return this;
	}
	/**
	* Draws a polygon with rounded corners.
	* Similar to `regularPoly` but with the ability to round the corners of the polygon.
	* @param x - The x-coordinate of the center of the polygon.
	* @param y - The y-coordinate of the center of the polygon.
	* @param radius - The radius of the circumscribed circle of the polygon.
	* @param sides - The number of sides of the polygon. Must be 3 or more.
	* @param corner - The radius of the rounding of the corners.
	* @param rotation - The rotation angle of the polygon, in radians. Zero by default.
	* @param smoothness - Optional parameter to adjust the smoothness of the rounding.
	* @returns The instance of the current object for chaining.
	*/
	roundPoly(x, y, radius, sides, corner, rotation = 0, smoothness) {
		sides = Math.max(sides | 0, 3);
		if (corner <= 0) return this.regularPoly(x, y, radius, sides, rotation);
		const sideLength = radius * Math.sin(Math.PI / sides) - .001;
		corner = Math.min(corner, sideLength);
		const startAngle = -1 * Math.PI / 2 + rotation;
		const delta = Math.PI * 2 / sides;
		const internalAngle = (sides - 2) * Math.PI / sides / 2;
		for (let i = 0; i < sides; i++) {
			const angle = i * delta + startAngle;
			const x0 = x + radius * Math.cos(angle);
			const y0 = y + radius * Math.sin(angle);
			const a1 = angle + Math.PI + internalAngle;
			const a2 = angle - Math.PI - internalAngle;
			const x1 = x0 + corner * Math.cos(a1);
			const y1 = y0 + corner * Math.sin(a1);
			const x3 = x0 + corner * Math.cos(a2);
			const y3 = y0 + corner * Math.sin(a2);
			if (i === 0) this.moveTo(x1, y1);
			else this.lineTo(x1, y1);
			this.quadraticCurveTo(x0, y0, x3, y3, smoothness);
		}
		return this.closePath();
	}
	/**
	* Draws a shape with rounded corners. This function supports custom radius for each corner of the shape.
	* Optionally, corners can be rounded using a quadratic curve instead of an arc, providing a different aesthetic.
	* @param points - An array of `RoundedPoint` representing the corners of the shape to draw.
	* A minimum of 3 points is required.
	* @param radius - The default radius for the corners.
	* This radius is applied to all corners unless overridden in `points`.
	* @param useQuadratic - If set to true, rounded corners are drawn using a quadraticCurve
	*  method instead of an arc method. Defaults to false.
	* @param smoothness - Specifies the smoothness of the curve when `useQuadratic` is true.
	* Higher values make the curve smoother.
	* @returns The instance of the current object for chaining.
	*/
	roundShape(points, radius, useQuadratic = false, smoothness) {
		if (points.length < 3) return this;
		if (useQuadratic) roundedShapeQuadraticCurve(this, points, radius, smoothness);
		else roundedShapeArc(this, points, radius);
		return this.closePath();
	}
	/**
	* Draw Rectangle with fillet corners. This is much like rounded rectangle
	* however it support negative numbers as well for the corner radius.
	* @param x - Upper left corner of rect
	* @param y - Upper right corner of rect
	* @param width - Width of rect
	* @param height - Height of rect
	* @param fillet - accept negative or positive values
	*/
	filletRect(x, y, width, height, fillet) {
		if (fillet === 0) return this.rect(x, y, width, height);
		const maxFillet = Math.min(width, height) / 2;
		const inset = Math.min(maxFillet, Math.max(-maxFillet, fillet));
		const right = x + width;
		const bottom = y + height;
		const dir = inset < 0 ? -inset : 0;
		const size = Math.abs(inset);
		return this.moveTo(x, y + size).arcTo(x + dir, y + dir, x + size, y, size).lineTo(right - size, y).arcTo(right - dir, y + dir, right, y + size, size).lineTo(right, bottom - size).arcTo(right - dir, bottom - dir, x + width - size, bottom, size).lineTo(x + size, bottom).arcTo(x + dir, bottom - dir, x, bottom - size, size).closePath();
	}
	/**
	* Draw Rectangle with chamfer corners. These are angled corners.
	* @param x - Upper left corner of rect
	* @param y - Upper right corner of rect
	* @param width - Width of rect
	* @param height - Height of rect
	* @param chamfer - non-zero real number, size of corner cutout
	* @param transform
	*/
	chamferRect(x, y, width, height, chamfer, transform) {
		if (chamfer <= 0) return this.rect(x, y, width, height);
		const inset = Math.min(chamfer, Math.min(width, height) / 2);
		const right = x + width;
		const bottom = y + height;
		const points = [
			x + inset,
			y,
			right - inset,
			y,
			right,
			y + inset,
			right,
			bottom - inset,
			right - inset,
			bottom,
			x + inset,
			bottom,
			x,
			bottom - inset,
			x,
			y + inset
		];
		for (let i = points.length - 1; i >= 2; i -= 2) if (points[i] === points[i - 2] && points[i - 1] === points[i - 3]) points.splice(i - 1, 2);
		return this.poly(points, true, transform);
	}
	/**
	* Draws an ellipse at the specified location and with the given x and y radii.
	* An optional transformation can be applied, allowing for rotation, scaling, and translation.
	* @param x - The x-coordinate of the center of the ellipse.
	* @param y - The y-coordinate of the center of the ellipse.
	* @param radiusX - The horizontal radius of the ellipse.
	* @param radiusY - The vertical radius of the ellipse.
	* @param transform - An optional `Matrix` object to apply a transformation to the ellipse. This can include rotations.
	* @returns The instance of the current object for chaining.
	*/
	ellipse(x, y, radiusX, radiusY, transform) {
		this.drawShape(new Ellipse(x, y, radiusX, radiusY), transform);
		return this;
	}
	/**
	* Draws a rectangle with rounded corners.
	* The corner radius can be specified to determine how rounded the corners should be.
	* An optional transformation can be applied, which allows for rotation, scaling, and translation of the rectangle.
	* @param x - The x-coordinate of the top-left corner of the rectangle.
	* @param y - The y-coordinate of the top-left corner of the rectangle.
	* @param w - The width of the rectangle.
	* @param h - The height of the rectangle.
	* @param radius - The radius of the rectangle's corners. If not specified, corners will be sharp.
	* @param transform - An optional `Matrix` object to apply a transformation to the rectangle.
	* @returns The instance of the current object for chaining.
	*/
	roundRect(x, y, w, h, radius, transform) {
		this.drawShape(new RoundedRectangle(x, y, w, h, radius), transform);
		return this;
	}
	/**
	* Draws a given shape on the canvas.
	* This is a generic method that can draw any type of shape specified by the `ShapePrimitive` parameter.
	* An optional transformation matrix can be applied to the shape, allowing for complex transformations.
	* @param shape - The shape to draw, defined as a `ShapePrimitive` object.
	* @param matrix - An optional `Matrix` for transforming the shape. This can include rotations,
	* scaling, and translations.
	* @returns The instance of the current object for chaining.
	*/
	drawShape(shape, matrix) {
		this.endPoly();
		this.shapePrimitives.push({
			shape,
			transform: matrix
		});
		return this;
	}
	/**
	* Starts a new polygon path from the specified starting point.
	* This method initializes a new polygon or ends the current one if it exists.
	* @param x - The x-coordinate of the starting point of the new polygon.
	* @param y - The y-coordinate of the starting point of the new polygon.
	* @returns The instance of the current object for chaining.
	*/
	startPoly(x, y) {
		let currentPoly = this._currentPoly;
		if (currentPoly) this.endPoly();
		currentPoly = new Polygon();
		currentPoly.points.push(x, y);
		this._currentPoly = currentPoly;
		return this;
	}
	/**
	* Ends the current polygon path. If `closePath` is set to true,
	* the path is closed by connecting the last point to the first one.
	* This method finalizes the current polygon and prepares it for drawing or adding to the shape primitives.
	* @param closePath - A boolean indicating whether to close the polygon by connecting the last point
	*  back to the starting point. False by default.
	* @returns The instance of the current object for chaining.
	*/
	endPoly(closePath = false) {
		const shape = this._currentPoly;
		if (shape && shape.points.length > 2) {
			shape.closePath = closePath;
			this.shapePrimitives.push({ shape });
		}
		this._currentPoly = null;
		return this;
	}
	_ensurePoly(start = true) {
		if (this._currentPoly) return;
		this._currentPoly = new Polygon();
		if (start) {
			const lastShape = this.shapePrimitives[this.shapePrimitives.length - 1];
			if (lastShape) {
				let lx = lastShape.shape.x;
				let ly = lastShape.shape.y;
				if (lastShape.transform && !lastShape.transform.isIdentity()) {
					const t = lastShape.transform;
					const tempX = lx;
					lx = t.a * lx + t.c * ly + t.tx;
					ly = t.b * tempX + t.d * ly + t.ty;
				}
				this._currentPoly.points.push(lx, ly);
			} else this._currentPoly.points.push(0, 0);
		}
	}
	/** Builds the path. */
	buildPath() {
		const path = this._graphicsPath2D;
		this.shapePrimitives.length = 0;
		this._currentPoly = null;
		for (let i = 0; i < path.instructions.length; i++) {
			const instruction = path.instructions[i];
			this[instruction.action](...instruction.data);
		}
		this.finish();
	}
	/** Gets the bounds of the path. */
	get bounds() {
		const bounds = this._bounds;
		bounds.clear();
		const shapePrimitives = this.shapePrimitives;
		for (let i = 0; i < shapePrimitives.length; i++) {
			const shapePrimitive = shapePrimitives[i];
			const boundsRect = shapePrimitive.shape.getBounds(tempRectangle);
			if (shapePrimitive.transform) bounds.addRect(boundsRect, shapePrimitive.transform);
			else bounds.addRect(boundsRect);
		}
		return bounds;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/path/GraphicsPath.mjs
var GraphicsPath = class GraphicsPath {
	/**
	* Creates a `GraphicsPath` instance optionally from an SVG path string or an array of `PathInstruction`.
	* @param instructions - An SVG path string or an array of `PathInstruction` objects.
	* @param signed
	*/
	constructor(instructions, signed = false) {
		this.instructions = [];
		/** unique id for this graphics path */
		this.uid = uid("graphicsPath");
		this._dirty = true;
		this.checkForHoles = signed;
		if (typeof instructions === "string") parseSVGPath(instructions, this);
		else this.instructions = instructions?.slice() ?? [];
	}
	/**
	* Provides access to the internal shape path, ensuring it is up-to-date with the current instructions.
	* @returns The `ShapePath` instance associated with this `GraphicsPath`.
	*/
	get shapePath() {
		if (!this._shapePath) this._shapePath = new ShapePath(this);
		if (this._dirty) {
			this._dirty = false;
			this._shapePath.buildPath();
		}
		return this._shapePath;
	}
	/**
	* Adds another `GraphicsPath` to this path, optionally applying a transformation.
	* @param path - The `GraphicsPath` to add.
	* @param transform - An optional transformation to apply to the added path.
	* @returns The instance of the current object for chaining.
	*/
	addPath(path, transform) {
		path = path.clone();
		this.instructions.push({
			action: "addPath",
			data: [path, transform]
		});
		this._dirty = true;
		return this;
	}
	arc(...args) {
		this.instructions.push({
			action: "arc",
			data: args
		});
		this._dirty = true;
		return this;
	}
	arcTo(...args) {
		this.instructions.push({
			action: "arcTo",
			data: args
		});
		this._dirty = true;
		return this;
	}
	arcToSvg(...args) {
		this.instructions.push({
			action: "arcToSvg",
			data: args
		});
		this._dirty = true;
		return this;
	}
	bezierCurveTo(...args) {
		this.instructions.push({
			action: "bezierCurveTo",
			data: args
		});
		this._dirty = true;
		return this;
	}
	/**
	* Adds a cubic Bezier curve to the path.
	* It requires two points: the second control point and the end point. The first control point is assumed to be
	* The starting point is the last point in the current path.
	* @param cp2x - The x-coordinate of the second control point.
	* @param cp2y - The y-coordinate of the second control point.
	* @param x - The x-coordinate of the end point.
	* @param y - The y-coordinate of the end point.
	* @param smoothness - Optional parameter to adjust the smoothness of the curve.
	* @returns The instance of the current object for chaining.
	*/
	bezierCurveToShort(cp2x, cp2y, x, y, smoothness) {
		const last = this.instructions[this.instructions.length - 1];
		const lastPoint = this.getLastPoint(Point.shared);
		let cp1x = 0;
		let cp1y = 0;
		if (!last || last.action !== "bezierCurveTo") {
			cp1x = lastPoint.x;
			cp1y = lastPoint.y;
		} else {
			cp1x = last.data[2];
			cp1y = last.data[3];
			const currentX = lastPoint.x;
			const currentY = lastPoint.y;
			cp1x = currentX + (currentX - cp1x);
			cp1y = currentY + (currentY - cp1y);
		}
		this.instructions.push({
			action: "bezierCurveTo",
			data: [
				cp1x,
				cp1y,
				cp2x,
				cp2y,
				x,
				y,
				smoothness
			]
		});
		this._dirty = true;
		return this;
	}
	/**
	* Closes the current path by drawing a straight line back to the start.
	* If the shape is already closed or there are no points in the path, this method does nothing.
	* @returns The instance of the current object for chaining.
	*/
	closePath() {
		this.instructions.push({
			action: "closePath",
			data: []
		});
		this._dirty = true;
		return this;
	}
	ellipse(...args) {
		this.instructions.push({
			action: "ellipse",
			data: args
		});
		this._dirty = true;
		return this;
	}
	lineTo(...args) {
		this.instructions.push({
			action: "lineTo",
			data: args
		});
		this._dirty = true;
		return this;
	}
	moveTo(...args) {
		this.instructions.push({
			action: "moveTo",
			data: args
		});
		return this;
	}
	quadraticCurveTo(...args) {
		this.instructions.push({
			action: "quadraticCurveTo",
			data: args
		});
		this._dirty = true;
		return this;
	}
	/**
	* Adds a quadratic curve to the path. It uses the previous point as the control point.
	* @param x - The x-coordinate of the end point.
	* @param y - The y-coordinate of the end point.
	* @param smoothness - Optional parameter to adjust the smoothness of the curve.
	* @returns The instance of the current object for chaining.
	*/
	quadraticCurveToShort(x, y, smoothness) {
		const last = this.instructions[this.instructions.length - 1];
		const lastPoint = this.getLastPoint(Point.shared);
		let cpx1 = 0;
		let cpy1 = 0;
		if (!last || last.action !== "quadraticCurveTo") {
			cpx1 = lastPoint.x;
			cpy1 = lastPoint.y;
		} else {
			cpx1 = last.data[0];
			cpy1 = last.data[1];
			const currentX = lastPoint.x;
			const currentY = lastPoint.y;
			cpx1 = currentX + (currentX - cpx1);
			cpy1 = currentY + (currentY - cpy1);
		}
		this.instructions.push({
			action: "quadraticCurveTo",
			data: [
				cpx1,
				cpy1,
				x,
				y,
				smoothness
			]
		});
		this._dirty = true;
		return this;
	}
	/**
	* Draws a rectangle shape. This method adds a new rectangle path to the current drawing.
	* @param x - The x-coordinate of the top-left corner of the rectangle.
	* @param y - The y-coordinate of the top-left corner of the rectangle.
	* @param w - The width of the rectangle.
	* @param h - The height of the rectangle.
	* @param transform - An optional `Matrix` object to apply a transformation to the rectangle.
	* @returns The instance of the current object for chaining.
	*/
	rect(x, y, w, h, transform) {
		this.instructions.push({
			action: "rect",
			data: [
				x,
				y,
				w,
				h,
				transform
			]
		});
		this._dirty = true;
		return this;
	}
	/**
	* Draws a circle shape. This method adds a new circle path to the current drawing.
	* @param x - The x-coordinate of the center of the circle.
	* @param y - The y-coordinate of the center of the circle.
	* @param radius - The radius of the circle.
	* @param transform - An optional `Matrix` object to apply a transformation to the circle.
	* @returns The instance of the current object for chaining.
	*/
	circle(x, y, radius, transform) {
		this.instructions.push({
			action: "circle",
			data: [
				x,
				y,
				radius,
				transform
			]
		});
		this._dirty = true;
		return this;
	}
	roundRect(...args) {
		this.instructions.push({
			action: "roundRect",
			data: args
		});
		this._dirty = true;
		return this;
	}
	poly(...args) {
		this.instructions.push({
			action: "poly",
			data: args
		});
		this._dirty = true;
		return this;
	}
	regularPoly(...args) {
		this.instructions.push({
			action: "regularPoly",
			data: args
		});
		this._dirty = true;
		return this;
	}
	roundPoly(...args) {
		this.instructions.push({
			action: "roundPoly",
			data: args
		});
		this._dirty = true;
		return this;
	}
	roundShape(...args) {
		this.instructions.push({
			action: "roundShape",
			data: args
		});
		this._dirty = true;
		return this;
	}
	filletRect(...args) {
		this.instructions.push({
			action: "filletRect",
			data: args
		});
		this._dirty = true;
		return this;
	}
	chamferRect(...args) {
		this.instructions.push({
			action: "chamferRect",
			data: args
		});
		this._dirty = true;
		return this;
	}
	/**
	* Draws a star shape centered at a specified location. This method allows for the creation
	*  of stars with a variable number of points, outer radius, optional inner radius, and rotation.
	* The star is drawn as a closed polygon with alternating outer and inner vertices to create the star's points.
	* An optional transformation can be applied to scale, rotate, or translate the star as needed.
	* @param x - The x-coordinate of the center of the star.
	* @param y - The y-coordinate of the center of the star.
	* @param points - The number of points of the star.
	* @param radius - The outer radius of the star (distance from the center to the outer points).
	* @param innerRadius - Optional. The inner radius of the star
	* (distance from the center to the inner points between the outer points).
	* If not provided, defaults to half of the `radius`.
	* @param rotation - Optional. The rotation of the star in radians, where 0 is aligned with the y-axis.
	* Defaults to 0, meaning one point is directly upward.
	* @param transform - An optional `Matrix` object to apply a transformation to the star.
	* This can include rotations, scaling, and translations.
	* @returns The instance of the current object for chaining further drawing commands.
	*/
	star(x, y, points, radius, innerRadius, rotation, transform) {
		innerRadius || (innerRadius = radius / 2);
		const startAngle = -1 * Math.PI / 2 + rotation;
		const len = points * 2;
		const delta = Math.PI * 2 / len;
		const polygon = [];
		for (let i = 0; i < len; i++) {
			const r = i % 2 ? innerRadius : radius;
			const angle = i * delta + startAngle;
			polygon.push(x + r * Math.cos(angle), y + r * Math.sin(angle));
		}
		this.poly(polygon, true, transform);
		return this;
	}
	/**
	* Creates a copy of the current `GraphicsPath` instance. This method supports both shallow and deep cloning.
	* A shallow clone copies the reference of the instructions array, while a deep clone creates a new array and
	* copies each instruction individually, ensuring that modifications to the instructions of the cloned `GraphicsPath`
	* do not affect the original `GraphicsPath` and vice versa.
	* @param deep - A boolean flag indicating whether the clone should be deep.
	* @returns A new `GraphicsPath` instance that is a clone of the current instance.
	*/
	clone(deep = false) {
		const newGraphicsPath2D = new GraphicsPath();
		newGraphicsPath2D.checkForHoles = this.checkForHoles;
		if (!deep) newGraphicsPath2D.instructions = this.instructions.slice();
		else for (let i = 0; i < this.instructions.length; i++) {
			const instruction = this.instructions[i];
			newGraphicsPath2D.instructions.push({
				action: instruction.action,
				data: instruction.data.slice()
			});
		}
		return newGraphicsPath2D;
	}
	clear() {
		this.instructions.length = 0;
		this._dirty = true;
		return this;
	}
	/**
	* Applies a transformation matrix to all drawing instructions within the `GraphicsPath`.
	* This method enables the modification of the path's geometry according to the provided
	* transformation matrix, which can include translations, rotations, scaling, and skewing.
	*
	* Each drawing instruction in the path is updated to reflect the transformation,
	* ensuring the visual representation of the path is consistent with the applied matrix.
	*
	* Note: The transformation is applied directly to the coordinates and control points of the drawing instructions,
	* not to the path as a whole. This means the transformation's effects are baked into the individual instructions,
	* allowing for fine-grained control over the path's appearance.
	* @param matrix - A `Matrix` object representing the transformation to apply.
	* @returns The instance of the current object for chaining further operations.
	*/
	transform(matrix) {
		if (matrix.isIdentity()) return this;
		const a = matrix.a;
		const b = matrix.b;
		const c = matrix.c;
		const d = matrix.d;
		const tx = matrix.tx;
		const ty = matrix.ty;
		let x = 0;
		let y = 0;
		let cpx1 = 0;
		let cpy1 = 0;
		let cpx2 = 0;
		let cpy2 = 0;
		let rx = 0;
		let ry = 0;
		for (let i = 0; i < this.instructions.length; i++) {
			const instruction = this.instructions[i];
			const data = instruction.data;
			switch (instruction.action) {
				case "moveTo":
				case "lineTo":
					x = data[0];
					y = data[1];
					data[0] = a * x + c * y + tx;
					data[1] = b * x + d * y + ty;
					break;
				case "bezierCurveTo":
					cpx1 = data[0];
					cpy1 = data[1];
					cpx2 = data[2];
					cpy2 = data[3];
					x = data[4];
					y = data[5];
					data[0] = a * cpx1 + c * cpy1 + tx;
					data[1] = b * cpx1 + d * cpy1 + ty;
					data[2] = a * cpx2 + c * cpy2 + tx;
					data[3] = b * cpx2 + d * cpy2 + ty;
					data[4] = a * x + c * y + tx;
					data[5] = b * x + d * y + ty;
					break;
				case "quadraticCurveTo":
					cpx1 = data[0];
					cpy1 = data[1];
					x = data[2];
					y = data[3];
					data[0] = a * cpx1 + c * cpy1 + tx;
					data[1] = b * cpx1 + d * cpy1 + ty;
					data[2] = a * x + c * y + tx;
					data[3] = b * x + d * y + ty;
					break;
				case "arcToSvg":
					x = data[5];
					y = data[6];
					rx = data[0];
					ry = data[1];
					data[0] = a * rx + c * ry;
					data[1] = b * rx + d * ry;
					data[5] = a * x + c * y + tx;
					data[6] = b * x + d * y + ty;
					break;
				case "circle":
					data[4] = adjustTransform(data[3], matrix);
					break;
				case "rect":
					data[4] = adjustTransform(data[4], matrix);
					break;
				case "ellipse":
					data[8] = adjustTransform(data[8], matrix);
					break;
				case "roundRect":
					data[5] = adjustTransform(data[5], matrix);
					break;
				case "addPath":
					data[0].transform(matrix);
					break;
				case "poly":
					data[2] = adjustTransform(data[2], matrix);
					break;
				case "regularPoly":
				case "chamferRect":
					data[5] = adjustTransform(data[5], matrix);
					break;
				case "closePath": break;
				default: warn("unknown transform action", instruction.action);
			}
		}
		this._dirty = true;
		return this;
	}
	get bounds() {
		return this.shapePath.bounds;
	}
	/**
	* Retrieves the last point from the current drawing instructions in the `GraphicsPath`.
	* This method is useful for operations that depend on the path's current endpoint,
	* such as connecting subsequent shapes or paths. It supports various drawing instructions,
	* ensuring the last point's position is accurately determined regardless of the path's complexity.
	*
	* If the last instruction is a `closePath`, the method iterates backward through the instructions
	*  until it finds an actionable instruction that defines a point (e.g., `moveTo`, `lineTo`,
	* `quadraticCurveTo`, etc.). For compound paths added via `addPath`, it recursively retrieves
	* the last point from the nested path.
	* @param out - A `Point` object where the last point's coordinates will be stored.
	* This object is modified directly to contain the result.
	* @returns The `Point` object containing the last point's coordinates.
	*/
	getLastPoint(out) {
		let index = this.instructions.length - 1;
		let lastInstruction = this.instructions[index];
		if (!lastInstruction) {
			out.x = 0;
			out.y = 0;
			return out;
		}
		while (lastInstruction.action === "closePath") {
			index--;
			if (index < 0) {
				out.x = 0;
				out.y = 0;
				return out;
			}
			lastInstruction = this.instructions[index];
		}
		switch (lastInstruction.action) {
			case "moveTo":
			case "lineTo":
				out.x = lastInstruction.data[0];
				out.y = lastInstruction.data[1];
				break;
			case "quadraticCurveTo":
				out.x = lastInstruction.data[2];
				out.y = lastInstruction.data[3];
				break;
			case "bezierCurveTo":
				out.x = lastInstruction.data[4];
				out.y = lastInstruction.data[5];
				break;
			case "arc":
			case "arcToSvg":
				out.x = lastInstruction.data[5];
				out.y = lastInstruction.data[6];
				break;
			case "addPath": lastInstruction.data[0].getLastPoint(out);
		}
		return out;
	}
};
function adjustTransform(currentMatrix, transform) {
	if (currentMatrix) return currentMatrix.prepend(transform);
	return transform.clone();
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/parseSVGFloatAttribute.mjs
function parseSVGFloatAttribute(svg, id, defaultValue) {
	const value = svg.getAttribute(id);
	return value ? Number(value) : defaultValue;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/parseSVGDefinitions.mjs
function parseSVGDefinitions(svg, session) {
	const definitions = svg.querySelectorAll("defs");
	for (let i = 0; i < definitions.length; i++) {
		const definition = definitions[i];
		for (let j = 0; j < definition.children.length; j++) {
			const child = definition.children[j];
			switch (child.nodeName.toLowerCase()) {
				case "lineargradient":
					session.defs[child.id] = parseLinearGradient(child);
					break;
				case "radialgradient": session.defs[child.id] = parseRadialGradient(child);
			}
		}
	}
}
function parseGradientCoordinate(svg, id, defaultValue) {
	const value = svg.getAttribute(id);
	if (value?.trim().endsWith("%")) {
		const percentage = Number(value.trim().slice(0, -1));
		return Number.isNaN(percentage) ? defaultValue : percentage / 100;
	}
	return parseSVGFloatAttribute(svg, id, defaultValue);
}
function parseGradientTextureSpace(svg) {
	return (svg.getAttribute("gradientUnits") || "objectBoundingBox") === "objectBoundingBox" ? "local" : "global";
}
function parseGradientColorStops(svg) {
	const colorStops = [];
	for (let i = 0; i < svg.children.length; i++) {
		const stop = svg.children[i];
		const offset = parseGradientCoordinate(stop, "offset", 0);
		const color = Color.shared.setValue(stop.getAttribute("stop-color")).toNumber();
		colorStops.push({
			offset,
			color
		});
	}
	return colorStops;
}
function parseLinearGradient(child) {
	const x0 = parseGradientCoordinate(child, "x1", 0);
	const y0 = parseGradientCoordinate(child, "y1", 0);
	const x1 = parseGradientCoordinate(child, "x2", 1);
	const y1 = parseGradientCoordinate(child, "y2", 0);
	return new FillGradient({
		type: "linear",
		start: {
			x: x0,
			y: y0
		},
		end: {
			x: x1,
			y: y1
		},
		textureSpace: parseGradientTextureSpace(child),
		colorStops: parseGradientColorStops(child)
	});
}
function parseRadialGradient(child) {
	const cx = parseGradientCoordinate(child, "cx", .5);
	const cy = parseGradientCoordinate(child, "cy", .5);
	const r = parseGradientCoordinate(child, "r", .5);
	const fx = parseGradientCoordinate(child, "fx", cx);
	const fy = parseGradientCoordinate(child, "fy", cy);
	const fr = parseGradientCoordinate(child, "fr", 0);
	return new FillGradient({
		type: "radial",
		center: {
			x: fx,
			y: fy
		},
		innerRadius: fr,
		outerCenter: {
			x: cx,
			y: cy
		},
		outerRadius: r,
		textureSpace: parseGradientTextureSpace(child),
		colorStops: parseGradientColorStops(child)
	});
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/utils/extractSvgUrlId.mjs
function extractSvgUrlId(url) {
	const match = url.match(/url\s*\(\s*['"]?\s*#([^'"\s)]+)\s*['"]?\s*\)/i);
	return match ? match[1] : "";
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/parseSVGStyle.mjs
var styleAttributes = {
	fill: {
		type: "paint",
		default: 0
	},
	"fill-opacity": {
		type: "number",
		default: 1
	},
	stroke: {
		type: "paint",
		default: 0
	},
	"stroke-width": {
		type: "number",
		default: 1
	},
	"stroke-opacity": {
		type: "number",
		default: 1
	},
	"stroke-linecap": {
		type: "string",
		default: "butt"
	},
	"stroke-linejoin": {
		type: "string",
		default: "miter"
	},
	"stroke-miterlimit": {
		type: "number",
		default: 10
	},
	"stroke-dasharray": {
		type: "string",
		default: "none"
	},
	"stroke-dashoffset": {
		type: "number",
		default: 0
	},
	opacity: {
		type: "number",
		default: 1
	}
};
function parseSVGStyle(svg, session) {
	const style = svg.getAttribute("style");
	const strokeStyle = {};
	const fillStyle = {};
	const result = {
		strokeStyle,
		fillStyle,
		useFill: false,
		useStroke: false
	};
	for (const key in styleAttributes) {
		const attribute = svg.getAttribute(key);
		if (attribute) parseAttribute(session, result, key, attribute.trim());
	}
	if (style) {
		const styleParts = style.split(";");
		for (let i = 0; i < styleParts.length; i++) {
			const [key, value] = styleParts[i].trim().split(":");
			if (styleAttributes[key]) parseAttribute(session, result, key, value.trim());
		}
	}
	return {
		strokeStyle: result.useStroke ? strokeStyle : null,
		fillStyle: result.useFill ? fillStyle : null,
		useFill: result.useFill,
		useStroke: result.useStroke
	};
}
function parseAttribute(session, result, id, value) {
	switch (id) {
		case "stroke":
			if (value !== "none") {
				if (value.startsWith("url(")) {
					const id2 = extractSvgUrlId(value);
					result.strokeStyle.fill = session.defs[id2];
				} else result.strokeStyle.color = Color.shared.setValue(value).toNumber();
				result.useStroke = true;
			}
			break;
		case "stroke-width":
			result.strokeStyle.width = Number(value);
			break;
		case "fill":
			if (value !== "none") {
				if (value.startsWith("url(")) {
					const id2 = extractSvgUrlId(value);
					result.fillStyle.fill = session.defs[id2];
				} else result.fillStyle.color = Color.shared.setValue(value).toNumber();
				result.useFill = true;
			}
			break;
		case "fill-opacity":
			result.fillStyle.alpha = Number(value);
			break;
		case "stroke-opacity":
			result.strokeStyle.alpha = Number(value);
			break;
		case "opacity":
			result.fillStyle.alpha = Number(value);
			result.strokeStyle.alpha = Number(value);
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/utils/fillOperations.mjs
function checkForNestedPattern(subpathsWithArea) {
	if (subpathsWithArea.length <= 2) return true;
	const areas = subpathsWithArea.map((s) => s.area).sort((a, b) => b - a);
	const [largestArea, secondArea] = areas;
	const smallestArea = areas[areas.length - 1];
	const largestToSecondRatio = largestArea / secondArea;
	const secondToSmallestRatio = secondArea / smallestArea;
	if (largestToSecondRatio > 3 && secondToSmallestRatio < 2) return false;
	return true;
}
function getFillInstructionData(context, index = 0) {
	const instruction = context.instructions[index];
	if (!instruction || instruction.action !== "fill") throw new Error(`Expected fill instruction at index ${index}, got ${instruction?.action || "undefined"}`);
	return instruction.data;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/utils/pathOperations.mjs
function extractSubpaths(pathData) {
	return pathData.split(/(?=[Mm])/).filter((part) => part.trim().length > 0);
}
function calculatePathArea(pathData) {
	const coords = pathData.match(/[-+]?[0-9]*\.?[0-9]+/g);
	if (!coords || coords.length < 4) return 0;
	const numbers = coords.map(Number);
	const xs = [];
	const ys = [];
	for (let i = 0; i < numbers.length; i += 2) if (i + 1 < numbers.length) {
		xs.push(numbers[i]);
		ys.push(numbers[i + 1]);
	}
	if (xs.length === 0 || ys.length === 0) return 0;
	const minX = Math.min(...xs);
	const maxX = Math.max(...xs);
	const minY = Math.min(...ys);
	const maxY = Math.max(...ys);
	return (maxX - minX) * (maxY - minY);
}
function appendSVGPath(pathData, graphicsPath) {
	const tempPath = new GraphicsPath(pathData, false);
	for (const instruction of tempPath.instructions) graphicsPath.instructions.push(instruction);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/svg/SVGParser.mjs
function SVGParser(svg, graphicsContext) {
	if (typeof svg === "string") {
		const div = document.createElement("div");
		div.innerHTML = svg.trim();
		svg = div.querySelector("svg");
	}
	const session = {
		context: graphicsContext,
		defs: {},
		path: new GraphicsPath()
	};
	parseSVGDefinitions(svg, session);
	const children = svg.children;
	const { fillStyle, strokeStyle } = parseSVGStyle(svg, session);
	for (let i = 0; i < children.length; i++) {
		const child = children[i];
		if (child.nodeName.toLowerCase() === "defs") continue;
		renderChildren(child, session, fillStyle, strokeStyle);
	}
	return graphicsContext;
}
function renderChildren(svg, session, fillStyle, strokeStyle) {
	const children = svg.children;
	const { fillStyle: f1, strokeStyle: s1 } = parseSVGStyle(svg, session);
	if (f1 && fillStyle) fillStyle = {
		...fillStyle,
		...f1
	};
	else if (f1) fillStyle = f1;
	if (s1 && strokeStyle) strokeStyle = {
		...strokeStyle,
		...s1
	};
	else if (s1) strokeStyle = s1;
	const noStyle = !fillStyle && !strokeStyle;
	if (noStyle) fillStyle = { color: 0 };
	let x;
	let y;
	let x1;
	let y1;
	let x2;
	let y2;
	let cx;
	let cy;
	let r;
	let rx;
	let ry;
	let points;
	let pointsString;
	let d;
	let graphicsPath;
	let width;
	let height;
	switch (svg.nodeName.toLowerCase()) {
		case "path": {
			d = svg.getAttribute("d");
			const fillRule = svg.getAttribute("fill-rule");
			const subpaths = extractSubpaths(d);
			const hasExplicitEvenodd = fillRule === "evenodd";
			const hasMultipleSubpaths = subpaths.length > 1;
			if (hasExplicitEvenodd && hasMultipleSubpaths) {
				const subpathsWithArea = subpaths.map((subpath) => ({
					path: subpath,
					area: calculatePathArea(subpath)
				}));
				subpathsWithArea.sort((a, b) => b.area - a.area);
				if (subpaths.length > 3 || !checkForNestedPattern(subpathsWithArea)) for (let i = 0; i < subpathsWithArea.length; i++) {
					const subpath = subpathsWithArea[i];
					const isMainShape = i === 0;
					session.context.beginPath();
					const newPath = new GraphicsPath(void 0, true);
					appendSVGPath(subpath.path, newPath);
					session.context.path(newPath);
					if (isMainShape) {
						if (fillStyle) session.context.fill(fillStyle);
						if (strokeStyle) session.context.stroke(strokeStyle);
					} else session.context.cut();
				}
				else for (let i = 0; i < subpathsWithArea.length; i++) {
					const subpath = subpathsWithArea[i];
					const isHole = i % 2 === 1;
					session.context.beginPath();
					const newPath = new GraphicsPath(void 0, true);
					appendSVGPath(subpath.path, newPath);
					session.context.path(newPath);
					if (isHole) session.context.cut();
					else {
						if (fillStyle) session.context.fill(fillStyle);
						if (strokeStyle) session.context.stroke(strokeStyle);
					}
				}
			} else {
				graphicsPath = new GraphicsPath(d, fillRule ? fillRule === "evenodd" : true);
				session.context.path(graphicsPath);
				if (fillStyle) session.context.fill(fillStyle);
				if (strokeStyle) session.context.stroke(strokeStyle);
			}
			break;
		}
		case "circle":
			cx = parseSVGFloatAttribute(svg, "cx", 0);
			cy = parseSVGFloatAttribute(svg, "cy", 0);
			r = parseSVGFloatAttribute(svg, "r", 0);
			session.context.ellipse(cx, cy, r, r);
			if (fillStyle) session.context.fill(fillStyle);
			if (strokeStyle) session.context.stroke(strokeStyle);
			break;
		case "rect":
			x = parseSVGFloatAttribute(svg, "x", 0);
			y = parseSVGFloatAttribute(svg, "y", 0);
			width = parseSVGFloatAttribute(svg, "width", 0);
			height = parseSVGFloatAttribute(svg, "height", 0);
			rx = parseSVGFloatAttribute(svg, "rx", 0);
			ry = parseSVGFloatAttribute(svg, "ry", 0);
			if (rx || ry) session.context.roundRect(x, y, width, height, rx || ry);
			else session.context.rect(x, y, width, height);
			if (fillStyle) session.context.fill(fillStyle);
			if (strokeStyle) session.context.stroke(strokeStyle);
			break;
		case "ellipse":
			cx = parseSVGFloatAttribute(svg, "cx", 0);
			cy = parseSVGFloatAttribute(svg, "cy", 0);
			rx = parseSVGFloatAttribute(svg, "rx", 0);
			ry = parseSVGFloatAttribute(svg, "ry", 0);
			session.context.beginPath();
			session.context.ellipse(cx, cy, rx, ry);
			if (fillStyle) session.context.fill(fillStyle);
			if (strokeStyle) session.context.stroke(strokeStyle);
			break;
		case "line":
			x1 = parseSVGFloatAttribute(svg, "x1", 0);
			y1 = parseSVGFloatAttribute(svg, "y1", 0);
			x2 = parseSVGFloatAttribute(svg, "x2", 0);
			y2 = parseSVGFloatAttribute(svg, "y2", 0);
			session.context.beginPath();
			session.context.moveTo(x1, y1);
			session.context.lineTo(x2, y2);
			if (strokeStyle) session.context.stroke(strokeStyle);
			break;
		case "polygon":
			pointsString = svg.getAttribute("points");
			points = pointsString.match(/-?\d+/g).map((n) => parseInt(n, 10));
			session.context.poly(points, true);
			if (fillStyle) session.context.fill(fillStyle);
			if (strokeStyle) session.context.stroke(strokeStyle);
			break;
		case "polyline":
			pointsString = svg.getAttribute("points");
			points = pointsString.match(/-?\d+/g).map((n) => parseInt(n, 10));
			session.context.poly(points, false);
			if (strokeStyle) session.context.stroke(strokeStyle);
			break;
		case "g":
		case "svg": break;
		default: warn(`[SVG parser] <${svg.nodeName}> elements unsupported`);
	}
	if (noStyle) fillStyle = null;
	for (let i = 0; i < children.length; i++) renderChildren(children[i], session, fillStyle, strokeStyle);
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/fill/FillPattern.mjs
function isFillPatternOptions(value) {
	return value.texture !== void 0;
}
var repetitionMap = {
	repeat: {
		addressModeU: "repeat",
		addressModeV: "repeat"
	},
	"repeat-x": {
		addressModeU: "repeat",
		addressModeV: "clamp-to-edge"
	},
	"repeat-y": {
		addressModeU: "clamp-to-edge",
		addressModeV: "repeat"
	},
	"no-repeat": {
		addressModeU: "clamp-to-edge",
		addressModeV: "clamp-to-edge"
	}
};
var FillPattern = class {
	constructor(textureOrOptions, repetition) {
		/**
		* unique id for this fill pattern
		* @internal
		*/
		this.uid = uid("fillPattern");
		/**
		* Internal tick counter to track changes in the pattern.
		* This is used to invalidate the pattern when the texture or transform changes.
		* @internal
		*/
		this._tick = 0;
		/** The transform matrix applied to the pattern */
		this.transform = new Matrix();
		const options = isFillPatternOptions(textureOrOptions) ? textureOrOptions : {
			texture: textureOrOptions,
			repetition
		};
		this.texture = options.texture;
		this.textureSpace = options.textureSpace ?? "global";
		const rep = options.repetition;
		if (rep) {
			this.texture.source.style.addressModeU = repetitionMap[rep].addressModeU;
			this.texture.source.style.addressModeV = repetitionMap[rep].addressModeV;
		}
	}
	/**
	* Sets the transform for the pattern
	* @param transform - The transform matrix to apply to the pattern.
	* If not provided, the pattern will use the default transform.
	*/
	setTransform(transform) {
		if (transform) {
			if (this.transform.equals(transform)) return;
			this.transform.copyFrom(transform);
		} else {
			if (this.transform.isIdentity()) return;
			this.transform.identity();
		}
		this._tick++;
	}
	/** Internal texture used to render the gradient */
	get texture() {
		return this._texture;
	}
	set texture(value) {
		if (this._texture === value) return;
		this._texture = value;
		this._tick++;
	}
	/**
	* Returns a unique key for this instance.
	* This key is used for caching.
	* @returns {string} Unique key for the instance
	*/
	get styleKey() {
		return `fill-pattern-${this.uid}-${this._tick}`;
	}
	/** Destroys the fill pattern, releasing resources. This will also destroy the internal texture. */
	destroy() {
		this.texture.destroy(true);
		this.texture = null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/convertFillInputToFillStyle.mjs
function isColorLike(value) {
	return Color.isColorLike(value);
}
function isFillPattern(value) {
	return value instanceof FillPattern;
}
function isFillGradient(value) {
	return value instanceof FillGradient;
}
function isTexture(value) {
	return value instanceof Texture;
}
function handleColorLike(fill, value, defaultStyle) {
	const temp = Color.shared.setValue(value ?? 0);
	fill.color = temp.toNumber();
	fill.alpha = temp.alpha === 1 ? defaultStyle.alpha : temp.alpha;
	fill.texture = Texture.WHITE;
	return {
		...defaultStyle,
		...fill
	};
}
function handleTexture(fill, value, defaultStyle) {
	fill.texture = value;
	return {
		...defaultStyle,
		...fill
	};
}
function handleFillPattern(fill, value, defaultStyle) {
	fill.fill = value;
	fill.color = 16777215;
	fill.texture = value.texture;
	fill.matrix = value.transform;
	fill.textureSpace = value.textureSpace;
	return {
		...defaultStyle,
		...fill
	};
}
function handleFillGradient(fill, value, defaultStyle) {
	value.buildGradient();
	fill.fill = value;
	fill.color = 16777215;
	fill.texture = value.texture;
	fill.matrix = value.transform;
	fill.textureSpace = value.textureSpace;
	return {
		...defaultStyle,
		...fill
	};
}
function handleFillObject(value, defaultStyle) {
	const style = {
		...defaultStyle,
		...value
	};
	const color = Color.shared.setValue(style.color);
	style.alpha *= color.alpha;
	style.color = color.toNumber();
	return style;
}
function toFillStyle(value, defaultStyle) {
	if (value === void 0 || value === null) return null;
	const fill = {};
	const objectStyle = value;
	if (isColorLike(value)) return handleColorLike(fill, value, defaultStyle);
	else if (isTexture(value)) return handleTexture(fill, value, defaultStyle);
	else if (isFillPattern(value)) return handleFillPattern(fill, value, defaultStyle);
	else if (isFillGradient(value)) return handleFillGradient(fill, value, defaultStyle);
	else if (objectStyle.fill && isFillPattern(objectStyle.fill)) return handleFillPattern(objectStyle, objectStyle.fill, defaultStyle);
	else if (objectStyle.fill && isFillGradient(objectStyle.fill)) return handleFillGradient(objectStyle, objectStyle.fill, defaultStyle);
	return handleFillObject(objectStyle, defaultStyle);
}
function toStrokeStyle(value, defaultStyle) {
	const { width, alignment, miterLimit, cap, join, pixelLine, ...rest } = defaultStyle;
	const fill = toFillStyle(value, rest);
	if (!fill) return null;
	return {
		width,
		alignment,
		miterLimit,
		cap,
		join,
		pixelLine,
		...fill
	};
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/utils/getMaxMiterRatio.mjs
function getMaxMiterRatio(path, miterLimit) {
	let maxRatio = 1;
	const shapePrimitives = path.shapePath.shapePrimitives;
	for (let i = 0; i < shapePrimitives.length; i++) {
		const shape = shapePrimitives[i].shape;
		if (shape.type !== "polygon") continue;
		const points = shape.points;
		const n = points.length;
		if (n < 6) continue;
		const closed = shape.closePath;
		for (let j = 0; j < n; j += 2) {
			if (!closed && (j === 0 || j === n - 2)) continue;
			const prevIdx = (j - 2 + n) % n;
			const nextIdx = (j + 2) % n;
			const x0 = points[prevIdx];
			const y0 = points[prevIdx + 1];
			const x1 = points[j];
			const y1 = points[j + 1];
			const x2 = points[nextIdx];
			const y2 = points[nextIdx + 1];
			const dx0 = x0 - x1;
			const dy0 = y0 - y1;
			const dx1 = x2 - x1;
			const dy1 = y2 - y1;
			const len0Sq = dx0 * dx0 + dy0 * dy0;
			const len1Sq = dx1 * dx1 + dy1 * dy1;
			if (len0Sq < 1e-12 || len1Sq < 1e-12) continue;
			let clampedCos = (dx0 * dx1 + dy0 * dy1) / Math.sqrt(len0Sq * len1Sq);
			if (clampedCos < -1) clampedCos = -1;
			else if (clampedCos > 1) clampedCos = 1;
			const sinHalfAngle = Math.sqrt((1 - clampedCos) * .5);
			if (sinHalfAngle < 1e-6) continue;
			const miterRatio = Math.min(1 / sinHalfAngle, miterLimit);
			if (miterRatio > maxRatio) maxRatio = miterRatio;
		}
	}
	return maxRatio;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/shared/GraphicsContext.mjs
var tmpPoint = new Point();
var tempMatrix = new Matrix();
var _GraphicsContext = class _GraphicsContext extends eventemitter3_default {
	constructor() {
		super(...arguments);
		/** @internal */
		this._gpuData = /* @__PURE__ */ Object.create(null);
		/** If set to true, the resource will be garbage collected automatically when it is not used. */
		this.autoGarbageCollect = true;
		/** @internal */
		this._gcLastUsed = -1;
		/**
		* unique id for this graphics context
		* @internal
		*/
		this.uid = uid("graphicsContext");
		/**
		* Indicates whether content is updated and have to be re-rendered.
		* @internal
		*/
		this.dirty = true;
		/** The batch mode for this graphics context. It can be 'auto', 'batch', or 'no-batch'. */
		this.batchMode = "auto";
		/** @internal */
		this.instructions = [];
		/** Whether the graphics context has been destroyed. */
		this.destroyed = false;
		this._activePath = new GraphicsPath();
		this._transform = new Matrix();
		this._fillStyle = { ..._GraphicsContext.defaultFillStyle };
		this._strokeStyle = { ..._GraphicsContext.defaultStrokeStyle };
		this._stateStack = [];
		this._tick = 0;
		this._bounds = new Bounds();
		this._boundsDirty = true;
	}
	/**
	* Creates a new GraphicsContext object that is a clone of this instance, copying all properties,
	* including the current drawing state, transformations, styles, and instructions.
	* @returns A new GraphicsContext instance with the same properties and state as this one.
	*/
	clone() {
		const clone = new _GraphicsContext();
		clone.batchMode = this.batchMode;
		clone.instructions = this.instructions.slice();
		clone._activePath = this._activePath.clone();
		clone._transform = this._transform.clone();
		clone._fillStyle = { ...this._fillStyle };
		clone._strokeStyle = { ...this._strokeStyle };
		clone._stateStack = this._stateStack.slice();
		clone._bounds = this._bounds.clone();
		clone._boundsDirty = true;
		return clone;
	}
	/**
	* The current fill style of the graphics context. This can be a color, gradient, pattern, or a more complex style defined by a FillStyle object.
	*/
	get fillStyle() {
		return this._fillStyle;
	}
	set fillStyle(value) {
		this._fillStyle = toFillStyle(value, _GraphicsContext.defaultFillStyle);
	}
	/**
	* The current stroke style of the graphics context. Similar to fill styles, stroke styles can encompass colors, gradients, patterns, or more detailed configurations via a StrokeStyle object.
	*/
	get strokeStyle() {
		return this._strokeStyle;
	}
	set strokeStyle(value) {
		this._strokeStyle = toStrokeStyle(value, _GraphicsContext.defaultStrokeStyle);
	}
	/**
	* Sets the current fill style of the graphics context. The fill style can be a color, gradient,
	* pattern, or a more complex style defined by a FillStyle object.
	* @param style - The fill style to apply. This can be a simple color, a gradient or pattern object,
	*                or a FillStyle or ConvertedFillStyle object.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	setFillStyle(style) {
		this._fillStyle = toFillStyle(style, _GraphicsContext.defaultFillStyle);
		return this;
	}
	/**
	* Sets the current stroke style of the graphics context. Similar to fill styles, stroke styles can
	* encompass colors, gradients, patterns, or more detailed configurations via a StrokeStyle object.
	* @param style - The stroke style to apply. Can be defined as a color, a gradient or pattern,
	*                or a StrokeStyle or ConvertedStrokeStyle object.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	setStrokeStyle(style) {
		this._strokeStyle = toFillStyle(style, _GraphicsContext.defaultStrokeStyle);
		return this;
	}
	texture(texture, tint, dx, dy, dw, dh) {
		this.instructions.push({
			action: "texture",
			data: {
				image: texture,
				dx: dx || 0,
				dy: dy || 0,
				dw: dw || texture.frame.width,
				dh: dh || texture.frame.height,
				transform: this._transform.clone(),
				alpha: this._fillStyle.alpha,
				style: tint || tint === 0 ? Color.shared.setValue(tint).toNumber() : 16777215
			}
		});
		this.onUpdate();
		return this;
	}
	/**
	* Resets the current path. Any previous path and its commands are discarded and a new path is
	* started. This is typically called before beginning a new shape or series of drawing commands.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	beginPath() {
		this._activePath = new GraphicsPath();
		return this;
	}
	fill(style, alpha) {
		let path;
		const lastInstruction = this.instructions[this.instructions.length - 1];
		if (this._tick === 0 && lastInstruction?.action === "stroke") path = lastInstruction.data.path;
		else path = this._activePath.clone();
		if (!path) return this;
		if (style != null) {
			if (alpha !== void 0 && typeof style === "number") {
				deprecation(v8_0_0, "GraphicsContext.fill(color, alpha) is deprecated, use GraphicsContext.fill({ color, alpha }) instead");
				style = {
					color: style,
					alpha
				};
			}
			this._fillStyle = toFillStyle(style, _GraphicsContext.defaultFillStyle);
		}
		this.instructions.push({
			action: "fill",
			data: {
				style: this.fillStyle,
				path
			}
		});
		this.onUpdate();
		this._initNextPathLocation();
		this._tick = 0;
		return this;
	}
	_initNextPathLocation() {
		const { x, y } = this._activePath.getLastPoint(Point.shared);
		this._activePath.clear();
		this._activePath.moveTo(x, y);
	}
	/**
	* Strokes the current path with the current stroke style. This method can take an optional
	* FillInput parameter to define the stroke's appearance, including its color, width, and other properties.
	* @param style - (Optional) The stroke style to apply. Can be defined as a simple color or a more complex style object. If omitted, uses the current stroke style.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	stroke(style) {
		let path;
		const lastInstruction = this.instructions[this.instructions.length - 1];
		if (this._tick === 0 && lastInstruction?.action === "fill") path = lastInstruction.data.path;
		else path = this._activePath.clone();
		if (!path) return this;
		if (style != null) this._strokeStyle = toStrokeStyle(style, _GraphicsContext.defaultStrokeStyle);
		this.instructions.push({
			action: "stroke",
			data: {
				style: this.strokeStyle,
				path
			}
		});
		this.onUpdate();
		this._initNextPathLocation();
		this._tick = 0;
		return this;
	}
	/**
	* Applies a cutout to the last drawn shape. This is used to create holes or complex shapes by
	* subtracting a path from the previously drawn path. If a hole is not completely in a shape, it will
	* fail to cut correctly!
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	cut() {
		for (let i = 0; i < 2; i++) {
			const lastInstruction = this.instructions[this.instructions.length - 1 - i];
			const holePath = this._activePath.clone();
			if (lastInstruction) {
				if (lastInstruction.action === "stroke" || lastInstruction.action === "fill") {
					if (lastInstruction.data.hole) lastInstruction.data.hole.addPath(holePath);
					else {
						lastInstruction.data.hole = holePath;
						break;
					}
				}
			}
		}
		this._initNextPathLocation();
		return this;
	}
	/**
	* Adds an arc to the current path, which is centered at (x, y) with the specified radius,
	* starting and ending angles, and direction.
	* @param x - The x-coordinate of the arc's center.
	* @param y - The y-coordinate of the arc's center.
	* @param radius - The arc's radius.
	* @param startAngle - The starting angle, in radians.
	* @param endAngle - The ending angle, in radians.
	* @param counterclockwise - (Optional) Specifies whether the arc is drawn counterclockwise (true) or clockwise (false). Defaults to false.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	arc(x, y, radius, startAngle, endAngle, counterclockwise) {
		this._tick++;
		const t = this._transform;
		this._activePath.arc(t.a * x + t.c * y + t.tx, t.b * x + t.d * y + t.ty, radius, startAngle, endAngle, counterclockwise);
		return this;
	}
	/**
	* Adds an arc to the current path with the given control points and radius, connected to the previous point
	* by a straight line if necessary.
	* @param x1 - The x-coordinate of the first control point.
	* @param y1 - The y-coordinate of the first control point.
	* @param x2 - The x-coordinate of the second control point.
	* @param y2 - The y-coordinate of the second control point.
	* @param radius - The arc's radius.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	arcTo(x1, y1, x2, y2, radius) {
		this._tick++;
		const t = this._transform;
		this._activePath.arcTo(t.a * x1 + t.c * y1 + t.tx, t.b * x1 + t.d * y1 + t.ty, t.a * x2 + t.c * y2 + t.tx, t.b * x2 + t.d * y2 + t.ty, radius);
		return this;
	}
	/**
	* Adds an SVG-style arc to the path, allowing for elliptical arcs based on the SVG spec.
	* @param rx - The x-radius of the ellipse.
	* @param ry - The y-radius of the ellipse.
	* @param xAxisRotation - The rotation of the ellipse's x-axis relative
	* to the x-axis of the coordinate system, in degrees.
	* @param largeArcFlag - Determines if the arc should be greater than or less than 180 degrees.
	* @param sweepFlag - Determines if the arc should be swept in a positive angle direction.
	* @param x - The x-coordinate of the arc's end point.
	* @param y - The y-coordinate of the arc's end point.
	* @returns The instance of the current object for chaining.
	*/
	arcToSvg(rx, ry, xAxisRotation, largeArcFlag, sweepFlag, x, y) {
		this._tick++;
		const t = this._transform;
		this._activePath.arcToSvg(rx, ry, xAxisRotation, largeArcFlag, sweepFlag, t.a * x + t.c * y + t.tx, t.b * x + t.d * y + t.ty);
		return this;
	}
	/**
	* Adds a cubic Bezier curve to the path.
	* It requires three points: the first two are control points and the third one is the end point.
	* The starting point is the last point in the current path.
	* @param cp1x - The x-coordinate of the first control point.
	* @param cp1y - The y-coordinate of the first control point.
	* @param cp2x - The x-coordinate of the second control point.
	* @param cp2y - The y-coordinate of the second control point.
	* @param x - The x-coordinate of the end point.
	* @param y - The y-coordinate of the end point.
	* @param smoothness - Optional parameter to adjust the smoothness of the curve.
	* @returns The instance of the current object for chaining.
	*/
	bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y, smoothness) {
		this._tick++;
		const t = this._transform;
		this._activePath.bezierCurveTo(t.a * cp1x + t.c * cp1y + t.tx, t.b * cp1x + t.d * cp1y + t.ty, t.a * cp2x + t.c * cp2y + t.tx, t.b * cp2x + t.d * cp2y + t.ty, t.a * x + t.c * y + t.tx, t.b * x + t.d * y + t.ty, smoothness);
		return this;
	}
	/**
	* Closes the current path by drawing a straight line back to the start.
	* If the shape is already closed or there are no points in the path, this method does nothing.
	* @returns The instance of the current object for chaining.
	*/
	closePath() {
		this._tick++;
		this._activePath?.closePath();
		return this;
	}
	/**
	* Draws an ellipse at the specified location and with the given x and y radii.
	* An optional transformation can be applied, allowing for rotation, scaling, and translation.
	* @param x - The x-coordinate of the center of the ellipse.
	* @param y - The y-coordinate of the center of the ellipse.
	* @param radiusX - The horizontal radius of the ellipse.
	* @param radiusY - The vertical radius of the ellipse.
	* @returns The instance of the current object for chaining.
	*/
	ellipse(x, y, radiusX, radiusY) {
		this._tick++;
		this._activePath.ellipse(x, y, radiusX, radiusY, this._transform.clone());
		return this;
	}
	/**
	* Draws a circle shape. This method adds a new circle path to the current drawing.
	* @param x - The x-coordinate of the center of the circle.
	* @param y - The y-coordinate of the center of the circle.
	* @param radius - The radius of the circle.
	* @returns The instance of the current object for chaining.
	*/
	circle(x, y, radius) {
		this._tick++;
		this._activePath.circle(x, y, radius, this._transform.clone());
		return this;
	}
	/**
	* Adds another `GraphicsPath` to this path, optionally applying a transformation.
	* @param path - The `GraphicsPath` to add.
	* @returns The instance of the current object for chaining.
	*/
	path(path) {
		this._tick++;
		this._activePath.addPath(path, this._transform.clone());
		return this;
	}
	/**
	* Connects the current point to a new point with a straight line. This method updates the current path.
	* @param x - The x-coordinate of the new point to connect to.
	* @param y - The y-coordinate of the new point to connect to.
	* @returns The instance of the current object for chaining.
	*/
	lineTo(x, y) {
		this._tick++;
		const t = this._transform;
		this._activePath.lineTo(t.a * x + t.c * y + t.tx, t.b * x + t.d * y + t.ty);
		return this;
	}
	/**
	* Sets the starting point for a new sub-path. Any subsequent drawing commands are considered part of this path.
	* @param x - The x-coordinate for the starting point.
	* @param y - The y-coordinate for the starting point.
	* @returns The instance of the current object for chaining.
	*/
	moveTo(x, y) {
		this._tick++;
		const t = this._transform;
		const instructions = this._activePath.instructions;
		const transformedX = t.a * x + t.c * y + t.tx;
		const transformedY = t.b * x + t.d * y + t.ty;
		if (instructions.length === 1 && instructions[0].action === "moveTo") {
			instructions[0].data[0] = transformedX;
			instructions[0].data[1] = transformedY;
			return this;
		}
		this._activePath.moveTo(transformedX, transformedY);
		return this;
	}
	/**
	* Adds a quadratic curve to the path. It requires two points: the control point and the end point.
	* The starting point is the last point in the current path.
	* @param cpx - The x-coordinate of the control point.
	* @param cpy - The y-coordinate of the control point.
	* @param x - The x-coordinate of the end point.
	* @param y - The y-coordinate of the end point.
	* @param smoothness - Optional parameter to adjust the smoothness of the curve.
	* @returns The instance of the current object for chaining.
	*/
	quadraticCurveTo(cpx, cpy, x, y, smoothness) {
		this._tick++;
		const t = this._transform;
		this._activePath.quadraticCurveTo(t.a * cpx + t.c * cpy + t.tx, t.b * cpx + t.d * cpy + t.ty, t.a * x + t.c * y + t.tx, t.b * x + t.d * y + t.ty, smoothness);
		return this;
	}
	/**
	* Draws a rectangle shape. This method adds a new rectangle path to the current drawing.
	* @param x - The x-coordinate of the top-left corner of the rectangle.
	* @param y - The y-coordinate of the top-left corner of the rectangle.
	* @param w - The width of the rectangle.
	* @param h - The height of the rectangle.
	* @returns The instance of the current object for chaining.
	*/
	rect(x, y, w, h) {
		this._tick++;
		this._activePath.rect(x, y, w, h, this._transform.clone());
		return this;
	}
	/**
	* Draws a rectangle with rounded corners.
	* The corner radius can be specified to determine how rounded the corners should be.
	* An optional transformation can be applied, which allows for rotation, scaling, and translation of the rectangle.
	* @param x - The x-coordinate of the top-left corner of the rectangle.
	* @param y - The y-coordinate of the top-left corner of the rectangle.
	* @param w - The width of the rectangle.
	* @param h - The height of the rectangle.
	* @param radius - The radius of the rectangle's corners. If not specified, corners will be sharp.
	* @returns The instance of the current object for chaining.
	*/
	roundRect(x, y, w, h, radius) {
		this._tick++;
		this._activePath.roundRect(x, y, w, h, radius, this._transform.clone());
		return this;
	}
	/**
	* Draws a polygon shape by specifying a sequence of points. This method allows for the creation of complex polygons,
	* which can be both open and closed. An optional transformation can be applied, enabling the polygon to be scaled,
	* rotated, or translated as needed.
	* @param points - An array of numbers, or an array of PointData objects eg [{x,y}, {x,y}, {x,y}]
	* representing the x and y coordinates, of the polygon's vertices, in sequence.
	* @param close - A boolean indicating whether to close the polygon path. True by default.
	*/
	poly(points, close) {
		this._tick++;
		this._activePath.poly(points, close, this._transform.clone());
		return this;
	}
	/**
	* Draws a regular polygon with a specified number of sides. All sides and angles are equal.
	* @param x - The x-coordinate of the center of the polygon.
	* @param y - The y-coordinate of the center of the polygon.
	* @param radius - The radius of the circumscribed circle of the polygon.
	* @param sides - The number of sides of the polygon. Must be 3 or more.
	* @param rotation - The rotation angle of the polygon, in radians. Zero by default.
	* @param transform - An optional `Matrix` object to apply a transformation to the polygon.
	* @returns The instance of the current object for chaining.
	*/
	regularPoly(x, y, radius, sides, rotation = 0, transform) {
		this._tick++;
		this._activePath.regularPoly(x, y, radius, sides, rotation, transform);
		return this;
	}
	/**
	* Draws a polygon with rounded corners.
	* Similar to `regularPoly` but with the ability to round the corners of the polygon.
	* @param x - The x-coordinate of the center of the polygon.
	* @param y - The y-coordinate of the center of the polygon.
	* @param radius - The radius of the circumscribed circle of the polygon.
	* @param sides - The number of sides of the polygon. Must be 3 or more.
	* @param corner - The radius of the rounding of the corners.
	* @param rotation - The rotation angle of the polygon, in radians. Zero by default.
	* @returns The instance of the current object for chaining.
	*/
	roundPoly(x, y, radius, sides, corner, rotation) {
		this._tick++;
		this._activePath.roundPoly(x, y, radius, sides, corner, rotation);
		return this;
	}
	/**
	* Draws a shape with rounded corners. This function supports custom radius for each corner of the shape.
	* Optionally, corners can be rounded using a quadratic curve instead of an arc, providing a different aesthetic.
	* @param points - An array of `RoundedPoint` representing the corners of the shape to draw.
	* A minimum of 3 points is required.
	* @param radius - The default radius for the corners.
	* This radius is applied to all corners unless overridden in `points`.
	* @param useQuadratic - If set to true, rounded corners are drawn using a quadraticCurve
	*  method instead of an arc method. Defaults to false.
	* @param smoothness - Specifies the smoothness of the curve when `useQuadratic` is true.
	* Higher values make the curve smoother.
	* @returns The instance of the current object for chaining.
	*/
	roundShape(points, radius, useQuadratic, smoothness) {
		this._tick++;
		this._activePath.roundShape(points, radius, useQuadratic, smoothness);
		return this;
	}
	/**
	* Draw Rectangle with fillet corners. This is much like rounded rectangle
	* however it support negative numbers as well for the corner radius.
	* @param x - Upper left corner of rect
	* @param y - Upper right corner of rect
	* @param width - Width of rect
	* @param height - Height of rect
	* @param fillet - accept negative or positive values
	*/
	filletRect(x, y, width, height, fillet) {
		this._tick++;
		this._activePath.filletRect(x, y, width, height, fillet);
		return this;
	}
	/**
	* Draw Rectangle with chamfer corners. These are angled corners.
	* @param x - Upper left corner of rect
	* @param y - Upper right corner of rect
	* @param width - Width of rect
	* @param height - Height of rect
	* @param chamfer - non-zero real number, size of corner cutout
	* @param transform
	*/
	chamferRect(x, y, width, height, chamfer, transform) {
		this._tick++;
		this._activePath.chamferRect(x, y, width, height, chamfer, transform);
		return this;
	}
	/**
	* Draws a star shape centered at a specified location. This method allows for the creation
	*  of stars with a variable number of points, outer radius, optional inner radius, and rotation.
	* The star is drawn as a closed polygon with alternating outer and inner vertices to create the star's points.
	* An optional transformation can be applied to scale, rotate, or translate the star as needed.
	* @param x - The x-coordinate of the center of the star.
	* @param y - The y-coordinate of the center of the star.
	* @param points - The number of points of the star.
	* @param radius - The outer radius of the star (distance from the center to the outer points).
	* @param innerRadius - Optional. The inner radius of the star
	* (distance from the center to the inner points between the outer points).
	* If not provided, defaults to half of the `radius`.
	* @param rotation - Optional. The rotation of the star in radians, where 0 is aligned with the y-axis.
	* Defaults to 0, meaning one point is directly upward.
	* @returns The instance of the current object for chaining further drawing commands.
	*/
	star(x, y, points, radius, innerRadius = 0, rotation = 0) {
		this._tick++;
		this._activePath.star(x, y, points, radius, innerRadius, rotation, this._transform.clone());
		return this;
	}
	/**
	* Parses and renders an SVG string into the graphics context. This allows for complex shapes and paths
	* defined in SVG format to be drawn within the graphics context.
	* @param svg - The SVG string to be parsed and rendered.
	*/
	svg(svg) {
		this._tick++;
		SVGParser(svg, this);
		return this;
	}
	/**
	* Restores the most recently saved graphics state by popping the top of the graphics state stack.
	* This includes transformations, fill styles, and stroke styles.
	*/
	restore() {
		const state = this._stateStack.pop();
		if (state) {
			this._transform = state.transform;
			this._fillStyle = state.fillStyle;
			this._strokeStyle = state.strokeStyle;
		}
		return this;
	}
	/** Saves the current graphics state, including transformations, fill styles, and stroke styles, onto a stack. */
	save() {
		this._stateStack.push({
			transform: this._transform.clone(),
			fillStyle: { ...this._fillStyle },
			strokeStyle: { ...this._strokeStyle }
		});
		return this;
	}
	/**
	* Returns the current transformation matrix of the graphics context.
	* @returns The current transformation matrix.
	*/
	getTransform() {
		return this._transform;
	}
	/**
	* Resets the current transformation matrix to the identity matrix, effectively removing any transformations (rotation, scaling, translation) previously applied.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	resetTransform() {
		this._transform.identity();
		return this;
	}
	/**
	* Applies a rotation transformation to the graphics context around the current origin.
	* @param angle - The angle of rotation in radians.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	rotate(angle) {
		this._transform.rotate(angle);
		return this;
	}
	/**
	* Applies a scaling transformation to the graphics context, scaling drawings by x horizontally and by y vertically.
	* @param x - The scale factor in the horizontal direction.
	* @param y - (Optional) The scale factor in the vertical direction. If not specified, the x value is used for both directions.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	scale(x, y = x) {
		this._transform.scale(x, y);
		return this;
	}
	setTransform(a, b, c, d, dx, dy) {
		if (a instanceof Matrix) {
			this._transform.set(a.a, a.b, a.c, a.d, a.tx, a.ty);
			return this;
		}
		this._transform.set(a, b, c, d, dx, dy);
		return this;
	}
	transform(a, b, c, d, dx, dy) {
		if (a instanceof Matrix) {
			this._transform.append(a);
			return this;
		}
		tempMatrix.set(a, b, c, d, dx, dy);
		this._transform.append(tempMatrix);
		return this;
	}
	/**
	* Applies a translation transformation to the graphics context, moving the origin by the specified amounts.
	* @param x - The amount to translate in the horizontal direction.
	* @param y - (Optional) The amount to translate in the vertical direction. If not specified, the x value is used for both directions.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	translate(x, y = x) {
		this._transform.translate(x, y);
		return this;
	}
	/**
	* Clears all drawing commands from the graphics context, effectively resetting it. This includes clearing the path,
	* and optionally resetting transformations to the identity matrix.
	* @returns The instance of the current GraphicsContext for method chaining.
	*/
	clear() {
		this._activePath.clear();
		this.instructions.length = 0;
		this.resetTransform();
		this.onUpdate();
		return this;
	}
	onUpdate() {
		this._boundsDirty = true;
		this.dirty = true;
		this.emit("update", this, 16);
	}
	/** The bounds of the graphic shape. */
	get bounds() {
		if (!this._boundsDirty) return this._bounds;
		this._boundsDirty = false;
		const bounds = this._bounds;
		bounds.clear();
		for (let i = 0; i < this.instructions.length; i++) {
			const instruction = this.instructions[i];
			const action = instruction.action;
			if (action === "fill") {
				const data = instruction.data;
				bounds.addBounds(data.path.bounds);
			} else if (action === "texture") {
				const data = instruction.data;
				bounds.addFrame(data.dx, data.dy, data.dx + data.dw, data.dy + data.dh, data.transform);
			}
			if (action === "stroke") {
				const data = instruction.data;
				const alignment = data.style.alignment;
				let outerPadding = data.style.width * (1 - alignment);
				if (data.style.join === "miter") outerPadding *= getMaxMiterRatio(data.path, data.style.miterLimit);
				const _bounds = data.path.bounds;
				bounds.addFrame(_bounds.minX - outerPadding, _bounds.minY - outerPadding, _bounds.maxX + outerPadding, _bounds.maxY + outerPadding);
			}
		}
		if (!bounds.isValid) bounds.set(0, 0, 0, 0);
		return bounds;
	}
	/**
	* Check to see if a point is contained within this geometry.
	* @param point - Point to check if it's contained.
	* @returns {boolean} `true` if the point is contained within geometry.
	*/
	containsPoint(point) {
		if (!this.bounds.containsPoint(point.x, point.y)) return false;
		const instructions = this.instructions;
		let hasHit = false;
		for (let k = 0; k < instructions.length; k++) {
			const instruction = instructions[k];
			const data = instruction.data;
			const path = data.path;
			if (!instruction.action || !path) continue;
			const style = data.style;
			const shapes = path.shapePath.shapePrimitives;
			for (let i = 0; i < shapes.length; i++) {
				const shape = shapes[i].shape;
				if (!style || !shape) continue;
				const transform = shapes[i].transform;
				const transformedPoint = transform ? transform.applyInverse(point, tmpPoint) : point;
				if (instruction.action === "fill") hasHit = shape.contains(transformedPoint.x, transformedPoint.y);
				else {
					const strokeStyle = style;
					hasHit = shape.strokeContains(transformedPoint.x, transformedPoint.y, strokeStyle.width, strokeStyle.alignment);
				}
				const holes = data.hole;
				if (holes) {
					const holeShapes = holes.shapePath?.shapePrimitives;
					if (holeShapes) {
						for (let j = 0; j < holeShapes.length; j++) if (holeShapes[j].shape.contains(transformedPoint.x, transformedPoint.y)) hasHit = false;
					}
				}
				if (hasHit) return true;
			}
		}
		return hasHit;
	}
	/** Unloads the GPU data from the graphics context. */
	unload() {
		this.emit("unload", this);
		for (const key in this._gpuData) this._gpuData[key]?.destroy();
		this._gpuData = /* @__PURE__ */ Object.create(null);
	}
	/**
	* Destroys the GraphicsData object.
	* @param options - Options parameter. A boolean will act as if all options
	*  have been set to that value
	* @example
	* context.destroy();
	* context.destroy(true);
	* context.destroy({ texture: true, textureSource: true });
	*/
	destroy(options = false) {
		if (this.destroyed) return;
		this.destroyed = true;
		this._stateStack.length = 0;
		this._transform = null;
		this.unload();
		this.emit("destroy", this);
		this.removeAllListeners();
		if (typeof options === "boolean" ? options : options?.texture) {
			const destroyTextureSource = typeof options === "boolean" ? options : options?.textureSource;
			if (this._fillStyle.texture) this._fillStyle.fill && "uid" in this._fillStyle.fill ? this._fillStyle.fill.destroy() : this._fillStyle.texture.destroy(destroyTextureSource);
			if (this._strokeStyle.texture) this._strokeStyle.fill && "uid" in this._strokeStyle.fill ? this._strokeStyle.fill.destroy() : this._strokeStyle.texture.destroy(destroyTextureSource);
		}
		this._fillStyle = null;
		this._strokeStyle = null;
		this.instructions = null;
		this._activePath = null;
		this._bounds = null;
		this._stateStack = null;
		this.customShader = null;
		this._transform = null;
	}
};
/** The default fill style to use when none is provided. */
_GraphicsContext.defaultFillStyle = {
	/** The color to use for the fill. */
	color: 16777215,
	/** The alpha value to use for the fill. */
	alpha: 1,
	/** The texture to use for the fill. */
	texture: Texture.WHITE,
	/** The matrix to apply. */
	matrix: null,
	/** The fill pattern to use. */
	fill: null,
	/** Whether coordinates are 'global' or 'local' */
	textureSpace: "local"
};
/** The default stroke style to use when none is provided. */
_GraphicsContext.defaultStrokeStyle = {
	/** The width of the stroke. */
	width: 1,
	/** The color to use for the stroke. */
	color: 16777215,
	/** The alpha value to use for the stroke. */
	alpha: 1,
	/** The alignment of the stroke. */
	alignment: .5,
	/** The miter limit to use. */
	miterLimit: 10,
	/** The line cap style to use. */
	cap: "butt",
	/** The line join style to use. */
	join: "miter",
	/** The texture to use for the fill. */
	texture: Texture.WHITE,
	/** The matrix to apply. */
	matrix: null,
	/** The fill pattern to use. */
	fill: null,
	/** Whether coordinates are 'global' or 'local' */
	textureSpace: "local",
	/** If the stroke is a pixel line. */
	pixelLine: false
};
var GraphicsContext = _GraphicsContext;
//#endregion
export { Circle as $, shapeBuilders as A, curveEps as B, buildArc as C, GraphicsContextRenderData as D, GpuGraphicsContext as E, buildPolygon as F, transformVertices as G, buildEllipse as H, triangulateWithHoles as I, RoundedRectangle as J, buildSimpleUvs as K, buildPixelLine as L, FillGradient as M, buildTriangle as N, GraphicsContextSystem as O, buildRectangle as P, Ellipse as Q, buildLine as R, buildArcTo as S, buildAdaptiveBezier as T, buildRoundedRectangle as U, buildCircle as V, BatchableGraphics as W, squaredDistanceToLineSegment as X, Polygon as Y, getOrientationOfPoints as Z, GraphicsPath as _, FillPattern as a, roundedShapeQuadraticCurve as b, calculatePathArea as c, getFillInstructionData as d, parseSVGPath as et, parseSVGStyle as f, parseSVGFloatAttribute as g, parseSVGDefinitions as h, toStrokeStyle as i, generateTextureMatrix as j, buildContextBatches as k, extractSubpaths as l, extractSvgUrlId as m, getMaxMiterRatio as n, SVGParser as o, styleAttributes as p, buildUvs as q, toFillStyle as r, appendSVGPath as s, GraphicsContext as t, earcut as tt, checkForNestedPattern as u, ShapePath as v, buildAdaptiveQuadratic as w, buildArcToSvg as x, roundedShapeArc as y, closePointEps as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR3JhcGhpY3NDb250ZXh0LUNxZzRzRE0yLmpzIiwibmFtZXMiOlsiZWFyY3V0IiwiZWFyY3V0TW9kdWxlIiwidGVtcFJlY3QiLCJ0ZW1wVGV4dHVyZU1hdHJpeCIsInRlbXBSZWN0IiwiUkVDVVJTSU9OX0xJTUlUIiwiRkxUX0VQU0lMT04iLCJQQVRIX0RJU1RBTkNFX0VQU0lMT04iLCJiZWdpbiIsInJlY3Vyc2l2ZSIsIkV2ZW50RW1pdHRlciJdLCJzb3VyY2VzIjpbIi4uLy4uL2VhcmN1dC9zcmMvZWFyY3V0LmpzIiwiLi4vLi4vcGl4aS5qcy9saWIvdXRpbHMvdXRpbHMubWpzIiwiLi4vLi4vcGFyc2Utc3ZnLXBhdGgvZGlzdC9pbmRleC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvc3ZnL3BhcnNlU1ZHUGF0aC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9tYXRocy9zaGFwZXMvQ2lyY2xlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL21hdGhzL3NoYXBlcy9FbGxpcHNlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL21hdGhzL21pc2MvZ2V0T3JpZW50YXRpb25PZlBvaW50cy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9tYXRocy9taXNjL3NxdWFyZWREaXN0YW5jZVRvTGluZVNlZ21lbnQubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvbWF0aHMvc2hhcGVzL1BvbHlnb24ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvbWF0aHMvc2hhcGVzL1JvdW5kZWRSZWN0YW5nbGUubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvZ2VvbWV0cnkvdXRpbHMvYnVpbGRVdnMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvZ2VvbWV0cnkvdXRpbHMvdHJhbnNmb3JtVmVydGljZXMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3Mvc2hhcmVkL0JhdGNoYWJsZUdyYXBoaWNzLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC9idWlsZENvbW1hbmRzL2J1aWxkQ2lyY2xlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC9jb25zdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvYnVpbGRDb21tYW5kcy9idWlsZExpbmUubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3Mvc2hhcmVkL2J1aWxkQ29tbWFuZHMvYnVpbGRQaXhlbExpbmUubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3Mvc2hhcmVkL3V0aWxzL3RyaWFuZ3VsYXRlV2l0aEhvbGVzLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC9idWlsZENvbW1hbmRzL2J1aWxkUG9seWdvbi5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvYnVpbGRDb21tYW5kcy9idWlsZFJlY3RhbmdsZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvYnVpbGRDb21tYW5kcy9idWlsZFRyaWFuZ2xlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC9maWxsL0ZpbGxHcmFkaWVudC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvdXRpbHMvZ2VuZXJhdGVUZXh0dXJlRmlsbE1hdHJpeC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvdXRpbHMvYnVpbGRDb250ZXh0QmF0Y2hlcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvR3JhcGhpY3NDb250ZXh0U3lzdGVtLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC9idWlsZENvbW1hbmRzL2J1aWxkQWRhcHRpdmVCZXppZXIubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3Mvc2hhcmVkL2J1aWxkQ29tbWFuZHMvYnVpbGRBZGFwdGl2ZVF1YWRyYXRpYy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvYnVpbGRDb21tYW5kcy9idWlsZEFyYy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvYnVpbGRDb21tYW5kcy9idWlsZEFyY1RvLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC9idWlsZENvbW1hbmRzL2J1aWxkQXJjVG9TdmcubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3Mvc2hhcmVkL3BhdGgvcm91bmRTaGFwZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvcGF0aC9TaGFwZVBhdGgubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3Mvc2hhcmVkL3BhdGgvR3JhcGhpY3NQYXRoLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC9zdmcvcGFyc2VTVkdGbG9hdEF0dHJpYnV0ZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvc3ZnL3BhcnNlU1ZHRGVmaW5pdGlvbnMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3Mvc2hhcmVkL3N2Zy91dGlscy9leHRyYWN0U3ZnVXJsSWQubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3Mvc2hhcmVkL3N2Zy9wYXJzZVNWR1N0eWxlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC9zdmcvdXRpbHMvZmlsbE9wZXJhdGlvbnMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3Mvc2hhcmVkL3N2Zy91dGlscy9wYXRoT3BlcmF0aW9ucy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvc3ZnL1NWR1BhcnNlci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvZmlsbC9GaWxsUGF0dGVybi5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9ncmFwaGljcy9zaGFyZWQvdXRpbHMvY29udmVydEZpbGxJbnB1dFRvRmlsbFN0eWxlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC91dGlscy9nZXRNYXhNaXRlclJhdGlvLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2dyYXBoaWNzL3NoYXJlZC9HcmFwaGljc0NvbnRleHQubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQSB2ZXJ0ZXggaW4gYSBjaXJjdWxhciBkb3VibHkgbGlua2VkIGxpc3QgcmVwcmVzZW50aW5nIGEgcG9seWdvbiByaW5nLlxuICogYHByZXZgL2BuZXh0YCBhcmUgYWx3YXlzIGxpbmtlZCAoc2V0IGltbWVkaWF0ZWx5IGFmdGVyIHtAbGluayBjcmVhdGVOb2RlfSksIHNvIHRoZXkncmUgdHlwZWRcbiAqIG5vbi1udWxsOyBgcHJldlpgL2BuZXh0WmAgYXJlIHRoZSB6LW9yZGVyIGxpc3QgbGlua3MgYW5kIGFyZSBudWxsIGF0IHRoZSBlbmRzLlxuICpcbiAqIEB0eXBlZGVmIHtvYmplY3R9IE5vZGVcbiAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBpIHZlcnRleCBpbmRleCBpbiB0aGUgY29vcmRpbmF0ZXMgYXJyYXlcbiAqIEBwcm9wZXJ0eSB7bnVtYmVyfSB4IHZlcnRleCB4IGNvb3JkaW5hdGVcbiAqIEBwcm9wZXJ0eSB7bnVtYmVyfSB5IHZlcnRleCB5IGNvb3JkaW5hdGVcbiAqIEBwcm9wZXJ0eSB7Tm9kZX0gcHJldiBwcmV2aW91cyB2ZXJ0ZXggbm9kZSBpbiB0aGUgcG9seWdvbiByaW5nXG4gKiBAcHJvcGVydHkge05vZGV9IG5leHQgbmV4dCB2ZXJ0ZXggbm9kZSBpbiB0aGUgcG9seWdvbiByaW5nXG4gKiBAcHJvcGVydHkge251bWJlcn0geiB6LW9yZGVyIGN1cnZlIHZhbHVlOyBkb3VibGVzIGFzIHRoZSBvd25pbmcgYmxvY2sgaW5kZXggZHVyaW5nIGVsaW1pbmF0ZUhvbGVzXG4gKiBAcHJvcGVydHkge05vZGUgfCBudWxsfSBwcmV2WiBwcmV2aW91cyBub2RlIGluIHotb3JkZXJcbiAqIEBwcm9wZXJ0eSB7Tm9kZSB8IG51bGx9IG5leHRaIG5leHQgbm9kZSBpbiB6LW9yZGVyXG4gKi9cblxuLy8gc2luZ2xlLXZlcnRleCBob2xlcyB0byBwcmVzZXJ2ZSB0aHJvdWdoIGZpbHRlclBvaW50cyAoc3RlaW5lciBwb2ludHMpOyBrZXB0IG9mZiB0aGUgTm9kZVxuLy8gc2hhcGUgc2luY2UgdGhleSdyZSByYXJlIOKAlCB0aGUgZW1wdHktc2V0IGZhc3QgcGF0aCBtZWFucyBub24tc3RlaW5lciBpbnB1dHMgcGF5IG5vdGhpbmdcbi8qKiBAdHlwZSB7U2V0PE5vZGU+fSAqL1xuY29uc3Qgc3RlaW5lcnMgPSBuZXcgU2V0KCk7XG5cbi8vIHNldCBieSBmaWx0ZXJQb2ludHMgd2hlbmV2ZXIgaXQgcmVtb3ZlcyBhdCBsZWFzdCBvbmUgbm9kZTsgcmVhZCBieSBlYXJjdXRMaW5rZWQncyBzdGFsbFxuLy8gaGFuZGxlciB0byBkZWNpZGUgd2hldGhlciBhbm90aGVyIGNsaXAgcGFzcyBpcyB3b3J0aCBhdHRlbXB0aW5nIGJlZm9yZSB0aGUgY29zdGxpZXIgc3RhZ2VzXG5sZXQgZmlsdGVyZWRPdXQgPSBmYWxzZTtcblxuLyoqXG4gKiBUcmlhbmd1bGF0ZSBhIHBvbHlnb24gZ2l2ZW4gYXMgYSBmbGF0IGFycmF5IG9mIHZlcnRleCBjb29yZGluYXRlcy5cbiAqXG4gKiBAcGFyYW0ge0FycmF5TGlrZTxudW1iZXI+fSBkYXRhIGZsYXQgYXJyYXkgb2YgdmVydGV4IGNvb3JkaW5hdGVzXG4gKiBAcGFyYW0ge0FycmF5TGlrZTxudW1iZXI+IHwgbnVsbH0gW2hvbGVJbmRpY2VzXSBpbmRpY2VzIChpbiB2ZXJ0aWNlcywgbm90IGNvb3JkaW5hdGVzKSB3aGVyZSBlYWNoIGhvbGUgcmluZyBzdGFydHNcbiAqIEBwYXJhbSB7bnVtYmVyfSBbZGltPTJdIG51bWJlciBvZiBjb29yZGluYXRlcyBwZXIgdmVydGV4IGluIGBkYXRhYFxuICogQHJldHVybnMge251bWJlcltdfSB0cmlhbmdsZXMgYXMgdHJpcGxldHMgb2YgdmVydGV4IGluZGljZXMgaW50byBgZGF0YWBcbiAqIEBleGFtcGxlIGVhcmN1dChbMTAsMCwgMCw1MCwgNjAsNjAsIDcwLDEwXSk7IC8vIFsxLDAsMywgMywyLDFdXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGVhcmN1dChkYXRhLCBob2xlSW5kaWNlcywgZGltID0gMikge1xuXG4gICAgY29uc3QgaGFzSG9sZXMgPSBob2xlSW5kaWNlcyAmJiBob2xlSW5kaWNlcy5sZW5ndGg7XG4gICAgY29uc3Qgb3V0ZXJMZW4gPSBoYXNIb2xlcyA/IGhvbGVJbmRpY2VzWzBdICogZGltIDogZGF0YS5sZW5ndGg7XG4gICAgaWYgKHN0ZWluZXJzLnNpemUpIHN0ZWluZXJzLmNsZWFyKCk7XG5cbiAgICBsZXQgb3V0ZXJOb2RlID0gbGlua2VkTGlzdChkYXRhLCAwLCBvdXRlckxlbiwgZGltLCB0cnVlKTtcbiAgICAvKiogQHR5cGUge251bWJlcltdfSAqL1xuICAgIGNvbnN0IHRyaWFuZ2xlcyA9IFtdO1xuXG4gICAgaWYgKCFvdXRlck5vZGUgfHwgb3V0ZXJOb2RlLm5leHQgPT09IG91dGVyTm9kZS5wcmV2KSByZXR1cm4gdHJpYW5nbGVzO1xuXG4gICAgbGV0IG1pblggPSAwLCBtaW5ZID0gMCwgaW52U2l6ZSA9IDA7XG5cbiAgICBpZiAoaGFzSG9sZXMpIG91dGVyTm9kZSA9IGVsaW1pbmF0ZUhvbGVzKGRhdGEsIGhvbGVJbmRpY2VzLCBvdXRlck5vZGUsIGRpbSk7XG5cbiAgICAvLyBpZiB0aGUgc2hhcGUgaXMgbm90IHRvbyBzaW1wbGUsIHdlJ2xsIHVzZSB6LW9yZGVyIGN1cnZlIGhhc2ggbGF0ZXI7IGNhbGN1bGF0ZSBwb2x5Z29uIGJib3hcbiAgICBpZiAoZGF0YS5sZW5ndGggPiA4MCAqIGRpbSkge1xuICAgICAgICBtaW5YID0gZGF0YVswXTtcbiAgICAgICAgbWluWSA9IGRhdGFbMV07XG4gICAgICAgIGxldCBtYXhYID0gbWluWDtcbiAgICAgICAgbGV0IG1heFkgPSBtaW5ZO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSBkaW07IGkgPCBvdXRlckxlbjsgaSArPSBkaW0pIHtcbiAgICAgICAgICAgIGNvbnN0IHggPSBkYXRhW2ldO1xuICAgICAgICAgICAgY29uc3QgeSA9IGRhdGFbaSArIDFdO1xuICAgICAgICAgICAgaWYgKHggPCBtaW5YKSBtaW5YID0geDtcbiAgICAgICAgICAgIGlmICh5IDwgbWluWSkgbWluWSA9IHk7XG4gICAgICAgICAgICBpZiAoeCA+IG1heFgpIG1heFggPSB4O1xuICAgICAgICAgICAgaWYgKHkgPiBtYXhZKSBtYXhZID0geTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIG1pblgsIG1pblkgYW5kIGludlNpemUgYXJlIGxhdGVyIHVzZWQgdG8gdHJhbnNmb3JtIGNvb3JkcyBpbnRvIGludGVnZXJzIGZvciB6LW9yZGVyIGNhbGN1bGF0aW9uXG4gICAgICAgIGludlNpemUgPSBNYXRoLm1heChtYXhYIC0gbWluWCwgbWF4WSAtIG1pblkpO1xuICAgICAgICBpbnZTaXplID0gaW52U2l6ZSAhPT0gMCA/IDMyNzY3IC8gaW52U2l6ZSA6IDA7XG4gICAgfVxuXG4gICAgZWFyY3V0TGlua2VkKG91dGVyTm9kZSwgdHJpYW5nbGVzLCBtaW5YLCBtaW5ZLCBpbnZTaXplKTtcblxuICAgIHJldHVybiB0cmlhbmdsZXM7XG59XG5cbi8vIGNyZWF0ZSBhIGNpcmN1bGFyIGRvdWJseSBsaW5rZWQgbGlzdCBmcm9tIHBvbHlnb24gcG9pbnRzIGluIHRoZSBzcGVjaWZpZWQgd2luZGluZyBvcmRlclxuLyoqIEBwYXJhbSB7QXJyYXlMaWtlPG51bWJlcj59IGRhdGEgQHBhcmFtIHtudW1iZXJ9IHN0YXJ0IEBwYXJhbSB7bnVtYmVyfSBlbmQgQHBhcmFtIHtudW1iZXJ9IGRpbSBAcGFyYW0ge2Jvb2xlYW59IGNsb2Nrd2lzZSBAcmV0dXJucyB7Tm9kZSB8IG51bGx9ICovXG5mdW5jdGlvbiBsaW5rZWRMaXN0KGRhdGEsIHN0YXJ0LCBlbmQsIGRpbSwgY2xvY2t3aXNlKSB7XG4gICAgLyoqIEB0eXBlIHtOb2RlIHwgbnVsbH0gKi9cbiAgICBsZXQgbGFzdCA9IG51bGw7XG5cbiAgICBpZiAoY2xvY2t3aXNlID09PSAoc2lnbmVkQXJlYShkYXRhLCBzdGFydCwgZW5kLCBkaW0pID4gMCkpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IHN0YXJ0OyBpIDwgZW5kOyBpICs9IGRpbSkgbGFzdCA9IGluc2VydE5vZGUoaSAvIGRpbSB8IDAsIGRhdGFbaV0sIGRhdGFbaSArIDFdLCBsYXN0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBmb3IgKGxldCBpID0gZW5kIC0gZGltOyBpID49IHN0YXJ0OyBpIC09IGRpbSkgbGFzdCA9IGluc2VydE5vZGUoaSAvIGRpbSB8IDAsIGRhdGFbaV0sIGRhdGFbaSArIDFdLCBsYXN0KTtcbiAgICB9XG5cbiAgICBpZiAobGFzdCAmJiBlcXVhbHMobGFzdCwgbGFzdC5uZXh0KSkge1xuICAgICAgICByZW1vdmVOb2RlKGxhc3QpO1xuICAgICAgICBsYXN0ID0gbGFzdC5uZXh0O1xuICAgIH1cblxuICAgIHJldHVybiBsYXN0O1xufVxuXG4vLyBSZW1vdmUgY29sbGluZWFyIG9yIGNvaW5jaWRlbnQgcG9pbnRzOyByZW1vdmFiaWxpdHkgZGVwZW5kcyBvbmx5IG9uIGEgbm9kZSdzIGltbWVkaWF0ZVxuLy8gbmVpZ2hib3JzLCBzbyB3ZSBzd2VlcCBmb3J3YXJkIGFuZCByZS1jaGVjayB0aGUgcHJlZGVjZXNzb3IgYWZ0ZXIgZWFjaCByZW1vdmFsLiBXaXRoIG5vIGBlbmRgXG4vLyB3ZSBzd2VlcCB0aGUgd2hvbGUgcmluZywgbGFwcGluZyB1bnRpbCBub3RoaW5nIGlzIHJlbW92YWJsZSAodGhlIGZpeHBvaW50IHRoZSBjbGlwcGVyIG5lZWRzKS5cbi8vIFdpdGggYW4gZXhwbGljaXQgYGVuZGAgd2UgaGVhbCBvbmx5IHRoZSBkaXJ0eSB3aW5kb3cgYXJvdW5kIGEgYnJpZGdlL2RpYWdvbmFsIGN1dCwgc3RvcHBpbmcgYXRcbi8vIGBlbmRgIHJhdGhlciB0aGFuIGxhcHBpbmcg4oCUIE8od2luZG93KSBpbnN0ZWFkIG9mIE8ocmluZykuXG4vKiogQHBhcmFtIHtOb2RlfSBzdGFydCBAcGFyYW0ge05vZGV9IFtlbmRdIEByZXR1cm5zIHtOb2RlfSAqL1xuZnVuY3Rpb24gZmlsdGVyUG9pbnRzKHN0YXJ0LCBlbmQgPSBzdGFydCkge1xuICAgIGNvbnN0IGZ1bGwgPSBlbmQgPT09IHN0YXJ0O1xuXG4gICAgbGV0IHAgPSBzdGFydCwgYWdhaW47XG4gICAgZG8ge1xuICAgICAgICBhZ2FpbiA9IGZhbHNlO1xuICAgICAgICBpZiAocCAhPT0gcC5uZXh0ICYmIChzdGVpbmVycy5zaXplID09PSAwIHx8ICFzdGVpbmVycy5oYXMocCkpICYmXG4gICAgICAgICAgICAoZXF1YWxzKHAsIHAubmV4dCkgfHwgYXJlYShwLnByZXYsIHAsIHAubmV4dCkgPT09IDApKSB7XG4gICAgICAgICAgICBpZiAoZnVsbCB8fCBwID09PSBlbmQpIGVuZCA9IHAucHJldjsgLy8gcHVsbCB0aGUgc3RvcCBib3VuZCBiYWNrIHBhc3QgdGhlIHJlbW92YWxcbiAgICAgICAgICAgIGZpbHRlcmVkT3V0ID0gdHJ1ZTtcbiAgICAgICAgICAgIHJlbW92ZU5vZGUocCk7XG4gICAgICAgICAgICBwID0gcC5wcmV2OyAgICAgICAgIC8vIHJlLWNoZWNrIHRoZSBwcmVkZWNlc3NvclxuICAgICAgICAgICAgYWdhaW4gPSB0cnVlO1xuICAgICAgICB9IGVsc2UgaWYgKGZ1bGwgfHwgcCAhPT0gZW5kKSB7XG4gICAgICAgICAgICBwID0gcC5uZXh0O1xuICAgICAgICAgICAgYWdhaW4gPSAhZnVsbDsgICAgICAvLyBsb2NhbCBoZWFsOiBrZWVwIGxvb3BpbmcgdW50aWwgdGhlIHN3ZWVwIHJlYWNoZXMgZW5kXG4gICAgICAgIH1cbiAgICB9IHdoaWxlIChhZ2FpbiB8fCBwICE9PSBlbmQpO1xuXG4gICAgcmV0dXJuIGVuZDtcbn1cblxuLy8gbWFpbiBlYXIgc2xpY2luZyBsb29wIHdoaWNoIHRyaWFuZ3VsYXRlcyBhIHBvbHlnb24gKGdpdmVuIGFzIGEgbGlua2VkIGxpc3QpXG4vKiogQHBhcmFtIHtOb2RlfSBlYXIgQHBhcmFtIHtudW1iZXJbXX0gdHJpYW5nbGVzIEBwYXJhbSB7bnVtYmVyfSBtaW5YIEBwYXJhbSB7bnVtYmVyfSBtaW5ZIEBwYXJhbSB7bnVtYmVyfSBpbnZTaXplICovXG5mdW5jdGlvbiBlYXJjdXRMaW5rZWQoZWFyLCB0cmlhbmdsZXMsIG1pblgsIG1pblksIGludlNpemUpIHtcbiAgICAvLyBpbnRlcmxpbmsgcG9seWdvbiBub2RlcyBpbiB6LW9yZGVyXG4gICAgaWYgKGludlNpemUpIGluZGV4Q3VydmUoZWFyLCBtaW5YLCBtaW5ZLCBpbnZTaXplKTtcblxuICAgIGxldCBzdG9wID0gZWFyLCBjdXJlZCA9IGZhbHNlO1xuXG4gICAgLy8gaXRlcmF0ZSB0aHJvdWdoIGVhcnMsIHNsaWNpbmcgdGhlbSBvbmUgYnkgb25lXG4gICAgd2hpbGUgKGVhci5wcmV2ICE9PSBlYXIubmV4dCkge1xuICAgICAgICBjb25zdCBwcmV2ID0gZWFyLnByZXY7XG4gICAgICAgIC8qKiBAdHlwZSB7Tm9kZX0gKi9cbiAgICAgICAgY29uc3QgbmV4dCA9IGVhci5uZXh0O1xuXG4gICAgICAgIGlmIChhcmVhKHByZXYsIGVhciwgbmV4dCkgPCAwICYmIChpbnZTaXplID8gaXNFYXJIYXNoZWQoZWFyLCBtaW5YLCBtaW5ZLCBpbnZTaXplKSA6IGlzRWFyKGVhcikpKSB7XG4gICAgICAgICAgICB0cmlhbmdsZXMucHVzaChwcmV2LmksIGVhci5pLCBuZXh0LmkpOyAvLyBjdXQgb2ZmIHRoZSB0cmlhbmdsZVxuXG4gICAgICAgICAgICByZW1vdmVOb2RlKGVhcik7XG4gICAgICAgICAgICBlYXIgPSBuZXh0O1xuICAgICAgICAgICAgc3RvcCA9IG5leHQ7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGVhciA9IG5leHQ7XG5cbiAgICAgICAgLy8gaWYgd2UgbG9vcGVkIHRocm91Z2ggdGhlIHdob2xlIHJlbWFpbmluZyBwb2x5Z29uIGFuZCBjYW4ndCBmaW5kIGFueSBtb3JlIGVhcnNcbiAgICAgICAgaWYgKGVhciA9PT0gc3RvcCkge1xuICAgICAgICAgICAgLy8gdHJ5IGZpbHRlcmluZyBjb2xsaW5lYXIvY29pbmNpZGVudCBwb2ludHMgYW5kIHNsaWNpbmcgYWdhaW4g4oCUIHJlcGVhdCBhcyBsb25nIGFzXG4gICAgICAgICAgICAvLyBmaWx0ZXJpbmcgYWN0dWFsbHkgcmVtb3ZlcyBub2Rlcywgc2luY2UgZWFjaCByZW1vdmFsIGNhbiBleHBvc2UgbmV3IGVhcnNcbiAgICAgICAgICAgIGZpbHRlcmVkT3V0ID0gZmFsc2U7XG4gICAgICAgICAgICBlYXIgPSBmaWx0ZXJQb2ludHMoZWFyKTtcbiAgICAgICAgICAgIGlmIChmaWx0ZXJlZE91dCkgeyBzdG9wID0gZWFyOyBjb250aW51ZTsgfVxuXG4gICAgICAgICAgICAvLyBmaWx0ZXJpbmcgaXMgZXhoYXVzdGVkOiBjdXJlIHNtYWxsIGxvY2FsIHNlbGYtaW50ZXJzZWN0aW9ucyBvbmNlLCB0aGVuIHJldHJ5XG4gICAgICAgICAgICBpZiAoIWN1cmVkKSB7XG4gICAgICAgICAgICAgICAgZWFyID0gY3VyZUxvY2FsSW50ZXJzZWN0aW9ucyhlYXIsIHRyaWFuZ2xlcyk7XG4gICAgICAgICAgICAgICAgc3RvcCA9IGVhcjtcbiAgICAgICAgICAgICAgICBjdXJlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGFzIGEgbGFzdCByZXNvcnQsIHRyeSBzcGxpdHRpbmcgdGhlIHJlbWFpbmluZyBwb2x5Z29uIGludG8gdHdvXG4gICAgICAgICAgICBzcGxpdEVhcmN1dChlYXIsIHRyaWFuZ2xlcywgbWluWCwgbWluWSwgaW52U2l6ZSk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLy8gY2hlY2sgd2hldGhlciBhIHBvbHlnb24gbm9kZSBmb3JtcyBhIHZhbGlkIGVhciB3aXRoIGFkamFjZW50IG5vZGVzXG4vKiogQHBhcmFtIHtOb2RlfSBlYXIgQHJldHVybnMge2Jvb2xlYW59ICovXG5mdW5jdGlvbiBpc0VhcihlYXIpIHtcbiAgICAvLyByZWZsZXggY2hlY2sgKGFyZWEoYSwgYiwgYykgPj0gMCkgaXMgaG9pc3RlZCBpbnRvIHRoZSBlYXJjdXRMaW5rZWQgY2FsbGVyIHRvIGF2b2lkIG5vbi1pbmxpbmVkIGNhbGwgaGVyZVxuICAgIGNvbnN0IGEgPSBlYXIucHJldiwgYiA9IGVhciwgYyA9IGVhci5uZXh0LFxuICAgICAgICBheCA9IGEueCwgYnggPSBiLngsIGN4ID0gYy54LCBheSA9IGEueSwgYnkgPSBiLnksIGN5ID0gYy55LFxuICAgICAgICB4MCA9IE1hdGgubWluKGF4LCBieCwgY3gpLCAvLyB0cmlhbmdsZSBiYm94XG4gICAgICAgIHkwID0gTWF0aC5taW4oYXksIGJ5LCBjeSksXG4gICAgICAgIHgxID0gTWF0aC5tYXgoYXgsIGJ4LCBjeCksXG4gICAgICAgIHkxID0gTWF0aC5tYXgoYXksIGJ5LCBjeSk7XG5cbiAgICAvLyBtYWtlIHN1cmUgd2UgZG9uJ3QgaGF2ZSBvdGhlciBwb2ludHMgaW5zaWRlIHRoZSBwb3RlbnRpYWwgZWFyXG4gICAgbGV0IHAgPSBjLm5leHQ7XG4gICAgd2hpbGUgKHAgIT09IGEpIHtcbiAgICAgICAgaWYgKHAueCA+PSB4MCAmJiBwLnggPD0geDEgJiYgcC55ID49IHkwICYmIHAueSA8PSB5MSAmJiAhKGF4ID09PSBwLnggJiYgYXkgPT09IHAueSkgJiZcbiAgICAgICAgICAgIHBvaW50SW5UcmlhbmdsZShheCwgYXksIGJ4LCBieSwgY3gsIGN5LCBwLngsIHAueSkgJiYgYXJlYShwLnByZXYsIHAsIHAubmV4dCkgPj0gMCkgcmV0dXJuIGZhbHNlO1xuICAgICAgICBwID0gcC5uZXh0O1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn1cblxuLyoqIEBwYXJhbSB7Tm9kZX0gZWFyIEBwYXJhbSB7bnVtYmVyfSBtaW5YIEBwYXJhbSB7bnVtYmVyfSBtaW5ZIEBwYXJhbSB7bnVtYmVyfSBpbnZTaXplIEByZXR1cm5zIHtib29sZWFufSAqL1xuZnVuY3Rpb24gaXNFYXJIYXNoZWQoZWFyLCBtaW5YLCBtaW5ZLCBpbnZTaXplKSB7XG4gICAgLy8gcmVmbGV4IGNoZWNrIGlzIGhvaXN0ZWQgaW50byB0aGUgZWFyY3V0TGlua2VkIGNhbGxlciAoc2VlIGlzRWFyKVxuICAgIGNvbnN0IGEgPSBlYXIucHJldiwgYiA9IGVhciwgYyA9IGVhci5uZXh0LFxuICAgICAgICBheCA9IGEueCwgYnggPSBiLngsIGN4ID0gYy54LCBheSA9IGEueSwgYnkgPSBiLnksIGN5ID0gYy55LFxuICAgICAgICB4MCA9IE1hdGgubWluKGF4LCBieCwgY3gpLCAvLyB0cmlhbmdsZSBiYm94XG4gICAgICAgIHkwID0gTWF0aC5taW4oYXksIGJ5LCBjeSksXG4gICAgICAgIHgxID0gTWF0aC5tYXgoYXgsIGJ4LCBjeCksXG4gICAgICAgIHkxID0gTWF0aC5tYXgoYXksIGJ5LCBjeSksXG4gICAgICAgIG1pblogPSB6T3JkZXIoeDAsIHkwLCBtaW5YLCBtaW5ZLCBpbnZTaXplKSwgLy8gei1vcmRlciByYW5nZSBmb3IgdGhlIGN1cnJlbnQgdHJpYW5nbGUgYmJveDtcbiAgICAgICAgbWF4WiA9IHpPcmRlcih4MSwgeTEsIG1pblgsIG1pblksIGludlNpemUpO1xuXG4gICAgbGV0IHAgPSBlYXIucHJldlo7XG4gICAgd2hpbGUgKHAgJiYgcC56ID49IG1pblopIHsgLy8gbG9vayBmb3IgcG9pbnRzIGluc2lkZSB0aGUgdHJpYW5nbGUgaW4gZGVjcmVhc2luZyB6LW9yZGVyXG4gICAgICAgIGlmIChwLnggPj0geDAgJiYgcC54IDw9IHgxICYmIHAueSA+PSB5MCAmJiBwLnkgPD0geTEgJiYgcCAhPT0gYyAmJiAhKGF4ID09PSBwLnggJiYgYXkgPT09IHAueSkgJiZcbiAgICAgICAgICAgIHBvaW50SW5UcmlhbmdsZShheCwgYXksIGJ4LCBieSwgY3gsIGN5LCBwLngsIHAueSkgJiYgYXJlYShwLnByZXYsIHAsIHAubmV4dCkgPj0gMCkgcmV0dXJuIGZhbHNlO1xuICAgICAgICBwID0gcC5wcmV2WjtcbiAgICB9XG4gICAgbGV0IG4gPSBlYXIubmV4dFo7XG4gICAgd2hpbGUgKG4gJiYgbi56IDw9IG1heFopIHsgLy8gbG9vayBmb3IgcG9pbnRzIGluIGluY3JlYXNpbmcgei1vcmRlclxuICAgICAgICBpZiAobi54ID49IHgwICYmIG4ueCA8PSB4MSAmJiBuLnkgPj0geTAgJiYgbi55IDw9IHkxICYmIG4gIT09IGMgJiYgIShheCA9PT0gbi54ICYmIGF5ID09PSBuLnkpICYmXG4gICAgICAgICAgICBwb2ludEluVHJpYW5nbGUoYXgsIGF5LCBieCwgYnksIGN4LCBjeSwgbi54LCBuLnkpICYmIGFyZWEobi5wcmV2LCBuLCBuLm5leHQpID49IDApIHJldHVybiBmYWxzZTtcbiAgICAgICAgbiA9IG4ubmV4dFo7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufVxuXG4vLyBnbyB0aHJvdWdoIGFsbCBwb2x5Z29uIG5vZGVzIGFuZCBjdXJlIHNtYWxsIGxvY2FsIHNlbGYtaW50ZXJzZWN0aW9uc1xuLyoqIEBwYXJhbSB7Tm9kZX0gc3RhcnQgQHBhcmFtIHtudW1iZXJbXX0gdHJpYW5nbGVzIEByZXR1cm5zIHtOb2RlfSAqL1xuZnVuY3Rpb24gY3VyZUxvY2FsSW50ZXJzZWN0aW9ucyhzdGFydCwgdHJpYW5nbGVzKSB7XG4gICAgbGV0IHAgPSBzdGFydDtcbiAgICBsZXQgY3VyZWQgPSBmYWxzZTtcbiAgICBkbyB7XG4gICAgICAgIGNvbnN0IGEgPSBwLnByZXYsXG4gICAgICAgICAgICBiID0gcC5uZXh0Lm5leHQ7XG5cbiAgICAgICAgaWYgKGludGVyc2VjdHMoYSwgcCwgcC5uZXh0LCBiLCBmYWxzZSkgJiYgbG9jYWxseUluc2lkZShhLCBiKSAmJiBsb2NhbGx5SW5zaWRlKGIsIGEpKSB7XG5cbiAgICAgICAgICAgIHRyaWFuZ2xlcy5wdXNoKGEuaSwgcC5pLCBiLmkpO1xuXG4gICAgICAgICAgICAvLyByZW1vdmUgdHdvIG5vZGVzIGludm9sdmVkXG4gICAgICAgICAgICByZW1vdmVOb2RlKHApO1xuICAgICAgICAgICAgcmVtb3ZlTm9kZShwLm5leHQpO1xuXG4gICAgICAgICAgICBwID0gc3RhcnQgPSBiO1xuICAgICAgICAgICAgY3VyZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHAgPSBwLm5leHQ7XG4gICAgfSB3aGlsZSAocCAhPT0gc3RhcnQpO1xuXG4gICAgcmV0dXJuIGN1cmVkID8gZmlsdGVyUG9pbnRzKHApIDogcDtcbn1cblxuLy8gdHJ5IHNwbGl0dGluZyBwb2x5Z29uIGludG8gdHdvIGFuZCB0cmlhbmd1bGF0ZSB0aGVtIGluZGVwZW5kZW50bHlcbi8qKiBAcGFyYW0ge05vZGV9IHN0YXJ0IEBwYXJhbSB7bnVtYmVyW119IHRyaWFuZ2xlcyBAcGFyYW0ge251bWJlcn0gbWluWCBAcGFyYW0ge251bWJlcn0gbWluWSBAcGFyYW0ge251bWJlcn0gaW52U2l6ZSAqL1xuZnVuY3Rpb24gc3BsaXRFYXJjdXQoc3RhcnQsIHRyaWFuZ2xlcywgbWluWCwgbWluWSwgaW52U2l6ZSkge1xuICAgIC8vIGxvb2sgZm9yIGEgdmFsaWQgZGlhZ29uYWwgdGhhdCBkaXZpZGVzIHRoZSBwb2x5Z29uIGludG8gdHdvXG4gICAgbGV0IGEgPSBzdGFydDtcbiAgICBkbyB7XG4gICAgICAgIGxldCBiID0gYS5uZXh0Lm5leHQ7XG4gICAgICAgIHdoaWxlIChiICE9PSBhLnByZXYpIHtcbiAgICAgICAgICAgIGlmIChhLmkgIT09IGIuaSAmJiBpc1ZhbGlkRGlhZ29uYWwoYSwgYikpIHtcbiAgICAgICAgICAgICAgICAvLyBzcGxpdCB0aGUgcG9seWdvbiBpbiB0d28gYnkgdGhlIGRpYWdvbmFsXG4gICAgICAgICAgICAgICAgbGV0IGMgPSBzcGxpdFBvbHlnb24oYSwgYik7XG5cbiAgICAgICAgICAgICAgICAvLyBmaWx0ZXIgY29saW5lYXIgcG9pbnRzIGFyb3VuZCB0aGUgY3V0c1xuICAgICAgICAgICAgICAgIGEgPSBmaWx0ZXJQb2ludHMoYSwgYS5uZXh0KTtcbiAgICAgICAgICAgICAgICBjID0gZmlsdGVyUG9pbnRzKGMsIGMubmV4dCk7XG5cbiAgICAgICAgICAgICAgICAvLyBydW4gZWFyY3V0IG9uIGVhY2ggaGFsZlxuICAgICAgICAgICAgICAgIGVhcmN1dExpbmtlZChhLCB0cmlhbmdsZXMsIG1pblgsIG1pblksIGludlNpemUpO1xuICAgICAgICAgICAgICAgIGVhcmN1dExpbmtlZChjLCB0cmlhbmdsZXMsIG1pblgsIG1pblksIGludlNpemUpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGIgPSBiLm5leHQ7XG4gICAgICAgIH1cbiAgICAgICAgYSA9IGEubmV4dDtcbiAgICB9IHdoaWxlIChhICE9PSBzdGFydCk7XG59XG5cbi8vIHRydWUgb25seSB3aGlsZSBlbGltaW5hdGVIb2xlcyBtZXJnZXMgaG9sZXMsIHNvIHJlbW92ZU5vZGUga2VlcHMgdGhlIGJsb2NrIGluZGV4IGxpdmUgKGdyb3dCbG9jaylcbmxldCBpbmRleEFjdGl2ZSA9IGZhbHNlO1xuXG4vLyBsaW5rIGV2ZXJ5IGhvbGUgaW50byB0aGUgb3V0ZXIgbG9vcCwgcHJvZHVjaW5nIGEgc2luZ2xlLXJpbmcgcG9seWdvbiB3aXRob3V0IGhvbGVzXG4vKiogQHBhcmFtIHtBcnJheUxpa2U8bnVtYmVyPn0gZGF0YSBAcGFyYW0ge0FycmF5TGlrZTxudW1iZXI+fSBob2xlSW5kaWNlcyBAcGFyYW0ge05vZGV9IG91dGVyTm9kZSBAcGFyYW0ge251bWJlcn0gZGltIEByZXR1cm5zIHtOb2RlfSAqL1xuZnVuY3Rpb24gZWxpbWluYXRlSG9sZXMoZGF0YSwgaG9sZUluZGljZXMsIG91dGVyTm9kZSwgZGltKSB7XG4gICAgY29uc3QgcXVldWUgPSBbXTtcblxuICAgIGZvciAobGV0IGkgPSAwLCBsZW4gPSBob2xlSW5kaWNlcy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICBjb25zdCBzdGFydCA9IGhvbGVJbmRpY2VzW2ldICogZGltO1xuICAgICAgICBjb25zdCBlbmQgPSBpIDwgbGVuIC0gMSA/IGhvbGVJbmRpY2VzW2kgKyAxXSAqIGRpbSA6IGRhdGEubGVuZ3RoO1xuICAgICAgICBjb25zdCBsaXN0ID0gLyoqIEB0eXBlIHtOb2RlfSAqLyAobGlua2VkTGlzdChkYXRhLCBzdGFydCwgZW5kLCBkaW0sIGZhbHNlKSk7XG4gICAgICAgIGlmIChsaXN0ID09PSBsaXN0Lm5leHQpIHN0ZWluZXJzLmFkZChsaXN0KTtcbiAgICAgICAgcXVldWUucHVzaChnZXRMZWZ0bW9zdChsaXN0KSk7XG4gICAgfVxuXG4gICAgcXVldWUuc29ydChjb21wYXJlWFlTbG9wZSk7XG5cbiAgICAvLyBibG9jay1iYm94IGluZGV4IGZvciBmaW5kSG9sZUJyaWRnZSwgZ3Jvd24gYXBwZW5kLW9ubHkgYXMgaG9sZXMgbWVyZ2UgKHNlZSBub3Rlc1xuICAgIC8vIGFib3ZlIGJ1aWxkQmxvY2tJbmRleCkuIFNlZWQgaXQgd2l0aCB0aGUgb3V0ZXIgcmluZywgdGhlbiBhcHBlbmQgZWFjaCBtZXJnZWQgaG9sZS5cbiAgICBidWlsZEJsb2NrSW5kZXgoZGF0YS5sZW5ndGggLyBkaW0sIGhvbGVJbmRpY2VzLmxlbmd0aCk7XG4gICAgaW5kZXhTZWdtZW50KG91dGVyTm9kZSwgb3V0ZXJOb2RlKTtcblxuICAgIC8vIHByb2Nlc3MgaG9sZXMgZnJvbSBsZWZ0IHRvIHJpZ2h0OyBpbmRleEFjdGl2ZSBsZXRzIHJlbW92ZU5vZGUga2VlcCBibG9jayBiYm94ZXMgbGl2ZSBhc1xuICAgIC8vIGZpbHRlclBvaW50cyBoZWFscyBlZGdlcyBkdXJpbmcgbWVyZ2VzIChzZWUgZ3Jvd0Jsb2NrKVxuICAgIGluZGV4QWN0aXZlID0gdHJ1ZTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHF1ZXVlLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIG91dGVyTm9kZSA9IGVsaW1pbmF0ZUhvbGUocXVldWVbaV0sIG91dGVyTm9kZSk7XG4gICAgfVxuICAgIGluZGV4QWN0aXZlID0gZmFsc2U7XG5cbiAgICAvLyBjb2xsYXBzZSBjb2xsaW5lYXIvY29pbmNpZGVudCBwb2ludHMgYWNyb3NzIHRoZSB3aG9sZSBtZXJnZWQgcmluZyBvbmNlIGJlZm9yZSBjbGlwcGluZ1xuICAgIHJldHVybiBmaWx0ZXJQb2ludHMob3V0ZXJOb2RlKTtcbn1cblxuLyoqIEBwYXJhbSB7Tm9kZX0gYSBAcGFyYW0ge05vZGV9IGIgQHJldHVybnMge251bWJlcn0gKi9cbmZ1bmN0aW9uIGNvbXBhcmVYWVNsb3BlKGEsIGIpIHtcbiAgICAvLyB3aGVuIHRoZSBsZWZ0LW1vc3QgcG9pbnQgb2YgMiBob2xlcyBtZWV0IGF0IGEgdmVydGV4LCBzb3J0IHRoZSBob2xlcyBjb3VudGVyY2xvY2t3aXNlIHNvIHRoYXQgd2hlbiB3ZSBmaW5kXG4gICAgLy8gdGhlIGJyaWRnZSB0byB0aGUgb3V0ZXIgc2hlbGwgaXMgYWx3YXlzIHRoZSBwb2ludCB0aGF0IHRoZXkgbWVldCBhdC5cbiAgICByZXR1cm4gYS54IC0gYi54IHx8IGEueSAtIGIueSB8fFxuICAgICAgICAoYS5uZXh0LnkgLSBhLnkpIC8gKGEubmV4dC54IC0gYS54KSAtXG4gICAgICAgIChiLm5leHQueSAtIGIueSkgLyAoYi5uZXh0LnggLSBiLngpO1xufVxuXG4vLyBmaW5kIGEgYnJpZGdlIGJldHdlZW4gdmVydGljZXMgdGhhdCBjb25uZWN0cyBob2xlIHdpdGggYW4gb3V0ZXIgcmluZyBhbmQgbGluayBpdFxuLyoqIEBwYXJhbSB7Tm9kZX0gaG9sZSBAcGFyYW0ge05vZGV9IG91dGVyTm9kZSBAcmV0dXJucyB7Tm9kZX0gKi9cbmZ1bmN0aW9uIGVsaW1pbmF0ZUhvbGUoaG9sZSwgb3V0ZXJOb2RlKSB7XG4gICAgY29uc3QgYnJpZGdlID0gZmluZEhvbGVCcmlkZ2UoaG9sZSwgb3V0ZXJOb2RlKTtcbiAgICBpZiAoIWJyaWRnZSkge1xuICAgICAgICByZXR1cm4gb3V0ZXJOb2RlO1xuICAgIH1cblxuICAgIGNvbnN0IGJyaWRnZVJldmVyc2UgPSBzcGxpdFBvbHlnb24oYnJpZGdlLCBob2xlKTtcblxuICAgIC8vIGluZGV4IHRoZSBtZXJnZWQtaW4gc2VnbWVudCBiZWZvcmUgZmlsdGVyaW5nOiBpbiByaW5nIG9yZGVyIHRoZSBzcGxpY2UgcnVuc1xuICAgIC8vIGJyaWRnZSAtPiBob2xlIC0+IGJyaWRnZVJldmVyc2UgLT4gYnJpZGdlMiAtPiAoYnJpZGdlJ3Mgb2xkIG5leHQpLCBjb3ZlcmluZyB0aGVcbiAgICAvLyBob2xlJ3MgZWRnZXMgYW5kIGJvdGggbmV3IHNsaXQgZWRnZXMuIGZpbHRlclBvaW50cyBiZWxvdyBvbmx5IGRyb3BzIGNvbGxpbmVhciAvXG4gICAgLy8gY29pbmNpZGVudCBwb2ludHMsIHNvIHRoZXNlIGJib3hlcyBzdGF5IHZhbGlkIChjb25zZXJ2YXRpdmUpIHN1cGVyc2V0cy5cbiAgICBjb25zdCBicmlkZ2UyID0gYnJpZGdlUmV2ZXJzZS5uZXh0O1xuICAgIGluZGV4U2VnbWVudChicmlkZ2UsIGJyaWRnZTIubmV4dCk7XG5cbiAgICAvLyBoZWFsIGNvbGxpbmVhci9jb2luY2lkZW50IHBvaW50cyBhcm91bmQgdGhlIHR3byBuZXcgc2xpdCBlZGdlc1xuICAgIGZpbHRlclBvaW50cyhicmlkZ2VSZXZlcnNlLCBicmlkZ2VSZXZlcnNlLm5leHQpO1xuICAgIHJldHVybiBmaWx0ZXJQb2ludHMoYnJpZGdlLCBicmlkZ2UubmV4dCk7XG59XG5cbi8vIEJsb2NrLWJib3ggaW5kZXggZm9yIGZpbmRIb2xlQnJpZGdlIChpc3N1ZSAjMTgzKTogb25lIFttaW5YLG1pblksbWF4WCxtYXhZXSBiYm94IHBlciBLXG4vLyBjb25zZWN1dGl2ZSByaW5nIGVkZ2VzLCBpbiBhIGZsYXQgRmxvYXQ2NEFycmF5LCBzbyB0aGUgbGVmdHdhcmQtcmF5IHNjYW4gY2FuIHNraXAgd2hvbGVcbi8vIGJsb2NrcyBpbiBPKDEpIGluc3RlYWQgb2Ygd2Fsa2luZyB0aGUgZW50aXJlIG1lcmdlZCByaW5nLiBHcm93biBhcHBlbmQtb25seSDigJQgdGhlIG91dGVyXG4vLyByaW5nIHNlZWRzIGl0LCB0aGVuIGVhY2ggbWVyZ2VkIGhvbGUgYXBwZW5kcyBhIHNlZ21lbnQgKGhlYWQgbm9kZSwgc3RvcCBub2RlLCBLLWJsb2Nrc1xuLy8gb3ZlciBoZWFkLi5zdG9wKTsgaW5kZXBlbmRlbnQgc2VnbWVudHMsIG5vdCBhIHJpbmcgdGlsaW5nLCBzaW5jZSBzcGxpY2VzIGxhbmQgbWlkLXJpbmcuXG4vLyBCdWZmZXJzIGFyZSBzaXplZCBvbmNlIGZyb20gdGhlIGlucHV0IHVwcGVyIGJvdW5kIGFuZCByZXVzZWQgYWNyb3NzIGNhbGxzLlxuLy9cbi8vIGZpbHRlclBvaW50cyBvbmx5IGRyb3BzIGNvbGxpbmVhci9jb2luY2lkZW50IHBvaW50cywgc28gYSBzdGFsZSBiYm94IHN0YXlzIGEgY29uc2VydmF0aXZlXG4vLyBzdXBlcnNldCBvZiBpdHMgbGl2ZSBlZGdlcyAobmV2ZXIgYSBmYWxzZSBza2lwKTsgdGhlIHNjYW4gc2tpcHMgZGVhZCBub2RlcyAocC5wcmV2Lm5leHQgIT09XG4vLyBwKSBhbmQgbGF6aWx5IGFkdmFuY2VzIGEgZGVhZCBzdG9wLiBCbG9ja3MgYXJlIHNjYW5uZWQgaW4gYXBwZW5kIChub3QgcmluZykgb3JkZXIsIHNvIHRoZVxuLy8gY2hvc2VuIGJyaWRnZSBjYW4gZGlmZmVyIGZyb20gdGhlIHVuLWluZGV4ZWQgY29kZSDigJQgYSBkaWZmZXJlbnQgYnV0IGVxdWFsbHkgdmFsaWQgcmVzdWx0LlxuY29uc3QgSyA9IDE2OyAvLyBlZGdlcyBwZXIgYmxvY2tcblxubGV0IGJsb2NrQkJveCA9IG5ldyBGbG9hdDY0QXJyYXkoMCk7IC8vIFttaW5YLG1pblksbWF4WCxtYXhZXSBwZXIgYmxvY2tcbmxldCBudW1CbG9ja3MgPSAwO1xuLyoqIEB0eXBlIHtOb2RlW119ICovXG5jb25zdCBibG9ja0hlYWQgPSBbXTsgLy8gZmlyc3Qgbm9kZSBvZiBlYWNoIGJsb2NrJ3Mgc2VnbWVudFxuLyoqIEB0eXBlIHtOb2RlW119ICovXG5jb25zdCBibG9ja1N0b3AgPSBbXTsgLy8gbm9kZSBqdXN0IHBhc3QgZWFjaCBibG9jaydzIHNlZ21lbnQgKGV4Y2x1c2l2ZSB3YWxrIGJvdW5kKVxuXG4vKiogQHBhcmFtIHtudW1iZXJ9IG1heE5vZGVzIEBwYXJhbSB7bnVtYmVyfSBudW1Ib2xlcyAqL1xuZnVuY3Rpb24gYnVpbGRCbG9ja0luZGV4KG1heE5vZGVzLCBudW1Ib2xlcykge1xuICAgIC8vIHVwcGVyIGJvdW5kOiBldmVyeSBpbnB1dCBub2RlIGluZGV4ZWQgb25jZSwgKzIgYnJpZGdlIG5vZGVzIHBlciBob2xlLCBwbHVzIGEgcGFydGlhbFxuICAgIC8vIHRyYWlsaW5nIGJsb2NrIHBlciBhcHBlbmRlZCBzZWdtZW50IChvdXRlciByaW5nICsgb25lIHBlciBob2xlKVxuICAgIGNvbnN0IG1heEJsb2NrcyA9IE1hdGguY2VpbCgobWF4Tm9kZXMgKyAyICogbnVtSG9sZXMpIC8gSykgKyBudW1Ib2xlcyArIDI7XG4gICAgaWYgKGJsb2NrQkJveC5sZW5ndGggPCBtYXhCbG9ja3MgKiA0KSBibG9ja0JCb3ggPSBuZXcgRmxvYXQ2NEFycmF5KG1heEJsb2NrcyAqIDQpO1xuICAgIG51bUJsb2NrcyA9IDA7XG59XG5cbi8vIGluZGV4IHRoZSByaW5nIHJ1biBoZWFkLi5zdG9wIChleGNsdXNpdmUpIGFzIGNlaWwobGVuIC8gSykgYmxvY2tzOyBoZWFkID09PSBzdG9wIG1lYW5zXG4vLyB0aGUgd2hvbGUgcmluZy4gZWFjaCBibG9jaydzIGJib3ggY292ZXJzIGJvdGggZW5kcG9pbnRzIG9mIGV2ZXJ5IGVkZ2UgaXQgb3ducy5cbi8qKiBAcGFyYW0ge05vZGV9IGhlYWQgQHBhcmFtIHtOb2RlfSBzdG9wICovXG5mdW5jdGlvbiBpbmRleFNlZ21lbnQoaGVhZCwgc3RvcCkge1xuICAgIGxldCBwID0gaGVhZDtcbiAgICBkbyB7XG4gICAgICAgIGNvbnN0IGIgPSBudW1CbG9ja3MrKztcbiAgICAgICAgYmxvY2tIZWFkW2JdID0gcDtcbiAgICAgICAgbGV0IG1pblggPSBwLngsIG1pblkgPSBwLnksIG1heFggPSBwLngsIG1heFkgPSBwLnk7XG4gICAgICAgIGxldCBrID0gMDtcbiAgICAgICAgZG8ge1xuICAgICAgICAgICAgY29uc3QgYyA9IHAubmV4dDsgLy8gZWRnZSBwLT5jOyBiYm94IG11c3QgYm91bmQgYm90aCBlbmRwb2ludHNcbiAgICAgICAgICAgIHAueiA9IGI7IC8vIHJldXNlIHogYXMgdGhlIG93bmluZyBibG9jayBkdXJpbmcgZWxpbWluYXRlSG9sZXMgKHNlZSBncm93QmxvY2spXG4gICAgICAgICAgICBpZiAoYy54IDwgbWluWCkgbWluWCA9IGMueDsgaWYgKGMueCA+IG1heFgpIG1heFggPSBjLng7XG4gICAgICAgICAgICBpZiAoYy55IDwgbWluWSkgbWluWSA9IGMueTsgaWYgKGMueSA+IG1heFkpIG1heFkgPSBjLnk7XG4gICAgICAgICAgICBwID0gYztcbiAgICAgICAgfSB3aGlsZSAoKytrIDwgSyAmJiBwICE9PSBzdG9wKTtcbiAgICAgICAgYmxvY2tTdG9wW2JdID0gcDtcbiAgICAgICAgY29uc3QgZyA9IGIgKiA0O1xuICAgICAgICBibG9ja0JCb3hbZ10gPSBtaW5YOyBibG9ja0JCb3hbZyArIDFdID0gbWluWTsgYmxvY2tCQm94W2cgKyAyXSA9IG1heFg7IGJsb2NrQkJveFtnICsgM10gPSBtYXhZO1xuICAgIH0gd2hpbGUgKHAgIT09IHN0b3ApO1xufVxuXG4vLyB3aGVuIGZpbHRlclBvaW50cyBoZWFscyBhbiBlZGdlIGhlYWQtPnRhaWwgKHJlbW92aW5nIHRoZSBjb2xsaW5lYXIgbm9kZSBiZXR3ZWVuIHRoZW0pLCB0aGVcbi8vIGhlYWxlZCBlZGdlIGNhbiBleHRlbmQgcGFzdCBoZWFkJ3MgZnJvemVuIGJsb2NrIGJib3ggaWYgaXRzIG9sZCBmYXIgZW5kcG9pbnQgbGl2ZWQgaW4gYW5vdGhlclxuLy8gYmxvY2s7IGdyb3cgaGVhZCdzIGJsb2NrIGJib3ggdG8gY292ZXIgdGFpbCBzbyB0aGUgbGVmdHdhcmQtcmF5IHBydW5lIGNhbid0IGZhbHNlLXNraXAgaXQuXG4vKiogQHBhcmFtIHtOb2RlfSBoZWFkIEBwYXJhbSB7Tm9kZX0gdGFpbCAqL1xuZnVuY3Rpb24gZ3Jvd0Jsb2NrKGhlYWQsIHRhaWwpIHtcbiAgICBjb25zdCBnID0gaGVhZC56ICogNDtcbiAgICBpZiAodGFpbC54IDwgYmxvY2tCQm94W2ddKSBibG9ja0JCb3hbZ10gPSB0YWlsLng7XG4gICAgaWYgKHRhaWwueSA8IGJsb2NrQkJveFtnICsgMV0pIGJsb2NrQkJveFtnICsgMV0gPSB0YWlsLnk7XG4gICAgaWYgKHRhaWwueCA+IGJsb2NrQkJveFtnICsgMl0pIGJsb2NrQkJveFtnICsgMl0gPSB0YWlsLng7XG4gICAgaWYgKHRhaWwueSA+IGJsb2NrQkJveFtnICsgM10pIGJsb2NrQkJveFtnICsgM10gPSB0YWlsLnk7XG59XG5cbi8qKiBAcGFyYW0ge251bWJlcn0gYiBAcmV0dXJucyB7Tm9kZX0gKi9cbmZ1bmN0aW9uIGxpdmVCbG9ja1N0b3AoYikge1xuICAgIGxldCBzdG9wID0gYmxvY2tTdG9wW2JdO1xuICAgIHdoaWxlIChzdG9wLnByZXYubmV4dCAhPT0gc3RvcCkgc3RvcCA9IHN0b3AubmV4dDtcbiAgICBibG9ja1N0b3BbYl0gPSBzdG9wO1xuICAgIHJldHVybiBzdG9wO1xufVxuXG4vLyB0aGUgYmxvY2sncyBoZWFkIG5vZGUgY2FuIGJlIHJlbW92ZWQgYnkgZmlsdGVyUG9pbnRzIGR1cmluZyBtZXJnZXM7IGFkdmFuY2UgaXQgdG8gdGhlIG5leHRcbi8vIGxpdmUgbm9kZSBzbyB0aGUgd2FsayBkb2Vzbid0IHN0YXJ0IG9uIChhbmQgaW1tZWRpYXRlbHkgdGVybWluYXRlIGF0KSBhIGRlYWQgbm9kZS4gRm9yIHRoZVxuLy8gc2luZ2xlIGZ1bGwtcmluZyBzZWVkIGJsb2NrIChoZWFkID09PSBzdG9wKSB0aGUgc2FtZSBmb3J3YXJkIGFkdmFuY2Uga2VlcHMgdGhlbSBlcXVhbCwgc28gdGhlXG4vLyBkby13aGlsZSBzdGlsbCBsYXBzIHRoZSB3aG9sZSByaW5nIGluc3RlYWQgb2YgY29sbGFwc2luZyB0byBhbiBlbXB0eSB3YWxrLlxuLyoqIEBwYXJhbSB7bnVtYmVyfSBiIEByZXR1cm5zIHtOb2RlfSAqL1xuZnVuY3Rpb24gbGl2ZUJsb2NrSGVhZChiKSB7XG4gICAgbGV0IGhlYWQgPSBibG9ja0hlYWRbYl07XG4gICAgd2hpbGUgKGhlYWQucHJldi5uZXh0ICE9PSBoZWFkKSBoZWFkID0gaGVhZC5uZXh0O1xuICAgIGJsb2NrSGVhZFtiXSA9IGhlYWQ7XG4gICAgcmV0dXJuIGhlYWQ7XG59XG5cbi8vIERhdmlkIEViZXJseSdzIGFsZ29yaXRobSBmb3IgZmluZGluZyBhIGJyaWRnZSBiZXR3ZWVuIGhvbGUgYW5kIG91dGVyIHBvbHlnb25cbi8qKiBAcGFyYW0ge05vZGV9IGhvbGUgQHBhcmFtIHtOb2RlfSBvdXRlck5vZGUgQHJldHVybnMge05vZGUgfCBudWxsfSAqL1xuZnVuY3Rpb24gZmluZEhvbGVCcmlkZ2UoaG9sZSwgb3V0ZXJOb2RlKSB7XG4gICAgbGV0IHAgPSBvdXRlck5vZGU7XG4gICAgY29uc3QgaHggPSBob2xlLng7XG4gICAgY29uc3QgaHkgPSBob2xlLnk7XG4gICAgbGV0IHF4ID0gLUluZmluaXR5O1xuICAgIC8qKiBAdHlwZSB7Tm9kZSB8IHVuZGVmaW5lZH0gKi9cbiAgICBsZXQgbTtcblxuICAgIC8vIGZpbmQgYSBzZWdtZW50IGludGVyc2VjdGVkIGJ5IGEgcmF5IGZyb20gdGhlIGhvbGUncyBsZWZ0bW9zdCBwb2ludCB0byB0aGUgbGVmdDtcbiAgICAvLyBzZWdtZW50J3MgZW5kcG9pbnQgd2l0aCBsZXNzZXIgeCB3aWxsIGJlIHBvdGVudGlhbCBjb25uZWN0aW9uIHBvaW50XG4gICAgLy8gdW5sZXNzIHRoZXkgaW50ZXJzZWN0IGF0IGEgdmVydGV4LCB0aGVuIGNob29zZSB0aGUgdmVydGV4XG4gICAgaWYgKGVxdWFscyhob2xlLCBwKSkgcmV0dXJuIHA7XG5cbiAgICAvLyBzY2FuIGJsb2Nrczsgc2tpcCBhbnkgd2hvc2UgYmJveCBjYW4ndCBob2xkIGEgY3Jvc3NpbmcgdGhhdCBiZWF0cyBxeCBhbmQgbGllcyBsZWZ0XG4gICAgLy8gb2YgaHggKHRoZSBwcnVuZSBNb3J0b24gb3JkZXIgY2FuJ3QgZXhwcmVzcyDigJQgZXhwbGljaXQgcGVyLWF4aXMgW21pblksbWF4WV0vW21pblgsbWF4WF0pXG4gICAgZm9yIChsZXQgYiA9IDAsIGcgPSAwOyBiIDwgbnVtQmxvY2tzOyBiKyssIGcgKz0gNCkge1xuICAgICAgICBpZiAoaHkgPCBibG9ja0JCb3hbZyArIDFdIHx8IGh5ID4gYmxvY2tCQm94W2cgKyAzXSB8fCBibG9ja0JCb3hbZ10gPiBoeCB8fCBibG9ja0JCb3hbZyArIDJdIDw9IHF4KSBjb250aW51ZTtcblxuICAgICAgICAvLyBlbnN1cmUgdGhlIHdhbGsncyBleGNsdXNpdmUgYm91bmQgaXMgbGl2ZSBzbyB3ZSBkb24ndCBvdmVycnVuIGludG8gb3RoZXIgYmxvY2tzXG4gICAgICAgIGNvbnN0IHN0b3AgPSBsaXZlQmxvY2tTdG9wKGIpO1xuXG4gICAgICAgIHAgPSBsaXZlQmxvY2tIZWFkKGIpO1xuICAgICAgICBkbyB7XG4gICAgICAgICAgICBpZiAocC5wcmV2Lm5leHQgPT09IHApIHsgLy8gc2tpcCBub2RlcyByZW1vdmVkIGJ5IGZpbHRlclBvaW50cyAoc3RhbGUgaW4gdGhlIGluZGV4KVxuICAgICAgICAgICAgICAgIGlmIChlcXVhbHMoaG9sZSwgcC5uZXh0KSkgcmV0dXJuIHAubmV4dDtcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChoeSA8PSBwLnkgJiYgaHkgPj0gcC5uZXh0LnkgJiYgcC5uZXh0LnkgIT09IHAueSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB4ID0gcC54ICsgKGh5IC0gcC55KSAqIChwLm5leHQueCAtIHAueCkgLyAocC5uZXh0LnkgLSBwLnkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoeCA8PSBoeCAmJiB4ID4gcXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHF4ID0geDtcbiAgICAgICAgICAgICAgICAgICAgICAgIG0gPSBwLnggPCBwLm5leHQueCA/IHAgOiBwLm5leHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoeCA9PT0gaHgpIHJldHVybiBtOyAvLyBob2xlIHRvdWNoZXMgb3V0ZXIgc2VnbWVudDsgcGljayBsZWZ0bW9zdCBlbmRwb2ludFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcCA9IHAubmV4dDtcbiAgICAgICAgfSB3aGlsZSAocCAhPT0gc3RvcCk7XG4gICAgfVxuXG4gICAgaWYgKCFtKSByZXR1cm4gbnVsbDtcblxuICAgIC8vIGxvb2sgZm9yIHBvaW50cyBpbnNpZGUgdGhlIHRyaWFuZ2xlIG9mIGhvbGUgcG9pbnQsIHNlZ21lbnQgaW50ZXJzZWN0aW9uIGFuZCBlbmRwb2ludDtcbiAgICAvLyBpZiB0aGVyZSBhcmUgbm8gcG9pbnRzIGZvdW5kLCB3ZSBoYXZlIGEgdmFsaWQgY29ubmVjdGlvbjtcbiAgICAvLyBvdGhlcndpc2UgY2hvb3NlIHRoZSBwb2ludCBvZiB0aGUgbWluaW11bSBhbmdsZSB3aXRoIHRoZSByYXkgYXMgY29ubmVjdGlvbiBwb2ludFxuXG4gICAgY29uc3QgbXggPSBtLng7XG4gICAgY29uc3QgbXkgPSBtLnk7XG4gICAgY29uc3QgdG1pblkgPSBNYXRoLm1pbihoeSwgbXkpOyAvLyB0aGUgdHJpYW5nbGUncyB5IHNwYW47IHggc3BhbiBpcyBbbXgsIGh4XVxuICAgIGNvbnN0IHRtYXhZID0gTWF0aC5tYXgoaHksIG15KTtcbiAgICBsZXQgdGFuTWluID0gSW5maW5pdHk7XG5cbiAgICAvLyBzY2FuIHRoZSBzYW1lIGJsb2Nrczsgc2tpcCBhbnkgd2hvc2UgYmJveCBjYW4ndCBvdmVybGFwIHRoZSB0cmlhbmdsZSdzIFtteCxoeF3Dl1t0bWluWSx0bWF4WV0gYm94XG4gICAgZm9yIChsZXQgYiA9IDAsIGcgPSAwOyBiIDwgbnVtQmxvY2tzOyBiKyssIGcgKz0gNCkge1xuICAgICAgICBpZiAoYmxvY2tCQm94W2cgKyAyXSA8IG14IHx8IGJsb2NrQkJveFtnXSA+IGh4IHx8IGJsb2NrQkJveFtnICsgM10gPCB0bWluWSB8fCBibG9ja0JCb3hbZyArIDFdID4gdG1heFkpIGNvbnRpbnVlO1xuXG4gICAgICAgIGNvbnN0IHN0b3AgPSBsaXZlQmxvY2tTdG9wKGIpO1xuXG4gICAgICAgIHAgPSBsaXZlQmxvY2tIZWFkKGIpO1xuICAgICAgICBkbyB7XG4gICAgICAgICAgICBpZiAocC5wcmV2Lm5leHQgPT09IHAgJiYgaHggPj0gcC54ICYmIHAueCA+PSBteCAmJiBoeCAhPT0gcC54ICYmIC8vIHNraXAgZGVhZCBub2Rlc1xuICAgICAgICAgICAgICAgICAgICBwb2ludEluVHJpYW5nbGUoaHkgPCBteSA/IGh4IDogcXgsIGh5LCBteCwgbXksIGh5IDwgbXkgPyBxeCA6IGh4LCBoeSwgcC54LCBwLnkpKSB7XG5cbiAgICAgICAgICAgICAgICBjb25zdCB0YW4gPSBNYXRoLmFicyhoeSAtIHAueSkgLyAoaHggLSBwLngpOyAvLyB0YW5nZW50aWFsXG5cbiAgICAgICAgICAgICAgICAvLyBpZiBob2xlIHBvaW50IHNpdHMgb24gcCdzIGhvcml6b250YWwgZWRnZSAoVC1qdW5jdGlvbiB0b3VjaCk6IHRoZSBicmlkZ2UgcnVuc1xuICAgICAgICAgICAgICAgIC8vIGFsb25nIHRoYXQgZWRnZSDigJQgbG9jYWxseUluc2lkZSByZWplY3RzIGl0IGFzIGNvbGxpbmVhciwgYnV0IGl0J3MgdmFsaWRcbiAgICAgICAgICAgICAgICBpZiAoKGxvY2FsbHlJbnNpZGUocCwgaG9sZSkgfHwgKHAueSA9PT0gaHkgJiYgcC5uZXh0LnkgPT09IGh5ICYmIHAubmV4dC54ID4gaHgpKSAmJlxuICAgICAgICAgICAgICAgICAgICAodGFuIDwgdGFuTWluIHx8ICh0YW4gPT09IHRhbk1pbiAmJiAocC54ID4gbS54IHx8IChwLnggPT09IG0ueCAmJiBzZWN0b3JDb250YWluc1NlY3RvcihtLCBwKSkpKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgbSA9IHA7XG4gICAgICAgICAgICAgICAgICAgIHRhbk1pbiA9IHRhbjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHAgPSBwLm5leHQ7XG4gICAgICAgIH0gd2hpbGUgKHAgIT09IHN0b3ApO1xuICAgIH1cblxuICAgIHJldHVybiBtO1xufVxuXG4vLyB3aGV0aGVyIHNlY3RvciBpbiB2ZXJ0ZXggbSBjb250YWlucyBzZWN0b3IgaW4gdmVydGV4IHAgaW4gdGhlIHNhbWUgY29vcmRpbmF0ZXNcbi8qKiBAcGFyYW0ge05vZGV9IG0gQHBhcmFtIHtOb2RlfSBwIEByZXR1cm5zIHtib29sZWFufSAqL1xuZnVuY3Rpb24gc2VjdG9yQ29udGFpbnNTZWN0b3IobSwgcCkge1xuICAgIHJldHVybiBhcmVhKG0ucHJldiwgbSwgcC5wcmV2KSA8IDAgJiYgYXJlYShwLm5leHQsIG0sIG0ubmV4dCkgPCAwO1xufVxuXG4vLyBzY3JhdGNoIGJ1ZmZlcnMgcmV1c2VkIGFjcm9zcyBjYWxscyBhbmQgZ3Jvd24gb24gZGVtYW5kOiB0d28gbm9kZS1yZWYgYXJyYXlzIHRoYXRcbi8vIHBpbmctcG9uZyBkdXJpbmcgdGhlIHJhZGl4IHBhc3NlcywgcGx1cyBwYXJhbGxlbCB6LXZhbHVlIGFycmF5cyBzbyB0aGUgcGFzc2VzIHJlYWRcbi8vIHogZnJvbSBjb250aWd1b3VzIG1lbW9yeSBpbnN0ZWFkIG9mIGRlcmVmZXJlbmNpbmcgZWFjaCBub2RlLiAyNTYtZW50cnkgaGlzdG9ncmFtIGZvclxuLy8gOC1iaXQgZGlnaXRzOyB0aGUgc21hbGwgaGlzdG9ncmFtIGtlZXBzIHBlci1jYWxsIHNldHVwIGNoZWFwIChtb3N0IHJpbmdzIGFyZSBzaG9ydClcbi8qKiBAdHlwZSB7Tm9kZVtdfSAqL1xuY29uc3Qgc29ydEFyciA9IFtdO1xuLyoqIEB0eXBlIHtOb2RlW119ICovXG5sZXQgc29ydEJ1ZiA9IFtdO1xubGV0IHpBcnIgPSBuZXcgVWludDMyQXJyYXkoMCk7XG5sZXQgekJ1ZiA9IG5ldyBVaW50MzJBcnJheSgwKTtcbmNvbnN0IGNvdW50cyA9IG5ldyBVaW50MzJBcnJheSgyNTYpO1xuXG4vLyBpbnRlcmxpbmsgcG9seWdvbiBub2RlcyBpbiB6LW9yZGVyOiBjb2xsZWN0IGludG8gYW4gYXJyYXksIHNvcnQgYnkgeiwgcmVsaW5rXG4vKiogQHBhcmFtIHtOb2RlfSBzdGFydCBAcGFyYW0ge251bWJlcn0gbWluWCBAcGFyYW0ge251bWJlcn0gbWluWSBAcGFyYW0ge251bWJlcn0gaW52U2l6ZSAqL1xuZnVuY3Rpb24gaW5kZXhDdXJ2ZShzdGFydCwgbWluWCwgbWluWSwgaW52U2l6ZSkge1xuICAgIGxldCBwID0gc3RhcnQ7XG4gICAgbGV0IG4gPSAwO1xuICAgIGRvIHtcbiAgICAgICAgLy8gYWx3YXlzIChyZSljb21wdXRlOiB6IG1heSBzdGlsbCBob2xkIGEgYmxvY2sgaW5kZXggbGVmdCBvdmVyIGZyb20gZWxpbWluYXRlSG9sZXNcbiAgICAgICAgcC56ID0gek9yZGVyKHAueCwgcC55LCBtaW5YLCBtaW5ZLCBpbnZTaXplKTtcbiAgICAgICAgc29ydEFycltuKytdID0gcDtcbiAgICAgICAgcCA9IHAubmV4dDtcbiAgICB9IHdoaWxlIChwICE9PSBzdGFydCk7XG5cbiAgICBzb3J0Tm9kZXMobik7XG5cbiAgICAvKiogQHR5cGUge05vZGUgfCBudWxsfSAqL1xuICAgIGxldCBwcmV2ID0gbnVsbDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG47IGkrKykge1xuICAgICAgICBjb25zdCBub2RlID0gc29ydEFycltpXTtcbiAgICAgICAgbm9kZS5wcmV2WiA9IHByZXY7XG4gICAgICAgIGlmIChwcmV2KSBwcmV2Lm5leHRaID0gbm9kZTtcbiAgICAgICAgcHJldiA9IG5vZGU7XG4gICAgfVxuICAgIC8qKiBAdHlwZSB7Tm9kZX0gKi8gKHByZXYpLm5leHRaID0gbnVsbDtcblxuICAgIC8vIGRyb3AgdGhlIG5vZGUgcmVmcyBidXQga2VlcCB0aGUgY2FwYWNpdHk6IHNldHRpbmcgbGVuZ3RoIHRvIDAgbGVhdmVzIHNvcnRCdWYgdW5yZXNpemVkXG4gICAgLy8gKGl0cyBncm93dGggaXMgZ2F0ZWQgb24gekFyciksIHNvIHRoZSByYWRpeCBzY2F0dGVyIHJlZ3Jvd3MgaXQgb3V0IG9mIG9yZGVyIGV2ZXJ5IGNhbGxcbiAgICBzb3J0QXJyLmZpbGwoLyoqIEB0eXBlIHtOb2RlfSAqLyAoLyoqIEB0eXBlIHt1bmtub3dufSAqLyAobnVsbCkpLCAwLCBuKTtcbiAgICBzb3J0QnVmLmZpbGwoLyoqIEB0eXBlIHtOb2RlfSAqLyAoLyoqIEB0eXBlIHt1bmtub3dufSAqLyAobnVsbCkpLCAwLCBuKTtcbn1cblxuLy8gc29ydCB0aGUgZmlyc3QgbiBub2RlcyBvZiBzb3J0QXJyIGJ5IHosIGluIHBsYWNlOiBpbnNlcnRpb24gc29ydCBmb3Igc21hbGwgbiAoY2hlYXBlclxuLy8gdGhhbiBoaXN0b2dyYW0gc2V0dXApLCBlbHNlIExTRCByYWRpeCBpbiBmb3VyIDgtYml0IHBhc3NlcyAoY292ZXJpbmcgeidzIDMwIGJpdHMpXG4vKiogQHBhcmFtIHtudW1iZXJ9IG4gKi9cbmZ1bmN0aW9uIHNvcnROb2RlcyhuKSB7XG4gICAgaWYgKG4gPD0gMzIpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IG5vZGUgPSBzb3J0QXJyW2ldLCB6ID0gbm9kZS56O1xuICAgICAgICAgICAgbGV0IGogPSBpIC0gMTtcbiAgICAgICAgICAgIHdoaWxlIChqID49IDAgJiYgc29ydEFycltqXS56ID4geikgeyBzb3J0QXJyW2ogKyAxXSA9IHNvcnRBcnJbal07IGotLTsgfVxuICAgICAgICAgICAgc29ydEFycltqICsgMV0gPSBub2RlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoekFyci5sZW5ndGggPCBuKSB7XG4gICAgICAgIHpBcnIgPSBuZXcgVWludDMyQXJyYXkobik7XG4gICAgICAgIHpCdWYgPSBuZXcgVWludDMyQXJyYXkobik7XG4gICAgICAgIHNvcnRCdWYgPSBuZXcgQXJyYXkobik7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbjsgaSsrKSB6QXJyW2ldID0gc29ydEFycltpXS56O1xuXG4gICAgLy8gZXZlbiBwYXNzIGNvdW50IGxhbmRzIHRoZSBzb3J0ZWQgcmVzdWx0IGJhY2sgaW4gc29ydEFyclxuICAgIHJhZGl4UGFzcyhuLCBzb3J0QXJyLCB6QXJyLCBzb3J0QnVmLCB6QnVmLCAwKTtcbiAgICByYWRpeFBhc3Mobiwgc29ydEJ1ZiwgekJ1Ziwgc29ydEFyciwgekFyciwgOCk7XG4gICAgcmFkaXhQYXNzKG4sIHNvcnRBcnIsIHpBcnIsIHNvcnRCdWYsIHpCdWYsIDE2KTtcbiAgICByYWRpeFBhc3Mobiwgc29ydEJ1ZiwgekJ1Ziwgc29ydEFyciwgekFyciwgMjQpO1xufVxuXG4vLyBvbmUgTFNEIHJhZGl4IHBhc3M6IHN0YWJseSBzY2F0dGVyIHRoZSBmaXJzdCBuIG5vZGVzIChhbmQgdGhlaXIgeikgZnJvbSBzcmMgdG8gZHN0LFxuLy8gYnVja2V0ZWQgYnkgdGhlIDgtYml0IGRpZ2l0IG9mIHogYXQgdGhlIGdpdmVuIGJpdCBzaGlmdFxuLyoqIEBwYXJhbSB7bnVtYmVyfSBuIEBwYXJhbSB7Tm9kZVtdfSBzcmMgQHBhcmFtIHtVaW50MzJBcnJheX0gc3JjWiBAcGFyYW0ge05vZGVbXX0gZHN0IEBwYXJhbSB7VWludDMyQXJyYXl9IGRzdFogQHBhcmFtIHtudW1iZXJ9IHNoaWZ0ICovXG5mdW5jdGlvbiByYWRpeFBhc3Mobiwgc3JjLCBzcmNaLCBkc3QsIGRzdFosIHNoaWZ0KSB7XG4gICAgY291bnRzLmZpbGwoMCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBuOyBpKyspIGNvdW50c1soc3JjWltpXSA+Pj4gc2hpZnQpICYgMHhmZl0rKztcbiAgICAvLyB0dXJuIHBlci1idWNrZXQgY291bnRzIGludG8gc3RhcnQgb2Zmc2V0cyAocHJlZml4IHN1bSlcbiAgICBsZXQgc3VtID0gMDtcbiAgICBmb3IgKGxldCBiID0gMDsgYiA8IDI1NjsgYisrKSB7IGNvbnN0IGMgPSBjb3VudHNbYl07IGNvdW50c1tiXSA9IHN1bTsgc3VtICs9IGM7IH1cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG47IGkrKykge1xuICAgICAgICBjb25zdCB6ID0gc3JjWltpXTtcbiAgICAgICAgY29uc3QgcG9zID0gY291bnRzWyh6ID4+PiBzaGlmdCkgJiAweGZmXSsrO1xuICAgICAgICBkc3RbcG9zXSA9IHNyY1tpXTtcbiAgICAgICAgZHN0Wltwb3NdID0gejtcbiAgICB9XG59XG5cbi8vIHotb3JkZXIgb2YgYSBwb2ludCBnaXZlbiBjb29yZHMgYW5kIGludmVyc2Ugb2YgdGhlIGxvbmdlciBzaWRlIG9mIGRhdGEgYmJveFxuLyoqIEBwYXJhbSB7bnVtYmVyfSB4IEBwYXJhbSB7bnVtYmVyfSB5IEBwYXJhbSB7bnVtYmVyfSBtaW5YIEBwYXJhbSB7bnVtYmVyfSBtaW5ZIEBwYXJhbSB7bnVtYmVyfSBpbnZTaXplIEByZXR1cm5zIHtudW1iZXJ9ICovXG5mdW5jdGlvbiB6T3JkZXIoeCwgeSwgbWluWCwgbWluWSwgaW52U2l6ZSkge1xuICAgIC8vIGNvb3JkcyBhcmUgdHJhbnNmb3JtZWQgaW50byBub24tbmVnYXRpdmUgMTUtYml0IGludGVnZXIgcmFuZ2VcbiAgICB4ID0gKHggLSBtaW5YKSAqIGludlNpemUgfCAwO1xuICAgIHkgPSAoeSAtIG1pblkpICogaW52U2l6ZSB8IDA7XG5cbiAgICB4ID0gKHggfCAoeCA8PCA4KSkgJiAweDAwRkYwMEZGO1xuICAgIHggPSAoeCB8ICh4IDw8IDQpKSAmIDB4MEYwRjBGMEY7XG4gICAgeCA9ICh4IHwgKHggPDwgMikpICYgMHgzMzMzMzMzMztcbiAgICB4ID0gKHggfCAoeCA8PCAxKSkgJiAweDU1NTU1NTU1O1xuXG4gICAgeSA9ICh5IHwgKHkgPDwgOCkpICYgMHgwMEZGMDBGRjtcbiAgICB5ID0gKHkgfCAoeSA8PCA0KSkgJiAweDBGMEYwRjBGO1xuICAgIHkgPSAoeSB8ICh5IDw8IDIpKSAmIDB4MzMzMzMzMzM7XG4gICAgeSA9ICh5IHwgKHkgPDwgMSkpICYgMHg1NTU1NTU1NTtcblxuICAgIHJldHVybiB4IHwgKHkgPDwgMSk7XG59XG5cbi8vIGZpbmQgdGhlIGxlZnRtb3N0IG5vZGUgb2YgYSBwb2x5Z29uIHJpbmdcbi8qKiBAcGFyYW0ge05vZGV9IHN0YXJ0IEByZXR1cm5zIHtOb2RlfSAqL1xuZnVuY3Rpb24gZ2V0TGVmdG1vc3Qoc3RhcnQpIHtcbiAgICBsZXQgcCA9IHN0YXJ0LFxuICAgICAgICBsZWZ0bW9zdCA9IHN0YXJ0O1xuICAgIGRvIHtcbiAgICAgICAgaWYgKHAueCA8IGxlZnRtb3N0LnggfHwgKHAueCA9PT0gbGVmdG1vc3QueCAmJiBwLnkgPCBsZWZ0bW9zdC55KSkgbGVmdG1vc3QgPSBwO1xuICAgICAgICBwID0gcC5uZXh0O1xuICAgIH0gd2hpbGUgKHAgIT09IHN0YXJ0KTtcblxuICAgIHJldHVybiBsZWZ0bW9zdDtcbn1cblxuLy8gY2hlY2sgaWYgYSBwb2ludCBsaWVzIHdpdGhpbiBhIGNvbnZleCB0cmlhbmdsZVxuLyoqIEBwYXJhbSB7bnVtYmVyfSBheCBAcGFyYW0ge251bWJlcn0gYXkgQHBhcmFtIHtudW1iZXJ9IGJ4IEBwYXJhbSB7bnVtYmVyfSBieSBAcGFyYW0ge251bWJlcn0gY3ggQHBhcmFtIHtudW1iZXJ9IGN5IEBwYXJhbSB7bnVtYmVyfSBweCBAcGFyYW0ge251bWJlcn0gcHkgQHJldHVybnMge2Jvb2xlYW59ICovXG5mdW5jdGlvbiBwb2ludEluVHJpYW5nbGUoYXgsIGF5LCBieCwgYnksIGN4LCBjeSwgcHgsIHB5KSB7XG4gICAgcmV0dXJuIChjeCAtIHB4KSAqIChheSAtIHB5KSA+PSAoYXggLSBweCkgKiAoY3kgLSBweSkgJiZcbiAgICAgICAgICAgKGF4IC0gcHgpICogKGJ5IC0gcHkpID49IChieCAtIHB4KSAqIChheSAtIHB5KSAmJlxuICAgICAgICAgICAoYnggLSBweCkgKiAoY3kgLSBweSkgPj0gKGN4IC0gcHgpICogKGJ5IC0gcHkpO1xufVxuXG4vLyBjaGVjayBpZiBhIGRpYWdvbmFsIGJldHdlZW4gdHdvIHBvbHlnb24gbm9kZXMgaXMgdmFsaWQgKGxpZXMgaW4gcG9seWdvbiBpbnRlcmlvcilcbi8qKiBAcGFyYW0ge05vZGV9IGEgQHBhcmFtIHtOb2RlfSBiIEByZXR1cm5zIHtib29sZWFufSB0cnVlIHdoZW4gdGhlIGRpYWdvbmFsIGlzIHZhbGlkICovXG5mdW5jdGlvbiBpc1ZhbGlkRGlhZ29uYWwoYSwgYikge1xuICAgIGNvbnN0IHplcm9MZW5ndGggPSBlcXVhbHMoYSwgYikgJiYgYXJlYShhLnByZXYsIGEsIGEubmV4dCkgPiAwICYmIGFyZWEoYi5wcmV2LCBiLCBiLm5leHQpID4gMDsgLy8gZGVnZW5lcmF0ZSBjYXNlXG4gICAgcmV0dXJuIGEubmV4dC5pICE9PSBiLmkgJiYgKHplcm9MZW5ndGggfHwgbG9jYWxseUluc2lkZShhLCBiKSAmJiBsb2NhbGx5SW5zaWRlKGIsIGEpICYmIC8vIC8vIGxvY2FsbHkgdmlzaWJsZVxuICAgICAgICAoYXJlYShhLnByZXYsIGEsIGIucHJldikgIT09IDAgfHwgYXJlYShhLCBiLnByZXYsIGIpICE9PSAwKSkgJiYgLy8gbm8gb3Bwb3NpdGUtZmFjaW5nIHNlY3RvcnNcbiAgICAgICAgIWludGVyc2VjdHNQb2x5Z29uKGEsIGIpICYmICh6ZXJvTGVuZ3RoIHx8IG1pZGRsZUluc2lkZShhLCBiKSk7IC8vIGRvZXNuJ3QgaW50ZXJzZWN0IG90aGVyIGVkZ2VzLCBkaWFnb25hbCBpbnNpZGUgcG9seWdvblxufVxuXG4vLyBzaWduZWQgYXJlYSBvZiBhIHRyaWFuZ2xlXG4vKiogQHBhcmFtIHtOb2RlfSBwIEBwYXJhbSB7Tm9kZX0gcSBAcGFyYW0ge05vZGV9IHIgQHJldHVybnMge251bWJlcn0gKi9cbmZ1bmN0aW9uIGFyZWEocCwgcSwgcikge1xuICAgIHJldHVybiAocS55IC0gcC55KSAqIChyLnggLSBxLngpIC0gKHEueCAtIHAueCkgKiAoci55IC0gcS55KTtcbn1cblxuLy8gY2hlY2sgaWYgdHdvIHBvaW50cyBhcmUgZXF1YWxcbi8qKiBAcGFyYW0ge05vZGV9IHAxIEBwYXJhbSB7Tm9kZX0gcDIgQHJldHVybnMge2Jvb2xlYW59ICovXG5mdW5jdGlvbiBlcXVhbHMocDEsIHAyKSB7XG4gICAgcmV0dXJuIHAxLnggPT09IHAyLnggJiYgcDEueSA9PT0gcDIueTtcbn1cblxuLy8gY2hlY2sgaWYgdHdvIHNlZ21lbnRzIGludGVyc2VjdDsgYnkgZGVmYXVsdCBpbmNsdWRlcyBjb2xsaW5lYXIgYm91bmRhcnkgdG91Y2hlc1xuLyoqIEBwYXJhbSB7Tm9kZX0gcDEgQHBhcmFtIHtOb2RlfSBxMSBAcGFyYW0ge05vZGV9IHAyIEBwYXJhbSB7Tm9kZX0gcTIgQHBhcmFtIHtib29sZWFufSBbaW5jbHVkZUJvdW5kYXJ5XSBAcmV0dXJucyB7Ym9vbGVhbn0gKi9cbmZ1bmN0aW9uIGludGVyc2VjdHMocDEsIHExLCBwMiwgcTIsIGluY2x1ZGVCb3VuZGFyeSA9IHRydWUpIHtcbiAgICBjb25zdCBvMSA9IGFyZWEocDEsIHExLCBwMik7XG4gICAgY29uc3QgbzIgPSBhcmVhKHAxLCBxMSwgcTIpO1xuICAgIGNvbnN0IG8zID0gYXJlYShwMiwgcTIsIHAxKTtcbiAgICBjb25zdCBvNCA9IGFyZWEocDIsIHEyLCBxMSk7XG5cbiAgICBpZiAoKChvMSA+IDAgJiYgbzIgPCAwKSB8fCAobzEgPCAwICYmIG8yID4gMCkpICYmICgobzMgPiAwICYmIG80IDwgMCkgfHwgKG8zIDwgMCAmJiBvNCA+IDApKSkgcmV0dXJuIHRydWU7XG5cbiAgICBpZiAoIWluY2x1ZGVCb3VuZGFyeSkgcmV0dXJuIGZhbHNlO1xuXG4gICAgaWYgKG8xID09PSAwICYmIG9uU2VnbWVudChwMSwgcDIsIHExKSkgcmV0dXJuIHRydWU7IC8vIHAxLCBxMSBhbmQgcDIgYXJlIGNvbGxpbmVhciBhbmQgcDIgbGllcyBvbiBwMXExXG4gICAgaWYgKG8yID09PSAwICYmIG9uU2VnbWVudChwMSwgcTIsIHExKSkgcmV0dXJuIHRydWU7IC8vIHAxLCBxMSBhbmQgcTIgYXJlIGNvbGxpbmVhciBhbmQgcTIgbGllcyBvbiBwMXExXG4gICAgaWYgKG8zID09PSAwICYmIG9uU2VnbWVudChwMiwgcDEsIHEyKSkgcmV0dXJuIHRydWU7IC8vIHAyLCBxMiBhbmQgcDEgYXJlIGNvbGxpbmVhciBhbmQgcDEgbGllcyBvbiBwMnEyXG4gICAgaWYgKG80ID09PSAwICYmIG9uU2VnbWVudChwMiwgcTEsIHEyKSkgcmV0dXJuIHRydWU7IC8vIHAyLCBxMiBhbmQgcTEgYXJlIGNvbGxpbmVhciBhbmQgcTEgbGllcyBvbiBwMnEyXG5cbiAgICByZXR1cm4gZmFsc2U7XG59XG5cbi8vIGZvciBjb2xsaW5lYXIgcG9pbnRzIHAsIHEsIHIsIGNoZWNrIGlmIHBvaW50IHEgbGllcyBvbiBzZWdtZW50IHByXG4vKiogQHBhcmFtIHtOb2RlfSBwIEBwYXJhbSB7Tm9kZX0gcSBAcGFyYW0ge05vZGV9IHIgQHJldHVybnMge2Jvb2xlYW59ICovXG5mdW5jdGlvbiBvblNlZ21lbnQocCwgcSwgcikge1xuICAgIHJldHVybiBxLnggPD0gTWF0aC5tYXgocC54LCByLngpICYmIHEueCA+PSBNYXRoLm1pbihwLngsIHIueCkgJiYgcS55IDw9IE1hdGgubWF4KHAueSwgci55KSAmJiBxLnkgPj0gTWF0aC5taW4ocC55LCByLnkpO1xufVxuXG4vLyBjaGVjayBpZiBhIHBvbHlnb24gZGlhZ29uYWwgaW50ZXJzZWN0cyBhbnkgcG9seWdvbiBzZWdtZW50c1xuLyoqIEBwYXJhbSB7Tm9kZX0gYSBAcGFyYW0ge05vZGV9IGIgQHJldHVybnMge2Jvb2xlYW59ICovXG5mdW5jdGlvbiBpbnRlcnNlY3RzUG9seWdvbihhLCBiKSB7XG4gICAgLy8gZGlhZ29uYWwgYmJveDsgYW4gZWRnZSB3aG9zZSBiYm94IGNhbid0IG92ZXJsYXAgaXQgY2FuJ3QgaW50ZXJzZWN0IGl0LCBzb1xuICAgIC8vIHNraXAgdGhlIG9yaWVudGF0aW9uIHRlc3QgZm9yIHRob3NlICh0aGUgY29tbW9uIGNhc2Ug4oCUIHRoZSBkaWFnb25hbCBpcyBzaG9ydClcbiAgICBjb25zdCBtaW5YID0gTWF0aC5taW4oYS54LCBiLngpO1xuICAgIGNvbnN0IG1heFggPSBNYXRoLm1heChhLngsIGIueCk7XG4gICAgY29uc3QgbWluWSA9IE1hdGgubWluKGEueSwgYi55KTtcbiAgICBjb25zdCBtYXhZID0gTWF0aC5tYXgoYS55LCBiLnkpO1xuXG4gICAgbGV0IHAgPSBhO1xuICAgIGRvIHtcbiAgICAgICAgY29uc3QgbiA9IHAubmV4dDtcbiAgICAgICAgaWYgKChwLnggPiBtYXhYICYmIG4ueCA+IG1heFgpIHx8IChwLnggPCBtaW5YICYmIG4ueCA8IG1pblgpIHx8XG4gICAgICAgICAgICAocC55ID4gbWF4WSAmJiBuLnkgPiBtYXhZKSB8fCAocC55IDwgbWluWSAmJiBuLnkgPCBtaW5ZKSkge1xuICAgICAgICAgICAgcCA9IG47XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocC5pICE9PSBhLmkgJiYgbi5pICE9PSBhLmkgJiYgcC5pICE9PSBiLmkgJiYgbi5pICE9PSBiLmkgJiZcbiAgICAgICAgICAgICAgICBpbnRlcnNlY3RzKHAsIG4sIGEsIGIpKSByZXR1cm4gdHJ1ZTtcbiAgICAgICAgcCA9IG47XG4gICAgfSB3aGlsZSAocCAhPT0gYSk7XG5cbiAgICByZXR1cm4gZmFsc2U7XG59XG5cbi8vIGNoZWNrIGlmIGEgcG9seWdvbiBkaWFnb25hbCBpcyBsb2NhbGx5IGluc2lkZSB0aGUgcG9seWdvblxuLyoqIEBwYXJhbSB7Tm9kZX0gYSBAcGFyYW0ge05vZGV9IGIgQHJldHVybnMge2Jvb2xlYW59ICovXG5mdW5jdGlvbiBsb2NhbGx5SW5zaWRlKGEsIGIpIHtcbiAgICByZXR1cm4gYXJlYShhLnByZXYsIGEsIGEubmV4dCkgPCAwID9cbiAgICAgICAgYXJlYShhLCBiLCBhLm5leHQpID49IDAgJiYgYXJlYShhLCBhLnByZXYsIGIpID49IDAgOlxuICAgICAgICBhcmVhKGEsIGIsIGEucHJldikgPCAwIHx8IGFyZWEoYSwgYS5uZXh0LCBiKSA8IDA7XG59XG5cbi8vIGNoZWNrIGlmIHRoZSBtaWRkbGUgcG9pbnQgb2YgYSBwb2x5Z29uIGRpYWdvbmFsIGlzIGluc2lkZSB0aGUgcG9seWdvblxuLyoqIEBwYXJhbSB7Tm9kZX0gYSBAcGFyYW0ge05vZGV9IGIgQHJldHVybnMge2Jvb2xlYW59ICovXG5mdW5jdGlvbiBtaWRkbGVJbnNpZGUoYSwgYikge1xuICAgIGxldCBwID0gYTtcbiAgICBsZXQgaW5zaWRlID0gZmFsc2U7XG4gICAgY29uc3QgcHggPSAoYS54ICsgYi54KSAvIDI7XG4gICAgY29uc3QgcHkgPSAoYS55ICsgYi55KSAvIDI7XG4gICAgZG8ge1xuICAgICAgICBjb25zdCBuID0gcC5uZXh0O1xuICAgICAgICBpZiAoKChwLnkgPiBweSkgIT09IChuLnkgPiBweSkpICYmIChweCA8IChuLnggLSBwLngpICogKHB5IC0gcC55KSAvIChuLnkgLSBwLnkpICsgcC54KSlcbiAgICAgICAgICAgIGluc2lkZSA9ICFpbnNpZGU7XG4gICAgICAgIHAgPSBuO1xuICAgIH0gd2hpbGUgKHAgIT09IGEpO1xuXG4gICAgcmV0dXJuIGluc2lkZTtcbn1cblxuLy8gbGluayB0d28gcG9seWdvbiB2ZXJ0aWNlcyB3aXRoIGEgYnJpZGdlOyBpZiB0aGUgdmVydGljZXMgYmVsb25nIHRvIHRoZSBzYW1lIHJpbmcsIGl0IHNwbGl0cyBwb2x5Z29uIGludG8gdHdvO1xuLy8gaWYgb25lIGJlbG9uZ3MgdG8gdGhlIG91dGVyIHJpbmcgYW5kIGFub3RoZXIgdG8gYSBob2xlLCBpdCBtZXJnZXMgaXQgaW50byBhIHNpbmdsZSByaW5nXG4vKiogQHBhcmFtIHtOb2RlfSBhIEBwYXJhbSB7Tm9kZX0gYiBAcmV0dXJucyB7Tm9kZX0gKi9cbmZ1bmN0aW9uIHNwbGl0UG9seWdvbihhLCBiKSB7XG4gICAgY29uc3QgYTIgPSBjcmVhdGVOb2RlKGEuaSwgYS54LCBhLnkpLFxuICAgICAgICBiMiA9IGNyZWF0ZU5vZGUoYi5pLCBiLngsIGIueSksXG4gICAgICAgIGFuID0gYS5uZXh0LFxuICAgICAgICBicCA9IGIucHJldjtcblxuICAgIGEubmV4dCA9IGI7XG4gICAgYi5wcmV2ID0gYTtcblxuICAgIGEyLm5leHQgPSBhbjtcbiAgICBhbi5wcmV2ID0gYTI7XG5cbiAgICBiMi5uZXh0ID0gYTI7XG4gICAgYTIucHJldiA9IGIyO1xuXG4gICAgYnAubmV4dCA9IGIyO1xuICAgIGIyLnByZXYgPSBicDtcblxuICAgIHJldHVybiBiMjtcbn1cblxuLy8gY3JlYXRlIGEgbm9kZSBhbmQgb3B0aW9uYWxseSBsaW5rIGl0IHdpdGggcHJldmlvdXMgb25lIChpbiBhIGNpcmN1bGFyIGRvdWJseSBsaW5rZWQgbGlzdClcbi8qKiBAcGFyYW0ge251bWJlcn0gaSBAcGFyYW0ge251bWJlcn0geCBAcGFyYW0ge251bWJlcn0geSBAcGFyYW0ge05vZGUgfCBudWxsfSBsYXN0IEByZXR1cm5zIHtOb2RlfSAqL1xuZnVuY3Rpb24gaW5zZXJ0Tm9kZShpLCB4LCB5LCBsYXN0KSB7XG4gICAgY29uc3QgcCA9IGNyZWF0ZU5vZGUoaSwgeCwgeSk7XG5cbiAgICBpZiAoIWxhc3QpIHtcbiAgICAgICAgcC5wcmV2ID0gcDtcbiAgICAgICAgcC5uZXh0ID0gcDtcblxuICAgIH0gZWxzZSB7XG4gICAgICAgIHAubmV4dCA9IGxhc3QubmV4dDtcbiAgICAgICAgcC5wcmV2ID0gbGFzdDtcbiAgICAgICAgbGFzdC5uZXh0LnByZXYgPSBwO1xuICAgICAgICBsYXN0Lm5leHQgPSBwO1xuICAgIH1cbiAgICByZXR1cm4gcDtcbn1cblxuLyoqIEBwYXJhbSB7Tm9kZX0gcCAqL1xuZnVuY3Rpb24gcmVtb3ZlTm9kZShwKSB7XG4gICAgcC5uZXh0LnByZXYgPSBwLnByZXY7XG4gICAgcC5wcmV2Lm5leHQgPSBwLm5leHQ7XG5cbiAgICBpZiAocC5wcmV2WikgcC5wcmV2Wi5uZXh0WiA9IHAubmV4dFo7XG4gICAgaWYgKHAubmV4dFopIHAubmV4dFoucHJldlogPSBwLnByZXZaO1xuXG4gICAgLy8ga2VlcCB0aGUgaG9sZS1icmlkZ2UgaW5kZXgncyBibG9jayBiYm94ZXMgY292ZXJpbmcgdGhlIGhlYWxlZCBwcmV2LT5uZXh0IGVkZ2VcbiAgICBpZiAoaW5kZXhBY3RpdmUpIGdyb3dCbG9jayhwLnByZXYsIHAubmV4dCk7XG59XG5cbi8qKiBAcGFyYW0ge251bWJlcn0gaSBAcGFyYW0ge251bWJlcn0geCBAcGFyYW0ge251bWJlcn0geSBAcmV0dXJucyB7Tm9kZX0gKi9cbmZ1bmN0aW9uIGNyZWF0ZU5vZGUoaSwgeCwgeSkge1xuICAgIC8vIHByZXYvbmV4dCBhcmUgYXNzaWduZWQgYnkgdGhlIGNhbGxlciBiZWZvcmUgYW55IHJlYWQsIHNvIHRoZSBudWxsIGluaXQgaXMgY2FzdCBhd2F5IGhlcmVcbiAgICByZXR1cm4gLyoqIEB0eXBlIHtOb2RlfSAqLyAoLyoqIEB0eXBlIHt1bmtub3dufSAqLyAoe1xuICAgICAgICBpLCAvLyB2ZXJ0ZXggaW5kZXggaW4gY29vcmRpbmF0ZXMgYXJyYXlcbiAgICAgICAgeCwgeSwgLy8gdmVydGV4IGNvb3JkaW5hdGVzXG4gICAgICAgIHByZXY6IG51bGwsIC8vIHByZXZpb3VzIGFuZCBuZXh0IHZlcnRleCBub2RlcyBpbiBhIHBvbHlnb24gcmluZ1xuICAgICAgICBuZXh0OiBudWxsLFxuICAgICAgICB6OiAwLCAvLyB6LW9yZGVyIGN1cnZlIHZhbHVlOyBkb3VibGVzIGFzIG93bmluZyBibG9jayBpbiB0aGUgaG9sZS1icmlkZ2UgaW5kZXggZHVyaW5nIGVsaW1pbmF0ZUhvbGVzXG4gICAgICAgIHByZXZaOiBudWxsLCAvLyBwcmV2aW91cyBhbmQgbmV4dCBub2RlcyBpbiB6LW9yZGVyXG4gICAgICAgIG5leHRaOiBudWxsXG4gICAgfSkpO1xufVxuXG4vKipcbiAqIFJldHVybiB0aGUgcmVsYXRpdmUgZGlmZmVyZW5jZSBiZXR3ZWVuIHRoZSBwb2x5Z29uIGFyZWEgYW5kIHRoZSBhcmVhIG9mIGl0cyB0cmlhbmd1bGF0aW9uIOKAlFxuICogYSB2YWx1ZSBuZWFyIDAgbWVhbnMgYSBjb3JyZWN0IHRyaWFuZ3VsYXRpb24uIFVzZWZ1bCBmb3IgdmVyaWZ5aW5nIG91dHB1dCBpbiB0ZXN0cy5cbiAqXG4gKiBAcGFyYW0ge0FycmF5TGlrZTxudW1iZXI+fSBkYXRhXG4gKiBAcGFyYW0ge0FycmF5TGlrZTxudW1iZXI+IHwgbnVsbH0gaG9sZUluZGljZXNcbiAqIEBwYXJhbSB7bnVtYmVyfSBkaW0gbnVtYmVyIG9mIGNvb3JkaW5hdGVzIHBlciB2ZXJ0ZXggaW4gYGRhdGFgXG4gKiBAcGFyYW0ge0FycmF5TGlrZTxudW1iZXI+fSB0cmlhbmdsZXMgb3V0cHV0IG9mIHtAbGluayBlYXJjdXR9XG4gKiBAcmV0dXJucyB7bnVtYmVyfVxuICogQGV4YW1wbGUgZGV2aWF0aW9uKGRhdGEsIGhvbGVzLCBkaW0sIGVhcmN1dChkYXRhLCBob2xlcywgZGltKSk7IC8vIH4wIGlmIGNvcnJlY3RcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRldmlhdGlvbihkYXRhLCBob2xlSW5kaWNlcywgZGltLCB0cmlhbmdsZXMpIHtcbiAgICBjb25zdCBoYXNIb2xlcyA9IGhvbGVJbmRpY2VzICYmIGhvbGVJbmRpY2VzLmxlbmd0aDtcbiAgICBjb25zdCBvdXRlckxlbiA9IGhhc0hvbGVzID8gaG9sZUluZGljZXNbMF0gKiBkaW0gOiBkYXRhLmxlbmd0aDtcblxuICAgIGxldCBwb2x5Z29uQXJlYSA9IE1hdGguYWJzKHNpZ25lZEFyZWEoZGF0YSwgMCwgb3V0ZXJMZW4sIGRpbSkpO1xuICAgIGlmIChoYXNIb2xlcykge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbGVuID0gaG9sZUluZGljZXMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHN0YXJ0ID0gaG9sZUluZGljZXNbaV0gKiBkaW07XG4gICAgICAgICAgICBjb25zdCBlbmQgPSBpIDwgbGVuIC0gMSA/IGhvbGVJbmRpY2VzW2kgKyAxXSAqIGRpbSA6IGRhdGEubGVuZ3RoO1xuICAgICAgICAgICAgcG9seWdvbkFyZWEgLT0gTWF0aC5hYnMoc2lnbmVkQXJlYShkYXRhLCBzdGFydCwgZW5kLCBkaW0pKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGxldCB0cmlhbmdsZXNBcmVhID0gMDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRyaWFuZ2xlcy5sZW5ndGg7IGkgKz0gMykge1xuICAgICAgICBjb25zdCBhID0gdHJpYW5nbGVzW2ldICogZGltO1xuICAgICAgICBjb25zdCBiID0gdHJpYW5nbGVzW2kgKyAxXSAqIGRpbTtcbiAgICAgICAgY29uc3QgYyA9IHRyaWFuZ2xlc1tpICsgMl0gKiBkaW07XG4gICAgICAgIHRyaWFuZ2xlc0FyZWEgKz0gTWF0aC5hYnMoXG4gICAgICAgICAgICAoZGF0YVthXSAtIGRhdGFbY10pICogKGRhdGFbYiArIDFdIC0gZGF0YVthICsgMV0pIC1cbiAgICAgICAgICAgIChkYXRhW2FdIC0gZGF0YVtiXSkgKiAoZGF0YVtjICsgMV0gLSBkYXRhW2EgKyAxXSkpO1xuICAgIH1cblxuICAgIC8vIHdpdGggbm8gdHJpYW5nbGVzLCBhIHBvbHlnb24gYXJlYSB3aXRoaW4gc2hvZWxhY2Ugcm91bmRvZmYgb2YgemVybyAod2hpY2ggc2NhbGVzIHdpdGggdGhlXG4gICAgLy8gc3F1YXJlZCBjb29yZGluYXRlIG1hZ25pdHVkZSkgbWVhbnMgdGhlIGlucHV0IHdhcyBkZWdlbmVyYXRlIHJhdGhlciB0aGFuIG1pc3RyaWFuZ3VsYXRlZFxuICAgIGlmICh0cmlhbmdsZXNBcmVhID09PSAwKSB7XG4gICAgICAgIGxldCBtYXggPSAwO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpICs9IGRpbSkgbWF4ID0gTWF0aC5tYXgobWF4LCBNYXRoLmFicyhkYXRhW2ldKSwgTWF0aC5hYnMoZGF0YVtpICsgMV0pKTtcbiAgICAgICAgcmV0dXJuIE1hdGguYWJzKHBvbHlnb25BcmVhKSA8PSBkYXRhLmxlbmd0aCAqIG1heCAqIG1heCAqIE51bWJlci5FUFNJTE9OID8gMCA6IDE7XG4gICAgfVxuICAgIHJldHVybiBNYXRoLmFicygodHJpYW5nbGVzQXJlYSAtIHBvbHlnb25BcmVhKSAvIHBvbHlnb25BcmVhKTtcbn1cblxuLyoqIEBwYXJhbSB7QXJyYXlMaWtlPG51bWJlcj59IGRhdGEgQHBhcmFtIHtudW1iZXJ9IHN0YXJ0IEBwYXJhbSB7bnVtYmVyfSBlbmQgQHBhcmFtIHtudW1iZXJ9IGRpbSBAcmV0dXJucyB7bnVtYmVyfSAqL1xuZnVuY3Rpb24gc2lnbmVkQXJlYShkYXRhLCBzdGFydCwgZW5kLCBkaW0pIHtcbiAgICBsZXQgc3VtID0gMDtcbiAgICBmb3IgKGxldCBpID0gc3RhcnQsIGogPSBlbmQgLSBkaW07IGkgPCBlbmQ7IGkgKz0gZGltKSB7XG4gICAgICAgIHN1bSArPSAoZGF0YVtqXSAtIGRhdGFbaV0pICogKGRhdGFbaSArIDFdICsgZGF0YVtqICsgMV0pO1xuICAgICAgICBqID0gaTtcbiAgICB9XG4gICAgcmV0dXJuIHN1bTtcbn1cblxuLyoqXG4gKiBUdXJuIGEgcG9seWdvbiBpbiBtdWx0aS1kaW1lbnNpb25hbCBhcnJheSBmb3JtIChlLmcuIGFzIGluIEdlb0pTT04pIGludG8gdGhlIGZsYXQgZm9ybSBFYXJjdXQgYWNjZXB0cy5cbiAqXG4gKiBAcGFyYW0ge1JlYWRvbmx5QXJyYXk8UmVhZG9ubHlBcnJheTxBcnJheUxpa2U8bnVtYmVyPj4+fSBkYXRhIGFycmF5IG9mIHJpbmdzOyB0aGUgZmlyc3QgcmluZyBpcyB0aGUgb3V0ZXIgY29udG91ciwgdGhlIHJlc3QgYXJlIGhvbGVzXG4gKiBAcmV0dXJucyB7e3ZlcnRpY2VzOiBudW1iZXJbXSwgaG9sZXM6IG51bWJlcltdLCBkaW1lbnNpb25zOiBudW1iZXJ9fVxuICogQGV4YW1wbGUgY29uc3Qge3ZlcnRpY2VzLCBob2xlcywgZGltZW5zaW9uc30gPSBmbGF0dGVuKGdlb2pzb24uY29vcmRpbmF0ZXMpO1xuICovXG5leHBvcnQgZnVuY3Rpb24gZmxhdHRlbihkYXRhKSB7XG4gICAgY29uc3QgdmVydGljZXMgPSBbXTtcbiAgICBjb25zdCBob2xlcyA9IFtdO1xuICAgIGNvbnN0IGRpbWVuc2lvbnMgPSBkYXRhWzBdWzBdLmxlbmd0aDtcbiAgICBsZXQgaG9sZUluZGV4ID0gMDtcbiAgICBsZXQgcHJldkxlbiA9IDA7XG5cbiAgICBmb3IgKGNvbnN0IHJpbmcgb2YgZGF0YSkge1xuICAgICAgICBmb3IgKGNvbnN0IHAgb2YgcmluZykge1xuICAgICAgICAgICAgZm9yIChsZXQgZCA9IDA7IGQgPCBkaW1lbnNpb25zOyBkKyspIHZlcnRpY2VzLnB1c2gocFtkXSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHByZXZMZW4pIHtcbiAgICAgICAgICAgIGhvbGVJbmRleCArPSBwcmV2TGVuO1xuICAgICAgICAgICAgaG9sZXMucHVzaChob2xlSW5kZXgpO1xuICAgICAgICB9XG4gICAgICAgIHByZXZMZW4gPSByaW5nLmxlbmd0aDtcbiAgICB9XG4gICAgcmV0dXJuIHt2ZXJ0aWNlcywgaG9sZXMsIGRpbWVuc2lvbnN9O1xufVxuXG4vLyBSZXVzYWJsZSBtb2R1bGUtbGV2ZWwgc2NyYXRjaCBmb3IgcmVmaW5lKCk6XG4vLyAgIGhlICAgICAgPSB0d2luIGhhbGYtZWRnZSBvZiBlYWNoIGVkZ2UsIG9yIC0xIG9uIHRoZSBwb2x5Z29uIGJvdW5kYXJ5XG4vLyAgIGhUYWJsZSAgPSBvcGVuLWFkZHJlc3NpbmcgaGFzaCwgc2xvdCAtPiBoYWxmLWVkZ2UgaW5kZXgsIHZhbGlkIGlmZiBoU3RhbXBbc2xvdF0gPT09IGdlblxuLy8gICBlZGdlU3RhbXAgPSBwZW5kaW5nLWluLXN0YWNrIGZsYWcsIGNsZWFyZWQgd2hlbiB0aGUgZWRnZSBpcyBwb3BwZWRcbi8qKiBAdHlwZSB7SW50MzJBcnJheX0gKi8gbGV0IGVkZ2VTdGFjaztcbi8qKiBAdHlwZSB7SW50MzJBcnJheX0gKi8gbGV0IGhlO1xuLyoqIEB0eXBlIHtJbnQzMkFycmF5fSAqLyBsZXQgaFRhYmxlO1xuLyoqIEB0eXBlIHtVaW50MzJBcnJheX0gKi8gbGV0IGhTdGFtcDtcbi8qKiBAdHlwZSB7VWludDhBcnJheX0gKi8gbGV0IGVkZ2VTdGFtcDtcbmxldCBoTWFzayA9IDAsIGdlbiA9IDA7XG5cbi8qKlxuICogUmVmaW5lIGEgdHJpYW5ndWxhdGlvbiB0b3dhcmQgdGhlIGNvbnN0cmFpbmVkIERlbGF1bmF5IHRyaWFuZ3VsYXRpb24gYnkgbGVnYWxpemluZyBldmVyeVxuICogaW50ZXJpb3IgZWRnZSBpbiBwbGFjZSB3aXRoIExhd3NvbiBmbGlwcyDigJQgbWF4aW1pemluZyB0aGUgbWluaW11bSBhbmdsZSBhbmQgcmVtb3ZpbmcgbW9zdFxuICogc2xpdmVycy4gQW4gb3B0aW9uYWwgcG9zdC1wYXNzIGZvciB7QGxpbmsgZWFyY3V0fSBvdXRwdXQsIG9yIGFueSBtYW5pZm9sZCB0cmlhbmdsZS1pbmRleCBhcnJheVxuICogaW5kZXhpbmcgaW50byBgY29vcmRzYC4gQWRhcHRlZCBmcm9tIGRlbGF1bmF0b3IncyBlZGdlIGxlZ2FsaXphdGlvbi5cbiAqXG4gKiBVc2VzIG5vbi1yb2J1c3QgcHJlZGljYXRlczogZmxvYXQgaW5wdXQgaXMgZmluZSwgYW5kIHRoZSB3b3JzdCBjYXNlIGlzIGEgbm90LXF1aXRlLURlbGF1bmF5XG4gKiBlZGdlLCBuZXZlciBhbiBpbnZhbGlkIG1lc2guXG4gKlxuICogQHBhcmFtIHtudW1iZXJbXX0gdHJpYW5nbGVzIHRyaWFuZ2xlIGluZGljZXMsIGFzIHJldHVybmVkIGJ5IHtAbGluayBlYXJjdXR9OyBtdXRhdGVkIGluIHBsYWNlXG4gKiBAcGFyYW0ge0FycmF5TGlrZTxudW1iZXI+fSBjb29yZHMgdGhlIGZsYXQgdmVydGV4IGNvb3JkaW5hdGVzIHBhc3NlZCB0byB7QGxpbmsgZWFyY3V0fVxuICogQHBhcmFtIHtudW1iZXJ9IFtkaW09Ml0gbnVtYmVyIG9mIGNvb3JkaW5hdGVzIHBlciB2ZXJ0ZXggaW4gYGNvb3Jkc2BcbiAqIEBleGFtcGxlIHJlZmluZShlYXJjdXQoZGF0YSksIGRhdGEpO1xuICovXG5leHBvcnQgZnVuY3Rpb24gcmVmaW5lKHRyaWFuZ2xlcywgY29vcmRzLCBkaW0gPSAyKSB7XG4gICAgY29uc3QgdCA9IHRyaWFuZ2xlcztcbiAgICBjb25zdCBuID0gdC5sZW5ndGg7XG4gICAgaWYgKG4gPCA2KSByZXR1cm47XG4gICAgZW5zdXJlU2NyYXRjaChuKTtcbiAgICBnZW4rKzsgICAgICAgICAgICAgIC8vIGJ1bXBpbmcgdGhlIGdlbmVyYXRpb24gbG9naWNhbGx5IGVtcHRpZXMgdGhlIGhhc2ggKG5vIGNsZWFyaW5nKVxuICAgIGhlLmZpbGwoLTEsIDAsIG4pO1xuXG4gICAgLy8gQnVpbGQgaGFsZi1lZGdlIHR3aW5zIHdpdGggYW4gdW5kaXJlY3RlZC1lZGdlIGhhc2g7IGNvbnN1bWVkIHNsb3RzIG1hcmsgbGlua2VkIHBhaXJzLiBBcyBlYWNoXG4gICAgLy8gcGFpciBpcyBsaW5rZWQgd2Ugc2VlZCB0aGUgc3RhY2sgd2l0aCBvbmUgcmVwcmVzZW50YXRpdmUgKHMsIHRoZSBlYXJsaWVyLWluc2VydGVkIGVkZ2UpIOKAlCB0aGlzXG4gICAgLy8gZnVzZXMgdGhlIGluaXRpYWwgXCJwdXNoIGV2ZXJ5IGludGVyaW9yIGVkZ2VcIiBwYXNzIGludG8gdGhlIGJ1aWxkLCBzYXZpbmcgYSBmdWxsIE8obikgc2Nhbi5cbiAgICAvLyBlZGdlU3RhbXAgaXMgYWxsLXplcm8gaGVyZSAoYmFsYW5jZWQgcHVzaC9wb3AgbGVhdmVzIGl0IGNsZWFuKSBhbmQgZWFjaCBwYWlyIGxpbmtzIG9uY2UsIHNvXG4gICAgLy8gdGhlIHNlZWQgd3JpdGUgbmVlZHMgbm8gZGVkdXAgZ3VhcmQuXG4gICAgbGV0IGkgPSAwO1xuICAgIGZvciAobGV0IGUgPSAwOyBlIDwgbjsgZSsrKSB7XG4gICAgICAgIGNvbnN0IGEgPSB0W2VdLCBiID0gdFtuZXh0SEUoZSldO1xuICAgICAgICBjb25zdCBsbyA9IGEgPCBiID8gYSA6IGIsIGhpID0gYSA8IGIgPyBiIDogYTtcbiAgICAgICAgbGV0IGggPSAoTWF0aC5pbXVsKGxvLCAweDllMzc3OWIxKSBeIE1hdGguaW11bChoaSwgMHg4NWViY2E2YikpICYgaE1hc2s7XG4gICAgICAgIHdoaWxlIChoU3RhbXBbaF0gPT09IGdlbikge1xuICAgICAgICAgICAgY29uc3QgcyA9IGhUYWJsZVtoXTtcbiAgICAgICAgICAgIC8vIHMgPT09IC0xIG1hcmtzIGEgY29uc3VtZWQgc2xvdCAoYSBwYWlyIGFscmVhZHkgbGlua2VkKSDigJQgc2tpcCBwYXN0IGl0XG4gICAgICAgICAgICBpZiAocyAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBzYSA9IHRbc10sIHNiID0gdFtuZXh0SEUocyldO1xuICAgICAgICAgICAgICAgIGlmICgoc2EgPT09IGxvICYmIHNiID09PSBoaSkgfHwgKHNhID09PSBoaSAmJiBzYiA9PT0gbG8pKSB7XG4gICAgICAgICAgICAgICAgICAgIGhlW2VdID0gczsgaGVbc10gPSBlOyBoVGFibGVbaF0gPSAtMTsgLy8gbGluaywgdGhlbiBjb25zdW1lIHRoZSBzbG90XG4gICAgICAgICAgICAgICAgICAgIGVkZ2VTdGFtcFtzXSA9IDE7IGVkZ2VTdGFja1tpKytdID0gczsgLy8gc2VlZCB0aGUgaW50ZXJpb3IgZWRnZSBmb3IgdGhlIGNhc2NhZGVcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaCA9IChoICsgMSkgJiBoTWFzaztcbiAgICAgICAgfVxuICAgICAgICBpZiAoaFN0YW1wW2hdICE9PSBnZW4pIHsgaFRhYmxlW2hdID0gZTsgaFN0YW1wW2hdID0gZ2VuOyB9IC8vIGZpcnN0IG9jY3VycmVuY2U6IGluc2VydFxuICAgIH1cblxuICAgIHdoaWxlIChpID4gMCkge1xuICAgICAgICBjb25zdCBhID0gZWRnZVN0YWNrWy0taV07XG4gICAgICAgIGVkZ2VTdGFtcFthXSA9IDA7XG4gICAgICAgIGNvbnN0IGIgPSBoZVthXTtcbiAgICAgICAgaWYgKGIgPT09IC0xKSBjb250aW51ZTtcblxuICAgICAgICBjb25zdCBhMCA9IGEgLSBhICUgMztcbiAgICAgICAgY29uc3QgYjAgPSBiIC0gYiAlIDM7XG4gICAgICAgIGNvbnN0IGFyID0gYTAgKyAoYSArIDIpICUgMztcbiAgICAgICAgY29uc3QgYWwgPSBhMCArIChhICsgMSkgJSAzO1xuICAgICAgICBjb25zdCBibCA9IGIwICsgKGIgKyAyKSAlIDM7XG4gICAgICAgIGNvbnN0IGJyID0gYjAgKyAoYiArIDEpICUgMztcbiAgICAgICAgY29uc3QgcDAgPSB0W2FyXSwgcHIgPSB0W2FdLCBwbCA9IHRbYWxdLCBwMSA9IHRbYmxdO1xuXG4gICAgICAgIGNvbnN0IHgwID0gY29vcmRzW3AwICogZGltXSwgeTAgPSBjb29yZHNbcDAgKiBkaW0gKyAxXTtcbiAgICAgICAgY29uc3QgeHIgPSBjb29yZHNbcHIgKiBkaW1dLCB5ciA9IGNvb3Jkc1twciAqIGRpbSArIDFdO1xuICAgICAgICBjb25zdCB4bCA9IGNvb3Jkc1twbCAqIGRpbV0sIHlsID0gY29vcmRzW3BsICogZGltICsgMV07XG4gICAgICAgIGNvbnN0IHgxID0gY29vcmRzW3AxICogZGltXSwgeTEgPSBjb29yZHNbcDEgKiBkaW0gKyAxXTtcblxuICAgICAgICAvLyBUZXN0IGluQ2lyY2xlIGZpcnN0OiBtb3N0IGludGVyaW9yIGVkZ2VzIGFyZSBhbHJlYWR5IERlbGF1bmF5IChpbkNpcmNsZSB0cnVlIOKGkiBubyBmbGlwKSxcbiAgICAgICAgLy8gc28gdGhpcyBzaG9ydC1jaXJjdWl0cyBiZWZvcmUgdGhlIHR3byBjb252ZXhpdHkgb3JpZW50cyBvbiB0aGUgY29tbW9uIHBhdGguIFRoZSBxdWFkIG11c3RcbiAgICAgICAgLy8gYWxzbyBiZSBjb252ZXggKGJvdGggbmV3IHRyaWFuZ2xlcyBDQ1cpIOKAlCBmbGlwcGluZyBhIHJlZmxleCBxdWFkIHdvdWxkIHB1c2ggYSB0cmlhbmdsZVxuICAgICAgICAvLyBvdXRzaWRlIHRoZSBwb2x5Z29uLiBCb3VuZGFyeS9ob2xlIGVkZ2VzIG5lZWQgbm8gZ3VhcmQg4oCUIHRoZXkgc2VsZi1wcm90ZWN0IHZpYSBoZSA9PT0gLTEuXG4gICAgICAgIGlmICghaW5DaXJjbGUoeDAsIHkwLCB4ciwgeXIsIHhsLCB5bCwgeDEsIHkxKSAmJlxuICAgICAgICAgICAgb3JpZW50KHgwLCB5MCwgeHIsIHlyLCB4MSwgeTEpID4gMCAmJiBvcmllbnQoeDAsIHkwLCB4MSwgeTEsIHhsLCB5bCkgPiAwKSB7XG4gICAgICAgICAgICB0W2FdID0gcDE7IHRbYl0gPSBwMDtcbiAgICAgICAgICAgIGNvbnN0IGhibCA9IGhlW2JsXSwgaGFyID0gaGVbYXJdO1xuICAgICAgICAgICAgaGVbYV0gPSBoYmw7IGlmIChoYmwgIT09IC0xKSBoZVtoYmxdID0gYTtcbiAgICAgICAgICAgIGhlW2JdID0gaGFyOyBpZiAoaGFyICE9PSAtMSkgaGVbaGFyXSA9IGI7XG4gICAgICAgICAgICBoZVthcl0gPSBibDsgaGVbYmxdID0gYXI7XG5cbiAgICAgICAgICAgIC8vIHJlLWNoZWNrIHRoZSBxdWFkJ3MgZm91ciBvdXRlciBlZGdlczsgc2tpcCBib3VuZGFyeSBlZGdlcyAoaGUgPT09IC0xKSBhbmQgYW55XG4gICAgICAgICAgICAvLyBhbHJlYWR5IHF1ZXVlZCAoZWRnZVN0YW1wKSwgd2hpY2ggYWxzbyBrZWVwcyB0aGUgc3RhY2sgYm91bmRlZCBieSBuLlxuICAgICAgICAgICAgaWYgKGhibCAgICAhPT0gLTEgJiYgZWRnZVN0YW1wW2FdICA9PT0gMCkgeyBlZGdlU3RhbXBbYV0gID0gMTsgZWRnZVN0YWNrW2krK10gPSBhOyB9XG4gICAgICAgICAgICBpZiAoaGFyICAgICE9PSAtMSAmJiBlZGdlU3RhbXBbYl0gID09PSAwKSB7IGVkZ2VTdGFtcFtiXSAgPSAxOyBlZGdlU3RhY2tbaSsrXSA9IGI7IH1cbiAgICAgICAgICAgIGlmIChoZVthbF0gIT09IC0xICYmIGVkZ2VTdGFtcFthbF0gPT09IDApIHsgZWRnZVN0YW1wW2FsXSA9IDE7IGVkZ2VTdGFja1tpKytdID0gYWw7IH1cbiAgICAgICAgICAgIGlmIChoZVticl0gIT09IC0xICYmIGVkZ2VTdGFtcFticl0gPT09IDApIHsgZWRnZVN0YW1wW2JyXSA9IDE7IGVkZ2VTdGFja1tpKytdID0gYnI7IH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuLyoqIEBwYXJhbSB7bnVtYmVyfSBheCBAcGFyYW0ge251bWJlcn0gYXkgQHBhcmFtIHtudW1iZXJ9IGJ4IEBwYXJhbSB7bnVtYmVyfSBieSBAcGFyYW0ge251bWJlcn0gY3ggQHBhcmFtIHtudW1iZXJ9IGN5ICovXG5mdW5jdGlvbiBvcmllbnQoYXgsIGF5LCBieCwgYnksIGN4LCBjeSkge1xuICAgIHJldHVybiAoYnggLSBheCkgKiAoY3kgLSBheSkgLSAoYnkgLSBheSkgKiAoY3ggLSBheCk7XG59XG5cbi8vIFdoZXRoZXIgcCBpcyBpbnNpZGUgb3IgZXhhY3RseSBvbiB0aGUgY2lyY3VtY2lyY2xlIG9mIHRyaWFuZ2xlIChhLCBiLCBjKS4gU2lnbiBpcyBuZWdhdGVkIHZzIHRoZVxuLy8gdXN1YWwgcHJlZGljYXRlIHRvIG1hdGNoIGVhcmN1dCdzIENDVyB3aW5kaW5nIOKAlCB0aGUgc3RhbmRhcmQgc2lnbiB3b3VsZCBidWlsZCB0aGUgYW50aS1EZWxhdW5heVxuLy8gbWVzaC4gQ29jaXJjdWxhciBxdWFkcyBhcmUgbGVnYWwgdGllcywgc28gcmVmaW5lIG9ubHkgZmxpcHMgd2hlbiB0aGlzIHJldHVybnMgZmFsc2UuXG4vKiogQHBhcmFtIHtudW1iZXJ9IGF4IEBwYXJhbSB7bnVtYmVyfSBheSBAcGFyYW0ge251bWJlcn0gYnggQHBhcmFtIHtudW1iZXJ9IGJ5IEBwYXJhbSB7bnVtYmVyfSBjeCBAcGFyYW0ge251bWJlcn0gY3kgQHBhcmFtIHtudW1iZXJ9IHB4IEBwYXJhbSB7bnVtYmVyfSBweSAqL1xuZnVuY3Rpb24gaW5DaXJjbGUoYXgsIGF5LCBieCwgYnksIGN4LCBjeSwgcHgsIHB5KSB7XG4gICAgY29uc3QgZHggPSBheCAtIHB4LCBkeSA9IGF5IC0gcHksIGV4ID0gYnggLSBweCwgZXkgPSBieSAtIHB5LCBmeCA9IGN4IC0gcHgsIGZ5ID0gY3kgLSBweTtcbiAgICBjb25zdCBhcCA9IGR4ICogZHggKyBkeSAqIGR5LCBicCA9IGV4ICogZXggKyBleSAqIGV5LCBjcCA9IGZ4ICogZnggKyBmeSAqIGZ5O1xuICAgIC8vIEEgbmVhci1jb2NpcmN1bGFyIHF1YWQgaXMgYSBsZWdhbCBEZWxhdW5heSB0aWUsIGJ1dCByb3VuZG9mZiBjYW4gZmxhZyBib3RoIGFuIGVkZ2UgYW5kIGl0c1xuICAgIC8vIGZsaXAgYXMgaWxsZWdhbCwgY2FzY2FkaW5nIGludG8gYW4gZW5kbGVzcyBmbGlwIGxvb3AgKCMyMDUpIOKAlCBzbyB0cmVhdCBhIGRldGVybWluYW50IHdpdGhpblxuICAgIC8vIGEgc21hbGwgbWFyZ2luIG9mIHplcm8gYXMgYSB0aWUuIFRoZSBkZXRlcm1pbmFudCdzIHdvcnN0LWNhc2Ugcm91bmRvZmYgZXJyb3IgaXMgcHJvdmFibHlcbiAgICAvLyBiZWxvdyA5ZS0xNsK3KGFwICsgYnAgKyBjcCnCsiAoU2hld2NodWstc3R5bGUgYm91bmQpLCBzbyB0aGUgbWFyZ2luIGd1YXJhbnRlZXMgZXZlcnkgZXhlY3V0ZWRcbiAgICAvLyBmbGlwIGlzIGlsbGVnYWwgaW4gZXhhY3QgYXJpdGhtZXRpYywgYW5kIExhd3NvbiBmbGlwcGluZyBhbHdheXMgdGVybWluYXRlcy5cbiAgICBjb25zdCBzID0gYXAgKyBicCArIGNwO1xuICAgIHJldHVybiBkeCAqIChleSAqIGNwIC0gYnAgKiBmeSkgLSBkeSAqIChleCAqIGNwIC0gYnAgKiBmeCkgKyBhcCAqIChleCAqIGZ5IC0gZXkgKiBmeCkgPD0gMWUtMTMgKiBzICogcztcbn1cblxuLyoqIEBwYXJhbSB7bnVtYmVyfSBlICovXG5mdW5jdGlvbiBuZXh0SEUoZSkgeyAvLyBuZXh0IGhhbGYtZWRnZSB3aXRoaW4gdGhlIHNhbWUgdHJpYW5nbGVcbiAgICByZXR1cm4gZSAtIGUgJSAzICsgKGUgKyAxKSAlIDM7XG59XG5cbi8vIEdyb3cgdGhlIHNjcmF0Y2ggYXJyYXlzIG9uIGRlbWFuZCAobGlrZSBlYXJjdXQncyB6LW9yZGVyIGFycmF5cykuIEFsbG9jYXRpbmcgbGF6aWx5IGhlcmUgcmF0aGVyXG4vLyB0aGFuIGF0IG1vZHVsZSBsb2FkIGxldHMgdGhlIHdob2xlIHJlZmluZSgpIGJsb2NrIHRyZWUtc2hha2UgYXdheSBmb3IgY2FsbGVycyB3aG8gZG9uJ3QgdXNlIGl0LlxuLyoqIEBwYXJhbSB7bnVtYmVyfSBuICovXG5mdW5jdGlvbiBlbnN1cmVTY3JhdGNoKG4pIHtcbiAgICAvLyBlZGdlU3RhY2sgaG9sZHMgYXQgbW9zdCBvbmUgZW50cnkgcGVyIGhhbGYtZWRnZSAoZWRnZVN0YW1wIGRlZHVwcyksIHNvIG4gaXMgYSBzYWZlIGNhcCDigJRcbiAgICAvLyBzaXppbmcgaXQgdXAgZnJvbnQgbGV0cyB0aGUgY2FzY2FkZSBwdXNoIHdpdGhvdXQgYSBib3VuZHMvZ3JvdyBjaGVjay5cbiAgICBpZiAoIWVkZ2VTdGFjayB8fCBlZGdlU3RhY2subGVuZ3RoIDwgbikgZWRnZVN0YWNrID0gbmV3IEludDMyQXJyYXkobik7XG4gICAgaWYgKCFoZSB8fCBoZS5sZW5ndGggPCBuKSBoZSA9IG5ldyBJbnQzMkFycmF5KG4pO1xuICAgIGlmICghZWRnZVN0YW1wIHx8IGVkZ2VTdGFtcC5sZW5ndGggPCBuKSBlZGdlU3RhbXAgPSBuZXcgVWludDhBcnJheShuKTtcbiAgICBsZXQgc2l6ZSA9IDE7XG4gICAgd2hpbGUgKHNpemUgPCBuICogNCkgc2l6ZSA8PD0gMTsgLy8gcG93ZXItb2YtdHdvIHRhYmxlLCBsb2FkIGZhY3RvciA8PSAwLjI1XG4gICAgaWYgKCFoVGFibGUgfHwgaFRhYmxlLmxlbmd0aCA8IHNpemUpIHsgaFRhYmxlID0gbmV3IEludDMyQXJyYXkoc2l6ZSk7IGhTdGFtcCA9IG5ldyBVaW50MzJBcnJheShzaXplKTsgfVxuICAgIGhNYXNrID0gc2l6ZSAtIDE7XG59XG4iLCJpbXBvcnQgZWFyY3V0TW9kdWxlIGZyb20gJ2VhcmN1dCc7XG5leHBvcnQgeyBkZWZhdWx0IGFzIEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50ZW1pdHRlcjMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IGVhcmN1dCA9IGVhcmN1dE1vZHVsZS5kZWZhdWx0IHx8IGVhcmN1dE1vZHVsZTtcblxuZXhwb3J0IHsgZWFyY3V0IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11dGlscy5tanMubWFwXG4iLCIvLyNyZWdpb24gc3JjL2luZGV4LnRzXG4vKiogTnVtYmVyIG9mIG51bWVyaWMgYXJndW1lbnRzIGVhY2ggU1ZHIHBhdGggY29tbWFuZCBleHBlY3RzIChsb3dlcmNhc2Uga2V5cykuICovXG5jb25zdCBsZW5ndGggPSB7XG5cdGE6IDcsXG5cdGM6IDYsXG5cdGg6IDEsXG5cdGw6IDIsXG5cdG06IDIsXG5cdHE6IDQsXG5cdHM6IDQsXG5cdHQ6IDIsXG5cdHY6IDEsXG5cdHo6IDBcbn07XG4vKiogTWF0Y2hlcyBhIHNpbmdsZSBwYXRoIGNvbW1hbmQgbGV0dGVyIGZvbGxvd2VkIGJ5IGl0cyByYXcgYXJndW1lbnQgc3RyaW5nLiAqL1xuY29uc3Qgc2VnbWVudCA9IC8oW2FzdHZ6cW1obGNdKShbXmFzdHZ6cW1obGNdKikvZ2k7XG4vKiogTWF0Y2hlcyBhIHNpbmdsZSBudW1lcmljIHRva2VuLCBpbmNsdWRpbmcgbmVnYXRpdmVzLCBkZWNpbWFscywgYW5kIHNjaWVudGlmaWMgbm90YXRpb24uICovXG5jb25zdCBudW1iZXIgPSAvLT9bMC05XSpcXC4/WzAtOV0rKD86ZVstK10/XFxkKyk/L2dpO1xuLyoqXG4qIFBhcnNlIGFuIFNWRyBwYXRoIGBkYCBhdHRyaWJ1dGUgc3RyaW5nIGludG8gYW4gYXJyYXkgb2YgY29tbWFuZHMuXG4qXG4qIEVhY2ggY29tbWFuZCBpcyBhIHR1cGxlIG9mIGBbbGV0dGVyLCAuLi5hcmdzXWAuIFJlbGF0aXZlIGNvbW1hbmRzIHVzZVxuKiBsb3dlcmNhc2UgbGV0dGVyczsgYWJzb2x1dGUgY29tbWFuZHMgdXNlIHVwcGVyY2FzZS4gQW4gaW1wbGljaXQgYGxpbmV0b2BcbiogaXMgaW5zZXJ0ZWQgYWZ0ZXIgdGhlIGZpcnN0IGNvb3JkaW5hdGUgcGFpciBvZiBhIGBtb3ZldG9gIHdpdGggZXh0cmEgYXJncyxcbiogcGVyIHRoZSBTVkcgc3BlYy5cbipcbiogQHBhcmFtIHBhdGggLSBUaGUgcmF3IFNWRyBwYXRoIGRhdGEgc3RyaW5nIChlLmcuIGBcIk0wLDAgTDEwLDEwIFpcImApLlxuKiBAcmV0dXJucyBBcnJheSBvZiBwYXJzZWQgY29tbWFuZHMuXG4qIEB0aHJvd3Mge0Vycm9yfSBpZiBhIGNvbW1hbmQgaGFzIGZld2VyIGFyZ3VtZW50cyB0aGFuIGV4cGVjdGVkLlxuKi9cbmZ1bmN0aW9uIHBhcnNlKHBhdGgpIHtcblx0Y29uc3QgZGF0YSA9IFtdO1xuXHRwYXRoLnJlcGxhY2Uoc2VnbWVudCwgKF8sIGNtZCwgYXJncykgPT4ge1xuXHRcdGxldCB0eXBlID0gY21kLnRvTG93ZXJDYXNlKCk7XG5cdFx0bGV0IGNvbW1hbmQgPSBjbWQ7XG5cdFx0Y29uc3QgdmFsdWVzID0gcGFyc2VWYWx1ZXMoYXJncyk7XG5cdFx0aWYgKHR5cGUgPT09IFwibVwiICYmIHZhbHVlcy5sZW5ndGggPiAyKSB7XG5cdFx0XHRkYXRhLnB1c2goW2NvbW1hbmQsIC4uLnZhbHVlcy5zcGxpY2UoMCwgMildKTtcblx0XHRcdHR5cGUgPSBcImxcIjtcblx0XHRcdGNvbW1hbmQgPSBjb21tYW5kID09PSBcIm1cIiA/IFwibFwiIDogXCJMXCI7XG5cdFx0fVxuXHRcdHdoaWxlICh0cnVlKSB7XG5cdFx0XHRpZiAodmFsdWVzLmxlbmd0aCA9PT0gbGVuZ3RoW3R5cGVdKSB7XG5cdFx0XHRcdGRhdGEucHVzaChbY29tbWFuZCwgLi4udmFsdWVzXSk7XG5cdFx0XHRcdHJldHVybiBcIlwiO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHZhbHVlcy5sZW5ndGggPCBsZW5ndGhbdHlwZV0pIHRocm93IG5ldyBFcnJvcihcIm1hbGZvcm1lZCBwYXRoIGRhdGFcIik7XG5cdFx0XHRkYXRhLnB1c2goW2NvbW1hbmQsIC4uLnZhbHVlcy5zcGxpY2UoMCwgbGVuZ3RoW3R5cGVdKV0pO1xuXHRcdH1cblx0fSk7XG5cdHJldHVybiBkYXRhO1xufVxuLyoqIEV4dHJhY3QgYWxsIG51bWVyaWMgdG9rZW5zIGZyb20gYSByYXcgYXJndW1lbnQgc3RyaW5nLiAqL1xuZnVuY3Rpb24gcGFyc2VWYWx1ZXMoYXJncykge1xuXHRjb25zdCBudW1iZXJzID0gYXJncy5tYXRjaChudW1iZXIpO1xuXHRyZXR1cm4gbnVtYmVycyA/IG51bWJlcnMubWFwKE51bWJlcikgOiBbXTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcGFyc2UgYXMgZGVmYXVsdCB9O1xuIiwiaW1wb3J0IHBhcnNlIGZyb20gJ3BhcnNlLXN2Zy1wYXRoJztcbmltcG9ydCB7IHdhcm4gfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9sb2dnaW5nL3dhcm4ubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBwYXJzZVNWR1BhdGgoc3ZnUGF0aCwgcGF0aCkge1xuICBjb25zdCBjb21tYW5kcyA9IHBhcnNlKHN2Z1BhdGgpO1xuICBjb25zdCBzdWJwYXRocyA9IFtdO1xuICBsZXQgY3VycmVudFN1YlBhdGggPSBudWxsO1xuICBsZXQgbGFzdFggPSAwO1xuICBsZXQgbGFzdFkgPSAwO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGNvbW1hbmRzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgY29tbWFuZCA9IGNvbW1hbmRzW2ldO1xuICAgIGNvbnN0IHR5cGUgPSBjb21tYW5kWzBdO1xuICAgIGNvbnN0IGRhdGEgPSBjb21tYW5kO1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSBcIk1cIjpcbiAgICAgICAgbGFzdFggPSBkYXRhWzFdO1xuICAgICAgICBsYXN0WSA9IGRhdGFbMl07XG4gICAgICAgIHBhdGgubW92ZVRvKGxhc3RYLCBsYXN0WSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcIm1cIjpcbiAgICAgICAgbGFzdFggKz0gZGF0YVsxXTtcbiAgICAgICAgbGFzdFkgKz0gZGF0YVsyXTtcbiAgICAgICAgcGF0aC5tb3ZlVG8obGFzdFgsIGxhc3RZKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiSFwiOlxuICAgICAgICBsYXN0WCA9IGRhdGFbMV07XG4gICAgICAgIHBhdGgubGluZVRvKGxhc3RYLCBsYXN0WSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImhcIjpcbiAgICAgICAgbGFzdFggKz0gZGF0YVsxXTtcbiAgICAgICAgcGF0aC5saW5lVG8obGFzdFgsIGxhc3RZKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiVlwiOlxuICAgICAgICBsYXN0WSA9IGRhdGFbMV07XG4gICAgICAgIHBhdGgubGluZVRvKGxhc3RYLCBsYXN0WSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcInZcIjpcbiAgICAgICAgbGFzdFkgKz0gZGF0YVsxXTtcbiAgICAgICAgcGF0aC5saW5lVG8obGFzdFgsIGxhc3RZKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiTFwiOlxuICAgICAgICBsYXN0WCA9IGRhdGFbMV07XG4gICAgICAgIGxhc3RZID0gZGF0YVsyXTtcbiAgICAgICAgcGF0aC5saW5lVG8obGFzdFgsIGxhc3RZKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwibFwiOlxuICAgICAgICBsYXN0WCArPSBkYXRhWzFdO1xuICAgICAgICBsYXN0WSArPSBkYXRhWzJdO1xuICAgICAgICBwYXRoLmxpbmVUbyhsYXN0WCwgbGFzdFkpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJDXCI6XG4gICAgICAgIGxhc3RYID0gZGF0YVs1XTtcbiAgICAgICAgbGFzdFkgPSBkYXRhWzZdO1xuICAgICAgICBwYXRoLmJlemllckN1cnZlVG8oXG4gICAgICAgICAgZGF0YVsxXSxcbiAgICAgICAgICBkYXRhWzJdLFxuICAgICAgICAgIC8vIEZpcnN0IGNvbnRyb2wgcG9pbnRcbiAgICAgICAgICBkYXRhWzNdLFxuICAgICAgICAgIGRhdGFbNF0sXG4gICAgICAgICAgLy8gU2Vjb25kIGNvbnRyb2wgcG9pbnRcbiAgICAgICAgICBsYXN0WCxcbiAgICAgICAgICBsYXN0WVxuICAgICAgICAgIC8vIEVuZCBwb2ludFxuICAgICAgICApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJjXCI6XG4gICAgICAgIHBhdGguYmV6aWVyQ3VydmVUbyhcbiAgICAgICAgICBsYXN0WCArIGRhdGFbMV0sXG4gICAgICAgICAgbGFzdFkgKyBkYXRhWzJdLFxuICAgICAgICAgIC8vIEZpcnN0IGNvbnRyb2wgcG9pbnRcbiAgICAgICAgICBsYXN0WCArIGRhdGFbM10sXG4gICAgICAgICAgbGFzdFkgKyBkYXRhWzRdLFxuICAgICAgICAgIC8vIFNlY29uZCBjb250cm9sIHBvaW50XG4gICAgICAgICAgbGFzdFggKyBkYXRhWzVdLFxuICAgICAgICAgIGxhc3RZICsgZGF0YVs2XVxuICAgICAgICAgIC8vIEVuZCBwb2ludFxuICAgICAgICApO1xuICAgICAgICBsYXN0WCArPSBkYXRhWzVdO1xuICAgICAgICBsYXN0WSArPSBkYXRhWzZdO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJTXCI6XG4gICAgICAgIGxhc3RYID0gZGF0YVszXTtcbiAgICAgICAgbGFzdFkgPSBkYXRhWzRdO1xuICAgICAgICBwYXRoLmJlemllckN1cnZlVG9TaG9ydChcbiAgICAgICAgICBkYXRhWzFdLFxuICAgICAgICAgIGRhdGFbMl0sXG4gICAgICAgICAgLy8gQ29udHJvbCBwb2ludFxuICAgICAgICAgIGxhc3RYLFxuICAgICAgICAgIGxhc3RZXG4gICAgICAgICAgLy8gRW5kIHBvaW50XG4gICAgICAgICk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcInNcIjpcbiAgICAgICAgcGF0aC5iZXppZXJDdXJ2ZVRvU2hvcnQoXG4gICAgICAgICAgbGFzdFggKyBkYXRhWzFdLFxuICAgICAgICAgIGxhc3RZICsgZGF0YVsyXSxcbiAgICAgICAgICAvLyBDb250cm9sIHBvaW50XG4gICAgICAgICAgbGFzdFggKyBkYXRhWzNdLFxuICAgICAgICAgIGxhc3RZICsgZGF0YVs0XVxuICAgICAgICAgIC8vIEVuZCBwb2ludFxuICAgICAgICApO1xuICAgICAgICBsYXN0WCArPSBkYXRhWzNdO1xuICAgICAgICBsYXN0WSArPSBkYXRhWzRdO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJRXCI6XG4gICAgICAgIGxhc3RYID0gZGF0YVszXTtcbiAgICAgICAgbGFzdFkgPSBkYXRhWzRdO1xuICAgICAgICBwYXRoLnF1YWRyYXRpY0N1cnZlVG8oXG4gICAgICAgICAgZGF0YVsxXSxcbiAgICAgICAgICBkYXRhWzJdLFxuICAgICAgICAgIC8vIENvbnRyb2wgcG9pbnRcbiAgICAgICAgICBsYXN0WCxcbiAgICAgICAgICBsYXN0WVxuICAgICAgICAgIC8vIEVuZCBwb2ludFxuICAgICAgICApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJxXCI6XG4gICAgICAgIHBhdGgucXVhZHJhdGljQ3VydmVUbyhcbiAgICAgICAgICBsYXN0WCArIGRhdGFbMV0sXG4gICAgICAgICAgbGFzdFkgKyBkYXRhWzJdLFxuICAgICAgICAgIC8vIENvbnRyb2wgcG9pbnRcbiAgICAgICAgICBsYXN0WCArIGRhdGFbM10sXG4gICAgICAgICAgbGFzdFkgKyBkYXRhWzRdXG4gICAgICAgICAgLy8gRW5kIHBvaW50XG4gICAgICAgICk7XG4gICAgICAgIGxhc3RYICs9IGRhdGFbM107XG4gICAgICAgIGxhc3RZICs9IGRhdGFbNF07XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcIlRcIjpcbiAgICAgICAgbGFzdFggPSBkYXRhWzFdO1xuICAgICAgICBsYXN0WSA9IGRhdGFbMl07XG4gICAgICAgIHBhdGgucXVhZHJhdGljQ3VydmVUb1Nob3J0KFxuICAgICAgICAgIGxhc3RYLFxuICAgICAgICAgIGxhc3RZXG4gICAgICAgICAgLy8gRW5kIHBvaW50XG4gICAgICAgICk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcInRcIjpcbiAgICAgICAgbGFzdFggKz0gZGF0YVsxXTtcbiAgICAgICAgbGFzdFkgKz0gZGF0YVsyXTtcbiAgICAgICAgcGF0aC5xdWFkcmF0aWNDdXJ2ZVRvU2hvcnQoXG4gICAgICAgICAgbGFzdFgsXG4gICAgICAgICAgbGFzdFlcbiAgICAgICAgICAvLyBFbmQgcG9pbnRcbiAgICAgICAgKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiQVwiOlxuICAgICAgICBsYXN0WCA9IGRhdGFbNl07XG4gICAgICAgIGxhc3RZID0gZGF0YVs3XTtcbiAgICAgICAgcGF0aC5hcmNUb1N2ZyhcbiAgICAgICAgICBkYXRhWzFdLFxuICAgICAgICAgIC8vIHJ4XG4gICAgICAgICAgZGF0YVsyXSxcbiAgICAgICAgICAvLyByeVxuICAgICAgICAgIGRhdGFbM10sXG4gICAgICAgICAgLy8geC1heGlzLXJvdGF0aW9uXG4gICAgICAgICAgZGF0YVs0XSxcbiAgICAgICAgICAvLyBsYXJnZS1hcmMtZmxhZ1xuICAgICAgICAgIGRhdGFbNV0sXG4gICAgICAgICAgLy8gc3dlZXAtZmxhZ1xuICAgICAgICAgIGxhc3RYLFxuICAgICAgICAgIGxhc3RZXG4gICAgICAgICAgLy8gRW5kIHBvaW50XG4gICAgICAgICk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImFcIjpcbiAgICAgICAgbGFzdFggKz0gZGF0YVs2XTtcbiAgICAgICAgbGFzdFkgKz0gZGF0YVs3XTtcbiAgICAgICAgcGF0aC5hcmNUb1N2ZyhcbiAgICAgICAgICBkYXRhWzFdLFxuICAgICAgICAgIC8vIHJ4XG4gICAgICAgICAgZGF0YVsyXSxcbiAgICAgICAgICAvLyByeVxuICAgICAgICAgIGRhdGFbM10sXG4gICAgICAgICAgLy8geC1heGlzLXJvdGF0aW9uXG4gICAgICAgICAgZGF0YVs0XSxcbiAgICAgICAgICAvLyBsYXJnZS1hcmMtZmxhZ1xuICAgICAgICAgIGRhdGFbNV0sXG4gICAgICAgICAgLy8gc3dlZXAtZmxhZ1xuICAgICAgICAgIGxhc3RYLFxuICAgICAgICAgIGxhc3RZXG4gICAgICAgICAgLy8gRW5kIHBvaW50XG4gICAgICAgICk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcIlpcIjpcbiAgICAgIC8vIENsb3NlIFBhdGhcbiAgICAgIGNhc2UgXCJ6XCI6XG4gICAgICAgIHBhdGguY2xvc2VQYXRoKCk7XG4gICAgICAgIGlmIChzdWJwYXRocy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY3VycmVudFN1YlBhdGggPSBzdWJwYXRocy5wb3AoKTtcbiAgICAgICAgICBpZiAoY3VycmVudFN1YlBhdGgpIHtcbiAgICAgICAgICAgIGxhc3RYID0gY3VycmVudFN1YlBhdGguc3RhcnRYO1xuICAgICAgICAgICAgbGFzdFkgPSBjdXJyZW50U3ViUGF0aC5zdGFydFk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGxhc3RYID0gMDtcbiAgICAgICAgICAgIGxhc3RZID0gMDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY3VycmVudFN1YlBhdGggPSBudWxsO1xuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHdhcm4oYFVua25vd24gU1ZHIHBhdGggY29tbWFuZDogJHt0eXBlfWApO1xuICAgIH1cbiAgICBpZiAodHlwZSAhPT0gXCJaXCIgJiYgdHlwZSAhPT0gXCJ6XCIpIHtcbiAgICAgIGlmIChjdXJyZW50U3ViUGF0aCA9PT0gbnVsbCkge1xuICAgICAgICBjdXJyZW50U3ViUGF0aCA9IHsgc3RhcnRYOiBsYXN0WCwgc3RhcnRZOiBsYXN0WSB9O1xuICAgICAgICBzdWJwYXRocy5wdXNoKGN1cnJlbnRTdWJQYXRoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHBhdGg7XG59XG5cbmV4cG9ydCB7IHBhcnNlU1ZHUGF0aCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFyc2VTVkdQYXRoLm1qcy5tYXBcbiIsImltcG9ydCB7IFJlY3RhbmdsZSB9IGZyb20gJy4vUmVjdGFuZ2xlLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgQ2lyY2xlIHtcbiAgLyoqXG4gICAqIEBwYXJhbSB4IC0gVGhlIFggY29vcmRpbmF0ZSBvZiB0aGUgY2VudGVyIG9mIHRoaXMgY2lyY2xlXG4gICAqIEBwYXJhbSB5IC0gVGhlIFkgY29vcmRpbmF0ZSBvZiB0aGUgY2VudGVyIG9mIHRoaXMgY2lyY2xlXG4gICAqIEBwYXJhbSByYWRpdXMgLSBUaGUgcmFkaXVzIG9mIHRoZSBjaXJjbGVcbiAgICovXG4gIGNvbnN0cnVjdG9yKHggPSAwLCB5ID0gMCwgcmFkaXVzID0gMCkge1xuICAgIC8qKlxuICAgICAqIFRoZSB0eXBlIG9mIHRoZSBvYmplY3QsIG1haW5seSB1c2VkIHRvIGF2b2lkIGBpbnN0YW5jZW9mYCBjaGVja3MuXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIC8vIENoZWNrIHNoYXBlIHR5cGVcbiAgICAgKiBjb25zdCBzaGFwZSA9IG5ldyBDaXJjbGUoMCwgMCwgNTApO1xuICAgICAqIGNvbnNvbGUubG9nKHNoYXBlLnR5cGUpOyAvLyAnY2lyY2xlJ1xuICAgICAqXG4gICAgICogLy8gVXNlIGluIHR5cGUgZ3VhcmRzXG4gICAgICogaWYgKHNoYXBlLnR5cGUgPT09ICdjaXJjbGUnKSB7XG4gICAgICogICAgIGNvbnNvbGUubG9nKHNoYXBlLnJhZGl1cyk7XG4gICAgICogfVxuICAgICAqIGBgYFxuICAgICAqIEByZW1hcmtzXG4gICAgICogLSBVc2VkIGZvciBzaGFwZSB0eXBlIGNoZWNraW5nXG4gICAgICogLSBNb3JlIGVmZmljaWVudCB0aGFuIGluc3RhbmNlb2ZcbiAgICAgKiAtIFJlYWQtb25seSBwcm9wZXJ0eVxuICAgICAqIEByZWFkb25seVxuICAgICAqIEBkZWZhdWx0ICdjaXJjbGUnXG4gICAgICogQHNlZSB7QGxpbmsgU0hBUEVfUFJJTUlUSVZFfSBGb3IgYWxsIHNoYXBlIHR5cGVzXG4gICAgICogQHNlZSB7QGxpbmsgU2hhcGVQcmltaXRpdmV9IEZvciBzaGFwZSBpbnRlcmZhY2VcbiAgICAgKi9cbiAgICB0aGlzLnR5cGUgPSBcImNpcmNsZVwiO1xuICAgIHRoaXMueCA9IHg7XG4gICAgdGhpcy55ID0geTtcbiAgICB0aGlzLnJhZGl1cyA9IHJhZGl1cztcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBhIGNsb25lIG9mIHRoaXMgQ2lyY2xlIGluc3RhbmNlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjaXJjbGUgY2xvbmluZ1xuICAgKiBjb25zdCBvcmlnaW5hbCA9IG5ldyBDaXJjbGUoMTAwLCAxMDAsIDUwKTtcbiAgICogY29uc3QgY29weSA9IG9yaWdpbmFsLmNsb25lKCk7XG4gICAqXG4gICAqIC8vIENsb25lIGFuZCBtb2RpZnlcbiAgICogY29uc3QgbW9kaWZpZWQgPSBvcmlnaW5hbC5jbG9uZSgpO1xuICAgKiBtb2RpZmllZC5yYWRpdXMgPSA3NTtcbiAgICpcbiAgICogLy8gVmVyaWZ5IGluZGVwZW5kZW5jZVxuICAgKiBjb25zb2xlLmxvZyhvcmlnaW5hbC5yYWRpdXMpOyAvLyA1MFxuICAgKiBjb25zb2xlLmxvZyhtb2RpZmllZC5yYWRpdXMpOyAvLyA3NVxuICAgKiBgYGBcbiAgICogQHJldHVybnMgQSBjb3B5IG9mIHRoZSBDaXJjbGVcbiAgICogQHNlZSB7QGxpbmsgQ2lyY2xlLmNvcHlGcm9tfSBGb3IgY29weWluZyBpbnRvIGV4aXN0aW5nIGNpcmNsZVxuICAgKiBAc2VlIHtAbGluayBDaXJjbGUuY29weVRvfSBGb3IgY29weWluZyB0byBhbm90aGVyIGNpcmNsZVxuICAgKi9cbiAgY2xvbmUoKSB7XG4gICAgcmV0dXJuIG5ldyBDaXJjbGUodGhpcy54LCB0aGlzLnksIHRoaXMucmFkaXVzKTtcbiAgfVxuICAvKipcbiAgICogQ2hlY2tzIHdoZXRoZXIgdGhlIHggYW5kIHkgY29vcmRpbmF0ZXMgZ2l2ZW4gYXJlIGNvbnRhaW5lZCB3aXRoaW4gdGhpcyBjaXJjbGUuXG4gICAqXG4gICAqIFVzZXMgdGhlIGRpc3RhbmNlIGZvcm11bGEgdG8gZGV0ZXJtaW5lIGlmIGEgcG9pbnQgaXMgaW5zaWRlIHRoZSBjaXJjbGUncyByYWRpdXMuXG4gICAqXG4gICAqIENvbW1vbmx5IHVzZWQgZm9yIGhpdCB0ZXN0aW5nIGluIFBpeGlKUyBldmVudHMgYW5kIGdyYXBoaWNzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb250YWlubWVudCBjaGVja1xuICAgKiBjb25zdCBjaXJjbGUgPSBuZXcgQ2lyY2xlKDEwMCwgMTAwLCA1MCk7XG4gICAqIGNvbnN0IGlzSW5zaWRlID0gY2lyY2xlLmNvbnRhaW5zKDEyMCwgMTIwKTtcbiAgICpcbiAgICogLy8gQ2hlY2sgbW91c2UgcG9zaXRpb25cbiAgICogY29uc3QgY2lyY2xlID0gbmV3IENpcmNsZSgwLCAwLCAxMDApO1xuICAgKiBjb250YWluZXIuaGl0QXJlYSA9IGNpcmNsZTtcbiAgICogY29udGFpbmVyLm9uKCdwb2ludGVybW92ZScsIChlKSA9PiB7XG4gICAqICAgICAvLyBvbmx5IGNhbGxlZCBpZiBwb2ludGVyIGlzIHdpdGhpbiBjaXJjbGVcbiAgICogfSk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0geCAtIFRoZSBYIGNvb3JkaW5hdGUgb2YgdGhlIHBvaW50IHRvIHRlc3RcbiAgICogQHBhcmFtIHkgLSBUaGUgWSBjb29yZGluYXRlIG9mIHRoZSBwb2ludCB0byB0ZXN0XG4gICAqIEByZXR1cm5zIFdoZXRoZXIgdGhlIHgveSBjb29yZGluYXRlcyBhcmUgd2l0aGluIHRoaXMgQ2lyY2xlXG4gICAqIEBzZWUge0BsaW5rIENpcmNsZS5zdHJva2VDb250YWluc30gRm9yIGNoZWNraW5nIHN0cm9rZSBpbnRlcnNlY3Rpb25cbiAgICogQHNlZSB7QGxpbmsgQ2lyY2xlLmdldEJvdW5kc30gRm9yIGdldHRpbmcgYm91bmRpbmcgYm94XG4gICAqL1xuICBjb250YWlucyh4LCB5KSB7XG4gICAgaWYgKHRoaXMucmFkaXVzIDw9IDApIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCByMiA9IHRoaXMucmFkaXVzICogdGhpcy5yYWRpdXM7XG4gICAgbGV0IGR4ID0gdGhpcy54IC0geDtcbiAgICBsZXQgZHkgPSB0aGlzLnkgLSB5O1xuICAgIGR4ICo9IGR4O1xuICAgIGR5ICo9IGR5O1xuICAgIHJldHVybiBkeCArIGR5IDw9IHIyO1xuICB9XG4gIC8qKlxuICAgKiBDaGVja3Mgd2hldGhlciB0aGUgeCBhbmQgeSBjb29yZGluYXRlcyBnaXZlbiBhcmUgY29udGFpbmVkIHdpdGhpbiB0aGlzIGNpcmNsZSBpbmNsdWRpbmcgdGhlIHN0cm9rZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgc3Ryb2tlIGNoZWNrXG4gICAqIGNvbnN0IGNpcmNsZSA9IG5ldyBDaXJjbGUoMTAwLCAxMDAsIDUwKTtcbiAgICogY29uc3QgaXNPblN0cm9rZSA9IGNpcmNsZS5zdHJva2VDb250YWlucygxNTAsIDEwMCwgNCk7IC8vIDRweCBsaW5lIHdpZHRoXG4gICAqXG4gICAqIC8vIENoZWNrIHdpdGggZGlmZmVyZW50IGFsaWdubWVudHNcbiAgICogY29uc3QgaW5uZXJTdHJva2UgPSBjaXJjbGUuc3Ryb2tlQ29udGFpbnMoMTUwLCAxMDAsIDQsIDEpOyAgIC8vIEluc2lkZVxuICAgKiBjb25zdCBjZW50ZXJTdHJva2UgPSBjaXJjbGUuc3Ryb2tlQ29udGFpbnMoMTUwLCAxMDAsIDQsIDAuNSk7IC8vIENlbnRlcmVkXG4gICAqIGNvbnN0IG91dGVyU3Ryb2tlID0gY2lyY2xlLnN0cm9rZUNvbnRhaW5zKDE1MCwgMTAwLCA0LCAwKTsgICAvLyBPdXRzaWRlXG4gICAqIGBgYFxuICAgKiBAcGFyYW0geCAtIFRoZSBYIGNvb3JkaW5hdGUgb2YgdGhlIHBvaW50IHRvIHRlc3RcbiAgICogQHBhcmFtIHkgLSBUaGUgWSBjb29yZGluYXRlIG9mIHRoZSBwb2ludCB0byB0ZXN0XG4gICAqIEBwYXJhbSB3aWR0aCAtIFRoZSB3aWR0aCBvZiB0aGUgbGluZSB0byBjaGVja1xuICAgKiBAcGFyYW0gYWxpZ25tZW50IC0gVGhlIGFsaWdubWVudCBvZiB0aGUgc3Ryb2tlLCAwLjUgYnkgZGVmYXVsdFxuICAgKiBAcmV0dXJucyBXaGV0aGVyIHRoZSB4L3kgY29vcmRpbmF0ZXMgYXJlIHdpdGhpbiB0aGlzIENpcmNsZSdzIHN0cm9rZVxuICAgKiBAc2VlIHtAbGluayBDaXJjbGUuY29udGFpbnN9IEZvciBjaGVja2luZyBmaWxsIGNvbnRhaW5tZW50XG4gICAqIEBzZWUge0BsaW5rIENpcmNsZS5nZXRCb3VuZHN9IEZvciBnZXR0aW5nIHN0cm9rZSBib3VuZHNcbiAgICovXG4gIHN0cm9rZUNvbnRhaW5zKHgsIHksIHdpZHRoLCBhbGlnbm1lbnQgPSAwLjUpIHtcbiAgICBpZiAodGhpcy5yYWRpdXMgPT09IDApIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBkeCA9IHRoaXMueCAtIHg7XG4gICAgY29uc3QgZHkgPSB0aGlzLnkgLSB5O1xuICAgIGNvbnN0IHJhZGl1cyA9IHRoaXMucmFkaXVzO1xuICAgIGNvbnN0IG91dGVyV2lkdGggPSAoMSAtIGFsaWdubWVudCkgKiB3aWR0aDtcbiAgICBjb25zdCBkaXN0YW5jZSA9IE1hdGguc3FydChkeCAqIGR4ICsgZHkgKiBkeSk7XG4gICAgcmV0dXJuIGRpc3RhbmNlIDw9IHJhZGl1cyArIG91dGVyV2lkdGggJiYgZGlzdGFuY2UgPiByYWRpdXMgLSAod2lkdGggLSBvdXRlcldpZHRoKTtcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgZnJhbWluZyByZWN0YW5nbGUgb2YgdGhlIGNpcmNsZSBhcyBhIFJlY3RhbmdsZSBvYmplY3QuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGJvdW5kcyBjYWxjdWxhdGlvblxuICAgKiBjb25zdCBjaXJjbGUgPSBuZXcgQ2lyY2xlKDEwMCwgMTAwLCA1MCk7XG4gICAqIGNvbnN0IGJvdW5kcyA9IGNpcmNsZS5nZXRCb3VuZHMoKTtcbiAgICogLy8gYm91bmRzOiB4PTUwLCB5PTUwLCB3aWR0aD0xMDAsIGhlaWdodD0xMDBcbiAgICpcbiAgICogLy8gUmV1c2UgZXhpc3RpbmcgcmVjdGFuZ2xlXG4gICAqIGNvbnN0IHJlY3QgPSBuZXcgUmVjdGFuZ2xlKCk7XG4gICAqIGNpcmNsZS5nZXRCb3VuZHMocmVjdCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gb3V0IC0gT3B0aW9uYWwgUmVjdGFuZ2xlIG9iamVjdCB0byBzdG9yZSB0aGUgcmVzdWx0XG4gICAqIEByZXR1cm5zIFRoZSBmcmFtaW5nIHJlY3RhbmdsZVxuICAgKiBAc2VlIHtAbGluayBSZWN0YW5nbGV9IEZvciByZWN0YW5nbGUgcHJvcGVydGllc1xuICAgKiBAc2VlIHtAbGluayBDaXJjbGUuY29udGFpbnN9IEZvciBwb2ludCBjb250YWlubWVudFxuICAgKi9cbiAgZ2V0Qm91bmRzKG91dCkge1xuICAgIG91dCB8fCAob3V0ID0gbmV3IFJlY3RhbmdsZSgpKTtcbiAgICBvdXQueCA9IHRoaXMueCAtIHRoaXMucmFkaXVzO1xuICAgIG91dC55ID0gdGhpcy55IC0gdGhpcy5yYWRpdXM7XG4gICAgb3V0LndpZHRoID0gdGhpcy5yYWRpdXMgKiAyO1xuICAgIG91dC5oZWlnaHQgPSB0aGlzLnJhZGl1cyAqIDI7XG4gICAgcmV0dXJuIG91dDtcbiAgfVxuICAvKipcbiAgICogQ29waWVzIGFub3RoZXIgY2lyY2xlIHRvIHRoaXMgb25lLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb3B5aW5nXG4gICAqIGNvbnN0IHNvdXJjZSA9IG5ldyBDaXJjbGUoMTAwLCAxMDAsIDUwKTtcbiAgICogY29uc3QgdGFyZ2V0ID0gbmV3IENpcmNsZSgpO1xuICAgKiB0YXJnZXQuY29weUZyb20oc291cmNlKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSBjaXJjbGUgLSBUaGUgY2lyY2xlIHRvIGNvcHkgZnJvbVxuICAgKiBAcmV0dXJucyBSZXR1cm5zIGl0c2VsZlxuICAgKiBAc2VlIHtAbGluayBDaXJjbGUuY29weVRvfSBGb3IgY29weWluZyB0byBhbm90aGVyIGNpcmNsZVxuICAgKiBAc2VlIHtAbGluayBDaXJjbGUuY2xvbmV9IEZvciBjcmVhdGluZyBuZXcgY2lyY2xlIGNvcHlcbiAgICovXG4gIGNvcHlGcm9tKGNpcmNsZSkge1xuICAgIHRoaXMueCA9IGNpcmNsZS54O1xuICAgIHRoaXMueSA9IGNpcmNsZS55O1xuICAgIHRoaXMucmFkaXVzID0gY2lyY2xlLnJhZGl1cztcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQ29waWVzIHRoaXMgY2lyY2xlIHRvIGFub3RoZXIgb25lLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb3B5aW5nXG4gICAqIGNvbnN0IHNvdXJjZSA9IG5ldyBDaXJjbGUoMTAwLCAxMDAsIDUwKTtcbiAgICogY29uc3QgdGFyZ2V0ID0gbmV3IENpcmNsZSgpO1xuICAgKiBzb3VyY2UuY29weVRvKHRhcmdldCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gY2lyY2xlIC0gVGhlIGNpcmNsZSB0byBjb3B5IHRvXG4gICAqIEByZXR1cm5zIFJldHVybnMgZ2l2ZW4gcGFyYW1ldGVyXG4gICAqIEBzZWUge0BsaW5rIENpcmNsZS5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgZnJvbSBhbm90aGVyIGNpcmNsZVxuICAgKiBAc2VlIHtAbGluayBDaXJjbGUuY2xvbmV9IEZvciBjcmVhdGluZyBuZXcgY2lyY2xlIGNvcHlcbiAgICovXG4gIGNvcHlUbyhjaXJjbGUpIHtcbiAgICBjaXJjbGUuY29weUZyb20odGhpcyk7XG4gICAgcmV0dXJuIGNpcmNsZTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYFtwaXhpLmpzL21hdGg6Q2lyY2xlIHg9JHt0aGlzLnh9IHk9JHt0aGlzLnl9IHJhZGl1cz0ke3RoaXMucmFkaXVzfV1gO1xuICB9XG59XG5cbmV4cG9ydCB7IENpcmNsZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q2lyY2xlLm1qcy5tYXBcbiIsImltcG9ydCB7IFJlY3RhbmdsZSB9IGZyb20gJy4vUmVjdGFuZ2xlLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgRWxsaXBzZSB7XG4gIC8qKlxuICAgKiBAcGFyYW0geCAtIFRoZSBYIGNvb3JkaW5hdGUgb2YgdGhlIGNlbnRlciBvZiB0aGlzIGVsbGlwc2VcbiAgICogQHBhcmFtIHkgLSBUaGUgWSBjb29yZGluYXRlIG9mIHRoZSBjZW50ZXIgb2YgdGhpcyBlbGxpcHNlXG4gICAqIEBwYXJhbSBoYWxmV2lkdGggLSBUaGUgaGFsZiB3aWR0aCBvZiB0aGlzIGVsbGlwc2VcbiAgICogQHBhcmFtIGhhbGZIZWlnaHQgLSBUaGUgaGFsZiBoZWlnaHQgb2YgdGhpcyBlbGxpcHNlXG4gICAqL1xuICBjb25zdHJ1Y3Rvcih4ID0gMCwgeSA9IDAsIGhhbGZXaWR0aCA9IDAsIGhhbGZIZWlnaHQgPSAwKSB7XG4gICAgLyoqXG4gICAgICogVGhlIHR5cGUgb2YgdGhlIG9iamVjdCwgbWFpbmx5IHVzZWQgdG8gYXZvaWQgYGluc3RhbmNlb2ZgIGNoZWNrc1xuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiAvLyBDaGVjayBzaGFwZSB0eXBlXG4gICAgICogY29uc3Qgc2hhcGUgPSBuZXcgRWxsaXBzZSgwLCAwLCA1MCwgMjUpO1xuICAgICAqIGNvbnNvbGUubG9nKHNoYXBlLnR5cGUpOyAvLyAnZWxsaXBzZSdcbiAgICAgKlxuICAgICAqIC8vIFVzZSBpbiB0eXBlIGd1YXJkc1xuICAgICAqIGlmIChzaGFwZS50eXBlID09PSAnZWxsaXBzZScpIHtcbiAgICAgKiAgICAgY29uc29sZS5sb2coc2hhcGUuaGFsZldpZHRoLCBzaGFwZS5oYWxmSGVpZ2h0KTtcbiAgICAgKiB9XG4gICAgICogYGBgXG4gICAgICogQHJlYWRvbmx5XG4gICAgICogQGRlZmF1bHQgJ2VsbGlwc2UnXG4gICAgICogQHNlZSB7QGxpbmsgU0hBUEVfUFJJTUlUSVZFfSBGb3IgYWxsIHNoYXBlIHR5cGVzXG4gICAgICovXG4gICAgdGhpcy50eXBlID0gXCJlbGxpcHNlXCI7XG4gICAgdGhpcy54ID0geDtcbiAgICB0aGlzLnkgPSB5O1xuICAgIHRoaXMuaGFsZldpZHRoID0gaGFsZldpZHRoO1xuICAgIHRoaXMuaGFsZkhlaWdodCA9IGhhbGZIZWlnaHQ7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBjbG9uZSBvZiB0aGlzIEVsbGlwc2UgaW5zdGFuY2UuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNsb25pbmdcbiAgICogY29uc3Qgb3JpZ2luYWwgPSBuZXcgRWxsaXBzZSgxMDAsIDEwMCwgNTAsIDI1KTtcbiAgICogY29uc3QgY29weSA9IG9yaWdpbmFsLmNsb25lKCk7XG4gICAqXG4gICAqIC8vIENsb25lIGFuZCBtb2RpZnlcbiAgICogY29uc3QgbW9kaWZpZWQgPSBvcmlnaW5hbC5jbG9uZSgpO1xuICAgKiBtb2RpZmllZC5oYWxmV2lkdGggKj0gMjtcbiAgICogbW9kaWZpZWQuaGFsZkhlaWdodCAqPSAyO1xuICAgKlxuICAgKiAvLyBWZXJpZnkgaW5kZXBlbmRlbmNlXG4gICAqIGNvbnNvbGUubG9nKG9yaWdpbmFsLmhhbGZXaWR0aCk7ICAvLyA1MFxuICAgKiBjb25zb2xlLmxvZyhtb2RpZmllZC5oYWxmV2lkdGgpOyAgLy8gMTAwXG4gICAqIGBgYFxuICAgKiBAcmV0dXJucyBBIGNvcHkgb2YgdGhlIGVsbGlwc2VcbiAgICogQHNlZSB7QGxpbmsgRWxsaXBzZS5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgaW50byBleGlzdGluZyBlbGxpcHNlXG4gICAqIEBzZWUge0BsaW5rIEVsbGlwc2UuY29weVRvfSBGb3IgY29weWluZyB0byBhbm90aGVyIGVsbGlwc2VcbiAgICovXG4gIGNsb25lKCkge1xuICAgIHJldHVybiBuZXcgRWxsaXBzZSh0aGlzLngsIHRoaXMueSwgdGhpcy5oYWxmV2lkdGgsIHRoaXMuaGFsZkhlaWdodCk7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyB3aGV0aGVyIHRoZSB4IGFuZCB5IGNvb3JkaW5hdGVzIGdpdmVuIGFyZSBjb250YWluZWQgd2l0aGluIHRoaXMgZWxsaXBzZS5cbiAgICogVXNlcyBub3JtYWxpemVkIGNvb3JkaW5hdGVzIGFuZCB0aGUgZWxsaXBzZSBlcXVhdGlvbiB0byBkZXRlcm1pbmUgY29udGFpbm1lbnQuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNvbnRhaW5tZW50IGNoZWNrXG4gICAqIGNvbnN0IGVsbGlwc2UgPSBuZXcgRWxsaXBzZSgxMDAsIDEwMCwgNTAsIDI1KTtcbiAgICogY29uc3QgaXNJbnNpZGUgPSBlbGxpcHNlLmNvbnRhaW5zKDEyMCwgMTEwKTtcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gVXNlcyBlbGxpcHNlIGVxdWF0aW9uICh4wrIvYcKyICsgecKyL2LCsiDiiaQgMSlcbiAgICogLSBSZXR1cm5zIGZhbHNlIGlmIGRpbWVuc2lvbnMgYXJlIDAgb3IgbmVnYXRpdmVcbiAgICogLSBOb3JtYWxpemVkIHRvIGNlbnRlciAoMCwwKSBmb3IgY2FsY3VsYXRpb25cbiAgICogQHBhcmFtIHggLSBUaGUgWCBjb29yZGluYXRlIG9mIHRoZSBwb2ludCB0byB0ZXN0XG4gICAqIEBwYXJhbSB5IC0gVGhlIFkgY29vcmRpbmF0ZSBvZiB0aGUgcG9pbnQgdG8gdGVzdFxuICAgKiBAcmV0dXJucyBXaGV0aGVyIHRoZSB4L3kgY29vcmRzIGFyZSB3aXRoaW4gdGhpcyBlbGxpcHNlXG4gICAqIEBzZWUge0BsaW5rIEVsbGlwc2Uuc3Ryb2tlQ29udGFpbnN9IEZvciBjaGVja2luZyBzdHJva2UgaW50ZXJzZWN0aW9uXG4gICAqIEBzZWUge0BsaW5rIEVsbGlwc2UuZ2V0Qm91bmRzfSBGb3IgZ2V0dGluZyBjb250YWluaW5nIHJlY3RhbmdsZVxuICAgKi9cbiAgY29udGFpbnMoeCwgeSkge1xuICAgIGlmICh0aGlzLmhhbGZXaWR0aCA8PSAwIHx8IHRoaXMuaGFsZkhlaWdodCA8PSAwKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGxldCBub3JteCA9ICh4IC0gdGhpcy54KSAvIHRoaXMuaGFsZldpZHRoO1xuICAgIGxldCBub3JteSA9ICh5IC0gdGhpcy55KSAvIHRoaXMuaGFsZkhlaWdodDtcbiAgICBub3JteCAqPSBub3JteDtcbiAgICBub3JteSAqPSBub3JteTtcbiAgICByZXR1cm4gbm9ybXggKyBub3JteSA8PSAxO1xuICB9XG4gIC8qKlxuICAgKiBDaGVja3Mgd2hldGhlciB0aGUgeCBhbmQgeSBjb29yZGluYXRlcyBnaXZlbiBhcmUgY29udGFpbmVkIHdpdGhpbiB0aGlzIGVsbGlwc2UgaW5jbHVkaW5nIHN0cm9rZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgc3Ryb2tlIGNoZWNrXG4gICAqIGNvbnN0IGVsbGlwc2UgPSBuZXcgRWxsaXBzZSgxMDAsIDEwMCwgNTAsIDI1KTtcbiAgICogY29uc3QgaXNPblN0cm9rZSA9IGVsbGlwc2Uuc3Ryb2tlQ29udGFpbnMoMTUwLCAxMDAsIDQpOyAvLyA0cHggbGluZSB3aWR0aFxuICAgKlxuICAgKiAvLyBDaGVjayB3aXRoIGRpZmZlcmVudCBhbGlnbm1lbnRzXG4gICAqIGNvbnN0IGlubmVyU3Ryb2tlID0gZWxsaXBzZS5zdHJva2VDb250YWlucygxNTAsIDEwMCwgNCwgMSk7ICAgLy8gSW5zaWRlXG4gICAqIGNvbnN0IGNlbnRlclN0cm9rZSA9IGVsbGlwc2Uuc3Ryb2tlQ29udGFpbnMoMTUwLCAxMDAsIDQsIDAuNSk7IC8vIENlbnRlcmVkXG4gICAqIGNvbnN0IG91dGVyU3Ryb2tlID0gZWxsaXBzZS5zdHJva2VDb250YWlucygxNTAsIDEwMCwgNCwgMCk7ICAgLy8gT3V0c2lkZVxuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBVc2VzIG5vcm1hbGl6ZWQgZWxsaXBzZSBlcXVhdGlvbnNcbiAgICogLSBDb25zaWRlcnMgc3Ryb2tlIGFsaWdubWVudFxuICAgKiAtIFJldHVybnMgZmFsc2UgaWYgZGltZW5zaW9ucyBhcmUgMFxuICAgKiAtIEEgc3Ryb2tlIHdpZGVyIHRoYW4gdGhlIHNoYXBlIGNvdmVycyBpdCBlbnRpcmVseSwgbGVhdmluZyBubyB1bnN0cm9rZWQgaW50ZXJpb3JcbiAgICogQHBhcmFtIHggLSBUaGUgWCBjb29yZGluYXRlIG9mIHRoZSBwb2ludCB0byB0ZXN0XG4gICAqIEBwYXJhbSB5IC0gVGhlIFkgY29vcmRpbmF0ZSBvZiB0aGUgcG9pbnQgdG8gdGVzdFxuICAgKiBAcGFyYW0gc3Ryb2tlV2lkdGggLSBUaGUgd2lkdGggb2YgdGhlIGxpbmUgdG8gY2hlY2tcbiAgICogQHBhcmFtIGFsaWdubWVudCAtIFRoZSBhbGlnbm1lbnQgb2YgdGhlIHN0cm9rZSAoMSA9IGlubmVyLCAwLjUgPSBjZW50ZXJlZCwgMCA9IG91dGVyKVxuICAgKiBAcmV0dXJucyBXaGV0aGVyIHRoZSB4L3kgY29vcmRzIGFyZSB3aXRoaW4gdGhpcyBlbGxpcHNlJ3Mgc3Ryb2tlXG4gICAqIEBzZWUge0BsaW5rIEVsbGlwc2UuY29udGFpbnN9IEZvciBjaGVja2luZyBmaWxsIGNvbnRhaW5tZW50XG4gICAqIEBzZWUge0BsaW5rIEVsbGlwc2UuZ2V0Qm91bmRzfSBGb3IgZ2V0dGluZyBzdHJva2UgYm91bmRzXG4gICAqL1xuICBzdHJva2VDb250YWlucyh4LCB5LCBzdHJva2VXaWR0aCwgYWxpZ25tZW50ID0gMC41KSB7XG4gICAgY29uc3QgeyBoYWxmV2lkdGgsIGhhbGZIZWlnaHQgfSA9IHRoaXM7XG4gICAgaWYgKGhhbGZXaWR0aCA8PSAwIHx8IGhhbGZIZWlnaHQgPD0gMCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBzdHJva2VPdXRlcldpZHRoID0gc3Ryb2tlV2lkdGggKiAoMSAtIGFsaWdubWVudCk7XG4gICAgY29uc3Qgc3Ryb2tlSW5uZXJXaWR0aCA9IHN0cm9rZVdpZHRoIC0gc3Ryb2tlT3V0ZXJXaWR0aDtcbiAgICBjb25zdCBpbm5lckhvcml6b250YWwgPSBoYWxmV2lkdGggLSBzdHJva2VJbm5lcldpZHRoO1xuICAgIGNvbnN0IGlubmVyVmVydGljYWwgPSBoYWxmSGVpZ2h0IC0gc3Ryb2tlSW5uZXJXaWR0aDtcbiAgICBjb25zdCBvdXRlckhvcml6b250YWwgPSBoYWxmV2lkdGggKyBzdHJva2VPdXRlcldpZHRoO1xuICAgIGNvbnN0IG91dGVyVmVydGljYWwgPSBoYWxmSGVpZ2h0ICsgc3Ryb2tlT3V0ZXJXaWR0aDtcbiAgICBjb25zdCBub3JtYWxpemVkWCA9IHggLSB0aGlzLng7XG4gICAgY29uc3Qgbm9ybWFsaXplZFkgPSB5IC0gdGhpcy55O1xuICAgIGNvbnN0IG91dGVyRWxsaXBzZSA9IG5vcm1hbGl6ZWRYICogbm9ybWFsaXplZFggLyAob3V0ZXJIb3Jpem9udGFsICogb3V0ZXJIb3Jpem9udGFsKSArIG5vcm1hbGl6ZWRZICogbm9ybWFsaXplZFkgLyAob3V0ZXJWZXJ0aWNhbCAqIG91dGVyVmVydGljYWwpO1xuICAgIGlmIChvdXRlckVsbGlwc2UgPiAxKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKGlubmVySG9yaXpvbnRhbCA8PSAwIHx8IGlubmVyVmVydGljYWwgPD0gMCkgcmV0dXJuIHRydWU7XG4gICAgY29uc3QgaW5uZXJFbGxpcHNlID0gbm9ybWFsaXplZFggKiBub3JtYWxpemVkWCAvIChpbm5lckhvcml6b250YWwgKiBpbm5lckhvcml6b250YWwpICsgbm9ybWFsaXplZFkgKiBub3JtYWxpemVkWSAvIChpbm5lclZlcnRpY2FsICogaW5uZXJWZXJ0aWNhbCk7XG4gICAgcmV0dXJuIGlubmVyRWxsaXBzZSA+IDE7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGZyYW1pbmcgcmVjdGFuZ2xlIG9mIHRoZSBlbGxpcHNlIGFzIGEgUmVjdGFuZ2xlIG9iamVjdC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgYm91bmRzIGNhbGN1bGF0aW9uXG4gICAqIGNvbnN0IGVsbGlwc2UgPSBuZXcgRWxsaXBzZSgxMDAsIDEwMCwgNTAsIDI1KTtcbiAgICogY29uc3QgYm91bmRzID0gZWxsaXBzZS5nZXRCb3VuZHMoKTtcbiAgICogLy8gYm91bmRzOiB4PTUwLCB5PTc1LCB3aWR0aD0xMDAsIGhlaWdodD01MFxuICAgKlxuICAgKiAvLyBSZXVzZSBleGlzdGluZyByZWN0YW5nbGVcbiAgICogY29uc3QgcmVjdCA9IG5ldyBSZWN0YW5nbGUoKTtcbiAgICogZWxsaXBzZS5nZXRCb3VuZHMocmVjdCk7XG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIENyZWF0ZXMgUmVjdGFuZ2xlIGlmIG5vbmUgcHJvdmlkZWRcbiAgICogLSBUb3AtbGVmdCBpcyAoeC1oYWxmV2lkdGgsIHktaGFsZkhlaWdodClcbiAgICogLSBXaWR0aCBpcyBoYWxmV2lkdGggKiAyXG4gICAqIC0gSGVpZ2h0IGlzIGhhbGZIZWlnaHQgKiAyXG4gICAqIEBwYXJhbSBvdXQgLSBPcHRpb25hbCBSZWN0YW5nbGUgb2JqZWN0IHRvIHN0b3JlIHRoZSByZXN1bHRcbiAgICogQHJldHVybnMgVGhlIGZyYW1pbmcgcmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZX0gRm9yIHJlY3RhbmdsZSBwcm9wZXJ0aWVzXG4gICAqIEBzZWUge0BsaW5rIEVsbGlwc2UuY29udGFpbnN9IEZvciBjaGVja2luZyBpZiBhIHBvaW50IGlzIGluc2lkZVxuICAgKi9cbiAgZ2V0Qm91bmRzKG91dCkge1xuICAgIG91dCB8fCAob3V0ID0gbmV3IFJlY3RhbmdsZSgpKTtcbiAgICBvdXQueCA9IHRoaXMueCAtIHRoaXMuaGFsZldpZHRoO1xuICAgIG91dC55ID0gdGhpcy55IC0gdGhpcy5oYWxmSGVpZ2h0O1xuICAgIG91dC53aWR0aCA9IHRoaXMuaGFsZldpZHRoICogMjtcbiAgICBvdXQuaGVpZ2h0ID0gdGhpcy5oYWxmSGVpZ2h0ICogMjtcbiAgICByZXR1cm4gb3V0O1xuICB9XG4gIC8qKlxuICAgKiBDb3BpZXMgYW5vdGhlciBlbGxpcHNlIHRvIHRoaXMgb25lLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb3B5aW5nXG4gICAqIGNvbnN0IHNvdXJjZSA9IG5ldyBFbGxpcHNlKDEwMCwgMTAwLCA1MCwgMjUpO1xuICAgKiBjb25zdCB0YXJnZXQgPSBuZXcgRWxsaXBzZSgpO1xuICAgKiB0YXJnZXQuY29weUZyb20oc291cmNlKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSBlbGxpcHNlIC0gVGhlIGVsbGlwc2UgdG8gY29weSBmcm9tXG4gICAqIEByZXR1cm5zIFJldHVybnMgaXRzZWxmXG4gICAqIEBzZWUge0BsaW5rIEVsbGlwc2UuY29weVRvfSBGb3IgY29weWluZyB0byBhbm90aGVyIGVsbGlwc2VcbiAgICogQHNlZSB7QGxpbmsgRWxsaXBzZS5jbG9uZX0gRm9yIGNyZWF0aW5nIG5ldyBlbGxpcHNlIGNvcHlcbiAgICovXG4gIGNvcHlGcm9tKGVsbGlwc2UpIHtcbiAgICB0aGlzLnggPSBlbGxpcHNlLng7XG4gICAgdGhpcy55ID0gZWxsaXBzZS55O1xuICAgIHRoaXMuaGFsZldpZHRoID0gZWxsaXBzZS5oYWxmV2lkdGg7XG4gICAgdGhpcy5oYWxmSGVpZ2h0ID0gZWxsaXBzZS5oYWxmSGVpZ2h0O1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBDb3BpZXMgdGhpcyBlbGxpcHNlIHRvIGFub3RoZXIgb25lLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb3B5aW5nXG4gICAqIGNvbnN0IHNvdXJjZSA9IG5ldyBFbGxpcHNlKDEwMCwgMTAwLCA1MCwgMjUpO1xuICAgKiBjb25zdCB0YXJnZXQgPSBuZXcgRWxsaXBzZSgpO1xuICAgKiBzb3VyY2UuY29weVRvKHRhcmdldCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gZWxsaXBzZSAtIFRoZSBlbGxpcHNlIHRvIGNvcHkgdG9cbiAgICogQHJldHVybnMgUmV0dXJucyBnaXZlbiBwYXJhbWV0ZXJcbiAgICogQHNlZSB7QGxpbmsgRWxsaXBzZS5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgZnJvbSBhbm90aGVyIGVsbGlwc2VcbiAgICogQHNlZSB7QGxpbmsgRWxsaXBzZS5jbG9uZX0gRm9yIGNyZWF0aW5nIG5ldyBlbGxpcHNlIGNvcHlcbiAgICovXG4gIGNvcHlUbyhlbGxpcHNlKSB7XG4gICAgZWxsaXBzZS5jb3B5RnJvbSh0aGlzKTtcbiAgICByZXR1cm4gZWxsaXBzZTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYFtwaXhpLmpzL21hdGg6RWxsaXBzZSB4PSR7dGhpcy54fSB5PSR7dGhpcy55fSBoYWxmV2lkdGg9JHt0aGlzLmhhbGZXaWR0aH0gaGFsZkhlaWdodD0ke3RoaXMuaGFsZkhlaWdodH1dYDtcbiAgfVxufVxuXG5leHBvcnQgeyBFbGxpcHNlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1FbGxpcHNlLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gZ2V0T3JpZW50YXRpb25PZlBvaW50cyhwb2ludHMpIHtcbiAgY29uc3QgbSA9IHBvaW50cy5sZW5ndGg7XG4gIGlmIChtIDwgNikge1xuICAgIHJldHVybiAxO1xuICB9XG4gIGxldCBhcmVhID0gMDtcbiAgZm9yIChsZXQgaSA9IDAsIHgxID0gcG9pbnRzW20gLSAyXSwgeTEgPSBwb2ludHNbbSAtIDFdOyBpIDwgbTsgaSArPSAyKSB7XG4gICAgY29uc3QgeDIgPSBwb2ludHNbaV07XG4gICAgY29uc3QgeTIgPSBwb2ludHNbaSArIDFdO1xuICAgIGFyZWEgKz0gKHgyIC0geDEpICogKHkyICsgeTEpO1xuICAgIHgxID0geDI7XG4gICAgeTEgPSB5MjtcbiAgfVxuICBpZiAoYXJlYSA8IDApIHtcbiAgICByZXR1cm4gLTE7XG4gIH1cbiAgcmV0dXJuIDE7XG59XG5cbmV4cG9ydCB7IGdldE9yaWVudGF0aW9uT2ZQb2ludHMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdldE9yaWVudGF0aW9uT2ZQb2ludHMubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBzcXVhcmVkRGlzdGFuY2VUb0xpbmVTZWdtZW50KHgsIHksIHgxLCB5MSwgeDIsIHkyKSB7XG4gIGNvbnN0IGEgPSB4IC0geDE7XG4gIGNvbnN0IGIgPSB5IC0geTE7XG4gIGNvbnN0IGMgPSB4MiAtIHgxO1xuICBjb25zdCBkID0geTIgLSB5MTtcbiAgY29uc3QgZG90ID0gYSAqIGMgKyBiICogZDtcbiAgY29uc3QgbGVuU3EgPSBjICogYyArIGQgKiBkO1xuICBsZXQgcGFyYW0gPSAtMTtcbiAgaWYgKGxlblNxICE9PSAwKSB7XG4gICAgcGFyYW0gPSBkb3QgLyBsZW5TcTtcbiAgfVxuICBsZXQgeHg7XG4gIGxldCB5eTtcbiAgaWYgKHBhcmFtIDwgMCkge1xuICAgIHh4ID0geDE7XG4gICAgeXkgPSB5MTtcbiAgfSBlbHNlIGlmIChwYXJhbSA+IDEpIHtcbiAgICB4eCA9IHgyO1xuICAgIHl5ID0geTI7XG4gIH0gZWxzZSB7XG4gICAgeHggPSB4MSArIHBhcmFtICogYztcbiAgICB5eSA9IHkxICsgcGFyYW0gKiBkO1xuICB9XG4gIGNvbnN0IGR4ID0geCAtIHh4O1xuICBjb25zdCBkeSA9IHkgLSB5eTtcbiAgcmV0dXJuIGR4ICogZHggKyBkeSAqIGR5O1xufVxuXG5leHBvcnQgeyBzcXVhcmVkRGlzdGFuY2VUb0xpbmVTZWdtZW50IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zcXVhcmVkRGlzdGFuY2VUb0xpbmVTZWdtZW50Lm1qcy5tYXBcbiIsImltcG9ydCB7IGRlcHJlY2F0aW9uIH0gZnJvbSAnLi4vLi4vdXRpbHMvbG9nZ2luZy9kZXByZWNhdGlvbi5tanMnO1xuaW1wb3J0IHsgZ2V0T3JpZW50YXRpb25PZlBvaW50cyB9IGZyb20gJy4uL21pc2MvZ2V0T3JpZW50YXRpb25PZlBvaW50cy5tanMnO1xuaW1wb3J0IHsgc3F1YXJlZERpc3RhbmNlVG9MaW5lU2VnbWVudCB9IGZyb20gJy4uL21pc2Mvc3F1YXJlZERpc3RhbmNlVG9MaW5lU2VnbWVudC5tanMnO1xuaW1wb3J0IHsgUmVjdGFuZ2xlIH0gZnJvbSAnLi9SZWN0YW5nbGUubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5sZXQgdGVtcFJlY3Q7XG5sZXQgdGVtcFJlY3QyO1xuY2xhc3MgUG9seWdvbiB7XG4gIC8qKlxuICAgKiBAcGFyYW0gcG9pbnRzIC0gVGhpcyBjYW4gYmUgYW4gYXJyYXkgb2YgUG9pbnRzXG4gICAqICB0aGF0IGZvcm0gdGhlIHBvbHlnb24sIGEgZmxhdCBhcnJheSBvZiBudW1iZXJzIHRoYXQgd2lsbCBiZSBpbnRlcnByZXRlZCBhcyBbeCx5LCB4LHksIC4uLl0sIG9yXG4gICAqICB0aGUgYXJndW1lbnRzIHBhc3NlZCBjYW4gYmUgYWxsIHRoZSBwb2ludHMgb2YgdGhlIHBvbHlnb24gZS5nLlxuICAgKiAgYG5ldyBQb2x5Z29uKG5ldyBQb2ludCgpLCBuZXcgUG9pbnQoKSwgLi4uKWAsIG9yIHRoZSBhcmd1bWVudHMgcGFzc2VkIGNhbiBiZSBmbGF0XG4gICAqICB4LHkgdmFsdWVzIGUuZy4gYG5ldyBQb2x5Z29uKHgseSwgeCx5LCB4LHksIC4uLilgIHdoZXJlIGB4YCBhbmQgYHlgIGFyZSBOdW1iZXJzLlxuICAgKi9cbiAgY29uc3RydWN0b3IoLi4ucG9pbnRzKSB7XG4gICAgLyoqXG4gICAgICogVGhlIHR5cGUgb2YgdGhlIG9iamVjdCwgbWFpbmx5IHVzZWQgdG8gYXZvaWQgYGluc3RhbmNlb2ZgIGNoZWNrc1xuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiAvLyBDaGVjayBzaGFwZSB0eXBlXG4gICAgICogY29uc3Qgc2hhcGUgPSBuZXcgUG9seWdvbihbMCwgMCwgMTAwLCAwLCA1MCwgMTAwXSk7XG4gICAgICogY29uc29sZS5sb2coc2hhcGUudHlwZSk7IC8vICdwb2x5Z29uJ1xuICAgICAqXG4gICAgICogLy8gVXNlIGluIHR5cGUgZ3VhcmRzXG4gICAgICogaWYgKHNoYXBlLnR5cGUgPT09ICdwb2x5Z29uJykge1xuICAgICAqICAgICAvLyBUeXBlU2NyaXB0IGtub3dzIHRoaXMgaXMgYSBQb2x5Z29uXG4gICAgICogICAgIGNvbnNvbGUubG9nKHNoYXBlLnBvaW50cy5sZW5ndGgpO1xuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgKiBAcmVhZG9ubHlcbiAgICAgKiBAZGVmYXVsdCAncG9seWdvbidcbiAgICAgKiBAc2VlIHtAbGluayBTSEFQRV9QUklNSVRJVkV9IEZvciBhbGwgc2hhcGUgdHlwZXNcbiAgICAgKi9cbiAgICB0aGlzLnR5cGUgPSBcInBvbHlnb25cIjtcbiAgICBsZXQgZmxhdCA9IEFycmF5LmlzQXJyYXkocG9pbnRzWzBdKSA/IHBvaW50c1swXSA6IHBvaW50cztcbiAgICBpZiAodHlwZW9mIGZsYXRbMF0gIT09IFwibnVtYmVyXCIpIHtcbiAgICAgIGNvbnN0IHAgPSBbXTtcbiAgICAgIGZvciAobGV0IGkgPSAwLCBpbCA9IGZsYXQubGVuZ3RoOyBpIDwgaWw7IGkrKykge1xuICAgICAgICBwLnB1c2goZmxhdFtpXS54LCBmbGF0W2ldLnkpO1xuICAgICAgfVxuICAgICAgZmxhdCA9IHA7XG4gICAgfVxuICAgIHRoaXMucG9pbnRzID0gZmxhdDtcbiAgICB0aGlzLmNsb3NlUGF0aCA9IHRydWU7XG4gIH1cbiAgLyoqXG4gICAqIERldGVybWluZXMgd2hldGhlciB0aGUgcG9seWdvbidzIHBvaW50cyBhcmUgYXJyYW5nZWQgaW4gYSBjbG9ja3dpc2UgZGlyZWN0aW9uLlxuICAgKiBVc2VzIHRoZSBzaG9lbGFjZSBmb3JtdWxhIChzdXJ2ZXlvcidzIGZvcm11bGEpIHRvIGNhbGN1bGF0ZSB0aGUgc2lnbmVkIGFyZWEuXG4gICAqXG4gICAqIEEgcG9zaXRpdmUgYXJlYSBpbmRpY2F0ZXMgY2xvY2t3aXNlIHdpbmRpbmcsIHdoaWxlIG5lZ2F0aXZlIGluZGljYXRlcyBjb3VudGVyLWNsb2Nrd2lzZS5cbiAgICpcbiAgICogVGhlIGZvcm11bGEgc3VtcyB1cCB0aGUgY3Jvc3MgcHJvZHVjdHMgb2YgYWRqYWNlbnQgdmVydGljZXM6XG4gICAqIEZvciBlYWNoIHBhaXIgb2YgYWRqYWNlbnQgcG9pbnRzICh4MSx5MSkgYW5kICh4Mix5MiksIHdlIGNhbGN1bGF0ZSAoeDEqeTIgLSB4Mip5MSlcbiAgICogVGhlIGZpbmFsIHN1bSBkaXZpZGVkIGJ5IDIgZ2l2ZXMgdGhlIHNpZ25lZCBhcmVhIC0gcG9zaXRpdmUgZm9yIGNsb2Nrd2lzZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQ2hlY2sgcG9seWdvbiB3aW5kaW5nXG4gICAqIGNvbnN0IHBvbHlnb24gPSBuZXcgUG9seWdvbihbMCwgMCwgMTAwLCAwLCA1MCwgMTAwXSk7XG4gICAqIGNvbnNvbGUubG9nKHBvbHlnb24uaXNDbG9ja3dpc2UoKSk7IC8vIENoZWNrIGRpcmVjdGlvblxuICAgKlxuICAgKiAvLyBVc2UgaW4gcGF0aCBjb25zdHJ1Y3Rpb25cbiAgICogY29uc3QgaG9sZSA9IG5ldyBQb2x5Z29uKFsyNSwgMjUsIDc1LCAyNSwgNzUsIDc1LCAyNSwgNzVdKTtcbiAgICogaWYgKGhvbGUuaXNDbG9ja3dpc2UoKSA9PT0gc2hhcGUuaXNDbG9ja3dpc2UoKSkge1xuICAgKiAgICAgaG9sZS5wb2ludHMucmV2ZXJzZSgpOyAvLyBSZXZlcnNlIGZvciBwcm9wZXIgaG9sZSB3aW5kaW5nXG4gICAqIH1cbiAgICogYGBgXG4gICAqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcG9seWdvbidzIHBvaW50cyBhcmUgYXJyYW5nZWQgY2xvY2t3aXNlLCBgZmFsc2VgIGlmIGNvdW50ZXItY2xvY2t3aXNlXG4gICAqL1xuICBpc0Nsb2Nrd2lzZSgpIHtcbiAgICBsZXQgYXJlYSA9IDA7XG4gICAgY29uc3QgcG9pbnRzID0gdGhpcy5wb2ludHM7XG4gICAgY29uc3QgbGVuZ3RoID0gcG9pbnRzLmxlbmd0aDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSArPSAyKSB7XG4gICAgICBjb25zdCB4MSA9IHBvaW50c1tpXTtcbiAgICAgIGNvbnN0IHkxID0gcG9pbnRzW2kgKyAxXTtcbiAgICAgIGNvbnN0IHgyID0gcG9pbnRzWyhpICsgMikgJSBsZW5ndGhdO1xuICAgICAgY29uc3QgeTIgPSBwb2ludHNbKGkgKyAzKSAlIGxlbmd0aF07XG4gICAgICBhcmVhICs9ICh4MiAtIHgxKSAqICh5MiArIHkxKTtcbiAgICB9XG4gICAgcmV0dXJuIGFyZWEgPCAwO1xuICB9XG4gIC8qKlxuICAgKiBDaGVja3MgaWYgdGhpcyBwb2x5Z29uIGNvbXBsZXRlbHkgY29udGFpbnMgYW5vdGhlciBwb2x5Z29uLlxuICAgKiBVc2VkIGZvciBkZXRlY3RpbmcgaG9sZXMgaW4gc2hhcGVzLCBsaWtlIHdoZW4gcGFyc2luZyBTVkcgcGF0aHMuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNvbnRhaW5tZW50IGNoZWNrXG4gICAqIGNvbnN0IG91dGVyU3F1YXJlID0gbmV3IFBvbHlnb24oWzAsMCwgMTAwLDAsIDEwMCwxMDAsIDAsMTAwXSk7IC8vIEEgc3F1YXJlXG4gICAqIGNvbnN0IGlubmVyU3F1YXJlID0gbmV3IFBvbHlnb24oWzI1LDI1LCA3NSwyNSwgNzUsNzUsIDI1LDc1XSk7IC8vIEEgc21hbGxlciBzcXVhcmUgaW5zaWRlXG4gICAqXG4gICAqIG91dGVyU3F1YXJlLmNvbnRhaW5zUG9seWdvbihpbm5lclNxdWFyZSk7IC8vIFJldHVybnMgdHJ1ZVxuICAgKiBpbm5lclNxdWFyZS5jb250YWluc1BvbHlnb24ob3V0ZXJTcXVhcmUpOyAvLyBSZXR1cm5zIGZhbHNlXG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFVzZXMgYm91bmRzIGNoZWNrIGZvciBxdWljayByZWplY3Rpb25cbiAgICogLSBUZXN0cyBhbGwgcG9pbnRzIGZvciBjb250YWlubWVudFxuICAgKiBAcGFyYW0gcG9seWdvbiAtIFRoZSBwb2x5Z29uIHRvIHRlc3QgZm9yIGNvbnRhaW5tZW50XG4gICAqIEByZXR1cm5zIFRydWUgaWYgdGhpcyBwb2x5Z29uIGNvbXBsZXRlbHkgY29udGFpbnMgdGhlIG90aGVyIHBvbHlnb25cbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5jb250YWluc30gRm9yIHNpbmdsZSBwb2ludCB0ZXN0aW5nXG4gICAqIEBzZWUge0BsaW5rIFBvbHlnb24uZ2V0Qm91bmRzfSBGb3IgYm91bmRzIGNhbGN1bGF0aW9uXG4gICAqL1xuICBjb250YWluc1BvbHlnb24ocG9seWdvbikge1xuICAgIGNvbnN0IHRoaXNCb3VuZHMgPSB0aGlzLmdldEJvdW5kcyh0ZW1wUmVjdCk7XG4gICAgY29uc3Qgb3RoZXJCb3VuZHMgPSBwb2x5Z29uLmdldEJvdW5kcyh0ZW1wUmVjdDIpO1xuICAgIGlmICghdGhpc0JvdW5kcy5jb250YWluc1JlY3Qob3RoZXJCb3VuZHMpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHBvaW50cyA9IHBvbHlnb24ucG9pbnRzO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcG9pbnRzLmxlbmd0aDsgaSArPSAyKSB7XG4gICAgICBjb25zdCB4ID0gcG9pbnRzW2ldO1xuICAgICAgY29uc3QgeSA9IHBvaW50c1tpICsgMV07XG4gICAgICBpZiAoIXRoaXMuY29udGFpbnMoeCwgeSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBhIGNsb25lIG9mIHRoaXMgcG9seWdvbi5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY2xvbmluZ1xuICAgKiBjb25zdCBvcmlnaW5hbCA9IG5ldyBQb2x5Z29uKFswLCAwLCAxMDAsIDAsIDUwLCAxMDBdKTtcbiAgICogY29uc3QgY29weSA9IG9yaWdpbmFsLmNsb25lKCk7XG4gICAqXG4gICAqIC8vIENsb25lIGFuZCBtb2RpZnlcbiAgICogY29uc3QgbW9kaWZpZWQgPSBvcmlnaW5hbC5jbG9uZSgpO1xuICAgKiBtb2RpZmllZC5wb2ludHNbMF0gPSAxMDsgLy8gTW9kaWZ5IGZpcnN0IHggY29vcmRpbmF0ZVxuICAgKiBgYGBcbiAgICogQHJldHVybnMgQSBjb3B5IG9mIHRoZSBwb2x5Z29uXG4gICAqIEBzZWUge0BsaW5rIFBvbHlnb24uY29weUZyb219IEZvciBjb3B5aW5nIGludG8gZXhpc3RpbmcgcG9seWdvblxuICAgKiBAc2VlIHtAbGluayBQb2x5Z29uLmNvcHlUb30gRm9yIGNvcHlpbmcgdG8gYW5vdGhlciBwb2x5Z29uXG4gICAqL1xuICBjbG9uZSgpIHtcbiAgICBjb25zdCBwb2ludHMgPSB0aGlzLnBvaW50cy5zbGljZSgpO1xuICAgIGNvbnN0IHBvbHlnb24gPSBuZXcgUG9seWdvbihwb2ludHMpO1xuICAgIHBvbHlnb24uY2xvc2VQYXRoID0gdGhpcy5jbG9zZVBhdGg7XG4gICAgcmV0dXJuIHBvbHlnb247XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyB3aGV0aGVyIHRoZSB4IGFuZCB5IGNvb3JkaW5hdGVzIHBhc3NlZCB0byB0aGlzIGZ1bmN0aW9uIGFyZSBjb250YWluZWQgd2l0aGluIHRoaXMgcG9seWdvbi5cbiAgICogVXNlcyByYXljYXN0aW5nIGFsZ29yaXRobSBmb3IgcG9pbnQtaW4tcG9seWdvbiB0ZXN0aW5nLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb250YWlubWVudCBjaGVja1xuICAgKiBjb25zdCBwb2x5Z29uID0gbmV3IFBvbHlnb24oWzAsIDAsIDEwMCwgMCwgNTAsIDEwMF0pO1xuICAgKiBjb25zdCBpc0luc2lkZSA9IHBvbHlnb24uY29udGFpbnMoMjUsIDI1KTsgLy8gdHJ1ZVxuICAgKiBgYGBcbiAgICogQHBhcmFtIHggLSBUaGUgWCBjb29yZGluYXRlIG9mIHRoZSBwb2ludCB0byB0ZXN0XG4gICAqIEBwYXJhbSB5IC0gVGhlIFkgY29vcmRpbmF0ZSBvZiB0aGUgcG9pbnQgdG8gdGVzdFxuICAgKiBAcmV0dXJucyBXaGV0aGVyIHRoZSB4L3kgY29vcmRpbmF0ZXMgYXJlIHdpdGhpbiB0aGlzIHBvbHlnb25cbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5zdHJva2VDb250YWluc30gRm9yIGNoZWNraW5nIHN0cm9rZSBpbnRlcnNlY3Rpb25cbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5jb250YWluc1BvbHlnb259IEZvciBwb2x5Z29uLWluLXBvbHlnb24gdGVzdGluZ1xuICAgKi9cbiAgY29udGFpbnMoeCwgeSkge1xuICAgIGxldCBpbnNpZGUgPSBmYWxzZTtcbiAgICBjb25zdCBsZW5ndGggPSB0aGlzLnBvaW50cy5sZW5ndGggLyAyO1xuICAgIGZvciAobGV0IGkgPSAwLCBqID0gbGVuZ3RoIC0gMTsgaSA8IGxlbmd0aDsgaiA9IGkrKykge1xuICAgICAgY29uc3QgeGkgPSB0aGlzLnBvaW50c1tpICogMl07XG4gICAgICBjb25zdCB5aSA9IHRoaXMucG9pbnRzW2kgKiAyICsgMV07XG4gICAgICBjb25zdCB4aiA9IHRoaXMucG9pbnRzW2ogKiAyXTtcbiAgICAgIGNvbnN0IHlqID0gdGhpcy5wb2ludHNbaiAqIDIgKyAxXTtcbiAgICAgIGNvbnN0IGludGVyc2VjdCA9IHlpID4geSAhPT0geWogPiB5ICYmIHggPCAoeGogLSB4aSkgKiAoKHkgLSB5aSkgLyAoeWogLSB5aSkpICsgeGk7XG4gICAgICBpZiAoaW50ZXJzZWN0KSB7XG4gICAgICAgIGluc2lkZSA9ICFpbnNpZGU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBpbnNpZGU7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyB3aGV0aGVyIHRoZSB4IGFuZCB5IGNvb3JkaW5hdGVzIGdpdmVuIGFyZSBjb250YWluZWQgd2l0aGluIHRoaXMgcG9seWdvbiBpbmNsdWRpbmcgdGhlIHN0cm9rZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgc3Ryb2tlIGNoZWNrXG4gICAqIGNvbnN0IHBvbHlnb24gPSBuZXcgUG9seWdvbihbMCwgMCwgMTAwLCAwLCA1MCwgMTAwXSk7XG4gICAqIGNvbnN0IGlzT25TdHJva2UgPSBwb2x5Z29uLnN0cm9rZUNvbnRhaW5zKDI1LCAyNSwgNCk7IC8vIDRweCBsaW5lIHdpZHRoXG4gICAqXG4gICAqIC8vIENoZWNrIHdpdGggZGlmZmVyZW50IGFsaWdubWVudHNcbiAgICogY29uc3QgaW5uZXJTdHJva2UgPSBwb2x5Z29uLnN0cm9rZUNvbnRhaW5zKDI1LCAyNSwgNCwgMSk7ICAgLy8gSW5zaWRlXG4gICAqIGNvbnN0IGNlbnRlclN0cm9rZSA9IHBvbHlnb24uc3Ryb2tlQ29udGFpbnMoMjUsIDI1LCA0LCAwLjUpOyAvLyBDZW50ZXJlZFxuICAgKiBjb25zdCBvdXRlclN0cm9rZSA9IHBvbHlnb24uc3Ryb2tlQ29udGFpbnMoMjUsIDI1LCA0LCAwKTsgICAvLyBPdXRzaWRlXG4gICAqIGBgYFxuICAgKiBAcGFyYW0geCAtIFRoZSBYIGNvb3JkaW5hdGUgb2YgdGhlIHBvaW50IHRvIHRlc3RcbiAgICogQHBhcmFtIHkgLSBUaGUgWSBjb29yZGluYXRlIG9mIHRoZSBwb2ludCB0byB0ZXN0XG4gICAqIEBwYXJhbSBzdHJva2VXaWR0aCAtIFRoZSB3aWR0aCBvZiB0aGUgbGluZSB0byBjaGVja1xuICAgKiBAcGFyYW0gYWxpZ25tZW50IC0gVGhlIGFsaWdubWVudCBvZiB0aGUgc3Ryb2tlICgxID0gaW5uZXIsIDAuNSA9IGNlbnRlcmVkLCAwID0gb3V0ZXIpXG4gICAqIEByZXR1cm5zIFdoZXRoZXIgdGhlIHgveSBjb29yZGluYXRlcyBhcmUgd2l0aGluIHRoaXMgcG9seWdvbidzIHN0cm9rZVxuICAgKiBAc2VlIHtAbGluayBQb2x5Z29uLmNvbnRhaW5zfSBGb3IgY2hlY2tpbmcgZmlsbCBjb250YWlubWVudFxuICAgKiBAc2VlIHtAbGluayBQb2x5Z29uLmdldEJvdW5kc30gRm9yIGdldHRpbmcgc3Ryb2tlIGJvdW5kc1xuICAgKi9cbiAgc3Ryb2tlQ29udGFpbnMoeCwgeSwgc3Ryb2tlV2lkdGgsIGFsaWdubWVudCA9IDAuNSkge1xuICAgIGNvbnN0IHsgcG9pbnRzIH0gPSB0aGlzO1xuICAgIGNvbnN0IGFsaWduZWRCeVdpbmRpbmcgPSBhbGlnbm1lbnQgPT09IDAuNSA/IGFsaWdubWVudCA6IChhbGlnbm1lbnQgLSAwLjUpICogZ2V0T3JpZW50YXRpb25PZlBvaW50cyhwb2ludHMpICsgMC41O1xuICAgIGNvbnN0IG91dGVyV2lkdGggPSBzdHJva2VXaWR0aCAqIGFsaWduZWRCeVdpbmRpbmc7XG4gICAgY29uc3QgaW5uZXJXaWR0aCA9IHN0cm9rZVdpZHRoIC0gb3V0ZXJXaWR0aDtcbiAgICBjb25zdCBvdXRlcldpZHRoU3F1YXJlZCA9IG91dGVyV2lkdGggKiBvdXRlcldpZHRoO1xuICAgIGNvbnN0IGlubmVyV2lkdGhTcXVhcmVkID0gaW5uZXJXaWR0aCAqIGlubmVyV2lkdGg7XG4gICAgY29uc3QgaXRlcmF0aW9uTGVuZ3RoID0gcG9pbnRzLmxlbmd0aCAtICh0aGlzLmNsb3NlUGF0aCA/IDAgOiAyKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZXJhdGlvbkxlbmd0aDsgaSArPSAyKSB7XG4gICAgICBjb25zdCB4MSA9IHBvaW50c1tpXTtcbiAgICAgIGNvbnN0IHkxID0gcG9pbnRzW2kgKyAxXTtcbiAgICAgIGNvbnN0IHgyID0gcG9pbnRzWyhpICsgMikgJSBwb2ludHMubGVuZ3RoXTtcbiAgICAgIGNvbnN0IHkyID0gcG9pbnRzWyhpICsgMykgJSBwb2ludHMubGVuZ3RoXTtcbiAgICAgIGNvbnN0IGRpc3RhbmNlU3F1YXJlZCA9IHNxdWFyZWREaXN0YW5jZVRvTGluZVNlZ21lbnQoeCwgeSwgeDEsIHkxLCB4MiwgeTIpO1xuICAgICAgY29uc3Qgc2lnbiA9IE1hdGguc2lnbigoeDIgLSB4MSkgKiAoeSAtIHkxKSAtICh5MiAtIHkxKSAqICh4IC0geDEpKTtcbiAgICAgIGlmIChkaXN0YW5jZVNxdWFyZWQgPD0gKHNpZ24gPCAwID8gb3V0ZXJXaWR0aFNxdWFyZWQgOiBpbm5lcldpZHRoU3F1YXJlZCkpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgZnJhbWluZyByZWN0YW5nbGUgb2YgdGhlIHBvbHlnb24gYXMgYSBSZWN0YW5nbGUgb2JqZWN0LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBib3VuZHMgY2FsY3VsYXRpb25cbiAgICogY29uc3QgcG9seWdvbiA9IG5ldyBQb2x5Z29uKFswLCAwLCAxMDAsIDAsIDUwLCAxMDBdKTtcbiAgICogY29uc3QgYm91bmRzID0gcG9seWdvbi5nZXRCb3VuZHMoKTtcbiAgICogLy8gYm91bmRzOiB4PTAsIHk9MCwgd2lkdGg9MTAwLCBoZWlnaHQ9MTAwXG4gICAqXG4gICAqIC8vIFJldXNlIGV4aXN0aW5nIHJlY3RhbmdsZVxuICAgKiBjb25zdCByZWN0ID0gbmV3IFJlY3RhbmdsZSgpO1xuICAgKiBwb2x5Z29uLmdldEJvdW5kcyhyZWN0KTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSBvdXQgLSBPcHRpb25hbCByZWN0YW5nbGUgdG8gc3RvcmUgdGhlIHJlc3VsdFxuICAgKiBAcmV0dXJucyBUaGUgZnJhbWluZyByZWN0YW5nbGVcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlfSBGb3IgcmVjdGFuZ2xlIHByb3BlcnRpZXNcbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5jb250YWluc30gRm9yIGNoZWNraW5nIGlmIGEgcG9pbnQgaXMgaW5zaWRlXG4gICAqL1xuICBnZXRCb3VuZHMob3V0KSB7XG4gICAgb3V0IHx8IChvdXQgPSBuZXcgUmVjdGFuZ2xlKCkpO1xuICAgIGNvbnN0IHBvaW50cyA9IHRoaXMucG9pbnRzO1xuICAgIGxldCBtaW5YID0gSW5maW5pdHk7XG4gICAgbGV0IG1heFggPSAtSW5maW5pdHk7XG4gICAgbGV0IG1pblkgPSBJbmZpbml0eTtcbiAgICBsZXQgbWF4WSA9IC1JbmZpbml0eTtcbiAgICBmb3IgKGxldCBpID0gMCwgbiA9IHBvaW50cy5sZW5ndGg7IGkgPCBuOyBpICs9IDIpIHtcbiAgICAgIGNvbnN0IHggPSBwb2ludHNbaV07XG4gICAgICBjb25zdCB5ID0gcG9pbnRzW2kgKyAxXTtcbiAgICAgIG1pblggPSB4IDwgbWluWCA/IHggOiBtaW5YO1xuICAgICAgbWF4WCA9IHggPiBtYXhYID8geCA6IG1heFg7XG4gICAgICBtaW5ZID0geSA8IG1pblkgPyB5IDogbWluWTtcbiAgICAgIG1heFkgPSB5ID4gbWF4WSA/IHkgOiBtYXhZO1xuICAgIH1cbiAgICBvdXQueCA9IG1pblg7XG4gICAgb3V0LndpZHRoID0gbWF4WCAtIG1pblg7XG4gICAgb3V0LnkgPSBtaW5ZO1xuICAgIG91dC5oZWlnaHQgPSBtYXhZIC0gbWluWTtcbiAgICByZXR1cm4gb3V0O1xuICB9XG4gIC8qKlxuICAgKiBDb3BpZXMgYW5vdGhlciBwb2x5Z29uIHRvIHRoaXMgb25lLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb3B5aW5nXG4gICAqIGNvbnN0IHNvdXJjZSA9IG5ldyBQb2x5Z29uKFswLCAwLCAxMDAsIDAsIDUwLCAxMDBdKTtcbiAgICogY29uc3QgdGFyZ2V0ID0gbmV3IFBvbHlnb24oKTtcbiAgICogdGFyZ2V0LmNvcHlGcm9tKHNvdXJjZSk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcG9seWdvbiAtIFRoZSBwb2x5Z29uIHRvIGNvcHkgZnJvbVxuICAgKiBAcmV0dXJucyBSZXR1cm5zIGl0c2VsZlxuICAgKiBAc2VlIHtAbGluayBQb2x5Z29uLmNvcHlUb30gRm9yIGNvcHlpbmcgdG8gYW5vdGhlciBwb2x5Z29uXG4gICAqIEBzZWUge0BsaW5rIFBvbHlnb24uY2xvbmV9IEZvciBjcmVhdGluZyBuZXcgcG9seWdvbiBjb3B5XG4gICAqL1xuICBjb3B5RnJvbShwb2x5Z29uKSB7XG4gICAgdGhpcy5wb2ludHMgPSBwb2x5Z29uLnBvaW50cy5zbGljZSgpO1xuICAgIHRoaXMuY2xvc2VQYXRoID0gcG9seWdvbi5jbG9zZVBhdGg7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENvcGllcyB0aGlzIHBvbHlnb24gdG8gYW5vdGhlciBvbmUuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNvcHlpbmdcbiAgICogY29uc3Qgc291cmNlID0gbmV3IFBvbHlnb24oWzAsIDAsIDEwMCwgMCwgNTAsIDEwMF0pO1xuICAgKiBjb25zdCB0YXJnZXQgPSBuZXcgUG9seWdvbigpO1xuICAgKiBzb3VyY2UuY29weVRvKHRhcmdldCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcG9seWdvbiAtIFRoZSBwb2x5Z29uIHRvIGNvcHkgdG9cbiAgICogQHJldHVybnMgUmV0dXJucyBnaXZlbiBwYXJhbWV0ZXJcbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgZnJvbSBhbm90aGVyIHBvbHlnb25cbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5jbG9uZX0gRm9yIGNyZWF0aW5nIG5ldyBwb2x5Z29uIGNvcHlcbiAgICovXG4gIGNvcHlUbyhwb2x5Z29uKSB7XG4gICAgcG9seWdvbi5jb3B5RnJvbSh0aGlzKTtcbiAgICByZXR1cm4gcG9seWdvbjtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYFtwaXhpLmpzL21hdGg6UG9seWdvbmNsb3NlU3Ryb2tlPSR7dGhpcy5jbG9zZVBhdGh9cG9pbnRzPSR7dGhpcy5wb2ludHMucmVkdWNlKChwb2ludHNEZXNjLCBjdXJyZW50UG9pbnQpID0+IGAke3BvaW50c0Rlc2N9LCAke2N1cnJlbnRQb2ludH1gLCBcIlwiKX1dYDtcbiAgfVxuICAvKipcbiAgICogR2V0IHRoZSBsYXN0IFggY29vcmRpbmF0ZSBvZiB0aGUgcG9seWdvbi5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY29vcmRpbmF0ZSBhY2Nlc3NcbiAgICogY29uc3QgcG9seWdvbiA9IG5ldyBQb2x5Z29uKFswLCAwLCAxMDAsIDIwMCwgMzAwLCA0MDBdKTtcbiAgICogY29uc29sZS5sb2cocG9seWdvbi5sYXN0WCk7IC8vIDMwMFxuICAgKiBgYGBcbiAgICogQHJlYWRvbmx5XG4gICAqIEByZXR1cm5zIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGxhc3QgdmVydGV4XG4gICAqIEBzZWUge0BsaW5rIFBvbHlnb24ubGFzdFl9IEZvciBsYXN0IFkgY29vcmRpbmF0ZVxuICAgKiBAc2VlIHtAbGluayBQb2x5Z29uLnBvaW50c30gRm9yIHJhdyBwb2ludHMgYXJyYXlcbiAgICovXG4gIGdldCBsYXN0WCgpIHtcbiAgICByZXR1cm4gdGhpcy5wb2ludHNbdGhpcy5wb2ludHMubGVuZ3RoIC0gMl07XG4gIH1cbiAgLyoqXG4gICAqIEdldCB0aGUgbGFzdCBZIGNvb3JkaW5hdGUgb2YgdGhlIHBvbHlnb24uXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNvb3JkaW5hdGUgYWNjZXNzXG4gICAqIGNvbnN0IHBvbHlnb24gPSBuZXcgUG9seWdvbihbMCwgMCwgMTAwLCAyMDAsIDMwMCwgNDAwXSk7XG4gICAqIGNvbnNvbGUubG9nKHBvbHlnb24ubGFzdFkpOyAvLyA0MDBcbiAgICogYGBgXG4gICAqIEByZWFkb25seVxuICAgKiBAcmV0dXJucyBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBsYXN0IHZlcnRleFxuICAgKiBAc2VlIHtAbGluayBQb2x5Z29uLmxhc3RYfSBGb3IgbGFzdCBYIGNvb3JkaW5hdGVcbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5wb2ludHN9IEZvciByYXcgcG9pbnRzIGFycmF5XG4gICAqL1xuICBnZXQgbGFzdFkoKSB7XG4gICAgcmV0dXJuIHRoaXMucG9pbnRzW3RoaXMucG9pbnRzLmxlbmd0aCAtIDFdO1xuICB9XG4gIC8qKlxuICAgKiBHZXQgdGhlIGxhc3QgWCBjb29yZGluYXRlIG9mIHRoZSBwb2x5Z29uLlxuICAgKiBAcmVhZG9ubHlcbiAgICogQGRlcHJlY2F0ZWQgc2luY2UgOC4xMS4wLCB1c2Uge0BsaW5rIFBvbHlnb24ubGFzdFh9IGluc3RlYWQuXG4gICAqL1xuICBnZXQgeCgpIHtcbiAgICBkZXByZWNhdGlvbihcIjguMTEuMFwiLCBcIlBvbHlnb24ubGFzdFggaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSBQb2x5Z29uLmxhc3RYIGluc3RlYWQuXCIpO1xuICAgIHJldHVybiB0aGlzLnBvaW50c1t0aGlzLnBvaW50cy5sZW5ndGggLSAyXTtcbiAgfVxuICAvKipcbiAgICogR2V0IHRoZSBsYXN0IFkgY29vcmRpbmF0ZSBvZiB0aGUgcG9seWdvbi5cbiAgICogQHJlYWRvbmx5XG4gICAqIEBkZXByZWNhdGVkIHNpbmNlIDguMTEuMCwgdXNlIHtAbGluayBQb2x5Z29uLmxhc3RZfSBpbnN0ZWFkLlxuICAgKi9cbiAgZ2V0IHkoKSB7XG4gICAgZGVwcmVjYXRpb24oXCI4LjExLjBcIiwgXCJQb2x5Z29uLnkgaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSBQb2x5Z29uLmxhc3RZIGluc3RlYWQuXCIpO1xuICAgIHJldHVybiB0aGlzLnBvaW50c1t0aGlzLnBvaW50cy5sZW5ndGggLSAxXTtcbiAgfVxuICAvKipcbiAgICogR2V0IHRoZSBmaXJzdCBYIGNvb3JkaW5hdGUgb2YgdGhlIHBvbHlnb24uXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNvb3JkaW5hdGUgYWNjZXNzXG4gICAqIGNvbnN0IHBvbHlnb24gPSBuZXcgUG9seWdvbihbMCwgMCwgMTAwLCAyMDAsIDMwMCwgNDAwXSk7XG4gICAqIGNvbnNvbGUubG9nKHBvbHlnb24ueCk7IC8vIDBcbiAgICogYGBgXG4gICAqIEByZWFkb25seVxuICAgKiBAcmV0dXJucyBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBmaXJzdCB2ZXJ0ZXhcbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5zdGFydFl9IEZvciBmaXJzdCBZIGNvb3JkaW5hdGVcbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5wb2ludHN9IEZvciByYXcgcG9pbnRzIGFycmF5XG4gICAqL1xuICBnZXQgc3RhcnRYKCkge1xuICAgIHJldHVybiB0aGlzLnBvaW50c1swXTtcbiAgfVxuICAvKipcbiAgICogR2V0IHRoZSBmaXJzdCBZIGNvb3JkaW5hdGUgb2YgdGhlIHBvbHlnb24uXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNvb3JkaW5hdGUgYWNjZXNzXG4gICAqIGNvbnN0IHBvbHlnb24gPSBuZXcgUG9seWdvbihbMCwgMCwgMTAwLCAyMDAsIDMwMCwgNDAwXSk7XG4gICAqIGNvbnNvbGUubG9nKHBvbHlnb24ueSk7IC8vIDBcbiAgICogYGBgXG4gICAqIEByZWFkb25seVxuICAgKiBAcmV0dXJucyBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBmaXJzdCB2ZXJ0ZXhcbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5zdGFydFh9IEZvciBmaXJzdCBYIGNvb3JkaW5hdGVcbiAgICogQHNlZSB7QGxpbmsgUG9seWdvbi5wb2ludHN9IEZvciByYXcgcG9pbnRzIGFycmF5XG4gICAqL1xuICBnZXQgc3RhcnRZKCkge1xuICAgIHJldHVybiB0aGlzLnBvaW50c1sxXTtcbiAgfVxufVxuXG5leHBvcnQgeyBQb2x5Z29uIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1Qb2x5Z29uLm1qcy5tYXBcbiIsImltcG9ydCB7IFJlY3RhbmdsZSB9IGZyb20gJy4vUmVjdGFuZ2xlLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgaXNDb3JuZXJXaXRoaW5TdHJva2UgPSAocFgsIHBZLCBjb3JuZXJYLCBjb3JuZXJZLCByYWRpdXMsIHN0cm9rZVdpZHRoSW5uZXIsIHN0cm9rZVdpZHRoT3V0ZXIpID0+IHtcbiAgY29uc3QgZHggPSBwWCAtIGNvcm5lclg7XG4gIGNvbnN0IGR5ID0gcFkgLSBjb3JuZXJZO1xuICBjb25zdCBkaXN0YW5jZSA9IE1hdGguc3FydChkeCAqIGR4ICsgZHkgKiBkeSk7XG4gIHJldHVybiBkaXN0YW5jZSA+PSByYWRpdXMgLSBzdHJva2VXaWR0aElubmVyICYmIGRpc3RhbmNlIDw9IHJhZGl1cyArIHN0cm9rZVdpZHRoT3V0ZXI7XG59O1xuY2xhc3MgUm91bmRlZFJlY3RhbmdsZSB7XG4gIC8qKlxuICAgKiBAcGFyYW0geCAtIFRoZSBYIGNvb3JkaW5hdGUgb2YgdGhlIHVwcGVyLWxlZnQgY29ybmVyIG9mIHRoZSByb3VuZGVkIHJlY3RhbmdsZVxuICAgKiBAcGFyYW0geSAtIFRoZSBZIGNvb3JkaW5hdGUgb2YgdGhlIHVwcGVyLWxlZnQgY29ybmVyIG9mIHRoZSByb3VuZGVkIHJlY3RhbmdsZVxuICAgKiBAcGFyYW0gd2lkdGggLSBUaGUgb3ZlcmFsbCB3aWR0aCBvZiB0aGlzIHJvdW5kZWQgcmVjdGFuZ2xlXG4gICAqIEBwYXJhbSBoZWlnaHQgLSBUaGUgb3ZlcmFsbCBoZWlnaHQgb2YgdGhpcyByb3VuZGVkIHJlY3RhbmdsZVxuICAgKiBAcGFyYW0gcmFkaXVzIC0gQ29udHJvbHMgdGhlIHJhZGl1cyBvZiB0aGUgcm91bmRlZCBjb3JuZXJzXG4gICAqL1xuICBjb25zdHJ1Y3Rvcih4ID0gMCwgeSA9IDAsIHdpZHRoID0gMCwgaGVpZ2h0ID0gMCwgcmFkaXVzID0gMjApIHtcbiAgICAvKipcbiAgICAgKiBUaGUgdHlwZSBvZiB0aGUgb2JqZWN0LCBtYWlubHkgdXNlZCB0byBhdm9pZCBgaW5zdGFuY2VvZmAgY2hlY2tzXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIC8vIENoZWNrIHNoYXBlIHR5cGVcbiAgICAgKiBjb25zdCBzaGFwZSA9IG5ldyBSb3VuZGVkUmVjdGFuZ2xlKDAsIDAsIDEwMCwgMTAwLCAyMCk7XG4gICAgICogY29uc29sZS5sb2coc2hhcGUudHlwZSk7IC8vICdyb3VuZGVkUmVjdGFuZ2xlJ1xuICAgICAqXG4gICAgICogLy8gVXNlIGluIHR5cGUgZ3VhcmRzXG4gICAgICogaWYgKHNoYXBlLnR5cGUgPT09ICdyb3VuZGVkUmVjdGFuZ2xlJykge1xuICAgICAqICAgICBjb25zb2xlLmxvZyhzaGFwZS5yYWRpdXMpO1xuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgKiBAcmVhZG9ubHlcbiAgICAgKiBAZGVmYXVsdCAncm91bmRlZFJlY3RhbmdsZSdcbiAgICAgKiBAc2VlIHtAbGluayBTSEFQRV9QUklNSVRJVkV9IEZvciBhbGwgc2hhcGUgdHlwZXNcbiAgICAgKi9cbiAgICB0aGlzLnR5cGUgPSBcInJvdW5kZWRSZWN0YW5nbGVcIjtcbiAgICB0aGlzLnggPSB4O1xuICAgIHRoaXMueSA9IHk7XG4gICAgdGhpcy53aWR0aCA9IHdpZHRoO1xuICAgIHRoaXMuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgIHRoaXMucmFkaXVzID0gcmFkaXVzO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBmcmFtaW5nIHJlY3RhbmdsZSBvZiB0aGUgcm91bmRlZCByZWN0YW5nbGUgYXMgYSBSZWN0YW5nbGUgb2JqZWN0XG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGJvdW5kcyBjYWxjdWxhdGlvblxuICAgKiBjb25zdCByZWN0ID0gbmV3IFJvdW5kZWRSZWN0YW5nbGUoMTAwLCAxMDAsIDIwMCwgMTUwLCAyMCk7XG4gICAqIGNvbnN0IGJvdW5kcyA9IHJlY3QuZ2V0Qm91bmRzKCk7XG4gICAqIC8vIGJvdW5kczogeD0xMDAsIHk9MTAwLCB3aWR0aD0yMDAsIGhlaWdodD0xNTBcbiAgICpcbiAgICogLy8gUmV1c2UgZXhpc3RpbmcgcmVjdGFuZ2xlXG4gICAqIGNvbnN0IG91dCA9IG5ldyBSZWN0YW5nbGUoKTtcbiAgICogcmVjdC5nZXRCb3VuZHMob3V0KTtcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gUmVjdGFuZ2xlIG1hdGNoZXMgb3V0ZXIgZGltZW5zaW9uc1xuICAgKiAtIElnbm9yZXMgY29ybmVyIHJhZGl1c1xuICAgKiBAcGFyYW0gb3V0IC0gT3B0aW9uYWwgcmVjdGFuZ2xlIHRvIHN0b3JlIHRoZSByZXN1bHRcbiAgICogQHJldHVybnMgVGhlIGZyYW1pbmcgcmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZX0gRm9yIHJlY3RhbmdsZSBwcm9wZXJ0aWVzXG4gICAqIEBzZWUge0BsaW5rIFJvdW5kZWRSZWN0YW5nbGUuY29udGFpbnN9IEZvciBjaGVja2luZyBpZiBhIHBvaW50IGlzIGluc2lkZVxuICAgKi9cbiAgZ2V0Qm91bmRzKG91dCkge1xuICAgIG91dCB8fCAob3V0ID0gbmV3IFJlY3RhbmdsZSgpKTtcbiAgICBvdXQueCA9IHRoaXMueDtcbiAgICBvdXQueSA9IHRoaXMueTtcbiAgICBvdXQud2lkdGggPSB0aGlzLndpZHRoO1xuICAgIG91dC5oZWlnaHQgPSB0aGlzLmhlaWdodDtcbiAgICByZXR1cm4gb3V0O1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgY2xvbmUgb2YgdGhpcyBSb3VuZGVkIFJlY3RhbmdsZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY2xvbmluZ1xuICAgKiBjb25zdCBvcmlnaW5hbCA9IG5ldyBSb3VuZGVkUmVjdGFuZ2xlKDEwMCwgMTAwLCAyMDAsIDE1MCwgMjApO1xuICAgKiBjb25zdCBjb3B5ID0gb3JpZ2luYWwuY2xvbmUoKTtcbiAgICpcbiAgICogLy8gQ2xvbmUgYW5kIG1vZGlmeVxuICAgKiBjb25zdCBtb2RpZmllZCA9IG9yaWdpbmFsLmNsb25lKCk7XG4gICAqIG1vZGlmaWVkLnJhZGl1cyA9IDMwO1xuICAgKiBtb2RpZmllZC53aWR0aCAqPSAyO1xuICAgKlxuICAgKiAvLyBWZXJpZnkgaW5kZXBlbmRlbmNlXG4gICAqIGNvbnNvbGUubG9nKG9yaWdpbmFsLnJhZGl1cyk7ICAvLyAyMFxuICAgKiBjb25zb2xlLmxvZyhtb2RpZmllZC5yYWRpdXMpOyAgLy8gMzBcbiAgICogYGBgXG4gICAqIEByZXR1cm5zIEEgY29weSBvZiB0aGUgcm91bmRlZCByZWN0YW5nbGVcbiAgICogQHNlZSB7QGxpbmsgUm91bmRlZFJlY3RhbmdsZS5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgaW50byBleGlzdGluZyByZWN0YW5nbGVcbiAgICogQHNlZSB7QGxpbmsgUm91bmRlZFJlY3RhbmdsZS5jb3B5VG99IEZvciBjb3B5aW5nIHRvIGFub3RoZXIgcmVjdGFuZ2xlXG4gICAqL1xuICBjbG9uZSgpIHtcbiAgICByZXR1cm4gbmV3IFJvdW5kZWRSZWN0YW5nbGUodGhpcy54LCB0aGlzLnksIHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0LCB0aGlzLnJhZGl1cyk7XG4gIH1cbiAgLyoqXG4gICAqIENvcGllcyBhbm90aGVyIHJlY3RhbmdsZSB0byB0aGlzIG9uZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY29weWluZ1xuICAgKiBjb25zdCBzb3VyY2UgPSBuZXcgUm91bmRlZFJlY3RhbmdsZSgxMDAsIDEwMCwgMjAwLCAxNTAsIDIwKTtcbiAgICogY29uc3QgdGFyZ2V0ID0gbmV3IFJvdW5kZWRSZWN0YW5nbGUoKTtcbiAgICogdGFyZ2V0LmNvcHlGcm9tKHNvdXJjZSk7XG4gICAqXG4gICAqIC8vIENoYWluIHdpdGggb3RoZXIgb3BlcmF0aW9uc1xuICAgKiBjb25zdCByZWN0ID0gbmV3IFJvdW5kZWRSZWN0YW5nbGUoKVxuICAgKiAgICAgLmNvcHlGcm9tKHNvdXJjZSlcbiAgICogICAgIC5nZXRCb3VuZHMocmVjdCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcmVjdGFuZ2xlIC0gVGhlIHJlY3RhbmdsZSB0byBjb3B5IGZyb21cbiAgICogQHJldHVybnMgUmV0dXJucyBpdHNlbGZcbiAgICogQHNlZSB7QGxpbmsgUm91bmRlZFJlY3RhbmdsZS5jb3B5VG99IEZvciBjb3B5aW5nIHRvIGFub3RoZXIgcmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIFJvdW5kZWRSZWN0YW5nbGUuY2xvbmV9IEZvciBjcmVhdGluZyBuZXcgcmVjdGFuZ2xlIGNvcHlcbiAgICovXG4gIGNvcHlGcm9tKHJlY3RhbmdsZSkge1xuICAgIHRoaXMueCA9IHJlY3RhbmdsZS54O1xuICAgIHRoaXMueSA9IHJlY3RhbmdsZS55O1xuICAgIHRoaXMud2lkdGggPSByZWN0YW5nbGUud2lkdGg7XG4gICAgdGhpcy5oZWlnaHQgPSByZWN0YW5nbGUuaGVpZ2h0O1xuICAgIHRoaXMucmFkaXVzID0gcmVjdGFuZ2xlLnJhZGl1cztcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQ29waWVzIHRoaXMgcmVjdGFuZ2xlIHRvIGFub3RoZXIgb25lLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb3B5aW5nXG4gICAqIGNvbnN0IHNvdXJjZSA9IG5ldyBSb3VuZGVkUmVjdGFuZ2xlKDEwMCwgMTAwLCAyMDAsIDE1MCwgMjApO1xuICAgKiBjb25zdCB0YXJnZXQgPSBuZXcgUm91bmRlZFJlY3RhbmdsZSgpO1xuICAgKiBzb3VyY2UuY29weVRvKHRhcmdldCk7XG4gICAqXG4gICAqIC8vIENoYWluIHdpdGggb3RoZXIgb3BlcmF0aW9uc1xuICAgKiBjb25zdCByZXN1bHQgPSBzb3VyY2VcbiAgICogICAgIC5jb3B5VG8obmV3IFJvdW5kZWRSZWN0YW5nbGUoKSlcbiAgICogICAgIC5nZXRCb3VuZHMoKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSByZWN0YW5nbGUgLSBUaGUgcmVjdGFuZ2xlIHRvIGNvcHkgdG9cbiAgICogQHJldHVybnMgUmV0dXJucyBnaXZlbiBwYXJhbWV0ZXJcbiAgICogQHNlZSB7QGxpbmsgUm91bmRlZFJlY3RhbmdsZS5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgZnJvbSBhbm90aGVyIHJlY3RhbmdsZVxuICAgKiBAc2VlIHtAbGluayBSb3VuZGVkUmVjdGFuZ2xlLmNsb25lfSBGb3IgY3JlYXRpbmcgbmV3IHJlY3RhbmdsZSBjb3B5XG4gICAqL1xuICBjb3B5VG8ocmVjdGFuZ2xlKSB7XG4gICAgcmVjdGFuZ2xlLmNvcHlGcm9tKHRoaXMpO1xuICAgIHJldHVybiByZWN0YW5nbGU7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyB3aGV0aGVyIHRoZSB4IGFuZCB5IGNvb3JkaW5hdGVzIGdpdmVuIGFyZSBjb250YWluZWQgd2l0aGluIHRoaXMgUm91bmRlZCBSZWN0YW5nbGVcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY29udGFpbm1lbnQgY2hlY2tcbiAgICogY29uc3QgcmVjdCA9IG5ldyBSb3VuZGVkUmVjdGFuZ2xlKDEwMCwgMTAwLCAyMDAsIDE1MCwgMjApO1xuICAgKiBjb25zdCBpc0luc2lkZSA9IHJlY3QuY29udGFpbnMoMTUwLCAxMjUpOyAvLyB0cnVlXG4gICAqIC8vIENoZWNrIGNvcm5lciByYWRpdXNcbiAgICogY29uc3QgY29ybmVyID0gcmVjdC5jb250YWlucygxMDAsIDEwMCk7IC8vIGZhbHNlIGlmIHdpdGhpbiBjb3JuZXIgY3VydmVcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gUmV0dXJucyBmYWxzZSBpZiB3aWR0aC9oZWlnaHQgaXMgMCBvciBuZWdhdGl2ZVxuICAgKiAtIEhhbmRsZXMgcm91bmRlZCBjb3JuZXJzIHdpdGggcmFkaXVzIGNoZWNrXG4gICAqIEBwYXJhbSB4IC0gVGhlIFggY29vcmRpbmF0ZSBvZiB0aGUgcG9pbnQgdG8gdGVzdFxuICAgKiBAcGFyYW0geSAtIFRoZSBZIGNvb3JkaW5hdGUgb2YgdGhlIHBvaW50IHRvIHRlc3RcbiAgICogQHJldHVybnMgV2hldGhlciB0aGUgeC95IGNvb3JkaW5hdGVzIGFyZSB3aXRoaW4gdGhpcyBSb3VuZGVkIFJlY3RhbmdsZVxuICAgKiBAc2VlIHtAbGluayBSb3VuZGVkUmVjdGFuZ2xlLnN0cm9rZUNvbnRhaW5zfSBGb3IgY2hlY2tpbmcgc3Ryb2tlIGludGVyc2VjdGlvblxuICAgKiBAc2VlIHtAbGluayBSb3VuZGVkUmVjdGFuZ2xlLmdldEJvdW5kc30gRm9yIGdldHRpbmcgY29udGFpbmluZyByZWN0YW5nbGVcbiAgICovXG4gIGNvbnRhaW5zKHgsIHkpIHtcbiAgICBpZiAodGhpcy53aWR0aCA8PSAwIHx8IHRoaXMuaGVpZ2h0IDw9IDApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKHggPj0gdGhpcy54ICYmIHggPD0gdGhpcy54ICsgdGhpcy53aWR0aCkge1xuICAgICAgaWYgKHkgPj0gdGhpcy55ICYmIHkgPD0gdGhpcy55ICsgdGhpcy5oZWlnaHQpIHtcbiAgICAgICAgY29uc3QgcmFkaXVzID0gTWF0aC5tYXgoMCwgTWF0aC5taW4odGhpcy5yYWRpdXMsIE1hdGgubWluKHRoaXMud2lkdGgsIHRoaXMuaGVpZ2h0KSAvIDIpKTtcbiAgICAgICAgaWYgKHkgPj0gdGhpcy55ICsgcmFkaXVzICYmIHkgPD0gdGhpcy55ICsgdGhpcy5oZWlnaHQgLSByYWRpdXMgfHwgeCA+PSB0aGlzLnggKyByYWRpdXMgJiYgeCA8PSB0aGlzLnggKyB0aGlzLndpZHRoIC0gcmFkaXVzKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGR4ID0geCAtICh0aGlzLnggKyByYWRpdXMpO1xuICAgICAgICBsZXQgZHkgPSB5IC0gKHRoaXMueSArIHJhZGl1cyk7XG4gICAgICAgIGNvbnN0IHJhZGl1czIgPSByYWRpdXMgKiByYWRpdXM7XG4gICAgICAgIGlmIChkeCAqIGR4ICsgZHkgKiBkeSA8PSByYWRpdXMyKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZHggPSB4IC0gKHRoaXMueCArIHRoaXMud2lkdGggLSByYWRpdXMpO1xuICAgICAgICBpZiAoZHggKiBkeCArIGR5ICogZHkgPD0gcmFkaXVzMikge1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGR5ID0geSAtICh0aGlzLnkgKyB0aGlzLmhlaWdodCAtIHJhZGl1cyk7XG4gICAgICAgIGlmIChkeCAqIGR4ICsgZHkgKiBkeSA8PSByYWRpdXMyKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZHggPSB4IC0gKHRoaXMueCArIHJhZGl1cyk7XG4gICAgICAgIGlmIChkeCAqIGR4ICsgZHkgKiBkeSA8PSByYWRpdXMyKSB7XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8qKlxuICAgKiBDaGVja3Mgd2hldGhlciB0aGUgeCBhbmQgeSBjb29yZGluYXRlcyBnaXZlbiBhcmUgY29udGFpbmVkIHdpdGhpbiB0aGlzIHJlY3RhbmdsZSBpbmNsdWRpbmcgdGhlIHN0cm9rZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgc3Ryb2tlIGNoZWNrXG4gICAqIGNvbnN0IHJlY3QgPSBuZXcgUm91bmRlZFJlY3RhbmdsZSgxMDAsIDEwMCwgMjAwLCAxNTAsIDIwKTtcbiAgICogY29uc3QgaXNPblN0cm9rZSA9IHJlY3Quc3Ryb2tlQ29udGFpbnMoMTUwLCAxMDAsIDQpOyAvLyA0cHggbGluZSB3aWR0aFxuICAgKlxuICAgKiAvLyBDaGVjayB3aXRoIGRpZmZlcmVudCBhbGlnbm1lbnRzXG4gICAqIGNvbnN0IGlubmVyU3Ryb2tlID0gcmVjdC5zdHJva2VDb250YWlucygxNTAsIDEwMCwgNCwgMSk7ICAgLy8gSW5zaWRlXG4gICAqIGNvbnN0IGNlbnRlclN0cm9rZSA9IHJlY3Quc3Ryb2tlQ29udGFpbnMoMTUwLCAxMDAsIDQsIDAuNSk7IC8vIENlbnRlcmVkXG4gICAqIGNvbnN0IG91dGVyU3Ryb2tlID0gcmVjdC5zdHJva2VDb250YWlucygxNTAsIDEwMCwgNCwgMCk7ICAgLy8gT3V0c2lkZVxuICAgKiBgYGBcbiAgICogQHBhcmFtIHBYIC0gVGhlIFggY29vcmRpbmF0ZSBvZiB0aGUgcG9pbnQgdG8gdGVzdFxuICAgKiBAcGFyYW0gcFkgLSBUaGUgWSBjb29yZGluYXRlIG9mIHRoZSBwb2ludCB0byB0ZXN0XG4gICAqIEBwYXJhbSBzdHJva2VXaWR0aCAtIFRoZSB3aWR0aCBvZiB0aGUgbGluZSB0byBjaGVja1xuICAgKiBAcGFyYW0gYWxpZ25tZW50IC0gVGhlIGFsaWdubWVudCBvZiB0aGUgc3Ryb2tlICgxID0gaW5uZXIsIDAuNSA9IGNlbnRlcmVkLCAwID0gb3V0ZXIpXG4gICAqIEByZXR1cm5zIFdoZXRoZXIgdGhlIHgveSBjb29yZGluYXRlcyBhcmUgd2l0aGluIHRoaXMgcmVjdGFuZ2xlJ3Mgc3Ryb2tlXG4gICAqIEBzZWUge0BsaW5rIFJvdW5kZWRSZWN0YW5nbGUuY29udGFpbnN9IEZvciBjaGVja2luZyBmaWxsIGNvbnRhaW5tZW50XG4gICAqIEBzZWUge0BsaW5rIFJvdW5kZWRSZWN0YW5nbGUuZ2V0Qm91bmRzfSBGb3IgZ2V0dGluZyBzdHJva2UgYm91bmRzXG4gICAqL1xuICBzdHJva2VDb250YWlucyhwWCwgcFksIHN0cm9rZVdpZHRoLCBhbGlnbm1lbnQgPSAwLjUpIHtcbiAgICBjb25zdCB7IHgsIHksIHdpZHRoLCBoZWlnaHQsIHJhZGl1cyB9ID0gdGhpcztcbiAgICBjb25zdCBzdHJva2VXaWR0aE91dGVyID0gc3Ryb2tlV2lkdGggKiAoMSAtIGFsaWdubWVudCk7XG4gICAgY29uc3Qgc3Ryb2tlV2lkdGhJbm5lciA9IHN0cm9rZVdpZHRoIC0gc3Ryb2tlV2lkdGhPdXRlcjtcbiAgICBjb25zdCBpbm5lclggPSB4ICsgcmFkaXVzO1xuICAgIGNvbnN0IGlubmVyWSA9IHkgKyByYWRpdXM7XG4gICAgY29uc3QgaW5uZXJXaWR0aCA9IHdpZHRoIC0gcmFkaXVzICogMjtcbiAgICBjb25zdCBpbm5lckhlaWdodCA9IGhlaWdodCAtIHJhZGl1cyAqIDI7XG4gICAgY29uc3QgcmlnaHRCb3VuZCA9IHggKyB3aWR0aDtcbiAgICBjb25zdCBib3R0b21Cb3VuZCA9IHkgKyBoZWlnaHQ7XG4gICAgaWYgKChwWCA+PSB4IC0gc3Ryb2tlV2lkdGhPdXRlciAmJiBwWCA8PSB4ICsgc3Ryb2tlV2lkdGhJbm5lciB8fCBwWCA+PSByaWdodEJvdW5kIC0gc3Ryb2tlV2lkdGhJbm5lciAmJiBwWCA8PSByaWdodEJvdW5kICsgc3Ryb2tlV2lkdGhPdXRlcikgJiYgcFkgPj0gaW5uZXJZICYmIHBZIDw9IGlubmVyWSArIGlubmVySGVpZ2h0KSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKChwWSA+PSB5IC0gc3Ryb2tlV2lkdGhPdXRlciAmJiBwWSA8PSB5ICsgc3Ryb2tlV2lkdGhJbm5lciB8fCBwWSA+PSBib3R0b21Cb3VuZCAtIHN0cm9rZVdpZHRoSW5uZXIgJiYgcFkgPD0gYm90dG9tQm91bmQgKyBzdHJva2VXaWR0aE91dGVyKSAmJiBwWCA+PSBpbm5lclggJiYgcFggPD0gaW5uZXJYICsgaW5uZXJXaWR0aCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiAoXG4gICAgICAvLyBUb3AtbGVmdFxuICAgICAgcFggPCBpbm5lclggJiYgcFkgPCBpbm5lclkgJiYgaXNDb3JuZXJXaXRoaW5TdHJva2UoXG4gICAgICAgIHBYLFxuICAgICAgICBwWSxcbiAgICAgICAgaW5uZXJYLFxuICAgICAgICBpbm5lclksXG4gICAgICAgIHJhZGl1cyxcbiAgICAgICAgc3Ryb2tlV2lkdGhJbm5lcixcbiAgICAgICAgc3Ryb2tlV2lkdGhPdXRlclxuICAgICAgKSB8fCBwWCA+IHJpZ2h0Qm91bmQgLSByYWRpdXMgJiYgcFkgPCBpbm5lclkgJiYgaXNDb3JuZXJXaXRoaW5TdHJva2UoXG4gICAgICAgIHBYLFxuICAgICAgICBwWSxcbiAgICAgICAgcmlnaHRCb3VuZCAtIHJhZGl1cyxcbiAgICAgICAgaW5uZXJZLFxuICAgICAgICByYWRpdXMsXG4gICAgICAgIHN0cm9rZVdpZHRoSW5uZXIsXG4gICAgICAgIHN0cm9rZVdpZHRoT3V0ZXJcbiAgICAgICkgfHwgcFggPiByaWdodEJvdW5kIC0gcmFkaXVzICYmIHBZID4gYm90dG9tQm91bmQgLSByYWRpdXMgJiYgaXNDb3JuZXJXaXRoaW5TdHJva2UoXG4gICAgICAgIHBYLFxuICAgICAgICBwWSxcbiAgICAgICAgcmlnaHRCb3VuZCAtIHJhZGl1cyxcbiAgICAgICAgYm90dG9tQm91bmQgLSByYWRpdXMsXG4gICAgICAgIHJhZGl1cyxcbiAgICAgICAgc3Ryb2tlV2lkdGhJbm5lcixcbiAgICAgICAgc3Ryb2tlV2lkdGhPdXRlclxuICAgICAgKSB8fCBwWCA8IGlubmVyWCAmJiBwWSA+IGJvdHRvbUJvdW5kIC0gcmFkaXVzICYmIGlzQ29ybmVyV2l0aGluU3Ryb2tlKFxuICAgICAgICBwWCxcbiAgICAgICAgcFksXG4gICAgICAgIGlubmVyWCxcbiAgICAgICAgYm90dG9tQm91bmQgLSByYWRpdXMsXG4gICAgICAgIHJhZGl1cyxcbiAgICAgICAgc3Ryb2tlV2lkdGhJbm5lcixcbiAgICAgICAgc3Ryb2tlV2lkdGhPdXRlclxuICAgICAgKVxuICAgICk7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIGBbcGl4aS5qcy9tYXRoOlJvdW5kZWRSZWN0YW5nbGUgeD0ke3RoaXMueH0geT0ke3RoaXMueX13aWR0aD0ke3RoaXMud2lkdGh9IGhlaWdodD0ke3RoaXMuaGVpZ2h0fSByYWRpdXM9JHt0aGlzLnJhZGl1c31dYDtcbiAgfVxufVxuXG5leHBvcnQgeyBSb3VuZGVkUmVjdGFuZ2xlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1Sb3VuZGVkUmVjdGFuZ2xlLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gYnVpbGRVdnModmVydGljZXMsIHZlcnRpY2VzU3RyaWRlLCB2ZXJ0aWNlc09mZnNldCwgdXZzLCB1dnNPZmZzZXQsIHV2c1N0cmlkZSwgc2l6ZSwgbWF0cml4ID0gbnVsbCkge1xuICBsZXQgaW5kZXggPSAwO1xuICB2ZXJ0aWNlc09mZnNldCAqPSB2ZXJ0aWNlc1N0cmlkZTtcbiAgdXZzT2Zmc2V0ICo9IHV2c1N0cmlkZTtcbiAgY29uc3QgYSA9IG1hdHJpeC5hO1xuICBjb25zdCBiID0gbWF0cml4LmI7XG4gIGNvbnN0IGMgPSBtYXRyaXguYztcbiAgY29uc3QgZCA9IG1hdHJpeC5kO1xuICBjb25zdCB0eCA9IG1hdHJpeC50eDtcbiAgY29uc3QgdHkgPSBtYXRyaXgudHk7XG4gIHdoaWxlIChpbmRleCA8IHNpemUpIHtcbiAgICBjb25zdCB4ID0gdmVydGljZXNbdmVydGljZXNPZmZzZXRdO1xuICAgIGNvbnN0IHkgPSB2ZXJ0aWNlc1t2ZXJ0aWNlc09mZnNldCArIDFdO1xuICAgIHV2c1t1dnNPZmZzZXRdID0gYSAqIHggKyBjICogeSArIHR4O1xuICAgIHV2c1t1dnNPZmZzZXQgKyAxXSA9IGIgKiB4ICsgZCAqIHkgKyB0eTtcbiAgICB1dnNPZmZzZXQgKz0gdXZzU3RyaWRlO1xuICAgIHZlcnRpY2VzT2Zmc2V0ICs9IHZlcnRpY2VzU3RyaWRlO1xuICAgIGluZGV4Kys7XG4gIH1cbn1cbmZ1bmN0aW9uIGJ1aWxkU2ltcGxlVXZzKHV2cywgdXZzT2Zmc2V0LCB1dnNTdHJpZGUsIHNpemUpIHtcbiAgbGV0IGluZGV4ID0gMDtcbiAgdXZzT2Zmc2V0ICo9IHV2c1N0cmlkZTtcbiAgd2hpbGUgKGluZGV4IDwgc2l6ZSkge1xuICAgIHV2c1t1dnNPZmZzZXRdID0gMDtcbiAgICB1dnNbdXZzT2Zmc2V0ICsgMV0gPSAwO1xuICAgIHV2c09mZnNldCArPSB1dnNTdHJpZGU7XG4gICAgaW5kZXgrKztcbiAgfVxufVxuXG5leHBvcnQgeyBidWlsZFNpbXBsZVV2cywgYnVpbGRVdnMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1aWxkVXZzLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gdHJhbnNmb3JtVmVydGljZXModmVydGljZXMsIG0sIG9mZnNldCwgc3RyaWRlLCBzaXplKSB7XG4gIGNvbnN0IGEgPSBtLmE7XG4gIGNvbnN0IGIgPSBtLmI7XG4gIGNvbnN0IGMgPSBtLmM7XG4gIGNvbnN0IGQgPSBtLmQ7XG4gIGNvbnN0IHR4ID0gbS50eDtcbiAgY29uc3QgdHkgPSBtLnR5O1xuICBvZmZzZXQgfHwgKG9mZnNldCA9IDApO1xuICBzdHJpZGUgfHwgKHN0cmlkZSA9IDIpO1xuICBzaXplIHx8IChzaXplID0gdmVydGljZXMubGVuZ3RoIC8gc3RyaWRlIC0gb2Zmc2V0KTtcbiAgbGV0IGluZGV4ID0gb2Zmc2V0ICogc3RyaWRlO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHNpemU7IGkrKykge1xuICAgIGNvbnN0IHggPSB2ZXJ0aWNlc1tpbmRleF07XG4gICAgY29uc3QgeSA9IHZlcnRpY2VzW2luZGV4ICsgMV07XG4gICAgdmVydGljZXNbaW5kZXhdID0gYSAqIHggKyBjICogeSArIHR4O1xuICAgIHZlcnRpY2VzW2luZGV4ICsgMV0gPSBiICogeCArIGQgKiB5ICsgdHk7XG4gICAgaW5kZXggKz0gc3RyaWRlO1xuICB9XG59XG5cbmV4cG9ydCB7IHRyYW5zZm9ybVZlcnRpY2VzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD10cmFuc2Zvcm1WZXJ0aWNlcy5tanMubWFwXG4iLCJpbXBvcnQgeyBNYXRyaXggfSBmcm9tICcuLi8uLi8uLi9tYXRocy9tYXRyaXgvTWF0cml4Lm1qcyc7XG5pbXBvcnQgeyBtdWx0aXBseUhleENvbG9ycyB9IGZyb20gJy4uLy4uL2NvbnRhaW5lci91dGlscy9tdWx0aXBseUhleENvbG9ycy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IGlkZW50aXR5TWF0cml4ID0gbmV3IE1hdHJpeCgpO1xuY2xhc3MgQmF0Y2hhYmxlR3JhcGhpY3Mge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnBhY2tBc1F1YWQgPSBmYWxzZTtcbiAgICB0aGlzLmJhdGNoZXJOYW1lID0gXCJkZWZhdWx0XCI7XG4gICAgdGhpcy50b3BvbG9neSA9IFwidHJpYW5nbGUtbGlzdFwiO1xuICAgIHRoaXMuYXBwbHlUcmFuc2Zvcm0gPSB0cnVlO1xuICAgIHRoaXMucm91bmRQaXhlbHMgPSAwO1xuICAgIHRoaXMuX2JhdGNoZXIgPSBudWxsO1xuICAgIHRoaXMuX2JhdGNoID0gbnVsbDtcbiAgfVxuICBnZXQgdXZzKCkge1xuICAgIHJldHVybiB0aGlzLmdlb21ldHJ5RGF0YS51dnM7XG4gIH1cbiAgZ2V0IHBvc2l0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy5nZW9tZXRyeURhdGEudmVydGljZXM7XG4gIH1cbiAgZ2V0IGluZGljZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2VvbWV0cnlEYXRhLmluZGljZXM7XG4gIH1cbiAgZ2V0IGJsZW5kTW9kZSgpIHtcbiAgICBpZiAodGhpcy5yZW5kZXJhYmxlICYmIHRoaXMuYXBwbHlUcmFuc2Zvcm0pIHtcbiAgICAgIHJldHVybiB0aGlzLnJlbmRlcmFibGUuZ3JvdXBCbGVuZE1vZGU7XG4gICAgfVxuICAgIHJldHVybiBcIm5vcm1hbFwiO1xuICB9XG4gIGdldCBjb2xvcigpIHtcbiAgICBjb25zdCByZ2IgPSB0aGlzLmJhc2VDb2xvcjtcbiAgICBjb25zdCBiZ3IgPSByZ2IgPj4gMTYgfCByZ2IgJiA2NTI4MCB8IChyZ2IgJiAyNTUpIDw8IDE2O1xuICAgIGNvbnN0IHJlbmRlcmFibGUgPSB0aGlzLnJlbmRlcmFibGU7XG4gICAgaWYgKHJlbmRlcmFibGUpIHtcbiAgICAgIHJldHVybiBtdWx0aXBseUhleENvbG9ycyhiZ3IsIHJlbmRlcmFibGUuZ3JvdXBDb2xvcikgKyAodGhpcy5hbHBoYSAqIHJlbmRlcmFibGUuZ3JvdXBBbHBoYSAqIDI1NSA8PCAyNCk7XG4gICAgfVxuICAgIHJldHVybiBiZ3IgKyAodGhpcy5hbHBoYSAqIDI1NSA8PCAyNCk7XG4gIH1cbiAgZ2V0IHRyYW5zZm9ybSgpIHtcbiAgICByZXR1cm4gdGhpcy5yZW5kZXJhYmxlPy5ncm91cFRyYW5zZm9ybSB8fCBpZGVudGl0eU1hdHJpeDtcbiAgfVxuICBjb3B5VG8oZ3B1QnVmZmVyKSB7XG4gICAgZ3B1QnVmZmVyLmluZGV4T2Zmc2V0ID0gdGhpcy5pbmRleE9mZnNldDtcbiAgICBncHVCdWZmZXIuaW5kZXhTaXplID0gdGhpcy5pbmRleFNpemU7XG4gICAgZ3B1QnVmZmVyLmF0dHJpYnV0ZU9mZnNldCA9IHRoaXMuYXR0cmlidXRlT2Zmc2V0O1xuICAgIGdwdUJ1ZmZlci5hdHRyaWJ1dGVTaXplID0gdGhpcy5hdHRyaWJ1dGVTaXplO1xuICAgIGdwdUJ1ZmZlci5iYXNlQ29sb3IgPSB0aGlzLmJhc2VDb2xvcjtcbiAgICBncHVCdWZmZXIuYWxwaGEgPSB0aGlzLmFscGhhO1xuICAgIGdwdUJ1ZmZlci50ZXh0dXJlID0gdGhpcy50ZXh0dXJlO1xuICAgIGdwdUJ1ZmZlci5nZW9tZXRyeURhdGEgPSB0aGlzLmdlb21ldHJ5RGF0YTtcbiAgICBncHVCdWZmZXIudG9wb2xvZ3kgPSB0aGlzLnRvcG9sb2d5O1xuICB9XG4gIHJlc2V0KCkge1xuICAgIHRoaXMuYXBwbHlUcmFuc2Zvcm0gPSB0cnVlO1xuICAgIHRoaXMucmVuZGVyYWJsZSA9IG51bGw7XG4gICAgdGhpcy50b3BvbG9neSA9IFwidHJpYW5nbGUtbGlzdFwiO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5yZW5kZXJhYmxlID0gbnVsbDtcbiAgICB0aGlzLnRleHR1cmUgPSBudWxsO1xuICAgIHRoaXMuZ2VvbWV0cnlEYXRhID0gbnVsbDtcbiAgICB0aGlzLl9iYXRjaGVyID0gbnVsbDtcbiAgICB0aGlzLl9iYXRjaCA9IG51bGw7XG4gIH1cbn1cblxuZXhwb3J0IHsgQmF0Y2hhYmxlR3JhcGhpY3MgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUJhdGNoYWJsZUdyYXBoaWNzLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBidWlsZENpcmNsZSA9IHtcbiAgZXh0ZW5zaW9uOiB7XG4gICAgdHlwZTogRXh0ZW5zaW9uVHlwZS5TaGFwZUJ1aWxkZXIsXG4gICAgbmFtZTogXCJjaXJjbGVcIlxuICB9LFxuICBidWlsZChzaGFwZSwgcG9pbnRzKSB7XG4gICAgbGV0IHg7XG4gICAgbGV0IHk7XG4gICAgbGV0IGR4O1xuICAgIGxldCBkeTtcbiAgICBsZXQgcng7XG4gICAgbGV0IHJ5O1xuICAgIGlmIChzaGFwZS50eXBlID09PSBcImNpcmNsZVwiKSB7XG4gICAgICBjb25zdCBjaXJjbGUgPSBzaGFwZTtcbiAgICAgIHJ4ID0gcnkgPSBjaXJjbGUucmFkaXVzO1xuICAgICAgaWYgKHJ4IDw9IDApIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgeCA9IGNpcmNsZS54O1xuICAgICAgeSA9IGNpcmNsZS55O1xuICAgICAgZHggPSBkeSA9IDA7XG4gICAgfSBlbHNlIGlmIChzaGFwZS50eXBlID09PSBcImVsbGlwc2VcIikge1xuICAgICAgY29uc3QgZWxsaXBzZSA9IHNoYXBlO1xuICAgICAgcnggPSBlbGxpcHNlLmhhbGZXaWR0aDtcbiAgICAgIHJ5ID0gZWxsaXBzZS5oYWxmSGVpZ2h0O1xuICAgICAgaWYgKHJ4IDw9IDAgfHwgcnkgPD0gMCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICB4ID0gZWxsaXBzZS54O1xuICAgICAgeSA9IGVsbGlwc2UueTtcbiAgICAgIGR4ID0gZHkgPSAwO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCByb3VuZGVkUmVjdCA9IHNoYXBlO1xuICAgICAgY29uc3QgaGFsZldpZHRoID0gcm91bmRlZFJlY3Qud2lkdGggLyAyO1xuICAgICAgY29uc3QgaGFsZkhlaWdodCA9IHJvdW5kZWRSZWN0LmhlaWdodCAvIDI7XG4gICAgICB4ID0gcm91bmRlZFJlY3QueCArIGhhbGZXaWR0aDtcbiAgICAgIHkgPSByb3VuZGVkUmVjdC55ICsgaGFsZkhlaWdodDtcbiAgICAgIHJ4ID0gcnkgPSBNYXRoLm1heCgwLCBNYXRoLm1pbihyb3VuZGVkUmVjdC5yYWRpdXMsIE1hdGgubWluKGhhbGZXaWR0aCwgaGFsZkhlaWdodCkpKTtcbiAgICAgIGR4ID0gaGFsZldpZHRoIC0gcng7XG4gICAgICBkeSA9IGhhbGZIZWlnaHQgLSByeTtcbiAgICB9XG4gICAgaWYgKGR4IDwgMCB8fCBkeSA8IDApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgbiA9IE1hdGguY2VpbCgyLjMgKiBNYXRoLnNxcnQocnggKyByeSkpO1xuICAgIGNvbnN0IG0gPSBuICogOCArIChkeCA/IDQgOiAwKSArIChkeSA/IDQgOiAwKTtcbiAgICBpZiAobSA9PT0gMCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAobiA9PT0gMCkge1xuICAgICAgcG9pbnRzWzBdID0gcG9pbnRzWzZdID0geCArIGR4O1xuICAgICAgcG9pbnRzWzFdID0gcG9pbnRzWzNdID0geSArIGR5O1xuICAgICAgcG9pbnRzWzJdID0gcG9pbnRzWzRdID0geCAtIGR4O1xuICAgICAgcG9pbnRzWzVdID0gcG9pbnRzWzddID0geSAtIGR5O1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGxldCBqMSA9IDA7XG4gICAgbGV0IGoyID0gbiAqIDQgKyAoZHggPyAyIDogMCkgKyAyO1xuICAgIGxldCBqMyA9IGoyO1xuICAgIGxldCBqNCA9IG07XG4gICAgbGV0IHgwID0gZHggKyByeDtcbiAgICBsZXQgeTAgPSBkeTtcbiAgICBsZXQgeDEgPSB4ICsgeDA7XG4gICAgbGV0IHgyID0geCAtIHgwO1xuICAgIGxldCB5MSA9IHkgKyB5MDtcbiAgICBwb2ludHNbajErK10gPSB4MTtcbiAgICBwb2ludHNbajErK10gPSB5MTtcbiAgICBwb2ludHNbLS1qMl0gPSB5MTtcbiAgICBwb2ludHNbLS1qMl0gPSB4MjtcbiAgICBpZiAoZHkpIHtcbiAgICAgIGNvbnN0IHkyMiA9IHkgLSB5MDtcbiAgICAgIHBvaW50c1tqMysrXSA9IHgyO1xuICAgICAgcG9pbnRzW2ozKytdID0geTIyO1xuICAgICAgcG9pbnRzWy0tajRdID0geTIyO1xuICAgICAgcG9pbnRzWy0tajRdID0geDE7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgbjsgaSsrKSB7XG4gICAgICBjb25zdCBhID0gTWF0aC5QSSAvIDIgKiAoaSAvIG4pO1xuICAgICAgY29uc3QgeDAyID0gZHggKyBNYXRoLmNvcyhhKSAqIHJ4O1xuICAgICAgY29uc3QgeTAyID0gZHkgKyBNYXRoLnNpbihhKSAqIHJ5O1xuICAgICAgY29uc3QgeDEyID0geCArIHgwMjtcbiAgICAgIGNvbnN0IHgyMiA9IHggLSB4MDI7XG4gICAgICBjb25zdCB5MTIgPSB5ICsgeTAyO1xuICAgICAgY29uc3QgeTIyID0geSAtIHkwMjtcbiAgICAgIHBvaW50c1tqMSsrXSA9IHgxMjtcbiAgICAgIHBvaW50c1tqMSsrXSA9IHkxMjtcbiAgICAgIHBvaW50c1stLWoyXSA9IHkxMjtcbiAgICAgIHBvaW50c1stLWoyXSA9IHgyMjtcbiAgICAgIHBvaW50c1tqMysrXSA9IHgyMjtcbiAgICAgIHBvaW50c1tqMysrXSA9IHkyMjtcbiAgICAgIHBvaW50c1stLWo0XSA9IHkyMjtcbiAgICAgIHBvaW50c1stLWo0XSA9IHgxMjtcbiAgICB9XG4gICAgeDAgPSBkeDtcbiAgICB5MCA9IGR5ICsgcnk7XG4gICAgeDEgPSB4ICsgeDA7XG4gICAgeDIgPSB4IC0geDA7XG4gICAgeTEgPSB5ICsgeTA7XG4gICAgY29uc3QgeTIgPSB5IC0geTA7XG4gICAgcG9pbnRzW2oxKytdID0geDE7XG4gICAgcG9pbnRzW2oxKytdID0geTE7XG4gICAgcG9pbnRzWy0tajRdID0geTI7XG4gICAgcG9pbnRzWy0tajRdID0geDE7XG4gICAgaWYgKGR4KSB7XG4gICAgICBwb2ludHNbajErK10gPSB4MjtcbiAgICAgIHBvaW50c1tqMSsrXSA9IHkxO1xuICAgICAgcG9pbnRzWy0tajRdID0geTI7XG4gICAgICBwb2ludHNbLS1qNF0gPSB4MjtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIHRyaWFuZ3VsYXRlKHBvaW50cywgdmVydGljZXMsIHZlcnRpY2VzU3RyaWRlLCB2ZXJ0aWNlc09mZnNldCwgaW5kaWNlcywgaW5kaWNlc09mZnNldCkge1xuICAgIGlmIChwb2ludHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBjZW50ZXJYID0gMDtcbiAgICBsZXQgY2VudGVyWSA9IDA7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwb2ludHMubGVuZ3RoOyBpICs9IDIpIHtcbiAgICAgIGNlbnRlclggKz0gcG9pbnRzW2ldO1xuICAgICAgY2VudGVyWSArPSBwb2ludHNbaSArIDFdO1xuICAgIH1cbiAgICBjZW50ZXJYIC89IHBvaW50cy5sZW5ndGggLyAyO1xuICAgIGNlbnRlclkgLz0gcG9pbnRzLmxlbmd0aCAvIDI7XG4gICAgbGV0IGNvdW50ID0gdmVydGljZXNPZmZzZXQ7XG4gICAgdmVydGljZXNbY291bnQgKiB2ZXJ0aWNlc1N0cmlkZV0gPSBjZW50ZXJYO1xuICAgIHZlcnRpY2VzW2NvdW50ICogdmVydGljZXNTdHJpZGUgKyAxXSA9IGNlbnRlclk7XG4gICAgY29uc3QgY2VudGVySW5kZXggPSBjb3VudCsrO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcG9pbnRzLmxlbmd0aDsgaSArPSAyKSB7XG4gICAgICB2ZXJ0aWNlc1tjb3VudCAqIHZlcnRpY2VzU3RyaWRlXSA9IHBvaW50c1tpXTtcbiAgICAgIHZlcnRpY2VzW2NvdW50ICogdmVydGljZXNTdHJpZGUgKyAxXSA9IHBvaW50c1tpICsgMV07XG4gICAgICBpZiAoaSA+IDApIHtcbiAgICAgICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gY291bnQ7XG4gICAgICAgIGluZGljZXNbaW5kaWNlc09mZnNldCsrXSA9IGNlbnRlckluZGV4O1xuICAgICAgICBpbmRpY2VzW2luZGljZXNPZmZzZXQrK10gPSBjb3VudCAtIDE7XG4gICAgICB9XG4gICAgICBjb3VudCsrO1xuICAgIH1cbiAgICBpbmRpY2VzW2luZGljZXNPZmZzZXQrK10gPSBjZW50ZXJJbmRleCArIDE7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gY2VudGVySW5kZXg7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gY291bnQgLSAxO1xuICB9XG59O1xuY29uc3QgYnVpbGRFbGxpcHNlID0geyAuLi5idWlsZENpcmNsZSwgZXh0ZW5zaW9uOiB7IC4uLmJ1aWxkQ2lyY2xlLmV4dGVuc2lvbiwgbmFtZTogXCJlbGxpcHNlXCIgfSB9O1xuY29uc3QgYnVpbGRSb3VuZGVkUmVjdGFuZ2xlID0geyAuLi5idWlsZENpcmNsZSwgZXh0ZW5zaW9uOiB7IC4uLmJ1aWxkQ2lyY2xlLmV4dGVuc2lvbiwgbmFtZTogXCJyb3VuZGVkUmVjdGFuZ2xlXCIgfSB9O1xuXG5leHBvcnQgeyBidWlsZENpcmNsZSwgYnVpbGRFbGxpcHNlLCBidWlsZFJvdW5kZWRSZWN0YW5nbGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1aWxkQ2lyY2xlLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY29uc3QgY2xvc2VQb2ludEVwcyA9IDFlLTQ7XG5jb25zdCBjdXJ2ZUVwcyA9IDFlLTQ7XG5cbmV4cG9ydCB7IGNsb3NlUG9pbnRFcHMsIGN1cnZlRXBzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb25zdC5tanMubWFwXG4iLCJpbXBvcnQgeyBnZXRPcmllbnRhdGlvbk9mUG9pbnRzIH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvbWlzYy9nZXRPcmllbnRhdGlvbk9mUG9pbnRzLm1qcyc7XG5pbXBvcnQgeyBQb2ludCB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL3BvaW50L1BvaW50Lm1qcyc7XG5pbXBvcnQgeyBjbG9zZVBvaW50RXBzLCBjdXJ2ZUVwcyB9IGZyb20gJy4uL2NvbnN0Lm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gc3F1YXJlKHgsIHksIG54LCBueSwgaW5uZXJXZWlnaHQsIG91dGVyV2VpZ2h0LCBjbG9ja3dpc2UsIHZlcnRzKSB7XG4gIGNvbnN0IGl4ID0geCAtIG54ICogaW5uZXJXZWlnaHQ7XG4gIGNvbnN0IGl5ID0geSAtIG55ICogaW5uZXJXZWlnaHQ7XG4gIGNvbnN0IG94ID0geCArIG54ICogb3V0ZXJXZWlnaHQ7XG4gIGNvbnN0IG95ID0geSArIG55ICogb3V0ZXJXZWlnaHQ7XG4gIGxldCBleHg7XG4gIGxldCBleXk7XG4gIGlmIChjbG9ja3dpc2UpIHtcbiAgICBleHggPSBueTtcbiAgICBleXkgPSAtbng7XG4gIH0gZWxzZSB7XG4gICAgZXh4ID0gLW55O1xuICAgIGV5eSA9IG54O1xuICB9XG4gIGNvbnN0IGVpeCA9IGl4ICsgZXh4O1xuICBjb25zdCBlaXkgPSBpeSArIGV5eTtcbiAgY29uc3QgZW94ID0gb3ggKyBleHg7XG4gIGNvbnN0IGVveSA9IG95ICsgZXl5O1xuICB2ZXJ0cy5wdXNoKGVpeCwgZWl5KTtcbiAgdmVydHMucHVzaChlb3gsIGVveSk7XG4gIHJldHVybiAyO1xufVxuZnVuY3Rpb24gcm91bmQoY3gsIGN5LCBzeCwgc3ksIGV4LCBleSwgdmVydHMsIGNsb2Nrd2lzZSkge1xuICBjb25zdCBjeDJwMHggPSBzeCAtIGN4O1xuICBjb25zdCBjeTJwMHkgPSBzeSAtIGN5O1xuICBsZXQgYW5nbGUwID0gTWF0aC5hdGFuMihjeDJwMHgsIGN5MnAweSk7XG4gIGxldCBhbmdsZTEgPSBNYXRoLmF0YW4yKGV4IC0gY3gsIGV5IC0gY3kpO1xuICBpZiAoY2xvY2t3aXNlICYmIGFuZ2xlMCA8IGFuZ2xlMSkge1xuICAgIGFuZ2xlMCArPSBNYXRoLlBJICogMjtcbiAgfSBlbHNlIGlmICghY2xvY2t3aXNlICYmIGFuZ2xlMCA+IGFuZ2xlMSkge1xuICAgIGFuZ2xlMSArPSBNYXRoLlBJICogMjtcbiAgfVxuICBsZXQgc3RhcnRBbmdsZSA9IGFuZ2xlMDtcbiAgY29uc3QgYW5nbGVEaWZmID0gYW5nbGUxIC0gYW5nbGUwO1xuICBjb25zdCBhYnNBbmdsZURpZmYgPSBNYXRoLmFicyhhbmdsZURpZmYpO1xuICBjb25zdCByYWRpdXMgPSBNYXRoLnNxcnQoY3gycDB4ICogY3gycDB4ICsgY3kycDB5ICogY3kycDB5KTtcbiAgY29uc3Qgc2VnQ291bnQgPSAoMTUgKiBhYnNBbmdsZURpZmYgKiBNYXRoLnNxcnQocmFkaXVzKSAvIE1hdGguUEkgPj4gMCkgKyAxO1xuICBjb25zdCBhbmdsZUluYyA9IGFuZ2xlRGlmZiAvIHNlZ0NvdW50O1xuICBzdGFydEFuZ2xlICs9IGFuZ2xlSW5jO1xuICBpZiAoY2xvY2t3aXNlKSB7XG4gICAgdmVydHMucHVzaChjeCwgY3kpO1xuICAgIHZlcnRzLnB1c2goc3gsIHN5KTtcbiAgICBmb3IgKGxldCBpID0gMSwgYW5nbGUgPSBzdGFydEFuZ2xlOyBpIDwgc2VnQ291bnQ7IGkrKywgYW5nbGUgKz0gYW5nbGVJbmMpIHtcbiAgICAgIHZlcnRzLnB1c2goY3gsIGN5KTtcbiAgICAgIHZlcnRzLnB1c2goXG4gICAgICAgIGN4ICsgTWF0aC5zaW4oYW5nbGUpICogcmFkaXVzLFxuICAgICAgICBjeSArIE1hdGguY29zKGFuZ2xlKSAqIHJhZGl1c1xuICAgICAgKTtcbiAgICB9XG4gICAgdmVydHMucHVzaChjeCwgY3kpO1xuICAgIHZlcnRzLnB1c2goZXgsIGV5KTtcbiAgfSBlbHNlIHtcbiAgICB2ZXJ0cy5wdXNoKHN4LCBzeSk7XG4gICAgdmVydHMucHVzaChjeCwgY3kpO1xuICAgIGZvciAobGV0IGkgPSAxLCBhbmdsZSA9IHN0YXJ0QW5nbGU7IGkgPCBzZWdDb3VudDsgaSsrLCBhbmdsZSArPSBhbmdsZUluYykge1xuICAgICAgdmVydHMucHVzaChcbiAgICAgICAgY3ggKyBNYXRoLnNpbihhbmdsZSkgKiByYWRpdXMsXG4gICAgICAgIGN5ICsgTWF0aC5jb3MoYW5nbGUpICogcmFkaXVzXG4gICAgICApO1xuICAgICAgdmVydHMucHVzaChjeCwgY3kpO1xuICAgIH1cbiAgICB2ZXJ0cy5wdXNoKGV4LCBleSk7XG4gICAgdmVydHMucHVzaChjeCwgY3kpO1xuICB9XG4gIHJldHVybiBzZWdDb3VudCAqIDI7XG59XG5mdW5jdGlvbiBidWlsZExpbmUocG9pbnRzLCBsaW5lU3R5bGUsIGZsaXBBbGlnbm1lbnQsIGNsb3NlZCwgdmVydGljZXMsIGluZGljZXMpIHtcbiAgY29uc3QgZXBzID0gY2xvc2VQb2ludEVwcztcbiAgaWYgKHBvaW50cy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3Qgc3R5bGUgPSBsaW5lU3R5bGU7XG4gIGxldCBhbGlnbm1lbnQgPSBzdHlsZS5hbGlnbm1lbnQ7XG4gIGlmIChsaW5lU3R5bGUuYWxpZ25tZW50ICE9PSAwLjUpIHtcbiAgICBsZXQgb3JpZW50YXRpb24gPSBnZXRPcmllbnRhdGlvbk9mUG9pbnRzKHBvaW50cyk7XG4gICAgaWYgKGZsaXBBbGlnbm1lbnQpIG9yaWVudGF0aW9uICo9IC0xO1xuICAgIGFsaWdubWVudCA9IChhbGlnbm1lbnQgLSAwLjUpICogb3JpZW50YXRpb24gKyAwLjU7XG4gIH1cbiAgY29uc3QgZmlyc3RQb2ludCA9IG5ldyBQb2ludChwb2ludHNbMF0sIHBvaW50c1sxXSk7XG4gIGNvbnN0IGxhc3RQb2ludCA9IG5ldyBQb2ludChwb2ludHNbcG9pbnRzLmxlbmd0aCAtIDJdLCBwb2ludHNbcG9pbnRzLmxlbmd0aCAtIDFdKTtcbiAgY29uc3QgY2xvc2VkU2hhcGUgPSBjbG9zZWQ7XG4gIGNvbnN0IGNsb3NlZFBhdGggPSBNYXRoLmFicyhmaXJzdFBvaW50LnggLSBsYXN0UG9pbnQueCkgPCBlcHMgJiYgTWF0aC5hYnMoZmlyc3RQb2ludC55IC0gbGFzdFBvaW50LnkpIDwgZXBzO1xuICBpZiAoY2xvc2VkU2hhcGUpIHtcbiAgICBwb2ludHMgPSBwb2ludHMuc2xpY2UoKTtcbiAgICBpZiAoY2xvc2VkUGF0aCkge1xuICAgICAgcG9pbnRzLnBvcCgpO1xuICAgICAgcG9pbnRzLnBvcCgpO1xuICAgICAgbGFzdFBvaW50LnNldChwb2ludHNbcG9pbnRzLmxlbmd0aCAtIDJdLCBwb2ludHNbcG9pbnRzLmxlbmd0aCAtIDFdKTtcbiAgICB9XG4gICAgY29uc3QgbWlkUG9pbnRYID0gKGZpcnN0UG9pbnQueCArIGxhc3RQb2ludC54KSAqIDAuNTtcbiAgICBjb25zdCBtaWRQb2ludFkgPSAobGFzdFBvaW50LnkgKyBmaXJzdFBvaW50LnkpICogMC41O1xuICAgIHBvaW50cy51bnNoaWZ0KG1pZFBvaW50WCwgbWlkUG9pbnRZKTtcbiAgICBwb2ludHMucHVzaChtaWRQb2ludFgsIG1pZFBvaW50WSk7XG4gIH1cbiAgY29uc3QgdmVydHMgPSB2ZXJ0aWNlcztcbiAgY29uc3QgbGVuZ3RoID0gcG9pbnRzLmxlbmd0aCAvIDI7XG4gIGxldCBpbmRleENvdW50ID0gcG9pbnRzLmxlbmd0aDtcbiAgY29uc3QgaW5kZXhTdGFydCA9IHZlcnRzLmxlbmd0aCAvIDI7XG4gIGNvbnN0IHdpZHRoID0gc3R5bGUud2lkdGggLyAyO1xuICBjb25zdCB3aWR0aFNxdWFyZWQgPSB3aWR0aCAqIHdpZHRoO1xuICBjb25zdCBtaXRlckxpbWl0U3F1YXJlZCA9IHN0eWxlLm1pdGVyTGltaXQgKiBzdHlsZS5taXRlckxpbWl0O1xuICBsZXQgeDAgPSBwb2ludHNbMF07XG4gIGxldCB5MCA9IHBvaW50c1sxXTtcbiAgbGV0IHgxID0gcG9pbnRzWzJdO1xuICBsZXQgeTEgPSBwb2ludHNbM107XG4gIGxldCB4MiA9IDA7XG4gIGxldCB5MiA9IDA7XG4gIGxldCBwZXJwWCA9IC0oeTAgLSB5MSk7XG4gIGxldCBwZXJwWSA9IHgwIC0geDE7XG4gIGxldCBwZXJwMXggPSAwO1xuICBsZXQgcGVycDF5ID0gMDtcbiAgbGV0IGRpc3QgPSBNYXRoLnNxcnQocGVycFggKiBwZXJwWCArIHBlcnBZICogcGVycFkpO1xuICBwZXJwWCAvPSBkaXN0O1xuICBwZXJwWSAvPSBkaXN0O1xuICBwZXJwWCAqPSB3aWR0aDtcbiAgcGVycFkgKj0gd2lkdGg7XG4gIGNvbnN0IHJhdGlvID0gYWxpZ25tZW50O1xuICBjb25zdCBpbm5lcldlaWdodCA9ICgxIC0gcmF0aW8pICogMjtcbiAgY29uc3Qgb3V0ZXJXZWlnaHQgPSByYXRpbyAqIDI7XG4gIGlmICghY2xvc2VkU2hhcGUpIHtcbiAgICBpZiAoc3R5bGUuY2FwID09PSBcInJvdW5kXCIpIHtcbiAgICAgIGluZGV4Q291bnQgKz0gcm91bmQoXG4gICAgICAgIHgwIC0gcGVycFggKiAoaW5uZXJXZWlnaHQgLSBvdXRlcldlaWdodCkgKiAwLjUsXG4gICAgICAgIHkwIC0gcGVycFkgKiAoaW5uZXJXZWlnaHQgLSBvdXRlcldlaWdodCkgKiAwLjUsXG4gICAgICAgIHgwIC0gcGVycFggKiBpbm5lcldlaWdodCxcbiAgICAgICAgeTAgLSBwZXJwWSAqIGlubmVyV2VpZ2h0LFxuICAgICAgICB4MCArIHBlcnBYICogb3V0ZXJXZWlnaHQsXG4gICAgICAgIHkwICsgcGVycFkgKiBvdXRlcldlaWdodCxcbiAgICAgICAgdmVydHMsXG4gICAgICAgIHRydWVcbiAgICAgICkgKyAyO1xuICAgIH0gZWxzZSBpZiAoc3R5bGUuY2FwID09PSBcInNxdWFyZVwiKSB7XG4gICAgICBpbmRleENvdW50ICs9IHNxdWFyZSh4MCwgeTAsIHBlcnBYLCBwZXJwWSwgaW5uZXJXZWlnaHQsIG91dGVyV2VpZ2h0LCB0cnVlLCB2ZXJ0cyk7XG4gICAgfVxuICB9XG4gIHZlcnRzLnB1c2goXG4gICAgeDAgLSBwZXJwWCAqIGlubmVyV2VpZ2h0LFxuICAgIHkwIC0gcGVycFkgKiBpbm5lcldlaWdodFxuICApO1xuICB2ZXJ0cy5wdXNoKFxuICAgIHgwICsgcGVycFggKiBvdXRlcldlaWdodCxcbiAgICB5MCArIHBlcnBZICogb3V0ZXJXZWlnaHRcbiAgKTtcbiAgZm9yIChsZXQgaSA9IDE7IGkgPCBsZW5ndGggLSAxOyArK2kpIHtcbiAgICB4MCA9IHBvaW50c1soaSAtIDEpICogMl07XG4gICAgeTAgPSBwb2ludHNbKGkgLSAxKSAqIDIgKyAxXTtcbiAgICB4MSA9IHBvaW50c1tpICogMl07XG4gICAgeTEgPSBwb2ludHNbaSAqIDIgKyAxXTtcbiAgICB4MiA9IHBvaW50c1soaSArIDEpICogMl07XG4gICAgeTIgPSBwb2ludHNbKGkgKyAxKSAqIDIgKyAxXTtcbiAgICBwZXJwWCA9IC0oeTAgLSB5MSk7XG4gICAgcGVycFkgPSB4MCAtIHgxO1xuICAgIGRpc3QgPSBNYXRoLnNxcnQocGVycFggKiBwZXJwWCArIHBlcnBZICogcGVycFkpO1xuICAgIHBlcnBYIC89IGRpc3Q7XG4gICAgcGVycFkgLz0gZGlzdDtcbiAgICBwZXJwWCAqPSB3aWR0aDtcbiAgICBwZXJwWSAqPSB3aWR0aDtcbiAgICBwZXJwMXggPSAtKHkxIC0geTIpO1xuICAgIHBlcnAxeSA9IHgxIC0geDI7XG4gICAgZGlzdCA9IE1hdGguc3FydChwZXJwMXggKiBwZXJwMXggKyBwZXJwMXkgKiBwZXJwMXkpO1xuICAgIHBlcnAxeCAvPSBkaXN0O1xuICAgIHBlcnAxeSAvPSBkaXN0O1xuICAgIHBlcnAxeCAqPSB3aWR0aDtcbiAgICBwZXJwMXkgKj0gd2lkdGg7XG4gICAgY29uc3QgZHgwID0geDEgLSB4MDtcbiAgICBjb25zdCBkeTAgPSB5MCAtIHkxO1xuICAgIGNvbnN0IGR4MSA9IHgxIC0geDI7XG4gICAgY29uc3QgZHkxID0geTIgLSB5MTtcbiAgICBjb25zdCBkb3QgPSBkeDAgKiBkeDEgKyBkeTAgKiBkeTE7XG4gICAgY29uc3QgY3Jvc3MgPSBkeTAgKiBkeDEgLSBkeTEgKiBkeDA7XG4gICAgY29uc3QgY2xvY2t3aXNlID0gY3Jvc3MgPCAwO1xuICAgIGlmIChNYXRoLmFicyhjcm9zcykgPCAxZS0zICogTWF0aC5hYnMoZG90KSkge1xuICAgICAgdmVydHMucHVzaChcbiAgICAgICAgeDEgLSBwZXJwWCAqIGlubmVyV2VpZ2h0LFxuICAgICAgICB5MSAtIHBlcnBZICogaW5uZXJXZWlnaHRcbiAgICAgICk7XG4gICAgICB2ZXJ0cy5wdXNoKFxuICAgICAgICB4MSArIHBlcnBYICogb3V0ZXJXZWlnaHQsXG4gICAgICAgIHkxICsgcGVycFkgKiBvdXRlcldlaWdodFxuICAgICAgKTtcbiAgICAgIGlmIChkb3QgPj0gMCkge1xuICAgICAgICBpZiAoc3R5bGUuam9pbiA9PT0gXCJyb3VuZFwiKSB7XG4gICAgICAgICAgaW5kZXhDb3VudCArPSByb3VuZChcbiAgICAgICAgICAgIHgxLFxuICAgICAgICAgICAgeTEsXG4gICAgICAgICAgICB4MSAtIHBlcnBYICogaW5uZXJXZWlnaHQsXG4gICAgICAgICAgICB5MSAtIHBlcnBZICogaW5uZXJXZWlnaHQsXG4gICAgICAgICAgICB4MSAtIHBlcnAxeCAqIGlubmVyV2VpZ2h0LFxuICAgICAgICAgICAgeTEgLSBwZXJwMXkgKiBpbm5lcldlaWdodCxcbiAgICAgICAgICAgIHZlcnRzLFxuICAgICAgICAgICAgZmFsc2VcbiAgICAgICAgICApICsgNDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpbmRleENvdW50ICs9IDI7XG4gICAgICAgIH1cbiAgICAgICAgdmVydHMucHVzaChcbiAgICAgICAgICB4MSAtIHBlcnAxeCAqIG91dGVyV2VpZ2h0LFxuICAgICAgICAgIHkxIC0gcGVycDF5ICogb3V0ZXJXZWlnaHRcbiAgICAgICAgKTtcbiAgICAgICAgdmVydHMucHVzaChcbiAgICAgICAgICB4MSArIHBlcnAxeCAqIGlubmVyV2VpZ2h0LFxuICAgICAgICAgIHkxICsgcGVycDF5ICogaW5uZXJXZWlnaHRcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBjMSA9ICgtcGVycFggKyB4MCkgKiAoLXBlcnBZICsgeTEpIC0gKC1wZXJwWCArIHgxKSAqICgtcGVycFkgKyB5MCk7XG4gICAgY29uc3QgYzIgPSAoLXBlcnAxeCArIHgyKSAqICgtcGVycDF5ICsgeTEpIC0gKC1wZXJwMXggKyB4MSkgKiAoLXBlcnAxeSArIHkyKTtcbiAgICBjb25zdCBweCA9IChkeDAgKiBjMiAtIGR4MSAqIGMxKSAvIGNyb3NzO1xuICAgIGNvbnN0IHB5ID0gKGR5MSAqIGMxIC0gZHkwICogYzIpIC8gY3Jvc3M7XG4gICAgY29uc3QgcERpc3QgPSAocHggLSB4MSkgKiAocHggLSB4MSkgKyAocHkgLSB5MSkgKiAocHkgLSB5MSk7XG4gICAgY29uc3QgaW14ID0geDEgKyAocHggLSB4MSkgKiBpbm5lcldlaWdodDtcbiAgICBjb25zdCBpbXkgPSB5MSArIChweSAtIHkxKSAqIGlubmVyV2VpZ2h0O1xuICAgIGNvbnN0IG9teCA9IHgxIC0gKHB4IC0geDEpICogb3V0ZXJXZWlnaHQ7XG4gICAgY29uc3Qgb215ID0geTEgLSAocHkgLSB5MSkgKiBvdXRlcldlaWdodDtcbiAgICBjb25zdCBzbWFsbGVySW5zaWRlU2VnbWVudFNxID0gTWF0aC5taW4oZHgwICogZHgwICsgZHkwICogZHkwLCBkeDEgKiBkeDEgKyBkeTEgKiBkeTEpO1xuICAgIGNvbnN0IGluc2lkZVdlaWdodCA9IGNsb2Nrd2lzZSA/IGlubmVyV2VpZ2h0IDogb3V0ZXJXZWlnaHQ7XG4gICAgY29uc3Qgc21hbGxlckluc2lkZURpYWdvbmFsU3EgPSBzbWFsbGVySW5zaWRlU2VnbWVudFNxICsgaW5zaWRlV2VpZ2h0ICogaW5zaWRlV2VpZ2h0ICogd2lkdGhTcXVhcmVkO1xuICAgIGNvbnN0IGluc2lkZU1pdGVyT2sgPSBwRGlzdCA8PSBzbWFsbGVySW5zaWRlRGlhZ29uYWxTcTtcbiAgICBpZiAoaW5zaWRlTWl0ZXJPaykge1xuICAgICAgaWYgKHN0eWxlLmpvaW4gPT09IFwiYmV2ZWxcIiB8fCBwRGlzdCAvIHdpZHRoU3F1YXJlZCA+IG1pdGVyTGltaXRTcXVhcmVkKSB7XG4gICAgICAgIGlmIChjbG9ja3dpc2UpIHtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKGlteCwgaW15KTtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKHgxICsgcGVycFggKiBvdXRlcldlaWdodCwgeTEgKyBwZXJwWSAqIG91dGVyV2VpZ2h0KTtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKGlteCwgaW15KTtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKHgxICsgcGVycDF4ICogb3V0ZXJXZWlnaHQsIHkxICsgcGVycDF5ICogb3V0ZXJXZWlnaHQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZlcnRzLnB1c2goeDEgLSBwZXJwWCAqIGlubmVyV2VpZ2h0LCB5MSAtIHBlcnBZICogaW5uZXJXZWlnaHQpO1xuICAgICAgICAgIHZlcnRzLnB1c2gob214LCBvbXkpO1xuICAgICAgICAgIHZlcnRzLnB1c2goeDEgLSBwZXJwMXggKiBpbm5lcldlaWdodCwgeTEgLSBwZXJwMXkgKiBpbm5lcldlaWdodCk7XG4gICAgICAgICAgdmVydHMucHVzaChvbXgsIG9teSk7XG4gICAgICAgIH1cbiAgICAgICAgaW5kZXhDb3VudCArPSAyO1xuICAgICAgfSBlbHNlIGlmIChzdHlsZS5qb2luID09PSBcInJvdW5kXCIpIHtcbiAgICAgICAgaWYgKGNsb2Nrd2lzZSkge1xuICAgICAgICAgIHZlcnRzLnB1c2goaW14LCBpbXkpO1xuICAgICAgICAgIHZlcnRzLnB1c2goeDEgKyBwZXJwWCAqIG91dGVyV2VpZ2h0LCB5MSArIHBlcnBZICogb3V0ZXJXZWlnaHQpO1xuICAgICAgICAgIGluZGV4Q291bnQgKz0gcm91bmQoXG4gICAgICAgICAgICB4MSxcbiAgICAgICAgICAgIHkxLFxuICAgICAgICAgICAgeDEgKyBwZXJwWCAqIG91dGVyV2VpZ2h0LFxuICAgICAgICAgICAgeTEgKyBwZXJwWSAqIG91dGVyV2VpZ2h0LFxuICAgICAgICAgICAgeDEgKyBwZXJwMXggKiBvdXRlcldlaWdodCxcbiAgICAgICAgICAgIHkxICsgcGVycDF5ICogb3V0ZXJXZWlnaHQsXG4gICAgICAgICAgICB2ZXJ0cyxcbiAgICAgICAgICAgIHRydWVcbiAgICAgICAgICApICsgNDtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKGlteCwgaW15KTtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKHgxICsgcGVycDF4ICogb3V0ZXJXZWlnaHQsIHkxICsgcGVycDF5ICogb3V0ZXJXZWlnaHQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZlcnRzLnB1c2goeDEgLSBwZXJwWCAqIGlubmVyV2VpZ2h0LCB5MSAtIHBlcnBZICogaW5uZXJXZWlnaHQpO1xuICAgICAgICAgIHZlcnRzLnB1c2gob214LCBvbXkpO1xuICAgICAgICAgIGluZGV4Q291bnQgKz0gcm91bmQoXG4gICAgICAgICAgICB4MSxcbiAgICAgICAgICAgIHkxLFxuICAgICAgICAgICAgeDEgLSBwZXJwWCAqIGlubmVyV2VpZ2h0LFxuICAgICAgICAgICAgeTEgLSBwZXJwWSAqIGlubmVyV2VpZ2h0LFxuICAgICAgICAgICAgeDEgLSBwZXJwMXggKiBpbm5lcldlaWdodCxcbiAgICAgICAgICAgIHkxIC0gcGVycDF5ICogaW5uZXJXZWlnaHQsXG4gICAgICAgICAgICB2ZXJ0cyxcbiAgICAgICAgICAgIGZhbHNlXG4gICAgICAgICAgKSArIDQ7XG4gICAgICAgICAgdmVydHMucHVzaCh4MSAtIHBlcnAxeCAqIGlubmVyV2VpZ2h0LCB5MSAtIHBlcnAxeSAqIGlubmVyV2VpZ2h0KTtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKG9teCwgb215KTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmVydHMucHVzaChpbXgsIGlteSk7XG4gICAgICAgIHZlcnRzLnB1c2gob214LCBvbXkpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB2ZXJ0cy5wdXNoKHgxIC0gcGVycFggKiBpbm5lcldlaWdodCwgeTEgLSBwZXJwWSAqIGlubmVyV2VpZ2h0KTtcbiAgICAgIHZlcnRzLnB1c2goeDEgKyBwZXJwWCAqIG91dGVyV2VpZ2h0LCB5MSArIHBlcnBZICogb3V0ZXJXZWlnaHQpO1xuICAgICAgaWYgKHN0eWxlLmpvaW4gPT09IFwicm91bmRcIikge1xuICAgICAgICBpZiAoY2xvY2t3aXNlKSB7XG4gICAgICAgICAgaW5kZXhDb3VudCArPSByb3VuZChcbiAgICAgICAgICAgIHgxLFxuICAgICAgICAgICAgeTEsXG4gICAgICAgICAgICB4MSArIHBlcnBYICogb3V0ZXJXZWlnaHQsXG4gICAgICAgICAgICB5MSArIHBlcnBZICogb3V0ZXJXZWlnaHQsXG4gICAgICAgICAgICB4MSArIHBlcnAxeCAqIG91dGVyV2VpZ2h0LFxuICAgICAgICAgICAgeTEgKyBwZXJwMXkgKiBvdXRlcldlaWdodCxcbiAgICAgICAgICAgIHZlcnRzLFxuICAgICAgICAgICAgdHJ1ZVxuICAgICAgICAgICkgKyAyO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGluZGV4Q291bnQgKz0gcm91bmQoXG4gICAgICAgICAgICB4MSxcbiAgICAgICAgICAgIHkxLFxuICAgICAgICAgICAgeDEgLSBwZXJwWCAqIGlubmVyV2VpZ2h0LFxuICAgICAgICAgICAgeTEgLSBwZXJwWSAqIGlubmVyV2VpZ2h0LFxuICAgICAgICAgICAgeDEgLSBwZXJwMXggKiBpbm5lcldlaWdodCxcbiAgICAgICAgICAgIHkxIC0gcGVycDF5ICogaW5uZXJXZWlnaHQsXG4gICAgICAgICAgICB2ZXJ0cyxcbiAgICAgICAgICAgIGZhbHNlXG4gICAgICAgICAgKSArIDI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoc3R5bGUuam9pbiA9PT0gXCJtaXRlclwiICYmIHBEaXN0IC8gd2lkdGhTcXVhcmVkIDw9IG1pdGVyTGltaXRTcXVhcmVkKSB7XG4gICAgICAgIGlmIChjbG9ja3dpc2UpIHtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKG9teCwgb215KTtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKG9teCwgb215KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKGlteCwgaW15KTtcbiAgICAgICAgICB2ZXJ0cy5wdXNoKGlteCwgaW15KTtcbiAgICAgICAgfVxuICAgICAgICBpbmRleENvdW50ICs9IDI7XG4gICAgICB9XG4gICAgICB2ZXJ0cy5wdXNoKHgxIC0gcGVycDF4ICogaW5uZXJXZWlnaHQsIHkxIC0gcGVycDF5ICogaW5uZXJXZWlnaHQpO1xuICAgICAgdmVydHMucHVzaCh4MSArIHBlcnAxeCAqIG91dGVyV2VpZ2h0LCB5MSArIHBlcnAxeSAqIG91dGVyV2VpZ2h0KTtcbiAgICAgIGluZGV4Q291bnQgKz0gMjtcbiAgICB9XG4gIH1cbiAgeDAgPSBwb2ludHNbKGxlbmd0aCAtIDIpICogMl07XG4gIHkwID0gcG9pbnRzWyhsZW5ndGggLSAyKSAqIDIgKyAxXTtcbiAgeDEgPSBwb2ludHNbKGxlbmd0aCAtIDEpICogMl07XG4gIHkxID0gcG9pbnRzWyhsZW5ndGggLSAxKSAqIDIgKyAxXTtcbiAgcGVycFggPSAtKHkwIC0geTEpO1xuICBwZXJwWSA9IHgwIC0geDE7XG4gIGRpc3QgPSBNYXRoLnNxcnQocGVycFggKiBwZXJwWCArIHBlcnBZICogcGVycFkpO1xuICBwZXJwWCAvPSBkaXN0O1xuICBwZXJwWSAvPSBkaXN0O1xuICBwZXJwWCAqPSB3aWR0aDtcbiAgcGVycFkgKj0gd2lkdGg7XG4gIHZlcnRzLnB1c2goeDEgLSBwZXJwWCAqIGlubmVyV2VpZ2h0LCB5MSAtIHBlcnBZICogaW5uZXJXZWlnaHQpO1xuICB2ZXJ0cy5wdXNoKHgxICsgcGVycFggKiBvdXRlcldlaWdodCwgeTEgKyBwZXJwWSAqIG91dGVyV2VpZ2h0KTtcbiAgaWYgKCFjbG9zZWRTaGFwZSkge1xuICAgIGlmIChzdHlsZS5jYXAgPT09IFwicm91bmRcIikge1xuICAgICAgaW5kZXhDb3VudCArPSByb3VuZChcbiAgICAgICAgeDEgLSBwZXJwWCAqIChpbm5lcldlaWdodCAtIG91dGVyV2VpZ2h0KSAqIDAuNSxcbiAgICAgICAgeTEgLSBwZXJwWSAqIChpbm5lcldlaWdodCAtIG91dGVyV2VpZ2h0KSAqIDAuNSxcbiAgICAgICAgeDEgLSBwZXJwWCAqIGlubmVyV2VpZ2h0LFxuICAgICAgICB5MSAtIHBlcnBZICogaW5uZXJXZWlnaHQsXG4gICAgICAgIHgxICsgcGVycFggKiBvdXRlcldlaWdodCxcbiAgICAgICAgeTEgKyBwZXJwWSAqIG91dGVyV2VpZ2h0LFxuICAgICAgICB2ZXJ0cyxcbiAgICAgICAgZmFsc2VcbiAgICAgICkgKyAyO1xuICAgIH0gZWxzZSBpZiAoc3R5bGUuY2FwID09PSBcInNxdWFyZVwiKSB7XG4gICAgICBpbmRleENvdW50ICs9IHNxdWFyZSh4MSwgeTEsIHBlcnBYLCBwZXJwWSwgaW5uZXJXZWlnaHQsIG91dGVyV2VpZ2h0LCBmYWxzZSwgdmVydHMpO1xuICAgIH1cbiAgfVxuICBjb25zdCBlcHMyID0gY3VydmVFcHMgKiBjdXJ2ZUVwcztcbiAgZm9yIChsZXQgaSA9IGluZGV4U3RhcnQ7IGkgPCBpbmRleENvdW50ICsgaW5kZXhTdGFydCAtIDI7ICsraSkge1xuICAgIHgwID0gdmVydHNbaSAqIDJdO1xuICAgIHkwID0gdmVydHNbaSAqIDIgKyAxXTtcbiAgICB4MSA9IHZlcnRzWyhpICsgMSkgKiAyXTtcbiAgICB5MSA9IHZlcnRzWyhpICsgMSkgKiAyICsgMV07XG4gICAgeDIgPSB2ZXJ0c1soaSArIDIpICogMl07XG4gICAgeTIgPSB2ZXJ0c1soaSArIDIpICogMiArIDFdO1xuICAgIGlmIChNYXRoLmFicyh4MCAqICh5MSAtIHkyKSArIHgxICogKHkyIC0geTApICsgeDIgKiAoeTAgLSB5MSkpIDwgZXBzMikge1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGluZGljZXMucHVzaChpLCBpICsgMSwgaSArIDIpO1xuICB9XG59XG5cbmV4cG9ydCB7IGJ1aWxkTGluZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVpbGRMaW5lLm1qcy5tYXBcbiIsImltcG9ydCB7IGNsb3NlUG9pbnRFcHMgfSBmcm9tICcuLi9jb25zdC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGJ1aWxkUGl4ZWxMaW5lKHBvaW50cywgY2xvc2VkLCB2ZXJ0aWNlcywgaW5kaWNlcykge1xuICBjb25zdCBlcHMgPSBjbG9zZVBvaW50RXBzO1xuICBpZiAocG9pbnRzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBmeCA9IHBvaW50c1swXTtcbiAgY29uc3QgZnkgPSBwb2ludHNbMV07XG4gIGNvbnN0IGx4ID0gcG9pbnRzW3BvaW50cy5sZW5ndGggLSAyXTtcbiAgY29uc3QgbHkgPSBwb2ludHNbcG9pbnRzLmxlbmd0aCAtIDFdO1xuICBjb25zdCBjbG9zZVBhdGggPSBjbG9zZWQgfHwgTWF0aC5hYnMoZnggLSBseCkgPCBlcHMgJiYgTWF0aC5hYnMoZnkgLSBseSkgPCBlcHM7XG4gIGNvbnN0IHZlcnRzID0gdmVydGljZXM7XG4gIGNvbnN0IGxlbmd0aCA9IHBvaW50cy5sZW5ndGggLyAyO1xuICBjb25zdCBpbmRleFN0YXJ0ID0gdmVydHMubGVuZ3RoIC8gMjtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgIHZlcnRzLnB1c2gocG9pbnRzW2kgKiAyXSk7XG4gICAgdmVydHMucHVzaChwb2ludHNbaSAqIDIgKyAxXSk7XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGggLSAxOyBpKyspIHtcbiAgICBpbmRpY2VzLnB1c2goaW5kZXhTdGFydCArIGksIGluZGV4U3RhcnQgKyBpICsgMSk7XG4gIH1cbiAgaWYgKGNsb3NlUGF0aCkge1xuICAgIGluZGljZXMucHVzaChpbmRleFN0YXJ0ICsgbGVuZ3RoIC0gMSwgaW5kZXhTdGFydCk7XG4gIH1cbn1cblxuZXhwb3J0IHsgYnVpbGRQaXhlbExpbmUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1aWxkUGl4ZWxMaW5lLm1qcy5tYXBcbiIsImltcG9ydCB7IGVhcmN1dCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL3V0aWxzLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gdHJpYW5ndWxhdGVXaXRoSG9sZXMocG9pbnRzLCBob2xlcywgdmVydGljZXMsIHZlcnRpY2VzU3RyaWRlLCB2ZXJ0aWNlc09mZnNldCwgaW5kaWNlcywgaW5kaWNlc09mZnNldCkge1xuICBjb25zdCB0cmlhbmdsZXMgPSBlYXJjdXQocG9pbnRzLCBob2xlcywgMik7XG4gIGlmICghdHJpYW5nbGVzKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdHJpYW5nbGVzLmxlbmd0aDsgaSArPSAzKSB7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gdHJpYW5nbGVzW2ldICsgdmVydGljZXNPZmZzZXQ7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gdHJpYW5nbGVzW2kgKyAxXSArIHZlcnRpY2VzT2Zmc2V0O1xuICAgIGluZGljZXNbaW5kaWNlc09mZnNldCsrXSA9IHRyaWFuZ2xlc1tpICsgMl0gKyB2ZXJ0aWNlc09mZnNldDtcbiAgfVxuICBsZXQgaW5kZXggPSB2ZXJ0aWNlc09mZnNldCAqIHZlcnRpY2VzU3RyaWRlO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHBvaW50cy5sZW5ndGg7IGkgKz0gMikge1xuICAgIHZlcnRpY2VzW2luZGV4XSA9IHBvaW50c1tpXTtcbiAgICB2ZXJ0aWNlc1tpbmRleCArIDFdID0gcG9pbnRzW2kgKyAxXTtcbiAgICBpbmRleCArPSB2ZXJ0aWNlc1N0cmlkZTtcbiAgfVxufVxuXG5leHBvcnQgeyB0cmlhbmd1bGF0ZVdpdGhIb2xlcyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dHJpYW5ndWxhdGVXaXRoSG9sZXMubWpzLm1hcFxuIiwiaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgdHJpYW5ndWxhdGVXaXRoSG9sZXMgfSBmcm9tICcuLi91dGlscy90cmlhbmd1bGF0ZVdpdGhIb2xlcy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IGVtcHR5QXJyYXkgPSBbXTtcbmNvbnN0IGJ1aWxkUG9seWdvbiA9IHtcbiAgZXh0ZW5zaW9uOiB7XG4gICAgdHlwZTogRXh0ZW5zaW9uVHlwZS5TaGFwZUJ1aWxkZXIsXG4gICAgbmFtZTogXCJwb2x5Z29uXCJcbiAgfSxcbiAgYnVpbGQoc2hhcGUsIHBvaW50cykge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2hhcGUucG9pbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBwb2ludHNbaV0gPSBzaGFwZS5wb2ludHNbaV07XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9LFxuICB0cmlhbmd1bGF0ZShwb2ludHMsIHZlcnRpY2VzLCB2ZXJ0aWNlc1N0cmlkZSwgdmVydGljZXNPZmZzZXQsIGluZGljZXMsIGluZGljZXNPZmZzZXQpIHtcbiAgICB0cmlhbmd1bGF0ZVdpdGhIb2xlcyhwb2ludHMsIGVtcHR5QXJyYXksIHZlcnRpY2VzLCB2ZXJ0aWNlc1N0cmlkZSwgdmVydGljZXNPZmZzZXQsIGluZGljZXMsIGluZGljZXNPZmZzZXQpO1xuICB9XG59O1xuXG5leHBvcnQgeyBidWlsZFBvbHlnb24gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1aWxkUG9seWdvbi5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgYnVpbGRSZWN0YW5nbGUgPSB7XG4gIGV4dGVuc2lvbjoge1xuICAgIHR5cGU6IEV4dGVuc2lvblR5cGUuU2hhcGVCdWlsZGVyLFxuICAgIG5hbWU6IFwicmVjdGFuZ2xlXCJcbiAgfSxcbiAgYnVpbGQoc2hhcGUsIHBvaW50cykge1xuICAgIGNvbnN0IHJlY3REYXRhID0gc2hhcGU7XG4gICAgY29uc3QgeCA9IHJlY3REYXRhLng7XG4gICAgY29uc3QgeSA9IHJlY3REYXRhLnk7XG4gICAgY29uc3Qgd2lkdGggPSByZWN0RGF0YS53aWR0aDtcbiAgICBjb25zdCBoZWlnaHQgPSByZWN0RGF0YS5oZWlnaHQ7XG4gICAgaWYgKCEod2lkdGggPiAwICYmIGhlaWdodCA+IDApKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHBvaW50c1swXSA9IHg7XG4gICAgcG9pbnRzWzFdID0geTtcbiAgICBwb2ludHNbMl0gPSB4ICsgd2lkdGg7XG4gICAgcG9pbnRzWzNdID0geTtcbiAgICBwb2ludHNbNF0gPSB4ICsgd2lkdGg7XG4gICAgcG9pbnRzWzVdID0geSArIGhlaWdodDtcbiAgICBwb2ludHNbNl0gPSB4O1xuICAgIHBvaW50c1s3XSA9IHkgKyBoZWlnaHQ7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIHRyaWFuZ3VsYXRlKHBvaW50cywgdmVydGljZXMsIHZlcnRpY2VzU3RyaWRlLCB2ZXJ0aWNlc09mZnNldCwgaW5kaWNlcywgaW5kaWNlc09mZnNldCkge1xuICAgIGxldCBjb3VudCA9IDA7XG4gICAgdmVydGljZXNPZmZzZXQgKj0gdmVydGljZXNTdHJpZGU7XG4gICAgdmVydGljZXNbdmVydGljZXNPZmZzZXQgKyBjb3VudF0gPSBwb2ludHNbMF07XG4gICAgdmVydGljZXNbdmVydGljZXNPZmZzZXQgKyBjb3VudCArIDFdID0gcG9pbnRzWzFdO1xuICAgIGNvdW50ICs9IHZlcnRpY2VzU3RyaWRlO1xuICAgIHZlcnRpY2VzW3ZlcnRpY2VzT2Zmc2V0ICsgY291bnRdID0gcG9pbnRzWzJdO1xuICAgIHZlcnRpY2VzW3ZlcnRpY2VzT2Zmc2V0ICsgY291bnQgKyAxXSA9IHBvaW50c1szXTtcbiAgICBjb3VudCArPSB2ZXJ0aWNlc1N0cmlkZTtcbiAgICB2ZXJ0aWNlc1t2ZXJ0aWNlc09mZnNldCArIGNvdW50XSA9IHBvaW50c1s2XTtcbiAgICB2ZXJ0aWNlc1t2ZXJ0aWNlc09mZnNldCArIGNvdW50ICsgMV0gPSBwb2ludHNbN107XG4gICAgY291bnQgKz0gdmVydGljZXNTdHJpZGU7XG4gICAgdmVydGljZXNbdmVydGljZXNPZmZzZXQgKyBjb3VudF0gPSBwb2ludHNbNF07XG4gICAgdmVydGljZXNbdmVydGljZXNPZmZzZXQgKyBjb3VudCArIDFdID0gcG9pbnRzWzVdO1xuICAgIGNvdW50ICs9IHZlcnRpY2VzU3RyaWRlO1xuICAgIGNvbnN0IHZlcnRpY2VzSW5kZXggPSB2ZXJ0aWNlc09mZnNldCAvIHZlcnRpY2VzU3RyaWRlO1xuICAgIGluZGljZXNbaW5kaWNlc09mZnNldCsrXSA9IHZlcnRpY2VzSW5kZXg7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gdmVydGljZXNJbmRleCArIDE7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gdmVydGljZXNJbmRleCArIDI7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gdmVydGljZXNJbmRleCArIDE7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gdmVydGljZXNJbmRleCArIDM7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gdmVydGljZXNJbmRleCArIDI7XG4gIH1cbn07XG5cbmV4cG9ydCB7IGJ1aWxkUmVjdGFuZ2xlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1idWlsZFJlY3RhbmdsZS5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgYnVpbGRUcmlhbmdsZSA9IHtcbiAgZXh0ZW5zaW9uOiB7XG4gICAgdHlwZTogRXh0ZW5zaW9uVHlwZS5TaGFwZUJ1aWxkZXIsXG4gICAgbmFtZTogXCJ0cmlhbmdsZVwiXG4gIH0sXG4gIGJ1aWxkKHNoYXBlLCBwb2ludHMpIHtcbiAgICBwb2ludHNbMF0gPSBzaGFwZS54O1xuICAgIHBvaW50c1sxXSA9IHNoYXBlLnk7XG4gICAgcG9pbnRzWzJdID0gc2hhcGUueDI7XG4gICAgcG9pbnRzWzNdID0gc2hhcGUueTI7XG4gICAgcG9pbnRzWzRdID0gc2hhcGUueDM7XG4gICAgcG9pbnRzWzVdID0gc2hhcGUueTM7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIHRyaWFuZ3VsYXRlKHBvaW50cywgdmVydGljZXMsIHZlcnRpY2VzU3RyaWRlLCB2ZXJ0aWNlc09mZnNldCwgaW5kaWNlcywgaW5kaWNlc09mZnNldCkge1xuICAgIGxldCBjb3VudCA9IDA7XG4gICAgdmVydGljZXNPZmZzZXQgKj0gdmVydGljZXNTdHJpZGU7XG4gICAgdmVydGljZXNbdmVydGljZXNPZmZzZXQgKyBjb3VudF0gPSBwb2ludHNbMF07XG4gICAgdmVydGljZXNbdmVydGljZXNPZmZzZXQgKyBjb3VudCArIDFdID0gcG9pbnRzWzFdO1xuICAgIGNvdW50ICs9IHZlcnRpY2VzU3RyaWRlO1xuICAgIHZlcnRpY2VzW3ZlcnRpY2VzT2Zmc2V0ICsgY291bnRdID0gcG9pbnRzWzJdO1xuICAgIHZlcnRpY2VzW3ZlcnRpY2VzT2Zmc2V0ICsgY291bnQgKyAxXSA9IHBvaW50c1szXTtcbiAgICBjb3VudCArPSB2ZXJ0aWNlc1N0cmlkZTtcbiAgICB2ZXJ0aWNlc1t2ZXJ0aWNlc09mZnNldCArIGNvdW50XSA9IHBvaW50c1s0XTtcbiAgICB2ZXJ0aWNlc1t2ZXJ0aWNlc09mZnNldCArIGNvdW50ICsgMV0gPSBwb2ludHNbNV07XG4gICAgY29uc3QgdmVydGljZXNJbmRleCA9IHZlcnRpY2VzT2Zmc2V0IC8gdmVydGljZXNTdHJpZGU7XG4gICAgaW5kaWNlc1tpbmRpY2VzT2Zmc2V0KytdID0gdmVydGljZXNJbmRleDtcbiAgICBpbmRpY2VzW2luZGljZXNPZmZzZXQrK10gPSB2ZXJ0aWNlc0luZGV4ICsgMTtcbiAgICBpbmRpY2VzW2luZGljZXNPZmZzZXQrK10gPSB2ZXJ0aWNlc0luZGV4ICsgMjtcbiAgfVxufTtcblxuZXhwb3J0IHsgYnVpbGRUcmlhbmdsZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVpbGRUcmlhbmdsZS5tanMubWFwXG4iLCJpbXBvcnQgeyBDb2xvciB9IGZyb20gJy4uLy4uLy4uLy4uL2NvbG9yL0NvbG9yLm1qcyc7XG5pbXBvcnQgeyBET01BZGFwdGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vZW52aXJvbm1lbnQvYWRhcHRlci5tanMnO1xuaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgSW1hZ2VTb3VyY2UgfSBmcm9tICcuLi8uLi8uLi8uLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL3NvdXJjZXMvSW1hZ2VTb3VyY2UubWpzJztcbmltcG9ydCB7IFRleHR1cmUgfSBmcm9tICcuLi8uLi8uLi8uLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL1RleHR1cmUubWpzJztcbmltcG9ydCB7IHVpZCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGEvdWlkLm1qcyc7XG5pbXBvcnQgeyBkZXByZWNhdGlvbiB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2xvZ2dpbmcvZGVwcmVjYXRpb24ubWpzJztcbmltcG9ydCB7IGRlZmluZWRQcm9wcyB9IGZyb20gJy4uLy4uLy4uL2NvbnRhaW5lci91dGlscy9kZWZpbmVkUHJvcHMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBlbXB0eUNvbG9yU3RvcHMgPSBbeyBvZmZzZXQ6IDAsIGNvbG9yOiBcIndoaXRlXCIgfSwgeyBvZmZzZXQ6IDEsIGNvbG9yOiBcImJsYWNrXCIgfV07XG5jb25zdCBfRmlsbEdyYWRpZW50ID0gY2xhc3MgX0ZpbGxHcmFkaWVudCB7XG4gIGNvbnN0cnVjdG9yKC4uLmFyZ3MpIHtcbiAgICAvKipcbiAgICAgKiBVbmlxdWUgaWRlbnRpZmllciBmb3IgdGhpcyBncmFkaWVudCBpbnN0YW5jZVxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMudWlkID0gdWlkKFwiZmlsbEdyYWRpZW50XCIpO1xuICAgIC8qKlxuICAgICAqIEludGVybmFsIHRpY2sgY291bnRlciB0byB0cmFjayBjaGFuZ2VzIGluIHRoZSBncmFkaWVudC5cbiAgICAgKiBUaGlzIGlzIHVzZWQgdG8gaW52YWxpZGF0ZSB0aGUgZ3JhZGllbnQgd2hlbiB0aGUgdGV4dHVyZSBjaGFuZ2VzLlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX3RpY2sgPSAwO1xuICAgIC8qKiBUeXBlIG9mIGdyYWRpZW50IC0gY3VycmVudGx5IG9ubHkgc3VwcG9ydHMgJ2xpbmVhcicgKi9cbiAgICB0aGlzLnR5cGUgPSBcImxpbmVhclwiO1xuICAgIC8qKiBBcnJheSBvZiBjb2xvciBzdG9wcyBkZWZpbmluZyB0aGUgZ3JhZGllbnQgKi9cbiAgICB0aGlzLmNvbG9yU3RvcHMgPSBbXTtcbiAgICBsZXQgb3B0aW9ucyA9IGVuc3VyZUdyYWRpZW50T3B0aW9ucyhhcmdzKTtcbiAgICBjb25zdCBkZWZhdWx0cyA9IG9wdGlvbnMudHlwZSA9PT0gXCJyYWRpYWxcIiA/IF9GaWxsR3JhZGllbnQuZGVmYXVsdFJhZGlhbE9wdGlvbnMgOiBfRmlsbEdyYWRpZW50LmRlZmF1bHRMaW5lYXJPcHRpb25zO1xuICAgIG9wdGlvbnMgPSB7IC4uLmRlZmF1bHRzLCAuLi5kZWZpbmVkUHJvcHMob3B0aW9ucykgfTtcbiAgICB0aGlzLl90ZXh0dXJlU2l6ZSA9IG9wdGlvbnMudGV4dHVyZVNpemU7XG4gICAgdGhpcy5fd3JhcE1vZGUgPSBvcHRpb25zLndyYXBNb2RlO1xuICAgIGlmIChvcHRpb25zLnR5cGUgPT09IFwicmFkaWFsXCIpIHtcbiAgICAgIHRoaXMuY2VudGVyID0gb3B0aW9ucy5jZW50ZXI7XG4gICAgICB0aGlzLm91dGVyQ2VudGVyID0gb3B0aW9ucy5vdXRlckNlbnRlciA/PyB0aGlzLmNlbnRlcjtcbiAgICAgIHRoaXMuaW5uZXJSYWRpdXMgPSBvcHRpb25zLmlubmVyUmFkaXVzO1xuICAgICAgdGhpcy5vdXRlclJhZGl1cyA9IG9wdGlvbnMub3V0ZXJSYWRpdXM7XG4gICAgICB0aGlzLnNjYWxlID0gb3B0aW9ucy5zY2FsZTtcbiAgICAgIHRoaXMucm90YXRpb24gPSBvcHRpb25zLnJvdGF0aW9uO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnN0YXJ0ID0gb3B0aW9ucy5zdGFydDtcbiAgICAgIHRoaXMuZW5kID0gb3B0aW9ucy5lbmQ7XG4gICAgfVxuICAgIHRoaXMudGV4dHVyZVNwYWNlID0gb3B0aW9ucy50ZXh0dXJlU3BhY2U7XG4gICAgdGhpcy50eXBlID0gb3B0aW9ucy50eXBlO1xuICAgIG9wdGlvbnMuY29sb3JTdG9wcy5mb3JFYWNoKChzdG9wKSA9PiB7XG4gICAgICB0aGlzLmFkZENvbG9yU3RvcChzdG9wLm9mZnNldCwgc3RvcC5jb2xvcik7XG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYSBjb2xvciBzdG9wIHRvIHRoZSBncmFkaWVudFxuICAgKiBAcGFyYW0gb2Zmc2V0IC0gUG9zaXRpb24gb2YgdGhlIHN0b3AgKDAtMSlcbiAgICogQHBhcmFtIGNvbG9yIC0gQ29sb3Igb2YgdGhlIHN0b3BcbiAgICogQHJldHVybnMgVGhpcyBncmFkaWVudCBpbnN0YW5jZSBmb3IgY2hhaW5pbmdcbiAgICovXG4gIGFkZENvbG9yU3RvcChvZmZzZXQsIGNvbG9yKSB7XG4gICAgdGhpcy5jb2xvclN0b3BzLnB1c2goeyBvZmZzZXQsIGNvbG9yOiBDb2xvci5zaGFyZWQuc2V0VmFsdWUoY29sb3IpLnRvSGV4YSgpIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBCdWlsZHMgdGhlIGludGVybmFsIHRleHR1cmUgYW5kIHRyYW5zZm9ybSBmb3IgdGhlIGdyYWRpZW50LlxuICAgKiBDYWxsZWQgYXV0b21hdGljYWxseSB3aGVuIHRoZSBncmFkaWVudCBpcyBmaXJzdCB1c2VkLlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGJ1aWxkTGluZWFyR3JhZGllbnQoKSB7XG4gICAgaWYgKHRoaXMudGV4dHVyZSkgcmV0dXJuO1xuICAgIGxldCB7IHg6IHgwLCB5OiB5MCB9ID0gdGhpcy5zdGFydDtcbiAgICBsZXQgeyB4OiB4MSwgeTogeTEgfSA9IHRoaXMuZW5kO1xuICAgIGxldCBkeCA9IHgxIC0geDA7XG4gICAgbGV0IGR5ID0geTEgLSB5MDtcbiAgICBjb25zdCBmbGlwID0gZHggPCAwIHx8IGR5IDwgMDtcbiAgICBpZiAodGhpcy5fd3JhcE1vZGUgPT09IFwiY2xhbXAtdG8tZWRnZVwiKSB7XG4gICAgICBpZiAoZHggPCAwKSB7XG4gICAgICAgIGNvbnN0IHRlbXAgPSB4MDtcbiAgICAgICAgeDAgPSB4MTtcbiAgICAgICAgeDEgPSB0ZW1wO1xuICAgICAgICBkeCAqPSAtMTtcbiAgICAgIH1cbiAgICAgIGlmIChkeSA8IDApIHtcbiAgICAgICAgY29uc3QgdGVtcCA9IHkwO1xuICAgICAgICB5MCA9IHkxO1xuICAgICAgICB5MSA9IHRlbXA7XG4gICAgICAgIGR5ICo9IC0xO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBjb2xvclN0b3BzID0gdGhpcy5jb2xvclN0b3BzLmxlbmd0aCA/IHRoaXMuY29sb3JTdG9wcyA6IGVtcHR5Q29sb3JTdG9wcztcbiAgICBjb25zdCBkZWZhdWx0U2l6ZSA9IHRoaXMuX3RleHR1cmVTaXplO1xuICAgIGNvbnN0IHsgY2FudmFzLCBjb250ZXh0IH0gPSBnZXRDYW52YXMoZGVmYXVsdFNpemUsIDEpO1xuICAgIGNvbnN0IGdyYWRpZW50ID0gIWZsaXAgPyBjb250ZXh0LmNyZWF0ZUxpbmVhckdyYWRpZW50KDAsIDAsIHRoaXMuX3RleHR1cmVTaXplLCAwKSA6IGNvbnRleHQuY3JlYXRlTGluZWFyR3JhZGllbnQodGhpcy5fdGV4dHVyZVNpemUsIDAsIDAsIDApO1xuICAgIGFkZENvbG9yU3RvcHMoZ3JhZGllbnQsIGNvbG9yU3RvcHMpO1xuICAgIGNvbnRleHQuZmlsbFN0eWxlID0gZ3JhZGllbnQ7XG4gICAgY29udGV4dC5maWxsUmVjdCgwLCAwLCBkZWZhdWx0U2l6ZSwgMSk7XG4gICAgdGhpcy50ZXh0dXJlID0gbmV3IFRleHR1cmUoe1xuICAgICAgc291cmNlOiBuZXcgSW1hZ2VTb3VyY2Uoe1xuICAgICAgICByZXNvdXJjZTogY2FudmFzLFxuICAgICAgICBhZGRyZXNzTW9kZTogdGhpcy5fd3JhcE1vZGVcbiAgICAgIH0pXG4gICAgfSk7XG4gICAgY29uc3QgZGlzdCA9IE1hdGguc3FydChkeCAqIGR4ICsgZHkgKiBkeSk7XG4gICAgY29uc3QgYW5nbGUgPSBNYXRoLmF0YW4yKGR5LCBkeCk7XG4gICAgY29uc3QgbSA9IG5ldyBNYXRyaXgoKTtcbiAgICBtLnNjYWxlKGRpc3QgLyBkZWZhdWx0U2l6ZSwgMSk7XG4gICAgbS5yb3RhdGUoYW5nbGUpO1xuICAgIG0udHJhbnNsYXRlKHgwLCB5MCk7XG4gICAgaWYgKHRoaXMudGV4dHVyZVNwYWNlID09PSBcImxvY2FsXCIpIHtcbiAgICAgIG0uc2NhbGUoZGVmYXVsdFNpemUsIGRlZmF1bHRTaXplKTtcbiAgICB9XG4gICAgdGhpcy50cmFuc2Zvcm0gPSBtO1xuICB9XG4gIC8qKlxuICAgKiBCdWlsZHMgdGhlIGludGVybmFsIHRleHR1cmUgYW5kIHRyYW5zZm9ybSBmb3IgdGhlIGdyYWRpZW50LlxuICAgKiBDYWxsZWQgYXV0b21hdGljYWxseSB3aGVuIHRoZSBncmFkaWVudCBpcyBmaXJzdCB1c2VkLlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGJ1aWxkR3JhZGllbnQoKSB7XG4gICAgaWYgKCF0aGlzLnRleHR1cmUpIHRoaXMuX3RpY2srKztcbiAgICBpZiAodGhpcy50eXBlID09PSBcImxpbmVhclwiKSB7XG4gICAgICB0aGlzLmJ1aWxkTGluZWFyR3JhZGllbnQoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5idWlsZFJhZGlhbEdyYWRpZW50KCk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBCdWlsZHMgdGhlIGludGVybmFsIHRleHR1cmUgYW5kIHRyYW5zZm9ybSBmb3IgdGhlIHJhZGlhbCBncmFkaWVudC5cbiAgICogQ2FsbGVkIGF1dG9tYXRpY2FsbHkgd2hlbiB0aGUgZ3JhZGllbnQgaXMgZmlyc3QgdXNlZC5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBidWlsZFJhZGlhbEdyYWRpZW50KCkge1xuICAgIGlmICh0aGlzLnRleHR1cmUpIHJldHVybjtcbiAgICBjb25zdCBjb2xvclN0b3BzID0gdGhpcy5jb2xvclN0b3BzLmxlbmd0aCA/IHRoaXMuY29sb3JTdG9wcyA6IGVtcHR5Q29sb3JTdG9wcztcbiAgICBjb25zdCBkZWZhdWx0U2l6ZSA9IHRoaXMuX3RleHR1cmVTaXplO1xuICAgIGNvbnN0IHsgY2FudmFzLCBjb250ZXh0IH0gPSBnZXRDYW52YXMoZGVmYXVsdFNpemUsIGRlZmF1bHRTaXplKTtcbiAgICBjb25zdCB7IHg6IHgwLCB5OiB5MCB9ID0gdGhpcy5jZW50ZXI7XG4gICAgY29uc3QgeyB4OiB4MSwgeTogeTEgfSA9IHRoaXMub3V0ZXJDZW50ZXI7XG4gICAgY29uc3QgcjAgPSB0aGlzLmlubmVyUmFkaXVzO1xuICAgIGNvbnN0IHIxID0gdGhpcy5vdXRlclJhZGl1cztcbiAgICBjb25zdCBveCA9IHgxIC0gcjE7XG4gICAgY29uc3Qgb3kgPSB5MSAtIHIxO1xuICAgIGNvbnN0IHNjYWxlID0gZGVmYXVsdFNpemUgLyAocjEgKiAyKTtcbiAgICBjb25zdCBjeCA9ICh4MCAtIG94KSAqIHNjYWxlO1xuICAgIGNvbnN0IGN5ID0gKHkwIC0gb3kpICogc2NhbGU7XG4gICAgY29uc3QgZ3JhZGllbnQgPSBjb250ZXh0LmNyZWF0ZVJhZGlhbEdyYWRpZW50KFxuICAgICAgY3gsXG4gICAgICBjeSxcbiAgICAgIHIwICogc2NhbGUsXG4gICAgICAoeDEgLSBveCkgKiBzY2FsZSxcbiAgICAgICh5MSAtIG95KSAqIHNjYWxlLFxuICAgICAgcjEgKiBzY2FsZVxuICAgICk7XG4gICAgYWRkQ29sb3JTdG9wcyhncmFkaWVudCwgY29sb3JTdG9wcyk7XG4gICAgY29udGV4dC5maWxsU3R5bGUgPSBjb2xvclN0b3BzW2NvbG9yU3RvcHMubGVuZ3RoIC0gMV0uY29sb3I7XG4gICAgY29udGV4dC5maWxsUmVjdCgwLCAwLCBkZWZhdWx0U2l6ZSwgZGVmYXVsdFNpemUpO1xuICAgIGNvbnRleHQuZmlsbFN0eWxlID0gZ3JhZGllbnQ7XG4gICAgY29udGV4dC50cmFuc2xhdGUoY3gsIGN5KTtcbiAgICBjb250ZXh0LnJvdGF0ZSh0aGlzLnJvdGF0aW9uKTtcbiAgICBjb250ZXh0LnNjYWxlKDEsIHRoaXMuc2NhbGUpO1xuICAgIGNvbnRleHQudHJhbnNsYXRlKC1jeCwgLWN5KTtcbiAgICBjb250ZXh0LmZpbGxSZWN0KDAsIDAsIGRlZmF1bHRTaXplLCBkZWZhdWx0U2l6ZSk7XG4gICAgdGhpcy50ZXh0dXJlID0gbmV3IFRleHR1cmUoe1xuICAgICAgc291cmNlOiBuZXcgSW1hZ2VTb3VyY2Uoe1xuICAgICAgICByZXNvdXJjZTogY2FudmFzLFxuICAgICAgICBhZGRyZXNzTW9kZTogdGhpcy5fd3JhcE1vZGVcbiAgICAgIH0pXG4gICAgfSk7XG4gICAgY29uc3QgbSA9IG5ldyBNYXRyaXgoKTtcbiAgICBpZiAodGhpcy50ZXh0dXJlU3BhY2UgPT09IFwibG9jYWxcIikge1xuICAgICAgbS5zY2FsZSgyICogcjEsIDIgKiByMSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG0uc2NhbGUoMSAvIHNjYWxlLCAxIC8gc2NhbGUpO1xuICAgIH1cbiAgICBtLnRyYW5zbGF0ZShveCwgb3kpO1xuICAgIHRoaXMudHJhbnNmb3JtID0gbTtcbiAgfVxuICAvKiogRGVzdHJveXMgdGhlIGdyYWRpZW50LCByZWxlYXNpbmcgcmVzb3VyY2VzLiBUaGlzIHdpbGwgYWxzbyBkZXN0cm95IHRoZSBpbnRlcm5hbCB0ZXh0dXJlLiAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMudGV4dHVyZT8uZGVzdHJveSh0cnVlKTtcbiAgICB0aGlzLnRleHR1cmUgPSBudWxsO1xuICAgIHRoaXMudHJhbnNmb3JtID0gbnVsbDtcbiAgICB0aGlzLmNvbG9yU3RvcHMgPSBbXTtcbiAgICB0aGlzLnN0YXJ0ID0gbnVsbDtcbiAgICB0aGlzLmVuZCA9IG51bGw7XG4gICAgdGhpcy5jZW50ZXIgPSBudWxsO1xuICAgIHRoaXMub3V0ZXJDZW50ZXIgPSBudWxsO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgdW5pcXVlIGtleSBmb3IgdGhpcyBncmFkaWVudCBpbnN0YW5jZS5cbiAgICogVGhpcyBrZXkgaXMgdXNlZCBmb3IgY2FjaGluZyBhbmQgdGV4dHVyZSBtYW5hZ2VtZW50LlxuICAgKiBAcmV0dXJucyB7c3RyaW5nfSBVbmlxdWUga2V5IGZvciB0aGUgZ3JhZGllbnRcbiAgICovXG4gIGdldCBzdHlsZUtleSgpIHtcbiAgICByZXR1cm4gYGZpbGwtZ3JhZGllbnQtJHt0aGlzLnVpZH0tJHt0aGlzLl90aWNrfWA7XG4gIH1cbn07XG4vKiogRGVmYXVsdCBvcHRpb25zIGZvciBjcmVhdGluZyBhIGdyYWRpZW50IGZpbGwgKi9cbl9GaWxsR3JhZGllbnQuZGVmYXVsdExpbmVhck9wdGlvbnMgPSB7XG4gIHN0YXJ0OiB7IHg6IDAsIHk6IDAgfSxcbiAgZW5kOiB7IHg6IDAsIHk6IDEgfSxcbiAgY29sb3JTdG9wczogW10sXG4gIHRleHR1cmVTcGFjZTogXCJsb2NhbFwiLFxuICB0eXBlOiBcImxpbmVhclwiLFxuICB0ZXh0dXJlU2l6ZTogMjU2LFxuICB3cmFwTW9kZTogXCJjbGFtcC10by1lZGdlXCJcbn07XG4vKiogRGVmYXVsdCBvcHRpb25zIGZvciBjcmVhdGluZyBhIHJhZGlhbCBncmFkaWVudCBmaWxsICovXG5fRmlsbEdyYWRpZW50LmRlZmF1bHRSYWRpYWxPcHRpb25zID0ge1xuICBjZW50ZXI6IHsgeDogMC41LCB5OiAwLjUgfSxcbiAgaW5uZXJSYWRpdXM6IDAsXG4gIG91dGVyUmFkaXVzOiAwLjUsXG4gIGNvbG9yU3RvcHM6IFtdLFxuICBzY2FsZTogMSxcbiAgcm90YXRpb246IDAsXG4gIHRleHR1cmVTcGFjZTogXCJsb2NhbFwiLFxuICB0eXBlOiBcInJhZGlhbFwiLFxuICB0ZXh0dXJlU2l6ZTogMjU2LFxuICB3cmFwTW9kZTogXCJjbGFtcC10by1lZGdlXCJcbn07XG5sZXQgRmlsbEdyYWRpZW50ID0gX0ZpbGxHcmFkaWVudDtcbmZ1bmN0aW9uIGFkZENvbG9yU3RvcHMoZ3JhZGllbnQsIGNvbG9yU3RvcHMpIHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb2xvclN0b3BzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3Qgc3RvcCA9IGNvbG9yU3RvcHNbaV07XG4gICAgZ3JhZGllbnQuYWRkQ29sb3JTdG9wKHN0b3Aub2Zmc2V0LCBzdG9wLmNvbG9yKTtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0Q2FudmFzKHdpZHRoLCBoZWlnaHQpIHtcbiAgY29uc3QgY2FudmFzID0gRE9NQWRhcHRlci5nZXQoKS5jcmVhdGVDYW52YXMod2lkdGgsIGhlaWdodCk7XG4gIGNvbnN0IGNvbnRleHQgPSBjYW52YXMuZ2V0Q29udGV4dChcIjJkXCIpO1xuICByZXR1cm4geyBjYW52YXMsIGNvbnRleHQgfTtcbn1cbmZ1bmN0aW9uIGVuc3VyZUdyYWRpZW50T3B0aW9ucyhhcmdzKSB7XG4gIGxldCBvcHRpb25zID0gYXJnc1swXSA/PyB7fTtcbiAgaWYgKHR5cGVvZiBvcHRpb25zID09PSBcIm51bWJlclwiIHx8IGFyZ3NbMV0pIHtcbiAgICBkZXByZWNhdGlvbihcIjguNS4yXCIsIGB1c2Ugb3B0aW9ucyBvYmplY3QgaW5zdGVhZGApO1xuICAgIG9wdGlvbnMgPSB7XG4gICAgICB0eXBlOiBcImxpbmVhclwiLFxuICAgICAgc3RhcnQ6IHsgeDogYXJnc1swXSwgeTogYXJnc1sxXSB9LFxuICAgICAgZW5kOiB7IHg6IGFyZ3NbMl0sIHk6IGFyZ3NbM10gfSxcbiAgICAgIHRleHR1cmVTcGFjZTogYXJnc1s0XSxcbiAgICAgIHRleHR1cmVTaXplOiBhcmdzWzVdID8/IEZpbGxHcmFkaWVudC5kZWZhdWx0TGluZWFyT3B0aW9ucy50ZXh0dXJlU2l6ZVxuICAgIH07XG4gIH1cbiAgcmV0dXJuIG9wdGlvbnM7XG59XG5cbmV4cG9ydCB7IEZpbGxHcmFkaWVudCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9RmlsbEdyYWRpZW50Lm1qcy5tYXBcbiIsImltcG9ydCB7IE1hdHJpeCB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL21hdHJpeC9NYXRyaXgubWpzJztcbmltcG9ydCB7IFJlY3RhbmdsZSB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL3NoYXBlcy9SZWN0YW5nbGUubWpzJztcbmltcG9ydCB7IEZpbGxHcmFkaWVudCB9IGZyb20gJy4uL2ZpbGwvRmlsbEdyYWRpZW50Lm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgdGVtcFRleHR1cmVNYXRyaXggPSBuZXcgTWF0cml4KCk7XG5jb25zdCB0ZW1wUmVjdCA9IG5ldyBSZWN0YW5nbGUoKTtcbmNvbnN0IHRlbXBVdk1hdHJpeCA9IG5ldyBNYXRyaXgoKTtcbmZ1bmN0aW9uIGdlbmVyYXRlVGV4dHVyZU1hdHJpeChvdXQsIHN0eWxlLCBzaGFwZSwgbWF0cml4KSB7XG4gIGNvbnN0IHRleHR1cmVNYXRyaXggPSBzdHlsZS5tYXRyaXggPyBvdXQuY29weUZyb20oc3R5bGUubWF0cml4KS5pbnZlcnQoKSA6IG91dC5pZGVudGl0eSgpO1xuICBpZiAoc3R5bGUudGV4dHVyZVNwYWNlID09PSBcImxvY2FsXCIpIHtcbiAgICBjb25zdCBib3VuZHMgPSBzaGFwZS5nZXRCb3VuZHModGVtcFJlY3QpO1xuICAgIGlmIChzdHlsZS53aWR0aCkge1xuICAgICAgYm91bmRzLnBhZChzdHlsZS53aWR0aCk7XG4gICAgfVxuICAgIGNvbnN0IHsgeDogdHgsIHk6IHR5IH0gPSBib3VuZHM7XG4gICAgY29uc3Qgc3ggPSAxIC8gYm91bmRzLndpZHRoO1xuICAgIGNvbnN0IHN5ID0gMSAvIGJvdW5kcy5oZWlnaHQ7XG4gICAgY29uc3QgbVR4ID0gLXR4ICogc3g7XG4gICAgY29uc3QgbVR5ID0gLXR5ICogc3k7XG4gICAgY29uc3QgYTEgPSB0ZXh0dXJlTWF0cml4LmE7XG4gICAgY29uc3QgYjEgPSB0ZXh0dXJlTWF0cml4LmI7XG4gICAgY29uc3QgYzEgPSB0ZXh0dXJlTWF0cml4LmM7XG4gICAgY29uc3QgZDEgPSB0ZXh0dXJlTWF0cml4LmQ7XG4gICAgdGV4dHVyZU1hdHJpeC5hICo9IHN4O1xuICAgIHRleHR1cmVNYXRyaXguYiAqPSBzeDtcbiAgICB0ZXh0dXJlTWF0cml4LmMgKj0gc3k7XG4gICAgdGV4dHVyZU1hdHJpeC5kICo9IHN5O1xuICAgIHRleHR1cmVNYXRyaXgudHggPSBtVHggKiBhMSArIG1UeSAqIGMxICsgdGV4dHVyZU1hdHJpeC50eDtcbiAgICB0ZXh0dXJlTWF0cml4LnR5ID0gbVR4ICogYjEgKyBtVHkgKiBkMSArIHRleHR1cmVNYXRyaXgudHk7XG4gIH0gZWxzZSBpZiAoc3R5bGUudGV4dHVyZS5yb3RhdGUpIHtcbiAgICBjb25zdCB7IHV2cywgb3JpZyB9ID0gc3R5bGUudGV4dHVyZTtcbiAgICB0ZXh0dXJlTWF0cml4LnNjYWxlKDEgLyBvcmlnLndpZHRoLCAxIC8gb3JpZy5oZWlnaHQpO1xuICAgIHRleHR1cmVNYXRyaXgucHJlcGVuZCh0ZW1wVXZNYXRyaXguc2V0KFxuICAgICAgdXZzLngxIC0gdXZzLngwLFxuICAgICAgdXZzLnkxIC0gdXZzLnkwLFxuICAgICAgdXZzLngzIC0gdXZzLngwLFxuICAgICAgdXZzLnkzIC0gdXZzLnkwLFxuICAgICAgdXZzLngwLFxuICAgICAgdXZzLnkwXG4gICAgKSk7XG4gIH0gZWxzZSB7XG4gICAgdGV4dHVyZU1hdHJpeC50cmFuc2xhdGUoc3R5bGUudGV4dHVyZS5mcmFtZS54LCBzdHlsZS50ZXh0dXJlLmZyYW1lLnkpO1xuICAgIHRleHR1cmVNYXRyaXguc2NhbGUoMSAvIHN0eWxlLnRleHR1cmUuc291cmNlLndpZHRoLCAxIC8gc3R5bGUudGV4dHVyZS5zb3VyY2UuaGVpZ2h0KTtcbiAgfVxuICBjb25zdCBzb3VyY2VTdHlsZSA9IHN0eWxlLnRleHR1cmUuc291cmNlLnN0eWxlO1xuICBpZiAoIShzdHlsZS5maWxsIGluc3RhbmNlb2YgRmlsbEdyYWRpZW50KSAmJiBzb3VyY2VTdHlsZS5hZGRyZXNzTW9kZSA9PT0gXCJjbGFtcC10by1lZGdlXCIpIHtcbiAgICBzb3VyY2VTdHlsZS5hZGRyZXNzTW9kZSA9IFwicmVwZWF0XCI7XG4gICAgc291cmNlU3R5bGUudXBkYXRlKCk7XG4gIH1cbiAgaWYgKG1hdHJpeCkge1xuICAgIHRleHR1cmVNYXRyaXguYXBwZW5kKHRlbXBUZXh0dXJlTWF0cml4LmNvcHlGcm9tKG1hdHJpeCkuaW52ZXJ0KCkpO1xuICB9XG4gIHJldHVybiB0ZXh0dXJlTWF0cml4O1xufVxuXG5leHBvcnQgeyBnZW5lcmF0ZVRleHR1cmVNYXRyaXggfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdlbmVyYXRlVGV4dHVyZUZpbGxNYXRyaXgubWpzLm1hcFxuIiwiaW1wb3J0IHsgZXh0ZW5zaW9ucywgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgUmVjdGFuZ2xlIH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvc2hhcGVzL1JlY3RhbmdsZS5tanMnO1xuaW1wb3J0IHsgYnVpbGRVdnMsIGJ1aWxkU2ltcGxlVXZzIH0gZnJvbSAnLi4vLi4vLi4vLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvZ2VvbWV0cnkvdXRpbHMvYnVpbGRVdnMubWpzJztcbmltcG9ydCB7IHRyYW5zZm9ybVZlcnRpY2VzIH0gZnJvbSAnLi4vLi4vLi4vLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvZ2VvbWV0cnkvdXRpbHMvdHJhbnNmb3JtVmVydGljZXMubWpzJztcbmltcG9ydCB7IFRleHR1cmUgfSBmcm9tICcuLi8uLi8uLi8uLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL1RleHR1cmUubWpzJztcbmltcG9ydCB7IEJpZ1Bvb2wgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9wb29sL1Bvb2xHcm91cC5tanMnO1xuaW1wb3J0IHsgQmF0Y2hhYmxlR3JhcGhpY3MgfSBmcm9tICcuLi9CYXRjaGFibGVHcmFwaGljcy5tanMnO1xuaW1wb3J0IHsgYnVpbGRDaXJjbGUsIGJ1aWxkRWxsaXBzZSwgYnVpbGRSb3VuZGVkUmVjdGFuZ2xlIH0gZnJvbSAnLi4vYnVpbGRDb21tYW5kcy9idWlsZENpcmNsZS5tanMnO1xuaW1wb3J0IHsgYnVpbGRMaW5lIH0gZnJvbSAnLi4vYnVpbGRDb21tYW5kcy9idWlsZExpbmUubWpzJztcbmltcG9ydCB7IGJ1aWxkUGl4ZWxMaW5lIH0gZnJvbSAnLi4vYnVpbGRDb21tYW5kcy9idWlsZFBpeGVsTGluZS5tanMnO1xuaW1wb3J0IHsgYnVpbGRQb2x5Z29uIH0gZnJvbSAnLi4vYnVpbGRDb21tYW5kcy9idWlsZFBvbHlnb24ubWpzJztcbmltcG9ydCB7IGJ1aWxkUmVjdGFuZ2xlIH0gZnJvbSAnLi4vYnVpbGRDb21tYW5kcy9idWlsZFJlY3RhbmdsZS5tanMnO1xuaW1wb3J0IHsgYnVpbGRUcmlhbmdsZSB9IGZyb20gJy4uL2J1aWxkQ29tbWFuZHMvYnVpbGRUcmlhbmdsZS5tanMnO1xuaW1wb3J0IHsgZ2VuZXJhdGVUZXh0dXJlTWF0cml4IH0gZnJvbSAnLi9nZW5lcmF0ZVRleHR1cmVGaWxsTWF0cml4Lm1qcyc7XG5pbXBvcnQgeyB0cmlhbmd1bGF0ZVdpdGhIb2xlcyB9IGZyb20gJy4vdHJpYW5ndWxhdGVXaXRoSG9sZXMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBzaGFwZUJ1aWxkZXJzID0ge307XG5leHRlbnNpb25zLmhhbmRsZUJ5TWFwKEV4dGVuc2lvblR5cGUuU2hhcGVCdWlsZGVyLCBzaGFwZUJ1aWxkZXJzKTtcbmV4dGVuc2lvbnMuYWRkKGJ1aWxkUmVjdGFuZ2xlLCBidWlsZFBvbHlnb24sIGJ1aWxkVHJpYW5nbGUsIGJ1aWxkQ2lyY2xlLCBidWlsZEVsbGlwc2UsIGJ1aWxkUm91bmRlZFJlY3RhbmdsZSk7XG5jb25zdCB0ZW1wUmVjdCA9IG5ldyBSZWN0YW5nbGUoKTtcbmNvbnN0IHRlbXBUZXh0dXJlTWF0cml4ID0gbmV3IE1hdHJpeCgpO1xuZnVuY3Rpb24gYnVpbGRDb250ZXh0QmF0Y2hlcyhjb250ZXh0LCBncHVDb250ZXh0KSB7XG4gIGNvbnN0IHsgZ2VvbWV0cnlEYXRhLCBiYXRjaGVzIH0gPSBncHVDb250ZXh0O1xuICBiYXRjaGVzLmxlbmd0aCA9IDA7XG4gIGdlb21ldHJ5RGF0YS5pbmRpY2VzLmxlbmd0aCA9IDA7XG4gIGdlb21ldHJ5RGF0YS52ZXJ0aWNlcy5sZW5ndGggPSAwO1xuICBnZW9tZXRyeURhdGEudXZzLmxlbmd0aCA9IDA7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgY29udGV4dC5pbnN0cnVjdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBpbnN0cnVjdGlvbiA9IGNvbnRleHQuaW5zdHJ1Y3Rpb25zW2ldO1xuICAgIGlmIChpbnN0cnVjdGlvbi5hY3Rpb24gPT09IFwidGV4dHVyZVwiKSB7XG4gICAgICBhZGRUZXh0dXJlVG9HZW9tZXRyeURhdGEoaW5zdHJ1Y3Rpb24uZGF0YSwgYmF0Y2hlcywgZ2VvbWV0cnlEYXRhKTtcbiAgICB9IGVsc2UgaWYgKGluc3RydWN0aW9uLmFjdGlvbiA9PT0gXCJmaWxsXCIgfHwgaW5zdHJ1Y3Rpb24uYWN0aW9uID09PSBcInN0cm9rZVwiKSB7XG4gICAgICBjb25zdCBpc1N0cm9rZSA9IGluc3RydWN0aW9uLmFjdGlvbiA9PT0gXCJzdHJva2VcIjtcbiAgICAgIGNvbnN0IHNoYXBlUGF0aCA9IGluc3RydWN0aW9uLmRhdGEucGF0aC5zaGFwZVBhdGg7XG4gICAgICBjb25zdCBzdHlsZSA9IGluc3RydWN0aW9uLmRhdGEuc3R5bGU7XG4gICAgICBjb25zdCBob2xlID0gaW5zdHJ1Y3Rpb24uZGF0YS5ob2xlO1xuICAgICAgaWYgKGlzU3Ryb2tlICYmIGhvbGUpIHtcbiAgICAgICAgYWRkU2hhcGVQYXRoVG9HZW9tZXRyeURhdGEoaG9sZS5zaGFwZVBhdGgsIHN0eWxlLCB0cnVlLCBiYXRjaGVzLCBnZW9tZXRyeURhdGEpO1xuICAgICAgfVxuICAgICAgaWYgKGhvbGUpIHtcbiAgICAgICAgc2hhcGVQYXRoLnNoYXBlUHJpbWl0aXZlc1tzaGFwZVBhdGguc2hhcGVQcmltaXRpdmVzLmxlbmd0aCAtIDFdLmhvbGVzID0gaG9sZS5zaGFwZVBhdGguc2hhcGVQcmltaXRpdmVzO1xuICAgICAgfVxuICAgICAgYWRkU2hhcGVQYXRoVG9HZW9tZXRyeURhdGEoc2hhcGVQYXRoLCBzdHlsZSwgaXNTdHJva2UsIGJhdGNoZXMsIGdlb21ldHJ5RGF0YSk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBhZGRUZXh0dXJlVG9HZW9tZXRyeURhdGEoZGF0YSwgYmF0Y2hlcywgZ2VvbWV0cnlEYXRhKSB7XG4gIGNvbnN0IHBvaW50cyA9IFtdO1xuICBjb25zdCBidWlsZCA9IHNoYXBlQnVpbGRlcnMucmVjdGFuZ2xlO1xuICBjb25zdCByZWN0ID0gdGVtcFJlY3Q7XG4gIHJlY3QueCA9IGRhdGEuZHg7XG4gIHJlY3QueSA9IGRhdGEuZHk7XG4gIHJlY3Qud2lkdGggPSBkYXRhLmR3O1xuICByZWN0LmhlaWdodCA9IGRhdGEuZGg7XG4gIGNvbnN0IG1hdHJpeCA9IGRhdGEudHJhbnNmb3JtO1xuICBpZiAoIWJ1aWxkLmJ1aWxkKHJlY3QsIHBvaW50cykpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgeyB2ZXJ0aWNlcywgdXZzLCBpbmRpY2VzIH0gPSBnZW9tZXRyeURhdGE7XG4gIGNvbnN0IGluZGV4T2Zmc2V0ID0gaW5kaWNlcy5sZW5ndGg7XG4gIGNvbnN0IHZlcnRPZmZzZXQgPSB2ZXJ0aWNlcy5sZW5ndGggLyAyO1xuICBpZiAobWF0cml4KSB7XG4gICAgdHJhbnNmb3JtVmVydGljZXMocG9pbnRzLCBtYXRyaXgpO1xuICB9XG4gIGJ1aWxkLnRyaWFuZ3VsYXRlKHBvaW50cywgdmVydGljZXMsIDIsIHZlcnRPZmZzZXQsIGluZGljZXMsIGluZGV4T2Zmc2V0KTtcbiAgY29uc3QgdGV4dHVyZSA9IGRhdGEuaW1hZ2U7XG4gIGNvbnN0IHRleHR1cmVVdnMgPSB0ZXh0dXJlLnV2cztcbiAgdXZzLnB1c2goXG4gICAgdGV4dHVyZVV2cy54MCxcbiAgICB0ZXh0dXJlVXZzLnkwLFxuICAgIHRleHR1cmVVdnMueDEsXG4gICAgdGV4dHVyZVV2cy55MSxcbiAgICB0ZXh0dXJlVXZzLngzLFxuICAgIHRleHR1cmVVdnMueTMsXG4gICAgdGV4dHVyZVV2cy54MixcbiAgICB0ZXh0dXJlVXZzLnkyXG4gICk7XG4gIGNvbnN0IGdyYXBoaWNzQmF0Y2ggPSBCaWdQb29sLmdldChCYXRjaGFibGVHcmFwaGljcyk7XG4gIGdyYXBoaWNzQmF0Y2guaW5kZXhPZmZzZXQgPSBpbmRleE9mZnNldDtcbiAgZ3JhcGhpY3NCYXRjaC5pbmRleFNpemUgPSBpbmRpY2VzLmxlbmd0aCAtIGluZGV4T2Zmc2V0O1xuICBncmFwaGljc0JhdGNoLmF0dHJpYnV0ZU9mZnNldCA9IHZlcnRPZmZzZXQ7XG4gIGdyYXBoaWNzQmF0Y2guYXR0cmlidXRlU2l6ZSA9IHZlcnRpY2VzLmxlbmd0aCAvIDIgLSB2ZXJ0T2Zmc2V0O1xuICBncmFwaGljc0JhdGNoLmJhc2VDb2xvciA9IGRhdGEuc3R5bGU7XG4gIGdyYXBoaWNzQmF0Y2guYWxwaGEgPSBkYXRhLmFscGhhO1xuICBncmFwaGljc0JhdGNoLnRleHR1cmUgPSB0ZXh0dXJlO1xuICBncmFwaGljc0JhdGNoLmdlb21ldHJ5RGF0YSA9IGdlb21ldHJ5RGF0YTtcbiAgYmF0Y2hlcy5wdXNoKGdyYXBoaWNzQmF0Y2gpO1xufVxuZnVuY3Rpb24gYWRkU2hhcGVQYXRoVG9HZW9tZXRyeURhdGEoc2hhcGVQYXRoLCBzdHlsZSwgaXNTdHJva2UsIGJhdGNoZXMsIGdlb21ldHJ5RGF0YSkge1xuICBjb25zdCB7IHZlcnRpY2VzLCB1dnMsIGluZGljZXMgfSA9IGdlb21ldHJ5RGF0YTtcbiAgc2hhcGVQYXRoLnNoYXBlUHJpbWl0aXZlcy5mb3JFYWNoKCh7IHNoYXBlLCB0cmFuc2Zvcm06IG1hdHJpeCwgaG9sZXMgfSkgPT4ge1xuICAgIGNvbnN0IHBvaW50cyA9IFtdO1xuICAgIGNvbnN0IGJ1aWxkID0gc2hhcGVCdWlsZGVyc1tzaGFwZS50eXBlXTtcbiAgICBpZiAoIWJ1aWxkLmJ1aWxkKHNoYXBlLCBwb2ludHMpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGluZGV4T2Zmc2V0ID0gaW5kaWNlcy5sZW5ndGg7XG4gICAgY29uc3QgdmVydE9mZnNldCA9IHZlcnRpY2VzLmxlbmd0aCAvIDI7XG4gICAgbGV0IHRvcG9sb2d5ID0gXCJ0cmlhbmdsZS1saXN0XCI7XG4gICAgaWYgKG1hdHJpeCkge1xuICAgICAgdHJhbnNmb3JtVmVydGljZXMocG9pbnRzLCBtYXRyaXgpO1xuICAgIH1cbiAgICBpZiAoIWlzU3Ryb2tlKSB7XG4gICAgICBpZiAoaG9sZXMpIHtcbiAgICAgICAgY29uc3QgaG9sZUluZGljZXMgPSBbXTtcbiAgICAgICAgY29uc3Qgb3RoZXJQb2ludHMgPSBwb2ludHMuc2xpY2UoKTtcbiAgICAgICAgY29uc3QgaG9sZUFycmF5cyA9IGdldEhvbGVBcnJheXMoaG9sZXMpO1xuICAgICAgICBob2xlQXJyYXlzLmZvckVhY2goKGhvbGVQb2ludHMpID0+IHtcbiAgICAgICAgICBob2xlSW5kaWNlcy5wdXNoKG90aGVyUG9pbnRzLmxlbmd0aCAvIDIpO1xuICAgICAgICAgIG90aGVyUG9pbnRzLnB1c2goLi4uaG9sZVBvaW50cyk7XG4gICAgICAgIH0pO1xuICAgICAgICB0cmlhbmd1bGF0ZVdpdGhIb2xlcyhvdGhlclBvaW50cywgaG9sZUluZGljZXMsIHZlcnRpY2VzLCAyLCB2ZXJ0T2Zmc2V0LCBpbmRpY2VzLCBpbmRleE9mZnNldCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBidWlsZC50cmlhbmd1bGF0ZShwb2ludHMsIHZlcnRpY2VzLCAyLCB2ZXJ0T2Zmc2V0LCBpbmRpY2VzLCBpbmRleE9mZnNldCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGNsb3NlID0gc2hhcGUuY2xvc2VQYXRoID8/IHRydWU7XG4gICAgICBjb25zdCBsaW5lU3R5bGUgPSBzdHlsZTtcbiAgICAgIGlmICghbGluZVN0eWxlLnBpeGVsTGluZSkge1xuICAgICAgICBidWlsZExpbmUocG9pbnRzLCBsaW5lU3R5bGUsIGZhbHNlLCBjbG9zZSwgdmVydGljZXMsIGluZGljZXMpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYnVpbGRQaXhlbExpbmUocG9pbnRzLCBjbG9zZSwgdmVydGljZXMsIGluZGljZXMpO1xuICAgICAgICB0b3BvbG9neSA9IFwibGluZS1saXN0XCI7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHV2c09mZnNldCA9IHV2cy5sZW5ndGggLyAyO1xuICAgIGNvbnN0IHRleHR1cmUgPSBzdHlsZS50ZXh0dXJlO1xuICAgIGlmICh0ZXh0dXJlICE9PSBUZXh0dXJlLldISVRFKSB7XG4gICAgICBjb25zdCB0ZXh0dXJlTWF0cml4ID0gZ2VuZXJhdGVUZXh0dXJlTWF0cml4KHRlbXBUZXh0dXJlTWF0cml4LCBzdHlsZSwgc2hhcGUsIG1hdHJpeCk7XG4gICAgICBidWlsZFV2cyh2ZXJ0aWNlcywgMiwgdmVydE9mZnNldCwgdXZzLCB1dnNPZmZzZXQsIDIsIHZlcnRpY2VzLmxlbmd0aCAvIDIgLSB2ZXJ0T2Zmc2V0LCB0ZXh0dXJlTWF0cml4KTtcbiAgICB9IGVsc2Uge1xuICAgICAgYnVpbGRTaW1wbGVVdnModXZzLCB1dnNPZmZzZXQsIDIsIHZlcnRpY2VzLmxlbmd0aCAvIDIgLSB2ZXJ0T2Zmc2V0KTtcbiAgICB9XG4gICAgY29uc3QgZ3JhcGhpY3NCYXRjaCA9IEJpZ1Bvb2wuZ2V0KEJhdGNoYWJsZUdyYXBoaWNzKTtcbiAgICBncmFwaGljc0JhdGNoLmluZGV4T2Zmc2V0ID0gaW5kZXhPZmZzZXQ7XG4gICAgZ3JhcGhpY3NCYXRjaC5pbmRleFNpemUgPSBpbmRpY2VzLmxlbmd0aCAtIGluZGV4T2Zmc2V0O1xuICAgIGdyYXBoaWNzQmF0Y2guYXR0cmlidXRlT2Zmc2V0ID0gdmVydE9mZnNldDtcbiAgICBncmFwaGljc0JhdGNoLmF0dHJpYnV0ZVNpemUgPSB2ZXJ0aWNlcy5sZW5ndGggLyAyIC0gdmVydE9mZnNldDtcbiAgICBncmFwaGljc0JhdGNoLmJhc2VDb2xvciA9IHN0eWxlLmNvbG9yO1xuICAgIGdyYXBoaWNzQmF0Y2guYWxwaGEgPSBzdHlsZS5hbHBoYTtcbiAgICBncmFwaGljc0JhdGNoLnRleHR1cmUgPSB0ZXh0dXJlO1xuICAgIGdyYXBoaWNzQmF0Y2guZ2VvbWV0cnlEYXRhID0gZ2VvbWV0cnlEYXRhO1xuICAgIGdyYXBoaWNzQmF0Y2gudG9wb2xvZ3kgPSB0b3BvbG9neTtcbiAgICBiYXRjaGVzLnB1c2goZ3JhcGhpY3NCYXRjaCk7XG4gIH0pO1xufVxuZnVuY3Rpb24gZ2V0SG9sZUFycmF5cyhob2xlUHJpbWl0aXZlcykge1xuICBjb25zdCBob2xlQXJyYXlzID0gW107XG4gIGZvciAobGV0IGsgPSAwOyBrIDwgaG9sZVByaW1pdGl2ZXMubGVuZ3RoOyBrKyspIHtcbiAgICBjb25zdCBob2xlUHJpbWl0aXZlID0gaG9sZVByaW1pdGl2ZXNba10uc2hhcGU7XG4gICAgY29uc3QgaG9sZVBvaW50cyA9IFtdO1xuICAgIGNvbnN0IGhvbGVCdWlsZGVyID0gc2hhcGVCdWlsZGVyc1tob2xlUHJpbWl0aXZlLnR5cGVdO1xuICAgIGlmIChob2xlQnVpbGRlci5idWlsZChob2xlUHJpbWl0aXZlLCBob2xlUG9pbnRzKSkge1xuICAgICAgaG9sZUFycmF5cy5wdXNoKGhvbGVQb2ludHMpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gaG9sZUFycmF5cztcbn1cblxuZXhwb3J0IHsgYnVpbGRDb250ZXh0QmF0Y2hlcywgc2hhcGVCdWlsZGVycyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVpbGRDb250ZXh0QmF0Y2hlcy5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBnZXRUZXh0dXJlQmF0Y2hCaW5kR3JvdXAgfSBmcm9tICcuLi8uLi8uLi9yZW5kZXJpbmcvYmF0Y2hlci9ncHUvZ2V0VGV4dHVyZUJhdGNoQmluZEdyb3VwLm1qcyc7XG5pbXBvcnQgeyBEZWZhdWx0QmF0Y2hlciB9IGZyb20gJy4uLy4uLy4uL3JlbmRlcmluZy9iYXRjaGVyL3NoYXJlZC9EZWZhdWx0QmF0Y2hlci5tanMnO1xuaW1wb3J0IHsgSW5zdHJ1Y3Rpb25TZXQgfSBmcm9tICcuLi8uLi8uLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9pbnN0cnVjdGlvbnMvSW5zdHJ1Y3Rpb25TZXQubWpzJztcbmltcG9ydCB7IEdDTWFuYWdlZEhhc2ggfSBmcm9tICcuLi8uLi8uLi91dGlscy9kYXRhL0dDTWFuYWdlZEhhc2gubWpzJztcbmltcG9ydCB7IGRlcHJlY2F0aW9uLCB2OF8zXzQgfSBmcm9tICcuLi8uLi8uLi91dGlscy9sb2dnaW5nL2RlcHJlY2F0aW9uLm1qcyc7XG5pbXBvcnQgeyBCaWdQb29sIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvcG9vbC9Qb29sR3JvdXAubWpzJztcbmltcG9ydCB7IGJ1aWxkQ29udGV4dEJhdGNoZXMgfSBmcm9tICcuL3V0aWxzL2J1aWxkQ29udGV4dEJhdGNoZXMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBHcHVHcmFwaGljc0NvbnRleHQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmJhdGNoZXMgPSBbXTtcbiAgICB0aGlzLmdlb21ldHJ5RGF0YSA9IHtcbiAgICAgIHZlcnRpY2VzOiBbXSxcbiAgICAgIHV2czogW10sXG4gICAgICBpbmRpY2VzOiBbXVxuICAgIH07XG4gIH1cbiAgcmVzZXQoKSB7XG4gICAgaWYgKHRoaXMuYmF0Y2hlcykge1xuICAgICAgdGhpcy5iYXRjaGVzLmZvckVhY2goKGJhdGNoKSA9PiB7XG4gICAgICAgIEJpZ1Bvb2wucmV0dXJuKGJhdGNoKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAodGhpcy5ncmFwaGljc0RhdGEpIHtcbiAgICAgIEJpZ1Bvb2wucmV0dXJuKHRoaXMuZ3JhcGhpY3NEYXRhKTtcbiAgICB9XG4gICAgdGhpcy5pc0JhdGNoYWJsZSA9IGZhbHNlO1xuICAgIHRoaXMuY29udGV4dCA9IG51bGw7XG4gICAgdGhpcy5iYXRjaGVzLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5nZW9tZXRyeURhdGEuaW5kaWNlcy5sZW5ndGggPSAwO1xuICAgIHRoaXMuZ2VvbWV0cnlEYXRhLnZlcnRpY2VzLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5nZW9tZXRyeURhdGEudXZzLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5ncmFwaGljc0RhdGEgPSBudWxsO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5yZXNldCgpO1xuICAgIHRoaXMuYmF0Y2hlcyA9IG51bGw7XG4gICAgdGhpcy5nZW9tZXRyeURhdGEgPSBudWxsO1xuICB9XG59XG5jbGFzcyBHcmFwaGljc0NvbnRleHRSZW5kZXJEYXRhIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMgPSBuZXcgSW5zdHJ1Y3Rpb25TZXQoKTtcbiAgfVxuICBpbml0KG9wdGlvbnMpIHtcbiAgICBjb25zdCBtYXhUZXh0dXJlcyA9IG9wdGlvbnMubWF4VGV4dHVyZXM7XG4gICAgdGhpcy5iYXRjaGVyID8gdGhpcy5iYXRjaGVyLl91cGRhdGVNYXhUZXh0dXJlcyhtYXhUZXh0dXJlcykgOiB0aGlzLmJhdGNoZXIgPSBuZXcgRGVmYXVsdEJhdGNoZXIoeyBtYXhUZXh0dXJlcyB9KTtcbiAgICB0aGlzLmluc3RydWN0aW9ucy5yZXNldCgpO1xuICB9XG4gIC8qKlxuICAgKiBAZGVwcmVjYXRlZCBzaW5jZSB2ZXJzaW9uIDguMC4wXG4gICAqIFVzZSBgYmF0Y2hlci5nZW9tZXRyeWAgaW5zdGVhZC5cbiAgICogQHNlZSB7QmF0Y2hlciNnZW9tZXRyeX1cbiAgICovXG4gIGdldCBnZW9tZXRyeSgpIHtcbiAgICBkZXByZWNhdGlvbih2OF8zXzQsIFwiR3JhcGhpY3NDb250ZXh0UmVuZGVyRGF0YSNnZW9tZXRyeSBpcyBkZXByZWNhdGVkLCBwbGVhc2UgdXNlIGJhdGNoZXIuZ2VvbWV0cnkgaW5zdGVhZC5cIik7XG4gICAgcmV0dXJuIHRoaXMuYmF0Y2hlci5nZW9tZXRyeTtcbiAgfVxuICBkZXN0cm95KCkge1xuICAgIHRoaXMuYmF0Y2hlci5kZXN0cm95KCk7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMuZGVzdHJveSgpO1xuICAgIHRoaXMuYmF0Y2hlciA9IG51bGw7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMgPSBudWxsO1xuICB9XG59XG5jb25zdCBfR3JhcGhpY3NDb250ZXh0U3lzdGVtID0gY2xhc3MgX0dyYXBoaWNzQ29udGV4dFN5c3RlbSB7XG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgICB0aGlzLl9tYW5hZ2VkQ29udGV4dHMgPSBuZXcgR0NNYW5hZ2VkSGFzaCh7IHJlbmRlcmVyLCB0eXBlOiBcInJlc291cmNlXCIsIG5hbWU6IFwiZ3JhcGhpY3NDb250ZXh0XCIgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFJ1bm5lciBpbml0IGNhbGxlZCwgdXBkYXRlIHRoZSBkZWZhdWx0IG9wdGlvbnNcbiAgICogQGlnbm9yZVxuICAgKi9cbiAgaW5pdChvcHRpb25zKSB7XG4gICAgX0dyYXBoaWNzQ29udGV4dFN5c3RlbS5kZWZhdWx0T3B0aW9ucy5iZXppZXJTbW9vdGhuZXNzID0gb3B0aW9ucz8uYmV6aWVyU21vb3RobmVzcyA/PyBfR3JhcGhpY3NDb250ZXh0U3lzdGVtLmRlZmF1bHRPcHRpb25zLmJlemllclNtb290aG5lc3M7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHJlbmRlciBkYXRhIGZvciBhIGdpdmVuIEdyYXBoaWNzQ29udGV4dC5cbiAgICogQHBhcmFtIGNvbnRleHQgLSBUaGUgR3JhcGhpY3NDb250ZXh0IHRvIGdldCB0aGUgcmVuZGVyIGRhdGEgZm9yLlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGdldENvbnRleHRSZW5kZXJEYXRhKGNvbnRleHQpIHtcbiAgICByZXR1cm4gY29udGV4dC5fZ3B1RGF0YVt0aGlzLl9yZW5kZXJlci51aWRdLmdyYXBoaWNzRGF0YSB8fCB0aGlzLl9pbml0Q29udGV4dFJlbmRlckRhdGEoY29udGV4dCk7XG4gIH1cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIEdQVSBjb250ZXh0IGZvciBhIGdpdmVuIEdyYXBoaWNzQ29udGV4dC5cbiAgICogSWYgdGhlIGNvbnRleHQgaXMgZGlydHksIGl0IHdpbGwgcmVidWlsZCB0aGUgYmF0Y2hlcyBhbmQgZ2VvbWV0cnkgZGF0YS5cbiAgICogQHBhcmFtIGNvbnRleHQgLSBUaGUgR3JhcGhpY3NDb250ZXh0IHRvIHVwZGF0ZS5cbiAgICogQHJldHVybnMgVGhlIHVwZGF0ZWQgR3B1R3JhcGhpY3NDb250ZXh0LlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIHVwZGF0ZUdwdUNvbnRleHQoY29udGV4dCkge1xuICAgIGNvbnN0IGhhc0NvbnRleHQgPSAhIWNvbnRleHQuX2dwdURhdGFbdGhpcy5fcmVuZGVyZXIudWlkXTtcbiAgICBjb25zdCBncHVDb250ZXh0ID0gY29udGV4dC5fZ3B1RGF0YVt0aGlzLl9yZW5kZXJlci51aWRdIHx8IHRoaXMuX2luaXRDb250ZXh0KGNvbnRleHQpO1xuICAgIGlmIChjb250ZXh0LmRpcnR5IHx8ICFoYXNDb250ZXh0KSB7XG4gICAgICBpZiAoaGFzQ29udGV4dCkge1xuICAgICAgICBncHVDb250ZXh0LnJlc2V0KCk7XG4gICAgICB9XG4gICAgICBidWlsZENvbnRleHRCYXRjaGVzKGNvbnRleHQsIGdwdUNvbnRleHQpO1xuICAgICAgY29uc3QgYmF0Y2hNb2RlID0gY29udGV4dC5iYXRjaE1vZGU7XG4gICAgICBpZiAoY29udGV4dC5jdXN0b21TaGFkZXIgfHwgYmF0Y2hNb2RlID09PSBcIm5vLWJhdGNoXCIpIHtcbiAgICAgICAgZ3B1Q29udGV4dC5pc0JhdGNoYWJsZSA9IGZhbHNlO1xuICAgICAgfSBlbHNlIGlmIChiYXRjaE1vZGUgPT09IFwiYXV0b1wiKSB7XG4gICAgICAgIGdwdUNvbnRleHQuaXNCYXRjaGFibGUgPSBncHVDb250ZXh0Lmdlb21ldHJ5RGF0YS52ZXJ0aWNlcy5sZW5ndGggPCA0MDA7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBncHVDb250ZXh0LmlzQmF0Y2hhYmxlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGNvbnRleHQuZGlydHkgPSBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIGdwdUNvbnRleHQ7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIEdwdUdyYXBoaWNzQ29udGV4dCBmb3IgYSBnaXZlbiBHcmFwaGljc0NvbnRleHQuXG4gICAqIElmIGl0IGRvZXMgbm90IGV4aXN0LCBpdCB3aWxsIGluaXRpYWxpemUgYSBuZXcgb25lLlxuICAgKiBAcGFyYW0gY29udGV4dCAtIFRoZSBHcmFwaGljc0NvbnRleHQgdG8gZ2V0IHRoZSBHcHVHcmFwaGljc0NvbnRleHQgZm9yLlxuICAgKiBAcmV0dXJucyBUaGUgR3B1R3JhcGhpY3NDb250ZXh0IGZvciB0aGUgZ2l2ZW4gR3JhcGhpY3NDb250ZXh0LlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGdldEdwdUNvbnRleHQoY29udGV4dCkge1xuICAgIHJldHVybiBjb250ZXh0Ll9ncHVEYXRhW3RoaXMuX3JlbmRlcmVyLnVpZF0gfHwgdGhpcy5faW5pdENvbnRleHQoY29udGV4dCk7XG4gIH1cbiAgX2luaXRDb250ZXh0UmVuZGVyRGF0YShjb250ZXh0KSB7XG4gICAgY29uc3QgZ3JhcGhpY3NEYXRhID0gQmlnUG9vbC5nZXQoR3JhcGhpY3NDb250ZXh0UmVuZGVyRGF0YSwge1xuICAgICAgbWF4VGV4dHVyZXM6IHRoaXMuX3JlbmRlcmVyLmxpbWl0cy5tYXhCYXRjaGFibGVUZXh0dXJlc1xuICAgIH0pO1xuICAgIGNvbnN0IGdwdUNvbnRleHQgPSBjb250ZXh0Ll9ncHVEYXRhW3RoaXMuX3JlbmRlcmVyLnVpZF07XG4gICAgY29uc3QgeyBiYXRjaGVzLCBnZW9tZXRyeURhdGEgfSA9IGdwdUNvbnRleHQ7XG4gICAgZ3B1Q29udGV4dC5ncmFwaGljc0RhdGEgPSBncmFwaGljc0RhdGE7XG4gICAgY29uc3QgdmVydGV4U2l6ZSA9IGdlb21ldHJ5RGF0YS52ZXJ0aWNlcy5sZW5ndGg7XG4gICAgY29uc3QgaW5kZXhTaXplID0gZ2VvbWV0cnlEYXRhLmluZGljZXMubGVuZ3RoO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYmF0Y2hlcy5sZW5ndGg7IGkrKykge1xuICAgICAgYmF0Y2hlc1tpXS5hcHBseVRyYW5zZm9ybSA9IGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBiYXRjaGVyID0gZ3JhcGhpY3NEYXRhLmJhdGNoZXI7XG4gICAgYmF0Y2hlci5lbnN1cmVBdHRyaWJ1dGVCdWZmZXIodmVydGV4U2l6ZSk7XG4gICAgYmF0Y2hlci5lbnN1cmVJbmRleEJ1ZmZlcihpbmRleFNpemUpO1xuICAgIGJhdGNoZXIuYmVnaW4oKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJhdGNoZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGJhdGNoID0gYmF0Y2hlc1tpXTtcbiAgICAgIGJhdGNoZXIuYWRkKGJhdGNoKTtcbiAgICB9XG4gICAgYmF0Y2hlci5maW5pc2goZ3JhcGhpY3NEYXRhLmluc3RydWN0aW9ucyk7XG4gICAgY29uc3QgZ2VvbWV0cnkgPSBiYXRjaGVyLmdlb21ldHJ5O1xuICAgIGdlb21ldHJ5LmluZGV4QnVmZmVyLnNldERhdGFXaXRoU2l6ZShiYXRjaGVyLmluZGV4QnVmZmVyLCBiYXRjaGVyLmluZGV4U2l6ZSwgdHJ1ZSk7XG4gICAgZ2VvbWV0cnkuYnVmZmVyc1swXS5zZXREYXRhV2l0aFNpemUoYmF0Y2hlci5hdHRyaWJ1dGVCdWZmZXIuZmxvYXQzMlZpZXcsIGJhdGNoZXIuYXR0cmlidXRlU2l6ZSwgdHJ1ZSk7XG4gICAgY29uc3QgZHJhd0JhdGNoZXMgPSBiYXRjaGVyLmJhdGNoZXM7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBiYXRjaGVyLmJhdGNoSW5kZXg7IGkrKykge1xuICAgICAgY29uc3QgYmF0Y2ggPSBkcmF3QmF0Y2hlc1tpXTtcbiAgICAgIGJhdGNoLmJpbmRHcm91cCA9IGdldFRleHR1cmVCYXRjaEJpbmRHcm91cChcbiAgICAgICAgYmF0Y2gudGV4dHVyZXMudGV4dHVyZXMsXG4gICAgICAgIGJhdGNoLnRleHR1cmVzLmNvdW50LFxuICAgICAgICB0aGlzLl9yZW5kZXJlci5saW1pdHMubWF4QmF0Y2hhYmxlVGV4dHVyZXNcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBncmFwaGljc0RhdGE7XG4gIH1cbiAgX2luaXRDb250ZXh0KGNvbnRleHQpIHtcbiAgICBjb25zdCBncHVDb250ZXh0ID0gbmV3IEdwdUdyYXBoaWNzQ29udGV4dCgpO1xuICAgIGdwdUNvbnRleHQuY29udGV4dCA9IGNvbnRleHQ7XG4gICAgY29udGV4dC5fZ3B1RGF0YVt0aGlzLl9yZW5kZXJlci51aWRdID0gZ3B1Q29udGV4dDtcbiAgICB0aGlzLl9tYW5hZ2VkQ29udGV4dHMuYWRkKGNvbnRleHQpO1xuICAgIHJldHVybiBncHVDb250ZXh0O1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fbWFuYWdlZENvbnRleHRzLmRlc3Ryb3koKTtcbiAgICB0aGlzLl9yZW5kZXJlciA9IG51bGw7XG4gIH1cbn07XG4vKiogQGlnbm9yZSAqL1xuX0dyYXBoaWNzQ29udGV4dFN5c3RlbS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVU3lzdGVtXG4gIF0sXG4gIG5hbWU6IFwiZ3JhcGhpY3NDb250ZXh0XCJcbn07XG4vKiogVGhlIGRlZmF1bHQgb3B0aW9ucyBmb3IgdGhlIEdyYXBoaWNzQ29udGV4dFN5c3RlbS4gKi9cbl9HcmFwaGljc0NvbnRleHRTeXN0ZW0uZGVmYXVsdE9wdGlvbnMgPSB7XG4gIC8qKlxuICAgKiBBIHZhbHVlIGZyb20gMCB0byAxIHRoYXQgY29udHJvbHMgdGhlIHNtb290aG5lc3Mgb2YgYmV6aWVyIGN1cnZlcyAodGhlIGhpZ2hlciB0aGUgc21vb3RoZXIpXG4gICAqIEBkZWZhdWx0IDAuNVxuICAgKi9cbiAgYmV6aWVyU21vb3RobmVzczogMC41XG59O1xubGV0IEdyYXBoaWNzQ29udGV4dFN5c3RlbSA9IF9HcmFwaGljc0NvbnRleHRTeXN0ZW07XG5cbmV4cG9ydCB7IEdwdUdyYXBoaWNzQ29udGV4dCwgR3JhcGhpY3NDb250ZXh0UmVuZGVyRGF0YSwgR3JhcGhpY3NDb250ZXh0U3lzdGVtIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1HcmFwaGljc0NvbnRleHRTeXN0ZW0ubWpzLm1hcFxuIiwiaW1wb3J0IHsgR3JhcGhpY3NDb250ZXh0U3lzdGVtIH0gZnJvbSAnLi4vR3JhcGhpY3NDb250ZXh0U3lzdGVtLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgUkVDVVJTSU9OX0xJTUlUID0gODtcbmNvbnN0IEZMVF9FUFNJTE9OID0gMTE5MjA5MjllLTE0O1xuY29uc3QgUEFUSF9ESVNUQU5DRV9FUFNJTE9OID0gMTtcbmNvbnN0IGN1cnZlQW5nbGVUb2xlcmFuY2VFcHNpbG9uID0gMC4wMTtcbmNvbnN0IG1BbmdsZVRvbGVyYW5jZSA9IDA7XG5jb25zdCBtQ3VzcExpbWl0ID0gMDtcbmZ1bmN0aW9uIGJ1aWxkQWRhcHRpdmVCZXppZXIocG9pbnRzLCBzWCwgc1ksIGNwMXgsIGNwMXksIGNwMngsIGNwMnksIGVYLCBlWSwgc21vb3RobmVzcykge1xuICBjb25zdCBzY2FsZSA9IDE7XG4gIGNvbnN0IHNtb290aGluZyA9IE1hdGgubWluKFxuICAgIDAuOTksXG4gICAgLy8gYSB2YWx1ZSBvZiAxLjAgYWN0dWFsbHkgaW52ZXJ0cyBzbW9vdGhpbmcsIHNvIHdlIGNhcCBpdCBhdCAwLjk5XG4gICAgTWF0aC5tYXgoMCwgc21vb3RobmVzcyA/PyBHcmFwaGljc0NvbnRleHRTeXN0ZW0uZGVmYXVsdE9wdGlvbnMuYmV6aWVyU21vb3RobmVzcylcbiAgKTtcbiAgbGV0IGRpc3RhbmNlVG9sZXJhbmNlID0gKFBBVEhfRElTVEFOQ0VfRVBTSUxPTiAtIHNtb290aGluZykgLyBzY2FsZTtcbiAgZGlzdGFuY2VUb2xlcmFuY2UgKj0gZGlzdGFuY2VUb2xlcmFuY2U7XG4gIGJlZ2luKHNYLCBzWSwgY3AxeCwgY3AxeSwgY3AyeCwgY3AyeSwgZVgsIGVZLCBwb2ludHMsIGRpc3RhbmNlVG9sZXJhbmNlKTtcbiAgcmV0dXJuIHBvaW50cztcbn1cbmZ1bmN0aW9uIGJlZ2luKHNYLCBzWSwgY3AxeCwgY3AxeSwgY3AyeCwgY3AyeSwgZVgsIGVZLCBwb2ludHMsIGRpc3RhbmNlVG9sZXJhbmNlKSB7XG4gIHJlY3Vyc2l2ZShzWCwgc1ksIGNwMXgsIGNwMXksIGNwMngsIGNwMnksIGVYLCBlWSwgcG9pbnRzLCBkaXN0YW5jZVRvbGVyYW5jZSwgMCk7XG4gIHBvaW50cy5wdXNoKGVYLCBlWSk7XG59XG5mdW5jdGlvbiByZWN1cnNpdmUoeDEsIHkxLCB4MiwgeTIsIHgzLCB5MywgeDQsIHk0LCBwb2ludHMsIGRpc3RhbmNlVG9sZXJhbmNlLCBsZXZlbCkge1xuICBpZiAobGV2ZWwgPiBSRUNVUlNJT05fTElNSVQpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcGkgPSBNYXRoLlBJO1xuICBjb25zdCB4MTIgPSAoeDEgKyB4MikgLyAyO1xuICBjb25zdCB5MTIgPSAoeTEgKyB5MikgLyAyO1xuICBjb25zdCB4MjMgPSAoeDIgKyB4MykgLyAyO1xuICBjb25zdCB5MjMgPSAoeTIgKyB5MykgLyAyO1xuICBjb25zdCB4MzQgPSAoeDMgKyB4NCkgLyAyO1xuICBjb25zdCB5MzQgPSAoeTMgKyB5NCkgLyAyO1xuICBjb25zdCB4MTIzID0gKHgxMiArIHgyMykgLyAyO1xuICBjb25zdCB5MTIzID0gKHkxMiArIHkyMykgLyAyO1xuICBjb25zdCB4MjM0ID0gKHgyMyArIHgzNCkgLyAyO1xuICBjb25zdCB5MjM0ID0gKHkyMyArIHkzNCkgLyAyO1xuICBjb25zdCB4MTIzNCA9ICh4MTIzICsgeDIzNCkgLyAyO1xuICBjb25zdCB5MTIzNCA9ICh5MTIzICsgeTIzNCkgLyAyO1xuICBpZiAobGV2ZWwgPiAwKSB7XG4gICAgbGV0IGR4ID0geDQgLSB4MTtcbiAgICBsZXQgZHkgPSB5NCAtIHkxO1xuICAgIGNvbnN0IGQyID0gTWF0aC5hYnMoKHgyIC0geDQpICogZHkgLSAoeTIgLSB5NCkgKiBkeCk7XG4gICAgY29uc3QgZDMgPSBNYXRoLmFicygoeDMgLSB4NCkgKiBkeSAtICh5MyAtIHk0KSAqIGR4KTtcbiAgICBsZXQgZGExO1xuICAgIGxldCBkYTI7XG4gICAgaWYgKGQyID4gRkxUX0VQU0lMT04gJiYgZDMgPiBGTFRfRVBTSUxPTikge1xuICAgICAgaWYgKChkMiArIGQzKSAqIChkMiArIGQzKSA8PSBkaXN0YW5jZVRvbGVyYW5jZSAqIChkeCAqIGR4ICsgZHkgKiBkeSkpIHtcbiAgICAgICAgaWYgKG1BbmdsZVRvbGVyYW5jZSA8IGN1cnZlQW5nbGVUb2xlcmFuY2VFcHNpbG9uKSB7XG4gICAgICAgICAgcG9pbnRzLnB1c2goeDEyMzQsIHkxMjM0KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYTIzID0gTWF0aC5hdGFuMih5MyAtIHkyLCB4MyAtIHgyKTtcbiAgICAgICAgZGExID0gTWF0aC5hYnMoYTIzIC0gTWF0aC5hdGFuMih5MiAtIHkxLCB4MiAtIHgxKSk7XG4gICAgICAgIGRhMiA9IE1hdGguYWJzKE1hdGguYXRhbjIoeTQgLSB5MywgeDQgLSB4MykgLSBhMjMpO1xuICAgICAgICBpZiAoZGExID49IHBpKSBkYTEgPSAyICogcGkgLSBkYTE7XG4gICAgICAgIGlmIChkYTIgPj0gcGkpIGRhMiA9IDIgKiBwaSAtIGRhMjtcbiAgICAgICAgaWYgKGRhMSArIGRhMiA8IG1BbmdsZVRvbGVyYW5jZSkge1xuICAgICAgICAgIHBvaW50cy5wdXNoKHgxMjM0LCB5MTIzNCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtQ3VzcExpbWl0ICE9PSAwKSB7XG4gICAgICAgICAgaWYgKGRhMSA+IG1DdXNwTGltaXQpIHtcbiAgICAgICAgICAgIHBvaW50cy5wdXNoKHgyLCB5Mik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChkYTIgPiBtQ3VzcExpbWl0KSB7XG4gICAgICAgICAgICBwb2ludHMucHVzaCh4MywgeTMpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoZDIgPiBGTFRfRVBTSUxPTikge1xuICAgICAgaWYgKGQyICogZDIgPD0gZGlzdGFuY2VUb2xlcmFuY2UgKiAoZHggKiBkeCArIGR5ICogZHkpKSB7XG4gICAgICAgIGlmIChtQW5nbGVUb2xlcmFuY2UgPCBjdXJ2ZUFuZ2xlVG9sZXJhbmNlRXBzaWxvbikge1xuICAgICAgICAgIHBvaW50cy5wdXNoKHgxMjM0LCB5MTIzNCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGRhMSA9IE1hdGguYWJzKE1hdGguYXRhbjIoeTMgLSB5MiwgeDMgLSB4MikgLSBNYXRoLmF0YW4yKHkyIC0geTEsIHgyIC0geDEpKTtcbiAgICAgICAgaWYgKGRhMSA+PSBwaSkgZGExID0gMiAqIHBpIC0gZGExO1xuICAgICAgICBpZiAoZGExIDwgbUFuZ2xlVG9sZXJhbmNlKSB7XG4gICAgICAgICAgcG9pbnRzLnB1c2goeDIsIHkyKTtcbiAgICAgICAgICBwb2ludHMucHVzaCh4MywgeTMpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobUN1c3BMaW1pdCAhPT0gMCkge1xuICAgICAgICAgIGlmIChkYTEgPiBtQ3VzcExpbWl0KSB7XG4gICAgICAgICAgICBwb2ludHMucHVzaCh4MiwgeTIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoZDMgPiBGTFRfRVBTSUxPTikge1xuICAgICAgaWYgKGQzICogZDMgPD0gZGlzdGFuY2VUb2xlcmFuY2UgKiAoZHggKiBkeCArIGR5ICogZHkpKSB7XG4gICAgICAgIGlmIChtQW5nbGVUb2xlcmFuY2UgPCBjdXJ2ZUFuZ2xlVG9sZXJhbmNlRXBzaWxvbikge1xuICAgICAgICAgIHBvaW50cy5wdXNoKHgxMjM0LCB5MTIzNCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGRhMSA9IE1hdGguYWJzKE1hdGguYXRhbjIoeTQgLSB5MywgeDQgLSB4MykgLSBNYXRoLmF0YW4yKHkzIC0geTIsIHgzIC0geDIpKTtcbiAgICAgICAgaWYgKGRhMSA+PSBwaSkgZGExID0gMiAqIHBpIC0gZGExO1xuICAgICAgICBpZiAoZGExIDwgbUFuZ2xlVG9sZXJhbmNlKSB7XG4gICAgICAgICAgcG9pbnRzLnB1c2goeDIsIHkyKTtcbiAgICAgICAgICBwb2ludHMucHVzaCh4MywgeTMpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobUN1c3BMaW1pdCAhPT0gMCkge1xuICAgICAgICAgIGlmIChkYTEgPiBtQ3VzcExpbWl0KSB7XG4gICAgICAgICAgICBwb2ludHMucHVzaCh4MywgeTMpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBkeCA9IHgxMjM0IC0gKHgxICsgeDQpIC8gMjtcbiAgICAgIGR5ID0geTEyMzQgLSAoeTEgKyB5NCkgLyAyO1xuICAgICAgaWYgKGR4ICogZHggKyBkeSAqIGR5IDw9IGRpc3RhbmNlVG9sZXJhbmNlKSB7XG4gICAgICAgIHBvaW50cy5wdXNoKHgxMjM0LCB5MTIzNCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmVjdXJzaXZlKHgxLCB5MSwgeDEyLCB5MTIsIHgxMjMsIHkxMjMsIHgxMjM0LCB5MTIzNCwgcG9pbnRzLCBkaXN0YW5jZVRvbGVyYW5jZSwgbGV2ZWwgKyAxKTtcbiAgcmVjdXJzaXZlKHgxMjM0LCB5MTIzNCwgeDIzNCwgeTIzNCwgeDM0LCB5MzQsIHg0LCB5NCwgcG9pbnRzLCBkaXN0YW5jZVRvbGVyYW5jZSwgbGV2ZWwgKyAxKTtcbn1cblxuZXhwb3J0IHsgYnVpbGRBZGFwdGl2ZUJlemllciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVpbGRBZGFwdGl2ZUJlemllci5tanMubWFwXG4iLCJpbXBvcnQgeyBHcmFwaGljc0NvbnRleHRTeXN0ZW0gfSBmcm9tICcuLi9HcmFwaGljc0NvbnRleHRTeXN0ZW0ubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBSRUNVUlNJT05fTElNSVQgPSA4O1xuY29uc3QgRkxUX0VQU0lMT04gPSAxMTkyMDkyOWUtMTQ7XG5jb25zdCBQQVRIX0RJU1RBTkNFX0VQU0lMT04gPSAxO1xuY29uc3QgY3VydmVBbmdsZVRvbGVyYW5jZUVwc2lsb24gPSAwLjAxO1xuY29uc3QgbUFuZ2xlVG9sZXJhbmNlID0gMDtcbmZ1bmN0aW9uIGJ1aWxkQWRhcHRpdmVRdWFkcmF0aWMocG9pbnRzLCBzWCwgc1ksIGNwMXgsIGNwMXksIGVYLCBlWSwgc21vb3RobmVzcykge1xuICBjb25zdCBzY2FsZSA9IDE7XG4gIGNvbnN0IHNtb290aGluZyA9IE1hdGgubWluKFxuICAgIDAuOTksXG4gICAgLy8gYSB2YWx1ZSBvZiAxLjAgYWN0dWFsbHkgaW52ZXJ0cyBzbW9vdGhpbmcsIHNvIHdlIGNhcCBpdCBhdCAwLjk5XG4gICAgTWF0aC5tYXgoMCwgc21vb3RobmVzcyA/PyBHcmFwaGljc0NvbnRleHRTeXN0ZW0uZGVmYXVsdE9wdGlvbnMuYmV6aWVyU21vb3RobmVzcylcbiAgKTtcbiAgbGV0IGRpc3RhbmNlVG9sZXJhbmNlID0gKFBBVEhfRElTVEFOQ0VfRVBTSUxPTiAtIHNtb290aGluZykgLyBzY2FsZTtcbiAgZGlzdGFuY2VUb2xlcmFuY2UgKj0gZGlzdGFuY2VUb2xlcmFuY2U7XG4gIGJlZ2luKHNYLCBzWSwgY3AxeCwgY3AxeSwgZVgsIGVZLCBwb2ludHMsIGRpc3RhbmNlVG9sZXJhbmNlKTtcbiAgcmV0dXJuIHBvaW50cztcbn1cbmZ1bmN0aW9uIGJlZ2luKHNYLCBzWSwgY3AxeCwgY3AxeSwgZVgsIGVZLCBwb2ludHMsIGRpc3RhbmNlVG9sZXJhbmNlKSB7XG4gIHJlY3Vyc2l2ZShwb2ludHMsIHNYLCBzWSwgY3AxeCwgY3AxeSwgZVgsIGVZLCBkaXN0YW5jZVRvbGVyYW5jZSwgMCk7XG4gIHBvaW50cy5wdXNoKGVYLCBlWSk7XG59XG5mdW5jdGlvbiByZWN1cnNpdmUocG9pbnRzLCB4MSwgeTEsIHgyLCB5MiwgeDMsIHkzLCBkaXN0YW5jZVRvbGVyYW5jZSwgbGV2ZWwpIHtcbiAgaWYgKGxldmVsID4gUkVDVVJTSU9OX0xJTUlUKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHBpID0gTWF0aC5QSTtcbiAgY29uc3QgeDEyID0gKHgxICsgeDIpIC8gMjtcbiAgY29uc3QgeTEyID0gKHkxICsgeTIpIC8gMjtcbiAgY29uc3QgeDIzID0gKHgyICsgeDMpIC8gMjtcbiAgY29uc3QgeTIzID0gKHkyICsgeTMpIC8gMjtcbiAgY29uc3QgeDEyMyA9ICh4MTIgKyB4MjMpIC8gMjtcbiAgY29uc3QgeTEyMyA9ICh5MTIgKyB5MjMpIC8gMjtcbiAgbGV0IGR4ID0geDMgLSB4MTtcbiAgbGV0IGR5ID0geTMgLSB5MTtcbiAgY29uc3QgZCA9IE1hdGguYWJzKCh4MiAtIHgzKSAqIGR5IC0gKHkyIC0geTMpICogZHgpO1xuICBpZiAoZCA+IEZMVF9FUFNJTE9OKSB7XG4gICAgaWYgKGQgKiBkIDw9IGRpc3RhbmNlVG9sZXJhbmNlICogKGR4ICogZHggKyBkeSAqIGR5KSkge1xuICAgICAgaWYgKG1BbmdsZVRvbGVyYW5jZSA8IGN1cnZlQW5nbGVUb2xlcmFuY2VFcHNpbG9uKSB7XG4gICAgICAgIHBvaW50cy5wdXNoKHgxMjMsIHkxMjMpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBsZXQgZGEgPSBNYXRoLmFicyhNYXRoLmF0YW4yKHkzIC0geTIsIHgzIC0geDIpIC0gTWF0aC5hdGFuMih5MiAtIHkxLCB4MiAtIHgxKSk7XG4gICAgICBpZiAoZGEgPj0gcGkpIGRhID0gMiAqIHBpIC0gZGE7XG4gICAgICBpZiAoZGEgPCBtQW5nbGVUb2xlcmFuY2UpIHtcbiAgICAgICAgcG9pbnRzLnB1c2goeDEyMywgeTEyMyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZHggPSB4MTIzIC0gKHgxICsgeDMpIC8gMjtcbiAgICBkeSA9IHkxMjMgLSAoeTEgKyB5MykgLyAyO1xuICAgIGlmIChkeCAqIGR4ICsgZHkgKiBkeSA8PSBkaXN0YW5jZVRvbGVyYW5jZSkge1xuICAgICAgcG9pbnRzLnB1c2goeDEyMywgeTEyMyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICB9XG4gIHJlY3Vyc2l2ZShwb2ludHMsIHgxLCB5MSwgeDEyLCB5MTIsIHgxMjMsIHkxMjMsIGRpc3RhbmNlVG9sZXJhbmNlLCBsZXZlbCArIDEpO1xuICByZWN1cnNpdmUocG9pbnRzLCB4MTIzLCB5MTIzLCB4MjMsIHkyMywgeDMsIHkzLCBkaXN0YW5jZVRvbGVyYW5jZSwgbGV2ZWwgKyAxKTtcbn1cblxuZXhwb3J0IHsgYnVpbGRBZGFwdGl2ZVF1YWRyYXRpYyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVpbGRBZGFwdGl2ZVF1YWRyYXRpYy5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGJ1aWxkQXJjKHBvaW50cywgeCwgeSwgcmFkaXVzLCBzdGFydCwgZW5kLCBjbG9ja3dpc2UsIHN0ZXBzKSB7XG4gIGxldCBkaXN0ID0gTWF0aC5hYnMoc3RhcnQgLSBlbmQpO1xuICBpZiAoIWNsb2Nrd2lzZSAmJiBzdGFydCA+IGVuZCkge1xuICAgIGRpc3QgPSAyICogTWF0aC5QSSAtIGRpc3Q7XG4gIH0gZWxzZSBpZiAoY2xvY2t3aXNlICYmIGVuZCA+IHN0YXJ0KSB7XG4gICAgZGlzdCA9IDIgKiBNYXRoLlBJIC0gZGlzdDtcbiAgfVxuICBzdGVwcyB8fCAoc3RlcHMgPSBNYXRoLm1heCg2LCBNYXRoLmZsb29yKDYgKiBNYXRoLnBvdyhyYWRpdXMsIDEgLyAzKSAqIChkaXN0IC8gTWF0aC5QSSkpKSk7XG4gIHN0ZXBzID0gTWF0aC5tYXgoc3RlcHMsIDMpO1xuICBsZXQgZiA9IGRpc3QgLyBzdGVwcztcbiAgbGV0IHQgPSBzdGFydDtcbiAgZiAqPSBjbG9ja3dpc2UgPyAtMSA6IDE7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc3RlcHMgKyAxOyBpKyspIHtcbiAgICBjb25zdCBjcyA9IE1hdGguY29zKHQpO1xuICAgIGNvbnN0IHNuID0gTWF0aC5zaW4odCk7XG4gICAgY29uc3QgbnggPSB4ICsgY3MgKiByYWRpdXM7XG4gICAgY29uc3QgbnkgPSB5ICsgc24gKiByYWRpdXM7XG4gICAgcG9pbnRzLnB1c2gobngsIG55KTtcbiAgICB0ICs9IGY7XG4gIH1cbn1cblxuZXhwb3J0IHsgYnVpbGRBcmMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1aWxkQXJjLm1qcy5tYXBcbiIsImltcG9ydCB7IGJ1aWxkQXJjIH0gZnJvbSAnLi9idWlsZEFyYy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGJ1aWxkQXJjVG8ocG9pbnRzLCB4MSwgeTEsIHgyLCB5MiwgcmFkaXVzKSB7XG4gIGNvbnN0IGZyb21YID0gcG9pbnRzW3BvaW50cy5sZW5ndGggLSAyXTtcbiAgY29uc3QgZnJvbVkgPSBwb2ludHNbcG9pbnRzLmxlbmd0aCAtIDFdO1xuICBjb25zdCBhMSA9IGZyb21ZIC0geTE7XG4gIGNvbnN0IGIxID0gZnJvbVggLSB4MTtcbiAgY29uc3QgYTIgPSB5MiAtIHkxO1xuICBjb25zdCBiMiA9IHgyIC0geDE7XG4gIGNvbnN0IG1tID0gTWF0aC5hYnMoYTEgKiBiMiAtIGIxICogYTIpO1xuICBpZiAobW0gPCAxZS04IHx8IHJhZGl1cyA9PT0gMCkge1xuICAgIGlmIChwb2ludHNbcG9pbnRzLmxlbmd0aCAtIDJdICE9PSB4MSB8fCBwb2ludHNbcG9pbnRzLmxlbmd0aCAtIDFdICE9PSB5MSkge1xuICAgICAgcG9pbnRzLnB1c2goeDEsIHkxKTtcbiAgICB9XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGRkID0gYTEgKiBhMSArIGIxICogYjE7XG4gIGNvbnN0IGNjID0gYTIgKiBhMiArIGIyICogYjI7XG4gIGNvbnN0IHR0ID0gYTEgKiBhMiArIGIxICogYjI7XG4gIGNvbnN0IGsxID0gcmFkaXVzICogTWF0aC5zcXJ0KGRkKSAvIG1tO1xuICBjb25zdCBrMiA9IHJhZGl1cyAqIE1hdGguc3FydChjYykgLyBtbTtcbiAgY29uc3QgajEgPSBrMSAqIHR0IC8gZGQ7XG4gIGNvbnN0IGoyID0gazIgKiB0dCAvIGNjO1xuICBjb25zdCBjeCA9IGsxICogYjIgKyBrMiAqIGIxO1xuICBjb25zdCBjeSA9IGsxICogYTIgKyBrMiAqIGExO1xuICBjb25zdCBweCA9IGIxICogKGsyICsgajEpO1xuICBjb25zdCBweSA9IGExICogKGsyICsgajEpO1xuICBjb25zdCBxeCA9IGIyICogKGsxICsgajIpO1xuICBjb25zdCBxeSA9IGEyICogKGsxICsgajIpO1xuICBjb25zdCBzdGFydEFuZ2xlID0gTWF0aC5hdGFuMihweSAtIGN5LCBweCAtIGN4KTtcbiAgY29uc3QgZW5kQW5nbGUgPSBNYXRoLmF0YW4yKHF5IC0gY3ksIHF4IC0gY3gpO1xuICBidWlsZEFyYyhcbiAgICBwb2ludHMsXG4gICAgY3ggKyB4MSxcbiAgICBjeSArIHkxLFxuICAgIHJhZGl1cyxcbiAgICBzdGFydEFuZ2xlLFxuICAgIGVuZEFuZ2xlLFxuICAgIGIxICogYTIgPiBiMiAqIGExXG4gICk7XG59XG5cbmV4cG9ydCB7IGJ1aWxkQXJjVG8gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1aWxkQXJjVG8ubWpzLm1hcFxuIiwiaW1wb3J0IHsgYnVpbGRBZGFwdGl2ZUJlemllciB9IGZyb20gJy4vYnVpbGRBZGFwdGl2ZUJlemllci5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IFRBVSA9IE1hdGguUEkgKiAyO1xuY29uc3Qgb3V0ID0ge1xuICBjZW50ZXJYOiAwLFxuICBjZW50ZXJZOiAwLFxuICBhbmcxOiAwLFxuICBhbmcyOiAwXG59O1xuY29uc3QgbWFwVG9FbGxpcHNlID0gKHsgeCwgeSB9LCByeCwgcnksIGNvc1BoaSwgc2luUGhpLCBjZW50ZXJYLCBjZW50ZXJZLCBvdXQyKSA9PiB7XG4gIHggKj0gcng7XG4gIHkgKj0gcnk7XG4gIGNvbnN0IHhwID0gY29zUGhpICogeCAtIHNpblBoaSAqIHk7XG4gIGNvbnN0IHlwID0gc2luUGhpICogeCArIGNvc1BoaSAqIHk7XG4gIG91dDIueCA9IHhwICsgY2VudGVyWDtcbiAgb3V0Mi55ID0geXAgKyBjZW50ZXJZO1xuICByZXR1cm4gb3V0Mjtcbn07XG5mdW5jdGlvbiBhcHByb3hVbml0QXJjKGFuZzEsIGFuZzIpIHtcbiAgY29uc3QgYTEgPSBhbmcyID09PSAtMS41NzA3OTYzMjY3OTQ4OTY2ID8gLTAuNTUxOTE1MDI0NDk0IDogNCAvIDMgKiBNYXRoLnRhbihhbmcyIC8gNCk7XG4gIGNvbnN0IGEgPSBhbmcyID09PSAxLjU3MDc5NjMyNjc5NDg5NjYgPyAwLjU1MTkxNTAyNDQ5NCA6IGExO1xuICBjb25zdCB4MSA9IE1hdGguY29zKGFuZzEpO1xuICBjb25zdCB5MSA9IE1hdGguc2luKGFuZzEpO1xuICBjb25zdCB4MiA9IE1hdGguY29zKGFuZzEgKyBhbmcyKTtcbiAgY29uc3QgeTIgPSBNYXRoLnNpbihhbmcxICsgYW5nMik7XG4gIHJldHVybiBbXG4gICAge1xuICAgICAgeDogeDEgLSB5MSAqIGEsXG4gICAgICB5OiB5MSArIHgxICogYVxuICAgIH0sXG4gICAge1xuICAgICAgeDogeDIgKyB5MiAqIGEsXG4gICAgICB5OiB5MiAtIHgyICogYVxuICAgIH0sXG4gICAge1xuICAgICAgeDogeDIsXG4gICAgICB5OiB5MlxuICAgIH1cbiAgXTtcbn1cbmNvbnN0IHZlY3RvckFuZ2xlID0gKHV4LCB1eSwgdngsIHZ5KSA9PiB7XG4gIGNvbnN0IHNpZ24gPSB1eCAqIHZ5IC0gdXkgKiB2eCA8IDAgPyAtMSA6IDE7XG4gIGxldCBkb3QgPSB1eCAqIHZ4ICsgdXkgKiB2eTtcbiAgaWYgKGRvdCA+IDEpIHtcbiAgICBkb3QgPSAxO1xuICB9XG4gIGlmIChkb3QgPCAtMSkge1xuICAgIGRvdCA9IC0xO1xuICB9XG4gIHJldHVybiBzaWduICogTWF0aC5hY29zKGRvdCk7XG59O1xuY29uc3QgZ2V0QXJjQ2VudGVyID0gKHB4LCBweSwgY3gsIGN5LCByeCwgcnksIGxhcmdlQXJjRmxhZywgc3dlZXBGbGFnLCBzaW5QaGksIGNvc1BoaSwgcHhwLCBweXAsIG91dDIpID0+IHtcbiAgY29uc3QgcnhTcSA9IE1hdGgucG93KHJ4LCAyKTtcbiAgY29uc3QgcnlTcSA9IE1hdGgucG93KHJ5LCAyKTtcbiAgY29uc3QgcHhwU3EgPSBNYXRoLnBvdyhweHAsIDIpO1xuICBjb25zdCBweXBTcSA9IE1hdGgucG93KHB5cCwgMik7XG4gIGxldCByYWRpY2FudCA9IHJ4U3EgKiByeVNxIC0gcnhTcSAqIHB5cFNxIC0gcnlTcSAqIHB4cFNxO1xuICBpZiAocmFkaWNhbnQgPCAwKSB7XG4gICAgcmFkaWNhbnQgPSAwO1xuICB9XG4gIHJhZGljYW50IC89IHJ4U3EgKiBweXBTcSArIHJ5U3EgKiBweHBTcTtcbiAgcmFkaWNhbnQgPSBNYXRoLnNxcnQocmFkaWNhbnQpICogKGxhcmdlQXJjRmxhZyA9PT0gc3dlZXBGbGFnID8gLTEgOiAxKTtcbiAgY29uc3QgY2VudGVyWHAgPSByYWRpY2FudCAqIHJ4IC8gcnkgKiBweXA7XG4gIGNvbnN0IGNlbnRlcllwID0gcmFkaWNhbnQgKiAtcnkgLyByeCAqIHB4cDtcbiAgY29uc3QgY2VudGVyWCA9IGNvc1BoaSAqIGNlbnRlclhwIC0gc2luUGhpICogY2VudGVyWXAgKyAocHggKyBjeCkgLyAyO1xuICBjb25zdCBjZW50ZXJZID0gc2luUGhpICogY2VudGVyWHAgKyBjb3NQaGkgKiBjZW50ZXJZcCArIChweSArIGN5KSAvIDI7XG4gIGNvbnN0IHZ4MSA9IChweHAgLSBjZW50ZXJYcCkgLyByeDtcbiAgY29uc3QgdnkxID0gKHB5cCAtIGNlbnRlcllwKSAvIHJ5O1xuICBjb25zdCB2eDIgPSAoLXB4cCAtIGNlbnRlclhwKSAvIHJ4O1xuICBjb25zdCB2eTIgPSAoLXB5cCAtIGNlbnRlcllwKSAvIHJ5O1xuICBjb25zdCBhbmcxID0gdmVjdG9yQW5nbGUoMSwgMCwgdngxLCB2eTEpO1xuICBsZXQgYW5nMiA9IHZlY3RvckFuZ2xlKHZ4MSwgdnkxLCB2eDIsIHZ5Mik7XG4gIGlmIChzd2VlcEZsYWcgPT09IDAgJiYgYW5nMiA+IDApIHtcbiAgICBhbmcyIC09IFRBVTtcbiAgfVxuICBpZiAoc3dlZXBGbGFnID09PSAxICYmIGFuZzIgPCAwKSB7XG4gICAgYW5nMiArPSBUQVU7XG4gIH1cbiAgb3V0Mi5jZW50ZXJYID0gY2VudGVyWDtcbiAgb3V0Mi5jZW50ZXJZID0gY2VudGVyWTtcbiAgb3V0Mi5hbmcxID0gYW5nMTtcbiAgb3V0Mi5hbmcyID0gYW5nMjtcbn07XG5mdW5jdGlvbiBidWlsZEFyY1RvU3ZnKHBvaW50cywgcHgsIHB5LCBjeCwgY3ksIHJ4LCByeSwgeEF4aXNSb3RhdGlvbiA9IDAsIGxhcmdlQXJjRmxhZyA9IDAsIHN3ZWVwRmxhZyA9IDApIHtcbiAgaWYgKHJ4ID09PSAwIHx8IHJ5ID09PSAwKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHNpblBoaSA9IE1hdGguc2luKHhBeGlzUm90YXRpb24gKiBUQVUgLyAzNjApO1xuICBjb25zdCBjb3NQaGkgPSBNYXRoLmNvcyh4QXhpc1JvdGF0aW9uICogVEFVIC8gMzYwKTtcbiAgY29uc3QgcHhwID0gY29zUGhpICogKHB4IC0gY3gpIC8gMiArIHNpblBoaSAqIChweSAtIGN5KSAvIDI7XG4gIGNvbnN0IHB5cCA9IC1zaW5QaGkgKiAocHggLSBjeCkgLyAyICsgY29zUGhpICogKHB5IC0gY3kpIC8gMjtcbiAgaWYgKHB4cCA9PT0gMCAmJiBweXAgPT09IDApIHtcbiAgICByZXR1cm47XG4gIH1cbiAgcnggPSBNYXRoLmFicyhyeCk7XG4gIHJ5ID0gTWF0aC5hYnMocnkpO1xuICBjb25zdCBsYW1iZGEgPSBNYXRoLnBvdyhweHAsIDIpIC8gTWF0aC5wb3cocngsIDIpICsgTWF0aC5wb3cocHlwLCAyKSAvIE1hdGgucG93KHJ5LCAyKTtcbiAgaWYgKGxhbWJkYSA+IDEpIHtcbiAgICByeCAqPSBNYXRoLnNxcnQobGFtYmRhKTtcbiAgICByeSAqPSBNYXRoLnNxcnQobGFtYmRhKTtcbiAgfVxuICBnZXRBcmNDZW50ZXIoXG4gICAgcHgsXG4gICAgcHksXG4gICAgY3gsXG4gICAgY3ksXG4gICAgcngsXG4gICAgcnksXG4gICAgbGFyZ2VBcmNGbGFnLFxuICAgIHN3ZWVwRmxhZyxcbiAgICBzaW5QaGksXG4gICAgY29zUGhpLFxuICAgIHB4cCxcbiAgICBweXAsXG4gICAgb3V0XG4gICk7XG4gIGxldCB7IGFuZzEsIGFuZzIgfSA9IG91dDtcbiAgY29uc3QgeyBjZW50ZXJYLCBjZW50ZXJZIH0gPSBvdXQ7XG4gIGxldCByYXRpbyA9IE1hdGguYWJzKGFuZzIpIC8gKFRBVSAvIDQpO1xuICBpZiAoTWF0aC5hYnMoMSAtIHJhdGlvKSA8IDFlLTcpIHtcbiAgICByYXRpbyA9IDE7XG4gIH1cbiAgY29uc3Qgc2VnbWVudHMgPSBNYXRoLm1heChNYXRoLmNlaWwocmF0aW8pLCAxKTtcbiAgYW5nMiAvPSBzZWdtZW50cztcbiAgbGV0IGxhc3RYID0gcG9pbnRzW3BvaW50cy5sZW5ndGggLSAyXTtcbiAgbGV0IGxhc3RZID0gcG9pbnRzW3BvaW50cy5sZW5ndGggLSAxXTtcbiAgY29uc3Qgb3V0Q3VydmVQb2ludCA9IHsgeDogMCwgeTogMCB9O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzOyBpKyspIHtcbiAgICBjb25zdCBjdXJ2ZSA9IGFwcHJveFVuaXRBcmMoYW5nMSwgYW5nMik7XG4gICAgY29uc3QgeyB4OiB4MSwgeTogeTEgfSA9IG1hcFRvRWxsaXBzZShjdXJ2ZVswXSwgcngsIHJ5LCBjb3NQaGksIHNpblBoaSwgY2VudGVyWCwgY2VudGVyWSwgb3V0Q3VydmVQb2ludCk7XG4gICAgY29uc3QgeyB4OiB4MiwgeTogeTIgfSA9IG1hcFRvRWxsaXBzZShjdXJ2ZVsxXSwgcngsIHJ5LCBjb3NQaGksIHNpblBoaSwgY2VudGVyWCwgY2VudGVyWSwgb3V0Q3VydmVQb2ludCk7XG4gICAgY29uc3QgeyB4LCB5IH0gPSBtYXBUb0VsbGlwc2UoY3VydmVbMl0sIHJ4LCByeSwgY29zUGhpLCBzaW5QaGksIGNlbnRlclgsIGNlbnRlclksIG91dEN1cnZlUG9pbnQpO1xuICAgIGJ1aWxkQWRhcHRpdmVCZXppZXIoXG4gICAgICBwb2ludHMsXG4gICAgICBsYXN0WCxcbiAgICAgIGxhc3RZLFxuICAgICAgeDEsXG4gICAgICB5MSxcbiAgICAgIHgyLFxuICAgICAgeTIsXG4gICAgICB4LFxuICAgICAgeVxuICAgICk7XG4gICAgbGFzdFggPSB4O1xuICAgIGxhc3RZID0geTtcbiAgICBhbmcxICs9IGFuZzI7XG4gIH1cbn1cblxuZXhwb3J0IHsgYnVpbGRBcmNUb1N2ZyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVpbGRBcmNUb1N2Zy5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIHJvdW5kZWRTaGFwZUFyYyhnLCBwb2ludHMsIHJhZGl1cykge1xuICBjb25zdCB2ZWNGcm9tID0gKHAsIHBwKSA9PiB7XG4gICAgY29uc3QgeCA9IHBwLnggLSBwLng7XG4gICAgY29uc3QgeSA9IHBwLnkgLSBwLnk7XG4gICAgY29uc3QgbGVuID0gTWF0aC5zcXJ0KHggKiB4ICsgeSAqIHkpO1xuICAgIGNvbnN0IG54ID0geCAvIGxlbjtcbiAgICBjb25zdCBueSA9IHkgLyBsZW47XG4gICAgcmV0dXJuIHsgbGVuLCBueCwgbnkgfTtcbiAgfTtcbiAgY29uc3Qgc2hhcnBDb3JuZXIgPSAoaSwgcCkgPT4ge1xuICAgIGlmIChpID09PSAwKSB7XG4gICAgICBnLm1vdmVUbyhwLngsIHAueSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGcubGluZVRvKHAueCwgcC55KTtcbiAgICB9XG4gIH07XG4gIGxldCBwMSA9IHBvaW50c1twb2ludHMubGVuZ3RoIC0gMV07XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcG9pbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgcDIgPSBwb2ludHNbaSAlIHBvaW50cy5sZW5ndGhdO1xuICAgIGNvbnN0IHBSYWRpdXMgPSBwMi5yYWRpdXMgPz8gcmFkaXVzO1xuICAgIGlmIChwUmFkaXVzIDw9IDApIHtcbiAgICAgIHNoYXJwQ29ybmVyKGksIHAyKTtcbiAgICAgIHAxID0gcDI7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgcDMgPSBwb2ludHNbKGkgKyAxKSAlIHBvaW50cy5sZW5ndGhdO1xuICAgIGNvbnN0IHYxID0gdmVjRnJvbShwMiwgcDEpO1xuICAgIGNvbnN0IHYyID0gdmVjRnJvbShwMiwgcDMpO1xuICAgIGlmICh2MS5sZW4gPCAxZS00IHx8IHYyLmxlbiA8IDFlLTQpIHtcbiAgICAgIHNoYXJwQ29ybmVyKGksIHAyKTtcbiAgICAgIHAxID0gcDI7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgbGV0IGFuZ2xlID0gTWF0aC5hc2luKHYxLm54ICogdjIubnkgLSB2MS5ueSAqIHYyLm54KTtcbiAgICBsZXQgcmFkRGlyZWN0aW9uID0gMTtcbiAgICBsZXQgZHJhd0RpcmVjdGlvbiA9IGZhbHNlO1xuICAgIGlmICh2MS5ueCAqIHYyLm54IC0gdjEubnkgKiAtdjIubnkgPCAwKSB7XG4gICAgICBpZiAoYW5nbGUgPCAwKSB7XG4gICAgICAgIGFuZ2xlID0gTWF0aC5QSSArIGFuZ2xlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYW5nbGUgPSBNYXRoLlBJIC0gYW5nbGU7XG4gICAgICAgIHJhZERpcmVjdGlvbiA9IC0xO1xuICAgICAgICBkcmF3RGlyZWN0aW9uID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGFuZ2xlID4gMCkge1xuICAgICAgcmFkRGlyZWN0aW9uID0gLTE7XG4gICAgICBkcmF3RGlyZWN0aW9uID0gdHJ1ZTtcbiAgICB9XG4gICAgY29uc3QgaGFsZkFuZ2xlID0gYW5nbGUgLyAyO1xuICAgIGxldCBjUmFkaXVzO1xuICAgIGxldCBsZW5PdXQgPSBNYXRoLmFicyhcbiAgICAgIE1hdGguY29zKGhhbGZBbmdsZSkgKiBwUmFkaXVzIC8gTWF0aC5zaW4oaGFsZkFuZ2xlKVxuICAgICk7XG4gICAgaWYgKGxlbk91dCA+IE1hdGgubWluKHYxLmxlbiAvIDIsIHYyLmxlbiAvIDIpKSB7XG4gICAgICBsZW5PdXQgPSBNYXRoLm1pbih2MS5sZW4gLyAyLCB2Mi5sZW4gLyAyKTtcbiAgICAgIGNSYWRpdXMgPSBNYXRoLmFicyhsZW5PdXQgKiBNYXRoLnNpbihoYWxmQW5nbGUpIC8gTWF0aC5jb3MoaGFsZkFuZ2xlKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNSYWRpdXMgPSBwUmFkaXVzO1xuICAgIH1cbiAgICBjb25zdCBjWCA9IHAyLnggKyB2Mi5ueCAqIGxlbk91dCArIC12Mi5ueSAqIGNSYWRpdXMgKiByYWREaXJlY3Rpb247XG4gICAgY29uc3QgY1kgPSBwMi55ICsgdjIubnkgKiBsZW5PdXQgKyB2Mi5ueCAqIGNSYWRpdXMgKiByYWREaXJlY3Rpb247XG4gICAgY29uc3Qgc3RhcnRBbmdsZSA9IE1hdGguYXRhbjIodjEubnksIHYxLm54KSArIE1hdGguUEkgLyAyICogcmFkRGlyZWN0aW9uO1xuICAgIGNvbnN0IGVuZEFuZ2xlID0gTWF0aC5hdGFuMih2Mi5ueSwgdjIubngpIC0gTWF0aC5QSSAvIDIgKiByYWREaXJlY3Rpb247XG4gICAgaWYgKGkgPT09IDApIHtcbiAgICAgIGcubW92ZVRvKFxuICAgICAgICBjWCArIE1hdGguY29zKHN0YXJ0QW5nbGUpICogY1JhZGl1cyxcbiAgICAgICAgY1kgKyBNYXRoLnNpbihzdGFydEFuZ2xlKSAqIGNSYWRpdXNcbiAgICAgICk7XG4gICAgfVxuICAgIGcuYXJjKGNYLCBjWSwgY1JhZGl1cywgc3RhcnRBbmdsZSwgZW5kQW5nbGUsIGRyYXdEaXJlY3Rpb24pO1xuICAgIHAxID0gcDI7XG4gIH1cbn1cbmZ1bmN0aW9uIHJvdW5kZWRTaGFwZVF1YWRyYXRpY0N1cnZlKGcsIHBvaW50cywgcmFkaXVzLCBzbW9vdGhuZXNzKSB7XG4gIGNvbnN0IGRpc3RhbmNlID0gKHAxLCBwMikgPT4gTWF0aC5zcXJ0KChwMS54IC0gcDIueCkgKiogMiArIChwMS55IC0gcDIueSkgKiogMik7XG4gIGNvbnN0IHBvaW50TGVycCA9IChwMSwgcDIsIHQpID0+ICh7XG4gICAgeDogcDEueCArIChwMi54IC0gcDEueCkgKiB0LFxuICAgIHk6IHAxLnkgKyAocDIueSAtIHAxLnkpICogdFxuICB9KTtcbiAgY29uc3QgbnVtUG9pbnRzID0gcG9pbnRzLmxlbmd0aDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBudW1Qb2ludHM7IGkrKykge1xuICAgIGNvbnN0IHRoaXNQb2ludCA9IHBvaW50c1soaSArIDEpICUgbnVtUG9pbnRzXTtcbiAgICBjb25zdCBwUmFkaXVzID0gdGhpc1BvaW50LnJhZGl1cyA/PyByYWRpdXM7XG4gICAgaWYgKHBSYWRpdXMgPD0gMCkge1xuICAgICAgaWYgKGkgPT09IDApIHtcbiAgICAgICAgZy5tb3ZlVG8odGhpc1BvaW50LngsIHRoaXNQb2ludC55KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGcubGluZVRvKHRoaXNQb2ludC54LCB0aGlzUG9pbnQueSk7XG4gICAgICB9XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgbGFzdFBvaW50ID0gcG9pbnRzW2ldO1xuICAgIGNvbnN0IG5leHRQb2ludCA9IHBvaW50c1soaSArIDIpICUgbnVtUG9pbnRzXTtcbiAgICBjb25zdCBsYXN0RWRnZUxlbmd0aCA9IGRpc3RhbmNlKGxhc3RQb2ludCwgdGhpc1BvaW50KTtcbiAgICBsZXQgc3RhcnQ7XG4gICAgaWYgKGxhc3RFZGdlTGVuZ3RoIDwgMWUtNCkge1xuICAgICAgc3RhcnQgPSB0aGlzUG9pbnQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGxhc3RPZmZzZXREaXN0YW5jZSA9IE1hdGgubWluKGxhc3RFZGdlTGVuZ3RoIC8gMiwgcFJhZGl1cyk7XG4gICAgICBzdGFydCA9IHBvaW50TGVycChcbiAgICAgICAgdGhpc1BvaW50LFxuICAgICAgICBsYXN0UG9pbnQsXG4gICAgICAgIGxhc3RPZmZzZXREaXN0YW5jZSAvIGxhc3RFZGdlTGVuZ3RoXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBuZXh0RWRnZUxlbmd0aCA9IGRpc3RhbmNlKG5leHRQb2ludCwgdGhpc1BvaW50KTtcbiAgICBsZXQgZW5kO1xuICAgIGlmIChuZXh0RWRnZUxlbmd0aCA8IDFlLTQpIHtcbiAgICAgIGVuZCA9IHRoaXNQb2ludDtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgbmV4dE9mZnNldERpc3RhbmNlID0gTWF0aC5taW4obmV4dEVkZ2VMZW5ndGggLyAyLCBwUmFkaXVzKTtcbiAgICAgIGVuZCA9IHBvaW50TGVycChcbiAgICAgICAgdGhpc1BvaW50LFxuICAgICAgICBuZXh0UG9pbnQsXG4gICAgICAgIG5leHRPZmZzZXREaXN0YW5jZSAvIG5leHRFZGdlTGVuZ3RoXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAoaSA9PT0gMCkge1xuICAgICAgZy5tb3ZlVG8oc3RhcnQueCwgc3RhcnQueSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGcubGluZVRvKHN0YXJ0LngsIHN0YXJ0LnkpO1xuICAgIH1cbiAgICBnLnF1YWRyYXRpY0N1cnZlVG8odGhpc1BvaW50LngsIHRoaXNQb2ludC55LCBlbmQueCwgZW5kLnksIHNtb290aG5lc3MpO1xuICB9XG59XG5cbmV4cG9ydCB7IHJvdW5kZWRTaGFwZUFyYywgcm91bmRlZFNoYXBlUXVhZHJhdGljQ3VydmUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdW5kU2hhcGUubWpzLm1hcFxuIiwiaW1wb3J0IHsgQ2lyY2xlIH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvc2hhcGVzL0NpcmNsZS5tanMnO1xuaW1wb3J0IHsgRWxsaXBzZSB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL3NoYXBlcy9FbGxpcHNlLm1qcyc7XG5pbXBvcnQgeyBQb2x5Z29uIH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvc2hhcGVzL1BvbHlnb24ubWpzJztcbmltcG9ydCB7IFJlY3RhbmdsZSB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL3NoYXBlcy9SZWN0YW5nbGUubWpzJztcbmltcG9ydCB7IFJvdW5kZWRSZWN0YW5nbGUgfSBmcm9tICcuLi8uLi8uLi8uLi9tYXRocy9zaGFwZXMvUm91bmRlZFJlY3RhbmdsZS5tanMnO1xuaW1wb3J0IHsgQm91bmRzIH0gZnJvbSAnLi4vLi4vLi4vY29udGFpbmVyL2JvdW5kcy9Cb3VuZHMubWpzJztcbmltcG9ydCB7IGJ1aWxkQWRhcHRpdmVCZXppZXIgfSBmcm9tICcuLi9idWlsZENvbW1hbmRzL2J1aWxkQWRhcHRpdmVCZXppZXIubWpzJztcbmltcG9ydCB7IGJ1aWxkQWRhcHRpdmVRdWFkcmF0aWMgfSBmcm9tICcuLi9idWlsZENvbW1hbmRzL2J1aWxkQWRhcHRpdmVRdWFkcmF0aWMubWpzJztcbmltcG9ydCB7IGJ1aWxkQXJjIH0gZnJvbSAnLi4vYnVpbGRDb21tYW5kcy9idWlsZEFyYy5tanMnO1xuaW1wb3J0IHsgYnVpbGRBcmNUbyB9IGZyb20gJy4uL2J1aWxkQ29tbWFuZHMvYnVpbGRBcmNUby5tanMnO1xuaW1wb3J0IHsgYnVpbGRBcmNUb1N2ZyB9IGZyb20gJy4uL2J1aWxkQ29tbWFuZHMvYnVpbGRBcmNUb1N2Zy5tanMnO1xuaW1wb3J0IHsgcm91bmRlZFNoYXBlUXVhZHJhdGljQ3VydmUsIHJvdW5kZWRTaGFwZUFyYyB9IGZyb20gJy4vcm91bmRTaGFwZS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IHRlbXBSZWN0YW5nbGUgPSBuZXcgUmVjdGFuZ2xlKCk7XG5jbGFzcyBTaGFwZVBhdGgge1xuICBjb25zdHJ1Y3RvcihncmFwaGljc1BhdGgyRCkge1xuICAgIC8qKiBUaGUgbGlzdCBvZiBzaGFwZSBwcmltaXRpdmVzIHRoYXQgbWFrZSB1cCB0aGUgcGF0aC4gKi9cbiAgICB0aGlzLnNoYXBlUHJpbWl0aXZlcyA9IFtdO1xuICAgIHRoaXMuX2N1cnJlbnRQb2x5ID0gbnVsbDtcbiAgICB0aGlzLl9ib3VuZHMgPSBuZXcgQm91bmRzKCk7XG4gICAgdGhpcy5fZ3JhcGhpY3NQYXRoMkQgPSBncmFwaGljc1BhdGgyRDtcbiAgICB0aGlzLnNpZ25lZCA9IGdyYXBoaWNzUGF0aDJELmNoZWNrRm9ySG9sZXM7XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgdGhlIHN0YXJ0aW5nIHBvaW50IGZvciBhIG5ldyBzdWItcGF0aC4gQW55IHN1YnNlcXVlbnQgZHJhd2luZyBjb21tYW5kcyBhcmUgY29uc2lkZXJlZCBwYXJ0IG9mIHRoaXMgcGF0aC5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIGZvciB0aGUgc3RhcnRpbmcgcG9pbnQuXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBmb3IgdGhlIHN0YXJ0aW5nIHBvaW50LlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIG1vdmVUbyh4LCB5KSB7XG4gICAgdGhpcy5zdGFydFBvbHkoeCwgeSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENvbm5lY3RzIHRoZSBjdXJyZW50IHBvaW50IHRvIGEgbmV3IHBvaW50IHdpdGggYSBzdHJhaWdodCBsaW5lLiBUaGlzIG1ldGhvZCB1cGRhdGVzIHRoZSBjdXJyZW50IHBhdGguXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgbmV3IHBvaW50IHRvIGNvbm5lY3QgdG8uXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgbmV3IHBvaW50IHRvIGNvbm5lY3QgdG8uXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgbGluZVRvKHgsIHkpIHtcbiAgICB0aGlzLl9lbnN1cmVQb2x5KCk7XG4gICAgY29uc3QgcG9pbnRzID0gdGhpcy5fY3VycmVudFBvbHkucG9pbnRzO1xuICAgIGNvbnN0IGZyb21YID0gcG9pbnRzW3BvaW50cy5sZW5ndGggLSAyXTtcbiAgICBjb25zdCBmcm9tWSA9IHBvaW50c1twb2ludHMubGVuZ3RoIC0gMV07XG4gICAgaWYgKGZyb21YICE9PSB4IHx8IGZyb21ZICE9PSB5KSB7XG4gICAgICBwb2ludHMucHVzaCh4LCB5KTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYW4gYXJjIHRvIHRoZSBwYXRoLiBUaGUgYXJjIGlzIGNlbnRlcmVkIGF0ICh4LCB5KVxuICAgKiAgcG9zaXRpb24gd2l0aCByYWRpdXMgYHJhZGl1c2Agc3RhcnRpbmcgYXQgYHN0YXJ0QW5nbGVgIGFuZCBlbmRpbmcgYXQgYGVuZEFuZ2xlYC5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBhcmMncyBjZW50ZXIuXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgYXJjJ3MgY2VudGVyLlxuICAgKiBAcGFyYW0gcmFkaXVzIC0gVGhlIHJhZGl1cyBvZiB0aGUgYXJjLlxuICAgKiBAcGFyYW0gc3RhcnRBbmdsZSAtIFRoZSBzdGFydGluZyBhbmdsZSBvZiB0aGUgYXJjLCBpbiByYWRpYW5zLlxuICAgKiBAcGFyYW0gZW5kQW5nbGUgLSBUaGUgZW5kaW5nIGFuZ2xlIG9mIHRoZSBhcmMsIGluIHJhZGlhbnMuXG4gICAqIEBwYXJhbSBjb3VudGVyY2xvY2t3aXNlIC0gU3BlY2lmaWVzIHdoZXRoZXIgdGhlIGFyYyBzaG91bGQgYmUgZHJhd24gaW4gdGhlIGFudGljbG9ja3dpc2UgZGlyZWN0aW9uLiBGYWxzZSBieSBkZWZhdWx0LlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIGFyYyh4LCB5LCByYWRpdXMsIHN0YXJ0QW5nbGUsIGVuZEFuZ2xlLCBjb3VudGVyY2xvY2t3aXNlKSB7XG4gICAgdGhpcy5fZW5zdXJlUG9seShmYWxzZSk7XG4gICAgY29uc3QgcG9pbnRzID0gdGhpcy5fY3VycmVudFBvbHkucG9pbnRzO1xuICAgIGJ1aWxkQXJjKHBvaW50cywgeCwgeSwgcmFkaXVzLCBzdGFydEFuZ2xlLCBlbmRBbmdsZSwgY291bnRlcmNsb2Nrd2lzZSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYW4gYXJjIHRvIHRoZSBwYXRoIHdpdGggdGhlIGFyYyB0YW5nZW50IHRvIHRoZSBsaW5lIGpvaW5pbmcgdHdvIHNwZWNpZmllZCBwb2ludHMuXG4gICAqIFRoZSBhcmMgcmFkaXVzIGlzIHNwZWNpZmllZCBieSBgcmFkaXVzYC5cbiAgICogQHBhcmFtIHgxIC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgZmlyc3QgcG9pbnQuXG4gICAqIEBwYXJhbSB5MSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGZpcnN0IHBvaW50LlxuICAgKiBAcGFyYW0geDIgLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBzZWNvbmQgcG9pbnQuXG4gICAqIEBwYXJhbSB5MiAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIHNlY29uZCBwb2ludC5cbiAgICogQHBhcmFtIHJhZGl1cyAtIFRoZSByYWRpdXMgb2YgdGhlIGFyYy5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICBhcmNUbyh4MSwgeTEsIHgyLCB5MiwgcmFkaXVzKSB7XG4gICAgdGhpcy5fZW5zdXJlUG9seSgpO1xuICAgIGNvbnN0IHBvaW50cyA9IHRoaXMuX2N1cnJlbnRQb2x5LnBvaW50cztcbiAgICBidWlsZEFyY1RvKHBvaW50cywgeDEsIHkxLCB4MiwgeTIsIHJhZGl1cyk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYW4gU1ZHLXN0eWxlIGFyYyB0byB0aGUgcGF0aCwgYWxsb3dpbmcgZm9yIGVsbGlwdGljYWwgYXJjcyBiYXNlZCBvbiB0aGUgU1ZHIHNwZWMuXG4gICAqIEBwYXJhbSByeCAtIFRoZSB4LXJhZGl1cyBvZiB0aGUgZWxsaXBzZS5cbiAgICogQHBhcmFtIHJ5IC0gVGhlIHktcmFkaXVzIG9mIHRoZSBlbGxpcHNlLlxuICAgKiBAcGFyYW0geEF4aXNSb3RhdGlvbiAtIFRoZSByb3RhdGlvbiBvZiB0aGUgZWxsaXBzZSdzIHgtYXhpcyByZWxhdGl2ZVxuICAgKiB0byB0aGUgeC1heGlzIG9mIHRoZSBjb29yZGluYXRlIHN5c3RlbSwgaW4gZGVncmVlcy5cbiAgICogQHBhcmFtIGxhcmdlQXJjRmxhZyAtIERldGVybWluZXMgaWYgdGhlIGFyYyBzaG91bGQgYmUgZ3JlYXRlciB0aGFuIG9yIGxlc3MgdGhhbiAxODAgZGVncmVlcy5cbiAgICogQHBhcmFtIHN3ZWVwRmxhZyAtIERldGVybWluZXMgaWYgdGhlIGFyYyBzaG91bGQgYmUgc3dlcHQgaW4gYSBwb3NpdGl2ZSBhbmdsZSBkaXJlY3Rpb24uXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgYXJjJ3MgZW5kIHBvaW50LlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGFyYydzIGVuZCBwb2ludC5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICBhcmNUb1N2ZyhyeCwgcnksIHhBeGlzUm90YXRpb24sIGxhcmdlQXJjRmxhZywgc3dlZXBGbGFnLCB4LCB5KSB7XG4gICAgY29uc3QgcG9pbnRzID0gdGhpcy5fY3VycmVudFBvbHkucG9pbnRzO1xuICAgIGJ1aWxkQXJjVG9TdmcoXG4gICAgICBwb2ludHMsXG4gICAgICB0aGlzLl9jdXJyZW50UG9seS5sYXN0WCxcbiAgICAgIHRoaXMuX2N1cnJlbnRQb2x5Lmxhc3RZLFxuICAgICAgeCxcbiAgICAgIHksXG4gICAgICByeCxcbiAgICAgIHJ5LFxuICAgICAgeEF4aXNSb3RhdGlvbixcbiAgICAgIGxhcmdlQXJjRmxhZyxcbiAgICAgIHN3ZWVwRmxhZ1xuICAgICk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYSBjdWJpYyBCZXppZXIgY3VydmUgdG8gdGhlIHBhdGguXG4gICAqIEl0IHJlcXVpcmVzIHRocmVlIHBvaW50czogdGhlIGZpcnN0IHR3byBhcmUgY29udHJvbCBwb2ludHMgYW5kIHRoZSB0aGlyZCBvbmUgaXMgdGhlIGVuZCBwb2ludC5cbiAgICogVGhlIHN0YXJ0aW5nIHBvaW50IGlzIHRoZSBsYXN0IHBvaW50IGluIHRoZSBjdXJyZW50IHBhdGguXG4gICAqIEBwYXJhbSBjcDF4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgZmlyc3QgY29udHJvbCBwb2ludC5cbiAgICogQHBhcmFtIGNwMXkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBmaXJzdCBjb250cm9sIHBvaW50LlxuICAgKiBAcGFyYW0gY3AyeCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIHNlY29uZCBjb250cm9sIHBvaW50LlxuICAgKiBAcGFyYW0gY3AyeSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIHNlY29uZCBjb250cm9sIHBvaW50LlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGVuZCBwb2ludC5cbiAgICogQHBhcmFtIHkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBlbmQgcG9pbnQuXG4gICAqIEBwYXJhbSBzbW9vdGhuZXNzIC0gT3B0aW9uYWwgcGFyYW1ldGVyIHRvIGFkanVzdCB0aGUgc21vb3RobmVzcyBvZiB0aGUgY3VydmUuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgYmV6aWVyQ3VydmVUbyhjcDF4LCBjcDF5LCBjcDJ4LCBjcDJ5LCB4LCB5LCBzbW9vdGhuZXNzKSB7XG4gICAgdGhpcy5fZW5zdXJlUG9seSgpO1xuICAgIGNvbnN0IGN1cnJlbnRQb2x5ID0gdGhpcy5fY3VycmVudFBvbHk7XG4gICAgYnVpbGRBZGFwdGl2ZUJlemllcihcbiAgICAgIHRoaXMuX2N1cnJlbnRQb2x5LnBvaW50cyxcbiAgICAgIGN1cnJlbnRQb2x5Lmxhc3RYLFxuICAgICAgY3VycmVudFBvbHkubGFzdFksXG4gICAgICBjcDF4LFxuICAgICAgY3AxeSxcbiAgICAgIGNwMngsXG4gICAgICBjcDJ5LFxuICAgICAgeCxcbiAgICAgIHksXG4gICAgICBzbW9vdGhuZXNzXG4gICAgKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQWRkcyBhIHF1YWRyYXRpYyBjdXJ2ZSB0byB0aGUgcGF0aC4gSXQgcmVxdWlyZXMgdHdvIHBvaW50czogdGhlIGNvbnRyb2wgcG9pbnQgYW5kIHRoZSBlbmQgcG9pbnQuXG4gICAqIFRoZSBzdGFydGluZyBwb2ludCBpcyB0aGUgbGFzdCBwb2ludCBpbiB0aGUgY3VycmVudCBwYXRoLlxuICAgKiBAcGFyYW0gY3AxeCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGNvbnRyb2wgcG9pbnQuXG4gICAqIEBwYXJhbSBjcDF5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgY29udHJvbCBwb2ludC5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBlbmQgcG9pbnQuXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgZW5kIHBvaW50LlxuICAgKiBAcGFyYW0gc21vb3RoaW5nIC0gT3B0aW9uYWwgcGFyYW1ldGVyIHRvIGFkanVzdCB0aGUgc21vb3RobmVzcyBvZiB0aGUgY3VydmUuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgcXVhZHJhdGljQ3VydmVUbyhjcDF4LCBjcDF5LCB4LCB5LCBzbW9vdGhpbmcpIHtcbiAgICB0aGlzLl9lbnN1cmVQb2x5KCk7XG4gICAgY29uc3QgY3VycmVudFBvbHkgPSB0aGlzLl9jdXJyZW50UG9seTtcbiAgICBidWlsZEFkYXB0aXZlUXVhZHJhdGljKFxuICAgICAgdGhpcy5fY3VycmVudFBvbHkucG9pbnRzLFxuICAgICAgY3VycmVudFBvbHkubGFzdFgsXG4gICAgICBjdXJyZW50UG9seS5sYXN0WSxcbiAgICAgIGNwMXgsXG4gICAgICBjcDF5LFxuICAgICAgeCxcbiAgICAgIHksXG4gICAgICBzbW9vdGhpbmdcbiAgICApO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBDbG9zZXMgdGhlIGN1cnJlbnQgcGF0aCBieSBkcmF3aW5nIGEgc3RyYWlnaHQgbGluZSBiYWNrIHRvIHRoZSBzdGFydC5cbiAgICogSWYgdGhlIHNoYXBlIGlzIGFscmVhZHkgY2xvc2VkIG9yIHRoZXJlIGFyZSBubyBwb2ludHMgaW4gdGhlIHBhdGgsIHRoaXMgbWV0aG9kIGRvZXMgbm90aGluZy5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICBjbG9zZVBhdGgoKSB7XG4gICAgdGhpcy5lbmRQb2x5KHRydWUpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBBZGRzIGFub3RoZXIgcGF0aCB0byB0aGUgY3VycmVudCBwYXRoLiBUaGlzIG1ldGhvZCBhbGxvd3MgZm9yIHRoZSBjb21iaW5hdGlvbiBvZiBtdWx0aXBsZSBwYXRocyBpbnRvIG9uZS5cbiAgICogQHBhcmFtIHBhdGggLSBUaGUgYEdyYXBoaWNzUGF0aGAgb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgcGF0aCB0byBhZGQuXG4gICAqIEBwYXJhbSB0cmFuc2Zvcm0gLSBBbiBvcHRpb25hbCBgTWF0cml4YCBvYmplY3QgdG8gYXBwbHkgYSB0cmFuc2Zvcm1hdGlvbiB0byB0aGUgcGF0aCBiZWZvcmUgYWRkaW5nIGl0LlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIGFkZFBhdGgocGF0aCwgdHJhbnNmb3JtKSB7XG4gICAgdGhpcy5lbmRQb2x5KCk7XG4gICAgaWYgKHRyYW5zZm9ybSAmJiAhdHJhbnNmb3JtLmlzSWRlbnRpdHkoKSkge1xuICAgICAgcGF0aCA9IHBhdGguY2xvbmUodHJ1ZSk7XG4gICAgICBwYXRoLnRyYW5zZm9ybSh0cmFuc2Zvcm0pO1xuICAgIH1cbiAgICBjb25zdCBzaGFwZVByaW1pdGl2ZXMgPSB0aGlzLnNoYXBlUHJpbWl0aXZlcztcbiAgICBjb25zdCBzdGFydCA9IHNoYXBlUHJpbWl0aXZlcy5sZW5ndGg7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXRoLmluc3RydWN0aW9ucy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgaW5zdHJ1Y3Rpb24gPSBwYXRoLmluc3RydWN0aW9uc1tpXTtcbiAgICAgIHRoaXNbaW5zdHJ1Y3Rpb24uYWN0aW9uXSguLi5pbnN0cnVjdGlvbi5kYXRhKTtcbiAgICB9XG4gICAgaWYgKHBhdGguY2hlY2tGb3JIb2xlcyAmJiBzaGFwZVByaW1pdGl2ZXMubGVuZ3RoIC0gc3RhcnQgPiAxKSB7XG4gICAgICBsZXQgbWFpblNoYXBlID0gbnVsbDtcbiAgICAgIGZvciAobGV0IGkgPSBzdGFydDsgaSA8IHNoYXBlUHJpbWl0aXZlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBzaGFwZVByaW1pdGl2ZSA9IHNoYXBlUHJpbWl0aXZlc1tpXTtcbiAgICAgICAgaWYgKHNoYXBlUHJpbWl0aXZlLnNoYXBlLnR5cGUgPT09IFwicG9seWdvblwiKSB7XG4gICAgICAgICAgY29uc3QgcG9seWdvbiA9IHNoYXBlUHJpbWl0aXZlLnNoYXBlO1xuICAgICAgICAgIGNvbnN0IG1haW5Qb2x5Z29uID0gbWFpblNoYXBlPy5zaGFwZTtcbiAgICAgICAgICBpZiAobWFpblBvbHlnb24gJiYgbWFpblBvbHlnb24uY29udGFpbnNQb2x5Z29uKHBvbHlnb24pKSB7XG4gICAgICAgICAgICBtYWluU2hhcGUuaG9sZXMgfHwgKG1haW5TaGFwZS5ob2xlcyA9IFtdKTtcbiAgICAgICAgICAgIG1haW5TaGFwZS5ob2xlcy5wdXNoKHNoYXBlUHJpbWl0aXZlKTtcbiAgICAgICAgICAgIHNoYXBlUHJpbWl0aXZlcy5jb3B5V2l0aGluKGksIGkgKyAxKTtcbiAgICAgICAgICAgIHNoYXBlUHJpbWl0aXZlcy5sZW5ndGgtLTtcbiAgICAgICAgICAgIGktLTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbWFpblNoYXBlID0gc2hhcGVQcmltaXRpdmU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBGaW5hbGl6ZXMgdGhlIGRyYXdpbmcgb2YgdGhlIGN1cnJlbnQgcGF0aC4gT3B0aW9uYWxseSwgaXQgY2FuIGNsb3NlIHRoZSBwYXRoLlxuICAgKiBAcGFyYW0gY2xvc2VQYXRoIC0gQSBib29sZWFuIGluZGljYXRpbmcgd2hldGhlciB0byBjbG9zZSB0aGUgcGF0aCBhZnRlciBmaW5pc2hpbmcuIEZhbHNlIGJ5IGRlZmF1bHQuXG4gICAqL1xuICBmaW5pc2goY2xvc2VQYXRoID0gZmFsc2UpIHtcbiAgICB0aGlzLmVuZFBvbHkoY2xvc2VQYXRoKTtcbiAgfVxuICAvKipcbiAgICogRHJhd3MgYSByZWN0YW5nbGUgc2hhcGUuIFRoaXMgbWV0aG9kIGFkZHMgYSBuZXcgcmVjdGFuZ2xlIHBhdGggdG8gdGhlIGN1cnJlbnQgZHJhd2luZy5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSB0b3AtbGVmdCBjb3JuZXIgb2YgdGhlIHJlY3RhbmdsZS5cbiAgICogQHBhcmFtIHkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSB0b3AtbGVmdCBjb3JuZXIgb2YgdGhlIHJlY3RhbmdsZS5cbiAgICogQHBhcmFtIHcgLSBUaGUgd2lkdGggb2YgdGhlIHJlY3RhbmdsZS5cbiAgICogQHBhcmFtIGggLSBUaGUgaGVpZ2h0IG9mIHRoZSByZWN0YW5nbGUuXG4gICAqIEBwYXJhbSB0cmFuc2Zvcm0gLSBBbiBvcHRpb25hbCBgTWF0cml4YCBvYmplY3QgdG8gYXBwbHkgYSB0cmFuc2Zvcm1hdGlvbiB0byB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIHJlY3QoeCwgeSwgdywgaCwgdHJhbnNmb3JtKSB7XG4gICAgdGhpcy5kcmF3U2hhcGUobmV3IFJlY3RhbmdsZSh4LCB5LCB3LCBoKSwgdHJhbnNmb3JtKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogRHJhd3MgYSBjaXJjbGUgc2hhcGUuIFRoaXMgbWV0aG9kIGFkZHMgYSBuZXcgY2lyY2xlIHBhdGggdG8gdGhlIGN1cnJlbnQgZHJhd2luZy5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBjZW50ZXIgb2YgdGhlIGNpcmNsZS5cbiAgICogQHBhcmFtIHkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBjZW50ZXIgb2YgdGhlIGNpcmNsZS5cbiAgICogQHBhcmFtIHJhZGl1cyAtIFRoZSByYWRpdXMgb2YgdGhlIGNpcmNsZS5cbiAgICogQHBhcmFtIHRyYW5zZm9ybSAtIEFuIG9wdGlvbmFsIGBNYXRyaXhgIG9iamVjdCB0byBhcHBseSBhIHRyYW5zZm9ybWF0aW9uIHRvIHRoZSBjaXJjbGUuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgY2lyY2xlKHgsIHksIHJhZGl1cywgdHJhbnNmb3JtKSB7XG4gICAgdGhpcy5kcmF3U2hhcGUobmV3IENpcmNsZSh4LCB5LCByYWRpdXMpLCB0cmFuc2Zvcm0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIHBvbHlnb24gc2hhcGUuIFRoaXMgbWV0aG9kIGFsbG93cyBmb3IgdGhlIGNyZWF0aW9uIG9mIGNvbXBsZXggcG9seWdvbnMgYnkgc3BlY2lmeWluZyBhIHNlcXVlbmNlIG9mIHBvaW50cy5cbiAgICogQHBhcmFtIHBvaW50cyAtIEFuIGFycmF5IG9mIG51bWJlcnMsIG9yIG9yIGFuIGFycmF5IG9mIFBvaW50RGF0YSBvYmplY3RzIGVnIFt7eCx5fSwge3gseX0sIHt4LHl9XVxuICAgKiByZXByZXNlbnRpbmcgdGhlIHggYW5kIHkgY29vcmRpbmF0ZXMgb2YgdGhlIHBvbHlnb24ncyB2ZXJ0aWNlcywgaW4gc2VxdWVuY2UuXG4gICAqIEBwYXJhbSBjbG9zZSAtIEEgYm9vbGVhbiBpbmRpY2F0aW5nIHdoZXRoZXIgdG8gY2xvc2UgdGhlIHBvbHlnb24gcGF0aC4gVHJ1ZSBieSBkZWZhdWx0LlxuICAgKiBAcGFyYW0gdHJhbnNmb3JtIC0gQW4gb3B0aW9uYWwgYE1hdHJpeGAgb2JqZWN0IHRvIGFwcGx5IGEgdHJhbnNmb3JtYXRpb24gdG8gdGhlIHBvbHlnb24uXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgcG9seShwb2ludHMsIGNsb3NlLCB0cmFuc2Zvcm0pIHtcbiAgICBjb25zdCBwb2x5Z29uID0gbmV3IFBvbHlnb24ocG9pbnRzKTtcbiAgICBwb2x5Z29uLmNsb3NlUGF0aCA9IGNsb3NlO1xuICAgIHRoaXMuZHJhd1NoYXBlKHBvbHlnb24sIHRyYW5zZm9ybSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIERyYXdzIGEgcmVndWxhciBwb2x5Z29uIHdpdGggYSBzcGVjaWZpZWQgbnVtYmVyIG9mIHNpZGVzLiBBbGwgc2lkZXMgYW5kIGFuZ2xlcyBhcmUgZXF1YWwuXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgY2VudGVyIG9mIHRoZSBwb2x5Z29uLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGNlbnRlciBvZiB0aGUgcG9seWdvbi5cbiAgICogQHBhcmFtIHJhZGl1cyAtIFRoZSByYWRpdXMgb2YgdGhlIGNpcmN1bXNjcmliZWQgY2lyY2xlIG9mIHRoZSBwb2x5Z29uLlxuICAgKiBAcGFyYW0gc2lkZXMgLSBUaGUgbnVtYmVyIG9mIHNpZGVzIG9mIHRoZSBwb2x5Z29uLiBNdXN0IGJlIDMgb3IgbW9yZS5cbiAgICogQHBhcmFtIHJvdGF0aW9uIC0gVGhlIHJvdGF0aW9uIGFuZ2xlIG9mIHRoZSBwb2x5Z29uLCBpbiByYWRpYW5zLiBaZXJvIGJ5IGRlZmF1bHQuXG4gICAqIEBwYXJhbSB0cmFuc2Zvcm0gLSBBbiBvcHRpb25hbCBgTWF0cml4YCBvYmplY3QgdG8gYXBwbHkgYSB0cmFuc2Zvcm1hdGlvbiB0byB0aGUgcG9seWdvbi5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICByZWd1bGFyUG9seSh4LCB5LCByYWRpdXMsIHNpZGVzLCByb3RhdGlvbiA9IDAsIHRyYW5zZm9ybSkge1xuICAgIHNpZGVzID0gTWF0aC5tYXgoc2lkZXMgfCAwLCAzKTtcbiAgICBjb25zdCBzdGFydEFuZ2xlID0gLTEgKiBNYXRoLlBJIC8gMiArIHJvdGF0aW9uO1xuICAgIGNvbnN0IGRlbHRhID0gTWF0aC5QSSAqIDIgLyBzaWRlcztcbiAgICBjb25zdCBwb2x5Z29uID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaWRlczsgaSsrKSB7XG4gICAgICBjb25zdCBhbmdsZSA9IHN0YXJ0QW5nbGUgLSBpICogZGVsdGE7XG4gICAgICBwb2x5Z29uLnB1c2goXG4gICAgICAgIHggKyByYWRpdXMgKiBNYXRoLmNvcyhhbmdsZSksXG4gICAgICAgIHkgKyByYWRpdXMgKiBNYXRoLnNpbihhbmdsZSlcbiAgICAgICk7XG4gICAgfVxuICAgIHRoaXMucG9seShwb2x5Z29uLCB0cnVlLCB0cmFuc2Zvcm0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIHBvbHlnb24gd2l0aCByb3VuZGVkIGNvcm5lcnMuXG4gICAqIFNpbWlsYXIgdG8gYHJlZ3VsYXJQb2x5YCBidXQgd2l0aCB0aGUgYWJpbGl0eSB0byByb3VuZCB0aGUgY29ybmVycyBvZiB0aGUgcG9seWdvbi5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBjZW50ZXIgb2YgdGhlIHBvbHlnb24uXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgY2VudGVyIG9mIHRoZSBwb2x5Z29uLlxuICAgKiBAcGFyYW0gcmFkaXVzIC0gVGhlIHJhZGl1cyBvZiB0aGUgY2lyY3Vtc2NyaWJlZCBjaXJjbGUgb2YgdGhlIHBvbHlnb24uXG4gICAqIEBwYXJhbSBzaWRlcyAtIFRoZSBudW1iZXIgb2Ygc2lkZXMgb2YgdGhlIHBvbHlnb24uIE11c3QgYmUgMyBvciBtb3JlLlxuICAgKiBAcGFyYW0gY29ybmVyIC0gVGhlIHJhZGl1cyBvZiB0aGUgcm91bmRpbmcgb2YgdGhlIGNvcm5lcnMuXG4gICAqIEBwYXJhbSByb3RhdGlvbiAtIFRoZSByb3RhdGlvbiBhbmdsZSBvZiB0aGUgcG9seWdvbiwgaW4gcmFkaWFucy4gWmVybyBieSBkZWZhdWx0LlxuICAgKiBAcGFyYW0gc21vb3RobmVzcyAtIE9wdGlvbmFsIHBhcmFtZXRlciB0byBhZGp1c3QgdGhlIHNtb290aG5lc3Mgb2YgdGhlIHJvdW5kaW5nLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIHJvdW5kUG9seSh4LCB5LCByYWRpdXMsIHNpZGVzLCBjb3JuZXIsIHJvdGF0aW9uID0gMCwgc21vb3RobmVzcykge1xuICAgIHNpZGVzID0gTWF0aC5tYXgoc2lkZXMgfCAwLCAzKTtcbiAgICBpZiAoY29ybmVyIDw9IDApIHtcbiAgICAgIHJldHVybiB0aGlzLnJlZ3VsYXJQb2x5KHgsIHksIHJhZGl1cywgc2lkZXMsIHJvdGF0aW9uKTtcbiAgICB9XG4gICAgY29uc3Qgc2lkZUxlbmd0aCA9IHJhZGl1cyAqIE1hdGguc2luKE1hdGguUEkgLyBzaWRlcykgLSAxZS0zO1xuICAgIGNvcm5lciA9IE1hdGgubWluKGNvcm5lciwgc2lkZUxlbmd0aCk7XG4gICAgY29uc3Qgc3RhcnRBbmdsZSA9IC0xICogTWF0aC5QSSAvIDIgKyByb3RhdGlvbjtcbiAgICBjb25zdCBkZWx0YSA9IE1hdGguUEkgKiAyIC8gc2lkZXM7XG4gICAgY29uc3QgaW50ZXJuYWxBbmdsZSA9IChzaWRlcyAtIDIpICogTWF0aC5QSSAvIHNpZGVzIC8gMjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNpZGVzOyBpKyspIHtcbiAgICAgIGNvbnN0IGFuZ2xlID0gaSAqIGRlbHRhICsgc3RhcnRBbmdsZTtcbiAgICAgIGNvbnN0IHgwID0geCArIHJhZGl1cyAqIE1hdGguY29zKGFuZ2xlKTtcbiAgICAgIGNvbnN0IHkwID0geSArIHJhZGl1cyAqIE1hdGguc2luKGFuZ2xlKTtcbiAgICAgIGNvbnN0IGExID0gYW5nbGUgKyBNYXRoLlBJICsgaW50ZXJuYWxBbmdsZTtcbiAgICAgIGNvbnN0IGEyID0gYW5nbGUgLSBNYXRoLlBJIC0gaW50ZXJuYWxBbmdsZTtcbiAgICAgIGNvbnN0IHgxID0geDAgKyBjb3JuZXIgKiBNYXRoLmNvcyhhMSk7XG4gICAgICBjb25zdCB5MSA9IHkwICsgY29ybmVyICogTWF0aC5zaW4oYTEpO1xuICAgICAgY29uc3QgeDMgPSB4MCArIGNvcm5lciAqIE1hdGguY29zKGEyKTtcbiAgICAgIGNvbnN0IHkzID0geTAgKyBjb3JuZXIgKiBNYXRoLnNpbihhMik7XG4gICAgICBpZiAoaSA9PT0gMCkge1xuICAgICAgICB0aGlzLm1vdmVUbyh4MSwgeTEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5saW5lVG8oeDEsIHkxKTtcbiAgICAgIH1cbiAgICAgIHRoaXMucXVhZHJhdGljQ3VydmVUbyh4MCwgeTAsIHgzLCB5Mywgc21vb3RobmVzcyk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmNsb3NlUGF0aCgpO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIHNoYXBlIHdpdGggcm91bmRlZCBjb3JuZXJzLiBUaGlzIGZ1bmN0aW9uIHN1cHBvcnRzIGN1c3RvbSByYWRpdXMgZm9yIGVhY2ggY29ybmVyIG9mIHRoZSBzaGFwZS5cbiAgICogT3B0aW9uYWxseSwgY29ybmVycyBjYW4gYmUgcm91bmRlZCB1c2luZyBhIHF1YWRyYXRpYyBjdXJ2ZSBpbnN0ZWFkIG9mIGFuIGFyYywgcHJvdmlkaW5nIGEgZGlmZmVyZW50IGFlc3RoZXRpYy5cbiAgICogQHBhcmFtIHBvaW50cyAtIEFuIGFycmF5IG9mIGBSb3VuZGVkUG9pbnRgIHJlcHJlc2VudGluZyB0aGUgY29ybmVycyBvZiB0aGUgc2hhcGUgdG8gZHJhdy5cbiAgICogQSBtaW5pbXVtIG9mIDMgcG9pbnRzIGlzIHJlcXVpcmVkLlxuICAgKiBAcGFyYW0gcmFkaXVzIC0gVGhlIGRlZmF1bHQgcmFkaXVzIGZvciB0aGUgY29ybmVycy5cbiAgICogVGhpcyByYWRpdXMgaXMgYXBwbGllZCB0byBhbGwgY29ybmVycyB1bmxlc3Mgb3ZlcnJpZGRlbiBpbiBgcG9pbnRzYC5cbiAgICogQHBhcmFtIHVzZVF1YWRyYXRpYyAtIElmIHNldCB0byB0cnVlLCByb3VuZGVkIGNvcm5lcnMgYXJlIGRyYXduIHVzaW5nIGEgcXVhZHJhdGljQ3VydmVcbiAgICogIG1ldGhvZCBpbnN0ZWFkIG9mIGFuIGFyYyBtZXRob2QuIERlZmF1bHRzIHRvIGZhbHNlLlxuICAgKiBAcGFyYW0gc21vb3RobmVzcyAtIFNwZWNpZmllcyB0aGUgc21vb3RobmVzcyBvZiB0aGUgY3VydmUgd2hlbiBgdXNlUXVhZHJhdGljYCBpcyB0cnVlLlxuICAgKiBIaWdoZXIgdmFsdWVzIG1ha2UgdGhlIGN1cnZlIHNtb290aGVyLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIHJvdW5kU2hhcGUocG9pbnRzLCByYWRpdXMsIHVzZVF1YWRyYXRpYyA9IGZhbHNlLCBzbW9vdGhuZXNzKSB7XG4gICAgaWYgKHBvaW50cy5sZW5ndGggPCAzKSB7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgaWYgKHVzZVF1YWRyYXRpYykge1xuICAgICAgcm91bmRlZFNoYXBlUXVhZHJhdGljQ3VydmUodGhpcywgcG9pbnRzLCByYWRpdXMsIHNtb290aG5lc3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICByb3VuZGVkU2hhcGVBcmModGhpcywgcG9pbnRzLCByYWRpdXMpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5jbG9zZVBhdGgoKTtcbiAgfVxuICAvKipcbiAgICogRHJhdyBSZWN0YW5nbGUgd2l0aCBmaWxsZXQgY29ybmVycy4gVGhpcyBpcyBtdWNoIGxpa2Ugcm91bmRlZCByZWN0YW5nbGVcbiAgICogaG93ZXZlciBpdCBzdXBwb3J0IG5lZ2F0aXZlIG51bWJlcnMgYXMgd2VsbCBmb3IgdGhlIGNvcm5lciByYWRpdXMuXG4gICAqIEBwYXJhbSB4IC0gVXBwZXIgbGVmdCBjb3JuZXIgb2YgcmVjdFxuICAgKiBAcGFyYW0geSAtIFVwcGVyIHJpZ2h0IGNvcm5lciBvZiByZWN0XG4gICAqIEBwYXJhbSB3aWR0aCAtIFdpZHRoIG9mIHJlY3RcbiAgICogQHBhcmFtIGhlaWdodCAtIEhlaWdodCBvZiByZWN0XG4gICAqIEBwYXJhbSBmaWxsZXQgLSBhY2NlcHQgbmVnYXRpdmUgb3IgcG9zaXRpdmUgdmFsdWVzXG4gICAqL1xuICBmaWxsZXRSZWN0KHgsIHksIHdpZHRoLCBoZWlnaHQsIGZpbGxldCkge1xuICAgIGlmIChmaWxsZXQgPT09IDApIHtcbiAgICAgIHJldHVybiB0aGlzLnJlY3QoeCwgeSwgd2lkdGgsIGhlaWdodCk7XG4gICAgfVxuICAgIGNvbnN0IG1heEZpbGxldCA9IE1hdGgubWluKHdpZHRoLCBoZWlnaHQpIC8gMjtcbiAgICBjb25zdCBpbnNldCA9IE1hdGgubWluKG1heEZpbGxldCwgTWF0aC5tYXgoLW1heEZpbGxldCwgZmlsbGV0KSk7XG4gICAgY29uc3QgcmlnaHQgPSB4ICsgd2lkdGg7XG4gICAgY29uc3QgYm90dG9tID0geSArIGhlaWdodDtcbiAgICBjb25zdCBkaXIgPSBpbnNldCA8IDAgPyAtaW5zZXQgOiAwO1xuICAgIGNvbnN0IHNpemUgPSBNYXRoLmFicyhpbnNldCk7XG4gICAgcmV0dXJuIHRoaXMubW92ZVRvKHgsIHkgKyBzaXplKS5hcmNUbyh4ICsgZGlyLCB5ICsgZGlyLCB4ICsgc2l6ZSwgeSwgc2l6ZSkubGluZVRvKHJpZ2h0IC0gc2l6ZSwgeSkuYXJjVG8ocmlnaHQgLSBkaXIsIHkgKyBkaXIsIHJpZ2h0LCB5ICsgc2l6ZSwgc2l6ZSkubGluZVRvKHJpZ2h0LCBib3R0b20gLSBzaXplKS5hcmNUbyhyaWdodCAtIGRpciwgYm90dG9tIC0gZGlyLCB4ICsgd2lkdGggLSBzaXplLCBib3R0b20sIHNpemUpLmxpbmVUbyh4ICsgc2l6ZSwgYm90dG9tKS5hcmNUbyh4ICsgZGlyLCBib3R0b20gLSBkaXIsIHgsIGJvdHRvbSAtIHNpemUsIHNpemUpLmNsb3NlUGF0aCgpO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3IFJlY3RhbmdsZSB3aXRoIGNoYW1mZXIgY29ybmVycy4gVGhlc2UgYXJlIGFuZ2xlZCBjb3JuZXJzLlxuICAgKiBAcGFyYW0geCAtIFVwcGVyIGxlZnQgY29ybmVyIG9mIHJlY3RcbiAgICogQHBhcmFtIHkgLSBVcHBlciByaWdodCBjb3JuZXIgb2YgcmVjdFxuICAgKiBAcGFyYW0gd2lkdGggLSBXaWR0aCBvZiByZWN0XG4gICAqIEBwYXJhbSBoZWlnaHQgLSBIZWlnaHQgb2YgcmVjdFxuICAgKiBAcGFyYW0gY2hhbWZlciAtIG5vbi16ZXJvIHJlYWwgbnVtYmVyLCBzaXplIG9mIGNvcm5lciBjdXRvdXRcbiAgICogQHBhcmFtIHRyYW5zZm9ybVxuICAgKi9cbiAgY2hhbWZlclJlY3QoeCwgeSwgd2lkdGgsIGhlaWdodCwgY2hhbWZlciwgdHJhbnNmb3JtKSB7XG4gICAgaWYgKGNoYW1mZXIgPD0gMCkge1xuICAgICAgcmV0dXJuIHRoaXMucmVjdCh4LCB5LCB3aWR0aCwgaGVpZ2h0KTtcbiAgICB9XG4gICAgY29uc3QgaW5zZXQgPSBNYXRoLm1pbihjaGFtZmVyLCBNYXRoLm1pbih3aWR0aCwgaGVpZ2h0KSAvIDIpO1xuICAgIGNvbnN0IHJpZ2h0ID0geCArIHdpZHRoO1xuICAgIGNvbnN0IGJvdHRvbSA9IHkgKyBoZWlnaHQ7XG4gICAgY29uc3QgcG9pbnRzID0gW1xuICAgICAgeCArIGluc2V0LFxuICAgICAgeSxcbiAgICAgIHJpZ2h0IC0gaW5zZXQsXG4gICAgICB5LFxuICAgICAgcmlnaHQsXG4gICAgICB5ICsgaW5zZXQsXG4gICAgICByaWdodCxcbiAgICAgIGJvdHRvbSAtIGluc2V0LFxuICAgICAgcmlnaHQgLSBpbnNldCxcbiAgICAgIGJvdHRvbSxcbiAgICAgIHggKyBpbnNldCxcbiAgICAgIGJvdHRvbSxcbiAgICAgIHgsXG4gICAgICBib3R0b20gLSBpbnNldCxcbiAgICAgIHgsXG4gICAgICB5ICsgaW5zZXRcbiAgICBdO1xuICAgIGZvciAobGV0IGkgPSBwb2ludHMubGVuZ3RoIC0gMTsgaSA+PSAyOyBpIC09IDIpIHtcbiAgICAgIGlmIChwb2ludHNbaV0gPT09IHBvaW50c1tpIC0gMl0gJiYgcG9pbnRzW2kgLSAxXSA9PT0gcG9pbnRzW2kgLSAzXSkge1xuICAgICAgICBwb2ludHMuc3BsaWNlKGkgLSAxLCAyKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucG9seShwb2ludHMsIHRydWUsIHRyYW5zZm9ybSk7XG4gIH1cbiAgLyoqXG4gICAqIERyYXdzIGFuIGVsbGlwc2UgYXQgdGhlIHNwZWNpZmllZCBsb2NhdGlvbiBhbmQgd2l0aCB0aGUgZ2l2ZW4geCBhbmQgeSByYWRpaS5cbiAgICogQW4gb3B0aW9uYWwgdHJhbnNmb3JtYXRpb24gY2FuIGJlIGFwcGxpZWQsIGFsbG93aW5nIGZvciByb3RhdGlvbiwgc2NhbGluZywgYW5kIHRyYW5zbGF0aW9uLlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGNlbnRlciBvZiB0aGUgZWxsaXBzZS5cbiAgICogQHBhcmFtIHkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBjZW50ZXIgb2YgdGhlIGVsbGlwc2UuXG4gICAqIEBwYXJhbSByYWRpdXNYIC0gVGhlIGhvcml6b250YWwgcmFkaXVzIG9mIHRoZSBlbGxpcHNlLlxuICAgKiBAcGFyYW0gcmFkaXVzWSAtIFRoZSB2ZXJ0aWNhbCByYWRpdXMgb2YgdGhlIGVsbGlwc2UuXG4gICAqIEBwYXJhbSB0cmFuc2Zvcm0gLSBBbiBvcHRpb25hbCBgTWF0cml4YCBvYmplY3QgdG8gYXBwbHkgYSB0cmFuc2Zvcm1hdGlvbiB0byB0aGUgZWxsaXBzZS4gVGhpcyBjYW4gaW5jbHVkZSByb3RhdGlvbnMuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgZWxsaXBzZSh4LCB5LCByYWRpdXNYLCByYWRpdXNZLCB0cmFuc2Zvcm0pIHtcbiAgICB0aGlzLmRyYXdTaGFwZShuZXcgRWxsaXBzZSh4LCB5LCByYWRpdXNYLCByYWRpdXNZKSwgdHJhbnNmb3JtKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogRHJhd3MgYSByZWN0YW5nbGUgd2l0aCByb3VuZGVkIGNvcm5lcnMuXG4gICAqIFRoZSBjb3JuZXIgcmFkaXVzIGNhbiBiZSBzcGVjaWZpZWQgdG8gZGV0ZXJtaW5lIGhvdyByb3VuZGVkIHRoZSBjb3JuZXJzIHNob3VsZCBiZS5cbiAgICogQW4gb3B0aW9uYWwgdHJhbnNmb3JtYXRpb24gY2FuIGJlIGFwcGxpZWQsIHdoaWNoIGFsbG93cyBmb3Igcm90YXRpb24sIHNjYWxpbmcsIGFuZCB0cmFuc2xhdGlvbiBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIHRvcC1sZWZ0IGNvcm5lciBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIHRvcC1sZWZ0IGNvcm5lciBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcGFyYW0gdyAtIFRoZSB3aWR0aCBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcGFyYW0gaCAtIFRoZSBoZWlnaHQgb2YgdGhlIHJlY3RhbmdsZS5cbiAgICogQHBhcmFtIHJhZGl1cyAtIFRoZSByYWRpdXMgb2YgdGhlIHJlY3RhbmdsZSdzIGNvcm5lcnMuIElmIG5vdCBzcGVjaWZpZWQsIGNvcm5lcnMgd2lsbCBiZSBzaGFycC5cbiAgICogQHBhcmFtIHRyYW5zZm9ybSAtIEFuIG9wdGlvbmFsIGBNYXRyaXhgIG9iamVjdCB0byBhcHBseSBhIHRyYW5zZm9ybWF0aW9uIHRvIHRoZSByZWN0YW5nbGUuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgcm91bmRSZWN0KHgsIHksIHcsIGgsIHJhZGl1cywgdHJhbnNmb3JtKSB7XG4gICAgdGhpcy5kcmF3U2hhcGUobmV3IFJvdW5kZWRSZWN0YW5nbGUoeCwgeSwgdywgaCwgcmFkaXVzKSwgdHJhbnNmb3JtKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogRHJhd3MgYSBnaXZlbiBzaGFwZSBvbiB0aGUgY2FudmFzLlxuICAgKiBUaGlzIGlzIGEgZ2VuZXJpYyBtZXRob2QgdGhhdCBjYW4gZHJhdyBhbnkgdHlwZSBvZiBzaGFwZSBzcGVjaWZpZWQgYnkgdGhlIGBTaGFwZVByaW1pdGl2ZWAgcGFyYW1ldGVyLlxuICAgKiBBbiBvcHRpb25hbCB0cmFuc2Zvcm1hdGlvbiBtYXRyaXggY2FuIGJlIGFwcGxpZWQgdG8gdGhlIHNoYXBlLCBhbGxvd2luZyBmb3IgY29tcGxleCB0cmFuc2Zvcm1hdGlvbnMuXG4gICAqIEBwYXJhbSBzaGFwZSAtIFRoZSBzaGFwZSB0byBkcmF3LCBkZWZpbmVkIGFzIGEgYFNoYXBlUHJpbWl0aXZlYCBvYmplY3QuXG4gICAqIEBwYXJhbSBtYXRyaXggLSBBbiBvcHRpb25hbCBgTWF0cml4YCBmb3IgdHJhbnNmb3JtaW5nIHRoZSBzaGFwZS4gVGhpcyBjYW4gaW5jbHVkZSByb3RhdGlvbnMsXG4gICAqIHNjYWxpbmcsIGFuZCB0cmFuc2xhdGlvbnMuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgZHJhd1NoYXBlKHNoYXBlLCBtYXRyaXgpIHtcbiAgICB0aGlzLmVuZFBvbHkoKTtcbiAgICB0aGlzLnNoYXBlUHJpbWl0aXZlcy5wdXNoKHsgc2hhcGUsIHRyYW5zZm9ybTogbWF0cml4IH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBTdGFydHMgYSBuZXcgcG9seWdvbiBwYXRoIGZyb20gdGhlIHNwZWNpZmllZCBzdGFydGluZyBwb2ludC5cbiAgICogVGhpcyBtZXRob2QgaW5pdGlhbGl6ZXMgYSBuZXcgcG9seWdvbiBvciBlbmRzIHRoZSBjdXJyZW50IG9uZSBpZiBpdCBleGlzdHMuXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgc3RhcnRpbmcgcG9pbnQgb2YgdGhlIG5ldyBwb2x5Z29uLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIHN0YXJ0aW5nIHBvaW50IG9mIHRoZSBuZXcgcG9seWdvbi5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICBzdGFydFBvbHkoeCwgeSkge1xuICAgIGxldCBjdXJyZW50UG9seSA9IHRoaXMuX2N1cnJlbnRQb2x5O1xuICAgIGlmIChjdXJyZW50UG9seSkge1xuICAgICAgdGhpcy5lbmRQb2x5KCk7XG4gICAgfVxuICAgIGN1cnJlbnRQb2x5ID0gbmV3IFBvbHlnb24oKTtcbiAgICBjdXJyZW50UG9seS5wb2ludHMucHVzaCh4LCB5KTtcbiAgICB0aGlzLl9jdXJyZW50UG9seSA9IGN1cnJlbnRQb2x5O1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBFbmRzIHRoZSBjdXJyZW50IHBvbHlnb24gcGF0aC4gSWYgYGNsb3NlUGF0aGAgaXMgc2V0IHRvIHRydWUsXG4gICAqIHRoZSBwYXRoIGlzIGNsb3NlZCBieSBjb25uZWN0aW5nIHRoZSBsYXN0IHBvaW50IHRvIHRoZSBmaXJzdCBvbmUuXG4gICAqIFRoaXMgbWV0aG9kIGZpbmFsaXplcyB0aGUgY3VycmVudCBwb2x5Z29uIGFuZCBwcmVwYXJlcyBpdCBmb3IgZHJhd2luZyBvciBhZGRpbmcgdG8gdGhlIHNoYXBlIHByaW1pdGl2ZXMuXG4gICAqIEBwYXJhbSBjbG9zZVBhdGggLSBBIGJvb2xlYW4gaW5kaWNhdGluZyB3aGV0aGVyIHRvIGNsb3NlIHRoZSBwb2x5Z29uIGJ5IGNvbm5lY3RpbmcgdGhlIGxhc3QgcG9pbnRcbiAgICogIGJhY2sgdG8gdGhlIHN0YXJ0aW5nIHBvaW50LiBGYWxzZSBieSBkZWZhdWx0LlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIGVuZFBvbHkoY2xvc2VQYXRoID0gZmFsc2UpIHtcbiAgICBjb25zdCBzaGFwZSA9IHRoaXMuX2N1cnJlbnRQb2x5O1xuICAgIGlmIChzaGFwZSAmJiBzaGFwZS5wb2ludHMubGVuZ3RoID4gMikge1xuICAgICAgc2hhcGUuY2xvc2VQYXRoID0gY2xvc2VQYXRoO1xuICAgICAgdGhpcy5zaGFwZVByaW1pdGl2ZXMucHVzaCh7IHNoYXBlIH0pO1xuICAgIH1cbiAgICB0aGlzLl9jdXJyZW50UG9seSA9IG51bGw7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgX2Vuc3VyZVBvbHkoc3RhcnQgPSB0cnVlKSB7XG4gICAgaWYgKHRoaXMuX2N1cnJlbnRQb2x5KSByZXR1cm47XG4gICAgdGhpcy5fY3VycmVudFBvbHkgPSBuZXcgUG9seWdvbigpO1xuICAgIGlmIChzdGFydCkge1xuICAgICAgY29uc3QgbGFzdFNoYXBlID0gdGhpcy5zaGFwZVByaW1pdGl2ZXNbdGhpcy5zaGFwZVByaW1pdGl2ZXMubGVuZ3RoIC0gMV07XG4gICAgICBpZiAobGFzdFNoYXBlKSB7XG4gICAgICAgIGxldCBseCA9IGxhc3RTaGFwZS5zaGFwZS54O1xuICAgICAgICBsZXQgbHkgPSBsYXN0U2hhcGUuc2hhcGUueTtcbiAgICAgICAgaWYgKGxhc3RTaGFwZS50cmFuc2Zvcm0gJiYgIWxhc3RTaGFwZS50cmFuc2Zvcm0uaXNJZGVudGl0eSgpKSB7XG4gICAgICAgICAgY29uc3QgdCA9IGxhc3RTaGFwZS50cmFuc2Zvcm07XG4gICAgICAgICAgY29uc3QgdGVtcFggPSBseDtcbiAgICAgICAgICBseCA9IHQuYSAqIGx4ICsgdC5jICogbHkgKyB0LnR4O1xuICAgICAgICAgIGx5ID0gdC5iICogdGVtcFggKyB0LmQgKiBseSArIHQudHk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fY3VycmVudFBvbHkucG9pbnRzLnB1c2gobHgsIGx5KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX2N1cnJlbnRQb2x5LnBvaW50cy5wdXNoKDAsIDApO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICAvKiogQnVpbGRzIHRoZSBwYXRoLiAqL1xuICBidWlsZFBhdGgoKSB7XG4gICAgY29uc3QgcGF0aCA9IHRoaXMuX2dyYXBoaWNzUGF0aDJEO1xuICAgIHRoaXMuc2hhcGVQcmltaXRpdmVzLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5fY3VycmVudFBvbHkgPSBudWxsO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcGF0aC5pbnN0cnVjdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGluc3RydWN0aW9uID0gcGF0aC5pbnN0cnVjdGlvbnNbaV07XG4gICAgICB0aGlzW2luc3RydWN0aW9uLmFjdGlvbl0oLi4uaW5zdHJ1Y3Rpb24uZGF0YSk7XG4gICAgfVxuICAgIHRoaXMuZmluaXNoKCk7XG4gIH1cbiAgLyoqIEdldHMgdGhlIGJvdW5kcyBvZiB0aGUgcGF0aC4gKi9cbiAgZ2V0IGJvdW5kcygpIHtcbiAgICBjb25zdCBib3VuZHMgPSB0aGlzLl9ib3VuZHM7XG4gICAgYm91bmRzLmNsZWFyKCk7XG4gICAgY29uc3Qgc2hhcGVQcmltaXRpdmVzID0gdGhpcy5zaGFwZVByaW1pdGl2ZXM7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaGFwZVByaW1pdGl2ZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IHNoYXBlUHJpbWl0aXZlID0gc2hhcGVQcmltaXRpdmVzW2ldO1xuICAgICAgY29uc3QgYm91bmRzUmVjdCA9IHNoYXBlUHJpbWl0aXZlLnNoYXBlLmdldEJvdW5kcyh0ZW1wUmVjdGFuZ2xlKTtcbiAgICAgIGlmIChzaGFwZVByaW1pdGl2ZS50cmFuc2Zvcm0pIHtcbiAgICAgICAgYm91bmRzLmFkZFJlY3QoYm91bmRzUmVjdCwgc2hhcGVQcmltaXRpdmUudHJhbnNmb3JtKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGJvdW5kcy5hZGRSZWN0KGJvdW5kc1JlY3QpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gYm91bmRzO1xuICB9XG59XG5cbmV4cG9ydCB7IFNoYXBlUGF0aCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9U2hhcGVQYXRoLm1qcy5tYXBcbiIsImltcG9ydCB7IFBvaW50IH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvcG9pbnQvUG9pbnQubWpzJztcbmltcG9ydCB7IHVpZCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGEvdWlkLm1qcyc7XG5pbXBvcnQgeyB3YXJuIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy93YXJuLm1qcyc7XG5pbXBvcnQgeyBwYXJzZVNWR1BhdGggfSBmcm9tICcuLi9zdmcvcGFyc2VTVkdQYXRoLm1qcyc7XG5pbXBvcnQgeyBTaGFwZVBhdGggfSBmcm9tICcuL1NoYXBlUGF0aC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIEdyYXBoaWNzUGF0aCB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgYEdyYXBoaWNzUGF0aGAgaW5zdGFuY2Ugb3B0aW9uYWxseSBmcm9tIGFuIFNWRyBwYXRoIHN0cmluZyBvciBhbiBhcnJheSBvZiBgUGF0aEluc3RydWN0aW9uYC5cbiAgICogQHBhcmFtIGluc3RydWN0aW9ucyAtIEFuIFNWRyBwYXRoIHN0cmluZyBvciBhbiBhcnJheSBvZiBgUGF0aEluc3RydWN0aW9uYCBvYmplY3RzLlxuICAgKiBAcGFyYW0gc2lnbmVkXG4gICAqL1xuICBjb25zdHJ1Y3RvcihpbnN0cnVjdGlvbnMsIHNpZ25lZCA9IGZhbHNlKSB7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMgPSBbXTtcbiAgICAvKiogdW5pcXVlIGlkIGZvciB0aGlzIGdyYXBoaWNzIHBhdGggKi9cbiAgICB0aGlzLnVpZCA9IHVpZChcImdyYXBoaWNzUGF0aFwiKTtcbiAgICB0aGlzLl9kaXJ0eSA9IHRydWU7XG4gICAgdGhpcy5jaGVja0ZvckhvbGVzID0gc2lnbmVkO1xuICAgIGlmICh0eXBlb2YgaW5zdHJ1Y3Rpb25zID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBwYXJzZVNWR1BhdGgoaW5zdHJ1Y3Rpb25zLCB0aGlzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5pbnN0cnVjdGlvbnMgPSBpbnN0cnVjdGlvbnM/LnNsaWNlKCkgPz8gW107XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBQcm92aWRlcyBhY2Nlc3MgdG8gdGhlIGludGVybmFsIHNoYXBlIHBhdGgsIGVuc3VyaW5nIGl0IGlzIHVwLXRvLWRhdGUgd2l0aCB0aGUgY3VycmVudCBpbnN0cnVjdGlvbnMuXG4gICAqIEByZXR1cm5zIFRoZSBgU2hhcGVQYXRoYCBpbnN0YW5jZSBhc3NvY2lhdGVkIHdpdGggdGhpcyBgR3JhcGhpY3NQYXRoYC5cbiAgICovXG4gIGdldCBzaGFwZVBhdGgoKSB7XG4gICAgaWYgKCF0aGlzLl9zaGFwZVBhdGgpIHtcbiAgICAgIHRoaXMuX3NoYXBlUGF0aCA9IG5ldyBTaGFwZVBhdGgodGhpcyk7XG4gICAgfVxuICAgIGlmICh0aGlzLl9kaXJ0eSkge1xuICAgICAgdGhpcy5fZGlydHkgPSBmYWxzZTtcbiAgICAgIHRoaXMuX3NoYXBlUGF0aC5idWlsZFBhdGgoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX3NoYXBlUGF0aDtcbiAgfVxuICAvKipcbiAgICogQWRkcyBhbm90aGVyIGBHcmFwaGljc1BhdGhgIHRvIHRoaXMgcGF0aCwgb3B0aW9uYWxseSBhcHBseWluZyBhIHRyYW5zZm9ybWF0aW9uLlxuICAgKiBAcGFyYW0gcGF0aCAtIFRoZSBgR3JhcGhpY3NQYXRoYCB0byBhZGQuXG4gICAqIEBwYXJhbSB0cmFuc2Zvcm0gLSBBbiBvcHRpb25hbCB0cmFuc2Zvcm1hdGlvbiB0byBhcHBseSB0byB0aGUgYWRkZWQgcGF0aC5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICBhZGRQYXRoKHBhdGgsIHRyYW5zZm9ybSkge1xuICAgIHBhdGggPSBwYXRoLmNsb25lKCk7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMucHVzaCh7IGFjdGlvbjogXCJhZGRQYXRoXCIsIGRhdGE6IFtwYXRoLCB0cmFuc2Zvcm1dIH0pO1xuICAgIHRoaXMuX2RpcnR5ID0gdHJ1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBhcmMoLi4uYXJncykge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwiYXJjXCIsIGRhdGE6IGFyZ3MgfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIGFyY1RvKC4uLmFyZ3MpIHtcbiAgICB0aGlzLmluc3RydWN0aW9ucy5wdXNoKHsgYWN0aW9uOiBcImFyY1RvXCIsIGRhdGE6IGFyZ3MgfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIGFyY1RvU3ZnKC4uLmFyZ3MpIHtcbiAgICB0aGlzLmluc3RydWN0aW9ucy5wdXNoKHsgYWN0aW9uOiBcImFyY1RvU3ZnXCIsIGRhdGE6IGFyZ3MgfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIGJlemllckN1cnZlVG8oLi4uYXJncykge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwiYmV6aWVyQ3VydmVUb1wiLCBkYXRhOiBhcmdzIH0pO1xuICAgIHRoaXMuX2RpcnR5ID0gdHJ1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQWRkcyBhIGN1YmljIEJlemllciBjdXJ2ZSB0byB0aGUgcGF0aC5cbiAgICogSXQgcmVxdWlyZXMgdHdvIHBvaW50czogdGhlIHNlY29uZCBjb250cm9sIHBvaW50IGFuZCB0aGUgZW5kIHBvaW50LiBUaGUgZmlyc3QgY29udHJvbCBwb2ludCBpcyBhc3N1bWVkIHRvIGJlXG4gICAqIFRoZSBzdGFydGluZyBwb2ludCBpcyB0aGUgbGFzdCBwb2ludCBpbiB0aGUgY3VycmVudCBwYXRoLlxuICAgKiBAcGFyYW0gY3AyeCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIHNlY29uZCBjb250cm9sIHBvaW50LlxuICAgKiBAcGFyYW0gY3AyeSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIHNlY29uZCBjb250cm9sIHBvaW50LlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGVuZCBwb2ludC5cbiAgICogQHBhcmFtIHkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBlbmQgcG9pbnQuXG4gICAqIEBwYXJhbSBzbW9vdGhuZXNzIC0gT3B0aW9uYWwgcGFyYW1ldGVyIHRvIGFkanVzdCB0aGUgc21vb3RobmVzcyBvZiB0aGUgY3VydmUuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgYmV6aWVyQ3VydmVUb1Nob3J0KGNwMngsIGNwMnksIHgsIHksIHNtb290aG5lc3MpIHtcbiAgICBjb25zdCBsYXN0ID0gdGhpcy5pbnN0cnVjdGlvbnNbdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoIC0gMV07XG4gICAgY29uc3QgbGFzdFBvaW50ID0gdGhpcy5nZXRMYXN0UG9pbnQoUG9pbnQuc2hhcmVkKTtcbiAgICBsZXQgY3AxeCA9IDA7XG4gICAgbGV0IGNwMXkgPSAwO1xuICAgIGlmICghbGFzdCB8fCBsYXN0LmFjdGlvbiAhPT0gXCJiZXppZXJDdXJ2ZVRvXCIpIHtcbiAgICAgIGNwMXggPSBsYXN0UG9pbnQueDtcbiAgICAgIGNwMXkgPSBsYXN0UG9pbnQueTtcbiAgICB9IGVsc2Uge1xuICAgICAgY3AxeCA9IGxhc3QuZGF0YVsyXTtcbiAgICAgIGNwMXkgPSBsYXN0LmRhdGFbM107XG4gICAgICBjb25zdCBjdXJyZW50WCA9IGxhc3RQb2ludC54O1xuICAgICAgY29uc3QgY3VycmVudFkgPSBsYXN0UG9pbnQueTtcbiAgICAgIGNwMXggPSBjdXJyZW50WCArIChjdXJyZW50WCAtIGNwMXgpO1xuICAgICAgY3AxeSA9IGN1cnJlbnRZICsgKGN1cnJlbnRZIC0gY3AxeSk7XG4gICAgfVxuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwiYmV6aWVyQ3VydmVUb1wiLCBkYXRhOiBbY3AxeCwgY3AxeSwgY3AyeCwgY3AyeSwgeCwgeSwgc21vb3RobmVzc10gfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBDbG9zZXMgdGhlIGN1cnJlbnQgcGF0aCBieSBkcmF3aW5nIGEgc3RyYWlnaHQgbGluZSBiYWNrIHRvIHRoZSBzdGFydC5cbiAgICogSWYgdGhlIHNoYXBlIGlzIGFscmVhZHkgY2xvc2VkIG9yIHRoZXJlIGFyZSBubyBwb2ludHMgaW4gdGhlIHBhdGgsIHRoaXMgbWV0aG9kIGRvZXMgbm90aGluZy5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICBjbG9zZVBhdGgoKSB7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMucHVzaCh7IGFjdGlvbjogXCJjbG9zZVBhdGhcIiwgZGF0YTogW10gfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIGVsbGlwc2UoLi4uYXJncykge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwiZWxsaXBzZVwiLCBkYXRhOiBhcmdzIH0pO1xuICAgIHRoaXMuX2RpcnR5ID0gdHJ1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBsaW5lVG8oLi4uYXJncykge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwibGluZVRvXCIsIGRhdGE6IGFyZ3MgfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIG1vdmVUbyguLi5hcmdzKSB7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMucHVzaCh7IGFjdGlvbjogXCJtb3ZlVG9cIiwgZGF0YTogYXJncyB9KTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBxdWFkcmF0aWNDdXJ2ZVRvKC4uLmFyZ3MpIHtcbiAgICB0aGlzLmluc3RydWN0aW9ucy5wdXNoKHsgYWN0aW9uOiBcInF1YWRyYXRpY0N1cnZlVG9cIiwgZGF0YTogYXJncyB9KTtcbiAgICB0aGlzLl9kaXJ0eSA9IHRydWU7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYSBxdWFkcmF0aWMgY3VydmUgdG8gdGhlIHBhdGguIEl0IHVzZXMgdGhlIHByZXZpb3VzIHBvaW50IGFzIHRoZSBjb250cm9sIHBvaW50LlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGVuZCBwb2ludC5cbiAgICogQHBhcmFtIHkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBlbmQgcG9pbnQuXG4gICAqIEBwYXJhbSBzbW9vdGhuZXNzIC0gT3B0aW9uYWwgcGFyYW1ldGVyIHRvIGFkanVzdCB0aGUgc21vb3RobmVzcyBvZiB0aGUgY3VydmUuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgcXVhZHJhdGljQ3VydmVUb1Nob3J0KHgsIHksIHNtb290aG5lc3MpIHtcbiAgICBjb25zdCBsYXN0ID0gdGhpcy5pbnN0cnVjdGlvbnNbdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoIC0gMV07XG4gICAgY29uc3QgbGFzdFBvaW50ID0gdGhpcy5nZXRMYXN0UG9pbnQoUG9pbnQuc2hhcmVkKTtcbiAgICBsZXQgY3B4MSA9IDA7XG4gICAgbGV0IGNweTEgPSAwO1xuICAgIGlmICghbGFzdCB8fCBsYXN0LmFjdGlvbiAhPT0gXCJxdWFkcmF0aWNDdXJ2ZVRvXCIpIHtcbiAgICAgIGNweDEgPSBsYXN0UG9pbnQueDtcbiAgICAgIGNweTEgPSBsYXN0UG9pbnQueTtcbiAgICB9IGVsc2Uge1xuICAgICAgY3B4MSA9IGxhc3QuZGF0YVswXTtcbiAgICAgIGNweTEgPSBsYXN0LmRhdGFbMV07XG4gICAgICBjb25zdCBjdXJyZW50WCA9IGxhc3RQb2ludC54O1xuICAgICAgY29uc3QgY3VycmVudFkgPSBsYXN0UG9pbnQueTtcbiAgICAgIGNweDEgPSBjdXJyZW50WCArIChjdXJyZW50WCAtIGNweDEpO1xuICAgICAgY3B5MSA9IGN1cnJlbnRZICsgKGN1cnJlbnRZIC0gY3B5MSk7XG4gICAgfVxuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwicXVhZHJhdGljQ3VydmVUb1wiLCBkYXRhOiBbY3B4MSwgY3B5MSwgeCwgeSwgc21vb3RobmVzc10gfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIHJlY3RhbmdsZSBzaGFwZS4gVGhpcyBtZXRob2QgYWRkcyBhIG5ldyByZWN0YW5nbGUgcGF0aCB0byB0aGUgY3VycmVudCBkcmF3aW5nLlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIHRvcC1sZWZ0IGNvcm5lciBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIHRvcC1sZWZ0IGNvcm5lciBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcGFyYW0gdyAtIFRoZSB3aWR0aCBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcGFyYW0gaCAtIFRoZSBoZWlnaHQgb2YgdGhlIHJlY3RhbmdsZS5cbiAgICogQHBhcmFtIHRyYW5zZm9ybSAtIEFuIG9wdGlvbmFsIGBNYXRyaXhgIG9iamVjdCB0byBhcHBseSBhIHRyYW5zZm9ybWF0aW9uIHRvIHRoZSByZWN0YW5nbGUuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgcmVjdCh4LCB5LCB3LCBoLCB0cmFuc2Zvcm0pIHtcbiAgICB0aGlzLmluc3RydWN0aW9ucy5wdXNoKHsgYWN0aW9uOiBcInJlY3RcIiwgZGF0YTogW3gsIHksIHcsIGgsIHRyYW5zZm9ybV0gfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIGNpcmNsZSBzaGFwZS4gVGhpcyBtZXRob2QgYWRkcyBhIG5ldyBjaXJjbGUgcGF0aCB0byB0aGUgY3VycmVudCBkcmF3aW5nLlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGNlbnRlciBvZiB0aGUgY2lyY2xlLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGNlbnRlciBvZiB0aGUgY2lyY2xlLlxuICAgKiBAcGFyYW0gcmFkaXVzIC0gVGhlIHJhZGl1cyBvZiB0aGUgY2lyY2xlLlxuICAgKiBAcGFyYW0gdHJhbnNmb3JtIC0gQW4gb3B0aW9uYWwgYE1hdHJpeGAgb2JqZWN0IHRvIGFwcGx5IGEgdHJhbnNmb3JtYXRpb24gdG8gdGhlIGNpcmNsZS5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICBjaXJjbGUoeCwgeSwgcmFkaXVzLCB0cmFuc2Zvcm0pIHtcbiAgICB0aGlzLmluc3RydWN0aW9ucy5wdXNoKHsgYWN0aW9uOiBcImNpcmNsZVwiLCBkYXRhOiBbeCwgeSwgcmFkaXVzLCB0cmFuc2Zvcm1dIH0pO1xuICAgIHRoaXMuX2RpcnR5ID0gdHJ1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICByb3VuZFJlY3QoLi4uYXJncykge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwicm91bmRSZWN0XCIsIGRhdGE6IGFyZ3MgfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIHBvbHkoLi4uYXJncykge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwicG9seVwiLCBkYXRhOiBhcmdzIH0pO1xuICAgIHRoaXMuX2RpcnR5ID0gdHJ1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICByZWd1bGFyUG9seSguLi5hcmdzKSB7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMucHVzaCh7IGFjdGlvbjogXCJyZWd1bGFyUG9seVwiLCBkYXRhOiBhcmdzIH0pO1xuICAgIHRoaXMuX2RpcnR5ID0gdHJ1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICByb3VuZFBvbHkoLi4uYXJncykge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwicm91bmRQb2x5XCIsIGRhdGE6IGFyZ3MgfSk7XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIHJvdW5kU2hhcGUoLi4uYXJncykge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwicm91bmRTaGFwZVwiLCBkYXRhOiBhcmdzIH0pO1xuICAgIHRoaXMuX2RpcnR5ID0gdHJ1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBmaWxsZXRSZWN0KC4uLmFyZ3MpIHtcbiAgICB0aGlzLmluc3RydWN0aW9ucy5wdXNoKHsgYWN0aW9uOiBcImZpbGxldFJlY3RcIiwgZGF0YTogYXJncyB9KTtcbiAgICB0aGlzLl9kaXJ0eSA9IHRydWU7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgY2hhbWZlclJlY3QoLi4uYXJncykge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IFwiY2hhbWZlclJlY3RcIiwgZGF0YTogYXJncyB9KTtcbiAgICB0aGlzLl9kaXJ0eSA9IHRydWU7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIERyYXdzIGEgc3RhciBzaGFwZSBjZW50ZXJlZCBhdCBhIHNwZWNpZmllZCBsb2NhdGlvbi4gVGhpcyBtZXRob2QgYWxsb3dzIGZvciB0aGUgY3JlYXRpb25cbiAgICogIG9mIHN0YXJzIHdpdGggYSB2YXJpYWJsZSBudW1iZXIgb2YgcG9pbnRzLCBvdXRlciByYWRpdXMsIG9wdGlvbmFsIGlubmVyIHJhZGl1cywgYW5kIHJvdGF0aW9uLlxuICAgKiBUaGUgc3RhciBpcyBkcmF3biBhcyBhIGNsb3NlZCBwb2x5Z29uIHdpdGggYWx0ZXJuYXRpbmcgb3V0ZXIgYW5kIGlubmVyIHZlcnRpY2VzIHRvIGNyZWF0ZSB0aGUgc3RhcidzIHBvaW50cy5cbiAgICogQW4gb3B0aW9uYWwgdHJhbnNmb3JtYXRpb24gY2FuIGJlIGFwcGxpZWQgdG8gc2NhbGUsIHJvdGF0ZSwgb3IgdHJhbnNsYXRlIHRoZSBzdGFyIGFzIG5lZWRlZC5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBjZW50ZXIgb2YgdGhlIHN0YXIuXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgY2VudGVyIG9mIHRoZSBzdGFyLlxuICAgKiBAcGFyYW0gcG9pbnRzIC0gVGhlIG51bWJlciBvZiBwb2ludHMgb2YgdGhlIHN0YXIuXG4gICAqIEBwYXJhbSByYWRpdXMgLSBUaGUgb3V0ZXIgcmFkaXVzIG9mIHRoZSBzdGFyIChkaXN0YW5jZSBmcm9tIHRoZSBjZW50ZXIgdG8gdGhlIG91dGVyIHBvaW50cykuXG4gICAqIEBwYXJhbSBpbm5lclJhZGl1cyAtIE9wdGlvbmFsLiBUaGUgaW5uZXIgcmFkaXVzIG9mIHRoZSBzdGFyXG4gICAqIChkaXN0YW5jZSBmcm9tIHRoZSBjZW50ZXIgdG8gdGhlIGlubmVyIHBvaW50cyBiZXR3ZWVuIHRoZSBvdXRlciBwb2ludHMpLlxuICAgKiBJZiBub3QgcHJvdmlkZWQsIGRlZmF1bHRzIHRvIGhhbGYgb2YgdGhlIGByYWRpdXNgLlxuICAgKiBAcGFyYW0gcm90YXRpb24gLSBPcHRpb25hbC4gVGhlIHJvdGF0aW9uIG9mIHRoZSBzdGFyIGluIHJhZGlhbnMsIHdoZXJlIDAgaXMgYWxpZ25lZCB3aXRoIHRoZSB5LWF4aXMuXG4gICAqIERlZmF1bHRzIHRvIDAsIG1lYW5pbmcgb25lIHBvaW50IGlzIGRpcmVjdGx5IHVwd2FyZC5cbiAgICogQHBhcmFtIHRyYW5zZm9ybSAtIEFuIG9wdGlvbmFsIGBNYXRyaXhgIG9iamVjdCB0byBhcHBseSBhIHRyYW5zZm9ybWF0aW9uIHRvIHRoZSBzdGFyLlxuICAgKiBUaGlzIGNhbiBpbmNsdWRlIHJvdGF0aW9ucywgc2NhbGluZywgYW5kIHRyYW5zbGF0aW9ucy5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcgZnVydGhlciBkcmF3aW5nIGNvbW1hbmRzLlxuICAgKi9cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG1heC1sZW5cbiAgc3Rhcih4LCB5LCBwb2ludHMsIHJhZGl1cywgaW5uZXJSYWRpdXMsIHJvdGF0aW9uLCB0cmFuc2Zvcm0pIHtcbiAgICBpbm5lclJhZGl1cyB8fCAoaW5uZXJSYWRpdXMgPSByYWRpdXMgLyAyKTtcbiAgICBjb25zdCBzdGFydEFuZ2xlID0gLTEgKiBNYXRoLlBJIC8gMiArIHJvdGF0aW9uO1xuICAgIGNvbnN0IGxlbiA9IHBvaW50cyAqIDI7XG4gICAgY29uc3QgZGVsdGEgPSBNYXRoLlBJICogMiAvIGxlbjtcbiAgICBjb25zdCBwb2x5Z29uID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgY29uc3QgciA9IGkgJSAyID8gaW5uZXJSYWRpdXMgOiByYWRpdXM7XG4gICAgICBjb25zdCBhbmdsZSA9IGkgKiBkZWx0YSArIHN0YXJ0QW5nbGU7XG4gICAgICBwb2x5Z29uLnB1c2goXG4gICAgICAgIHggKyByICogTWF0aC5jb3MoYW5nbGUpLFxuICAgICAgICB5ICsgciAqIE1hdGguc2luKGFuZ2xlKVxuICAgICAgKTtcbiAgICB9XG4gICAgdGhpcy5wb2x5KHBvbHlnb24sIHRydWUsIHRyYW5zZm9ybSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBjb3B5IG9mIHRoZSBjdXJyZW50IGBHcmFwaGljc1BhdGhgIGluc3RhbmNlLiBUaGlzIG1ldGhvZCBzdXBwb3J0cyBib3RoIHNoYWxsb3cgYW5kIGRlZXAgY2xvbmluZy5cbiAgICogQSBzaGFsbG93IGNsb25lIGNvcGllcyB0aGUgcmVmZXJlbmNlIG9mIHRoZSBpbnN0cnVjdGlvbnMgYXJyYXksIHdoaWxlIGEgZGVlcCBjbG9uZSBjcmVhdGVzIGEgbmV3IGFycmF5IGFuZFxuICAgKiBjb3BpZXMgZWFjaCBpbnN0cnVjdGlvbiBpbmRpdmlkdWFsbHksIGVuc3VyaW5nIHRoYXQgbW9kaWZpY2F0aW9ucyB0byB0aGUgaW5zdHJ1Y3Rpb25zIG9mIHRoZSBjbG9uZWQgYEdyYXBoaWNzUGF0aGBcbiAgICogZG8gbm90IGFmZmVjdCB0aGUgb3JpZ2luYWwgYEdyYXBoaWNzUGF0aGAgYW5kIHZpY2UgdmVyc2EuXG4gICAqIEBwYXJhbSBkZWVwIC0gQSBib29sZWFuIGZsYWcgaW5kaWNhdGluZyB3aGV0aGVyIHRoZSBjbG9uZSBzaG91bGQgYmUgZGVlcC5cbiAgICogQHJldHVybnMgQSBuZXcgYEdyYXBoaWNzUGF0aGAgaW5zdGFuY2UgdGhhdCBpcyBhIGNsb25lIG9mIHRoZSBjdXJyZW50IGluc3RhbmNlLlxuICAgKi9cbiAgY2xvbmUoZGVlcCA9IGZhbHNlKSB7XG4gICAgY29uc3QgbmV3R3JhcGhpY3NQYXRoMkQgPSBuZXcgR3JhcGhpY3NQYXRoKCk7XG4gICAgbmV3R3JhcGhpY3NQYXRoMkQuY2hlY2tGb3JIb2xlcyA9IHRoaXMuY2hlY2tGb3JIb2xlcztcbiAgICBpZiAoIWRlZXApIHtcbiAgICAgIG5ld0dyYXBoaWNzUGF0aDJELmluc3RydWN0aW9ucyA9IHRoaXMuaW5zdHJ1Y3Rpb25zLnNsaWNlKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgaW5zdHJ1Y3Rpb24gPSB0aGlzLmluc3RydWN0aW9uc1tpXTtcbiAgICAgICAgbmV3R3JhcGhpY3NQYXRoMkQuaW5zdHJ1Y3Rpb25zLnB1c2goeyBhY3Rpb246IGluc3RydWN0aW9uLmFjdGlvbiwgZGF0YTogaW5zdHJ1Y3Rpb24uZGF0YS5zbGljZSgpIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbmV3R3JhcGhpY3NQYXRoMkQ7XG4gIH1cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoID0gMDtcbiAgICB0aGlzLl9kaXJ0eSA9IHRydWU7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEFwcGxpZXMgYSB0cmFuc2Zvcm1hdGlvbiBtYXRyaXggdG8gYWxsIGRyYXdpbmcgaW5zdHJ1Y3Rpb25zIHdpdGhpbiB0aGUgYEdyYXBoaWNzUGF0aGAuXG4gICAqIFRoaXMgbWV0aG9kIGVuYWJsZXMgdGhlIG1vZGlmaWNhdGlvbiBvZiB0aGUgcGF0aCdzIGdlb21ldHJ5IGFjY29yZGluZyB0byB0aGUgcHJvdmlkZWRcbiAgICogdHJhbnNmb3JtYXRpb24gbWF0cml4LCB3aGljaCBjYW4gaW5jbHVkZSB0cmFuc2xhdGlvbnMsIHJvdGF0aW9ucywgc2NhbGluZywgYW5kIHNrZXdpbmcuXG4gICAqXG4gICAqIEVhY2ggZHJhd2luZyBpbnN0cnVjdGlvbiBpbiB0aGUgcGF0aCBpcyB1cGRhdGVkIHRvIHJlZmxlY3QgdGhlIHRyYW5zZm9ybWF0aW9uLFxuICAgKiBlbnN1cmluZyB0aGUgdmlzdWFsIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBwYXRoIGlzIGNvbnNpc3RlbnQgd2l0aCB0aGUgYXBwbGllZCBtYXRyaXguXG4gICAqXG4gICAqIE5vdGU6IFRoZSB0cmFuc2Zvcm1hdGlvbiBpcyBhcHBsaWVkIGRpcmVjdGx5IHRvIHRoZSBjb29yZGluYXRlcyBhbmQgY29udHJvbCBwb2ludHMgb2YgdGhlIGRyYXdpbmcgaW5zdHJ1Y3Rpb25zLFxuICAgKiBub3QgdG8gdGhlIHBhdGggYXMgYSB3aG9sZS4gVGhpcyBtZWFucyB0aGUgdHJhbnNmb3JtYXRpb24ncyBlZmZlY3RzIGFyZSBiYWtlZCBpbnRvIHRoZSBpbmRpdmlkdWFsIGluc3RydWN0aW9ucyxcbiAgICogYWxsb3dpbmcgZm9yIGZpbmUtZ3JhaW5lZCBjb250cm9sIG92ZXIgdGhlIHBhdGgncyBhcHBlYXJhbmNlLlxuICAgKiBAcGFyYW0gbWF0cml4IC0gQSBgTWF0cml4YCBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSB0cmFuc2Zvcm1hdGlvbiB0byBhcHBseS5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcgZnVydGhlciBvcGVyYXRpb25zLlxuICAgKi9cbiAgdHJhbnNmb3JtKG1hdHJpeCkge1xuICAgIGlmIChtYXRyaXguaXNJZGVudGl0eSgpKSByZXR1cm4gdGhpcztcbiAgICBjb25zdCBhID0gbWF0cml4LmE7XG4gICAgY29uc3QgYiA9IG1hdHJpeC5iO1xuICAgIGNvbnN0IGMgPSBtYXRyaXguYztcbiAgICBjb25zdCBkID0gbWF0cml4LmQ7XG4gICAgY29uc3QgdHggPSBtYXRyaXgudHg7XG4gICAgY29uc3QgdHkgPSBtYXRyaXgudHk7XG4gICAgbGV0IHggPSAwO1xuICAgIGxldCB5ID0gMDtcbiAgICBsZXQgY3B4MSA9IDA7XG4gICAgbGV0IGNweTEgPSAwO1xuICAgIGxldCBjcHgyID0gMDtcbiAgICBsZXQgY3B5MiA9IDA7XG4gICAgbGV0IHJ4ID0gMDtcbiAgICBsZXQgcnkgPSAwO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGluc3RydWN0aW9uID0gdGhpcy5pbnN0cnVjdGlvbnNbaV07XG4gICAgICBjb25zdCBkYXRhID0gaW5zdHJ1Y3Rpb24uZGF0YTtcbiAgICAgIHN3aXRjaCAoaW5zdHJ1Y3Rpb24uYWN0aW9uKSB7XG4gICAgICAgIGNhc2UgXCJtb3ZlVG9cIjpcbiAgICAgICAgY2FzZSBcImxpbmVUb1wiOlxuICAgICAgICAgIHggPSBkYXRhWzBdO1xuICAgICAgICAgIHkgPSBkYXRhWzFdO1xuICAgICAgICAgIGRhdGFbMF0gPSBhICogeCArIGMgKiB5ICsgdHg7XG4gICAgICAgICAgZGF0YVsxXSA9IGIgKiB4ICsgZCAqIHkgKyB0eTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcImJlemllckN1cnZlVG9cIjpcbiAgICAgICAgICBjcHgxID0gZGF0YVswXTtcbiAgICAgICAgICBjcHkxID0gZGF0YVsxXTtcbiAgICAgICAgICBjcHgyID0gZGF0YVsyXTtcbiAgICAgICAgICBjcHkyID0gZGF0YVszXTtcbiAgICAgICAgICB4ID0gZGF0YVs0XTtcbiAgICAgICAgICB5ID0gZGF0YVs1XTtcbiAgICAgICAgICBkYXRhWzBdID0gYSAqIGNweDEgKyBjICogY3B5MSArIHR4O1xuICAgICAgICAgIGRhdGFbMV0gPSBiICogY3B4MSArIGQgKiBjcHkxICsgdHk7XG4gICAgICAgICAgZGF0YVsyXSA9IGEgKiBjcHgyICsgYyAqIGNweTIgKyB0eDtcbiAgICAgICAgICBkYXRhWzNdID0gYiAqIGNweDIgKyBkICogY3B5MiArIHR5O1xuICAgICAgICAgIGRhdGFbNF0gPSBhICogeCArIGMgKiB5ICsgdHg7XG4gICAgICAgICAgZGF0YVs1XSA9IGIgKiB4ICsgZCAqIHkgKyB0eTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInF1YWRyYXRpY0N1cnZlVG9cIjpcbiAgICAgICAgICBjcHgxID0gZGF0YVswXTtcbiAgICAgICAgICBjcHkxID0gZGF0YVsxXTtcbiAgICAgICAgICB4ID0gZGF0YVsyXTtcbiAgICAgICAgICB5ID0gZGF0YVszXTtcbiAgICAgICAgICBkYXRhWzBdID0gYSAqIGNweDEgKyBjICogY3B5MSArIHR4O1xuICAgICAgICAgIGRhdGFbMV0gPSBiICogY3B4MSArIGQgKiBjcHkxICsgdHk7XG4gICAgICAgICAgZGF0YVsyXSA9IGEgKiB4ICsgYyAqIHkgKyB0eDtcbiAgICAgICAgICBkYXRhWzNdID0gYiAqIHggKyBkICogeSArIHR5O1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiYXJjVG9TdmdcIjpcbiAgICAgICAgICB4ID0gZGF0YVs1XTtcbiAgICAgICAgICB5ID0gZGF0YVs2XTtcbiAgICAgICAgICByeCA9IGRhdGFbMF07XG4gICAgICAgICAgcnkgPSBkYXRhWzFdO1xuICAgICAgICAgIGRhdGFbMF0gPSBhICogcnggKyBjICogcnk7XG4gICAgICAgICAgZGF0YVsxXSA9IGIgKiByeCArIGQgKiByeTtcbiAgICAgICAgICBkYXRhWzVdID0gYSAqIHggKyBjICogeSArIHR4O1xuICAgICAgICAgIGRhdGFbNl0gPSBiICogeCArIGQgKiB5ICsgdHk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJjaXJjbGVcIjpcbiAgICAgICAgICBkYXRhWzRdID0gYWRqdXN0VHJhbnNmb3JtKGRhdGFbM10sIG1hdHJpeCk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJyZWN0XCI6XG4gICAgICAgICAgZGF0YVs0XSA9IGFkanVzdFRyYW5zZm9ybShkYXRhWzRdLCBtYXRyaXgpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiZWxsaXBzZVwiOlxuICAgICAgICAgIGRhdGFbOF0gPSBhZGp1c3RUcmFuc2Zvcm0oZGF0YVs4XSwgbWF0cml4KTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInJvdW5kUmVjdFwiOlxuICAgICAgICAgIGRhdGFbNV0gPSBhZGp1c3RUcmFuc2Zvcm0oZGF0YVs1XSwgbWF0cml4KTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcImFkZFBhdGhcIjpcbiAgICAgICAgICBkYXRhWzBdLnRyYW5zZm9ybShtYXRyaXgpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwicG9seVwiOlxuICAgICAgICAgIGRhdGFbMl0gPSBhZGp1c3RUcmFuc2Zvcm0oZGF0YVsyXSwgbWF0cml4KTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInJlZ3VsYXJQb2x5XCI6XG4gICAgICAgIGNhc2UgXCJjaGFtZmVyUmVjdFwiOlxuICAgICAgICAgIGRhdGFbNV0gPSBhZGp1c3RUcmFuc2Zvcm0oZGF0YVs1XSwgbWF0cml4KTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcImNsb3NlUGF0aFwiOlxuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHdhcm4oXCJ1bmtub3duIHRyYW5zZm9ybSBhY3Rpb25cIiwgaW5zdHJ1Y3Rpb24uYWN0aW9uKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIGdldCBib3VuZHMoKSB7XG4gICAgcmV0dXJuIHRoaXMuc2hhcGVQYXRoLmJvdW5kcztcbiAgfVxuICAvKipcbiAgICogUmV0cmlldmVzIHRoZSBsYXN0IHBvaW50IGZyb20gdGhlIGN1cnJlbnQgZHJhd2luZyBpbnN0cnVjdGlvbnMgaW4gdGhlIGBHcmFwaGljc1BhdGhgLlxuICAgKiBUaGlzIG1ldGhvZCBpcyB1c2VmdWwgZm9yIG9wZXJhdGlvbnMgdGhhdCBkZXBlbmQgb24gdGhlIHBhdGgncyBjdXJyZW50IGVuZHBvaW50LFxuICAgKiBzdWNoIGFzIGNvbm5lY3Rpbmcgc3Vic2VxdWVudCBzaGFwZXMgb3IgcGF0aHMuIEl0IHN1cHBvcnRzIHZhcmlvdXMgZHJhd2luZyBpbnN0cnVjdGlvbnMsXG4gICAqIGVuc3VyaW5nIHRoZSBsYXN0IHBvaW50J3MgcG9zaXRpb24gaXMgYWNjdXJhdGVseSBkZXRlcm1pbmVkIHJlZ2FyZGxlc3Mgb2YgdGhlIHBhdGgncyBjb21wbGV4aXR5LlxuICAgKlxuICAgKiBJZiB0aGUgbGFzdCBpbnN0cnVjdGlvbiBpcyBhIGBjbG9zZVBhdGhgLCB0aGUgbWV0aG9kIGl0ZXJhdGVzIGJhY2t3YXJkIHRocm91Z2ggdGhlIGluc3RydWN0aW9uc1xuICAgKiAgdW50aWwgaXQgZmluZHMgYW4gYWN0aW9uYWJsZSBpbnN0cnVjdGlvbiB0aGF0IGRlZmluZXMgYSBwb2ludCAoZS5nLiwgYG1vdmVUb2AsIGBsaW5lVG9gLFxuICAgKiBgcXVhZHJhdGljQ3VydmVUb2AsIGV0Yy4pLiBGb3IgY29tcG91bmQgcGF0aHMgYWRkZWQgdmlhIGBhZGRQYXRoYCwgaXQgcmVjdXJzaXZlbHkgcmV0cmlldmVzXG4gICAqIHRoZSBsYXN0IHBvaW50IGZyb20gdGhlIG5lc3RlZCBwYXRoLlxuICAgKiBAcGFyYW0gb3V0IC0gQSBgUG9pbnRgIG9iamVjdCB3aGVyZSB0aGUgbGFzdCBwb2ludCdzIGNvb3JkaW5hdGVzIHdpbGwgYmUgc3RvcmVkLlxuICAgKiBUaGlzIG9iamVjdCBpcyBtb2RpZmllZCBkaXJlY3RseSB0byBjb250YWluIHRoZSByZXN1bHQuXG4gICAqIEByZXR1cm5zIFRoZSBgUG9pbnRgIG9iamVjdCBjb250YWluaW5nIHRoZSBsYXN0IHBvaW50J3MgY29vcmRpbmF0ZXMuXG4gICAqL1xuICBnZXRMYXN0UG9pbnQob3V0KSB7XG4gICAgbGV0IGluZGV4ID0gdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoIC0gMTtcbiAgICBsZXQgbGFzdEluc3RydWN0aW9uID0gdGhpcy5pbnN0cnVjdGlvbnNbaW5kZXhdO1xuICAgIGlmICghbGFzdEluc3RydWN0aW9uKSB7XG4gICAgICBvdXQueCA9IDA7XG4gICAgICBvdXQueSA9IDA7XG4gICAgICByZXR1cm4gb3V0O1xuICAgIH1cbiAgICB3aGlsZSAobGFzdEluc3RydWN0aW9uLmFjdGlvbiA9PT0gXCJjbG9zZVBhdGhcIikge1xuICAgICAgaW5kZXgtLTtcbiAgICAgIGlmIChpbmRleCA8IDApIHtcbiAgICAgICAgb3V0LnggPSAwO1xuICAgICAgICBvdXQueSA9IDA7XG4gICAgICAgIHJldHVybiBvdXQ7XG4gICAgICB9XG4gICAgICBsYXN0SW5zdHJ1Y3Rpb24gPSB0aGlzLmluc3RydWN0aW9uc1tpbmRleF07XG4gICAgfVxuICAgIHN3aXRjaCAobGFzdEluc3RydWN0aW9uLmFjdGlvbikge1xuICAgICAgY2FzZSBcIm1vdmVUb1wiOlxuICAgICAgY2FzZSBcImxpbmVUb1wiOlxuICAgICAgICBvdXQueCA9IGxhc3RJbnN0cnVjdGlvbi5kYXRhWzBdO1xuICAgICAgICBvdXQueSA9IGxhc3RJbnN0cnVjdGlvbi5kYXRhWzFdO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJxdWFkcmF0aWNDdXJ2ZVRvXCI6XG4gICAgICAgIG91dC54ID0gbGFzdEluc3RydWN0aW9uLmRhdGFbMl07XG4gICAgICAgIG91dC55ID0gbGFzdEluc3RydWN0aW9uLmRhdGFbM107XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImJlemllckN1cnZlVG9cIjpcbiAgICAgICAgb3V0LnggPSBsYXN0SW5zdHJ1Y3Rpb24uZGF0YVs0XTtcbiAgICAgICAgb3V0LnkgPSBsYXN0SW5zdHJ1Y3Rpb24uZGF0YVs1XTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiYXJjXCI6XG4gICAgICBjYXNlIFwiYXJjVG9TdmdcIjpcbiAgICAgICAgb3V0LnggPSBsYXN0SW5zdHJ1Y3Rpb24uZGF0YVs1XTtcbiAgICAgICAgb3V0LnkgPSBsYXN0SW5zdHJ1Y3Rpb24uZGF0YVs2XTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiYWRkUGF0aFwiOlxuICAgICAgICBsYXN0SW5zdHJ1Y3Rpb24uZGF0YVswXS5nZXRMYXN0UG9pbnQob3V0KTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIHJldHVybiBvdXQ7XG4gIH1cbn1cbmZ1bmN0aW9uIGFkanVzdFRyYW5zZm9ybShjdXJyZW50TWF0cml4LCB0cmFuc2Zvcm0pIHtcbiAgaWYgKGN1cnJlbnRNYXRyaXgpIHtcbiAgICByZXR1cm4gY3VycmVudE1hdHJpeC5wcmVwZW5kKHRyYW5zZm9ybSk7XG4gIH1cbiAgcmV0dXJuIHRyYW5zZm9ybS5jbG9uZSgpO1xufVxuXG5leHBvcnQgeyBHcmFwaGljc1BhdGggfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUdyYXBoaWNzUGF0aC5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIHBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUoc3ZnLCBpZCwgZGVmYXVsdFZhbHVlKSB7XG4gIGNvbnN0IHZhbHVlID0gc3ZnLmdldEF0dHJpYnV0ZShpZCk7XG4gIHJldHVybiB2YWx1ZSA/IE51bWJlcih2YWx1ZSkgOiBkZWZhdWx0VmFsdWU7XG59XG5cbmV4cG9ydCB7IHBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUubWpzLm1hcFxuIiwiaW1wb3J0IHsgQ29sb3IgfSBmcm9tICcuLi8uLi8uLi8uLi9jb2xvci9Db2xvci5tanMnO1xuaW1wb3J0IHsgRmlsbEdyYWRpZW50IH0gZnJvbSAnLi4vZmlsbC9GaWxsR3JhZGllbnQubWpzJztcbmltcG9ydCB7IHBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUgfSBmcm9tICcuL3BhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBwYXJzZVNWR0RlZmluaXRpb25zKHN2Zywgc2Vzc2lvbikge1xuICBjb25zdCBkZWZpbml0aW9ucyA9IHN2Zy5xdWVyeVNlbGVjdG9yQWxsKFwiZGVmc1wiKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBkZWZpbml0aW9ucy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGRlZmluaXRpb24gPSBkZWZpbml0aW9uc1tpXTtcbiAgICBmb3IgKGxldCBqID0gMDsgaiA8IGRlZmluaXRpb24uY2hpbGRyZW4ubGVuZ3RoOyBqKyspIHtcbiAgICAgIGNvbnN0IGNoaWxkID0gZGVmaW5pdGlvbi5jaGlsZHJlbltqXTtcbiAgICAgIHN3aXRjaCAoY2hpbGQubm9kZU5hbWUudG9Mb3dlckNhc2UoKSkge1xuICAgICAgICBjYXNlIFwibGluZWFyZ3JhZGllbnRcIjpcbiAgICAgICAgICBzZXNzaW9uLmRlZnNbY2hpbGQuaWRdID0gcGFyc2VMaW5lYXJHcmFkaWVudChjaGlsZCk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJyYWRpYWxncmFkaWVudFwiOlxuICAgICAgICAgIHNlc3Npb24uZGVmc1tjaGlsZC5pZF0gPSBwYXJzZVJhZGlhbEdyYWRpZW50KGNoaWxkKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIHBhcnNlR3JhZGllbnRDb29yZGluYXRlKHN2ZywgaWQsIGRlZmF1bHRWYWx1ZSkge1xuICBjb25zdCB2YWx1ZSA9IHN2Zy5nZXRBdHRyaWJ1dGUoaWQpO1xuICBpZiAodmFsdWU/LnRyaW0oKS5lbmRzV2l0aChcIiVcIikpIHtcbiAgICBjb25zdCBwZXJjZW50YWdlID0gTnVtYmVyKHZhbHVlLnRyaW0oKS5zbGljZSgwLCAtMSkpO1xuICAgIHJldHVybiBOdW1iZXIuaXNOYU4ocGVyY2VudGFnZSkgPyBkZWZhdWx0VmFsdWUgOiBwZXJjZW50YWdlIC8gMTAwO1xuICB9XG4gIHJldHVybiBwYXJzZVNWR0Zsb2F0QXR0cmlidXRlKHN2ZywgaWQsIGRlZmF1bHRWYWx1ZSk7XG59XG5mdW5jdGlvbiBwYXJzZUdyYWRpZW50VGV4dHVyZVNwYWNlKHN2Zykge1xuICByZXR1cm4gKHN2Zy5nZXRBdHRyaWJ1dGUoXCJncmFkaWVudFVuaXRzXCIpIHx8IFwib2JqZWN0Qm91bmRpbmdCb3hcIikgPT09IFwib2JqZWN0Qm91bmRpbmdCb3hcIiA/IFwibG9jYWxcIiA6IFwiZ2xvYmFsXCI7XG59XG5mdW5jdGlvbiBwYXJzZUdyYWRpZW50Q29sb3JTdG9wcyhzdmcpIHtcbiAgY29uc3QgY29sb3JTdG9wcyA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHN2Zy5jaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IHN0b3AgPSBzdmcuY2hpbGRyZW5baV07XG4gICAgY29uc3Qgb2Zmc2V0ID0gcGFyc2VHcmFkaWVudENvb3JkaW5hdGUoc3RvcCwgXCJvZmZzZXRcIiwgMCk7XG4gICAgY29uc3QgY29sb3IgPSBDb2xvci5zaGFyZWQuc2V0VmFsdWUoc3RvcC5nZXRBdHRyaWJ1dGUoXCJzdG9wLWNvbG9yXCIpKS50b051bWJlcigpO1xuICAgIGNvbG9yU3RvcHMucHVzaCh7IG9mZnNldCwgY29sb3IgfSk7XG4gIH1cbiAgcmV0dXJuIGNvbG9yU3RvcHM7XG59XG5mdW5jdGlvbiBwYXJzZUxpbmVhckdyYWRpZW50KGNoaWxkKSB7XG4gIGNvbnN0IHgwID0gcGFyc2VHcmFkaWVudENvb3JkaW5hdGUoY2hpbGQsIFwieDFcIiwgMCk7XG4gIGNvbnN0IHkwID0gcGFyc2VHcmFkaWVudENvb3JkaW5hdGUoY2hpbGQsIFwieTFcIiwgMCk7XG4gIGNvbnN0IHgxID0gcGFyc2VHcmFkaWVudENvb3JkaW5hdGUoY2hpbGQsIFwieDJcIiwgMSk7XG4gIGNvbnN0IHkxID0gcGFyc2VHcmFkaWVudENvb3JkaW5hdGUoY2hpbGQsIFwieTJcIiwgMCk7XG4gIHJldHVybiBuZXcgRmlsbEdyYWRpZW50KHtcbiAgICB0eXBlOiBcImxpbmVhclwiLFxuICAgIHN0YXJ0OiB7IHg6IHgwLCB5OiB5MCB9LFxuICAgIGVuZDogeyB4OiB4MSwgeTogeTEgfSxcbiAgICB0ZXh0dXJlU3BhY2U6IHBhcnNlR3JhZGllbnRUZXh0dXJlU3BhY2UoY2hpbGQpLFxuICAgIGNvbG9yU3RvcHM6IHBhcnNlR3JhZGllbnRDb2xvclN0b3BzKGNoaWxkKVxuICB9KTtcbn1cbmZ1bmN0aW9uIHBhcnNlUmFkaWFsR3JhZGllbnQoY2hpbGQpIHtcbiAgY29uc3QgY3ggPSBwYXJzZUdyYWRpZW50Q29vcmRpbmF0ZShjaGlsZCwgXCJjeFwiLCAwLjUpO1xuICBjb25zdCBjeSA9IHBhcnNlR3JhZGllbnRDb29yZGluYXRlKGNoaWxkLCBcImN5XCIsIDAuNSk7XG4gIGNvbnN0IHIgPSBwYXJzZUdyYWRpZW50Q29vcmRpbmF0ZShjaGlsZCwgXCJyXCIsIDAuNSk7XG4gIGNvbnN0IGZ4ID0gcGFyc2VHcmFkaWVudENvb3JkaW5hdGUoY2hpbGQsIFwiZnhcIiwgY3gpO1xuICBjb25zdCBmeSA9IHBhcnNlR3JhZGllbnRDb29yZGluYXRlKGNoaWxkLCBcImZ5XCIsIGN5KTtcbiAgY29uc3QgZnIgPSBwYXJzZUdyYWRpZW50Q29vcmRpbmF0ZShjaGlsZCwgXCJmclwiLCAwKTtcbiAgcmV0dXJuIG5ldyBGaWxsR3JhZGllbnQoe1xuICAgIHR5cGU6IFwicmFkaWFsXCIsXG4gICAgY2VudGVyOiB7IHg6IGZ4LCB5OiBmeSB9LFxuICAgIGlubmVyUmFkaXVzOiBmcixcbiAgICBvdXRlckNlbnRlcjogeyB4OiBjeCwgeTogY3kgfSxcbiAgICBvdXRlclJhZGl1czogcixcbiAgICB0ZXh0dXJlU3BhY2U6IHBhcnNlR3JhZGllbnRUZXh0dXJlU3BhY2UoY2hpbGQpLFxuICAgIGNvbG9yU3RvcHM6IHBhcnNlR3JhZGllbnRDb2xvclN0b3BzKGNoaWxkKVxuICB9KTtcbn1cblxuZXhwb3J0IHsgcGFyc2VTVkdEZWZpbml0aW9ucyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFyc2VTVkdEZWZpbml0aW9ucy5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGV4dHJhY3RTdmdVcmxJZCh1cmwpIHtcbiAgY29uc3QgbWF0Y2ggPSB1cmwubWF0Y2goL3VybFxccypcXChcXHMqWydcIl0/XFxzKiMoW14nXCJcXHMpXSspXFxzKlsnXCJdP1xccypcXCkvaSk7XG4gIHJldHVybiBtYXRjaCA/IG1hdGNoWzFdIDogXCJcIjtcbn1cblxuZXhwb3J0IHsgZXh0cmFjdFN2Z1VybElkIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1leHRyYWN0U3ZnVXJsSWQubWpzLm1hcFxuIiwiaW1wb3J0IHsgQ29sb3IgfSBmcm9tICcuLi8uLi8uLi8uLi9jb2xvci9Db2xvci5tanMnO1xuaW1wb3J0IHsgZXh0cmFjdFN2Z1VybElkIH0gZnJvbSAnLi91dGlscy9leHRyYWN0U3ZnVXJsSWQubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBzdHlsZUF0dHJpYnV0ZXMgPSB7XG4gIC8vIEZpbGwgcHJvcGVydGllc1xuICBmaWxsOiB7IHR5cGU6IFwicGFpbnRcIiwgZGVmYXVsdDogMCB9LFxuICAvLyBGaWxsIGNvbG9yL2dyYWRpZW50XG4gIFwiZmlsbC1vcGFjaXR5XCI6IHsgdHlwZTogXCJudW1iZXJcIiwgZGVmYXVsdDogMSB9LFxuICAvLyBGaWxsIHRyYW5zcGFyZW5jeVxuICAvLyBTdHJva2UgcHJvcGVydGllc1xuICBzdHJva2U6IHsgdHlwZTogXCJwYWludFwiLCBkZWZhdWx0OiAwIH0sXG4gIC8vIFN0cm9rZSBjb2xvci9ncmFkaWVudFxuICBcInN0cm9rZS13aWR0aFwiOiB7IHR5cGU6IFwibnVtYmVyXCIsIGRlZmF1bHQ6IDEgfSxcbiAgLy8gV2lkdGggb2Ygc3Ryb2tlXG4gIFwic3Ryb2tlLW9wYWNpdHlcIjogeyB0eXBlOiBcIm51bWJlclwiLCBkZWZhdWx0OiAxIH0sXG4gIC8vIFN0cm9rZSB0cmFuc3BhcmVuY3lcbiAgXCJzdHJva2UtbGluZWNhcFwiOiB7IHR5cGU6IFwic3RyaW5nXCIsIGRlZmF1bHQ6IFwiYnV0dFwiIH0sXG4gIC8vIEVuZCBjYXAgc3R5bGU6IGJ1dHQsIHJvdW5kLCBzcXVhcmVcbiAgXCJzdHJva2UtbGluZWpvaW5cIjogeyB0eXBlOiBcInN0cmluZ1wiLCBkZWZhdWx0OiBcIm1pdGVyXCIgfSxcbiAgLy8gSm9pbiBzdHlsZTogbWl0ZXIsIHJvdW5kLCBiZXZlbFxuICBcInN0cm9rZS1taXRlcmxpbWl0XCI6IHsgdHlwZTogXCJudW1iZXJcIiwgZGVmYXVsdDogMTAgfSxcbiAgLy8gTGltaXQgb24gbWl0ZXIgam9pbiBzaGFycG5lc3NcbiAgXCJzdHJva2UtZGFzaGFycmF5XCI6IHsgdHlwZTogXCJzdHJpbmdcIiwgZGVmYXVsdDogXCJub25lXCIgfSxcbiAgLy8gRGFzaCBwYXR0ZXJuXG4gIFwic3Ryb2tlLWRhc2hvZmZzZXRcIjogeyB0eXBlOiBcIm51bWJlclwiLCBkZWZhdWx0OiAwIH0sXG4gIC8vIE9mZnNldCBmb3IgZGFzaCBwYXR0ZXJuXG4gIC8vIEdsb2JhbCBwcm9wZXJ0aWVzXG4gIG9wYWNpdHk6IHsgdHlwZTogXCJudW1iZXJcIiwgZGVmYXVsdDogMSB9XG4gIC8vIE92ZXJhbGwgb3BhY2l0eVxufTtcbmZ1bmN0aW9uIHBhcnNlU1ZHU3R5bGUoc3ZnLCBzZXNzaW9uKSB7XG4gIGNvbnN0IHN0eWxlID0gc3ZnLmdldEF0dHJpYnV0ZShcInN0eWxlXCIpO1xuICBjb25zdCBzdHJva2VTdHlsZSA9IHt9O1xuICBjb25zdCBmaWxsU3R5bGUgPSB7fTtcbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgIHN0cm9rZVN0eWxlLFxuICAgIGZpbGxTdHlsZSxcbiAgICB1c2VGaWxsOiBmYWxzZSxcbiAgICB1c2VTdHJva2U6IGZhbHNlXG4gIH07XG4gIGZvciAoY29uc3Qga2V5IGluIHN0eWxlQXR0cmlidXRlcykge1xuICAgIGNvbnN0IGF0dHJpYnV0ZSA9IHN2Zy5nZXRBdHRyaWJ1dGUoa2V5KTtcbiAgICBpZiAoYXR0cmlidXRlKSB7XG4gICAgICBwYXJzZUF0dHJpYnV0ZShzZXNzaW9uLCByZXN1bHQsIGtleSwgYXR0cmlidXRlLnRyaW0oKSk7XG4gICAgfVxuICB9XG4gIGlmIChzdHlsZSkge1xuICAgIGNvbnN0IHN0eWxlUGFydHMgPSBzdHlsZS5zcGxpdChcIjtcIik7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHlsZVBhcnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBzdHlsZVBhcnQgPSBzdHlsZVBhcnRzW2ldLnRyaW0oKTtcbiAgICAgIGNvbnN0IFtrZXksIHZhbHVlXSA9IHN0eWxlUGFydC5zcGxpdChcIjpcIik7XG4gICAgICBpZiAoc3R5bGVBdHRyaWJ1dGVzW2tleV0pIHtcbiAgICAgICAgcGFyc2VBdHRyaWJ1dGUoc2Vzc2lvbiwgcmVzdWx0LCBrZXksIHZhbHVlLnRyaW0oKSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgc3Ryb2tlU3R5bGU6IHJlc3VsdC51c2VTdHJva2UgPyBzdHJva2VTdHlsZSA6IG51bGwsXG4gICAgZmlsbFN0eWxlOiByZXN1bHQudXNlRmlsbCA/IGZpbGxTdHlsZSA6IG51bGwsXG4gICAgdXNlRmlsbDogcmVzdWx0LnVzZUZpbGwsXG4gICAgdXNlU3Ryb2tlOiByZXN1bHQudXNlU3Ryb2tlXG4gIH07XG59XG5mdW5jdGlvbiBwYXJzZUF0dHJpYnV0ZShzZXNzaW9uLCByZXN1bHQsIGlkLCB2YWx1ZSkge1xuICBzd2l0Y2ggKGlkKSB7XG4gICAgY2FzZSBcInN0cm9rZVwiOlxuICAgICAgaWYgKHZhbHVlICE9PSBcIm5vbmVcIikge1xuICAgICAgICBpZiAodmFsdWUuc3RhcnRzV2l0aChcInVybChcIikpIHtcbiAgICAgICAgICBjb25zdCBpZDIgPSBleHRyYWN0U3ZnVXJsSWQodmFsdWUpO1xuICAgICAgICAgIHJlc3VsdC5zdHJva2VTdHlsZS5maWxsID0gc2Vzc2lvbi5kZWZzW2lkMl07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzdWx0LnN0cm9rZVN0eWxlLmNvbG9yID0gQ29sb3Iuc2hhcmVkLnNldFZhbHVlKHZhbHVlKS50b051bWJlcigpO1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdC51c2VTdHJva2UgPSB0cnVlO1xuICAgICAgfVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInN0cm9rZS13aWR0aFwiOlxuICAgICAgcmVzdWx0LnN0cm9rZVN0eWxlLndpZHRoID0gTnVtYmVyKHZhbHVlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJmaWxsXCI6XG4gICAgICBpZiAodmFsdWUgIT09IFwibm9uZVwiKSB7XG4gICAgICAgIGlmICh2YWx1ZS5zdGFydHNXaXRoKFwidXJsKFwiKSkge1xuICAgICAgICAgIGNvbnN0IGlkMiA9IGV4dHJhY3RTdmdVcmxJZCh2YWx1ZSk7XG4gICAgICAgICAgcmVzdWx0LmZpbGxTdHlsZS5maWxsID0gc2Vzc2lvbi5kZWZzW2lkMl07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzdWx0LmZpbGxTdHlsZS5jb2xvciA9IENvbG9yLnNoYXJlZC5zZXRWYWx1ZSh2YWx1ZSkudG9OdW1iZXIoKTtcbiAgICAgICAgfVxuICAgICAgICByZXN1bHQudXNlRmlsbCA9IHRydWU7XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZmlsbC1vcGFjaXR5XCI6XG4gICAgICByZXN1bHQuZmlsbFN0eWxlLmFscGhhID0gTnVtYmVyKHZhbHVlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJzdHJva2Utb3BhY2l0eVwiOlxuICAgICAgcmVzdWx0LnN0cm9rZVN0eWxlLmFscGhhID0gTnVtYmVyKHZhbHVlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJvcGFjaXR5XCI6XG4gICAgICByZXN1bHQuZmlsbFN0eWxlLmFscGhhID0gTnVtYmVyKHZhbHVlKTtcbiAgICAgIHJlc3VsdC5zdHJva2VTdHlsZS5hbHBoYSA9IE51bWJlcih2YWx1ZSk7XG4gICAgICBicmVhaztcbiAgfVxufVxuXG5leHBvcnQgeyBwYXJzZVNWR1N0eWxlLCBzdHlsZUF0dHJpYnV0ZXMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhcnNlU1ZHU3R5bGUubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBjaGVja0Zvck5lc3RlZFBhdHRlcm4oc3VicGF0aHNXaXRoQXJlYSkge1xuICBpZiAoc3VicGF0aHNXaXRoQXJlYS5sZW5ndGggPD0gMikge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGNvbnN0IGFyZWFzID0gc3VicGF0aHNXaXRoQXJlYS5tYXAoKHMpID0+IHMuYXJlYSkuc29ydCgoYSwgYikgPT4gYiAtIGEpO1xuICBjb25zdCBbbGFyZ2VzdEFyZWEsIHNlY29uZEFyZWFdID0gYXJlYXM7XG4gIGNvbnN0IHNtYWxsZXN0QXJlYSA9IGFyZWFzW2FyZWFzLmxlbmd0aCAtIDFdO1xuICBjb25zdCBsYXJnZXN0VG9TZWNvbmRSYXRpbyA9IGxhcmdlc3RBcmVhIC8gc2Vjb25kQXJlYTtcbiAgY29uc3Qgc2Vjb25kVG9TbWFsbGVzdFJhdGlvID0gc2Vjb25kQXJlYSAvIHNtYWxsZXN0QXJlYTtcbiAgaWYgKGxhcmdlc3RUb1NlY29uZFJhdGlvID4gMyAmJiBzZWNvbmRUb1NtYWxsZXN0UmF0aW8gPCAyKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gZ2V0RmlsbEluc3RydWN0aW9uRGF0YShjb250ZXh0LCBpbmRleCA9IDApIHtcbiAgY29uc3QgaW5zdHJ1Y3Rpb24gPSBjb250ZXh0Lmluc3RydWN0aW9uc1tpbmRleF07XG4gIGlmICghaW5zdHJ1Y3Rpb24gfHwgaW5zdHJ1Y3Rpb24uYWN0aW9uICE9PSBcImZpbGxcIikge1xuICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgZmlsbCBpbnN0cnVjdGlvbiBhdCBpbmRleCAke2luZGV4fSwgZ290ICR7aW5zdHJ1Y3Rpb24/LmFjdGlvbiB8fCBcInVuZGVmaW5lZFwifWApO1xuICB9XG4gIHJldHVybiBpbnN0cnVjdGlvbi5kYXRhO1xufVxuXG5leHBvcnQgeyBjaGVja0Zvck5lc3RlZFBhdHRlcm4sIGdldEZpbGxJbnN0cnVjdGlvbkRhdGEgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZpbGxPcGVyYXRpb25zLm1qcy5tYXBcbiIsImltcG9ydCB7IEdyYXBoaWNzUGF0aCB9IGZyb20gJy4uLy4uL3BhdGgvR3JhcGhpY3NQYXRoLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gZXh0cmFjdFN1YnBhdGhzKHBhdGhEYXRhKSB7XG4gIGNvbnN0IHBhcnRzID0gcGF0aERhdGEuc3BsaXQoLyg/PVtNbV0pLyk7XG4gIGNvbnN0IHN1YnBhdGhzID0gcGFydHMuZmlsdGVyKChwYXJ0KSA9PiBwYXJ0LnRyaW0oKS5sZW5ndGggPiAwKTtcbiAgcmV0dXJuIHN1YnBhdGhzO1xufVxuZnVuY3Rpb24gY2FsY3VsYXRlUGF0aEFyZWEocGF0aERhdGEpIHtcbiAgY29uc3QgY29vcmRzID0gcGF0aERhdGEubWF0Y2goL1stK10/WzAtOV0qXFwuP1swLTldKy9nKTtcbiAgaWYgKCFjb29yZHMgfHwgY29vcmRzLmxlbmd0aCA8IDQpIHJldHVybiAwO1xuICBjb25zdCBudW1iZXJzID0gY29vcmRzLm1hcChOdW1iZXIpO1xuICBjb25zdCB4cyA9IFtdO1xuICBjb25zdCB5cyA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG51bWJlcnMubGVuZ3RoOyBpICs9IDIpIHtcbiAgICBpZiAoaSArIDEgPCBudW1iZXJzLmxlbmd0aCkge1xuICAgICAgeHMucHVzaChudW1iZXJzW2ldKTtcbiAgICAgIHlzLnB1c2gobnVtYmVyc1tpICsgMV0pO1xuICAgIH1cbiAgfVxuICBpZiAoeHMubGVuZ3RoID09PSAwIHx8IHlzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDA7XG4gIGNvbnN0IG1pblggPSBNYXRoLm1pbiguLi54cyk7XG4gIGNvbnN0IG1heFggPSBNYXRoLm1heCguLi54cyk7XG4gIGNvbnN0IG1pblkgPSBNYXRoLm1pbiguLi55cyk7XG4gIGNvbnN0IG1heFkgPSBNYXRoLm1heCguLi55cyk7XG4gIGNvbnN0IGFyZWEgPSAobWF4WCAtIG1pblgpICogKG1heFkgLSBtaW5ZKTtcbiAgcmV0dXJuIGFyZWE7XG59XG5mdW5jdGlvbiBhcHBlbmRTVkdQYXRoKHBhdGhEYXRhLCBncmFwaGljc1BhdGgpIHtcbiAgY29uc3QgdGVtcFBhdGggPSBuZXcgR3JhcGhpY3NQYXRoKHBhdGhEYXRhLCBmYWxzZSk7XG4gIGZvciAoY29uc3QgaW5zdHJ1Y3Rpb24gb2YgdGVtcFBhdGguaW5zdHJ1Y3Rpb25zKSB7XG4gICAgZ3JhcGhpY3NQYXRoLmluc3RydWN0aW9ucy5wdXNoKGluc3RydWN0aW9uKTtcbiAgfVxufVxuXG5leHBvcnQgeyBhcHBlbmRTVkdQYXRoLCBjYWxjdWxhdGVQYXRoQXJlYSwgZXh0cmFjdFN1YnBhdGhzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1wYXRoT3BlcmF0aW9ucy5tanMubWFwXG4iLCJpbXBvcnQgeyB3YXJuIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy93YXJuLm1qcyc7XG5pbXBvcnQgeyBHcmFwaGljc1BhdGggfSBmcm9tICcuLi9wYXRoL0dyYXBoaWNzUGF0aC5tanMnO1xuaW1wb3J0IHsgcGFyc2VTVkdEZWZpbml0aW9ucyB9IGZyb20gJy4vcGFyc2VTVkdEZWZpbml0aW9ucy5tanMnO1xuaW1wb3J0IHsgcGFyc2VTVkdGbG9hdEF0dHJpYnV0ZSB9IGZyb20gJy4vcGFyc2VTVkdGbG9hdEF0dHJpYnV0ZS5tanMnO1xuaW1wb3J0IHsgcGFyc2VTVkdTdHlsZSB9IGZyb20gJy4vcGFyc2VTVkdTdHlsZS5tanMnO1xuaW1wb3J0IHsgY2hlY2tGb3JOZXN0ZWRQYXR0ZXJuIH0gZnJvbSAnLi91dGlscy9maWxsT3BlcmF0aW9ucy5tanMnO1xuaW1wb3J0IHsgZXh0cmFjdFN1YnBhdGhzLCBjYWxjdWxhdGVQYXRoQXJlYSwgYXBwZW5kU1ZHUGF0aCB9IGZyb20gJy4vdXRpbHMvcGF0aE9wZXJhdGlvbnMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBTVkdQYXJzZXIoc3ZnLCBncmFwaGljc0NvbnRleHQpIHtcbiAgaWYgKHR5cGVvZiBzdmcgPT09IFwic3RyaW5nXCIpIHtcbiAgICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIGRpdi5pbm5lckhUTUwgPSBzdmcudHJpbSgpO1xuICAgIHN2ZyA9IGRpdi5xdWVyeVNlbGVjdG9yKFwic3ZnXCIpO1xuICB9XG4gIGNvbnN0IHNlc3Npb24gPSB7XG4gICAgY29udGV4dDogZ3JhcGhpY3NDb250ZXh0LFxuICAgIGRlZnM6IHt9LFxuICAgIHBhdGg6IG5ldyBHcmFwaGljc1BhdGgoKVxuICB9O1xuICBwYXJzZVNWR0RlZmluaXRpb25zKHN2Zywgc2Vzc2lvbik7XG4gIGNvbnN0IGNoaWxkcmVuID0gc3ZnLmNoaWxkcmVuO1xuICBjb25zdCB7IGZpbGxTdHlsZSwgc3Ryb2tlU3R5bGUgfSA9IHBhcnNlU1ZHU3R5bGUoc3ZnLCBzZXNzaW9uKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgaWYgKGNoaWxkLm5vZGVOYW1lLnRvTG93ZXJDYXNlKCkgPT09IFwiZGVmc1wiKSBjb250aW51ZTtcbiAgICByZW5kZXJDaGlsZHJlbihjaGlsZCwgc2Vzc2lvbiwgZmlsbFN0eWxlLCBzdHJva2VTdHlsZSk7XG4gIH1cbiAgcmV0dXJuIGdyYXBoaWNzQ29udGV4dDtcbn1cbmZ1bmN0aW9uIHJlbmRlckNoaWxkcmVuKHN2Zywgc2Vzc2lvbiwgZmlsbFN0eWxlLCBzdHJva2VTdHlsZSkge1xuICBjb25zdCBjaGlsZHJlbiA9IHN2Zy5jaGlsZHJlbjtcbiAgY29uc3QgeyBmaWxsU3R5bGU6IGYxLCBzdHJva2VTdHlsZTogczEgfSA9IHBhcnNlU1ZHU3R5bGUoc3ZnLCBzZXNzaW9uKTtcbiAgaWYgKGYxICYmIGZpbGxTdHlsZSkge1xuICAgIGZpbGxTdHlsZSA9IHsgLi4uZmlsbFN0eWxlLCAuLi5mMSB9O1xuICB9IGVsc2UgaWYgKGYxKSB7XG4gICAgZmlsbFN0eWxlID0gZjE7XG4gIH1cbiAgaWYgKHMxICYmIHN0cm9rZVN0eWxlKSB7XG4gICAgc3Ryb2tlU3R5bGUgPSB7IC4uLnN0cm9rZVN0eWxlLCAuLi5zMSB9O1xuICB9IGVsc2UgaWYgKHMxKSB7XG4gICAgc3Ryb2tlU3R5bGUgPSBzMTtcbiAgfVxuICBjb25zdCBub1N0eWxlID0gIWZpbGxTdHlsZSAmJiAhc3Ryb2tlU3R5bGU7XG4gIGlmIChub1N0eWxlKSB7XG4gICAgZmlsbFN0eWxlID0geyBjb2xvcjogMCB9O1xuICB9XG4gIGxldCB4O1xuICBsZXQgeTtcbiAgbGV0IHgxO1xuICBsZXQgeTE7XG4gIGxldCB4MjtcbiAgbGV0IHkyO1xuICBsZXQgY3g7XG4gIGxldCBjeTtcbiAgbGV0IHI7XG4gIGxldCByeDtcbiAgbGV0IHJ5O1xuICBsZXQgcG9pbnRzO1xuICBsZXQgcG9pbnRzU3RyaW5nO1xuICBsZXQgZDtcbiAgbGV0IGdyYXBoaWNzUGF0aDtcbiAgbGV0IHdpZHRoO1xuICBsZXQgaGVpZ2h0O1xuICBzd2l0Y2ggKHN2Zy5ub2RlTmFtZS50b0xvd2VyQ2FzZSgpKSB7XG4gICAgY2FzZSBcInBhdGhcIjoge1xuICAgICAgZCA9IHN2Zy5nZXRBdHRyaWJ1dGUoXCJkXCIpO1xuICAgICAgY29uc3QgZmlsbFJ1bGUgPSBzdmcuZ2V0QXR0cmlidXRlKFwiZmlsbC1ydWxlXCIpO1xuICAgICAgY29uc3Qgc3VicGF0aHMgPSBleHRyYWN0U3VicGF0aHMoZCk7XG4gICAgICBjb25zdCBoYXNFeHBsaWNpdEV2ZW5vZGQgPSBmaWxsUnVsZSA9PT0gXCJldmVub2RkXCI7XG4gICAgICBjb25zdCBoYXNNdWx0aXBsZVN1YnBhdGhzID0gc3VicGF0aHMubGVuZ3RoID4gMTtcbiAgICAgIGNvbnN0IHNob3VsZFByb2Nlc3NIb2xlcyA9IGhhc0V4cGxpY2l0RXZlbm9kZCAmJiBoYXNNdWx0aXBsZVN1YnBhdGhzO1xuICAgICAgaWYgKHNob3VsZFByb2Nlc3NIb2xlcykge1xuICAgICAgICBjb25zdCBzdWJwYXRoc1dpdGhBcmVhID0gc3VicGF0aHMubWFwKChzdWJwYXRoKSA9PiAoe1xuICAgICAgICAgIHBhdGg6IHN1YnBhdGgsXG4gICAgICAgICAgYXJlYTogY2FsY3VsYXRlUGF0aEFyZWEoc3VicGF0aClcbiAgICAgICAgfSkpO1xuICAgICAgICBzdWJwYXRoc1dpdGhBcmVhLnNvcnQoKGEsIGIpID0+IGIuYXJlYSAtIGEuYXJlYSk7XG4gICAgICAgIGNvbnN0IHVzZU11bHRpcGxlSG9sZXNBcHByb2FjaCA9IHN1YnBhdGhzLmxlbmd0aCA+IDMgfHwgIWNoZWNrRm9yTmVzdGVkUGF0dGVybihzdWJwYXRoc1dpdGhBcmVhKTtcbiAgICAgICAgaWYgKHVzZU11bHRpcGxlSG9sZXNBcHByb2FjaCkge1xuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc3VicGF0aHNXaXRoQXJlYS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3Qgc3VicGF0aCA9IHN1YnBhdGhzV2l0aEFyZWFbaV07XG4gICAgICAgICAgICBjb25zdCBpc01haW5TaGFwZSA9IGkgPT09IDA7XG4gICAgICAgICAgICBzZXNzaW9uLmNvbnRleHQuYmVnaW5QYXRoKCk7XG4gICAgICAgICAgICBjb25zdCBuZXdQYXRoID0gbmV3IEdyYXBoaWNzUGF0aCh2b2lkIDAsIHRydWUpO1xuICAgICAgICAgICAgYXBwZW5kU1ZHUGF0aChzdWJwYXRoLnBhdGgsIG5ld1BhdGgpO1xuICAgICAgICAgICAgc2Vzc2lvbi5jb250ZXh0LnBhdGgobmV3UGF0aCk7XG4gICAgICAgICAgICBpZiAoaXNNYWluU2hhcGUpIHtcbiAgICAgICAgICAgICAgaWYgKGZpbGxTdHlsZSkgc2Vzc2lvbi5jb250ZXh0LmZpbGwoZmlsbFN0eWxlKTtcbiAgICAgICAgICAgICAgaWYgKHN0cm9rZVN0eWxlKSBzZXNzaW9uLmNvbnRleHQuc3Ryb2tlKHN0cm9rZVN0eWxlKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHNlc3Npb24uY29udGV4dC5jdXQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdWJwYXRoc1dpdGhBcmVhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBzdWJwYXRoID0gc3VicGF0aHNXaXRoQXJlYVtpXTtcbiAgICAgICAgICAgIGNvbnN0IGlzSG9sZSA9IGkgJSAyID09PSAxO1xuICAgICAgICAgICAgc2Vzc2lvbi5jb250ZXh0LmJlZ2luUGF0aCgpO1xuICAgICAgICAgICAgY29uc3QgbmV3UGF0aCA9IG5ldyBHcmFwaGljc1BhdGgodm9pZCAwLCB0cnVlKTtcbiAgICAgICAgICAgIGFwcGVuZFNWR1BhdGgoc3VicGF0aC5wYXRoLCBuZXdQYXRoKTtcbiAgICAgICAgICAgIHNlc3Npb24uY29udGV4dC5wYXRoKG5ld1BhdGgpO1xuICAgICAgICAgICAgaWYgKGlzSG9sZSkge1xuICAgICAgICAgICAgICBzZXNzaW9uLmNvbnRleHQuY3V0KCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBpZiAoZmlsbFN0eWxlKSBzZXNzaW9uLmNvbnRleHQuZmlsbChmaWxsU3R5bGUpO1xuICAgICAgICAgICAgICBpZiAoc3Ryb2tlU3R5bGUpIHNlc3Npb24uY29udGV4dC5zdHJva2Uoc3Ryb2tlU3R5bGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgdXNlRXZlbm9kZEZvckdyYXBoaWNzUGF0aCA9IGZpbGxSdWxlID8gZmlsbFJ1bGUgPT09IFwiZXZlbm9kZFwiIDogdHJ1ZTtcbiAgICAgICAgZ3JhcGhpY3NQYXRoID0gbmV3IEdyYXBoaWNzUGF0aChkLCB1c2VFdmVub2RkRm9yR3JhcGhpY3NQYXRoKTtcbiAgICAgICAgc2Vzc2lvbi5jb250ZXh0LnBhdGgoZ3JhcGhpY3NQYXRoKTtcbiAgICAgICAgaWYgKGZpbGxTdHlsZSkgc2Vzc2lvbi5jb250ZXh0LmZpbGwoZmlsbFN0eWxlKTtcbiAgICAgICAgaWYgKHN0cm9rZVN0eWxlKSBzZXNzaW9uLmNvbnRleHQuc3Ryb2tlKHN0cm9rZVN0eWxlKTtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjYXNlIFwiY2lyY2xlXCI6XG4gICAgICBjeCA9IHBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUoc3ZnLCBcImN4XCIsIDApO1xuICAgICAgY3kgPSBwYXJzZVNWR0Zsb2F0QXR0cmlidXRlKHN2ZywgXCJjeVwiLCAwKTtcbiAgICAgIHIgPSBwYXJzZVNWR0Zsb2F0QXR0cmlidXRlKHN2ZywgXCJyXCIsIDApO1xuICAgICAgc2Vzc2lvbi5jb250ZXh0LmVsbGlwc2UoY3gsIGN5LCByLCByKTtcbiAgICAgIGlmIChmaWxsU3R5bGUpIHNlc3Npb24uY29udGV4dC5maWxsKGZpbGxTdHlsZSk7XG4gICAgICBpZiAoc3Ryb2tlU3R5bGUpIHNlc3Npb24uY29udGV4dC5zdHJva2Uoc3Ryb2tlU3R5bGUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInJlY3RcIjpcbiAgICAgIHggPSBwYXJzZVNWR0Zsb2F0QXR0cmlidXRlKHN2ZywgXCJ4XCIsIDApO1xuICAgICAgeSA9IHBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUoc3ZnLCBcInlcIiwgMCk7XG4gICAgICB3aWR0aCA9IHBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUoc3ZnLCBcIndpZHRoXCIsIDApO1xuICAgICAgaGVpZ2h0ID0gcGFyc2VTVkdGbG9hdEF0dHJpYnV0ZShzdmcsIFwiaGVpZ2h0XCIsIDApO1xuICAgICAgcnggPSBwYXJzZVNWR0Zsb2F0QXR0cmlidXRlKHN2ZywgXCJyeFwiLCAwKTtcbiAgICAgIHJ5ID0gcGFyc2VTVkdGbG9hdEF0dHJpYnV0ZShzdmcsIFwicnlcIiwgMCk7XG4gICAgICBpZiAocnggfHwgcnkpIHtcbiAgICAgICAgc2Vzc2lvbi5jb250ZXh0LnJvdW5kUmVjdCh4LCB5LCB3aWR0aCwgaGVpZ2h0LCByeCB8fCByeSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXNzaW9uLmNvbnRleHQucmVjdCh4LCB5LCB3aWR0aCwgaGVpZ2h0KTtcbiAgICAgIH1cbiAgICAgIGlmIChmaWxsU3R5bGUpIHNlc3Npb24uY29udGV4dC5maWxsKGZpbGxTdHlsZSk7XG4gICAgICBpZiAoc3Ryb2tlU3R5bGUpIHNlc3Npb24uY29udGV4dC5zdHJva2Uoc3Ryb2tlU3R5bGUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImVsbGlwc2VcIjpcbiAgICAgIGN4ID0gcGFyc2VTVkdGbG9hdEF0dHJpYnV0ZShzdmcsIFwiY3hcIiwgMCk7XG4gICAgICBjeSA9IHBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUoc3ZnLCBcImN5XCIsIDApO1xuICAgICAgcnggPSBwYXJzZVNWR0Zsb2F0QXR0cmlidXRlKHN2ZywgXCJyeFwiLCAwKTtcbiAgICAgIHJ5ID0gcGFyc2VTVkdGbG9hdEF0dHJpYnV0ZShzdmcsIFwicnlcIiwgMCk7XG4gICAgICBzZXNzaW9uLmNvbnRleHQuYmVnaW5QYXRoKCk7XG4gICAgICBzZXNzaW9uLmNvbnRleHQuZWxsaXBzZShjeCwgY3ksIHJ4LCByeSk7XG4gICAgICBpZiAoZmlsbFN0eWxlKSBzZXNzaW9uLmNvbnRleHQuZmlsbChmaWxsU3R5bGUpO1xuICAgICAgaWYgKHN0cm9rZVN0eWxlKSBzZXNzaW9uLmNvbnRleHQuc3Ryb2tlKHN0cm9rZVN0eWxlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJsaW5lXCI6XG4gICAgICB4MSA9IHBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUoc3ZnLCBcIngxXCIsIDApO1xuICAgICAgeTEgPSBwYXJzZVNWR0Zsb2F0QXR0cmlidXRlKHN2ZywgXCJ5MVwiLCAwKTtcbiAgICAgIHgyID0gcGFyc2VTVkdGbG9hdEF0dHJpYnV0ZShzdmcsIFwieDJcIiwgMCk7XG4gICAgICB5MiA9IHBhcnNlU1ZHRmxvYXRBdHRyaWJ1dGUoc3ZnLCBcInkyXCIsIDApO1xuICAgICAgc2Vzc2lvbi5jb250ZXh0LmJlZ2luUGF0aCgpO1xuICAgICAgc2Vzc2lvbi5jb250ZXh0Lm1vdmVUbyh4MSwgeTEpO1xuICAgICAgc2Vzc2lvbi5jb250ZXh0LmxpbmVUbyh4MiwgeTIpO1xuICAgICAgaWYgKHN0cm9rZVN0eWxlKSBzZXNzaW9uLmNvbnRleHQuc3Ryb2tlKHN0cm9rZVN0eWxlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJwb2x5Z29uXCI6XG4gICAgICBwb2ludHNTdHJpbmcgPSBzdmcuZ2V0QXR0cmlidXRlKFwicG9pbnRzXCIpO1xuICAgICAgcG9pbnRzID0gcG9pbnRzU3RyaW5nLm1hdGNoKC8tP1xcZCsvZykubWFwKChuKSA9PiBwYXJzZUludChuLCAxMCkpO1xuICAgICAgc2Vzc2lvbi5jb250ZXh0LnBvbHkocG9pbnRzLCB0cnVlKTtcbiAgICAgIGlmIChmaWxsU3R5bGUpIHNlc3Npb24uY29udGV4dC5maWxsKGZpbGxTdHlsZSk7XG4gICAgICBpZiAoc3Ryb2tlU3R5bGUpIHNlc3Npb24uY29udGV4dC5zdHJva2Uoc3Ryb2tlU3R5bGUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInBvbHlsaW5lXCI6XG4gICAgICBwb2ludHNTdHJpbmcgPSBzdmcuZ2V0QXR0cmlidXRlKFwicG9pbnRzXCIpO1xuICAgICAgcG9pbnRzID0gcG9pbnRzU3RyaW5nLm1hdGNoKC8tP1xcZCsvZykubWFwKChuKSA9PiBwYXJzZUludChuLCAxMCkpO1xuICAgICAgc2Vzc2lvbi5jb250ZXh0LnBvbHkocG9pbnRzLCBmYWxzZSk7XG4gICAgICBpZiAoc3Ryb2tlU3R5bGUpIHNlc3Npb24uY29udGV4dC5zdHJva2Uoc3Ryb2tlU3R5bGUpO1xuICAgICAgYnJlYWs7XG4gICAgLy8gR3JvdXAgZWxlbWVudHMgLSBqdXN0IHByb2Nlc3MgY2hpbGRyZW5cbiAgICBjYXNlIFwiZ1wiOlxuICAgIGNhc2UgXCJzdmdcIjpcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6IHtcbiAgICAgIHdhcm4oYFtTVkcgcGFyc2VyXSA8JHtzdmcubm9kZU5hbWV9PiBlbGVtZW50cyB1bnN1cHBvcnRlZGApO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIGlmIChub1N0eWxlKSB7XG4gICAgZmlsbFN0eWxlID0gbnVsbDtcbiAgfVxuICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgcmVuZGVyQ2hpbGRyZW4oY2hpbGRyZW5baV0sIHNlc3Npb24sIGZpbGxTdHlsZSwgc3Ryb2tlU3R5bGUpO1xuICB9XG59XG5cbmV4cG9ydCB7IFNWR1BhcnNlciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9U1ZHUGFyc2VyLm1qcy5tYXBcbiIsImltcG9ydCB7IE1hdHJpeCB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL21hdHJpeC9NYXRyaXgubWpzJztcbmltcG9ydCB7IHVpZCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGEvdWlkLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gaXNGaWxsUGF0dGVybk9wdGlvbnModmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlLnRleHR1cmUgIT09IHZvaWQgMDtcbn1cbmNvbnN0IHJlcGV0aXRpb25NYXAgPSB7XG4gIHJlcGVhdDoge1xuICAgIGFkZHJlc3NNb2RlVTogXCJyZXBlYXRcIixcbiAgICBhZGRyZXNzTW9kZVY6IFwicmVwZWF0XCJcbiAgfSxcbiAgXCJyZXBlYXQteFwiOiB7XG4gICAgYWRkcmVzc01vZGVVOiBcInJlcGVhdFwiLFxuICAgIGFkZHJlc3NNb2RlVjogXCJjbGFtcC10by1lZGdlXCJcbiAgfSxcbiAgXCJyZXBlYXQteVwiOiB7XG4gICAgYWRkcmVzc01vZGVVOiBcImNsYW1wLXRvLWVkZ2VcIixcbiAgICBhZGRyZXNzTW9kZVY6IFwicmVwZWF0XCJcbiAgfSxcbiAgXCJuby1yZXBlYXRcIjoge1xuICAgIGFkZHJlc3NNb2RlVTogXCJjbGFtcC10by1lZGdlXCIsXG4gICAgYWRkcmVzc01vZGVWOiBcImNsYW1wLXRvLWVkZ2VcIlxuICB9XG59O1xuY2xhc3MgRmlsbFBhdHRlcm4ge1xuICBjb25zdHJ1Y3Rvcih0ZXh0dXJlT3JPcHRpb25zLCByZXBldGl0aW9uKSB7XG4gICAgLyoqXG4gICAgICogdW5pcXVlIGlkIGZvciB0aGlzIGZpbGwgcGF0dGVyblxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMudWlkID0gdWlkKFwiZmlsbFBhdHRlcm5cIik7XG4gICAgLyoqXG4gICAgICogSW50ZXJuYWwgdGljayBjb3VudGVyIHRvIHRyYWNrIGNoYW5nZXMgaW4gdGhlIHBhdHRlcm4uXG4gICAgICogVGhpcyBpcyB1c2VkIHRvIGludmFsaWRhdGUgdGhlIHBhdHRlcm4gd2hlbiB0aGUgdGV4dHVyZSBvciB0cmFuc2Zvcm0gY2hhbmdlcy5cbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl90aWNrID0gMDtcbiAgICAvKiogVGhlIHRyYW5zZm9ybSBtYXRyaXggYXBwbGllZCB0byB0aGUgcGF0dGVybiAqL1xuICAgIHRoaXMudHJhbnNmb3JtID0gbmV3IE1hdHJpeCgpO1xuICAgIGNvbnN0IG9wdGlvbnMgPSBpc0ZpbGxQYXR0ZXJuT3B0aW9ucyh0ZXh0dXJlT3JPcHRpb25zKSA/IHRleHR1cmVPck9wdGlvbnMgOiB7IHRleHR1cmU6IHRleHR1cmVPck9wdGlvbnMsIHJlcGV0aXRpb24gfTtcbiAgICB0aGlzLnRleHR1cmUgPSBvcHRpb25zLnRleHR1cmU7XG4gICAgdGhpcy50ZXh0dXJlU3BhY2UgPSBvcHRpb25zLnRleHR1cmVTcGFjZSA/PyBcImdsb2JhbFwiO1xuICAgIGNvbnN0IHJlcCA9IG9wdGlvbnMucmVwZXRpdGlvbjtcbiAgICBpZiAocmVwKSB7XG4gICAgICB0aGlzLnRleHR1cmUuc291cmNlLnN0eWxlLmFkZHJlc3NNb2RlVSA9IHJlcGV0aXRpb25NYXBbcmVwXS5hZGRyZXNzTW9kZVU7XG4gICAgICB0aGlzLnRleHR1cmUuc291cmNlLnN0eWxlLmFkZHJlc3NNb2RlViA9IHJlcGV0aXRpb25NYXBbcmVwXS5hZGRyZXNzTW9kZVY7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBTZXRzIHRoZSB0cmFuc2Zvcm0gZm9yIHRoZSBwYXR0ZXJuXG4gICAqIEBwYXJhbSB0cmFuc2Zvcm0gLSBUaGUgdHJhbnNmb3JtIG1hdHJpeCB0byBhcHBseSB0byB0aGUgcGF0dGVybi5cbiAgICogSWYgbm90IHByb3ZpZGVkLCB0aGUgcGF0dGVybiB3aWxsIHVzZSB0aGUgZGVmYXVsdCB0cmFuc2Zvcm0uXG4gICAqL1xuICBzZXRUcmFuc2Zvcm0odHJhbnNmb3JtKSB7XG4gICAgaWYgKHRyYW5zZm9ybSkge1xuICAgICAgaWYgKHRoaXMudHJhbnNmb3JtLmVxdWFscyh0cmFuc2Zvcm0pKSByZXR1cm47XG4gICAgICB0aGlzLnRyYW5zZm9ybS5jb3B5RnJvbSh0cmFuc2Zvcm0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAodGhpcy50cmFuc2Zvcm0uaXNJZGVudGl0eSgpKSByZXR1cm47XG4gICAgICB0aGlzLnRyYW5zZm9ybS5pZGVudGl0eSgpO1xuICAgIH1cbiAgICB0aGlzLl90aWNrKys7XG4gIH1cbiAgLyoqIEludGVybmFsIHRleHR1cmUgdXNlZCB0byByZW5kZXIgdGhlIGdyYWRpZW50ICovXG4gIGdldCB0ZXh0dXJlKCkge1xuICAgIHJldHVybiB0aGlzLl90ZXh0dXJlO1xuICB9XG4gIHNldCB0ZXh0dXJlKHZhbHVlKSB7XG4gICAgaWYgKHRoaXMuX3RleHR1cmUgPT09IHZhbHVlKSByZXR1cm47XG4gICAgdGhpcy5fdGV4dHVyZSA9IHZhbHVlO1xuICAgIHRoaXMuX3RpY2srKztcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhIHVuaXF1ZSBrZXkgZm9yIHRoaXMgaW5zdGFuY2UuXG4gICAqIFRoaXMga2V5IGlzIHVzZWQgZm9yIGNhY2hpbmcuXG4gICAqIEByZXR1cm5zIHtzdHJpbmd9IFVuaXF1ZSBrZXkgZm9yIHRoZSBpbnN0YW5jZVxuICAgKi9cbiAgZ2V0IHN0eWxlS2V5KCkge1xuICAgIHJldHVybiBgZmlsbC1wYXR0ZXJuLSR7dGhpcy51aWR9LSR7dGhpcy5fdGlja31gO1xuICB9XG4gIC8qKiBEZXN0cm95cyB0aGUgZmlsbCBwYXR0ZXJuLCByZWxlYXNpbmcgcmVzb3VyY2VzLiBUaGlzIHdpbGwgYWxzbyBkZXN0cm95IHRoZSBpbnRlcm5hbCB0ZXh0dXJlLiAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMudGV4dHVyZS5kZXN0cm95KHRydWUpO1xuICAgIHRoaXMudGV4dHVyZSA9IG51bGw7XG4gIH1cbn1cblxuZXhwb3J0IHsgRmlsbFBhdHRlcm4gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUZpbGxQYXR0ZXJuLm1qcy5tYXBcbiIsImltcG9ydCB7IENvbG9yIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29sb3IvQ29sb3IubWpzJztcbmltcG9ydCB7IFRleHR1cmUgfSBmcm9tICcuLi8uLi8uLi8uLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL1RleHR1cmUubWpzJztcbmltcG9ydCB7IEZpbGxHcmFkaWVudCB9IGZyb20gJy4uL2ZpbGwvRmlsbEdyYWRpZW50Lm1qcyc7XG5pbXBvcnQgeyBGaWxsUGF0dGVybiB9IGZyb20gJy4uL2ZpbGwvRmlsbFBhdHRlcm4ubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBpc0NvbG9yTGlrZSh2YWx1ZSkge1xuICByZXR1cm4gQ29sb3IuaXNDb2xvckxpa2UodmFsdWUpO1xufVxuZnVuY3Rpb24gaXNGaWxsUGF0dGVybih2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBGaWxsUGF0dGVybjtcbn1cbmZ1bmN0aW9uIGlzRmlsbEdyYWRpZW50KHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIEZpbGxHcmFkaWVudDtcbn1cbmZ1bmN0aW9uIGlzVGV4dHVyZSh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBUZXh0dXJlO1xufVxuZnVuY3Rpb24gaGFuZGxlQ29sb3JMaWtlKGZpbGwsIHZhbHVlLCBkZWZhdWx0U3R5bGUpIHtcbiAgY29uc3QgdGVtcCA9IENvbG9yLnNoYXJlZC5zZXRWYWx1ZSh2YWx1ZSA/PyAwKTtcbiAgZmlsbC5jb2xvciA9IHRlbXAudG9OdW1iZXIoKTtcbiAgZmlsbC5hbHBoYSA9IHRlbXAuYWxwaGEgPT09IDEgPyBkZWZhdWx0U3R5bGUuYWxwaGEgOiB0ZW1wLmFscGhhO1xuICBmaWxsLnRleHR1cmUgPSBUZXh0dXJlLldISVRFO1xuICByZXR1cm4geyAuLi5kZWZhdWx0U3R5bGUsIC4uLmZpbGwgfTtcbn1cbmZ1bmN0aW9uIGhhbmRsZVRleHR1cmUoZmlsbCwgdmFsdWUsIGRlZmF1bHRTdHlsZSkge1xuICBmaWxsLnRleHR1cmUgPSB2YWx1ZTtcbiAgcmV0dXJuIHsgLi4uZGVmYXVsdFN0eWxlLCAuLi5maWxsIH07XG59XG5mdW5jdGlvbiBoYW5kbGVGaWxsUGF0dGVybihmaWxsLCB2YWx1ZSwgZGVmYXVsdFN0eWxlKSB7XG4gIGZpbGwuZmlsbCA9IHZhbHVlO1xuICBmaWxsLmNvbG9yID0gMTY3NzcyMTU7XG4gIGZpbGwudGV4dHVyZSA9IHZhbHVlLnRleHR1cmU7XG4gIGZpbGwubWF0cml4ID0gdmFsdWUudHJhbnNmb3JtO1xuICBmaWxsLnRleHR1cmVTcGFjZSA9IHZhbHVlLnRleHR1cmVTcGFjZTtcbiAgcmV0dXJuIHsgLi4uZGVmYXVsdFN0eWxlLCAuLi5maWxsIH07XG59XG5mdW5jdGlvbiBoYW5kbGVGaWxsR3JhZGllbnQoZmlsbCwgdmFsdWUsIGRlZmF1bHRTdHlsZSkge1xuICB2YWx1ZS5idWlsZEdyYWRpZW50KCk7XG4gIGZpbGwuZmlsbCA9IHZhbHVlO1xuICBmaWxsLmNvbG9yID0gMTY3NzcyMTU7XG4gIGZpbGwudGV4dHVyZSA9IHZhbHVlLnRleHR1cmU7XG4gIGZpbGwubWF0cml4ID0gdmFsdWUudHJhbnNmb3JtO1xuICBmaWxsLnRleHR1cmVTcGFjZSA9IHZhbHVlLnRleHR1cmVTcGFjZTtcbiAgcmV0dXJuIHsgLi4uZGVmYXVsdFN0eWxlLCAuLi5maWxsIH07XG59XG5mdW5jdGlvbiBoYW5kbGVGaWxsT2JqZWN0KHZhbHVlLCBkZWZhdWx0U3R5bGUpIHtcbiAgY29uc3Qgc3R5bGUgPSB7IC4uLmRlZmF1bHRTdHlsZSwgLi4udmFsdWUgfTtcbiAgY29uc3QgY29sb3IgPSBDb2xvci5zaGFyZWQuc2V0VmFsdWUoc3R5bGUuY29sb3IpO1xuICBzdHlsZS5hbHBoYSAqPSBjb2xvci5hbHBoYTtcbiAgc3R5bGUuY29sb3IgPSBjb2xvci50b051bWJlcigpO1xuICByZXR1cm4gc3R5bGU7XG59XG5mdW5jdGlvbiB0b0ZpbGxTdHlsZSh2YWx1ZSwgZGVmYXVsdFN0eWxlKSB7XG4gIGlmICh2YWx1ZSA9PT0gdm9pZCAwIHx8IHZhbHVlID09PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgZmlsbCA9IHt9O1xuICBjb25zdCBvYmplY3RTdHlsZSA9IHZhbHVlO1xuICBpZiAoaXNDb2xvckxpa2UodmFsdWUpKSB7XG4gICAgcmV0dXJuIGhhbmRsZUNvbG9yTGlrZShmaWxsLCB2YWx1ZSwgZGVmYXVsdFN0eWxlKTtcbiAgfSBlbHNlIGlmIChpc1RleHR1cmUodmFsdWUpKSB7XG4gICAgcmV0dXJuIGhhbmRsZVRleHR1cmUoZmlsbCwgdmFsdWUsIGRlZmF1bHRTdHlsZSk7XG4gIH0gZWxzZSBpZiAoaXNGaWxsUGF0dGVybih2YWx1ZSkpIHtcbiAgICByZXR1cm4gaGFuZGxlRmlsbFBhdHRlcm4oZmlsbCwgdmFsdWUsIGRlZmF1bHRTdHlsZSk7XG4gIH0gZWxzZSBpZiAoaXNGaWxsR3JhZGllbnQodmFsdWUpKSB7XG4gICAgcmV0dXJuIGhhbmRsZUZpbGxHcmFkaWVudChmaWxsLCB2YWx1ZSwgZGVmYXVsdFN0eWxlKTtcbiAgfSBlbHNlIGlmIChvYmplY3RTdHlsZS5maWxsICYmIGlzRmlsbFBhdHRlcm4ob2JqZWN0U3R5bGUuZmlsbCkpIHtcbiAgICByZXR1cm4gaGFuZGxlRmlsbFBhdHRlcm4ob2JqZWN0U3R5bGUsIG9iamVjdFN0eWxlLmZpbGwsIGRlZmF1bHRTdHlsZSk7XG4gIH0gZWxzZSBpZiAob2JqZWN0U3R5bGUuZmlsbCAmJiBpc0ZpbGxHcmFkaWVudChvYmplY3RTdHlsZS5maWxsKSkge1xuICAgIHJldHVybiBoYW5kbGVGaWxsR3JhZGllbnQob2JqZWN0U3R5bGUsIG9iamVjdFN0eWxlLmZpbGwsIGRlZmF1bHRTdHlsZSk7XG4gIH1cbiAgcmV0dXJuIGhhbmRsZUZpbGxPYmplY3Qob2JqZWN0U3R5bGUsIGRlZmF1bHRTdHlsZSk7XG59XG5mdW5jdGlvbiB0b1N0cm9rZVN0eWxlKHZhbHVlLCBkZWZhdWx0U3R5bGUpIHtcbiAgY29uc3QgeyB3aWR0aCwgYWxpZ25tZW50LCBtaXRlckxpbWl0LCBjYXAsIGpvaW4sIHBpeGVsTGluZSwgLi4ucmVzdCB9ID0gZGVmYXVsdFN0eWxlO1xuICBjb25zdCBmaWxsID0gdG9GaWxsU3R5bGUodmFsdWUsIHJlc3QpO1xuICBpZiAoIWZpbGwpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4ge1xuICAgIHdpZHRoLFxuICAgIGFsaWdubWVudCxcbiAgICBtaXRlckxpbWl0LFxuICAgIGNhcCxcbiAgICBqb2luLFxuICAgIHBpeGVsTGluZSxcbiAgICAuLi5maWxsXG4gIH07XG59XG5cbmV4cG9ydCB7IHRvRmlsbFN0eWxlLCB0b1N0cm9rZVN0eWxlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb252ZXJ0RmlsbElucHV0VG9GaWxsU3R5bGUubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBnZXRNYXhNaXRlclJhdGlvKHBhdGgsIG1pdGVyTGltaXQpIHtcbiAgbGV0IG1heFJhdGlvID0gMTtcbiAgY29uc3Qgc2hhcGVQcmltaXRpdmVzID0gcGF0aC5zaGFwZVBhdGguc2hhcGVQcmltaXRpdmVzO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHNoYXBlUHJpbWl0aXZlcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IHNoYXBlID0gc2hhcGVQcmltaXRpdmVzW2ldLnNoYXBlO1xuICAgIGlmIChzaGFwZS50eXBlICE9PSBcInBvbHlnb25cIikgY29udGludWU7XG4gICAgY29uc3QgcG9pbnRzID0gc2hhcGUucG9pbnRzO1xuICAgIGNvbnN0IG4gPSBwb2ludHMubGVuZ3RoO1xuICAgIGlmIChuIDwgNikgY29udGludWU7XG4gICAgY29uc3QgY2xvc2VkID0gc2hhcGUuY2xvc2VQYXRoO1xuICAgIGZvciAobGV0IGogPSAwOyBqIDwgbjsgaiArPSAyKSB7XG4gICAgICBpZiAoIWNsb3NlZCAmJiAoaiA9PT0gMCB8fCBqID09PSBuIC0gMikpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgcHJldklkeCA9IChqIC0gMiArIG4pICUgbjtcbiAgICAgIGNvbnN0IG5leHRJZHggPSAoaiArIDIpICUgbjtcbiAgICAgIGNvbnN0IHgwID0gcG9pbnRzW3ByZXZJZHhdO1xuICAgICAgY29uc3QgeTAgPSBwb2ludHNbcHJldklkeCArIDFdO1xuICAgICAgY29uc3QgeDEgPSBwb2ludHNbal07XG4gICAgICBjb25zdCB5MSA9IHBvaW50c1tqICsgMV07XG4gICAgICBjb25zdCB4MiA9IHBvaW50c1tuZXh0SWR4XTtcbiAgICAgIGNvbnN0IHkyID0gcG9pbnRzW25leHRJZHggKyAxXTtcbiAgICAgIGNvbnN0IGR4MCA9IHgwIC0geDE7XG4gICAgICBjb25zdCBkeTAgPSB5MCAtIHkxO1xuICAgICAgY29uc3QgZHgxID0geDIgLSB4MTtcbiAgICAgIGNvbnN0IGR5MSA9IHkyIC0geTE7XG4gICAgICBjb25zdCBsZW4wU3EgPSBkeDAgKiBkeDAgKyBkeTAgKiBkeTA7XG4gICAgICBjb25zdCBsZW4xU3EgPSBkeDEgKiBkeDEgKyBkeTEgKiBkeTE7XG4gICAgICBpZiAobGVuMFNxIDwgMWUtMTIgfHwgbGVuMVNxIDwgMWUtMTIpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgZG90ID0gZHgwICogZHgxICsgZHkwICogZHkxO1xuICAgICAgY29uc3QgY29zQW5nbGUgPSBkb3QgLyBNYXRoLnNxcnQobGVuMFNxICogbGVuMVNxKTtcbiAgICAgIGxldCBjbGFtcGVkQ29zID0gY29zQW5nbGU7XG4gICAgICBpZiAoY2xhbXBlZENvcyA8IC0xKSBjbGFtcGVkQ29zID0gLTE7XG4gICAgICBlbHNlIGlmIChjbGFtcGVkQ29zID4gMSkgY2xhbXBlZENvcyA9IDE7XG4gICAgICBjb25zdCBzaW5IYWxmQW5nbGUgPSBNYXRoLnNxcnQoKDEgLSBjbGFtcGVkQ29zKSAqIDAuNSk7XG4gICAgICBpZiAoc2luSGFsZkFuZ2xlIDwgMWUtNikgY29udGludWU7XG4gICAgICBjb25zdCBtaXRlclJhdGlvID0gTWF0aC5taW4oMSAvIHNpbkhhbGZBbmdsZSwgbWl0ZXJMaW1pdCk7XG4gICAgICBpZiAobWl0ZXJSYXRpbyA+IG1heFJhdGlvKSBtYXhSYXRpbyA9IG1pdGVyUmF0aW87XG4gICAgfVxuICB9XG4gIHJldHVybiBtYXhSYXRpbztcbn1cblxuZXhwb3J0IHsgZ2V0TWF4TWl0ZXJSYXRpbyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Z2V0TWF4TWl0ZXJSYXRpby5tanMubWFwXG4iLCJpbXBvcnQgRXZlbnRFbWl0dGVyIGZyb20gJ2V2ZW50ZW1pdHRlcjMnO1xuaW1wb3J0IHsgQ29sb3IgfSBmcm9tICcuLi8uLi8uLi9jb2xvci9Db2xvci5tanMnO1xuaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgUG9pbnQgfSBmcm9tICcuLi8uLi8uLi9tYXRocy9wb2ludC9Qb2ludC5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4uLy4uLy4uL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvVGV4dHVyZS5tanMnO1xuaW1wb3J0IHsgdWlkIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvZGF0YS91aWQubWpzJztcbmltcG9ydCB7IGRlcHJlY2F0aW9uLCB2OF8wXzAgfSBmcm9tICcuLi8uLi8uLi91dGlscy9sb2dnaW5nL2RlcHJlY2F0aW9uLm1qcyc7XG5pbXBvcnQgeyBCb3VuZHMgfSBmcm9tICcuLi8uLi9jb250YWluZXIvYm91bmRzL0JvdW5kcy5tanMnO1xuaW1wb3J0IHsgR3JhcGhpY3NQYXRoIH0gZnJvbSAnLi9wYXRoL0dyYXBoaWNzUGF0aC5tanMnO1xuaW1wb3J0IHsgU1ZHUGFyc2VyIH0gZnJvbSAnLi9zdmcvU1ZHUGFyc2VyLm1qcyc7XG5pbXBvcnQgeyB0b0ZpbGxTdHlsZSwgdG9TdHJva2VTdHlsZSB9IGZyb20gJy4vdXRpbHMvY29udmVydEZpbGxJbnB1dFRvRmlsbFN0eWxlLm1qcyc7XG5pbXBvcnQgeyBnZXRNYXhNaXRlclJhdGlvIH0gZnJvbSAnLi91dGlscy9nZXRNYXhNaXRlclJhdGlvLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgdG1wUG9pbnQgPSBuZXcgUG9pbnQoKTtcbmNvbnN0IHRlbXBNYXRyaXggPSBuZXcgTWF0cml4KCk7XG5jb25zdCBfR3JhcGhpY3NDb250ZXh0ID0gY2xhc3MgX0dyYXBoaWNzQ29udGV4dCBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuX2dwdURhdGEgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAvKiogSWYgc2V0IHRvIHRydWUsIHRoZSByZXNvdXJjZSB3aWxsIGJlIGdhcmJhZ2UgY29sbGVjdGVkIGF1dG9tYXRpY2FsbHkgd2hlbiBpdCBpcyBub3QgdXNlZC4gKi9cbiAgICB0aGlzLmF1dG9HYXJiYWdlQ29sbGVjdCA9IHRydWU7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuX2djTGFzdFVzZWQgPSAtMTtcbiAgICAvKipcbiAgICAgKiB1bmlxdWUgaWQgZm9yIHRoaXMgZ3JhcGhpY3MgY29udGV4dFxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMudWlkID0gdWlkKFwiZ3JhcGhpY3NDb250ZXh0XCIpO1xuICAgIC8qKlxuICAgICAqIEluZGljYXRlcyB3aGV0aGVyIGNvbnRlbnQgaXMgdXBkYXRlZCBhbmQgaGF2ZSB0byBiZSByZS1yZW5kZXJlZC5cbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLmRpcnR5ID0gdHJ1ZTtcbiAgICAvKiogVGhlIGJhdGNoIG1vZGUgZm9yIHRoaXMgZ3JhcGhpY3MgY29udGV4dC4gSXQgY2FuIGJlICdhdXRvJywgJ2JhdGNoJywgb3IgJ25vLWJhdGNoJy4gKi9cbiAgICB0aGlzLmJhdGNoTW9kZSA9IFwiYXV0b1wiO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLmluc3RydWN0aW9ucyA9IFtdO1xuICAgIC8qKiBXaGV0aGVyIHRoZSBncmFwaGljcyBjb250ZXh0IGhhcyBiZWVuIGRlc3Ryb3llZC4gKi9cbiAgICB0aGlzLmRlc3Ryb3llZCA9IGZhbHNlO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGggPSBuZXcgR3JhcGhpY3NQYXRoKCk7XG4gICAgdGhpcy5fdHJhbnNmb3JtID0gbmV3IE1hdHJpeCgpO1xuICAgIHRoaXMuX2ZpbGxTdHlsZSA9IHsgLi4uX0dyYXBoaWNzQ29udGV4dC5kZWZhdWx0RmlsbFN0eWxlIH07XG4gICAgdGhpcy5fc3Ryb2tlU3R5bGUgPSB7IC4uLl9HcmFwaGljc0NvbnRleHQuZGVmYXVsdFN0cm9rZVN0eWxlIH07XG4gICAgdGhpcy5fc3RhdGVTdGFjayA9IFtdO1xuICAgIHRoaXMuX3RpY2sgPSAwO1xuICAgIHRoaXMuX2JvdW5kcyA9IG5ldyBCb3VuZHMoKTtcbiAgICB0aGlzLl9ib3VuZHNEaXJ0eSA9IHRydWU7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgR3JhcGhpY3NDb250ZXh0IG9iamVjdCB0aGF0IGlzIGEgY2xvbmUgb2YgdGhpcyBpbnN0YW5jZSwgY29weWluZyBhbGwgcHJvcGVydGllcyxcbiAgICogaW5jbHVkaW5nIHRoZSBjdXJyZW50IGRyYXdpbmcgc3RhdGUsIHRyYW5zZm9ybWF0aW9ucywgc3R5bGVzLCBhbmQgaW5zdHJ1Y3Rpb25zLlxuICAgKiBAcmV0dXJucyBBIG5ldyBHcmFwaGljc0NvbnRleHQgaW5zdGFuY2Ugd2l0aCB0aGUgc2FtZSBwcm9wZXJ0aWVzIGFuZCBzdGF0ZSBhcyB0aGlzIG9uZS5cbiAgICovXG4gIGNsb25lKCkge1xuICAgIGNvbnN0IGNsb25lID0gbmV3IF9HcmFwaGljc0NvbnRleHQoKTtcbiAgICBjbG9uZS5iYXRjaE1vZGUgPSB0aGlzLmJhdGNoTW9kZTtcbiAgICBjbG9uZS5pbnN0cnVjdGlvbnMgPSB0aGlzLmluc3RydWN0aW9ucy5zbGljZSgpO1xuICAgIGNsb25lLl9hY3RpdmVQYXRoID0gdGhpcy5fYWN0aXZlUGF0aC5jbG9uZSgpO1xuICAgIGNsb25lLl90cmFuc2Zvcm0gPSB0aGlzLl90cmFuc2Zvcm0uY2xvbmUoKTtcbiAgICBjbG9uZS5fZmlsbFN0eWxlID0geyAuLi50aGlzLl9maWxsU3R5bGUgfTtcbiAgICBjbG9uZS5fc3Ryb2tlU3R5bGUgPSB7IC4uLnRoaXMuX3N0cm9rZVN0eWxlIH07XG4gICAgY2xvbmUuX3N0YXRlU3RhY2sgPSB0aGlzLl9zdGF0ZVN0YWNrLnNsaWNlKCk7XG4gICAgY2xvbmUuX2JvdW5kcyA9IHRoaXMuX2JvdW5kcy5jbG9uZSgpO1xuICAgIGNsb25lLl9ib3VuZHNEaXJ0eSA9IHRydWU7XG4gICAgcmV0dXJuIGNsb25lO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgY3VycmVudCBmaWxsIHN0eWxlIG9mIHRoZSBncmFwaGljcyBjb250ZXh0LiBUaGlzIGNhbiBiZSBhIGNvbG9yLCBncmFkaWVudCwgcGF0dGVybiwgb3IgYSBtb3JlIGNvbXBsZXggc3R5bGUgZGVmaW5lZCBieSBhIEZpbGxTdHlsZSBvYmplY3QuXG4gICAqL1xuICBnZXQgZmlsbFN0eWxlKCkge1xuICAgIHJldHVybiB0aGlzLl9maWxsU3R5bGU7XG4gIH1cbiAgc2V0IGZpbGxTdHlsZSh2YWx1ZSkge1xuICAgIHRoaXMuX2ZpbGxTdHlsZSA9IHRvRmlsbFN0eWxlKHZhbHVlLCBfR3JhcGhpY3NDb250ZXh0LmRlZmF1bHRGaWxsU3R5bGUpO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgY3VycmVudCBzdHJva2Ugc3R5bGUgb2YgdGhlIGdyYXBoaWNzIGNvbnRleHQuIFNpbWlsYXIgdG8gZmlsbCBzdHlsZXMsIHN0cm9rZSBzdHlsZXMgY2FuIGVuY29tcGFzcyBjb2xvcnMsIGdyYWRpZW50cywgcGF0dGVybnMsIG9yIG1vcmUgZGV0YWlsZWQgY29uZmlndXJhdGlvbnMgdmlhIGEgU3Ryb2tlU3R5bGUgb2JqZWN0LlxuICAgKi9cbiAgZ2V0IHN0cm9rZVN0eWxlKCkge1xuICAgIHJldHVybiB0aGlzLl9zdHJva2VTdHlsZTtcbiAgfVxuICBzZXQgc3Ryb2tlU3R5bGUodmFsdWUpIHtcbiAgICB0aGlzLl9zdHJva2VTdHlsZSA9IHRvU3Ryb2tlU3R5bGUodmFsdWUsIF9HcmFwaGljc0NvbnRleHQuZGVmYXVsdFN0cm9rZVN0eWxlKTtcbiAgfVxuICAvKipcbiAgICogU2V0cyB0aGUgY3VycmVudCBmaWxsIHN0eWxlIG9mIHRoZSBncmFwaGljcyBjb250ZXh0LiBUaGUgZmlsbCBzdHlsZSBjYW4gYmUgYSBjb2xvciwgZ3JhZGllbnQsXG4gICAqIHBhdHRlcm4sIG9yIGEgbW9yZSBjb21wbGV4IHN0eWxlIGRlZmluZWQgYnkgYSBGaWxsU3R5bGUgb2JqZWN0LlxuICAgKiBAcGFyYW0gc3R5bGUgLSBUaGUgZmlsbCBzdHlsZSB0byBhcHBseS4gVGhpcyBjYW4gYmUgYSBzaW1wbGUgY29sb3IsIGEgZ3JhZGllbnQgb3IgcGF0dGVybiBvYmplY3QsXG4gICAqICAgICAgICAgICAgICAgIG9yIGEgRmlsbFN0eWxlIG9yIENvbnZlcnRlZEZpbGxTdHlsZSBvYmplY3QuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBHcmFwaGljc0NvbnRleHQgZm9yIG1ldGhvZCBjaGFpbmluZy5cbiAgICovXG4gIHNldEZpbGxTdHlsZShzdHlsZSkge1xuICAgIHRoaXMuX2ZpbGxTdHlsZSA9IHRvRmlsbFN0eWxlKHN0eWxlLCBfR3JhcGhpY3NDb250ZXh0LmRlZmF1bHRGaWxsU3R5bGUpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBTZXRzIHRoZSBjdXJyZW50IHN0cm9rZSBzdHlsZSBvZiB0aGUgZ3JhcGhpY3MgY29udGV4dC4gU2ltaWxhciB0byBmaWxsIHN0eWxlcywgc3Ryb2tlIHN0eWxlcyBjYW5cbiAgICogZW5jb21wYXNzIGNvbG9ycywgZ3JhZGllbnRzLCBwYXR0ZXJucywgb3IgbW9yZSBkZXRhaWxlZCBjb25maWd1cmF0aW9ucyB2aWEgYSBTdHJva2VTdHlsZSBvYmplY3QuXG4gICAqIEBwYXJhbSBzdHlsZSAtIFRoZSBzdHJva2Ugc3R5bGUgdG8gYXBwbHkuIENhbiBiZSBkZWZpbmVkIGFzIGEgY29sb3IsIGEgZ3JhZGllbnQgb3IgcGF0dGVybixcbiAgICogICAgICAgICAgICAgICAgb3IgYSBTdHJva2VTdHlsZSBvciBDb252ZXJ0ZWRTdHJva2VTdHlsZSBvYmplY3QuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBHcmFwaGljc0NvbnRleHQgZm9yIG1ldGhvZCBjaGFpbmluZy5cbiAgICovXG4gIHNldFN0cm9rZVN0eWxlKHN0eWxlKSB7XG4gICAgdGhpcy5fc3Ryb2tlU3R5bGUgPSB0b0ZpbGxTdHlsZShzdHlsZSwgX0dyYXBoaWNzQ29udGV4dC5kZWZhdWx0U3Ryb2tlU3R5bGUpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIHRleHR1cmUodGV4dHVyZSwgdGludCwgZHgsIGR5LCBkdywgZGgpIHtcbiAgICB0aGlzLmluc3RydWN0aW9ucy5wdXNoKHtcbiAgICAgIGFjdGlvbjogXCJ0ZXh0dXJlXCIsXG4gICAgICBkYXRhOiB7XG4gICAgICAgIGltYWdlOiB0ZXh0dXJlLFxuICAgICAgICBkeDogZHggfHwgMCxcbiAgICAgICAgZHk6IGR5IHx8IDAsXG4gICAgICAgIGR3OiBkdyB8fCB0ZXh0dXJlLmZyYW1lLndpZHRoLFxuICAgICAgICBkaDogZGggfHwgdGV4dHVyZS5mcmFtZS5oZWlnaHQsXG4gICAgICAgIHRyYW5zZm9ybTogdGhpcy5fdHJhbnNmb3JtLmNsb25lKCksXG4gICAgICAgIGFscGhhOiB0aGlzLl9maWxsU3R5bGUuYWxwaGEsXG4gICAgICAgIHN0eWxlOiB0aW50IHx8IHRpbnQgPT09IDAgPyBDb2xvci5zaGFyZWQuc2V0VmFsdWUodGludCkudG9OdW1iZXIoKSA6IDE2Nzc3MjE1XG4gICAgICB9XG4gICAgfSk7XG4gICAgdGhpcy5vblVwZGF0ZSgpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBSZXNldHMgdGhlIGN1cnJlbnQgcGF0aC4gQW55IHByZXZpb3VzIHBhdGggYW5kIGl0cyBjb21tYW5kcyBhcmUgZGlzY2FyZGVkIGFuZCBhIG5ldyBwYXRoIGlzXG4gICAqIHN0YXJ0ZWQuIFRoaXMgaXMgdHlwaWNhbGx5IGNhbGxlZCBiZWZvcmUgYmVnaW5uaW5nIGEgbmV3IHNoYXBlIG9yIHNlcmllcyBvZiBkcmF3aW5nIGNvbW1hbmRzLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgR3JhcGhpY3NDb250ZXh0IGZvciBtZXRob2QgY2hhaW5pbmcuXG4gICAqL1xuICBiZWdpblBhdGgoKSB7XG4gICAgdGhpcy5fYWN0aXZlUGF0aCA9IG5ldyBHcmFwaGljc1BhdGgoKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBmaWxsKHN0eWxlLCBhbHBoYSkge1xuICAgIGxldCBwYXRoO1xuICAgIGNvbnN0IGxhc3RJbnN0cnVjdGlvbiA9IHRoaXMuaW5zdHJ1Y3Rpb25zW3RoaXMuaW5zdHJ1Y3Rpb25zLmxlbmd0aCAtIDFdO1xuICAgIGlmICh0aGlzLl90aWNrID09PSAwICYmIGxhc3RJbnN0cnVjdGlvbj8uYWN0aW9uID09PSBcInN0cm9rZVwiKSB7XG4gICAgICBwYXRoID0gbGFzdEluc3RydWN0aW9uLmRhdGEucGF0aDtcbiAgICB9IGVsc2Uge1xuICAgICAgcGF0aCA9IHRoaXMuX2FjdGl2ZVBhdGguY2xvbmUoKTtcbiAgICB9XG4gICAgaWYgKCFwYXRoKSByZXR1cm4gdGhpcztcbiAgICBpZiAoc3R5bGUgIT0gbnVsbCkge1xuICAgICAgaWYgKGFscGhhICE9PSB2b2lkIDAgJiYgdHlwZW9mIHN0eWxlID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgIGRlcHJlY2F0aW9uKHY4XzBfMCwgXCJHcmFwaGljc0NvbnRleHQuZmlsbChjb2xvciwgYWxwaGEpIGlzIGRlcHJlY2F0ZWQsIHVzZSBHcmFwaGljc0NvbnRleHQuZmlsbCh7IGNvbG9yLCBhbHBoYSB9KSBpbnN0ZWFkXCIpO1xuICAgICAgICBzdHlsZSA9IHsgY29sb3I6IHN0eWxlLCBhbHBoYSB9O1xuICAgICAgfVxuICAgICAgdGhpcy5fZmlsbFN0eWxlID0gdG9GaWxsU3R5bGUoc3R5bGUsIF9HcmFwaGljc0NvbnRleHQuZGVmYXVsdEZpbGxTdHlsZSk7XG4gICAgfVxuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goe1xuICAgICAgYWN0aW9uOiBcImZpbGxcIixcbiAgICAgIC8vIFRPRE8gY29weSBmaWxsIHN0eWxlIVxuICAgICAgZGF0YTogeyBzdHlsZTogdGhpcy5maWxsU3R5bGUsIHBhdGggfVxuICAgIH0pO1xuICAgIHRoaXMub25VcGRhdGUoKTtcbiAgICB0aGlzLl9pbml0TmV4dFBhdGhMb2NhdGlvbigpO1xuICAgIHRoaXMuX3RpY2sgPSAwO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIF9pbml0TmV4dFBhdGhMb2NhdGlvbigpIHtcbiAgICBjb25zdCB7IHgsIHkgfSA9IHRoaXMuX2FjdGl2ZVBhdGguZ2V0TGFzdFBvaW50KFBvaW50LnNoYXJlZCk7XG4gICAgdGhpcy5fYWN0aXZlUGF0aC5jbGVhcigpO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGgubW92ZVRvKHgsIHkpO1xuICB9XG4gIC8qKlxuICAgKiBTdHJva2VzIHRoZSBjdXJyZW50IHBhdGggd2l0aCB0aGUgY3VycmVudCBzdHJva2Ugc3R5bGUuIFRoaXMgbWV0aG9kIGNhbiB0YWtlIGFuIG9wdGlvbmFsXG4gICAqIEZpbGxJbnB1dCBwYXJhbWV0ZXIgdG8gZGVmaW5lIHRoZSBzdHJva2UncyBhcHBlYXJhbmNlLCBpbmNsdWRpbmcgaXRzIGNvbG9yLCB3aWR0aCwgYW5kIG90aGVyIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBzdHlsZSAtIChPcHRpb25hbCkgVGhlIHN0cm9rZSBzdHlsZSB0byBhcHBseS4gQ2FuIGJlIGRlZmluZWQgYXMgYSBzaW1wbGUgY29sb3Igb3IgYSBtb3JlIGNvbXBsZXggc3R5bGUgb2JqZWN0LiBJZiBvbWl0dGVkLCB1c2VzIHRoZSBjdXJyZW50IHN0cm9rZSBzdHlsZS5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IEdyYXBoaWNzQ29udGV4dCBmb3IgbWV0aG9kIGNoYWluaW5nLlxuICAgKi9cbiAgc3Ryb2tlKHN0eWxlKSB7XG4gICAgbGV0IHBhdGg7XG4gICAgY29uc3QgbGFzdEluc3RydWN0aW9uID0gdGhpcy5pbnN0cnVjdGlvbnNbdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoIC0gMV07XG4gICAgaWYgKHRoaXMuX3RpY2sgPT09IDAgJiYgbGFzdEluc3RydWN0aW9uPy5hY3Rpb24gPT09IFwiZmlsbFwiKSB7XG4gICAgICBwYXRoID0gbGFzdEluc3RydWN0aW9uLmRhdGEucGF0aDtcbiAgICB9IGVsc2Uge1xuICAgICAgcGF0aCA9IHRoaXMuX2FjdGl2ZVBhdGguY2xvbmUoKTtcbiAgICB9XG4gICAgaWYgKCFwYXRoKSByZXR1cm4gdGhpcztcbiAgICBpZiAoc3R5bGUgIT0gbnVsbCkge1xuICAgICAgdGhpcy5fc3Ryb2tlU3R5bGUgPSB0b1N0cm9rZVN0eWxlKHN0eWxlLCBfR3JhcGhpY3NDb250ZXh0LmRlZmF1bHRTdHJva2VTdHlsZSk7XG4gICAgfVxuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLnB1c2goe1xuICAgICAgYWN0aW9uOiBcInN0cm9rZVwiLFxuICAgICAgLy8gVE9ETyBjb3B5IGZpbGwgc3R5bGUhXG4gICAgICBkYXRhOiB7IHN0eWxlOiB0aGlzLnN0cm9rZVN0eWxlLCBwYXRoIH1cbiAgICB9KTtcbiAgICB0aGlzLm9uVXBkYXRlKCk7XG4gICAgdGhpcy5faW5pdE5leHRQYXRoTG9jYXRpb24oKTtcbiAgICB0aGlzLl90aWNrID0gMDtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQXBwbGllcyBhIGN1dG91dCB0byB0aGUgbGFzdCBkcmF3biBzaGFwZS4gVGhpcyBpcyB1c2VkIHRvIGNyZWF0ZSBob2xlcyBvciBjb21wbGV4IHNoYXBlcyBieVxuICAgKiBzdWJ0cmFjdGluZyBhIHBhdGggZnJvbSB0aGUgcHJldmlvdXNseSBkcmF3biBwYXRoLiBJZiBhIGhvbGUgaXMgbm90IGNvbXBsZXRlbHkgaW4gYSBzaGFwZSwgaXQgd2lsbFxuICAgKiBmYWlsIHRvIGN1dCBjb3JyZWN0bHkhXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBHcmFwaGljc0NvbnRleHQgZm9yIG1ldGhvZCBjaGFpbmluZy5cbiAgICovXG4gIGN1dCgpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDI7IGkrKykge1xuICAgICAgY29uc3QgbGFzdEluc3RydWN0aW9uID0gdGhpcy5pbnN0cnVjdGlvbnNbdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoIC0gMSAtIGldO1xuICAgICAgY29uc3QgaG9sZVBhdGggPSB0aGlzLl9hY3RpdmVQYXRoLmNsb25lKCk7XG4gICAgICBpZiAobGFzdEluc3RydWN0aW9uKSB7XG4gICAgICAgIGlmIChsYXN0SW5zdHJ1Y3Rpb24uYWN0aW9uID09PSBcInN0cm9rZVwiIHx8IGxhc3RJbnN0cnVjdGlvbi5hY3Rpb24gPT09IFwiZmlsbFwiKSB7XG4gICAgICAgICAgaWYgKGxhc3RJbnN0cnVjdGlvbi5kYXRhLmhvbGUpIHtcbiAgICAgICAgICAgIGxhc3RJbnN0cnVjdGlvbi5kYXRhLmhvbGUuYWRkUGF0aChob2xlUGF0aCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGxhc3RJbnN0cnVjdGlvbi5kYXRhLmhvbGUgPSBob2xlUGF0aDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLl9pbml0TmV4dFBhdGhMb2NhdGlvbigpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBBZGRzIGFuIGFyYyB0byB0aGUgY3VycmVudCBwYXRoLCB3aGljaCBpcyBjZW50ZXJlZCBhdCAoeCwgeSkgd2l0aCB0aGUgc3BlY2lmaWVkIHJhZGl1cyxcbiAgICogc3RhcnRpbmcgYW5kIGVuZGluZyBhbmdsZXMsIGFuZCBkaXJlY3Rpb24uXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgYXJjJ3MgY2VudGVyLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGFyYydzIGNlbnRlci5cbiAgICogQHBhcmFtIHJhZGl1cyAtIFRoZSBhcmMncyByYWRpdXMuXG4gICAqIEBwYXJhbSBzdGFydEFuZ2xlIC0gVGhlIHN0YXJ0aW5nIGFuZ2xlLCBpbiByYWRpYW5zLlxuICAgKiBAcGFyYW0gZW5kQW5nbGUgLSBUaGUgZW5kaW5nIGFuZ2xlLCBpbiByYWRpYW5zLlxuICAgKiBAcGFyYW0gY291bnRlcmNsb2Nrd2lzZSAtIChPcHRpb25hbCkgU3BlY2lmaWVzIHdoZXRoZXIgdGhlIGFyYyBpcyBkcmF3biBjb3VudGVyY2xvY2t3aXNlICh0cnVlKSBvciBjbG9ja3dpc2UgKGZhbHNlKS4gRGVmYXVsdHMgdG8gZmFsc2UuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBHcmFwaGljc0NvbnRleHQgZm9yIG1ldGhvZCBjaGFpbmluZy5cbiAgICovXG4gIGFyYyh4LCB5LCByYWRpdXMsIHN0YXJ0QW5nbGUsIGVuZEFuZ2xlLCBjb3VudGVyY2xvY2t3aXNlKSB7XG4gICAgdGhpcy5fdGljaysrO1xuICAgIGNvbnN0IHQgPSB0aGlzLl90cmFuc2Zvcm07XG4gICAgdGhpcy5fYWN0aXZlUGF0aC5hcmMoXG4gICAgICB0LmEgKiB4ICsgdC5jICogeSArIHQudHgsXG4gICAgICB0LmIgKiB4ICsgdC5kICogeSArIHQudHksXG4gICAgICByYWRpdXMsXG4gICAgICBzdGFydEFuZ2xlLFxuICAgICAgZW5kQW5nbGUsXG4gICAgICBjb3VudGVyY2xvY2t3aXNlXG4gICAgKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQWRkcyBhbiBhcmMgdG8gdGhlIGN1cnJlbnQgcGF0aCB3aXRoIHRoZSBnaXZlbiBjb250cm9sIHBvaW50cyBhbmQgcmFkaXVzLCBjb25uZWN0ZWQgdG8gdGhlIHByZXZpb3VzIHBvaW50XG4gICAqIGJ5IGEgc3RyYWlnaHQgbGluZSBpZiBuZWNlc3NhcnkuXG4gICAqIEBwYXJhbSB4MSAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGZpcnN0IGNvbnRyb2wgcG9pbnQuXG4gICAqIEBwYXJhbSB5MSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGZpcnN0IGNvbnRyb2wgcG9pbnQuXG4gICAqIEBwYXJhbSB4MiAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIHNlY29uZCBjb250cm9sIHBvaW50LlxuICAgKiBAcGFyYW0geTIgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBzZWNvbmQgY29udHJvbCBwb2ludC5cbiAgICogQHBhcmFtIHJhZGl1cyAtIFRoZSBhcmMncyByYWRpdXMuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBHcmFwaGljc0NvbnRleHQgZm9yIG1ldGhvZCBjaGFpbmluZy5cbiAgICovXG4gIGFyY1RvKHgxLCB5MSwgeDIsIHkyLCByYWRpdXMpIHtcbiAgICB0aGlzLl90aWNrKys7XG4gICAgY29uc3QgdCA9IHRoaXMuX3RyYW5zZm9ybTtcbiAgICB0aGlzLl9hY3RpdmVQYXRoLmFyY1RvKFxuICAgICAgdC5hICogeDEgKyB0LmMgKiB5MSArIHQudHgsXG4gICAgICB0LmIgKiB4MSArIHQuZCAqIHkxICsgdC50eSxcbiAgICAgIHQuYSAqIHgyICsgdC5jICogeTIgKyB0LnR4LFxuICAgICAgdC5iICogeDIgKyB0LmQgKiB5MiArIHQudHksXG4gICAgICByYWRpdXNcbiAgICApO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBBZGRzIGFuIFNWRy1zdHlsZSBhcmMgdG8gdGhlIHBhdGgsIGFsbG93aW5nIGZvciBlbGxpcHRpY2FsIGFyY3MgYmFzZWQgb24gdGhlIFNWRyBzcGVjLlxuICAgKiBAcGFyYW0gcnggLSBUaGUgeC1yYWRpdXMgb2YgdGhlIGVsbGlwc2UuXG4gICAqIEBwYXJhbSByeSAtIFRoZSB5LXJhZGl1cyBvZiB0aGUgZWxsaXBzZS5cbiAgICogQHBhcmFtIHhBeGlzUm90YXRpb24gLSBUaGUgcm90YXRpb24gb2YgdGhlIGVsbGlwc2UncyB4LWF4aXMgcmVsYXRpdmVcbiAgICogdG8gdGhlIHgtYXhpcyBvZiB0aGUgY29vcmRpbmF0ZSBzeXN0ZW0sIGluIGRlZ3JlZXMuXG4gICAqIEBwYXJhbSBsYXJnZUFyY0ZsYWcgLSBEZXRlcm1pbmVzIGlmIHRoZSBhcmMgc2hvdWxkIGJlIGdyZWF0ZXIgdGhhbiBvciBsZXNzIHRoYW4gMTgwIGRlZ3JlZXMuXG4gICAqIEBwYXJhbSBzd2VlcEZsYWcgLSBEZXRlcm1pbmVzIGlmIHRoZSBhcmMgc2hvdWxkIGJlIHN3ZXB0IGluIGEgcG9zaXRpdmUgYW5nbGUgZGlyZWN0aW9uLlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGFyYydzIGVuZCBwb2ludC5cbiAgICogQHBhcmFtIHkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBhcmMncyBlbmQgcG9pbnQuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgYXJjVG9TdmcocngsIHJ5LCB4QXhpc1JvdGF0aW9uLCBsYXJnZUFyY0ZsYWcsIHN3ZWVwRmxhZywgeCwgeSkge1xuICAgIHRoaXMuX3RpY2srKztcbiAgICBjb25zdCB0ID0gdGhpcy5fdHJhbnNmb3JtO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGguYXJjVG9TdmcoXG4gICAgICByeCxcbiAgICAgIHJ5LFxuICAgICAgeEF4aXNSb3RhdGlvbixcbiAgICAgIC8vIHNob3VsZCB3ZSByb3RhdGUgdGhpcyB3aXRoIHRyYW5zZm9ybT8/XG4gICAgICBsYXJnZUFyY0ZsYWcsXG4gICAgICBzd2VlcEZsYWcsXG4gICAgICB0LmEgKiB4ICsgdC5jICogeSArIHQudHgsXG4gICAgICB0LmIgKiB4ICsgdC5kICogeSArIHQudHlcbiAgICApO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBBZGRzIGEgY3ViaWMgQmV6aWVyIGN1cnZlIHRvIHRoZSBwYXRoLlxuICAgKiBJdCByZXF1aXJlcyB0aHJlZSBwb2ludHM6IHRoZSBmaXJzdCB0d28gYXJlIGNvbnRyb2wgcG9pbnRzIGFuZCB0aGUgdGhpcmQgb25lIGlzIHRoZSBlbmQgcG9pbnQuXG4gICAqIFRoZSBzdGFydGluZyBwb2ludCBpcyB0aGUgbGFzdCBwb2ludCBpbiB0aGUgY3VycmVudCBwYXRoLlxuICAgKiBAcGFyYW0gY3AxeCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGZpcnN0IGNvbnRyb2wgcG9pbnQuXG4gICAqIEBwYXJhbSBjcDF5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgZmlyc3QgY29udHJvbCBwb2ludC5cbiAgICogQHBhcmFtIGNwMnggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBzZWNvbmQgY29udHJvbCBwb2ludC5cbiAgICogQHBhcmFtIGNwMnkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBzZWNvbmQgY29udHJvbCBwb2ludC5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBlbmQgcG9pbnQuXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgZW5kIHBvaW50LlxuICAgKiBAcGFyYW0gc21vb3RobmVzcyAtIE9wdGlvbmFsIHBhcmFtZXRlciB0byBhZGp1c3QgdGhlIHNtb290aG5lc3Mgb2YgdGhlIGN1cnZlLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIGJlemllckN1cnZlVG8oY3AxeCwgY3AxeSwgY3AyeCwgY3AyeSwgeCwgeSwgc21vb3RobmVzcykge1xuICAgIHRoaXMuX3RpY2srKztcbiAgICBjb25zdCB0ID0gdGhpcy5fdHJhbnNmb3JtO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGguYmV6aWVyQ3VydmVUbyhcbiAgICAgIHQuYSAqIGNwMXggKyB0LmMgKiBjcDF5ICsgdC50eCxcbiAgICAgIHQuYiAqIGNwMXggKyB0LmQgKiBjcDF5ICsgdC50eSxcbiAgICAgIHQuYSAqIGNwMnggKyB0LmMgKiBjcDJ5ICsgdC50eCxcbiAgICAgIHQuYiAqIGNwMnggKyB0LmQgKiBjcDJ5ICsgdC50eSxcbiAgICAgIHQuYSAqIHggKyB0LmMgKiB5ICsgdC50eCxcbiAgICAgIHQuYiAqIHggKyB0LmQgKiB5ICsgdC50eSxcbiAgICAgIHNtb290aG5lc3NcbiAgICApO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBDbG9zZXMgdGhlIGN1cnJlbnQgcGF0aCBieSBkcmF3aW5nIGEgc3RyYWlnaHQgbGluZSBiYWNrIHRvIHRoZSBzdGFydC5cbiAgICogSWYgdGhlIHNoYXBlIGlzIGFscmVhZHkgY2xvc2VkIG9yIHRoZXJlIGFyZSBubyBwb2ludHMgaW4gdGhlIHBhdGgsIHRoaXMgbWV0aG9kIGRvZXMgbm90aGluZy5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICBjbG9zZVBhdGgoKSB7XG4gICAgdGhpcy5fdGljaysrO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGg/LmNsb3NlUGF0aCgpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhbiBlbGxpcHNlIGF0IHRoZSBzcGVjaWZpZWQgbG9jYXRpb24gYW5kIHdpdGggdGhlIGdpdmVuIHggYW5kIHkgcmFkaWkuXG4gICAqIEFuIG9wdGlvbmFsIHRyYW5zZm9ybWF0aW9uIGNhbiBiZSBhcHBsaWVkLCBhbGxvd2luZyBmb3Igcm90YXRpb24sIHNjYWxpbmcsIGFuZCB0cmFuc2xhdGlvbi5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBjZW50ZXIgb2YgdGhlIGVsbGlwc2UuXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgY2VudGVyIG9mIHRoZSBlbGxpcHNlLlxuICAgKiBAcGFyYW0gcmFkaXVzWCAtIFRoZSBob3Jpem9udGFsIHJhZGl1cyBvZiB0aGUgZWxsaXBzZS5cbiAgICogQHBhcmFtIHJhZGl1c1kgLSBUaGUgdmVydGljYWwgcmFkaXVzIG9mIHRoZSBlbGxpcHNlLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIGVsbGlwc2UoeCwgeSwgcmFkaXVzWCwgcmFkaXVzWSkge1xuICAgIHRoaXMuX3RpY2srKztcbiAgICB0aGlzLl9hY3RpdmVQYXRoLmVsbGlwc2UoeCwgeSwgcmFkaXVzWCwgcmFkaXVzWSwgdGhpcy5fdHJhbnNmb3JtLmNsb25lKCkpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIGNpcmNsZSBzaGFwZS4gVGhpcyBtZXRob2QgYWRkcyBhIG5ldyBjaXJjbGUgcGF0aCB0byB0aGUgY3VycmVudCBkcmF3aW5nLlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGNlbnRlciBvZiB0aGUgY2lyY2xlLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGNlbnRlciBvZiB0aGUgY2lyY2xlLlxuICAgKiBAcGFyYW0gcmFkaXVzIC0gVGhlIHJhZGl1cyBvZiB0aGUgY2lyY2xlLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIGNpcmNsZSh4LCB5LCByYWRpdXMpIHtcbiAgICB0aGlzLl90aWNrKys7XG4gICAgdGhpcy5fYWN0aXZlUGF0aC5jaXJjbGUoeCwgeSwgcmFkaXVzLCB0aGlzLl90cmFuc2Zvcm0uY2xvbmUoKSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYW5vdGhlciBgR3JhcGhpY3NQYXRoYCB0byB0aGlzIHBhdGgsIG9wdGlvbmFsbHkgYXBwbHlpbmcgYSB0cmFuc2Zvcm1hdGlvbi5cbiAgICogQHBhcmFtIHBhdGggLSBUaGUgYEdyYXBoaWNzUGF0aGAgdG8gYWRkLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIHBhdGgocGF0aCkge1xuICAgIHRoaXMuX3RpY2srKztcbiAgICB0aGlzLl9hY3RpdmVQYXRoLmFkZFBhdGgocGF0aCwgdGhpcy5fdHJhbnNmb3JtLmNsb25lKCkpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBDb25uZWN0cyB0aGUgY3VycmVudCBwb2ludCB0byBhIG5ldyBwb2ludCB3aXRoIGEgc3RyYWlnaHQgbGluZS4gVGhpcyBtZXRob2QgdXBkYXRlcyB0aGUgY3VycmVudCBwYXRoLlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIG5ldyBwb2ludCB0byBjb25uZWN0IHRvLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIG5ldyBwb2ludCB0byBjb25uZWN0IHRvLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIGxpbmVUbyh4LCB5KSB7XG4gICAgdGhpcy5fdGljaysrO1xuICAgIGNvbnN0IHQgPSB0aGlzLl90cmFuc2Zvcm07XG4gICAgdGhpcy5fYWN0aXZlUGF0aC5saW5lVG8oXG4gICAgICB0LmEgKiB4ICsgdC5jICogeSArIHQudHgsXG4gICAgICB0LmIgKiB4ICsgdC5kICogeSArIHQudHlcbiAgICApO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBTZXRzIHRoZSBzdGFydGluZyBwb2ludCBmb3IgYSBuZXcgc3ViLXBhdGguIEFueSBzdWJzZXF1ZW50IGRyYXdpbmcgY29tbWFuZHMgYXJlIGNvbnNpZGVyZWQgcGFydCBvZiB0aGlzIHBhdGguXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBmb3IgdGhlIHN0YXJ0aW5nIHBvaW50LlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgZm9yIHRoZSBzdGFydGluZyBwb2ludC5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICBtb3ZlVG8oeCwgeSkge1xuICAgIHRoaXMuX3RpY2srKztcbiAgICBjb25zdCB0ID0gdGhpcy5fdHJhbnNmb3JtO1xuICAgIGNvbnN0IGluc3RydWN0aW9ucyA9IHRoaXMuX2FjdGl2ZVBhdGguaW5zdHJ1Y3Rpb25zO1xuICAgIGNvbnN0IHRyYW5zZm9ybWVkWCA9IHQuYSAqIHggKyB0LmMgKiB5ICsgdC50eDtcbiAgICBjb25zdCB0cmFuc2Zvcm1lZFkgPSB0LmIgKiB4ICsgdC5kICogeSArIHQudHk7XG4gICAgaWYgKGluc3RydWN0aW9ucy5sZW5ndGggPT09IDEgJiYgaW5zdHJ1Y3Rpb25zWzBdLmFjdGlvbiA9PT0gXCJtb3ZlVG9cIikge1xuICAgICAgaW5zdHJ1Y3Rpb25zWzBdLmRhdGFbMF0gPSB0cmFuc2Zvcm1lZFg7XG4gICAgICBpbnN0cnVjdGlvbnNbMF0uZGF0YVsxXSA9IHRyYW5zZm9ybWVkWTtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICB0aGlzLl9hY3RpdmVQYXRoLm1vdmVUbyhcbiAgICAgIHRyYW5zZm9ybWVkWCxcbiAgICAgIHRyYW5zZm9ybWVkWVxuICAgICk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYSBxdWFkcmF0aWMgY3VydmUgdG8gdGhlIHBhdGguIEl0IHJlcXVpcmVzIHR3byBwb2ludHM6IHRoZSBjb250cm9sIHBvaW50IGFuZCB0aGUgZW5kIHBvaW50LlxuICAgKiBUaGUgc3RhcnRpbmcgcG9pbnQgaXMgdGhlIGxhc3QgcG9pbnQgaW4gdGhlIGN1cnJlbnQgcGF0aC5cbiAgICogQHBhcmFtIGNweCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGNvbnRyb2wgcG9pbnQuXG4gICAqIEBwYXJhbSBjcHkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBjb250cm9sIHBvaW50LlxuICAgKiBAcGFyYW0geCAtIFRoZSB4LWNvb3JkaW5hdGUgb2YgdGhlIGVuZCBwb2ludC5cbiAgICogQHBhcmFtIHkgLSBUaGUgeS1jb29yZGluYXRlIG9mIHRoZSBlbmQgcG9pbnQuXG4gICAqIEBwYXJhbSBzbW9vdGhuZXNzIC0gT3B0aW9uYWwgcGFyYW1ldGVyIHRvIGFkanVzdCB0aGUgc21vb3RobmVzcyBvZiB0aGUgY3VydmUuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nLlxuICAgKi9cbiAgcXVhZHJhdGljQ3VydmVUbyhjcHgsIGNweSwgeCwgeSwgc21vb3RobmVzcykge1xuICAgIHRoaXMuX3RpY2srKztcbiAgICBjb25zdCB0ID0gdGhpcy5fdHJhbnNmb3JtO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGgucXVhZHJhdGljQ3VydmVUbyhcbiAgICAgIHQuYSAqIGNweCArIHQuYyAqIGNweSArIHQudHgsXG4gICAgICB0LmIgKiBjcHggKyB0LmQgKiBjcHkgKyB0LnR5LFxuICAgICAgdC5hICogeCArIHQuYyAqIHkgKyB0LnR4LFxuICAgICAgdC5iICogeCArIHQuZCAqIHkgKyB0LnR5LFxuICAgICAgc21vb3RobmVzc1xuICAgICk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIERyYXdzIGEgcmVjdGFuZ2xlIHNoYXBlLiBUaGlzIG1ldGhvZCBhZGRzIGEgbmV3IHJlY3RhbmdsZSBwYXRoIHRvIHRoZSBjdXJyZW50IGRyYXdpbmcuXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgdG9wLWxlZnQgY29ybmVyIG9mIHRoZSByZWN0YW5nbGUuXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgdG9wLWxlZnQgY29ybmVyIG9mIHRoZSByZWN0YW5nbGUuXG4gICAqIEBwYXJhbSB3IC0gVGhlIHdpZHRoIG9mIHRoZSByZWN0YW5nbGUuXG4gICAqIEBwYXJhbSBoIC0gVGhlIGhlaWdodCBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIHJlY3QoeCwgeSwgdywgaCkge1xuICAgIHRoaXMuX3RpY2srKztcbiAgICB0aGlzLl9hY3RpdmVQYXRoLnJlY3QoeCwgeSwgdywgaCwgdGhpcy5fdHJhbnNmb3JtLmNsb25lKCkpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIHJlY3RhbmdsZSB3aXRoIHJvdW5kZWQgY29ybmVycy5cbiAgICogVGhlIGNvcm5lciByYWRpdXMgY2FuIGJlIHNwZWNpZmllZCB0byBkZXRlcm1pbmUgaG93IHJvdW5kZWQgdGhlIGNvcm5lcnMgc2hvdWxkIGJlLlxuICAgKiBBbiBvcHRpb25hbCB0cmFuc2Zvcm1hdGlvbiBjYW4gYmUgYXBwbGllZCwgd2hpY2ggYWxsb3dzIGZvciByb3RhdGlvbiwgc2NhbGluZywgYW5kIHRyYW5zbGF0aW9uIG9mIHRoZSByZWN0YW5nbGUuXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgdG9wLWxlZnQgY29ybmVyIG9mIHRoZSByZWN0YW5nbGUuXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgdG9wLWxlZnQgY29ybmVyIG9mIHRoZSByZWN0YW5nbGUuXG4gICAqIEBwYXJhbSB3IC0gVGhlIHdpZHRoIG9mIHRoZSByZWN0YW5nbGUuXG4gICAqIEBwYXJhbSBoIC0gVGhlIGhlaWdodCBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAcGFyYW0gcmFkaXVzIC0gVGhlIHJhZGl1cyBvZiB0aGUgcmVjdGFuZ2xlJ3MgY29ybmVycy4gSWYgbm90IHNwZWNpZmllZCwgY29ybmVycyB3aWxsIGJlIHNoYXJwLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIHJvdW5kUmVjdCh4LCB5LCB3LCBoLCByYWRpdXMpIHtcbiAgICB0aGlzLl90aWNrKys7XG4gICAgdGhpcy5fYWN0aXZlUGF0aC5yb3VuZFJlY3QoeCwgeSwgdywgaCwgcmFkaXVzLCB0aGlzLl90cmFuc2Zvcm0uY2xvbmUoKSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIERyYXdzIGEgcG9seWdvbiBzaGFwZSBieSBzcGVjaWZ5aW5nIGEgc2VxdWVuY2Ugb2YgcG9pbnRzLiBUaGlzIG1ldGhvZCBhbGxvd3MgZm9yIHRoZSBjcmVhdGlvbiBvZiBjb21wbGV4IHBvbHlnb25zLFxuICAgKiB3aGljaCBjYW4gYmUgYm90aCBvcGVuIGFuZCBjbG9zZWQuIEFuIG9wdGlvbmFsIHRyYW5zZm9ybWF0aW9uIGNhbiBiZSBhcHBsaWVkLCBlbmFibGluZyB0aGUgcG9seWdvbiB0byBiZSBzY2FsZWQsXG4gICAqIHJvdGF0ZWQsIG9yIHRyYW5zbGF0ZWQgYXMgbmVlZGVkLlxuICAgKiBAcGFyYW0gcG9pbnRzIC0gQW4gYXJyYXkgb2YgbnVtYmVycywgb3IgYW4gYXJyYXkgb2YgUG9pbnREYXRhIG9iamVjdHMgZWcgW3t4LHl9LCB7eCx5fSwge3gseX1dXG4gICAqIHJlcHJlc2VudGluZyB0aGUgeCBhbmQgeSBjb29yZGluYXRlcywgb2YgdGhlIHBvbHlnb24ncyB2ZXJ0aWNlcywgaW4gc2VxdWVuY2UuXG4gICAqIEBwYXJhbSBjbG9zZSAtIEEgYm9vbGVhbiBpbmRpY2F0aW5nIHdoZXRoZXIgdG8gY2xvc2UgdGhlIHBvbHlnb24gcGF0aC4gVHJ1ZSBieSBkZWZhdWx0LlxuICAgKi9cbiAgcG9seShwb2ludHMsIGNsb3NlKSB7XG4gICAgdGhpcy5fdGljaysrO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGgucG9seShwb2ludHMsIGNsb3NlLCB0aGlzLl90cmFuc2Zvcm0uY2xvbmUoKSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIERyYXdzIGEgcmVndWxhciBwb2x5Z29uIHdpdGggYSBzcGVjaWZpZWQgbnVtYmVyIG9mIHNpZGVzLiBBbGwgc2lkZXMgYW5kIGFuZ2xlcyBhcmUgZXF1YWwuXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgY2VudGVyIG9mIHRoZSBwb2x5Z29uLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGNlbnRlciBvZiB0aGUgcG9seWdvbi5cbiAgICogQHBhcmFtIHJhZGl1cyAtIFRoZSByYWRpdXMgb2YgdGhlIGNpcmN1bXNjcmliZWQgY2lyY2xlIG9mIHRoZSBwb2x5Z29uLlxuICAgKiBAcGFyYW0gc2lkZXMgLSBUaGUgbnVtYmVyIG9mIHNpZGVzIG9mIHRoZSBwb2x5Z29uLiBNdXN0IGJlIDMgb3IgbW9yZS5cbiAgICogQHBhcmFtIHJvdGF0aW9uIC0gVGhlIHJvdGF0aW9uIGFuZ2xlIG9mIHRoZSBwb2x5Z29uLCBpbiByYWRpYW5zLiBaZXJvIGJ5IGRlZmF1bHQuXG4gICAqIEBwYXJhbSB0cmFuc2Zvcm0gLSBBbiBvcHRpb25hbCBgTWF0cml4YCBvYmplY3QgdG8gYXBwbHkgYSB0cmFuc2Zvcm1hdGlvbiB0byB0aGUgcG9seWdvbi5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IG9iamVjdCBmb3IgY2hhaW5pbmcuXG4gICAqL1xuICByZWd1bGFyUG9seSh4LCB5LCByYWRpdXMsIHNpZGVzLCByb3RhdGlvbiA9IDAsIHRyYW5zZm9ybSkge1xuICAgIHRoaXMuX3RpY2srKztcbiAgICB0aGlzLl9hY3RpdmVQYXRoLnJlZ3VsYXJQb2x5KHgsIHksIHJhZGl1cywgc2lkZXMsIHJvdGF0aW9uLCB0cmFuc2Zvcm0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIHBvbHlnb24gd2l0aCByb3VuZGVkIGNvcm5lcnMuXG4gICAqIFNpbWlsYXIgdG8gYHJlZ3VsYXJQb2x5YCBidXQgd2l0aCB0aGUgYWJpbGl0eSB0byByb3VuZCB0aGUgY29ybmVycyBvZiB0aGUgcG9seWdvbi5cbiAgICogQHBhcmFtIHggLSBUaGUgeC1jb29yZGluYXRlIG9mIHRoZSBjZW50ZXIgb2YgdGhlIHBvbHlnb24uXG4gICAqIEBwYXJhbSB5IC0gVGhlIHktY29vcmRpbmF0ZSBvZiB0aGUgY2VudGVyIG9mIHRoZSBwb2x5Z29uLlxuICAgKiBAcGFyYW0gcmFkaXVzIC0gVGhlIHJhZGl1cyBvZiB0aGUgY2lyY3Vtc2NyaWJlZCBjaXJjbGUgb2YgdGhlIHBvbHlnb24uXG4gICAqIEBwYXJhbSBzaWRlcyAtIFRoZSBudW1iZXIgb2Ygc2lkZXMgb2YgdGhlIHBvbHlnb24uIE11c3QgYmUgMyBvciBtb3JlLlxuICAgKiBAcGFyYW0gY29ybmVyIC0gVGhlIHJhZGl1cyBvZiB0aGUgcm91bmRpbmcgb2YgdGhlIGNvcm5lcnMuXG4gICAqIEBwYXJhbSByb3RhdGlvbiAtIFRoZSByb3RhdGlvbiBhbmdsZSBvZiB0aGUgcG9seWdvbiwgaW4gcmFkaWFucy4gWmVybyBieSBkZWZhdWx0LlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIHJvdW5kUG9seSh4LCB5LCByYWRpdXMsIHNpZGVzLCBjb3JuZXIsIHJvdGF0aW9uKSB7XG4gICAgdGhpcy5fdGljaysrO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGgucm91bmRQb2x5KHgsIHksIHJhZGl1cywgc2lkZXMsIGNvcm5lciwgcm90YXRpb24pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIHNoYXBlIHdpdGggcm91bmRlZCBjb3JuZXJzLiBUaGlzIGZ1bmN0aW9uIHN1cHBvcnRzIGN1c3RvbSByYWRpdXMgZm9yIGVhY2ggY29ybmVyIG9mIHRoZSBzaGFwZS5cbiAgICogT3B0aW9uYWxseSwgY29ybmVycyBjYW4gYmUgcm91bmRlZCB1c2luZyBhIHF1YWRyYXRpYyBjdXJ2ZSBpbnN0ZWFkIG9mIGFuIGFyYywgcHJvdmlkaW5nIGEgZGlmZmVyZW50IGFlc3RoZXRpYy5cbiAgICogQHBhcmFtIHBvaW50cyAtIEFuIGFycmF5IG9mIGBSb3VuZGVkUG9pbnRgIHJlcHJlc2VudGluZyB0aGUgY29ybmVycyBvZiB0aGUgc2hhcGUgdG8gZHJhdy5cbiAgICogQSBtaW5pbXVtIG9mIDMgcG9pbnRzIGlzIHJlcXVpcmVkLlxuICAgKiBAcGFyYW0gcmFkaXVzIC0gVGhlIGRlZmF1bHQgcmFkaXVzIGZvciB0aGUgY29ybmVycy5cbiAgICogVGhpcyByYWRpdXMgaXMgYXBwbGllZCB0byBhbGwgY29ybmVycyB1bmxlc3Mgb3ZlcnJpZGRlbiBpbiBgcG9pbnRzYC5cbiAgICogQHBhcmFtIHVzZVF1YWRyYXRpYyAtIElmIHNldCB0byB0cnVlLCByb3VuZGVkIGNvcm5lcnMgYXJlIGRyYXduIHVzaW5nIGEgcXVhZHJhdGljQ3VydmVcbiAgICogIG1ldGhvZCBpbnN0ZWFkIG9mIGFuIGFyYyBtZXRob2QuIERlZmF1bHRzIHRvIGZhbHNlLlxuICAgKiBAcGFyYW0gc21vb3RobmVzcyAtIFNwZWNpZmllcyB0aGUgc21vb3RobmVzcyBvZiB0aGUgY3VydmUgd2hlbiBgdXNlUXVhZHJhdGljYCBpcyB0cnVlLlxuICAgKiBIaWdoZXIgdmFsdWVzIG1ha2UgdGhlIGN1cnZlIHNtb290aGVyLlxuICAgKiBAcmV0dXJucyBUaGUgaW5zdGFuY2Ugb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGZvciBjaGFpbmluZy5cbiAgICovXG4gIHJvdW5kU2hhcGUocG9pbnRzLCByYWRpdXMsIHVzZVF1YWRyYXRpYywgc21vb3RobmVzcykge1xuICAgIHRoaXMuX3RpY2srKztcbiAgICB0aGlzLl9hY3RpdmVQYXRoLnJvdW5kU2hhcGUocG9pbnRzLCByYWRpdXMsIHVzZVF1YWRyYXRpYywgc21vb3RobmVzcyk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIERyYXcgUmVjdGFuZ2xlIHdpdGggZmlsbGV0IGNvcm5lcnMuIFRoaXMgaXMgbXVjaCBsaWtlIHJvdW5kZWQgcmVjdGFuZ2xlXG4gICAqIGhvd2V2ZXIgaXQgc3VwcG9ydCBuZWdhdGl2ZSBudW1iZXJzIGFzIHdlbGwgZm9yIHRoZSBjb3JuZXIgcmFkaXVzLlxuICAgKiBAcGFyYW0geCAtIFVwcGVyIGxlZnQgY29ybmVyIG9mIHJlY3RcbiAgICogQHBhcmFtIHkgLSBVcHBlciByaWdodCBjb3JuZXIgb2YgcmVjdFxuICAgKiBAcGFyYW0gd2lkdGggLSBXaWR0aCBvZiByZWN0XG4gICAqIEBwYXJhbSBoZWlnaHQgLSBIZWlnaHQgb2YgcmVjdFxuICAgKiBAcGFyYW0gZmlsbGV0IC0gYWNjZXB0IG5lZ2F0aXZlIG9yIHBvc2l0aXZlIHZhbHVlc1xuICAgKi9cbiAgZmlsbGV0UmVjdCh4LCB5LCB3aWR0aCwgaGVpZ2h0LCBmaWxsZXQpIHtcbiAgICB0aGlzLl90aWNrKys7XG4gICAgdGhpcy5fYWN0aXZlUGF0aC5maWxsZXRSZWN0KHgsIHksIHdpZHRoLCBoZWlnaHQsIGZpbGxldCk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIERyYXcgUmVjdGFuZ2xlIHdpdGggY2hhbWZlciBjb3JuZXJzLiBUaGVzZSBhcmUgYW5nbGVkIGNvcm5lcnMuXG4gICAqIEBwYXJhbSB4IC0gVXBwZXIgbGVmdCBjb3JuZXIgb2YgcmVjdFxuICAgKiBAcGFyYW0geSAtIFVwcGVyIHJpZ2h0IGNvcm5lciBvZiByZWN0XG4gICAqIEBwYXJhbSB3aWR0aCAtIFdpZHRoIG9mIHJlY3RcbiAgICogQHBhcmFtIGhlaWdodCAtIEhlaWdodCBvZiByZWN0XG4gICAqIEBwYXJhbSBjaGFtZmVyIC0gbm9uLXplcm8gcmVhbCBudW1iZXIsIHNpemUgb2YgY29ybmVyIGN1dG91dFxuICAgKiBAcGFyYW0gdHJhbnNmb3JtXG4gICAqL1xuICBjaGFtZmVyUmVjdCh4LCB5LCB3aWR0aCwgaGVpZ2h0LCBjaGFtZmVyLCB0cmFuc2Zvcm0pIHtcbiAgICB0aGlzLl90aWNrKys7XG4gICAgdGhpcy5fYWN0aXZlUGF0aC5jaGFtZmVyUmVjdCh4LCB5LCB3aWR0aCwgaGVpZ2h0LCBjaGFtZmVyLCB0cmFuc2Zvcm0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBEcmF3cyBhIHN0YXIgc2hhcGUgY2VudGVyZWQgYXQgYSBzcGVjaWZpZWQgbG9jYXRpb24uIFRoaXMgbWV0aG9kIGFsbG93cyBmb3IgdGhlIGNyZWF0aW9uXG4gICAqICBvZiBzdGFycyB3aXRoIGEgdmFyaWFibGUgbnVtYmVyIG9mIHBvaW50cywgb3V0ZXIgcmFkaXVzLCBvcHRpb25hbCBpbm5lciByYWRpdXMsIGFuZCByb3RhdGlvbi5cbiAgICogVGhlIHN0YXIgaXMgZHJhd24gYXMgYSBjbG9zZWQgcG9seWdvbiB3aXRoIGFsdGVybmF0aW5nIG91dGVyIGFuZCBpbm5lciB2ZXJ0aWNlcyB0byBjcmVhdGUgdGhlIHN0YXIncyBwb2ludHMuXG4gICAqIEFuIG9wdGlvbmFsIHRyYW5zZm9ybWF0aW9uIGNhbiBiZSBhcHBsaWVkIHRvIHNjYWxlLCByb3RhdGUsIG9yIHRyYW5zbGF0ZSB0aGUgc3RhciBhcyBuZWVkZWQuXG4gICAqIEBwYXJhbSB4IC0gVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgY2VudGVyIG9mIHRoZSBzdGFyLlxuICAgKiBAcGFyYW0geSAtIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGNlbnRlciBvZiB0aGUgc3Rhci5cbiAgICogQHBhcmFtIHBvaW50cyAtIFRoZSBudW1iZXIgb2YgcG9pbnRzIG9mIHRoZSBzdGFyLlxuICAgKiBAcGFyYW0gcmFkaXVzIC0gVGhlIG91dGVyIHJhZGl1cyBvZiB0aGUgc3RhciAoZGlzdGFuY2UgZnJvbSB0aGUgY2VudGVyIHRvIHRoZSBvdXRlciBwb2ludHMpLlxuICAgKiBAcGFyYW0gaW5uZXJSYWRpdXMgLSBPcHRpb25hbC4gVGhlIGlubmVyIHJhZGl1cyBvZiB0aGUgc3RhclxuICAgKiAoZGlzdGFuY2UgZnJvbSB0aGUgY2VudGVyIHRvIHRoZSBpbm5lciBwb2ludHMgYmV0d2VlbiB0aGUgb3V0ZXIgcG9pbnRzKS5cbiAgICogSWYgbm90IHByb3ZpZGVkLCBkZWZhdWx0cyB0byBoYWxmIG9mIHRoZSBgcmFkaXVzYC5cbiAgICogQHBhcmFtIHJvdGF0aW9uIC0gT3B0aW9uYWwuIFRoZSByb3RhdGlvbiBvZiB0aGUgc3RhciBpbiByYWRpYW5zLCB3aGVyZSAwIGlzIGFsaWduZWQgd2l0aCB0aGUgeS1heGlzLlxuICAgKiBEZWZhdWx0cyB0byAwLCBtZWFuaW5nIG9uZSBwb2ludCBpcyBkaXJlY3RseSB1cHdhcmQuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBvYmplY3QgZm9yIGNoYWluaW5nIGZ1cnRoZXIgZHJhd2luZyBjb21tYW5kcy5cbiAgICovXG4gIHN0YXIoeCwgeSwgcG9pbnRzLCByYWRpdXMsIGlubmVyUmFkaXVzID0gMCwgcm90YXRpb24gPSAwKSB7XG4gICAgdGhpcy5fdGljaysrO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGguc3Rhcih4LCB5LCBwb2ludHMsIHJhZGl1cywgaW5uZXJSYWRpdXMsIHJvdGF0aW9uLCB0aGlzLl90cmFuc2Zvcm0uY2xvbmUoKSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFBhcnNlcyBhbmQgcmVuZGVycyBhbiBTVkcgc3RyaW5nIGludG8gdGhlIGdyYXBoaWNzIGNvbnRleHQuIFRoaXMgYWxsb3dzIGZvciBjb21wbGV4IHNoYXBlcyBhbmQgcGF0aHNcbiAgICogZGVmaW5lZCBpbiBTVkcgZm9ybWF0IHRvIGJlIGRyYXduIHdpdGhpbiB0aGUgZ3JhcGhpY3MgY29udGV4dC5cbiAgICogQHBhcmFtIHN2ZyAtIFRoZSBTVkcgc3RyaW5nIHRvIGJlIHBhcnNlZCBhbmQgcmVuZGVyZWQuXG4gICAqL1xuICBzdmcoc3ZnKSB7XG4gICAgdGhpcy5fdGljaysrO1xuICAgIFNWR1BhcnNlcihzdmcsIHRoaXMpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBSZXN0b3JlcyB0aGUgbW9zdCByZWNlbnRseSBzYXZlZCBncmFwaGljcyBzdGF0ZSBieSBwb3BwaW5nIHRoZSB0b3Agb2YgdGhlIGdyYXBoaWNzIHN0YXRlIHN0YWNrLlxuICAgKiBUaGlzIGluY2x1ZGVzIHRyYW5zZm9ybWF0aW9ucywgZmlsbCBzdHlsZXMsIGFuZCBzdHJva2Ugc3R5bGVzLlxuICAgKi9cbiAgcmVzdG9yZSgpIHtcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuX3N0YXRlU3RhY2sucG9wKCk7XG4gICAgaWYgKHN0YXRlKSB7XG4gICAgICB0aGlzLl90cmFuc2Zvcm0gPSBzdGF0ZS50cmFuc2Zvcm07XG4gICAgICB0aGlzLl9maWxsU3R5bGUgPSBzdGF0ZS5maWxsU3R5bGU7XG4gICAgICB0aGlzLl9zdHJva2VTdHlsZSA9IHN0YXRlLnN0cm9rZVN0eWxlO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKiogU2F2ZXMgdGhlIGN1cnJlbnQgZ3JhcGhpY3Mgc3RhdGUsIGluY2x1ZGluZyB0cmFuc2Zvcm1hdGlvbnMsIGZpbGwgc3R5bGVzLCBhbmQgc3Ryb2tlIHN0eWxlcywgb250byBhIHN0YWNrLiAqL1xuICBzYXZlKCkge1xuICAgIHRoaXMuX3N0YXRlU3RhY2sucHVzaCh7XG4gICAgICB0cmFuc2Zvcm06IHRoaXMuX3RyYW5zZm9ybS5jbG9uZSgpLFxuICAgICAgZmlsbFN0eWxlOiB7IC4uLnRoaXMuX2ZpbGxTdHlsZSB9LFxuICAgICAgc3Ryb2tlU3R5bGU6IHsgLi4udGhpcy5fc3Ryb2tlU3R5bGUgfVxuICAgIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBjdXJyZW50IHRyYW5zZm9ybWF0aW9uIG1hdHJpeCBvZiB0aGUgZ3JhcGhpY3MgY29udGV4dC5cbiAgICogQHJldHVybnMgVGhlIGN1cnJlbnQgdHJhbnNmb3JtYXRpb24gbWF0cml4LlxuICAgKi9cbiAgZ2V0VHJhbnNmb3JtKCkge1xuICAgIHJldHVybiB0aGlzLl90cmFuc2Zvcm07XG4gIH1cbiAgLyoqXG4gICAqIFJlc2V0cyB0aGUgY3VycmVudCB0cmFuc2Zvcm1hdGlvbiBtYXRyaXggdG8gdGhlIGlkZW50aXR5IG1hdHJpeCwgZWZmZWN0aXZlbHkgcmVtb3ZpbmcgYW55IHRyYW5zZm9ybWF0aW9ucyAocm90YXRpb24sIHNjYWxpbmcsIHRyYW5zbGF0aW9uKSBwcmV2aW91c2x5IGFwcGxpZWQuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBHcmFwaGljc0NvbnRleHQgZm9yIG1ldGhvZCBjaGFpbmluZy5cbiAgICovXG4gIHJlc2V0VHJhbnNmb3JtKCkge1xuICAgIHRoaXMuX3RyYW5zZm9ybS5pZGVudGl0eSgpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBBcHBsaWVzIGEgcm90YXRpb24gdHJhbnNmb3JtYXRpb24gdG8gdGhlIGdyYXBoaWNzIGNvbnRleHQgYXJvdW5kIHRoZSBjdXJyZW50IG9yaWdpbi5cbiAgICogQHBhcmFtIGFuZ2xlIC0gVGhlIGFuZ2xlIG9mIHJvdGF0aW9uIGluIHJhZGlhbnMuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBHcmFwaGljc0NvbnRleHQgZm9yIG1ldGhvZCBjaGFpbmluZy5cbiAgICovXG4gIHJvdGF0ZShhbmdsZSkge1xuICAgIHRoaXMuX3RyYW5zZm9ybS5yb3RhdGUoYW5nbGUpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBBcHBsaWVzIGEgc2NhbGluZyB0cmFuc2Zvcm1hdGlvbiB0byB0aGUgZ3JhcGhpY3MgY29udGV4dCwgc2NhbGluZyBkcmF3aW5ncyBieSB4IGhvcml6b250YWxseSBhbmQgYnkgeSB2ZXJ0aWNhbGx5LlxuICAgKiBAcGFyYW0geCAtIFRoZSBzY2FsZSBmYWN0b3IgaW4gdGhlIGhvcml6b250YWwgZGlyZWN0aW9uLlxuICAgKiBAcGFyYW0geSAtIChPcHRpb25hbCkgVGhlIHNjYWxlIGZhY3RvciBpbiB0aGUgdmVydGljYWwgZGlyZWN0aW9uLiBJZiBub3Qgc3BlY2lmaWVkLCB0aGUgeCB2YWx1ZSBpcyB1c2VkIGZvciBib3RoIGRpcmVjdGlvbnMuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBHcmFwaGljc0NvbnRleHQgZm9yIG1ldGhvZCBjaGFpbmluZy5cbiAgICovXG4gIHNjYWxlKHgsIHkgPSB4KSB7XG4gICAgdGhpcy5fdHJhbnNmb3JtLnNjYWxlKHgsIHkpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIHNldFRyYW5zZm9ybShhLCBiLCBjLCBkLCBkeCwgZHkpIHtcbiAgICBpZiAoYSBpbnN0YW5jZW9mIE1hdHJpeCkge1xuICAgICAgdGhpcy5fdHJhbnNmb3JtLnNldChhLmEsIGEuYiwgYS5jLCBhLmQsIGEudHgsIGEudHkpO1xuICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIHRoaXMuX3RyYW5zZm9ybS5zZXQoYSwgYiwgYywgZCwgZHgsIGR5KTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICB0cmFuc2Zvcm0oYSwgYiwgYywgZCwgZHgsIGR5KSB7XG4gICAgaWYgKGEgaW5zdGFuY2VvZiBNYXRyaXgpIHtcbiAgICAgIHRoaXMuX3RyYW5zZm9ybS5hcHBlbmQoYSk7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgdGVtcE1hdHJpeC5zZXQoYSwgYiwgYywgZCwgZHgsIGR5KTtcbiAgICB0aGlzLl90cmFuc2Zvcm0uYXBwZW5kKHRlbXBNYXRyaXgpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBBcHBsaWVzIGEgdHJhbnNsYXRpb24gdHJhbnNmb3JtYXRpb24gdG8gdGhlIGdyYXBoaWNzIGNvbnRleHQsIG1vdmluZyB0aGUgb3JpZ2luIGJ5IHRoZSBzcGVjaWZpZWQgYW1vdW50cy5cbiAgICogQHBhcmFtIHggLSBUaGUgYW1vdW50IHRvIHRyYW5zbGF0ZSBpbiB0aGUgaG9yaXpvbnRhbCBkaXJlY3Rpb24uXG4gICAqIEBwYXJhbSB5IC0gKE9wdGlvbmFsKSBUaGUgYW1vdW50IHRvIHRyYW5zbGF0ZSBpbiB0aGUgdmVydGljYWwgZGlyZWN0aW9uLiBJZiBub3Qgc3BlY2lmaWVkLCB0aGUgeCB2YWx1ZSBpcyB1c2VkIGZvciBib3RoIGRpcmVjdGlvbnMuXG4gICAqIEByZXR1cm5zIFRoZSBpbnN0YW5jZSBvZiB0aGUgY3VycmVudCBHcmFwaGljc0NvbnRleHQgZm9yIG1ldGhvZCBjaGFpbmluZy5cbiAgICovXG4gIHRyYW5zbGF0ZSh4LCB5ID0geCkge1xuICAgIHRoaXMuX3RyYW5zZm9ybS50cmFuc2xhdGUoeCwgeSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENsZWFycyBhbGwgZHJhd2luZyBjb21tYW5kcyBmcm9tIHRoZSBncmFwaGljcyBjb250ZXh0LCBlZmZlY3RpdmVseSByZXNldHRpbmcgaXQuIFRoaXMgaW5jbHVkZXMgY2xlYXJpbmcgdGhlIHBhdGgsXG4gICAqIGFuZCBvcHRpb25hbGx5IHJlc2V0dGluZyB0cmFuc2Zvcm1hdGlvbnMgdG8gdGhlIGlkZW50aXR5IG1hdHJpeC5cbiAgICogQHJldHVybnMgVGhlIGluc3RhbmNlIG9mIHRoZSBjdXJyZW50IEdyYXBoaWNzQ29udGV4dCBmb3IgbWV0aG9kIGNoYWluaW5nLlxuICAgKi9cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy5fYWN0aXZlUGF0aC5jbGVhcigpO1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5yZXNldFRyYW5zZm9ybSgpO1xuICAgIHRoaXMub25VcGRhdGUoKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBvblVwZGF0ZSgpIHtcbiAgICB0aGlzLl9ib3VuZHNEaXJ0eSA9IHRydWU7XG4gICAgdGhpcy5kaXJ0eSA9IHRydWU7XG4gICAgdGhpcy5lbWl0KFwidXBkYXRlXCIsIHRoaXMsIDE2KTtcbiAgfVxuICAvKiogVGhlIGJvdW5kcyBvZiB0aGUgZ3JhcGhpYyBzaGFwZS4gKi9cbiAgZ2V0IGJvdW5kcygpIHtcbiAgICBpZiAoIXRoaXMuX2JvdW5kc0RpcnR5KSByZXR1cm4gdGhpcy5fYm91bmRzO1xuICAgIHRoaXMuX2JvdW5kc0RpcnR5ID0gZmFsc2U7XG4gICAgY29uc3QgYm91bmRzID0gdGhpcy5fYm91bmRzO1xuICAgIGJvdW5kcy5jbGVhcigpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGluc3RydWN0aW9uID0gdGhpcy5pbnN0cnVjdGlvbnNbaV07XG4gICAgICBjb25zdCBhY3Rpb24gPSBpbnN0cnVjdGlvbi5hY3Rpb247XG4gICAgICBpZiAoYWN0aW9uID09PSBcImZpbGxcIikge1xuICAgICAgICBjb25zdCBkYXRhID0gaW5zdHJ1Y3Rpb24uZGF0YTtcbiAgICAgICAgYm91bmRzLmFkZEJvdW5kcyhkYXRhLnBhdGguYm91bmRzKTtcbiAgICAgIH0gZWxzZSBpZiAoYWN0aW9uID09PSBcInRleHR1cmVcIikge1xuICAgICAgICBjb25zdCBkYXRhID0gaW5zdHJ1Y3Rpb24uZGF0YTtcbiAgICAgICAgYm91bmRzLmFkZEZyYW1lKGRhdGEuZHgsIGRhdGEuZHksIGRhdGEuZHggKyBkYXRhLmR3LCBkYXRhLmR5ICsgZGF0YS5kaCwgZGF0YS50cmFuc2Zvcm0pO1xuICAgICAgfVxuICAgICAgaWYgKGFjdGlvbiA9PT0gXCJzdHJva2VcIikge1xuICAgICAgICBjb25zdCBkYXRhID0gaW5zdHJ1Y3Rpb24uZGF0YTtcbiAgICAgICAgY29uc3QgYWxpZ25tZW50ID0gZGF0YS5zdHlsZS5hbGlnbm1lbnQ7XG4gICAgICAgIGxldCBvdXRlclBhZGRpbmcgPSBkYXRhLnN0eWxlLndpZHRoICogKDEgLSBhbGlnbm1lbnQpO1xuICAgICAgICBpZiAoZGF0YS5zdHlsZS5qb2luID09PSBcIm1pdGVyXCIpIHtcbiAgICAgICAgICBvdXRlclBhZGRpbmcgKj0gZ2V0TWF4TWl0ZXJSYXRpbyhkYXRhLnBhdGgsIGRhdGEuc3R5bGUubWl0ZXJMaW1pdCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgX2JvdW5kcyA9IGRhdGEucGF0aC5ib3VuZHM7XG4gICAgICAgIGJvdW5kcy5hZGRGcmFtZShcbiAgICAgICAgICBfYm91bmRzLm1pblggLSBvdXRlclBhZGRpbmcsXG4gICAgICAgICAgX2JvdW5kcy5taW5ZIC0gb3V0ZXJQYWRkaW5nLFxuICAgICAgICAgIF9ib3VuZHMubWF4WCArIG91dGVyUGFkZGluZyxcbiAgICAgICAgICBfYm91bmRzLm1heFkgKyBvdXRlclBhZGRpbmdcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFib3VuZHMuaXNWYWxpZCkge1xuICAgICAgYm91bmRzLnNldCgwLCAwLCAwLCAwKTtcbiAgICB9XG4gICAgcmV0dXJuIGJvdW5kcztcbiAgfVxuICAvKipcbiAgICogQ2hlY2sgdG8gc2VlIGlmIGEgcG9pbnQgaXMgY29udGFpbmVkIHdpdGhpbiB0aGlzIGdlb21ldHJ5LlxuICAgKiBAcGFyYW0gcG9pbnQgLSBQb2ludCB0byBjaGVjayBpZiBpdCdzIGNvbnRhaW5lZC5cbiAgICogQHJldHVybnMge2Jvb2xlYW59IGB0cnVlYCBpZiB0aGUgcG9pbnQgaXMgY29udGFpbmVkIHdpdGhpbiBnZW9tZXRyeS5cbiAgICovXG4gIGNvbnRhaW5zUG9pbnQocG9pbnQpIHtcbiAgICBpZiAoIXRoaXMuYm91bmRzLmNvbnRhaW5zUG9pbnQocG9pbnQueCwgcG9pbnQueSkpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBpbnN0cnVjdGlvbnMgPSB0aGlzLmluc3RydWN0aW9ucztcbiAgICBsZXQgaGFzSGl0ID0gZmFsc2U7XG4gICAgZm9yIChsZXQgayA9IDA7IGsgPCBpbnN0cnVjdGlvbnMubGVuZ3RoOyBrKyspIHtcbiAgICAgIGNvbnN0IGluc3RydWN0aW9uID0gaW5zdHJ1Y3Rpb25zW2tdO1xuICAgICAgY29uc3QgZGF0YSA9IGluc3RydWN0aW9uLmRhdGE7XG4gICAgICBjb25zdCBwYXRoID0gZGF0YS5wYXRoO1xuICAgICAgaWYgKCFpbnN0cnVjdGlvbi5hY3Rpb24gfHwgIXBhdGgpIGNvbnRpbnVlO1xuICAgICAgY29uc3Qgc3R5bGUgPSBkYXRhLnN0eWxlO1xuICAgICAgY29uc3Qgc2hhcGVzID0gcGF0aC5zaGFwZVBhdGguc2hhcGVQcmltaXRpdmVzO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzaGFwZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3Qgc2hhcGUgPSBzaGFwZXNbaV0uc2hhcGU7XG4gICAgICAgIGlmICghc3R5bGUgfHwgIXNoYXBlKSBjb250aW51ZTtcbiAgICAgICAgY29uc3QgdHJhbnNmb3JtID0gc2hhcGVzW2ldLnRyYW5zZm9ybTtcbiAgICAgICAgY29uc3QgdHJhbnNmb3JtZWRQb2ludCA9IHRyYW5zZm9ybSA/IHRyYW5zZm9ybS5hcHBseUludmVyc2UocG9pbnQsIHRtcFBvaW50KSA6IHBvaW50O1xuICAgICAgICBpZiAoaW5zdHJ1Y3Rpb24uYWN0aW9uID09PSBcImZpbGxcIikge1xuICAgICAgICAgIGhhc0hpdCA9IHNoYXBlLmNvbnRhaW5zKHRyYW5zZm9ybWVkUG9pbnQueCwgdHJhbnNmb3JtZWRQb2ludC55KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBzdHJva2VTdHlsZSA9IHN0eWxlO1xuICAgICAgICAgIGhhc0hpdCA9IHNoYXBlLnN0cm9rZUNvbnRhaW5zKHRyYW5zZm9ybWVkUG9pbnQueCwgdHJhbnNmb3JtZWRQb2ludC55LCBzdHJva2VTdHlsZS53aWR0aCwgc3Ryb2tlU3R5bGUuYWxpZ25tZW50KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBob2xlcyA9IGRhdGEuaG9sZTtcbiAgICAgICAgaWYgKGhvbGVzKSB7XG4gICAgICAgICAgY29uc3QgaG9sZVNoYXBlcyA9IGhvbGVzLnNoYXBlUGF0aD8uc2hhcGVQcmltaXRpdmVzO1xuICAgICAgICAgIGlmIChob2xlU2hhcGVzKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGhvbGVTaGFwZXMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgaWYgKGhvbGVTaGFwZXNbal0uc2hhcGUuY29udGFpbnModHJhbnNmb3JtZWRQb2ludC54LCB0cmFuc2Zvcm1lZFBvaW50LnkpKSB7XG4gICAgICAgICAgICAgICAgaGFzSGl0ID0gZmFsc2U7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGhhc0hpdCkge1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBoYXNIaXQ7XG4gIH1cbiAgLyoqIFVubG9hZHMgdGhlIEdQVSBkYXRhIGZyb20gdGhlIGdyYXBoaWNzIGNvbnRleHQuICovXG4gIHVubG9hZCgpIHtcbiAgICB0aGlzLmVtaXQoXCJ1bmxvYWRcIiwgdGhpcyk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gdGhpcy5fZ3B1RGF0YSkge1xuICAgICAgdGhpcy5fZ3B1RGF0YVtrZXldPy5kZXN0cm95KCk7XG4gICAgfVxuICAgIHRoaXMuX2dwdURhdGEgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgfVxuICAvKipcbiAgICogRGVzdHJveXMgdGhlIEdyYXBoaWNzRGF0YSBvYmplY3QuXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gT3B0aW9ucyBwYXJhbWV0ZXIuIEEgYm9vbGVhbiB3aWxsIGFjdCBhcyBpZiBhbGwgb3B0aW9uc1xuICAgKiAgaGF2ZSBiZWVuIHNldCB0byB0aGF0IHZhbHVlXG4gICAqIEBleGFtcGxlXG4gICAqIGNvbnRleHQuZGVzdHJveSgpO1xuICAgKiBjb250ZXh0LmRlc3Ryb3kodHJ1ZSk7XG4gICAqIGNvbnRleHQuZGVzdHJveSh7IHRleHR1cmU6IHRydWUsIHRleHR1cmVTb3VyY2U6IHRydWUgfSk7XG4gICAqL1xuICBkZXN0cm95KG9wdGlvbnMgPSBmYWxzZSkge1xuICAgIGlmICh0aGlzLmRlc3Ryb3llZCkgcmV0dXJuO1xuICAgIHRoaXMuZGVzdHJveWVkID0gdHJ1ZTtcbiAgICB0aGlzLl9zdGF0ZVN0YWNrLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5fdHJhbnNmb3JtID0gbnVsbDtcbiAgICB0aGlzLnVubG9hZCgpO1xuICAgIHRoaXMuZW1pdChcImRlc3Ryb3lcIiwgdGhpcyk7XG4gICAgdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcbiAgICBjb25zdCBkZXN0cm95VGV4dHVyZSA9IHR5cGVvZiBvcHRpb25zID09PSBcImJvb2xlYW5cIiA/IG9wdGlvbnMgOiBvcHRpb25zPy50ZXh0dXJlO1xuICAgIGlmIChkZXN0cm95VGV4dHVyZSkge1xuICAgICAgY29uc3QgZGVzdHJveVRleHR1cmVTb3VyY2UgPSB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJib29sZWFuXCIgPyBvcHRpb25zIDogb3B0aW9ucz8udGV4dHVyZVNvdXJjZTtcbiAgICAgIGlmICh0aGlzLl9maWxsU3R5bGUudGV4dHVyZSkge1xuICAgICAgICB0aGlzLl9maWxsU3R5bGUuZmlsbCAmJiBcInVpZFwiIGluIHRoaXMuX2ZpbGxTdHlsZS5maWxsID8gdGhpcy5fZmlsbFN0eWxlLmZpbGwuZGVzdHJveSgpIDogdGhpcy5fZmlsbFN0eWxlLnRleHR1cmUuZGVzdHJveShkZXN0cm95VGV4dHVyZVNvdXJjZSk7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5fc3Ryb2tlU3R5bGUudGV4dHVyZSkge1xuICAgICAgICB0aGlzLl9zdHJva2VTdHlsZS5maWxsICYmIFwidWlkXCIgaW4gdGhpcy5fc3Ryb2tlU3R5bGUuZmlsbCA/IHRoaXMuX3N0cm9rZVN0eWxlLmZpbGwuZGVzdHJveSgpIDogdGhpcy5fc3Ryb2tlU3R5bGUudGV4dHVyZS5kZXN0cm95KGRlc3Ryb3lUZXh0dXJlU291cmNlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5fZmlsbFN0eWxlID0gbnVsbDtcbiAgICB0aGlzLl9zdHJva2VTdHlsZSA9IG51bGw7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMgPSBudWxsO1xuICAgIHRoaXMuX2FjdGl2ZVBhdGggPSBudWxsO1xuICAgIHRoaXMuX2JvdW5kcyA9IG51bGw7XG4gICAgdGhpcy5fc3RhdGVTdGFjayA9IG51bGw7XG4gICAgdGhpcy5jdXN0b21TaGFkZXIgPSBudWxsO1xuICAgIHRoaXMuX3RyYW5zZm9ybSA9IG51bGw7XG4gIH1cbn07XG4vKiogVGhlIGRlZmF1bHQgZmlsbCBzdHlsZSB0byB1c2Ugd2hlbiBub25lIGlzIHByb3ZpZGVkLiAqL1xuX0dyYXBoaWNzQ29udGV4dC5kZWZhdWx0RmlsbFN0eWxlID0ge1xuICAvKiogVGhlIGNvbG9yIHRvIHVzZSBmb3IgdGhlIGZpbGwuICovXG4gIGNvbG9yOiAxNjc3NzIxNSxcbiAgLyoqIFRoZSBhbHBoYSB2YWx1ZSB0byB1c2UgZm9yIHRoZSBmaWxsLiAqL1xuICBhbHBoYTogMSxcbiAgLyoqIFRoZSB0ZXh0dXJlIHRvIHVzZSBmb3IgdGhlIGZpbGwuICovXG4gIHRleHR1cmU6IFRleHR1cmUuV0hJVEUsXG4gIC8qKiBUaGUgbWF0cml4IHRvIGFwcGx5LiAqL1xuICBtYXRyaXg6IG51bGwsXG4gIC8qKiBUaGUgZmlsbCBwYXR0ZXJuIHRvIHVzZS4gKi9cbiAgZmlsbDogbnVsbCxcbiAgLyoqIFdoZXRoZXIgY29vcmRpbmF0ZXMgYXJlICdnbG9iYWwnIG9yICdsb2NhbCcgKi9cbiAgdGV4dHVyZVNwYWNlOiBcImxvY2FsXCJcbn07XG4vKiogVGhlIGRlZmF1bHQgc3Ryb2tlIHN0eWxlIHRvIHVzZSB3aGVuIG5vbmUgaXMgcHJvdmlkZWQuICovXG5fR3JhcGhpY3NDb250ZXh0LmRlZmF1bHRTdHJva2VTdHlsZSA9IHtcbiAgLyoqIFRoZSB3aWR0aCBvZiB0aGUgc3Ryb2tlLiAqL1xuICB3aWR0aDogMSxcbiAgLyoqIFRoZSBjb2xvciB0byB1c2UgZm9yIHRoZSBzdHJva2UuICovXG4gIGNvbG9yOiAxNjc3NzIxNSxcbiAgLyoqIFRoZSBhbHBoYSB2YWx1ZSB0byB1c2UgZm9yIHRoZSBzdHJva2UuICovXG4gIGFscGhhOiAxLFxuICAvKiogVGhlIGFsaWdubWVudCBvZiB0aGUgc3Ryb2tlLiAqL1xuICBhbGlnbm1lbnQ6IDAuNSxcbiAgLyoqIFRoZSBtaXRlciBsaW1pdCB0byB1c2UuICovXG4gIG1pdGVyTGltaXQ6IDEwLFxuICAvKiogVGhlIGxpbmUgY2FwIHN0eWxlIHRvIHVzZS4gKi9cbiAgY2FwOiBcImJ1dHRcIixcbiAgLyoqIFRoZSBsaW5lIGpvaW4gc3R5bGUgdG8gdXNlLiAqL1xuICBqb2luOiBcIm1pdGVyXCIsXG4gIC8qKiBUaGUgdGV4dHVyZSB0byB1c2UgZm9yIHRoZSBmaWxsLiAqL1xuICB0ZXh0dXJlOiBUZXh0dXJlLldISVRFLFxuICAvKiogVGhlIG1hdHJpeCB0byBhcHBseS4gKi9cbiAgbWF0cml4OiBudWxsLFxuICAvKiogVGhlIGZpbGwgcGF0dGVybiB0byB1c2UuICovXG4gIGZpbGw6IG51bGwsXG4gIC8qKiBXaGV0aGVyIGNvb3JkaW5hdGVzIGFyZSAnZ2xvYmFsJyBvciAnbG9jYWwnICovXG4gIHRleHR1cmVTcGFjZTogXCJsb2NhbFwiLFxuICAvKiogSWYgdGhlIHN0cm9rZSBpcyBhIHBpeGVsIGxpbmUuICovXG4gIHBpeGVsTGluZTogZmFsc2Vcbn07XG5sZXQgR3JhcGhpY3NDb250ZXh0ID0gX0dyYXBoaWNzQ29udGV4dDtcblxuZXhwb3J0IHsgR3JhcGhpY3NDb250ZXh0IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1HcmFwaGljc0NvbnRleHQubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQkEsSUFBTSwyQkFBVyxJQUFJLElBQUk7QUFJekIsSUFBSSxjQUFjOzs7Ozs7Ozs7O0FBV2xCLFNBQXdCQSxTQUFPLE1BQU0sYUFBYSxNQUFNLEdBQUc7Q0FFdkQsTUFBTSxXQUFXLGVBQWUsWUFBWTtDQUM1QyxNQUFNLFdBQVcsV0FBVyxZQUFZLEtBQUssTUFBTSxLQUFLO0NBQ3hELElBQUksU0FBUyxNQUFNLFNBQVMsTUFBTTtDQUVsQyxJQUFJLFlBQVksV0FBVyxNQUFNLEdBQUcsVUFBVSxLQUFLLElBQUk7O0NBRXZELE1BQU0sWUFBWSxDQUFDO0NBRW5CLElBQUksQ0FBQyxhQUFhLFVBQVUsU0FBUyxVQUFVLE1BQU0sT0FBTztDQUU1RCxJQUFJLE9BQU8sR0FBRyxPQUFPLEdBQUcsVUFBVTtDQUVsQyxJQUFJLFVBQVUsWUFBWSxlQUFlLE1BQU0sYUFBYSxXQUFXLEdBQUc7Q0FHMUUsSUFBSSxLQUFLLFNBQVMsS0FBSyxLQUFLO0VBQ3hCLE9BQU8sS0FBSztFQUNaLE9BQU8sS0FBSztFQUNaLElBQUksT0FBTztFQUNYLElBQUksT0FBTztFQUVYLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxVQUFVLEtBQUssS0FBSztHQUN0QyxNQUFNLElBQUksS0FBSztHQUNmLE1BQU0sSUFBSSxLQUFLLElBQUk7R0FDbkIsSUFBSSxJQUFJLE1BQU0sT0FBTztHQUNyQixJQUFJLElBQUksTUFBTSxPQUFPO0dBQ3JCLElBQUksSUFBSSxNQUFNLE9BQU87R0FDckIsSUFBSSxJQUFJLE1BQU0sT0FBTztFQUN6QjtFQUdBLFVBQVUsS0FBSyxJQUFJLE9BQU8sTUFBTSxPQUFPLElBQUk7RUFDM0MsVUFBVSxZQUFZLElBQUksUUFBUSxVQUFVO0NBQ2hEO0NBRUEsYUFBYSxXQUFXLFdBQVcsTUFBTSxNQUFNLE9BQU87Q0FFdEQsT0FBTztBQUNYOztBQUlBLFNBQVMsV0FBVyxNQUFNLE9BQU8sS0FBSyxLQUFLLFdBQVc7O0NBRWxELElBQUksT0FBTztDQUVYLElBQUksY0FBZSxXQUFXLE1BQU0sT0FBTyxLQUFLLEdBQUcsSUFBSSxHQUNuRCxLQUFLLElBQUksSUFBSSxPQUFPLElBQUksS0FBSyxLQUFLLEtBQUssT0FBTyxXQUFXLElBQUksTUFBTSxHQUFHLEtBQUssSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJO01BRWhHLEtBQUssSUFBSSxJQUFJLE1BQU0sS0FBSyxLQUFLLE9BQU8sS0FBSyxLQUFLLE9BQU8sV0FBVyxJQUFJLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksSUFBSTtDQUczRyxJQUFJLFFBQVEsT0FBTyxNQUFNLEtBQUssSUFBSSxHQUFHO0VBQ2pDLFdBQVcsSUFBSTtFQUNmLE9BQU8sS0FBSztDQUNoQjtDQUVBLE9BQU87QUFDWDs7QUFRQSxTQUFTLGFBQWEsT0FBTyxNQUFNLE9BQU87Q0FDdEMsTUFBTSxPQUFPLFFBQVE7Q0FFckIsSUFBSSxJQUFJLE9BQU87Q0FDZixHQUFHO0VBQ0MsUUFBUTtFQUNSLElBQUksTUFBTSxFQUFFLFNBQVMsU0FBUyxTQUFTLEtBQUssQ0FBQyxTQUFTLElBQUksQ0FBQyxPQUN0RCxPQUFPLEdBQUcsRUFBRSxJQUFJLEtBQUssS0FBSyxFQUFFLE1BQU0sR0FBRyxFQUFFLElBQUksTUFBTSxJQUFJO0dBQ3RELElBQUksUUFBUSxNQUFNLEtBQUssTUFBTSxFQUFFO0dBQy9CLGNBQWM7R0FDZCxXQUFXLENBQUM7R0FDWixJQUFJLEVBQUU7R0FDTixRQUFRO0VBQ1osT0FBTyxJQUFJLFFBQVEsTUFBTSxLQUFLO0dBQzFCLElBQUksRUFBRTtHQUNOLFFBQVEsQ0FBQztFQUNiO0NBQ0osU0FBUyxTQUFTLE1BQU07Q0FFeEIsT0FBTztBQUNYOztBQUlBLFNBQVMsYUFBYSxLQUFLLFdBQVcsTUFBTSxNQUFNLFNBQVM7Q0FFdkQsSUFBSSxTQUFTLFdBQVcsS0FBSyxNQUFNLE1BQU0sT0FBTztDQUVoRCxJQUFJLE9BQU8sS0FBSyxRQUFRO0NBR3hCLE9BQU8sSUFBSSxTQUFTLElBQUksTUFBTTtFQUMxQixNQUFNLE9BQU8sSUFBSTs7RUFFakIsTUFBTSxPQUFPLElBQUk7RUFFakIsSUFBSSxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksTUFBTSxVQUFVLFlBQVksS0FBSyxNQUFNLE1BQU0sT0FBTyxJQUFJLE1BQU0sR0FBRyxJQUFJO0dBQzdGLFVBQVUsS0FBSyxLQUFLLEdBQUcsSUFBSSxHQUFHLEtBQUssQ0FBQztHQUVwQyxXQUFXLEdBQUc7R0FDZCxNQUFNO0dBQ04sT0FBTztHQUNQO0VBQ0o7RUFFQSxNQUFNO0VBR04sSUFBSSxRQUFRLE1BQU07R0FHZCxjQUFjO0dBQ2QsTUFBTSxhQUFhLEdBQUc7R0FDdEIsSUFBSSxhQUFhO0lBQUUsT0FBTztJQUFLO0dBQVU7R0FHekMsSUFBSSxDQUFDLE9BQU87SUFDUixNQUFNLHVCQUF1QixLQUFLLFNBQVM7SUFDM0MsT0FBTztJQUNQLFFBQVE7SUFDUjtHQUNKO0dBR0EsWUFBWSxLQUFLLFdBQVcsTUFBTSxNQUFNLE9BQU87R0FDL0M7RUFDSjtDQUNKO0FBQ0o7O0FBSUEsU0FBUyxNQUFNLEtBQUs7Q0FFaEIsTUFBTSxJQUFJLElBQUksTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQ2pDLEtBQUssRUFBRSxHQUFHLEtBQUssRUFBRSxHQUFHLEtBQUssRUFBRSxHQUFHLEtBQUssRUFBRSxHQUFHLEtBQUssRUFBRSxHQUFHLEtBQUssRUFBRSxHQUN6RCxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksRUFBRSxHQUN4QixLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksRUFBRSxHQUN4QixLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksRUFBRSxHQUN4QixLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksRUFBRTtDQUc1QixJQUFJLElBQUksRUFBRTtDQUNWLE9BQU8sTUFBTSxHQUFHO0VBQ1osSUFBSSxFQUFFLEtBQUssTUFBTSxFQUFFLEtBQUssTUFBTSxFQUFFLEtBQUssTUFBTSxFQUFFLEtBQUssTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLE9BQU8sRUFBRSxNQUM3RSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLEtBQUssR0FBRyxPQUFPO0VBQzlGLElBQUksRUFBRTtDQUNWO0NBQ0EsT0FBTztBQUNYOztBQUdBLFNBQVMsWUFBWSxLQUFLLE1BQU0sTUFBTSxTQUFTO0NBRTNDLE1BQU0sSUFBSSxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUksSUFBSSxNQUNqQyxLQUFLLEVBQUUsR0FBRyxLQUFLLEVBQUUsR0FBRyxLQUFLLEVBQUUsR0FBRyxLQUFLLEVBQUUsR0FBRyxLQUFLLEVBQUUsR0FBRyxLQUFLLEVBQUUsR0FDekQsS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLEVBQUUsR0FDeEIsS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLEVBQUUsR0FDeEIsS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLEVBQUUsR0FDeEIsS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLEVBQUUsR0FDeEIsT0FBTyxPQUFPLElBQUksSUFBSSxNQUFNLE1BQU0sT0FBTyxHQUN6QyxPQUFPLE9BQU8sSUFBSSxJQUFJLE1BQU0sTUFBTSxPQUFPO0NBRTdDLElBQUksSUFBSSxJQUFJO0NBQ1osT0FBTyxLQUFLLEVBQUUsS0FBSyxNQUFNO0VBQ3JCLElBQUksRUFBRSxLQUFLLE1BQU0sRUFBRSxLQUFLLE1BQU0sRUFBRSxLQUFLLE1BQU0sRUFBRSxLQUFLLE1BQU0sTUFBTSxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssT0FBTyxFQUFFLE1BQ3hGLGdCQUFnQixJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLEtBQUssS0FBSyxFQUFFLE1BQU0sR0FBRyxFQUFFLElBQUksS0FBSyxHQUFHLE9BQU87RUFDOUYsSUFBSSxFQUFFO0NBQ1Y7Q0FDQSxJQUFJLElBQUksSUFBSTtDQUNaLE9BQU8sS0FBSyxFQUFFLEtBQUssTUFBTTtFQUNyQixJQUFJLEVBQUUsS0FBSyxNQUFNLEVBQUUsS0FBSyxNQUFNLEVBQUUsS0FBSyxNQUFNLEVBQUUsS0FBSyxNQUFNLE1BQU0sS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLE9BQU8sRUFBRSxNQUN4RixnQkFBZ0IsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLEtBQUssR0FBRyxPQUFPO0VBQzlGLElBQUksRUFBRTtDQUNWO0NBQ0EsT0FBTztBQUNYOztBQUlBLFNBQVMsdUJBQXVCLE9BQU8sV0FBVztDQUM5QyxJQUFJLElBQUk7Q0FDUixJQUFJLFFBQVE7Q0FDWixHQUFHO0VBQ0MsTUFBTSxJQUFJLEVBQUUsTUFDUixJQUFJLEVBQUUsS0FBSztFQUVmLElBQUksV0FBVyxHQUFHLEdBQUcsRUFBRSxNQUFNLEdBQUcsS0FBSyxLQUFLLGNBQWMsR0FBRyxDQUFDLEtBQUssY0FBYyxHQUFHLENBQUMsR0FBRztHQUVsRixVQUFVLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7R0FHNUIsV0FBVyxDQUFDO0dBQ1osV0FBVyxFQUFFLElBQUk7R0FFakIsSUFBSSxRQUFRO0dBQ1osUUFBUTtFQUNaO0VBQ0EsSUFBSSxFQUFFO0NBQ1YsU0FBUyxNQUFNO0NBRWYsT0FBTyxRQUFRLGFBQWEsQ0FBQyxJQUFJO0FBQ3JDOztBQUlBLFNBQVMsWUFBWSxPQUFPLFdBQVcsTUFBTSxNQUFNLFNBQVM7Q0FFeEQsSUFBSSxJQUFJO0NBQ1IsR0FBRztFQUNDLElBQUksSUFBSSxFQUFFLEtBQUs7RUFDZixPQUFPLE1BQU0sRUFBRSxNQUFNO0dBQ2pCLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxnQkFBZ0IsR0FBRyxDQUFDLEdBQUc7SUFFdEMsSUFBSSxJQUFJLGFBQWEsR0FBRyxDQUFDO0lBR3pCLElBQUksYUFBYSxHQUFHLEVBQUUsSUFBSTtJQUMxQixJQUFJLGFBQWEsR0FBRyxFQUFFLElBQUk7SUFHMUIsYUFBYSxHQUFHLFdBQVcsTUFBTSxNQUFNLE9BQU87SUFDOUMsYUFBYSxHQUFHLFdBQVcsTUFBTSxNQUFNLE9BQU87SUFDOUM7R0FDSjtHQUNBLElBQUksRUFBRTtFQUNWO0VBQ0EsSUFBSSxFQUFFO0NBQ1YsU0FBUyxNQUFNO0FBQ25CO0FBR0EsSUFBSSxjQUFjOztBQUlsQixTQUFTLGVBQWUsTUFBTSxhQUFhLFdBQVcsS0FBSztDQUN2RCxNQUFNLFFBQVEsQ0FBQztDQUVmLEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxZQUFZLFFBQVEsSUFBSSxLQUFLLEtBQUs7RUFHcEQsTUFBTSxPQUE0QixXQUFXLE1BRi9CLFlBQVksS0FBSyxLQUNuQixJQUFJLE1BQU0sSUFBSSxZQUFZLElBQUksS0FBSyxNQUFNLEtBQUssUUFDSyxLQUFLLEtBQUs7RUFDekUsSUFBSSxTQUFTLEtBQUssTUFBTSxTQUFTLElBQUksSUFBSTtFQUN6QyxNQUFNLEtBQUssWUFBWSxJQUFJLENBQUM7Q0FDaEM7Q0FFQSxNQUFNLEtBQUssY0FBYztDQUl6QixnQkFBZ0IsS0FBSyxTQUFTLEtBQUssWUFBWSxNQUFNO0NBQ3JELGFBQWEsV0FBVyxTQUFTO0NBSWpDLGNBQWM7Q0FDZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQzlCLFlBQVksY0FBYyxNQUFNLElBQUksU0FBUztDQUVqRCxjQUFjO0NBR2QsT0FBTyxhQUFhLFNBQVM7QUFDakM7O0FBR0EsU0FBUyxlQUFlLEdBQUcsR0FBRztDQUcxQixPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsTUFDdkIsRUFBRSxLQUFLLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxJQUFJLEVBQUUsTUFDaEMsRUFBRSxLQUFLLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxJQUFJLEVBQUU7QUFDekM7O0FBSUEsU0FBUyxjQUFjLE1BQU0sV0FBVztDQUNwQyxNQUFNLFNBQVMsZUFBZSxNQUFNLFNBQVM7Q0FDN0MsSUFBSSxDQUFDLFFBQ0QsT0FBTztDQUdYLE1BQU0sZ0JBQWdCLGFBQWEsUUFBUSxJQUFJO0NBTS9DLE1BQU0sVUFBVSxjQUFjO0NBQzlCLGFBQWEsUUFBUSxRQUFRLElBQUk7Q0FHakMsYUFBYSxlQUFlLGNBQWMsSUFBSTtDQUM5QyxPQUFPLGFBQWEsUUFBUSxPQUFPLElBQUk7QUFDM0M7QUFhQSxJQUFNLElBQUk7QUFFVixJQUFJLDRCQUFZLElBQUksYUFBYSxDQUFDO0FBQ2xDLElBQUksWUFBWTs7QUFFaEIsSUFBTSxZQUFZLENBQUM7O0FBRW5CLElBQU0sWUFBWSxDQUFDOztBQUduQixTQUFTLGdCQUFnQixVQUFVLFVBQVU7Q0FHekMsTUFBTSxZQUFZLEtBQUssTUFBTSxXQUFXLElBQUksWUFBWSxDQUFDLElBQUksV0FBVztDQUN4RSxJQUFJLFVBQVUsU0FBUyxZQUFZLEdBQUcsWUFBWSxJQUFJLGFBQWEsWUFBWSxDQUFDO0NBQ2hGLFlBQVk7QUFDaEI7O0FBS0EsU0FBUyxhQUFhLE1BQU0sTUFBTTtDQUM5QixJQUFJLElBQUk7Q0FDUixHQUFHO0VBQ0MsTUFBTSxJQUFJO0VBQ1YsVUFBVSxLQUFLO0VBQ2YsSUFBSSxPQUFPLEVBQUUsR0FBRyxPQUFPLEVBQUUsR0FBRyxPQUFPLEVBQUUsR0FBRyxPQUFPLEVBQUU7RUFDakQsSUFBSSxJQUFJO0VBQ1IsR0FBRztHQUNDLE1BQU0sSUFBSSxFQUFFO0dBQ1osRUFBRSxJQUFJO0dBQ04sSUFBSSxFQUFFLElBQUksTUFBTSxPQUFPLEVBQUU7R0FBRyxJQUFJLEVBQUUsSUFBSSxNQUFNLE9BQU8sRUFBRTtHQUNyRCxJQUFJLEVBQUUsSUFBSSxNQUFNLE9BQU8sRUFBRTtHQUFHLElBQUksRUFBRSxJQUFJLE1BQU0sT0FBTyxFQUFFO0dBQ3JELElBQUk7RUFDUixTQUFTLEVBQUUsSUFBSSxLQUFLLE1BQU07RUFDMUIsVUFBVSxLQUFLO0VBQ2YsTUFBTSxJQUFJLElBQUk7RUFDZCxVQUFVLEtBQUs7RUFBTSxVQUFVLElBQUksS0FBSztFQUFNLFVBQVUsSUFBSSxLQUFLO0VBQU0sVUFBVSxJQUFJLEtBQUs7Q0FDOUYsU0FBUyxNQUFNO0FBQ25COztBQU1BLFNBQVMsVUFBVSxNQUFNLE1BQU07Q0FDM0IsTUFBTSxJQUFJLEtBQUssSUFBSTtDQUNuQixJQUFJLEtBQUssSUFBSSxVQUFVLElBQUksVUFBVSxLQUFLLEtBQUs7Q0FDL0MsSUFBSSxLQUFLLElBQUksVUFBVSxJQUFJLElBQUksVUFBVSxJQUFJLEtBQUssS0FBSztDQUN2RCxJQUFJLEtBQUssSUFBSSxVQUFVLElBQUksSUFBSSxVQUFVLElBQUksS0FBSyxLQUFLO0NBQ3ZELElBQUksS0FBSyxJQUFJLFVBQVUsSUFBSSxJQUFJLFVBQVUsSUFBSSxLQUFLLEtBQUs7QUFDM0Q7O0FBR0EsU0FBUyxjQUFjLEdBQUc7Q0FDdEIsSUFBSSxPQUFPLFVBQVU7Q0FDckIsT0FBTyxLQUFLLEtBQUssU0FBUyxNQUFNLE9BQU8sS0FBSztDQUM1QyxVQUFVLEtBQUs7Q0FDZixPQUFPO0FBQ1g7O0FBT0EsU0FBUyxjQUFjLEdBQUc7Q0FDdEIsSUFBSSxPQUFPLFVBQVU7Q0FDckIsT0FBTyxLQUFLLEtBQUssU0FBUyxNQUFNLE9BQU8sS0FBSztDQUM1QyxVQUFVLEtBQUs7Q0FDZixPQUFPO0FBQ1g7O0FBSUEsU0FBUyxlQUFlLE1BQU0sV0FBVztDQUNyQyxJQUFJLElBQUk7Q0FDUixNQUFNLEtBQUssS0FBSztDQUNoQixNQUFNLEtBQUssS0FBSztDQUNoQixJQUFJLEtBQUs7O0NBRVQsSUFBSTtDQUtKLElBQUksT0FBTyxNQUFNLENBQUMsR0FBRyxPQUFPO0NBSTVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksV0FBVyxLQUFLLEtBQUssR0FBRztFQUMvQyxJQUFJLEtBQUssVUFBVSxJQUFJLE1BQU0sS0FBSyxVQUFVLElBQUksTUFBTSxVQUFVLEtBQUssTUFBTSxVQUFVLElBQUksTUFBTSxJQUFJO0VBR25HLE1BQU0sT0FBTyxjQUFjLENBQUM7RUFFNUIsSUFBSSxjQUFjLENBQUM7RUFDbkIsR0FBRztHQUNDLElBQUksRUFBRSxLQUFLLFNBQVMsR0FBRztJQUNuQixJQUFJLE9BQU8sTUFBTSxFQUFFLElBQUksR0FBRyxPQUFPLEVBQUU7U0FDOUIsSUFBSSxNQUFNLEVBQUUsS0FBSyxNQUFNLEVBQUUsS0FBSyxLQUFLLEVBQUUsS0FBSyxNQUFNLEVBQUUsR0FBRztLQUN0RCxNQUFNLElBQUksRUFBRSxLQUFLLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssSUFBSSxFQUFFO0tBQzlELElBQUksS0FBSyxNQUFNLElBQUksSUFBSTtNQUNuQixLQUFLO01BQ0wsSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLElBQUksSUFBSSxFQUFFO01BQzNCLElBQUksTUFBTSxJQUFJLE9BQU87S0FDekI7SUFDSjtHQUNKO0dBQ0EsSUFBSSxFQUFFO0VBQ1YsU0FBUyxNQUFNO0NBQ25CO0NBRUEsSUFBSSxDQUFDLEdBQUcsT0FBTztDQU1mLE1BQU0sS0FBSyxFQUFFO0NBQ2IsTUFBTSxLQUFLLEVBQUU7Q0FDYixNQUFNLFFBQVEsS0FBSyxJQUFJLElBQUksRUFBRTtDQUM3QixNQUFNLFFBQVEsS0FBSyxJQUFJLElBQUksRUFBRTtDQUM3QixJQUFJLFNBQVM7Q0FHYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLFdBQVcsS0FBSyxLQUFLLEdBQUc7RUFDL0MsSUFBSSxVQUFVLElBQUksS0FBSyxNQUFNLFVBQVUsS0FBSyxNQUFNLFVBQVUsSUFBSSxLQUFLLFNBQVMsVUFBVSxJQUFJLEtBQUssT0FBTztFQUV4RyxNQUFNLE9BQU8sY0FBYyxDQUFDO0VBRTVCLElBQUksY0FBYyxDQUFDO0VBQ25CLEdBQUc7R0FDQyxJQUFJLEVBQUUsS0FBSyxTQUFTLEtBQUssTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLE1BQU0sT0FBTyxFQUFFLEtBQ3BELGdCQUFnQixLQUFLLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssS0FBSyxLQUFLLElBQUksSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQUc7SUFFckYsTUFBTSxNQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsQ0FBQyxLQUFLLEtBQUssRUFBRTtJQUl6QyxLQUFLLGNBQWMsR0FBRyxJQUFJLEtBQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxLQUFLLE1BQU0sTUFBTSxFQUFFLEtBQUssSUFBSSxRQUN2RSxNQUFNLFVBQVcsUUFBUSxXQUFXLEVBQUUsSUFBSSxFQUFFLEtBQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxxQkFBcUIsR0FBRyxDQUFDLEtBQU87S0FDbEcsSUFBSTtLQUNKLFNBQVM7SUFDYjtHQUNKO0dBRUEsSUFBSSxFQUFFO0VBQ1YsU0FBUyxNQUFNO0NBQ25CO0NBRUEsT0FBTztBQUNYOztBQUlBLFNBQVMscUJBQXFCLEdBQUcsR0FBRztDQUNoQyxPQUFPLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLElBQUksS0FBSyxLQUFLLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxJQUFJO0FBQ3BFOztBQU9BLElBQU0sVUFBVSxDQUFDOztBQUVqQixJQUFJLFVBQVUsQ0FBQztBQUNmLElBQUksdUJBQU8sSUFBSSxZQUFZLENBQUM7QUFDNUIsSUFBSSx1QkFBTyxJQUFJLFlBQVksQ0FBQztBQUM1QixJQUFNLHlCQUFTLElBQUksWUFBWSxHQUFHOztBQUlsQyxTQUFTLFdBQVcsT0FBTyxNQUFNLE1BQU0sU0FBUztDQUM1QyxJQUFJLElBQUk7Q0FDUixJQUFJLElBQUk7Q0FDUixHQUFHO0VBRUMsRUFBRSxJQUFJLE9BQU8sRUFBRSxHQUFHLEVBQUUsR0FBRyxNQUFNLE1BQU0sT0FBTztFQUMxQyxRQUFRLE9BQU87RUFDZixJQUFJLEVBQUU7Q0FDVixTQUFTLE1BQU07Q0FFZixVQUFVLENBQUM7O0NBR1gsSUFBSSxPQUFPO0NBQ1gsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztFQUN4QixNQUFNLE9BQU8sUUFBUTtFQUNyQixLQUFLLFFBQVE7RUFDYixJQUFJLE1BQU0sS0FBSyxRQUFRO0VBQ3ZCLE9BQU87Q0FDWDtxQkFDb0IsS0FBTyxRQUFRO0NBSW5DLFFBQVEsS0FBa0QsTUFBUSxHQUFHLENBQUM7Q0FDdEUsUUFBUSxLQUFrRCxNQUFRLEdBQUcsQ0FBQztBQUMxRTs7QUFLQSxTQUFTLFVBQVUsR0FBRztDQUNsQixJQUFJLEtBQUssSUFBSTtFQUNULEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7R0FDeEIsTUFBTSxPQUFPLFFBQVEsSUFBSSxJQUFJLEtBQUs7R0FDbEMsSUFBSSxJQUFJLElBQUk7R0FDWixPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEdBQUc7SUFBRSxRQUFRLElBQUksS0FBSyxRQUFRO0lBQUk7R0FBSztHQUN2RSxRQUFRLElBQUksS0FBSztFQUNyQjtFQUNBO0NBQ0o7Q0FFQSxJQUFJLEtBQUssU0FBUyxHQUFHO0VBQ2pCLE9BQU8sSUFBSSxZQUFZLENBQUM7RUFDeEIsT0FBTyxJQUFJLFlBQVksQ0FBQztFQUN4QixVQUFVLElBQUksTUFBTSxDQUFDO0NBQ3pCO0NBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUM7Q0FHakQsVUFBVSxHQUFHLFNBQVMsTUFBTSxTQUFTLE1BQU0sQ0FBQztDQUM1QyxVQUFVLEdBQUcsU0FBUyxNQUFNLFNBQVMsTUFBTSxDQUFDO0NBQzVDLFVBQVUsR0FBRyxTQUFTLE1BQU0sU0FBUyxNQUFNLEVBQUU7Q0FDN0MsVUFBVSxHQUFHLFNBQVMsTUFBTSxTQUFTLE1BQU0sRUFBRTtBQUNqRDs7QUFLQSxTQUFTLFVBQVUsR0FBRyxLQUFLLE1BQU0sS0FBSyxNQUFNLE9BQU87Q0FDL0MsT0FBTyxLQUFLLENBQUM7Q0FDYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLLE9BQVEsS0FBSyxPQUFPLFFBQVMsSUFBSztDQUU5RCxJQUFJLE1BQU07Q0FDVixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0VBQUUsTUFBTSxJQUFJLE9BQU87RUFBSSxPQUFPLEtBQUs7RUFBSyxPQUFPO0NBQUc7Q0FDaEYsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztFQUN4QixNQUFNLElBQUksS0FBSztFQUNmLE1BQU0sTUFBTSxPQUFRLE1BQU0sUUFBUyxJQUFLO0VBQ3hDLElBQUksT0FBTyxJQUFJO0VBQ2YsS0FBSyxPQUFPO0NBQ2hCO0FBQ0o7O0FBSUEsU0FBUyxPQUFPLEdBQUcsR0FBRyxNQUFNLE1BQU0sU0FBUztDQUV2QyxLQUFLLElBQUksUUFBUSxVQUFVO0NBQzNCLEtBQUssSUFBSSxRQUFRLFVBQVU7Q0FFM0IsS0FBSyxJQUFLLEtBQUssS0FBTTtDQUNyQixLQUFLLElBQUssS0FBSyxLQUFNO0NBQ3JCLEtBQUssSUFBSyxLQUFLLEtBQU07Q0FDckIsS0FBSyxJQUFLLEtBQUssS0FBTTtDQUVyQixLQUFLLElBQUssS0FBSyxLQUFNO0NBQ3JCLEtBQUssSUFBSyxLQUFLLEtBQU07Q0FDckIsS0FBSyxJQUFLLEtBQUssS0FBTTtDQUNyQixLQUFLLElBQUssS0FBSyxLQUFNO0NBRXJCLE9BQU8sSUFBSyxLQUFLO0FBQ3JCOztBQUlBLFNBQVMsWUFBWSxPQUFPO0NBQ3hCLElBQUksSUFBSSxPQUNKLFdBQVc7Q0FDZixHQUFHO0VBQ0MsSUFBSSxFQUFFLElBQUksU0FBUyxLQUFNLEVBQUUsTUFBTSxTQUFTLEtBQUssRUFBRSxJQUFJLFNBQVMsR0FBSSxXQUFXO0VBQzdFLElBQUksRUFBRTtDQUNWLFNBQVMsTUFBTTtDQUVmLE9BQU87QUFDWDs7QUFJQSxTQUFTLGdCQUFnQixJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDckQsUUFBUSxLQUFLLE9BQU8sS0FBSyxRQUFRLEtBQUssT0FBTyxLQUFLLFFBQzFDLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPLEtBQUssUUFDMUMsS0FBSyxPQUFPLEtBQUssUUFBUSxLQUFLLE9BQU8sS0FBSztBQUN0RDs7QUFJQSxTQUFTLGdCQUFnQixHQUFHLEdBQUc7Q0FDM0IsTUFBTSxhQUFhLE9BQU8sR0FBRyxDQUFDLEtBQUssS0FBSyxFQUFFLE1BQU0sR0FBRyxFQUFFLElBQUksSUFBSSxLQUFLLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLElBQUk7Q0FDNUYsT0FBTyxFQUFFLEtBQUssTUFBTSxFQUFFLE1BQU0sY0FBYyxjQUFjLEdBQUcsQ0FBQyxLQUFLLGNBQWMsR0FBRyxDQUFDLE1BQzlFLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU0sS0FBSyxLQUFLLEdBQUcsRUFBRSxNQUFNLENBQUMsTUFBTSxPQUN6RCxDQUFDLGtCQUFrQixHQUFHLENBQUMsTUFBTSxjQUFjLGFBQWEsR0FBRyxDQUFDO0FBQ3BFOztBQUlBLFNBQVMsS0FBSyxHQUFHLEdBQUcsR0FBRztDQUNuQixRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFO0FBQzlEOztBQUlBLFNBQVMsT0FBTyxJQUFJLElBQUk7Q0FDcEIsT0FBTyxHQUFHLE1BQU0sR0FBRyxLQUFLLEdBQUcsTUFBTSxHQUFHO0FBQ3hDOztBQUlBLFNBQVMsV0FBVyxJQUFJLElBQUksSUFBSSxJQUFJLGtCQUFrQixNQUFNO0NBQ3hELE1BQU0sS0FBSyxLQUFLLElBQUksSUFBSSxFQUFFO0NBQzFCLE1BQU0sS0FBSyxLQUFLLElBQUksSUFBSSxFQUFFO0NBQzFCLE1BQU0sS0FBSyxLQUFLLElBQUksSUFBSSxFQUFFO0NBQzFCLE1BQU0sS0FBSyxLQUFLLElBQUksSUFBSSxFQUFFO0NBRTFCLEtBQU0sS0FBSyxLQUFLLEtBQUssS0FBTyxLQUFLLEtBQUssS0FBSyxPQUFTLEtBQUssS0FBSyxLQUFLLEtBQU8sS0FBSyxLQUFLLEtBQUssSUFBSyxPQUFPO0NBRXJHLElBQUksQ0FBQyxpQkFBaUIsT0FBTztDQUU3QixJQUFJLE9BQU8sS0FBSyxVQUFVLElBQUksSUFBSSxFQUFFLEdBQUcsT0FBTztDQUM5QyxJQUFJLE9BQU8sS0FBSyxVQUFVLElBQUksSUFBSSxFQUFFLEdBQUcsT0FBTztDQUM5QyxJQUFJLE9BQU8sS0FBSyxVQUFVLElBQUksSUFBSSxFQUFFLEdBQUcsT0FBTztDQUM5QyxJQUFJLE9BQU8sS0FBSyxVQUFVLElBQUksSUFBSSxFQUFFLEdBQUcsT0FBTztDQUU5QyxPQUFPO0FBQ1g7O0FBSUEsU0FBUyxVQUFVLEdBQUcsR0FBRyxHQUFHO0NBQ3hCLE9BQU8sRUFBRSxLQUFLLEtBQUssSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxLQUFLLEtBQUssSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxLQUFLLEtBQUssSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxLQUFLLEtBQUssSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDO0FBQzFIOztBQUlBLFNBQVMsa0JBQWtCLEdBQUcsR0FBRztDQUc3QixNQUFNLE9BQU8sS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUM7Q0FDOUIsTUFBTSxPQUFPLEtBQUssSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDO0NBQzlCLE1BQU0sT0FBTyxLQUFLLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztDQUM5QixNQUFNLE9BQU8sS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUM7Q0FFOUIsSUFBSSxJQUFJO0NBQ1IsR0FBRztFQUNDLE1BQU0sSUFBSSxFQUFFO0VBQ1osSUFBSyxFQUFFLElBQUksUUFBUSxFQUFFLElBQUksUUFBVSxFQUFFLElBQUksUUFBUSxFQUFFLElBQUksUUFDbEQsRUFBRSxJQUFJLFFBQVEsRUFBRSxJQUFJLFFBQVUsRUFBRSxJQUFJLFFBQVEsRUFBRSxJQUFJLE1BQU87R0FDMUQsSUFBSTtHQUNKO0VBQ0o7RUFDQSxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEtBQ25ELFdBQVcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLE9BQU87RUFDdkMsSUFBSTtDQUNSLFNBQVMsTUFBTTtDQUVmLE9BQU87QUFDWDs7QUFJQSxTQUFTLGNBQWMsR0FBRyxHQUFHO0NBQ3pCLE9BQU8sS0FBSyxFQUFFLE1BQU0sR0FBRyxFQUFFLElBQUksSUFBSSxJQUM3QixLQUFLLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxLQUFLLEtBQUssR0FBRyxFQUFFLE1BQU0sQ0FBQyxLQUFLLElBQ2pELEtBQUssR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDdkQ7O0FBSUEsU0FBUyxhQUFhLEdBQUcsR0FBRztDQUN4QixJQUFJLElBQUk7Q0FDUixJQUFJLFNBQVM7Q0FDYixNQUFNLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSztDQUN6QixNQUFNLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSztDQUN6QixHQUFHO0VBQ0MsTUFBTSxJQUFJLEVBQUU7RUFDWixJQUFNLEVBQUUsSUFBSSxPQUFTLEVBQUUsSUFBSSxNQUFTLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxLQUFLLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FDaEYsU0FBUyxDQUFDO0VBQ2QsSUFBSTtDQUNSLFNBQVMsTUFBTTtDQUVmLE9BQU87QUFDWDs7QUFLQSxTQUFTLGFBQWEsR0FBRyxHQUFHO0NBQ3hCLE1BQU0sS0FBSyxXQUFXLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLEdBQy9CLEtBQUssV0FBVyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxHQUM3QixLQUFLLEVBQUUsTUFDUCxLQUFLLEVBQUU7Q0FFWCxFQUFFLE9BQU87Q0FDVCxFQUFFLE9BQU87Q0FFVCxHQUFHLE9BQU87Q0FDVixHQUFHLE9BQU87Q0FFVixHQUFHLE9BQU87Q0FDVixHQUFHLE9BQU87Q0FFVixHQUFHLE9BQU87Q0FDVixHQUFHLE9BQU87Q0FFVixPQUFPO0FBQ1g7O0FBSUEsU0FBUyxXQUFXLEdBQUcsR0FBRyxHQUFHLE1BQU07Q0FDL0IsTUFBTSxJQUFJLFdBQVcsR0FBRyxHQUFHLENBQUM7Q0FFNUIsSUFBSSxDQUFDLE1BQU07RUFDUCxFQUFFLE9BQU87RUFDVCxFQUFFLE9BQU87Q0FFYixPQUFPO0VBQ0gsRUFBRSxPQUFPLEtBQUs7RUFDZCxFQUFFLE9BQU87RUFDVCxLQUFLLEtBQUssT0FBTztFQUNqQixLQUFLLE9BQU87Q0FDaEI7Q0FDQSxPQUFPO0FBQ1g7O0FBR0EsU0FBUyxXQUFXLEdBQUc7Q0FDbkIsRUFBRSxLQUFLLE9BQU8sRUFBRTtDQUNoQixFQUFFLEtBQUssT0FBTyxFQUFFO0NBRWhCLElBQUksRUFBRSxPQUFPLEVBQUUsTUFBTSxRQUFRLEVBQUU7Q0FDL0IsSUFBSSxFQUFFLE9BQU8sRUFBRSxNQUFNLFFBQVEsRUFBRTtDQUcvQixJQUFJLGFBQWEsVUFBVSxFQUFFLE1BQU0sRUFBRSxJQUFJO0FBQzdDOztBQUdBLFNBQVMsV0FBVyxHQUFHLEdBQUcsR0FBRztDQUV6QixPQUFvRDtFQUNoRDtFQUNBO0VBQUc7RUFDSCxNQUFNO0VBQ04sTUFBTTtFQUNOLEdBQUc7RUFDSCxPQUFPO0VBQ1AsT0FBTztDQUNYO0FBQ0o7O0FBK0NBLFNBQVMsV0FBVyxNQUFNLE9BQU8sS0FBSyxLQUFLO0NBQ3ZDLElBQUksTUFBTTtDQUNWLEtBQUssSUFBSSxJQUFJLE9BQU8sSUFBSSxNQUFNLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSztFQUNsRCxRQUFRLEtBQUssS0FBSyxLQUFLLE9BQU8sS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJO0VBQ3JELElBQUk7Q0FDUjtDQUNBLE9BQU87QUFDWDs7O0FDcDFCQSxJQUFNLFNBQVNDLFNBQWEsV0FBV0E7Ozs7QUNGdkMsSUFBTSxTQUFTO0NBQ2QsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztBQUNKOztBQUVBLElBQU0sVUFBVTs7QUFFaEIsSUFBTSxTQUFTOzs7Ozs7Ozs7Ozs7O0FBYWYsU0FBUyxNQUFNLE1BQU07Q0FDcEIsTUFBTSxPQUFPLENBQUM7Q0FDZCxLQUFLLFFBQVEsVUFBVSxHQUFHLEtBQUssU0FBUztFQUN2QyxJQUFJLE9BQU8sSUFBSSxZQUFZO0VBQzNCLElBQUksVUFBVTtFQUNkLE1BQU0sU0FBUyxZQUFZLElBQUk7RUFDL0IsSUFBSSxTQUFTLE9BQU8sT0FBTyxTQUFTLEdBQUc7R0FDdEMsS0FBSyxLQUFLLENBQUMsU0FBUyxHQUFHLE9BQU8sT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDO0dBQzNDLE9BQU87R0FDUCxVQUFVLFlBQVksTUFBTSxNQUFNO0VBQ25DO0VBQ0EsT0FBTyxNQUFNO0dBQ1osSUFBSSxPQUFPLFdBQVcsT0FBTyxPQUFPO0lBQ25DLEtBQUssS0FBSyxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUM7SUFDOUIsT0FBTztHQUNSO0dBQ0EsSUFBSSxPQUFPLFNBQVMsT0FBTyxPQUFPLE1BQU0sSUFBSSxNQUFNLHFCQUFxQjtHQUN2RSxLQUFLLEtBQUssQ0FBQyxTQUFTLEdBQUcsT0FBTyxPQUFPLEdBQUcsT0FBTyxLQUFLLENBQUMsQ0FBQztFQUN2RDtDQUNELENBQUM7Q0FDRCxPQUFPO0FBQ1I7O0FBRUEsU0FBUyxZQUFZLE1BQU07Q0FDMUIsTUFBTSxVQUFVLEtBQUssTUFBTSxNQUFNO0NBQ2pDLE9BQU8sVUFBVSxRQUFRLElBQUksTUFBTSxJQUFJLENBQUM7QUFDekM7OztBQ3BEQSxTQUFTLGFBQWEsU0FBUyxNQUFNO0NBQ25DLE1BQU0sV0FBVyxNQUFNLE9BQU87Q0FDOUIsTUFBTSxXQUFXLENBQUM7Q0FDbEIsSUFBSSxpQkFBaUI7Q0FDckIsSUFBSSxRQUFRO0NBQ1osSUFBSSxRQUFRO0NBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0VBQ3hDLE1BQU0sVUFBVSxTQUFTO0VBQ3pCLE1BQU0sT0FBTyxRQUFRO0VBQ3JCLE1BQU0sT0FBTztFQUNiLFFBQVEsTUFBUjtHQUNFLEtBQUs7SUFDSCxRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUs7SUFDYixLQUFLLE9BQU8sT0FBTyxLQUFLO0lBQ3hCO0dBQ0YsS0FBSztJQUNILFNBQVMsS0FBSztJQUNkLFNBQVMsS0FBSztJQUNkLEtBQUssT0FBTyxPQUFPLEtBQUs7SUFDeEI7R0FDRixLQUFLO0lBQ0gsUUFBUSxLQUFLO0lBQ2IsS0FBSyxPQUFPLE9BQU8sS0FBSztJQUN4QjtHQUNGLEtBQUs7SUFDSCxTQUFTLEtBQUs7SUFDZCxLQUFLLE9BQU8sT0FBTyxLQUFLO0lBQ3hCO0dBQ0YsS0FBSztJQUNILFFBQVEsS0FBSztJQUNiLEtBQUssT0FBTyxPQUFPLEtBQUs7SUFDeEI7R0FDRixLQUFLO0lBQ0gsU0FBUyxLQUFLO0lBQ2QsS0FBSyxPQUFPLE9BQU8sS0FBSztJQUN4QjtHQUNGLEtBQUs7SUFDSCxRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUs7SUFDYixLQUFLLE9BQU8sT0FBTyxLQUFLO0lBQ3hCO0dBQ0YsS0FBSztJQUNILFNBQVMsS0FBSztJQUNkLFNBQVMsS0FBSztJQUNkLEtBQUssT0FBTyxPQUFPLEtBQUs7SUFDeEI7R0FDRixLQUFLO0lBQ0gsUUFBUSxLQUFLO0lBQ2IsUUFBUSxLQUFLO0lBQ2IsS0FBSyxjQUNILEtBQUssSUFDTCxLQUFLLElBRUwsS0FBSyxJQUNMLEtBQUssSUFFTCxPQUNBLEtBRUY7SUFDQTtHQUNGLEtBQUs7SUFDSCxLQUFLLGNBQ0gsUUFBUSxLQUFLLElBQ2IsUUFBUSxLQUFLLElBRWIsUUFBUSxLQUFLLElBQ2IsUUFBUSxLQUFLLElBRWIsUUFBUSxLQUFLLElBQ2IsUUFBUSxLQUFLLEVBRWY7SUFDQSxTQUFTLEtBQUs7SUFDZCxTQUFTLEtBQUs7SUFDZDtHQUNGLEtBQUs7SUFDSCxRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUs7SUFDYixLQUFLLG1CQUNILEtBQUssSUFDTCxLQUFLLElBRUwsT0FDQSxLQUVGO0lBQ0E7R0FDRixLQUFLO0lBQ0gsS0FBSyxtQkFDSCxRQUFRLEtBQUssSUFDYixRQUFRLEtBQUssSUFFYixRQUFRLEtBQUssSUFDYixRQUFRLEtBQUssRUFFZjtJQUNBLFNBQVMsS0FBSztJQUNkLFNBQVMsS0FBSztJQUNkO0dBQ0YsS0FBSztJQUNILFFBQVEsS0FBSztJQUNiLFFBQVEsS0FBSztJQUNiLEtBQUssaUJBQ0gsS0FBSyxJQUNMLEtBQUssSUFFTCxPQUNBLEtBRUY7SUFDQTtHQUNGLEtBQUs7SUFDSCxLQUFLLGlCQUNILFFBQVEsS0FBSyxJQUNiLFFBQVEsS0FBSyxJQUViLFFBQVEsS0FBSyxJQUNiLFFBQVEsS0FBSyxFQUVmO0lBQ0EsU0FBUyxLQUFLO0lBQ2QsU0FBUyxLQUFLO0lBQ2Q7R0FDRixLQUFLO0lBQ0gsUUFBUSxLQUFLO0lBQ2IsUUFBUSxLQUFLO0lBQ2IsS0FBSyxzQkFDSCxPQUNBLEtBRUY7SUFDQTtHQUNGLEtBQUs7SUFDSCxTQUFTLEtBQUs7SUFDZCxTQUFTLEtBQUs7SUFDZCxLQUFLLHNCQUNILE9BQ0EsS0FFRjtJQUNBO0dBQ0YsS0FBSztJQUNILFFBQVEsS0FBSztJQUNiLFFBQVEsS0FBSztJQUNiLEtBQUssU0FDSCxLQUFLLElBRUwsS0FBSyxJQUVMLEtBQUssSUFFTCxLQUFLLElBRUwsS0FBSyxJQUVMLE9BQ0EsS0FFRjtJQUNBO0dBQ0YsS0FBSztJQUNILFNBQVMsS0FBSztJQUNkLFNBQVMsS0FBSztJQUNkLEtBQUssU0FDSCxLQUFLLElBRUwsS0FBSyxJQUVMLEtBQUssSUFFTCxLQUFLLElBRUwsS0FBSyxJQUVMLE9BQ0EsS0FFRjtJQUNBO0dBQ0YsS0FBSztHQUVMLEtBQUs7SUFDSCxLQUFLLFVBQVU7SUFDZixJQUFJLFNBQVMsU0FBUyxHQUFHO0tBQ3ZCLGlCQUFpQixTQUFTLElBQUk7S0FDOUIsSUFBSSxnQkFBZ0I7TUFDbEIsUUFBUSxlQUFlO01BQ3ZCLFFBQVEsZUFBZTtLQUN6QixPQUFPO01BQ0wsUUFBUTtNQUNSLFFBQVE7S0FDVjtJQUNGO0lBQ0EsaUJBQWlCO0lBQ2pCO0dBQ0YsU0FDRSxLQUFLLDZCQUE2QixNQUFNO0VBQzVDO0VBQ0EsSUFBSSxTQUFTLE9BQU8sU0FBUyxLQUN2QjtPQUFBLG1CQUFtQixNQUFNO0lBQzNCLGlCQUFpQjtLQUFFLFFBQVE7S0FBTyxRQUFRO0lBQU07SUFDaEQsU0FBUyxLQUFLLGNBQWM7R0FDOUI7O0NBRUo7Q0FDQSxPQUFPO0FBQ1Q7OztBQ2pOQSxJQUFNLFNBQU4sTUFBTSxPQUFPOzs7Ozs7Q0FNWCxZQUFZLElBQUksR0FBRyxJQUFJLEdBQUcsU0FBUyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXVCcEMsS0FBSyxPQUFPO0VBQ1osS0FBSyxJQUFJO0VBQ1QsS0FBSyxJQUFJO0VBQ1QsS0FBSyxTQUFTO0NBQ2hCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsUUFBUTtFQUNOLE9BQU8sSUFBSSxPQUFPLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxNQUFNO0NBQy9DOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTBCQSxTQUFTLEdBQUcsR0FBRztFQUNiLElBQUksS0FBSyxVQUFVLEdBQUcsT0FBTztFQUM3QixNQUFNLEtBQUssS0FBSyxTQUFTLEtBQUs7RUFDOUIsSUFBSSxLQUFLLEtBQUssSUFBSTtFQUNsQixJQUFJLEtBQUssS0FBSyxJQUFJO0VBQ2xCLE1BQU07RUFDTixNQUFNO0VBQ04sT0FBTyxLQUFLLE1BQU07Q0FDcEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsZUFBZSxHQUFHLEdBQUcsT0FBTyxZQUFZLElBQUs7RUFDM0MsSUFBSSxLQUFLLFdBQVcsR0FBRyxPQUFPO0VBQzlCLE1BQU0sS0FBSyxLQUFLLElBQUk7RUFDcEIsTUFBTSxLQUFLLEtBQUssSUFBSTtFQUNwQixNQUFNLFNBQVMsS0FBSztFQUNwQixNQUFNLGNBQWMsSUFBSSxhQUFhO0VBQ3JDLE1BQU0sV0FBVyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssRUFBRTtFQUM1QyxPQUFPLFlBQVksU0FBUyxjQUFjLFdBQVcsVUFBVSxRQUFRO0NBQ3pFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLFVBQVUsS0FBSztFQUNiLFFBQVEsTUFBTSxJQUFJLFVBQVU7RUFDNUIsSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLO0VBQ3RCLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztFQUN0QixJQUFJLFFBQVEsS0FBSyxTQUFTO0VBQzFCLElBQUksU0FBUyxLQUFLLFNBQVM7RUFDM0IsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxTQUFTLFFBQVE7RUFDZixLQUFLLElBQUksT0FBTztFQUNoQixLQUFLLElBQUksT0FBTztFQUNoQixLQUFLLFNBQVMsT0FBTztFQUNyQixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7OztDQWVBLE9BQU8sUUFBUTtFQUNiLE9BQU8sU0FBUyxJQUFJO0VBQ3BCLE9BQU87Q0FDVDtDQUNBLFdBQVc7RUFDVCxPQUFPLDBCQUEwQixLQUFLLEVBQUUsS0FBSyxLQUFLLEVBQUUsVUFBVSxLQUFLLE9BQU87Q0FDNUU7QUFDRjs7O0FDNUxBLElBQU0sVUFBTixNQUFNLFFBQVE7Ozs7Ozs7Q0FPWixZQUFZLElBQUksR0FBRyxJQUFJLEdBQUcsWUFBWSxHQUFHLGFBQWEsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBa0J2RCxLQUFLLE9BQU87RUFDWixLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLFlBQVk7RUFDakIsS0FBSyxhQUFhO0NBQ3BCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0JBLFFBQVE7RUFDTixPQUFPLElBQUksUUFBUSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssV0FBVyxLQUFLLFVBQVU7Q0FDcEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0JBLFNBQVMsR0FBRyxHQUFHO0VBQ2IsSUFBSSxLQUFLLGFBQWEsS0FBSyxLQUFLLGNBQWMsR0FDNUMsT0FBTztFQUVULElBQUksU0FBUyxJQUFJLEtBQUssS0FBSyxLQUFLO0VBQ2hDLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSyxLQUFLO0VBQ2hDLFNBQVM7RUFDVCxTQUFTO0VBQ1QsT0FBTyxRQUFRLFNBQVM7Q0FDMUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJCQSxlQUFlLEdBQUcsR0FBRyxhQUFhLFlBQVksSUFBSztFQUNqRCxNQUFNLEVBQUUsV0FBVyxlQUFlO0VBQ2xDLElBQUksYUFBYSxLQUFLLGNBQWMsR0FDbEMsT0FBTztFQUVULE1BQU0sbUJBQW1CLGVBQWUsSUFBSTtFQUM1QyxNQUFNLG1CQUFtQixjQUFjO0VBQ3ZDLE1BQU0sa0JBQWtCLFlBQVk7RUFDcEMsTUFBTSxnQkFBZ0IsYUFBYTtFQUNuQyxNQUFNLGtCQUFrQixZQUFZO0VBQ3BDLE1BQU0sZ0JBQWdCLGFBQWE7RUFDbkMsTUFBTSxjQUFjLElBQUksS0FBSztFQUM3QixNQUFNLGNBQWMsSUFBSSxLQUFLO0VBRTdCLElBRHFCLGNBQWMsZUFBZSxrQkFBa0IsbUJBQW1CLGNBQWMsZUFBZSxnQkFBZ0IsaUJBQ2pILEdBQUcsT0FBTztFQUM3QixJQUFJLG1CQUFtQixLQUFLLGlCQUFpQixHQUFHLE9BQU87RUFFdkQsT0FEcUIsY0FBYyxlQUFlLGtCQUFrQixtQkFBbUIsY0FBYyxlQUFlLGdCQUFnQixpQkFDOUc7Q0FDeEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXdCQSxVQUFVLEtBQUs7RUFDYixRQUFRLE1BQU0sSUFBSSxVQUFVO0VBQzVCLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztFQUN0QixJQUFJLElBQUksS0FBSyxJQUFJLEtBQUs7RUFDdEIsSUFBSSxRQUFRLEtBQUssWUFBWTtFQUM3QixJQUFJLFNBQVMsS0FBSyxhQUFhO0VBQy9CLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsU0FBUyxTQUFTO0VBQ2hCLEtBQUssSUFBSSxRQUFRO0VBQ2pCLEtBQUssSUFBSSxRQUFRO0VBQ2pCLEtBQUssWUFBWSxRQUFRO0VBQ3pCLEtBQUssYUFBYSxRQUFRO0VBQzFCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsT0FBTyxTQUFTO0VBQ2QsUUFBUSxTQUFTLElBQUk7RUFDckIsT0FBTztDQUNUO0NBQ0EsV0FBVztFQUNULE9BQU8sMkJBQTJCLEtBQUssRUFBRSxLQUFLLEtBQUssRUFBRSxhQUFhLEtBQUssVUFBVSxjQUFjLEtBQUssV0FBVztDQUNqSDtBQUNGOzs7QUM1TUEsU0FBUyx1QkFBdUIsUUFBUTtDQUN0QyxNQUFNLElBQUksT0FBTztDQUNqQixJQUFJLElBQUksR0FDTixPQUFPO0NBRVQsSUFBSSxPQUFPO0NBQ1gsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLE9BQU8sSUFBSSxJQUFJLEtBQUssT0FBTyxJQUFJLElBQUksSUFBSSxHQUFHLEtBQUssR0FBRztFQUNyRSxNQUFNLEtBQUssT0FBTztFQUNsQixNQUFNLEtBQUssT0FBTyxJQUFJO0VBQ3RCLFNBQVMsS0FBSyxPQUFPLEtBQUs7RUFDMUIsS0FBSztFQUNMLEtBQUs7Q0FDUDtDQUNBLElBQUksT0FBTyxHQUNULE9BQU87Q0FFVCxPQUFPO0FBQ1Q7OztBQ2pCQSxTQUFTLDZCQUE2QixHQUFHLEdBQUcsSUFBSSxJQUFJLElBQUksSUFBSTtDQUMxRCxNQUFNLElBQUksSUFBSTtDQUNkLE1BQU0sSUFBSSxJQUFJO0NBQ2QsTUFBTSxJQUFJLEtBQUs7Q0FDZixNQUFNLElBQUksS0FBSztDQUNmLE1BQU0sTUFBTSxJQUFJLElBQUksSUFBSTtDQUN4QixNQUFNLFFBQVEsSUFBSSxJQUFJLElBQUk7Q0FDMUIsSUFBSSxRQUFRO0NBQ1osSUFBSSxVQUFVLEdBQ1osUUFBUSxNQUFNO0NBRWhCLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxRQUFRLEdBQUc7RUFDYixLQUFLO0VBQ0wsS0FBSztDQUNQLE9BQU8sSUFBSSxRQUFRLEdBQUc7RUFDcEIsS0FBSztFQUNMLEtBQUs7Q0FDUCxPQUFPO0VBQ0wsS0FBSyxLQUFLLFFBQVE7RUFDbEIsS0FBSyxLQUFLLFFBQVE7Q0FDcEI7Q0FDQSxNQUFNLEtBQUssSUFBSTtDQUNmLE1BQU0sS0FBSyxJQUFJO0NBQ2YsT0FBTyxLQUFLLEtBQUssS0FBSztBQUN4Qjs7O0FDckJBLElBQUlDO0FBQ0osSUFBSTtBQUNKLElBQU0sVUFBTixNQUFNLFFBQVE7Ozs7Ozs7O0NBUVosWUFBWSxHQUFHLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFtQnJCLEtBQUssT0FBTztFQUNaLElBQUksT0FBTyxNQUFNLFFBQVEsT0FBTyxFQUFFLElBQUksT0FBTyxLQUFLO0VBQ2xELElBQUksT0FBTyxLQUFLLE9BQU8sVUFBVTtHQUMvQixNQUFNLElBQUksQ0FBQztHQUNYLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxLQUFLLFFBQVEsSUFBSSxJQUFJLEtBQ3hDLEVBQUUsS0FBSyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUM7R0FFN0IsT0FBTztFQUNUO0VBQ0EsS0FBSyxTQUFTO0VBQ2QsS0FBSyxZQUFZO0NBQ25COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3QkEsY0FBYztFQUNaLElBQUksT0FBTztFQUNYLE1BQU0sU0FBUyxLQUFLO0VBQ3BCLE1BQU0sU0FBUyxPQUFPO0VBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUssR0FBRztHQUNsQyxNQUFNLEtBQUssT0FBTztHQUNsQixNQUFNLEtBQUssT0FBTyxJQUFJO0dBQ3RCLE1BQU0sS0FBSyxRQUFRLElBQUksS0FBSztHQUM1QixNQUFNLEtBQUssUUFBUSxJQUFJLEtBQUs7R0FDNUIsU0FBUyxLQUFLLE9BQU8sS0FBSztFQUM1QjtFQUNBLE9BQU8sT0FBTztDQUNoQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLGdCQUFnQixTQUFTO0VBQ3ZCLE1BQU0sYUFBYSxLQUFLLFVBQVVBLFVBQVE7RUFDMUMsTUFBTSxjQUFjLFFBQVEsVUFBVSxTQUFTO0VBQy9DLElBQUksQ0FBQyxXQUFXLGFBQWEsV0FBVyxHQUN0QyxPQUFPO0VBRVQsTUFBTSxTQUFTLFFBQVE7RUFDdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLLEdBQUc7R0FDekMsTUFBTSxJQUFJLE9BQU87R0FDakIsTUFBTSxJQUFJLE9BQU8sSUFBSTtHQUNyQixJQUFJLENBQUMsS0FBSyxTQUFTLEdBQUcsQ0FBQyxHQUNyQixPQUFPO0VBRVg7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFFBQVE7RUFDTixNQUFNLFNBQVMsS0FBSyxPQUFPLE1BQU07RUFDakMsTUFBTSxVQUFVLElBQUksUUFBUSxNQUFNO0VBQ2xDLFFBQVEsWUFBWSxLQUFLO0VBQ3pCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxTQUFTLEdBQUcsR0FBRztFQUNiLElBQUksU0FBUztFQUNiLE1BQU0sU0FBUyxLQUFLLE9BQU8sU0FBUztFQUNwQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxHQUFHLElBQUksUUFBUSxJQUFJLEtBQUs7R0FDbkQsTUFBTSxLQUFLLEtBQUssT0FBTyxJQUFJO0dBQzNCLE1BQU0sS0FBSyxLQUFLLE9BQU8sSUFBSSxJQUFJO0dBQy9CLE1BQU0sS0FBSyxLQUFLLE9BQU8sSUFBSTtHQUMzQixNQUFNLEtBQUssS0FBSyxPQUFPLElBQUksSUFBSTtHQUUvQixJQURrQixLQUFLLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSyxRQUFRLElBQUksT0FBTyxLQUFLLE9BQU8sSUFFOUUsU0FBUyxDQUFDO0VBRWQ7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsZUFBZSxHQUFHLEdBQUcsYUFBYSxZQUFZLElBQUs7RUFDakQsTUFBTSxFQUFFLFdBQVc7RUFFbkIsTUFBTSxhQUFhLGVBRE0sY0FBYyxLQUFNLGFBQWEsWUFBWSxNQUFPLHVCQUF1QixNQUFNLElBQUk7RUFFOUcsTUFBTSxhQUFhLGNBQWM7RUFDakMsTUFBTSxvQkFBb0IsYUFBYTtFQUN2QyxNQUFNLG9CQUFvQixhQUFhO0VBQ3ZDLE1BQU0sa0JBQWtCLE9BQU8sVUFBVSxLQUFLLFlBQVksSUFBSTtFQUM5RCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksaUJBQWlCLEtBQUssR0FBRztHQUMzQyxNQUFNLEtBQUssT0FBTztHQUNsQixNQUFNLEtBQUssT0FBTyxJQUFJO0dBQ3RCLE1BQU0sS0FBSyxRQUFRLElBQUksS0FBSyxPQUFPO0dBQ25DLE1BQU0sS0FBSyxRQUFRLElBQUksS0FBSyxPQUFPO0dBR25DLElBRndCLDZCQUE2QixHQUFHLEdBQUcsSUFBSSxJQUFJLElBQUksRUFFckQsTUFETCxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sSUFBSSxHQUNwQyxJQUFJLElBQUksb0JBQW9CLG9CQUNyRCxPQUFPO0VBRVg7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsVUFBVSxLQUFLO0VBQ2IsUUFBUSxNQUFNLElBQUksVUFBVTtFQUM1QixNQUFNLFNBQVMsS0FBSztFQUNwQixJQUFJLE9BQU87RUFDWCxJQUFJLE9BQU87RUFDWCxJQUFJLE9BQU87RUFDWCxJQUFJLE9BQU87RUFDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLElBQUksR0FBRyxLQUFLLEdBQUc7R0FDaEQsTUFBTSxJQUFJLE9BQU87R0FDakIsTUFBTSxJQUFJLE9BQU8sSUFBSTtHQUNyQixPQUFPLElBQUksT0FBTyxJQUFJO0dBQ3RCLE9BQU8sSUFBSSxPQUFPLElBQUk7R0FDdEIsT0FBTyxJQUFJLE9BQU8sSUFBSTtHQUN0QixPQUFPLElBQUksT0FBTyxJQUFJO0VBQ3hCO0VBQ0EsSUFBSSxJQUFJO0VBQ1IsSUFBSSxRQUFRLE9BQU87RUFDbkIsSUFBSSxJQUFJO0VBQ1IsSUFBSSxTQUFTLE9BQU87RUFDcEIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxTQUFTLFNBQVM7RUFDaEIsS0FBSyxTQUFTLFFBQVEsT0FBTyxNQUFNO0VBQ25DLEtBQUssWUFBWSxRQUFRO0VBQ3pCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsT0FBTyxTQUFTO0VBQ2QsUUFBUSxTQUFTLElBQUk7RUFDckIsT0FBTztDQUNUO0NBQ0EsV0FBVztFQUNULE9BQU8sb0NBQW9DLEtBQUssVUFBVSxTQUFTLEtBQUssT0FBTyxRQUFRLFlBQVksaUJBQWlCLEdBQUcsV0FBVyxJQUFJLGdCQUFnQixFQUFFLEVBQUU7Q0FDNUo7Ozs7Ozs7Ozs7Ozs7O0NBY0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLFNBQVM7Q0FDMUM7Ozs7Ozs7Ozs7Ozs7O0NBY0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLFNBQVM7Q0FDMUM7Ozs7OztDQU1BLElBQUksSUFBSTtFQUNOLFlBQVksVUFBVSxnRUFBZ0U7RUFDdEYsT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLFNBQVM7Q0FDMUM7Ozs7OztDQU1BLElBQUksSUFBSTtFQUNOLFlBQVksVUFBVSw0REFBNEQ7RUFDbEYsT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLFNBQVM7Q0FDMUM7Ozs7Ozs7Ozs7Ozs7O0NBY0EsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLLE9BQU87Q0FDckI7Ozs7Ozs7Ozs7Ozs7O0NBY0EsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLLE9BQU87Q0FDckI7QUFDRjs7O0FDblhBLElBQU0sd0JBQXdCLElBQUksSUFBSSxTQUFTLFNBQVMsUUFBUSxrQkFBa0IscUJBQXFCO0NBQ3JHLE1BQU0sS0FBSyxLQUFLO0NBQ2hCLE1BQU0sS0FBSyxLQUFLO0NBQ2hCLE1BQU0sV0FBVyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssRUFBRTtDQUM1QyxPQUFPLFlBQVksU0FBUyxvQkFBb0IsWUFBWSxTQUFTO0FBQ3ZFO0FBQ0EsSUFBTSxtQkFBTixNQUFNLGlCQUFpQjs7Ozs7Ozs7Q0FRckIsWUFBWSxJQUFJLEdBQUcsSUFBSSxHQUFHLFFBQVEsR0FBRyxTQUFTLEdBQUcsU0FBUyxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFrQjVELEtBQUssT0FBTztFQUNaLEtBQUssSUFBSTtFQUNULEtBQUssSUFBSTtFQUNULEtBQUssUUFBUTtFQUNiLEtBQUssU0FBUztFQUNkLEtBQUssU0FBUztDQUNoQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxVQUFVLEtBQUs7RUFDYixRQUFRLE1BQU0sSUFBSSxVQUFVO0VBQzVCLElBQUksSUFBSSxLQUFLO0VBQ2IsSUFBSSxJQUFJLEtBQUs7RUFDYixJQUFJLFFBQVEsS0FBSztFQUNqQixJQUFJLFNBQVMsS0FBSztFQUNsQixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsUUFBUTtFQUNOLE9BQU8sSUFBSSxpQkFBaUIsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLE9BQU8sS0FBSyxRQUFRLEtBQUssTUFBTTtDQUNsRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvQkEsU0FBUyxXQUFXO0VBQ2xCLEtBQUssSUFBSSxVQUFVO0VBQ25CLEtBQUssSUFBSSxVQUFVO0VBQ25CLEtBQUssUUFBUSxVQUFVO0VBQ3ZCLEtBQUssU0FBUyxVQUFVO0VBQ3hCLEtBQUssU0FBUyxVQUFVO0VBQ3hCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvQkEsT0FBTyxXQUFXO0VBQ2hCLFVBQVUsU0FBUyxJQUFJO0VBQ3ZCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvQkEsU0FBUyxHQUFHLEdBQUc7RUFDYixJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssVUFBVSxHQUNwQyxPQUFPO0VBRVQsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLE9BQ2hDO09BQUEsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxRQUFRO0lBQzVDLE1BQU0sU0FBUyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxRQUFRLEtBQUssSUFBSSxLQUFLLE9BQU8sS0FBSyxNQUFNLElBQUksQ0FBQyxDQUFDO0lBQ3ZGLElBQUksS0FBSyxLQUFLLElBQUksVUFBVSxLQUFLLEtBQUssSUFBSSxLQUFLLFNBQVMsVUFBVSxLQUFLLEtBQUssSUFBSSxVQUFVLEtBQUssS0FBSyxJQUFJLEtBQUssUUFBUSxRQUNuSCxPQUFPO0lBRVQsSUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJO0lBQ3ZCLElBQUksS0FBSyxLQUFLLEtBQUssSUFBSTtJQUN2QixNQUFNLFVBQVUsU0FBUztJQUN6QixJQUFJLEtBQUssS0FBSyxLQUFLLE1BQU0sU0FDdkIsT0FBTztJQUVULEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxRQUFRO0lBQ2hDLElBQUksS0FBSyxLQUFLLEtBQUssTUFBTSxTQUN2QixPQUFPO0lBRVQsS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLFNBQVM7SUFDakMsSUFBSSxLQUFLLEtBQUssS0FBSyxNQUFNLFNBQ3ZCLE9BQU87SUFFVCxLQUFLLEtBQUssS0FBSyxJQUFJO0lBQ25CLElBQUksS0FBSyxLQUFLLEtBQUssTUFBTSxTQUN2QixPQUFPO0dBRVg7O0VBRUYsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0JBLGVBQWUsSUFBSSxJQUFJLGFBQWEsWUFBWSxJQUFLO0VBQ25ELE1BQU0sRUFBRSxHQUFHLEdBQUcsT0FBTyxRQUFRLFdBQVc7RUFDeEMsTUFBTSxtQkFBbUIsZUFBZSxJQUFJO0VBQzVDLE1BQU0sbUJBQW1CLGNBQWM7RUFDdkMsTUFBTSxTQUFTLElBQUk7RUFDbkIsTUFBTSxTQUFTLElBQUk7RUFDbkIsTUFBTSxhQUFhLFFBQVEsU0FBUztFQUNwQyxNQUFNLGNBQWMsU0FBUyxTQUFTO0VBQ3RDLE1BQU0sYUFBYSxJQUFJO0VBQ3ZCLE1BQU0sY0FBYyxJQUFJO0VBQ3hCLEtBQUssTUFBTSxJQUFJLG9CQUFvQixNQUFNLElBQUksb0JBQW9CLE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxhQUFhLHFCQUFxQixNQUFNLFVBQVUsTUFBTSxTQUFTLGFBQzdLLE9BQU87RUFFVCxLQUFLLE1BQU0sSUFBSSxvQkFBb0IsTUFBTSxJQUFJLG9CQUFvQixNQUFNLGNBQWMsb0JBQW9CLE1BQU0sY0FBYyxxQkFBcUIsTUFBTSxVQUFVLE1BQU0sU0FBUyxZQUMvSyxPQUFPO0VBRVQsT0FFRSxLQUFLLFVBQVUsS0FBSyxVQUFVLHFCQUM1QixJQUNBLElBQ0EsUUFDQSxRQUNBLFFBQ0Esa0JBQ0EsZ0JBQ0YsS0FBSyxLQUFLLGFBQWEsVUFBVSxLQUFLLFVBQVUscUJBQzlDLElBQ0EsSUFDQSxhQUFhLFFBQ2IsUUFDQSxRQUNBLGtCQUNBLGdCQUNGLEtBQUssS0FBSyxhQUFhLFVBQVUsS0FBSyxjQUFjLFVBQVUscUJBQzVELElBQ0EsSUFDQSxhQUFhLFFBQ2IsY0FBYyxRQUNkLFFBQ0Esa0JBQ0EsZ0JBQ0YsS0FBSyxLQUFLLFVBQVUsS0FBSyxjQUFjLFVBQVUscUJBQy9DLElBQ0EsSUFDQSxRQUNBLGNBQWMsUUFDZCxRQUNBLGtCQUNBLGdCQUNGO0NBRUo7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxvQ0FBb0MsS0FBSyxFQUFFLEtBQUssS0FBSyxFQUFFLFFBQVEsS0FBSyxNQUFNLFVBQVUsS0FBSyxPQUFPLFVBQVUsS0FBSyxPQUFPO0NBQy9IO0FBQ0Y7OztBQ2hSQSxTQUFTLFNBQVMsVUFBVSxnQkFBZ0IsZ0JBQWdCLEtBQUssV0FBVyxXQUFXLE1BQU0sU0FBUyxNQUFNO0NBQzFHLElBQUksUUFBUTtDQUNaLGtCQUFrQjtDQUNsQixhQUFhO0NBQ2IsTUFBTSxJQUFJLE9BQU87Q0FDakIsTUFBTSxJQUFJLE9BQU87Q0FDakIsTUFBTSxJQUFJLE9BQU87Q0FDakIsTUFBTSxJQUFJLE9BQU87Q0FDakIsTUFBTSxLQUFLLE9BQU87Q0FDbEIsTUFBTSxLQUFLLE9BQU87Q0FDbEIsT0FBTyxRQUFRLE1BQU07RUFDbkIsTUFBTSxJQUFJLFNBQVM7RUFDbkIsTUFBTSxJQUFJLFNBQVMsaUJBQWlCO0VBQ3BDLElBQUksYUFBYSxJQUFJLElBQUksSUFBSSxJQUFJO0VBQ2pDLElBQUksWUFBWSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUk7RUFDckMsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGVBQWUsS0FBSyxXQUFXLFdBQVcsTUFBTTtDQUN2RCxJQUFJLFFBQVE7Q0FDWixhQUFhO0NBQ2IsT0FBTyxRQUFRLE1BQU07RUFDbkIsSUFBSSxhQUFhO0VBQ2pCLElBQUksWUFBWSxLQUFLO0VBQ3JCLGFBQWE7RUFDYjtDQUNGO0FBQ0Y7OztBQzdCQSxTQUFTLGtCQUFrQixVQUFVLEdBQUcsUUFBUSxRQUFRLE1BQU07Q0FDNUQsTUFBTSxJQUFJLEVBQUU7Q0FDWixNQUFNLElBQUksRUFBRTtDQUNaLE1BQU0sSUFBSSxFQUFFO0NBQ1osTUFBTSxJQUFJLEVBQUU7Q0FDWixNQUFNLEtBQUssRUFBRTtDQUNiLE1BQU0sS0FBSyxFQUFFO0NBQ2IsV0FBVyxTQUFTO0NBQ3BCLFdBQVcsU0FBUztDQUNwQixTQUFTLE9BQU8sU0FBUyxTQUFTLFNBQVM7Q0FDM0MsSUFBSSxRQUFRLFNBQVM7Q0FDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sS0FBSztFQUM3QixNQUFNLElBQUksU0FBUztFQUNuQixNQUFNLElBQUksU0FBUyxRQUFRO0VBQzNCLFNBQVMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJO0VBQ2xDLFNBQVMsUUFBUSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUk7RUFDdEMsU0FBUztDQUNYO0FBQ0Y7OztBQ2ZBLElBQU0saUJBQWlCLElBQUksT0FBTztBQUNsQyxJQUFNLG9CQUFOLE1BQXdCO0NBQ3RCLGNBQWM7RUFDWixLQUFLLGFBQWE7RUFDbEIsS0FBSyxjQUFjO0VBQ25CLEtBQUssV0FBVztFQUNoQixLQUFLLGlCQUFpQjtFQUN0QixLQUFLLGNBQWM7RUFDbkIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssU0FBUztDQUNoQjtDQUNBLElBQUksTUFBTTtFQUNSLE9BQU8sS0FBSyxhQUFhO0NBQzNCO0NBQ0EsSUFBSSxZQUFZO0VBQ2QsT0FBTyxLQUFLLGFBQWE7Q0FDM0I7Q0FDQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUssYUFBYTtDQUMzQjtDQUNBLElBQUksWUFBWTtFQUNkLElBQUksS0FBSyxjQUFjLEtBQUssZ0JBQzFCLE9BQU8sS0FBSyxXQUFXO0VBRXpCLE9BQU87Q0FDVDtDQUNBLElBQUksUUFBUTtFQUNWLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLE1BQU0sTUFBTSxPQUFPLEtBQUssTUFBTSxTQUFTLE1BQU0sUUFBUTtFQUNyRCxNQUFNLGFBQWEsS0FBSztFQUN4QixJQUFJLFlBQ0YsT0FBTyxrQkFBa0IsS0FBSyxXQUFXLFVBQVUsS0FBSyxLQUFLLFFBQVEsV0FBVyxhQUFhLE9BQU87RUFFdEcsT0FBTyxPQUFPLEtBQUssUUFBUSxPQUFPO0NBQ3BDO0NBQ0EsSUFBSSxZQUFZO0VBQ2QsT0FBTyxLQUFLLFlBQVksa0JBQWtCO0NBQzVDO0NBQ0EsT0FBTyxXQUFXO0VBQ2hCLFVBQVUsY0FBYyxLQUFLO0VBQzdCLFVBQVUsWUFBWSxLQUFLO0VBQzNCLFVBQVUsa0JBQWtCLEtBQUs7RUFDakMsVUFBVSxnQkFBZ0IsS0FBSztFQUMvQixVQUFVLFlBQVksS0FBSztFQUMzQixVQUFVLFFBQVEsS0FBSztFQUN2QixVQUFVLFVBQVUsS0FBSztFQUN6QixVQUFVLGVBQWUsS0FBSztFQUM5QixVQUFVLFdBQVcsS0FBSztDQUM1QjtDQUNBLFFBQVE7RUFDTixLQUFLLGlCQUFpQjtFQUN0QixLQUFLLGFBQWE7RUFDbEIsS0FBSyxXQUFXO0NBQ2xCO0NBQ0EsVUFBVTtFQUNSLEtBQUssYUFBYTtFQUNsQixLQUFLLFVBQVU7RUFDZixLQUFLLGVBQWU7RUFDcEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssU0FBUztDQUNoQjtBQUNGOzs7QUM5REEsSUFBTSxjQUFjO0NBQ2xCLFdBQVc7RUFDVCxNQUFNLGNBQWM7RUFDcEIsTUFBTTtDQUNSO0NBQ0EsTUFBTSxPQUFPLFFBQVE7RUFDbkIsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSSxNQUFNLFNBQVMsVUFBVTtHQUMzQixNQUFNLFNBQVM7R0FDZixLQUFLLEtBQUssT0FBTztHQUNqQixJQUFJLE1BQU0sR0FDUixPQUFPO0dBRVQsSUFBSSxPQUFPO0dBQ1gsSUFBSSxPQUFPO0dBQ1gsS0FBSyxLQUFLO0VBQ1osT0FBTyxJQUFJLE1BQU0sU0FBUyxXQUFXO0dBQ25DLE1BQU0sVUFBVTtHQUNoQixLQUFLLFFBQVE7R0FDYixLQUFLLFFBQVE7R0FDYixJQUFJLE1BQU0sS0FBSyxNQUFNLEdBQ25CLE9BQU87R0FFVCxJQUFJLFFBQVE7R0FDWixJQUFJLFFBQVE7R0FDWixLQUFLLEtBQUs7RUFDWixPQUFPO0dBQ0wsTUFBTSxjQUFjO0dBQ3BCLE1BQU0sWUFBWSxZQUFZLFFBQVE7R0FDdEMsTUFBTSxhQUFhLFlBQVksU0FBUztHQUN4QyxJQUFJLFlBQVksSUFBSTtHQUNwQixJQUFJLFlBQVksSUFBSTtHQUNwQixLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLFlBQVksUUFBUSxLQUFLLElBQUksV0FBVyxVQUFVLENBQUMsQ0FBQztHQUNuRixLQUFLLFlBQVk7R0FDakIsS0FBSyxhQUFhO0VBQ3BCO0VBQ0EsSUFBSSxLQUFLLEtBQUssS0FBSyxHQUNqQixPQUFPO0VBRVQsTUFBTSxJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxLQUFLLEVBQUUsQ0FBQztFQUM1QyxNQUFNLElBQUksSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSTtFQUMzQyxJQUFJLE1BQU0sR0FDUixPQUFPO0VBRVQsSUFBSSxNQUFNLEdBQUc7R0FDWCxPQUFPLEtBQUssT0FBTyxLQUFLLElBQUk7R0FDNUIsT0FBTyxLQUFLLE9BQU8sS0FBSyxJQUFJO0dBQzVCLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFBSTtHQUM1QixPQUFPLEtBQUssT0FBTyxLQUFLLElBQUk7R0FDNUIsT0FBTztFQUNUO0VBQ0EsSUFBSSxLQUFLO0VBQ1QsSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksS0FBSztFQUNoQyxJQUFJLEtBQUs7RUFDVCxJQUFJLEtBQUs7RUFDVCxJQUFJLEtBQUssS0FBSztFQUNkLElBQUksS0FBSztFQUNULElBQUksS0FBSyxJQUFJO0VBQ2IsSUFBSSxLQUFLLElBQUk7RUFDYixJQUFJLEtBQUssSUFBSTtFQUNiLE9BQU8sUUFBUTtFQUNmLE9BQU8sUUFBUTtFQUNmLE9BQU8sRUFBRSxNQUFNO0VBQ2YsT0FBTyxFQUFFLE1BQU07RUFDZixJQUFJLElBQUk7R0FDTixNQUFNLE1BQU0sSUFBSTtHQUNoQixPQUFPLFFBQVE7R0FDZixPQUFPLFFBQVE7R0FDZixPQUFPLEVBQUUsTUFBTTtHQUNmLE9BQU8sRUFBRSxNQUFNO0VBQ2pCO0VBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztHQUMxQixNQUFNLElBQUksS0FBSyxLQUFLLEtBQUssSUFBSTtHQUM3QixNQUFNLE1BQU0sS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJO0dBQy9CLE1BQU0sTUFBTSxLQUFLLEtBQUssSUFBSSxDQUFDLElBQUk7R0FDL0IsTUFBTSxNQUFNLElBQUk7R0FDaEIsTUFBTSxNQUFNLElBQUk7R0FDaEIsTUFBTSxNQUFNLElBQUk7R0FDaEIsTUFBTSxNQUFNLElBQUk7R0FDaEIsT0FBTyxRQUFRO0dBQ2YsT0FBTyxRQUFRO0dBQ2YsT0FBTyxFQUFFLE1BQU07R0FDZixPQUFPLEVBQUUsTUFBTTtHQUNmLE9BQU8sUUFBUTtHQUNmLE9BQU8sUUFBUTtHQUNmLE9BQU8sRUFBRSxNQUFNO0dBQ2YsT0FBTyxFQUFFLE1BQU07RUFDakI7RUFDQSxLQUFLO0VBQ0wsS0FBSyxLQUFLO0VBQ1YsS0FBSyxJQUFJO0VBQ1QsS0FBSyxJQUFJO0VBQ1QsS0FBSyxJQUFJO0VBQ1QsTUFBTSxLQUFLLElBQUk7RUFDZixPQUFPLFFBQVE7RUFDZixPQUFPLFFBQVE7RUFDZixPQUFPLEVBQUUsTUFBTTtFQUNmLE9BQU8sRUFBRSxNQUFNO0VBQ2YsSUFBSSxJQUFJO0dBQ04sT0FBTyxRQUFRO0dBQ2YsT0FBTyxRQUFRO0dBQ2YsT0FBTyxFQUFFLE1BQU07R0FDZixPQUFPLEVBQUUsTUFBTTtFQUNqQjtFQUNBLE9BQU87Q0FDVDtDQUNBLFlBQVksUUFBUSxVQUFVLGdCQUFnQixnQkFBZ0IsU0FBUyxlQUFlO0VBQ3BGLElBQUksT0FBTyxXQUFXLEdBQ3BCO0VBRUYsSUFBSSxVQUFVO0VBQ2QsSUFBSSxVQUFVO0VBQ2QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLLEdBQUc7R0FDekMsV0FBVyxPQUFPO0dBQ2xCLFdBQVcsT0FBTyxJQUFJO0VBQ3hCO0VBQ0EsV0FBVyxPQUFPLFNBQVM7RUFDM0IsV0FBVyxPQUFPLFNBQVM7RUFDM0IsSUFBSSxRQUFRO0VBQ1osU0FBUyxRQUFRLGtCQUFrQjtFQUNuQyxTQUFTLFFBQVEsaUJBQWlCLEtBQUs7RUFDdkMsTUFBTSxjQUFjO0VBQ3BCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FBSyxHQUFHO0dBQ3pDLFNBQVMsUUFBUSxrQkFBa0IsT0FBTztHQUMxQyxTQUFTLFFBQVEsaUJBQWlCLEtBQUssT0FBTyxJQUFJO0dBQ2xELElBQUksSUFBSSxHQUFHO0lBQ1QsUUFBUSxtQkFBbUI7SUFDM0IsUUFBUSxtQkFBbUI7SUFDM0IsUUFBUSxtQkFBbUIsUUFBUTtHQUNyQztHQUNBO0VBQ0Y7RUFDQSxRQUFRLG1CQUFtQixjQUFjO0VBQ3pDLFFBQVEsbUJBQW1CO0VBQzNCLFFBQVEsbUJBQW1CLFFBQVE7Q0FDckM7QUFDRjtBQUNBLElBQU0sZUFBZTtDQUFFLEdBQUc7Q0FBYSxXQUFXO0VBQUUsR0FBRyxZQUFZO0VBQVcsTUFBTTtDQUFVO0FBQUU7QUFDaEcsSUFBTSx3QkFBd0I7Q0FBRSxHQUFHO0NBQWEsV0FBVztFQUFFLEdBQUcsWUFBWTtFQUFXLE1BQU07Q0FBbUI7QUFBRTs7O0FDakpsSCxJQUFNLGdCQUFnQjtBQUN0QixJQUFNLFdBQVc7OztBQ0dqQixTQUFTLE9BQU8sR0FBRyxHQUFHLElBQUksSUFBSSxhQUFhLGFBQWEsV0FBVyxPQUFPO0NBQ3hFLE1BQU0sS0FBSyxJQUFJLEtBQUs7Q0FDcEIsTUFBTSxLQUFLLElBQUksS0FBSztDQUNwQixNQUFNLEtBQUssSUFBSSxLQUFLO0NBQ3BCLE1BQU0sS0FBSyxJQUFJLEtBQUs7Q0FDcEIsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJLFdBQVc7RUFDYixNQUFNO0VBQ04sTUFBTSxDQUFDO0NBQ1QsT0FBTztFQUNMLE1BQU0sQ0FBQztFQUNQLE1BQU07Q0FDUjtDQUNBLE1BQU0sTUFBTSxLQUFLO0NBQ2pCLE1BQU0sTUFBTSxLQUFLO0NBQ2pCLE1BQU0sTUFBTSxLQUFLO0NBQ2pCLE1BQU0sTUFBTSxLQUFLO0NBQ2pCLE1BQU0sS0FBSyxLQUFLLEdBQUc7Q0FDbkIsTUFBTSxLQUFLLEtBQUssR0FBRztDQUNuQixPQUFPO0FBQ1Q7QUFDQSxTQUFTLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksT0FBTyxXQUFXO0NBQ3ZELE1BQU0sU0FBUyxLQUFLO0NBQ3BCLE1BQU0sU0FBUyxLQUFLO0NBQ3BCLElBQUksU0FBUyxLQUFLLE1BQU0sUUFBUSxNQUFNO0NBQ3RDLElBQUksU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssRUFBRTtDQUN4QyxJQUFJLGFBQWEsU0FBUyxRQUN4QixVQUFVLEtBQUssS0FBSztNQUNmLElBQUksQ0FBQyxhQUFhLFNBQVMsUUFDaEMsVUFBVSxLQUFLLEtBQUs7Q0FFdEIsSUFBSSxhQUFhO0NBQ2pCLE1BQU0sWUFBWSxTQUFTO0NBQzNCLE1BQU0sZUFBZSxLQUFLLElBQUksU0FBUztDQUN2QyxNQUFNLFNBQVMsS0FBSyxLQUFLLFNBQVMsU0FBUyxTQUFTLE1BQU07Q0FDMUQsTUFBTSxZQUFZLEtBQUssZUFBZSxLQUFLLEtBQUssTUFBTSxJQUFJLEtBQUssTUFBTSxLQUFLO0NBQzFFLE1BQU0sV0FBVyxZQUFZO0NBQzdCLGNBQWM7Q0FDZCxJQUFJLFdBQVc7RUFDYixNQUFNLEtBQUssSUFBSSxFQUFFO0VBQ2pCLE1BQU0sS0FBSyxJQUFJLEVBQUU7RUFDakIsS0FBSyxJQUFJLElBQUksR0FBRyxRQUFRLFlBQVksSUFBSSxVQUFVLEtBQUssU0FBUyxVQUFVO0dBQ3hFLE1BQU0sS0FBSyxJQUFJLEVBQUU7R0FDakIsTUFBTSxLQUNKLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxRQUN2QixLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksTUFDekI7RUFDRjtFQUNBLE1BQU0sS0FBSyxJQUFJLEVBQUU7RUFDakIsTUFBTSxLQUFLLElBQUksRUFBRTtDQUNuQixPQUFPO0VBQ0wsTUFBTSxLQUFLLElBQUksRUFBRTtFQUNqQixNQUFNLEtBQUssSUFBSSxFQUFFO0VBQ2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsUUFBUSxZQUFZLElBQUksVUFBVSxLQUFLLFNBQVMsVUFBVTtHQUN4RSxNQUFNLEtBQ0osS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLFFBQ3ZCLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxNQUN6QjtHQUNBLE1BQU0sS0FBSyxJQUFJLEVBQUU7RUFDbkI7RUFDQSxNQUFNLEtBQUssSUFBSSxFQUFFO0VBQ2pCLE1BQU0sS0FBSyxJQUFJLEVBQUU7Q0FDbkI7Q0FDQSxPQUFPLFdBQVc7QUFDcEI7QUFDQSxTQUFTLFVBQVUsUUFBUSxXQUFXLGVBQWUsUUFBUSxVQUFVLFNBQVM7Q0FDOUUsTUFBTSxNQUFNO0NBQ1osSUFBSSxPQUFPLFdBQVcsR0FDcEI7Q0FFRixNQUFNLFFBQVE7Q0FDZCxJQUFJLFlBQVksTUFBTTtDQUN0QixJQUFJLFVBQVUsY0FBYyxJQUFLO0VBQy9CLElBQUksY0FBYyx1QkFBdUIsTUFBTTtFQUMvQyxJQUFJLGVBQWUsZUFBZTtFQUNsQyxhQUFhLFlBQVksTUFBTyxjQUFjO0NBQ2hEO0NBQ0EsTUFBTSxhQUFhLElBQUksTUFBTSxPQUFPLElBQUksT0FBTyxFQUFFO0NBQ2pELE1BQU0sWUFBWSxJQUFJLE1BQU0sT0FBTyxPQUFPLFNBQVMsSUFBSSxPQUFPLE9BQU8sU0FBUyxFQUFFO0NBQ2hGLE1BQU0sY0FBYztDQUNwQixNQUFNLGFBQWEsS0FBSyxJQUFJLFdBQVcsSUFBSSxVQUFVLENBQUMsSUFBSSxPQUFPLEtBQUssSUFBSSxXQUFXLElBQUksVUFBVSxDQUFDLElBQUk7Q0FDeEcsSUFBSSxhQUFhO0VBQ2YsU0FBUyxPQUFPLE1BQU07RUFDdEIsSUFBSSxZQUFZO0dBQ2QsT0FBTyxJQUFJO0dBQ1gsT0FBTyxJQUFJO0dBQ1gsVUFBVSxJQUFJLE9BQU8sT0FBTyxTQUFTLElBQUksT0FBTyxPQUFPLFNBQVMsRUFBRTtFQUNwRTtFQUNBLE1BQU0sYUFBYSxXQUFXLElBQUksVUFBVSxLQUFLO0VBQ2pELE1BQU0sYUFBYSxVQUFVLElBQUksV0FBVyxLQUFLO0VBQ2pELE9BQU8sUUFBUSxXQUFXLFNBQVM7RUFDbkMsT0FBTyxLQUFLLFdBQVcsU0FBUztDQUNsQztDQUNBLE1BQU0sUUFBUTtDQUNkLE1BQU0sU0FBUyxPQUFPLFNBQVM7Q0FDL0IsSUFBSSxhQUFhLE9BQU87Q0FDeEIsTUFBTSxhQUFhLE1BQU0sU0FBUztDQUNsQyxNQUFNLFFBQVEsTUFBTSxRQUFRO0NBQzVCLE1BQU0sZUFBZSxRQUFRO0NBQzdCLE1BQU0sb0JBQW9CLE1BQU0sYUFBYSxNQUFNO0NBQ25ELElBQUksS0FBSyxPQUFPO0NBQ2hCLElBQUksS0FBSyxPQUFPO0NBQ2hCLElBQUksS0FBSyxPQUFPO0NBQ2hCLElBQUksS0FBSyxPQUFPO0NBQ2hCLElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULElBQUksUUFBUSxFQUFFLEtBQUs7Q0FDbkIsSUFBSSxRQUFRLEtBQUs7Q0FDakIsSUFBSSxTQUFTO0NBQ2IsSUFBSSxTQUFTO0NBQ2IsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLFFBQVEsUUFBUSxLQUFLO0NBQ2xELFNBQVM7Q0FDVCxTQUFTO0NBQ1QsU0FBUztDQUNULFNBQVM7Q0FDVCxNQUFNLFFBQVE7Q0FDZCxNQUFNLGVBQWUsSUFBSSxTQUFTO0NBQ2xDLE1BQU0sY0FBYyxRQUFRO0NBQzVCLElBQUksQ0FBQyxhQUFhO0VBQ2hCLElBQUksTUFBTSxRQUFRLFNBQ2hCLGNBQWMsTUFDWixLQUFLLFNBQVMsY0FBYyxlQUFlLElBQzNDLEtBQUssU0FBUyxjQUFjLGVBQWUsSUFDM0MsS0FBSyxRQUFRLGFBQ2IsS0FBSyxRQUFRLGFBQ2IsS0FBSyxRQUFRLGFBQ2IsS0FBSyxRQUFRLGFBQ2IsT0FDQSxJQUNGLElBQUk7T0FDQyxJQUFJLE1BQU0sUUFBUSxVQUN2QixjQUFjLE9BQU8sSUFBSSxJQUFJLE9BQU8sT0FBTyxhQUFhLGFBQWEsTUFBTSxLQUFLO0NBRXBGO0NBQ0EsTUFBTSxLQUNKLEtBQUssUUFBUSxhQUNiLEtBQUssUUFBUSxXQUNmO0NBQ0EsTUFBTSxLQUNKLEtBQUssUUFBUSxhQUNiLEtBQUssUUFBUSxXQUNmO0NBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsR0FBRyxFQUFFLEdBQUc7RUFDbkMsS0FBSyxRQUFRLElBQUksS0FBSztFQUN0QixLQUFLLFFBQVEsSUFBSSxLQUFLLElBQUk7RUFDMUIsS0FBSyxPQUFPLElBQUk7RUFDaEIsS0FBSyxPQUFPLElBQUksSUFBSTtFQUNwQixLQUFLLFFBQVEsSUFBSSxLQUFLO0VBQ3RCLEtBQUssUUFBUSxJQUFJLEtBQUssSUFBSTtFQUMxQixRQUFRLEVBQUUsS0FBSztFQUNmLFFBQVEsS0FBSztFQUNiLE9BQU8sS0FBSyxLQUFLLFFBQVEsUUFBUSxRQUFRLEtBQUs7RUFDOUMsU0FBUztFQUNULFNBQVM7RUFDVCxTQUFTO0VBQ1QsU0FBUztFQUNULFNBQVMsRUFBRSxLQUFLO0VBQ2hCLFNBQVMsS0FBSztFQUNkLE9BQU8sS0FBSyxLQUFLLFNBQVMsU0FBUyxTQUFTLE1BQU07RUFDbEQsVUFBVTtFQUNWLFVBQVU7RUFDVixVQUFVO0VBQ1YsVUFBVTtFQUNWLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTTtFQUM5QixNQUFNLFFBQVEsTUFBTSxNQUFNLE1BQU07RUFDaEMsTUFBTSxZQUFZLFFBQVE7RUFDMUIsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sS0FBSyxJQUFJLEdBQUcsR0FBRztHQUMxQyxNQUFNLEtBQ0osS0FBSyxRQUFRLGFBQ2IsS0FBSyxRQUFRLFdBQ2Y7R0FDQSxNQUFNLEtBQ0osS0FBSyxRQUFRLGFBQ2IsS0FBSyxRQUFRLFdBQ2Y7R0FDQSxJQUFJLE9BQU8sR0FBRztJQUNaLElBQUksTUFBTSxTQUFTLFNBQ2pCLGNBQWMsTUFDWixJQUNBLElBQ0EsS0FBSyxRQUFRLGFBQ2IsS0FBSyxRQUFRLGFBQ2IsS0FBSyxTQUFTLGFBQ2QsS0FBSyxTQUFTLGFBQ2QsT0FDQSxLQUNGLElBQUk7U0FFSixjQUFjO0lBRWhCLE1BQU0sS0FDSixLQUFLLFNBQVMsYUFDZCxLQUFLLFNBQVMsV0FDaEI7SUFDQSxNQUFNLEtBQ0osS0FBSyxTQUFTLGFBQ2QsS0FBSyxTQUFTLFdBQ2hCO0dBQ0Y7R0FDQTtFQUNGO0VBQ0EsTUFBTSxNQUFNLENBQUMsUUFBUSxPQUFPLENBQUMsUUFBUSxPQUFPLENBQUMsUUFBUSxPQUFPLENBQUMsUUFBUTtFQUNyRSxNQUFNLE1BQU0sQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTO0VBQ3pFLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNO0VBQ25DLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNO0VBQ25DLE1BQU0sU0FBUyxLQUFLLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLO0VBQ3hELE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTTtFQUM3QixNQUFNLE1BQU0sTUFBTSxLQUFLLE1BQU07RUFDN0IsTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNO0VBQzdCLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTTtFQUM3QixNQUFNLHlCQUF5QixLQUFLLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU0sTUFBTSxHQUFHO0VBQ3BGLE1BQU0sZUFBZSxZQUFZLGNBQWM7RUFHL0MsSUFEc0IsU0FEVSx5QkFBeUIsZUFBZSxlQUFlLGNBRXBFO0dBQ2pCLElBQUksTUFBTSxTQUFTLFdBQVcsUUFBUSxlQUFlLG1CQUFtQjtJQUN0RSxJQUFJLFdBQVc7S0FDYixNQUFNLEtBQUssS0FBSyxHQUFHO0tBQ25CLE1BQU0sS0FBSyxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsV0FBVztLQUM3RCxNQUFNLEtBQUssS0FBSyxHQUFHO0tBQ25CLE1BQU0sS0FBSyxLQUFLLFNBQVMsYUFBYSxLQUFLLFNBQVMsV0FBVztJQUNqRSxPQUFPO0tBQ0wsTUFBTSxLQUFLLEtBQUssUUFBUSxhQUFhLEtBQUssUUFBUSxXQUFXO0tBQzdELE1BQU0sS0FBSyxLQUFLLEdBQUc7S0FDbkIsTUFBTSxLQUFLLEtBQUssU0FBUyxhQUFhLEtBQUssU0FBUyxXQUFXO0tBQy9ELE1BQU0sS0FBSyxLQUFLLEdBQUc7SUFDckI7SUFDQSxjQUFjO0dBQ2hCLE9BQU8sSUFBSSxNQUFNLFNBQVMsU0FBUztJQUNqQyxJQUFJLFdBQVc7S0FDYixNQUFNLEtBQUssS0FBSyxHQUFHO0tBQ25CLE1BQU0sS0FBSyxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsV0FBVztLQUM3RCxjQUFjLE1BQ1osSUFDQSxJQUNBLEtBQUssUUFBUSxhQUNiLEtBQUssUUFBUSxhQUNiLEtBQUssU0FBUyxhQUNkLEtBQUssU0FBUyxhQUNkLE9BQ0EsSUFDRixJQUFJO0tBQ0osTUFBTSxLQUFLLEtBQUssR0FBRztLQUNuQixNQUFNLEtBQUssS0FBSyxTQUFTLGFBQWEsS0FBSyxTQUFTLFdBQVc7SUFDakUsT0FBTztLQUNMLE1BQU0sS0FBSyxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsV0FBVztLQUM3RCxNQUFNLEtBQUssS0FBSyxHQUFHO0tBQ25CLGNBQWMsTUFDWixJQUNBLElBQ0EsS0FBSyxRQUFRLGFBQ2IsS0FBSyxRQUFRLGFBQ2IsS0FBSyxTQUFTLGFBQ2QsS0FBSyxTQUFTLGFBQ2QsT0FDQSxLQUNGLElBQUk7S0FDSixNQUFNLEtBQUssS0FBSyxTQUFTLGFBQWEsS0FBSyxTQUFTLFdBQVc7S0FDL0QsTUFBTSxLQUFLLEtBQUssR0FBRztJQUNyQjtHQUNGLE9BQU87SUFDTCxNQUFNLEtBQUssS0FBSyxHQUFHO0lBQ25CLE1BQU0sS0FBSyxLQUFLLEdBQUc7R0FDckI7RUFDRixPQUFPO0dBQ0wsTUFBTSxLQUFLLEtBQUssUUFBUSxhQUFhLEtBQUssUUFBUSxXQUFXO0dBQzdELE1BQU0sS0FBSyxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsV0FBVztHQUM3RCxJQUFJLE1BQU0sU0FBUyxTQUFTO0lBQzFCLElBQUksV0FDRixjQUFjLE1BQ1osSUFDQSxJQUNBLEtBQUssUUFBUSxhQUNiLEtBQUssUUFBUSxhQUNiLEtBQUssU0FBUyxhQUNkLEtBQUssU0FBUyxhQUNkLE9BQ0EsSUFDRixJQUFJO1NBRUosY0FBYyxNQUNaLElBQ0EsSUFDQSxLQUFLLFFBQVEsYUFDYixLQUFLLFFBQVEsYUFDYixLQUFLLFNBQVMsYUFDZCxLQUFLLFNBQVMsYUFDZCxPQUNBLEtBQ0YsSUFBSTtHQUVSLE9BQU8sSUFBSSxNQUFNLFNBQVMsV0FBVyxRQUFRLGdCQUFnQixtQkFBbUI7SUFDOUUsSUFBSSxXQUFXO0tBQ2IsTUFBTSxLQUFLLEtBQUssR0FBRztLQUNuQixNQUFNLEtBQUssS0FBSyxHQUFHO0lBQ3JCLE9BQU87S0FDTCxNQUFNLEtBQUssS0FBSyxHQUFHO0tBQ25CLE1BQU0sS0FBSyxLQUFLLEdBQUc7SUFDckI7SUFDQSxjQUFjO0dBQ2hCO0dBQ0EsTUFBTSxLQUFLLEtBQUssU0FBUyxhQUFhLEtBQUssU0FBUyxXQUFXO0dBQy9ELE1BQU0sS0FBSyxLQUFLLFNBQVMsYUFBYSxLQUFLLFNBQVMsV0FBVztHQUMvRCxjQUFjO0VBQ2hCO0NBQ0Y7Q0FDQSxLQUFLLFFBQVEsU0FBUyxLQUFLO0NBQzNCLEtBQUssUUFBUSxTQUFTLEtBQUssSUFBSTtDQUMvQixLQUFLLFFBQVEsU0FBUyxLQUFLO0NBQzNCLEtBQUssUUFBUSxTQUFTLEtBQUssSUFBSTtDQUMvQixRQUFRLEVBQUUsS0FBSztDQUNmLFFBQVEsS0FBSztDQUNiLE9BQU8sS0FBSyxLQUFLLFFBQVEsUUFBUSxRQUFRLEtBQUs7Q0FDOUMsU0FBUztDQUNULFNBQVM7Q0FDVCxTQUFTO0NBQ1QsU0FBUztDQUNULE1BQU0sS0FBSyxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsV0FBVztDQUM3RCxNQUFNLEtBQUssS0FBSyxRQUFRLGFBQWEsS0FBSyxRQUFRLFdBQVc7Q0FDN0QsSUFBSSxDQUFDLGFBQWE7RUFDaEIsSUFBSSxNQUFNLFFBQVEsU0FDaEIsY0FBYyxNQUNaLEtBQUssU0FBUyxjQUFjLGVBQWUsSUFDM0MsS0FBSyxTQUFTLGNBQWMsZUFBZSxJQUMzQyxLQUFLLFFBQVEsYUFDYixLQUFLLFFBQVEsYUFDYixLQUFLLFFBQVEsYUFDYixLQUFLLFFBQVEsYUFDYixPQUNBLEtBQ0YsSUFBSTtPQUNDLElBQUksTUFBTSxRQUFRLFVBQ3ZCLGNBQWMsT0FBTyxJQUFJLElBQUksT0FBTyxPQUFPLGFBQWEsYUFBYSxPQUFPLEtBQUs7Q0FFckY7Q0FDQSxNQUFNLE9BQU8sV0FBVztDQUN4QixLQUFLLElBQUksSUFBSSxZQUFZLElBQUksYUFBYSxhQUFhLEdBQUcsRUFBRSxHQUFHO0VBQzdELEtBQUssTUFBTSxJQUFJO0VBQ2YsS0FBSyxNQUFNLElBQUksSUFBSTtFQUNuQixLQUFLLE9BQU8sSUFBSSxLQUFLO0VBQ3JCLEtBQUssT0FBTyxJQUFJLEtBQUssSUFBSTtFQUN6QixLQUFLLE9BQU8sSUFBSSxLQUFLO0VBQ3JCLEtBQUssT0FBTyxJQUFJLEtBQUssSUFBSTtFQUN6QixJQUFJLEtBQUssSUFBSSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUssR0FBRyxJQUFJLE1BQy9EO0VBRUYsUUFBUSxLQUFLLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztDQUM5QjtBQUNGOzs7QUNuV0EsU0FBUyxlQUFlLFFBQVEsUUFBUSxVQUFVLFNBQVM7Q0FDekQsTUFBTSxNQUFNO0NBQ1osSUFBSSxPQUFPLFdBQVcsR0FDcEI7Q0FFRixNQUFNLEtBQUssT0FBTztDQUNsQixNQUFNLEtBQUssT0FBTztDQUNsQixNQUFNLEtBQUssT0FBTyxPQUFPLFNBQVM7Q0FDbEMsTUFBTSxLQUFLLE9BQU8sT0FBTyxTQUFTO0NBQ2xDLE1BQU0sWUFBWSxVQUFVLEtBQUssSUFBSSxLQUFLLEVBQUUsSUFBSSxPQUFPLEtBQUssSUFBSSxLQUFLLEVBQUUsSUFBSTtDQUMzRSxNQUFNLFFBQVE7Q0FDZCxNQUFNLFNBQVMsT0FBTyxTQUFTO0NBQy9CLE1BQU0sYUFBYSxNQUFNLFNBQVM7Q0FDbEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSztFQUMvQixNQUFNLEtBQUssT0FBTyxJQUFJLEVBQUU7RUFDeEIsTUFBTSxLQUFLLE9BQU8sSUFBSSxJQUFJLEVBQUU7Q0FDOUI7Q0FDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxHQUFHLEtBQzlCLFFBQVEsS0FBSyxhQUFhLEdBQUcsYUFBYSxJQUFJLENBQUM7Q0FFakQsSUFBSSxXQUNGLFFBQVEsS0FBSyxhQUFhLFNBQVMsR0FBRyxVQUFVO0FBRXBEOzs7QUN2QkEsU0FBUyxxQkFBcUIsUUFBUSxPQUFPLFVBQVUsZ0JBQWdCLGdCQUFnQixTQUFTLGVBQWU7Q0FDN0csTUFBTSxZQUFZLE9BQU8sUUFBUSxPQUFPLENBQUM7Q0FDekMsSUFBSSxDQUFDLFdBQ0g7Q0FFRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUssR0FBRztFQUM1QyxRQUFRLG1CQUFtQixVQUFVLEtBQUs7RUFDMUMsUUFBUSxtQkFBbUIsVUFBVSxJQUFJLEtBQUs7RUFDOUMsUUFBUSxtQkFBbUIsVUFBVSxJQUFJLEtBQUs7Q0FDaEQ7Q0FDQSxJQUFJLFFBQVEsaUJBQWlCO0NBQzdCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FBSyxHQUFHO0VBQ3pDLFNBQVMsU0FBUyxPQUFPO0VBQ3pCLFNBQVMsUUFBUSxLQUFLLE9BQU8sSUFBSTtFQUNqQyxTQUFTO0NBQ1g7QUFDRjs7O0FDZkEsSUFBTSxhQUFhLENBQUM7QUFDcEIsSUFBTSxlQUFlO0NBQ25CLFdBQVc7RUFDVCxNQUFNLGNBQWM7RUFDcEIsTUFBTTtDQUNSO0NBQ0EsTUFBTSxPQUFPLFFBQVE7RUFDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sT0FBTyxRQUFRLEtBQ3ZDLE9BQU8sS0FBSyxNQUFNLE9BQU87RUFFM0IsT0FBTztDQUNUO0NBQ0EsWUFBWSxRQUFRLFVBQVUsZ0JBQWdCLGdCQUFnQixTQUFTLGVBQWU7RUFDcEYscUJBQXFCLFFBQVEsWUFBWSxVQUFVLGdCQUFnQixnQkFBZ0IsU0FBUyxhQUFhO0NBQzNHO0FBQ0Y7OztBQ2hCQSxJQUFNLGlCQUFpQjtDQUNyQixXQUFXO0VBQ1QsTUFBTSxjQUFjO0VBQ3BCLE1BQU07Q0FDUjtDQUNBLE1BQU0sT0FBTyxRQUFRO0VBQ25CLE1BQU0sV0FBVztFQUNqQixNQUFNLElBQUksU0FBUztFQUNuQixNQUFNLElBQUksU0FBUztFQUNuQixNQUFNLFFBQVEsU0FBUztFQUN2QixNQUFNLFNBQVMsU0FBUztFQUN4QixJQUFJLEVBQUUsUUFBUSxLQUFLLFNBQVMsSUFDMUIsT0FBTztFQUVULE9BQU8sS0FBSztFQUNaLE9BQU8sS0FBSztFQUNaLE9BQU8sS0FBSyxJQUFJO0VBQ2hCLE9BQU8sS0FBSztFQUNaLE9BQU8sS0FBSyxJQUFJO0VBQ2hCLE9BQU8sS0FBSyxJQUFJO0VBQ2hCLE9BQU8sS0FBSztFQUNaLE9BQU8sS0FBSyxJQUFJO0VBQ2hCLE9BQU87Q0FDVDtDQUNBLFlBQVksUUFBUSxVQUFVLGdCQUFnQixnQkFBZ0IsU0FBUyxlQUFlO0VBQ3BGLElBQUksUUFBUTtFQUNaLGtCQUFrQjtFQUNsQixTQUFTLGlCQUFpQixTQUFTLE9BQU87RUFDMUMsU0FBUyxpQkFBaUIsUUFBUSxLQUFLLE9BQU87RUFDOUMsU0FBUztFQUNULFNBQVMsaUJBQWlCLFNBQVMsT0FBTztFQUMxQyxTQUFTLGlCQUFpQixRQUFRLEtBQUssT0FBTztFQUM5QyxTQUFTO0VBQ1QsU0FBUyxpQkFBaUIsU0FBUyxPQUFPO0VBQzFDLFNBQVMsaUJBQWlCLFFBQVEsS0FBSyxPQUFPO0VBQzlDLFNBQVM7RUFDVCxTQUFTLGlCQUFpQixTQUFTLE9BQU87RUFDMUMsU0FBUyxpQkFBaUIsUUFBUSxLQUFLLE9BQU87RUFDOUMsU0FBUztFQUNULE1BQU0sZ0JBQWdCLGlCQUFpQjtFQUN2QyxRQUFRLG1CQUFtQjtFQUMzQixRQUFRLG1CQUFtQixnQkFBZ0I7RUFDM0MsUUFBUSxtQkFBbUIsZ0JBQWdCO0VBQzNDLFFBQVEsbUJBQW1CLGdCQUFnQjtFQUMzQyxRQUFRLG1CQUFtQixnQkFBZ0I7RUFDM0MsUUFBUSxtQkFBbUIsZ0JBQWdCO0NBQzdDO0FBQ0Y7OztBQy9DQSxJQUFNLGdCQUFnQjtDQUNwQixXQUFXO0VBQ1QsTUFBTSxjQUFjO0VBQ3BCLE1BQU07Q0FDUjtDQUNBLE1BQU0sT0FBTyxRQUFRO0VBQ25CLE9BQU8sS0FBSyxNQUFNO0VBQ2xCLE9BQU8sS0FBSyxNQUFNO0VBQ2xCLE9BQU8sS0FBSyxNQUFNO0VBQ2xCLE9BQU8sS0FBSyxNQUFNO0VBQ2xCLE9BQU8sS0FBSyxNQUFNO0VBQ2xCLE9BQU8sS0FBSyxNQUFNO0VBQ2xCLE9BQU87Q0FDVDtDQUNBLFlBQVksUUFBUSxVQUFVLGdCQUFnQixnQkFBZ0IsU0FBUyxlQUFlO0VBQ3BGLElBQUksUUFBUTtFQUNaLGtCQUFrQjtFQUNsQixTQUFTLGlCQUFpQixTQUFTLE9BQU87RUFDMUMsU0FBUyxpQkFBaUIsUUFBUSxLQUFLLE9BQU87RUFDOUMsU0FBUztFQUNULFNBQVMsaUJBQWlCLFNBQVMsT0FBTztFQUMxQyxTQUFTLGlCQUFpQixRQUFRLEtBQUssT0FBTztFQUM5QyxTQUFTO0VBQ1QsU0FBUyxpQkFBaUIsU0FBUyxPQUFPO0VBQzFDLFNBQVMsaUJBQWlCLFFBQVEsS0FBSyxPQUFPO0VBQzlDLE1BQU0sZ0JBQWdCLGlCQUFpQjtFQUN2QyxRQUFRLG1CQUFtQjtFQUMzQixRQUFRLG1CQUFtQixnQkFBZ0I7RUFDM0MsUUFBUSxtQkFBbUIsZ0JBQWdCO0NBQzdDO0FBQ0Y7OztBQ3ZCQSxJQUFNLGtCQUFrQixDQUFDO0NBQUUsUUFBUTtDQUFHLE9BQU87QUFBUSxHQUFHO0NBQUUsUUFBUTtDQUFHLE9BQU87QUFBUSxDQUFDO0FBQ3JGLElBQU0sZ0JBQWdCLE1BQU0sY0FBYztDQUN4QyxZQUFZLEdBQUcsTUFBTTs7Ozs7RUFLbkIsS0FBSyxNQUFNLElBQUksY0FBYzs7Ozs7O0VBTTdCLEtBQUssUUFBUTs7RUFFYixLQUFLLE9BQU87O0VBRVosS0FBSyxhQUFhLENBQUM7RUFDbkIsSUFBSSxVQUFVLHNCQUFzQixJQUFJO0VBRXhDLFVBQVU7R0FBRSxHQURLLFFBQVEsU0FBUyxXQUFXLGNBQWMsdUJBQXVCLGNBQWM7R0FDdkUsR0FBRyxhQUFhLE9BQU87RUFBRTtFQUNsRCxLQUFLLGVBQWUsUUFBUTtFQUM1QixLQUFLLFlBQVksUUFBUTtFQUN6QixJQUFJLFFBQVEsU0FBUyxVQUFVO0dBQzdCLEtBQUssU0FBUyxRQUFRO0dBQ3RCLEtBQUssY0FBYyxRQUFRLGVBQWUsS0FBSztHQUMvQyxLQUFLLGNBQWMsUUFBUTtHQUMzQixLQUFLLGNBQWMsUUFBUTtHQUMzQixLQUFLLFFBQVEsUUFBUTtHQUNyQixLQUFLLFdBQVcsUUFBUTtFQUMxQixPQUFPO0dBQ0wsS0FBSyxRQUFRLFFBQVE7R0FDckIsS0FBSyxNQUFNLFFBQVE7RUFDckI7RUFDQSxLQUFLLGVBQWUsUUFBUTtFQUM1QixLQUFLLE9BQU8sUUFBUTtFQUNwQixRQUFRLFdBQVcsU0FBUyxTQUFTO0dBQ25DLEtBQUssYUFBYSxLQUFLLFFBQVEsS0FBSyxLQUFLO0VBQzNDLENBQUM7Q0FDSDs7Ozs7OztDQU9BLGFBQWEsUUFBUSxPQUFPO0VBQzFCLEtBQUssV0FBVyxLQUFLO0dBQUU7R0FBUSxPQUFPLE1BQU0sT0FBTyxTQUFTLEtBQUssQ0FBQyxDQUFDLE9BQU87RUFBRSxDQUFDO0VBQzdFLE9BQU87Q0FDVDs7Ozs7O0NBTUEsc0JBQXNCO0VBQ3BCLElBQUksS0FBSyxTQUFTO0VBQ2xCLElBQUksRUFBRSxHQUFHLElBQUksR0FBRyxPQUFPLEtBQUs7RUFDNUIsSUFBSSxFQUFFLEdBQUcsSUFBSSxHQUFHLE9BQU8sS0FBSztFQUM1QixJQUFJLEtBQUssS0FBSztFQUNkLElBQUksS0FBSyxLQUFLO0VBQ2QsTUFBTSxPQUFPLEtBQUssS0FBSyxLQUFLO0VBQzVCLElBQUksS0FBSyxjQUFjLGlCQUFpQjtHQUN0QyxJQUFJLEtBQUssR0FBRztJQUNWLE1BQU0sT0FBTztJQUNiLEtBQUs7SUFDTCxLQUFLO0lBQ0wsTUFBTTtHQUNSO0dBQ0EsSUFBSSxLQUFLLEdBQUc7SUFDVixNQUFNLE9BQU87SUFDYixLQUFLO0lBQ0wsS0FBSztJQUNMLE1BQU07R0FDUjtFQUNGO0VBQ0EsTUFBTSxhQUFhLEtBQUssV0FBVyxTQUFTLEtBQUssYUFBYTtFQUM5RCxNQUFNLGNBQWMsS0FBSztFQUN6QixNQUFNLEVBQUUsUUFBUSxZQUFZLFVBQVUsYUFBYSxDQUFDO0VBQ3BELE1BQU0sV0FBVyxDQUFDLE9BQU8sUUFBUSxxQkFBcUIsR0FBRyxHQUFHLEtBQUssY0FBYyxDQUFDLElBQUksUUFBUSxxQkFBcUIsS0FBSyxjQUFjLEdBQUcsR0FBRyxDQUFDO0VBQzNJLGNBQWMsVUFBVSxVQUFVO0VBQ2xDLFFBQVEsWUFBWTtFQUNwQixRQUFRLFNBQVMsR0FBRyxHQUFHLGFBQWEsQ0FBQztFQUNyQyxLQUFLLFVBQVUsSUFBSSxRQUFRLEVBQ3pCLFFBQVEsSUFBSSxZQUFZO0dBQ3RCLFVBQVU7R0FDVixhQUFhLEtBQUs7RUFDcEIsQ0FBQyxFQUNILENBQUM7RUFDRCxNQUFNLE9BQU8sS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEVBQUU7RUFDeEMsTUFBTSxRQUFRLEtBQUssTUFBTSxJQUFJLEVBQUU7RUFDL0IsTUFBTSxJQUFJLElBQUksT0FBTztFQUNyQixFQUFFLE1BQU0sT0FBTyxhQUFhLENBQUM7RUFDN0IsRUFBRSxPQUFPLEtBQUs7RUFDZCxFQUFFLFVBQVUsSUFBSSxFQUFFO0VBQ2xCLElBQUksS0FBSyxpQkFBaUIsU0FDeEIsRUFBRSxNQUFNLGFBQWEsV0FBVztFQUVsQyxLQUFLLFlBQVk7Q0FDbkI7Ozs7OztDQU1BLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxLQUFLLFNBQVMsS0FBSztFQUN4QixJQUFJLEtBQUssU0FBUyxVQUNoQixLQUFLLG9CQUFvQjtPQUV6QixLQUFLLG9CQUFvQjtDQUU3Qjs7Ozs7O0NBTUEsc0JBQXNCO0VBQ3BCLElBQUksS0FBSyxTQUFTO0VBQ2xCLE1BQU0sYUFBYSxLQUFLLFdBQVcsU0FBUyxLQUFLLGFBQWE7RUFDOUQsTUFBTSxjQUFjLEtBQUs7RUFDekIsTUFBTSxFQUFFLFFBQVEsWUFBWSxVQUFVLGFBQWEsV0FBVztFQUM5RCxNQUFNLEVBQUUsR0FBRyxJQUFJLEdBQUcsT0FBTyxLQUFLO0VBQzlCLE1BQU0sRUFBRSxHQUFHLElBQUksR0FBRyxPQUFPLEtBQUs7RUFDOUIsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxRQUFRLGVBQWUsS0FBSztFQUNsQyxNQUFNLE1BQU0sS0FBSyxNQUFNO0VBQ3ZCLE1BQU0sTUFBTSxLQUFLLE1BQU07RUFDdkIsTUFBTSxXQUFXLFFBQVEscUJBQ3ZCLElBQ0EsSUFDQSxLQUFLLFFBQ0osS0FBSyxNQUFNLFFBQ1gsS0FBSyxNQUFNLE9BQ1osS0FBSyxLQUNQO0VBQ0EsY0FBYyxVQUFVLFVBQVU7RUFDbEMsUUFBUSxZQUFZLFdBQVcsV0FBVyxTQUFTLEVBQUUsQ0FBQztFQUN0RCxRQUFRLFNBQVMsR0FBRyxHQUFHLGFBQWEsV0FBVztFQUMvQyxRQUFRLFlBQVk7RUFDcEIsUUFBUSxVQUFVLElBQUksRUFBRTtFQUN4QixRQUFRLE9BQU8sS0FBSyxRQUFRO0VBQzVCLFFBQVEsTUFBTSxHQUFHLEtBQUssS0FBSztFQUMzQixRQUFRLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtFQUMxQixRQUFRLFNBQVMsR0FBRyxHQUFHLGFBQWEsV0FBVztFQUMvQyxLQUFLLFVBQVUsSUFBSSxRQUFRLEVBQ3pCLFFBQVEsSUFBSSxZQUFZO0dBQ3RCLFVBQVU7R0FDVixhQUFhLEtBQUs7RUFDcEIsQ0FBQyxFQUNILENBQUM7RUFDRCxNQUFNLElBQUksSUFBSSxPQUFPO0VBQ3JCLElBQUksS0FBSyxpQkFBaUIsU0FDeEIsRUFBRSxNQUFNLElBQUksSUFBSSxJQUFJLEVBQUU7T0FFdEIsRUFBRSxNQUFNLElBQUksT0FBTyxJQUFJLEtBQUs7RUFFOUIsRUFBRSxVQUFVLElBQUksRUFBRTtFQUNsQixLQUFLLFlBQVk7Q0FDbkI7O0NBRUEsVUFBVTtFQUNSLEtBQUssU0FBUyxRQUFRLElBQUk7RUFDMUIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxZQUFZO0VBQ2pCLEtBQUssYUFBYSxDQUFDO0VBQ25CLEtBQUssUUFBUTtFQUNiLEtBQUssTUFBTTtFQUNYLEtBQUssU0FBUztFQUNkLEtBQUssY0FBYztDQUNyQjs7Ozs7O0NBTUEsSUFBSSxXQUFXO0VBQ2IsT0FBTyxpQkFBaUIsS0FBSyxJQUFJLEdBQUcsS0FBSztDQUMzQztBQUNGOztBQUVBLGNBQWMsdUJBQXVCO0NBQ25DLE9BQU87RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFO0NBQ3BCLEtBQUs7RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFO0NBQ2xCLFlBQVksQ0FBQztDQUNiLGNBQWM7Q0FDZCxNQUFNO0NBQ04sYUFBYTtDQUNiLFVBQVU7QUFDWjs7QUFFQSxjQUFjLHVCQUF1QjtDQUNuQyxRQUFRO0VBQUUsR0FBRztFQUFLLEdBQUc7Q0FBSTtDQUN6QixhQUFhO0NBQ2IsYUFBYTtDQUNiLFlBQVksQ0FBQztDQUNiLE9BQU87Q0FDUCxVQUFVO0NBQ1YsY0FBYztDQUNkLE1BQU07Q0FDTixhQUFhO0NBQ2IsVUFBVTtBQUNaO0FBQ0EsSUFBSSxlQUFlO0FBQ25CLFNBQVMsY0FBYyxVQUFVLFlBQVk7Q0FDM0MsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsUUFBUSxLQUFLO0VBQzFDLE1BQU0sT0FBTyxXQUFXO0VBQ3hCLFNBQVMsYUFBYSxLQUFLLFFBQVEsS0FBSyxLQUFLO0NBQy9DO0FBQ0Y7QUFDQSxTQUFTLFVBQVUsT0FBTyxRQUFRO0NBQ2hDLE1BQU0sU0FBUyxXQUFXLElBQUksQ0FBQyxDQUFDLGFBQWEsT0FBTyxNQUFNO0NBRTFELE9BQU87RUFBRTtFQUFRLFNBREQsT0FBTyxXQUFXLElBQ1g7Q0FBRTtBQUMzQjtBQUNBLFNBQVMsc0JBQXNCLE1BQU07Q0FDbkMsSUFBSSxVQUFVLEtBQUssTUFBTSxDQUFDO0NBQzFCLElBQUksT0FBTyxZQUFZLFlBQVksS0FBSyxJQUFJO0VBQzFDLFlBQVksU0FBUyw0QkFBNEI7RUFDakQsVUFBVTtHQUNSLE1BQU07R0FDTixPQUFPO0lBQUUsR0FBRyxLQUFLO0lBQUksR0FBRyxLQUFLO0dBQUc7R0FDaEMsS0FBSztJQUFFLEdBQUcsS0FBSztJQUFJLEdBQUcsS0FBSztHQUFHO0dBQzlCLGNBQWMsS0FBSztHQUNuQixhQUFhLEtBQUssTUFBTSxhQUFhLHFCQUFxQjtFQUM1RDtDQUNGO0NBQ0EsT0FBTztBQUNUOzs7QUM3T0EsSUFBTUMsc0JBQW9CLElBQUksT0FBTztBQUNyQyxJQUFNQyxhQUFXLElBQUksVUFBVTtBQUMvQixJQUFNLGVBQWUsSUFBSSxPQUFPO0FBQ2hDLFNBQVMsc0JBQXNCLEtBQUssT0FBTyxPQUFPLFFBQVE7Q0FDeEQsTUFBTSxnQkFBZ0IsTUFBTSxTQUFTLElBQUksU0FBUyxNQUFNLE1BQU0sQ0FBQyxDQUFDLE9BQU8sSUFBSSxJQUFJLFNBQVM7Q0FDeEYsSUFBSSxNQUFNLGlCQUFpQixTQUFTO0VBQ2xDLE1BQU0sU0FBUyxNQUFNLFVBQVVBLFVBQVE7RUFDdkMsSUFBSSxNQUFNLE9BQ1IsT0FBTyxJQUFJLE1BQU0sS0FBSztFQUV4QixNQUFNLEVBQUUsR0FBRyxJQUFJLEdBQUcsT0FBTztFQUN6QixNQUFNLEtBQUssSUFBSSxPQUFPO0VBQ3RCLE1BQU0sS0FBSyxJQUFJLE9BQU87RUFDdEIsTUFBTSxNQUFNLENBQUMsS0FBSztFQUNsQixNQUFNLE1BQU0sQ0FBQyxLQUFLO0VBQ2xCLE1BQU0sS0FBSyxjQUFjO0VBQ3pCLE1BQU0sS0FBSyxjQUFjO0VBQ3pCLE1BQU0sS0FBSyxjQUFjO0VBQ3pCLE1BQU0sS0FBSyxjQUFjO0VBQ3pCLGNBQWMsS0FBSztFQUNuQixjQUFjLEtBQUs7RUFDbkIsY0FBYyxLQUFLO0VBQ25CLGNBQWMsS0FBSztFQUNuQixjQUFjLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxjQUFjO0VBQ3ZELGNBQWMsS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLGNBQWM7Q0FDekQsT0FBTyxJQUFJLE1BQU0sUUFBUSxRQUFRO0VBQy9CLE1BQU0sRUFBRSxLQUFLLFNBQVMsTUFBTTtFQUM1QixjQUFjLE1BQU0sSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLLE1BQU07RUFDbkQsY0FBYyxRQUFRLGFBQWEsSUFDakMsSUFBSSxLQUFLLElBQUksSUFDYixJQUFJLEtBQUssSUFBSSxJQUNiLElBQUksS0FBSyxJQUFJLElBQ2IsSUFBSSxLQUFLLElBQUksSUFDYixJQUFJLElBQ0osSUFBSSxFQUNOLENBQUM7Q0FDSCxPQUFPO0VBQ0wsY0FBYyxVQUFVLE1BQU0sUUFBUSxNQUFNLEdBQUcsTUFBTSxRQUFRLE1BQU0sQ0FBQztFQUNwRSxjQUFjLE1BQU0sSUFBSSxNQUFNLFFBQVEsT0FBTyxPQUFPLElBQUksTUFBTSxRQUFRLE9BQU8sTUFBTTtDQUNyRjtDQUNBLE1BQU0sY0FBYyxNQUFNLFFBQVEsT0FBTztDQUN6QyxJQUFJLEVBQUUsTUFBTSxnQkFBZ0IsaUJBQWlCLFlBQVksZ0JBQWdCLGlCQUFpQjtFQUN4RixZQUFZLGNBQWM7RUFDMUIsWUFBWSxPQUFPO0NBQ3JCO0NBQ0EsSUFBSSxRQUNGLGNBQWMsT0FBT0Qsb0JBQWtCLFNBQVMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO0NBRWxFLE9BQU87QUFDVDs7O0FDcENBLElBQU0sZ0JBQWdCLENBQUM7QUFDdkIsV0FBVyxZQUFZLGNBQWMsY0FBYyxhQUFhO0FBQ2hFLFdBQVcsSUFBSSxnQkFBZ0IsY0FBYyxlQUFlLGFBQWEsY0FBYyxxQkFBcUI7QUFDNUcsSUFBTSxXQUFXLElBQUksVUFBVTtBQUMvQixJQUFNLG9CQUFvQixJQUFJLE9BQU87QUFDckMsU0FBUyxvQkFBb0IsU0FBUyxZQUFZO0NBQ2hELE1BQU0sRUFBRSxjQUFjLFlBQVk7Q0FDbEMsUUFBUSxTQUFTO0NBQ2pCLGFBQWEsUUFBUSxTQUFTO0NBQzlCLGFBQWEsU0FBUyxTQUFTO0NBQy9CLGFBQWEsSUFBSSxTQUFTO0NBQzFCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLGFBQWEsUUFBUSxLQUFLO0VBQ3BELE1BQU0sY0FBYyxRQUFRLGFBQWE7RUFDekMsSUFBSSxZQUFZLFdBQVcsV0FDekIseUJBQXlCLFlBQVksTUFBTSxTQUFTLFlBQVk7T0FDM0QsSUFBSSxZQUFZLFdBQVcsVUFBVSxZQUFZLFdBQVcsVUFBVTtHQUMzRSxNQUFNLFdBQVcsWUFBWSxXQUFXO0dBQ3hDLE1BQU0sWUFBWSxZQUFZLEtBQUssS0FBSztHQUN4QyxNQUFNLFFBQVEsWUFBWSxLQUFLO0dBQy9CLE1BQU0sT0FBTyxZQUFZLEtBQUs7R0FDOUIsSUFBSSxZQUFZLE1BQ2QsMkJBQTJCLEtBQUssV0FBVyxPQUFPLE1BQU0sU0FBUyxZQUFZO0dBRS9FLElBQUksTUFDRixVQUFVLGdCQUFnQixVQUFVLGdCQUFnQixTQUFTLEVBQUUsQ0FBQyxRQUFRLEtBQUssVUFBVTtHQUV6RiwyQkFBMkIsV0FBVyxPQUFPLFVBQVUsU0FBUyxZQUFZO0VBQzlFO0NBQ0Y7QUFDRjtBQUNBLFNBQVMseUJBQXlCLE1BQU0sU0FBUyxjQUFjO0NBQzdELE1BQU0sU0FBUyxDQUFDO0NBQ2hCLE1BQU0sUUFBUSxjQUFjO0NBQzVCLE1BQU0sT0FBTztDQUNiLEtBQUssSUFBSSxLQUFLO0NBQ2QsS0FBSyxJQUFJLEtBQUs7Q0FDZCxLQUFLLFFBQVEsS0FBSztDQUNsQixLQUFLLFNBQVMsS0FBSztDQUNuQixNQUFNLFNBQVMsS0FBSztDQUNwQixJQUFJLENBQUMsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUMzQjtDQUVGLE1BQU0sRUFBRSxVQUFVLEtBQUssWUFBWTtDQUNuQyxNQUFNLGNBQWMsUUFBUTtDQUM1QixNQUFNLGFBQWEsU0FBUyxTQUFTO0NBQ3JDLElBQUksUUFDRixrQkFBa0IsUUFBUSxNQUFNO0NBRWxDLE1BQU0sWUFBWSxRQUFRLFVBQVUsR0FBRyxZQUFZLFNBQVMsV0FBVztDQUN2RSxNQUFNLFVBQVUsS0FBSztDQUNyQixNQUFNLGFBQWEsUUFBUTtDQUMzQixJQUFJLEtBQ0YsV0FBVyxJQUNYLFdBQVcsSUFDWCxXQUFXLElBQ1gsV0FBVyxJQUNYLFdBQVcsSUFDWCxXQUFXLElBQ1gsV0FBVyxJQUNYLFdBQVcsRUFDYjtDQUNBLE1BQU0sZ0JBQWdCLFFBQVEsSUFBSSxpQkFBaUI7Q0FDbkQsY0FBYyxjQUFjO0NBQzVCLGNBQWMsWUFBWSxRQUFRLFNBQVM7Q0FDM0MsY0FBYyxrQkFBa0I7Q0FDaEMsY0FBYyxnQkFBZ0IsU0FBUyxTQUFTLElBQUk7Q0FDcEQsY0FBYyxZQUFZLEtBQUs7Q0FDL0IsY0FBYyxRQUFRLEtBQUs7Q0FDM0IsY0FBYyxVQUFVO0NBQ3hCLGNBQWMsZUFBZTtDQUM3QixRQUFRLEtBQUssYUFBYTtBQUM1QjtBQUNBLFNBQVMsMkJBQTJCLFdBQVcsT0FBTyxVQUFVLFNBQVMsY0FBYztDQUNyRixNQUFNLEVBQUUsVUFBVSxLQUFLLFlBQVk7Q0FDbkMsVUFBVSxnQkFBZ0IsU0FBUyxFQUFFLE9BQU8sV0FBVyxRQUFRLFlBQVk7RUFDekUsTUFBTSxTQUFTLENBQUM7RUFDaEIsTUFBTSxRQUFRLGNBQWMsTUFBTTtFQUNsQyxJQUFJLENBQUMsTUFBTSxNQUFNLE9BQU8sTUFBTSxHQUM1QjtFQUVGLE1BQU0sY0FBYyxRQUFRO0VBQzVCLE1BQU0sYUFBYSxTQUFTLFNBQVM7RUFDckMsSUFBSSxXQUFXO0VBQ2YsSUFBSSxRQUNGLGtCQUFrQixRQUFRLE1BQU07RUFFbEMsSUFBSSxDQUFDLFVBQVU7R0FDYixJQUFJLE9BQU87SUFDVCxNQUFNLGNBQWMsQ0FBQztJQUNyQixNQUFNLGNBQWMsT0FBTyxNQUFNO0lBRWpDLGNBRGlDLEtBQ3hCLENBQUMsQ0FBQyxTQUFTLGVBQWU7S0FDakMsWUFBWSxLQUFLLFlBQVksU0FBUyxDQUFDO0tBQ3ZDLFlBQVksS0FBSyxHQUFHLFVBQVU7SUFDaEMsQ0FBQztJQUNELHFCQUFxQixhQUFhLGFBQWEsVUFBVSxHQUFHLFlBQVksU0FBUyxXQUFXO0dBQzlGLE9BQ0UsTUFBTSxZQUFZLFFBQVEsVUFBVSxHQUFHLFlBQVksU0FBUyxXQUFXO0VBRTNFLE9BQU87R0FDTCxNQUFNLFFBQVEsTUFBTSxhQUFhO0dBQ2pDLE1BQU0sWUFBWTtHQUNsQixJQUFJLENBQUMsVUFBVSxXQUNiLFVBQVUsUUFBUSxXQUFXLE9BQU8sT0FBTyxVQUFVLE9BQU87UUFDdkQ7SUFDTCxlQUFlLFFBQVEsT0FBTyxVQUFVLE9BQU87SUFDL0MsV0FBVztHQUNiO0VBQ0Y7RUFDQSxNQUFNLFlBQVksSUFBSSxTQUFTO0VBQy9CLE1BQU0sVUFBVSxNQUFNO0VBQ3RCLElBQUksWUFBWSxRQUFRLE9BQU87R0FDN0IsTUFBTSxnQkFBZ0Isc0JBQXNCLG1CQUFtQixPQUFPLE9BQU8sTUFBTTtHQUNuRixTQUFTLFVBQVUsR0FBRyxZQUFZLEtBQUssV0FBVyxHQUFHLFNBQVMsU0FBUyxJQUFJLFlBQVksYUFBYTtFQUN0RyxPQUNFLGVBQWUsS0FBSyxXQUFXLEdBQUcsU0FBUyxTQUFTLElBQUksVUFBVTtFQUVwRSxNQUFNLGdCQUFnQixRQUFRLElBQUksaUJBQWlCO0VBQ25ELGNBQWMsY0FBYztFQUM1QixjQUFjLFlBQVksUUFBUSxTQUFTO0VBQzNDLGNBQWMsa0JBQWtCO0VBQ2hDLGNBQWMsZ0JBQWdCLFNBQVMsU0FBUyxJQUFJO0VBQ3BELGNBQWMsWUFBWSxNQUFNO0VBQ2hDLGNBQWMsUUFBUSxNQUFNO0VBQzVCLGNBQWMsVUFBVTtFQUN4QixjQUFjLGVBQWU7RUFDN0IsY0FBYyxXQUFXO0VBQ3pCLFFBQVEsS0FBSyxhQUFhO0NBQzVCLENBQUM7QUFDSDtBQUNBLFNBQVMsY0FBYyxnQkFBZ0I7Q0FDckMsTUFBTSxhQUFhLENBQUM7Q0FDcEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGVBQWUsUUFBUSxLQUFLO0VBQzlDLE1BQU0sZ0JBQWdCLGVBQWUsRUFBRSxDQUFDO0VBQ3hDLE1BQU0sYUFBYSxDQUFDO0VBRXBCLElBRG9CLGNBQWMsY0FBYyxLQUNqQyxDQUFDLE1BQU0sZUFBZSxVQUFVLEdBQzdDLFdBQVcsS0FBSyxVQUFVO0NBRTlCO0NBQ0EsT0FBTztBQUNUOzs7QUNySkEsSUFBTSxxQkFBTixNQUF5QjtDQUN2QixjQUFjO0VBQ1osS0FBSyxVQUFVLENBQUM7RUFDaEIsS0FBSyxlQUFlO0dBQ2xCLFVBQVUsQ0FBQztHQUNYLEtBQUssQ0FBQztHQUNOLFNBQVMsQ0FBQztFQUNaO0NBQ0Y7Q0FDQSxRQUFRO0VBQ04sSUFBSSxLQUFLLFNBQ1AsS0FBSyxRQUFRLFNBQVMsVUFBVTtHQUM5QixRQUFRLE9BQU8sS0FBSztFQUN0QixDQUFDO0VBRUgsSUFBSSxLQUFLLGNBQ1AsUUFBUSxPQUFPLEtBQUssWUFBWTtFQUVsQyxLQUFLLGNBQWM7RUFDbkIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxRQUFRLFNBQVM7RUFDdEIsS0FBSyxhQUFhLFFBQVEsU0FBUztFQUNuQyxLQUFLLGFBQWEsU0FBUyxTQUFTO0VBQ3BDLEtBQUssYUFBYSxJQUFJLFNBQVM7RUFDL0IsS0FBSyxlQUFlO0NBQ3RCO0NBQ0EsVUFBVTtFQUNSLEtBQUssTUFBTTtFQUNYLEtBQUssVUFBVTtFQUNmLEtBQUssZUFBZTtDQUN0QjtBQUNGO0FBQ0EsSUFBTSw0QkFBTixNQUFnQztDQUM5QixjQUFjO0VBQ1osS0FBSyxlQUFlLElBQUksZUFBZTtDQUN6QztDQUNBLEtBQUssU0FBUztFQUNaLE1BQU0sY0FBYyxRQUFRO0VBQzVCLEtBQUssVUFBVSxLQUFLLFFBQVEsbUJBQW1CLFdBQVcsSUFBSSxLQUFLLFVBQVUsSUFBSSxlQUFlLEVBQUUsWUFBWSxDQUFDO0VBQy9HLEtBQUssYUFBYSxNQUFNO0NBQzFCOzs7Ozs7Q0FNQSxJQUFJLFdBQVc7RUFDYixZQUFZLFFBQVEsd0ZBQXdGO0VBQzVHLE9BQU8sS0FBSyxRQUFRO0NBQ3RCO0NBQ0EsVUFBVTtFQUNSLEtBQUssUUFBUSxRQUFRO0VBQ3JCLEtBQUssYUFBYSxRQUFRO0VBQzFCLEtBQUssVUFBVTtFQUNmLEtBQUssZUFBZTtDQUN0QjtBQUNGO0FBQ0EsSUFBTSx5QkFBeUIsTUFBTSx1QkFBdUI7Q0FDMUQsWUFBWSxVQUFVO0VBQ3BCLEtBQUssWUFBWTtFQUNqQixLQUFLLG1CQUFtQixJQUFJLGNBQWM7R0FBRTtHQUFVLE1BQU07R0FBWSxNQUFNO0VBQWtCLENBQUM7Q0FDbkc7Ozs7O0NBS0EsS0FBSyxTQUFTO0VBQ1osdUJBQXVCLGVBQWUsbUJBQW1CLFNBQVMsb0JBQW9CLHVCQUF1QixlQUFlO0NBQzlIOzs7Ozs7Q0FNQSxxQkFBcUIsU0FBUztFQUM1QixPQUFPLFFBQVEsU0FBUyxLQUFLLFVBQVUsSUFBSSxDQUFDLGdCQUFnQixLQUFLLHVCQUF1QixPQUFPO0NBQ2pHOzs7Ozs7OztDQVFBLGlCQUFpQixTQUFTO0VBQ3hCLE1BQU0sYUFBYSxDQUFDLENBQUMsUUFBUSxTQUFTLEtBQUssVUFBVTtFQUNyRCxNQUFNLGFBQWEsUUFBUSxTQUFTLEtBQUssVUFBVSxRQUFRLEtBQUssYUFBYSxPQUFPO0VBQ3BGLElBQUksUUFBUSxTQUFTLENBQUMsWUFBWTtHQUNoQyxJQUFJLFlBQ0YsV0FBVyxNQUFNO0dBRW5CLG9CQUFvQixTQUFTLFVBQVU7R0FDdkMsTUFBTSxZQUFZLFFBQVE7R0FDMUIsSUFBSSxRQUFRLGdCQUFnQixjQUFjLFlBQ3hDLFdBQVcsY0FBYztRQUNwQixJQUFJLGNBQWMsUUFDdkIsV0FBVyxjQUFjLFdBQVcsYUFBYSxTQUFTLFNBQVM7UUFFbkUsV0FBVyxjQUFjO0dBRTNCLFFBQVEsUUFBUTtFQUNsQjtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FRQSxjQUFjLFNBQVM7RUFDckIsT0FBTyxRQUFRLFNBQVMsS0FBSyxVQUFVLFFBQVEsS0FBSyxhQUFhLE9BQU87Q0FDMUU7Q0FDQSx1QkFBdUIsU0FBUztFQUM5QixNQUFNLGVBQWUsUUFBUSxJQUFJLDJCQUEyQixFQUMxRCxhQUFhLEtBQUssVUFBVSxPQUFPLHFCQUNyQyxDQUFDO0VBQ0QsTUFBTSxhQUFhLFFBQVEsU0FBUyxLQUFLLFVBQVU7RUFDbkQsTUFBTSxFQUFFLFNBQVMsaUJBQWlCO0VBQ2xDLFdBQVcsZUFBZTtFQUMxQixNQUFNLGFBQWEsYUFBYSxTQUFTO0VBQ3pDLE1BQU0sWUFBWSxhQUFhLFFBQVE7RUFDdkMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUNsQyxRQUFRLEVBQUUsQ0FBQyxpQkFBaUI7RUFFOUIsTUFBTSxVQUFVLGFBQWE7RUFDN0IsUUFBUSxzQkFBc0IsVUFBVTtFQUN4QyxRQUFRLGtCQUFrQixTQUFTO0VBQ25DLFFBQVEsTUFBTTtFQUNkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztHQUN2QyxNQUFNLFFBQVEsUUFBUTtHQUN0QixRQUFRLElBQUksS0FBSztFQUNuQjtFQUNBLFFBQVEsT0FBTyxhQUFhLFlBQVk7RUFDeEMsTUFBTSxXQUFXLFFBQVE7RUFDekIsU0FBUyxZQUFZLGdCQUFnQixRQUFRLGFBQWEsUUFBUSxXQUFXLElBQUk7RUFDakYsU0FBUyxRQUFRLEVBQUUsQ0FBQyxnQkFBZ0IsUUFBUSxnQkFBZ0IsYUFBYSxRQUFRLGVBQWUsSUFBSTtFQUNwRyxNQUFNLGNBQWMsUUFBUTtFQUM1QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxZQUFZLEtBQUs7R0FDM0MsTUFBTSxRQUFRLFlBQVk7R0FDMUIsTUFBTSxZQUFZLHlCQUNoQixNQUFNLFNBQVMsVUFDZixNQUFNLFNBQVMsT0FDZixLQUFLLFVBQVUsT0FBTyxvQkFDeEI7RUFDRjtFQUNBLE9BQU87Q0FDVDtDQUNBLGFBQWEsU0FBUztFQUNwQixNQUFNLGFBQWEsSUFBSSxtQkFBbUI7RUFDMUMsV0FBVyxVQUFVO0VBQ3JCLFFBQVEsU0FBUyxLQUFLLFVBQVUsT0FBTztFQUN2QyxLQUFLLGlCQUFpQixJQUFJLE9BQU87RUFDakMsT0FBTztDQUNUO0NBQ0EsVUFBVTtFQUNSLEtBQUssaUJBQWlCLFFBQVE7RUFDOUIsS0FBSyxZQUFZO0NBQ25CO0FBQ0Y7O0FBRUEsdUJBQXVCLFlBQVk7Q0FDakMsTUFBTSxDQUNKLGNBQWMsYUFDZCxjQUFjLFlBQ2hCO0NBQ0EsTUFBTTtBQUNSOztBQUVBLHVCQUF1QixpQkFBaUI7Ozs7O0FBS3RDLGtCQUFrQixHQUNwQjtBQUNBLElBQUksd0JBQXdCOzs7QUN4TDVCLElBQU1FLG9CQUFrQjtBQUN4QixJQUFNQyxnQkFBYztBQUNwQixJQUFNQywwQkFBd0I7QUFJOUIsU0FBUyxvQkFBb0IsUUFBUSxJQUFJLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxJQUFJLElBQUksWUFBWTtDQU92RixJQUFJLHFCQUFxQkEsMEJBTFAsS0FBSyxJQUNyQixLQUVBLEtBQUssSUFBSSxHQUFHLGNBQWMsc0JBQXNCLGVBQWUsZ0JBQWdCLENBRWhDLEtBQWE7Q0FDOUQscUJBQXFCO0NBQ3JCLFFBQU0sSUFBSSxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsaUJBQWlCO0NBQ3ZFLE9BQU87QUFDVDtBQUNBLFNBQVNDLFFBQU0sSUFBSSxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsbUJBQW1CO0NBQ2hGLFlBQVUsSUFBSSxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsbUJBQW1CLENBQUM7Q0FDOUUsT0FBTyxLQUFLLElBQUksRUFBRTtBQUNwQjtBQUNBLFNBQVNDLFlBQVUsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsbUJBQW1CLE9BQU87Q0FDbkYsSUFBSSxRQUFRSixtQkFDVjtDQUdGLE1BQU0sT0FBTyxLQUFLLE1BQU07Q0FDeEIsTUFBTSxPQUFPLEtBQUssTUFBTTtDQUN4QixNQUFNLE9BQU8sS0FBSyxNQUFNO0NBQ3hCLE1BQU0sT0FBTyxLQUFLLE1BQU07Q0FDeEIsTUFBTSxPQUFPLEtBQUssTUFBTTtDQUN4QixNQUFNLE9BQU8sS0FBSyxNQUFNO0NBQ3hCLE1BQU0sUUFBUSxNQUFNLE9BQU87Q0FDM0IsTUFBTSxRQUFRLE1BQU0sT0FBTztDQUMzQixNQUFNLFFBQVEsTUFBTSxPQUFPO0NBQzNCLE1BQU0sUUFBUSxNQUFNLE9BQU87Q0FDM0IsTUFBTSxTQUFTLE9BQU8sUUFBUTtDQUM5QixNQUFNLFNBQVMsT0FBTyxRQUFRO0NBQzlCLElBQUksUUFBUSxHQUFHO0VBQ2IsSUFBSSxLQUFLLEtBQUs7RUFDZCxJQUFJLEtBQUssS0FBSztFQUNkLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLEVBQUU7RUFDbkQsTUFBTSxLQUFLLEtBQUssS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sRUFBRTtFQUduRCxJQUFJLEtBQUtDLGlCQUFlLEtBQUtBLGVBQ3RCO1FBQUEsS0FBSyxPQUFPLEtBQUssT0FBTyxxQkFBcUIsS0FBSyxLQUFLLEtBQUssS0FBSztJQUVsRSxPQUFPLEtBQUssT0FBTyxLQUFLO0lBQ3hCO0dBcUJKO1NBQ0ssSUFBSSxLQUFLQSxlQUNWO09BQUEsS0FBSyxNQUFNLHFCQUFxQixLQUFLLEtBQUssS0FBSyxLQUFLO0lBRXBELE9BQU8sS0FBSyxPQUFPLEtBQUs7SUFDeEI7R0FlSjtTQUNLLElBQUksS0FBS0EsZUFDVjtPQUFBLEtBQUssTUFBTSxxQkFBcUIsS0FBSyxLQUFLLEtBQUssS0FBSztJQUVwRCxPQUFPLEtBQUssT0FBTyxLQUFLO0lBQ3hCO0dBZUo7U0FDSztHQUNMLEtBQUssU0FBUyxLQUFLLE1BQU07R0FDekIsS0FBSyxTQUFTLEtBQUssTUFBTTtHQUN6QixJQUFJLEtBQUssS0FBSyxLQUFLLE1BQU0sbUJBQW1CO0lBQzFDLE9BQU8sS0FBSyxPQUFPLEtBQUs7SUFDeEI7R0FDRjtFQUNGO0NBQ0Y7Q0FDQSxZQUFVLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxNQUFNLE9BQU8sT0FBTyxRQUFRLG1CQUFtQixRQUFRLENBQUM7Q0FDMUYsWUFBVSxPQUFPLE9BQU8sTUFBTSxNQUFNLEtBQUssS0FBSyxJQUFJLElBQUksUUFBUSxtQkFBbUIsUUFBUSxDQUFDO0FBQzVGOzs7QUMzSEEsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxjQUFjO0FBQ3BCLElBQU0sd0JBQXdCO0FBRzlCLFNBQVMsdUJBQXVCLFFBQVEsSUFBSSxJQUFJLE1BQU0sTUFBTSxJQUFJLElBQUksWUFBWTtDQU85RSxJQUFJLHFCQUFxQix3QkFMUCxLQUFLLElBQ3JCLEtBRUEsS0FBSyxJQUFJLEdBQUcsY0FBYyxzQkFBc0IsZUFBZSxnQkFBZ0IsQ0FFaEMsS0FBYTtDQUM5RCxxQkFBcUI7Q0FDckIsTUFBTSxJQUFJLElBQUksTUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGlCQUFpQjtDQUMzRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLE1BQU0sSUFBSSxJQUFJLE1BQU0sTUFBTSxJQUFJLElBQUksUUFBUSxtQkFBbUI7Q0FDcEUsVUFBVSxRQUFRLElBQUksSUFBSSxNQUFNLE1BQU0sSUFBSSxJQUFJLG1CQUFtQixDQUFDO0NBQ2xFLE9BQU8sS0FBSyxJQUFJLEVBQUU7QUFDcEI7QUFDQSxTQUFTLFVBQVUsUUFBUSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxtQkFBbUIsT0FBTztDQUMzRSxJQUFJLFFBQVEsaUJBQ1Y7Q0FHRixNQUFNLE9BQU8sS0FBSyxNQUFNO0NBQ3hCLE1BQU0sT0FBTyxLQUFLLE1BQU07Q0FDeEIsTUFBTSxPQUFPLEtBQUssTUFBTTtDQUN4QixNQUFNLE9BQU8sS0FBSyxNQUFNO0NBQ3hCLE1BQU0sUUFBUSxNQUFNLE9BQU87Q0FDM0IsTUFBTSxRQUFRLE1BQU0sT0FBTztDQUMzQixJQUFJLEtBQUssS0FBSztDQUNkLElBQUksS0FBSyxLQUFLO0NBQ2QsTUFBTSxJQUFJLEtBQUssS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sRUFBRTtDQUNsRCxJQUFJLElBQUksYUFDRjtNQUFBLElBQUksS0FBSyxxQkFBcUIsS0FBSyxLQUFLLEtBQUssS0FBSztHQUVsRCxPQUFPLEtBQUssTUFBTSxJQUFJO0dBQ3RCO0VBUUo7UUFDSztFQUNMLEtBQUssUUFBUSxLQUFLLE1BQU07RUFDeEIsS0FBSyxRQUFRLEtBQUssTUFBTTtFQUN4QixJQUFJLEtBQUssS0FBSyxLQUFLLE1BQU0sbUJBQW1CO0dBQzFDLE9BQU8sS0FBSyxNQUFNLElBQUk7R0FDdEI7RUFDRjtDQUNGO0NBQ0EsVUFBVSxRQUFRLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxNQUFNLG1CQUFtQixRQUFRLENBQUM7Q0FDNUUsVUFBVSxRQUFRLE1BQU0sTUFBTSxLQUFLLEtBQUssSUFBSSxJQUFJLG1CQUFtQixRQUFRLENBQUM7QUFDOUU7OztBQzVEQSxTQUFTLFNBQVMsUUFBUSxHQUFHLEdBQUcsUUFBUSxPQUFPLEtBQUssV0FBVyxPQUFPO0NBQ3BFLElBQUksT0FBTyxLQUFLLElBQUksUUFBUSxHQUFHO0NBQy9CLElBQUksQ0FBQyxhQUFhLFFBQVEsS0FDeEIsT0FBTyxJQUFJLEtBQUssS0FBSztNQUNoQixJQUFJLGFBQWEsTUFBTSxPQUM1QixPQUFPLElBQUksS0FBSyxLQUFLO0NBRXZCLFVBQVUsUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sSUFBSSxLQUFLLElBQUksUUFBUSxJQUFJLENBQUMsS0FBSyxPQUFPLEtBQUssR0FBRyxDQUFDO0NBQ3hGLFFBQVEsS0FBSyxJQUFJLE9BQU8sQ0FBQztDQUN6QixJQUFJLElBQUksT0FBTztDQUNmLElBQUksSUFBSTtDQUNSLEtBQUssWUFBWSxLQUFLO0NBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEdBQUcsS0FBSztFQUNsQyxNQUFNLEtBQUssS0FBSyxJQUFJLENBQUM7RUFDckIsTUFBTSxLQUFLLEtBQUssSUFBSSxDQUFDO0VBQ3JCLE1BQU0sS0FBSyxJQUFJLEtBQUs7RUFDcEIsTUFBTSxLQUFLLElBQUksS0FBSztFQUNwQixPQUFPLEtBQUssSUFBSSxFQUFFO0VBQ2xCLEtBQUs7Q0FDUDtBQUNGOzs7QUNsQkEsU0FBUyxXQUFXLFFBQVEsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRO0NBQ2xELE1BQU0sUUFBUSxPQUFPLE9BQU8sU0FBUztDQUVyQyxNQUFNLEtBRFEsT0FBTyxPQUFPLFNBQVMsS0FDbEI7Q0FDbkIsTUFBTSxLQUFLLFFBQVE7Q0FDbkIsTUFBTSxLQUFLLEtBQUs7Q0FDaEIsTUFBTSxLQUFLLEtBQUs7Q0FDaEIsTUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxFQUFFO0NBQ3JDLElBQUksS0FBSyxRQUFRLFdBQVcsR0FBRztFQUM3QixJQUFJLE9BQU8sT0FBTyxTQUFTLE9BQU8sTUFBTSxPQUFPLE9BQU8sU0FBUyxPQUFPLElBQ3BFLE9BQU8sS0FBSyxJQUFJLEVBQUU7RUFFcEI7Q0FDRjtDQUNBLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSztDQUMxQixNQUFNLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDMUIsTUFBTSxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQzFCLE1BQU0sS0FBSyxTQUFTLEtBQUssS0FBSyxFQUFFLElBQUk7Q0FDcEMsTUFBTSxLQUFLLFNBQVMsS0FBSyxLQUFLLEVBQUUsSUFBSTtDQUNwQyxNQUFNLEtBQUssS0FBSyxLQUFLO0NBQ3JCLE1BQU0sS0FBSyxLQUFLLEtBQUs7Q0FDckIsTUFBTSxLQUFLLEtBQUssS0FBSyxLQUFLO0NBQzFCLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSztDQUMxQixNQUFNLEtBQUssTUFBTSxLQUFLO0NBQ3RCLE1BQU0sS0FBSyxNQUFNLEtBQUs7Q0FDdEIsTUFBTSxLQUFLLE1BQU0sS0FBSztDQUN0QixNQUFNLEtBQUssTUFBTSxLQUFLO0NBQ3RCLE1BQU0sYUFBYSxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssRUFBRTtDQUM5QyxNQUFNLFdBQVcsS0FBSyxNQUFNLEtBQUssSUFBSSxLQUFLLEVBQUU7Q0FDNUMsU0FDRSxRQUNBLEtBQUssSUFDTCxLQUFLLElBQ0wsUUFDQSxZQUNBLFVBQ0EsS0FBSyxLQUFLLEtBQUssRUFDakI7QUFDRjs7O0FDdENBLElBQU0sTUFBTSxLQUFLLEtBQUs7QUFDdEIsSUFBTSxNQUFNO0NBQ1YsU0FBUztDQUNULFNBQVM7Q0FDVCxNQUFNO0NBQ04sTUFBTTtBQUNSO0FBQ0EsSUFBTSxnQkFBZ0IsRUFBRSxHQUFHLEtBQUssSUFBSSxJQUFJLFFBQVEsUUFBUSxTQUFTLFNBQVMsU0FBUztDQUNqRixLQUFLO0NBQ0wsS0FBSztDQUNMLE1BQU0sS0FBSyxTQUFTLElBQUksU0FBUztDQUNqQyxNQUFNLEtBQUssU0FBUyxJQUFJLFNBQVM7Q0FDakMsS0FBSyxJQUFJLEtBQUs7Q0FDZCxLQUFLLElBQUksS0FBSztDQUNkLE9BQU87QUFDVDtBQUNBLFNBQVMsY0FBYyxNQUFNLE1BQU07Q0FDakMsTUFBTSxLQUFLLFNBQVMsc0JBQXNCLGlCQUFrQixJQUFJLElBQUksS0FBSyxJQUFJLE9BQU8sQ0FBQztDQUNyRixNQUFNLElBQUksU0FBUyxxQkFBcUIsZ0JBQWlCO0NBQ3pELE1BQU0sS0FBSyxLQUFLLElBQUksSUFBSTtDQUN4QixNQUFNLEtBQUssS0FBSyxJQUFJLElBQUk7Q0FDeEIsTUFBTSxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUk7Q0FDL0IsTUFBTSxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUk7Q0FDL0IsT0FBTztFQUNMO0dBQ0UsR0FBRyxLQUFLLEtBQUs7R0FDYixHQUFHLEtBQUssS0FBSztFQUNmO0VBQ0E7R0FDRSxHQUFHLEtBQUssS0FBSztHQUNiLEdBQUcsS0FBSyxLQUFLO0VBQ2Y7RUFDQTtHQUNFLEdBQUc7R0FDSCxHQUFHO0VBQ0w7Q0FDRjtBQUNGO0FBQ0EsSUFBTSxlQUFlLElBQUksSUFBSSxJQUFJLE9BQU87Q0FDdEMsTUFBTSxPQUFPLEtBQUssS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLO0NBQzFDLElBQUksTUFBTSxLQUFLLEtBQUssS0FBSztDQUN6QixJQUFJLE1BQU0sR0FDUixNQUFNO0NBRVIsSUFBSSxNQUFNLElBQ1IsTUFBTTtDQUVSLE9BQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUM3QjtBQUNBLElBQU0sZ0JBQWdCLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLGNBQWMsV0FBVyxRQUFRLFFBQVEsS0FBSyxLQUFLLFNBQVM7Q0FDeEcsTUFBTSxPQUFPLEtBQUssSUFBSSxJQUFJLENBQUM7Q0FDM0IsTUFBTSxPQUFPLEtBQUssSUFBSSxJQUFJLENBQUM7Q0FDM0IsTUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLLENBQUM7Q0FDN0IsTUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLLENBQUM7Q0FDN0IsSUFBSSxXQUFXLE9BQU8sT0FBTyxPQUFPLFFBQVEsT0FBTztDQUNuRCxJQUFJLFdBQVcsR0FDYixXQUFXO0NBRWIsWUFBWSxPQUFPLFFBQVEsT0FBTztDQUNsQyxXQUFXLEtBQUssS0FBSyxRQUFRLEtBQUssaUJBQWlCLFlBQVksS0FBSztDQUNwRSxNQUFNLFdBQVcsV0FBVyxLQUFLLEtBQUs7Q0FDdEMsTUFBTSxXQUFXLFdBQVcsQ0FBQyxLQUFLLEtBQUs7Q0FDdkMsTUFBTSxVQUFVLFNBQVMsV0FBVyxTQUFTLFlBQVksS0FBSyxNQUFNO0NBQ3BFLE1BQU0sVUFBVSxTQUFTLFdBQVcsU0FBUyxZQUFZLEtBQUssTUFBTTtDQUNwRSxNQUFNLE9BQU8sTUFBTSxZQUFZO0NBQy9CLE1BQU0sT0FBTyxNQUFNLFlBQVk7Q0FDL0IsTUFBTSxPQUFPLENBQUMsTUFBTSxZQUFZO0NBQ2hDLE1BQU0sT0FBTyxDQUFDLE1BQU0sWUFBWTtDQUNoQyxNQUFNLE9BQU8sWUFBWSxHQUFHLEdBQUcsS0FBSyxHQUFHO0NBQ3ZDLElBQUksT0FBTyxZQUFZLEtBQUssS0FBSyxLQUFLLEdBQUc7Q0FDekMsSUFBSSxjQUFjLEtBQUssT0FBTyxHQUM1QixRQUFRO0NBRVYsSUFBSSxjQUFjLEtBQUssT0FBTyxHQUM1QixRQUFRO0NBRVYsS0FBSyxVQUFVO0NBQ2YsS0FBSyxVQUFVO0NBQ2YsS0FBSyxPQUFPO0NBQ1osS0FBSyxPQUFPO0FBQ2Q7QUFDQSxTQUFTLGNBQWMsUUFBUSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxnQkFBZ0IsR0FBRyxlQUFlLEdBQUcsWUFBWSxHQUFHO0NBQ3pHLElBQUksT0FBTyxLQUFLLE9BQU8sR0FDckI7Q0FFRixNQUFNLFNBQVMsS0FBSyxJQUFJLGdCQUFnQixNQUFNLEdBQUc7Q0FDakQsTUFBTSxTQUFTLEtBQUssSUFBSSxnQkFBZ0IsTUFBTSxHQUFHO0NBQ2pELE1BQU0sTUFBTSxVQUFVLEtBQUssTUFBTSxJQUFJLFVBQVUsS0FBSyxNQUFNO0NBQzFELE1BQU0sTUFBTSxDQUFDLFVBQVUsS0FBSyxNQUFNLElBQUksVUFBVSxLQUFLLE1BQU07Q0FDM0QsSUFBSSxRQUFRLEtBQUssUUFBUSxHQUN2QjtDQUVGLEtBQUssS0FBSyxJQUFJLEVBQUU7Q0FDaEIsS0FBSyxLQUFLLElBQUksRUFBRTtDQUNoQixNQUFNLFNBQVMsS0FBSyxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQztDQUNyRixJQUFJLFNBQVMsR0FBRztFQUNkLE1BQU0sS0FBSyxLQUFLLE1BQU07RUFDdEIsTUFBTSxLQUFLLEtBQUssTUFBTTtDQUN4QjtDQUNBLGFBQ0UsSUFDQSxJQUNBLElBQ0EsSUFDQSxJQUNBLElBQ0EsY0FDQSxXQUNBLFFBQ0EsUUFDQSxLQUNBLEtBQ0EsR0FDRjtDQUNBLElBQUksRUFBRSxNQUFNLFNBQVM7Q0FDckIsTUFBTSxFQUFFLFNBQVMsWUFBWTtDQUM3QixJQUFJLFFBQVEsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNO0NBQ3BDLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLE1BQ3hCLFFBQVE7Q0FFVixNQUFNLFdBQVcsS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEdBQUcsQ0FBQztDQUM3QyxRQUFRO0NBQ1IsSUFBSSxRQUFRLE9BQU8sT0FBTyxTQUFTO0NBQ25DLElBQUksUUFBUSxPQUFPLE9BQU8sU0FBUztDQUNuQyxNQUFNLGdCQUFnQjtFQUFFLEdBQUc7RUFBRyxHQUFHO0NBQUU7Q0FDbkMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsS0FBSztFQUNqQyxNQUFNLFFBQVEsY0FBYyxNQUFNLElBQUk7RUFDdEMsTUFBTSxFQUFFLEdBQUcsSUFBSSxHQUFHLE9BQU8sYUFBYSxNQUFNLElBQUksSUFBSSxJQUFJLFFBQVEsUUFBUSxTQUFTLFNBQVMsYUFBYTtFQUN2RyxNQUFNLEVBQUUsR0FBRyxJQUFJLEdBQUcsT0FBTyxhQUFhLE1BQU0sSUFBSSxJQUFJLElBQUksUUFBUSxRQUFRLFNBQVMsU0FBUyxhQUFhO0VBQ3ZHLE1BQU0sRUFBRSxHQUFHLE1BQU0sYUFBYSxNQUFNLElBQUksSUFBSSxJQUFJLFFBQVEsUUFBUSxTQUFTLFNBQVMsYUFBYTtFQUMvRixvQkFDRSxRQUNBLE9BQ0EsT0FDQSxJQUNBLElBQ0EsSUFDQSxJQUNBLEdBQ0EsQ0FDRjtFQUNBLFFBQVE7RUFDUixRQUFRO0VBQ1IsUUFBUTtDQUNWO0FBQ0Y7OztBQ25KQSxTQUFTLGdCQUFnQixHQUFHLFFBQVEsUUFBUTtDQUMxQyxNQUFNLFdBQVcsR0FBRyxPQUFPO0VBQ3pCLE1BQU0sSUFBSSxHQUFHLElBQUksRUFBRTtFQUNuQixNQUFNLElBQUksR0FBRyxJQUFJLEVBQUU7RUFDbkIsTUFBTSxNQUFNLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDO0VBR25DLE9BQU87R0FBRTtHQUFLLElBRkgsSUFBSTtHQUVHLElBRFAsSUFBSTtFQUNNO0NBQ3ZCO0NBQ0EsTUFBTSxlQUFlLEdBQUcsTUFBTTtFQUM1QixJQUFJLE1BQU0sR0FDUixFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQztPQUVqQixFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQztDQUVyQjtDQUNBLElBQUksS0FBSyxPQUFPLE9BQU8sU0FBUztDQUNoQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7RUFDdEMsTUFBTSxLQUFLLE9BQU8sSUFBSSxPQUFPO0VBQzdCLE1BQU0sVUFBVSxHQUFHLFVBQVU7RUFDN0IsSUFBSSxXQUFXLEdBQUc7R0FDaEIsWUFBWSxHQUFHLEVBQUU7R0FDakIsS0FBSztHQUNMO0VBQ0Y7RUFDQSxNQUFNLEtBQUssUUFBUSxJQUFJLEtBQUssT0FBTztFQUNuQyxNQUFNLEtBQUssUUFBUSxJQUFJLEVBQUU7RUFDekIsTUFBTSxLQUFLLFFBQVEsSUFBSSxFQUFFO0VBQ3pCLElBQUksR0FBRyxNQUFNLFFBQVEsR0FBRyxNQUFNLE1BQU07R0FDbEMsWUFBWSxHQUFHLEVBQUU7R0FDakIsS0FBSztHQUNMO0VBQ0Y7RUFDQSxJQUFJLFFBQVEsS0FBSyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsRUFBRTtFQUNuRCxJQUFJLGVBQWU7RUFDbkIsSUFBSSxnQkFBZ0I7RUFDcEIsSUFBSSxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSyxHQUFHO0dBQ3RDLElBQUksUUFBUSxHQUNWLFFBQVEsS0FBSyxLQUFLO1FBQ2I7SUFDTCxRQUFRLEtBQUssS0FBSztJQUNsQixlQUFlO0lBQ2YsZ0JBQWdCO0dBQ2xCO0VBQ0YsT0FBTyxJQUFJLFFBQVEsR0FBRztHQUNwQixlQUFlO0dBQ2YsZ0JBQWdCO0VBQ2xCO0VBQ0EsTUFBTSxZQUFZLFFBQVE7RUFDMUIsSUFBSTtFQUNKLElBQUksU0FBUyxLQUFLLElBQ2hCLEtBQUssSUFBSSxTQUFTLElBQUksVUFBVSxLQUFLLElBQUksU0FBUyxDQUNwRDtFQUNBLElBQUksU0FBUyxLQUFLLElBQUksR0FBRyxNQUFNLEdBQUcsR0FBRyxNQUFNLENBQUMsR0FBRztHQUM3QyxTQUFTLEtBQUssSUFBSSxHQUFHLE1BQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQztHQUN4QyxVQUFVLEtBQUssSUFBSSxTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksS0FBSyxJQUFJLFNBQVMsQ0FBQztFQUN2RSxPQUNFLFVBQVU7RUFFWixNQUFNLEtBQUssR0FBRyxJQUFJLEdBQUcsS0FBSyxTQUFTLENBQUMsR0FBRyxLQUFLLFVBQVU7RUFDdEQsTUFBTSxLQUFLLEdBQUcsSUFBSSxHQUFHLEtBQUssU0FBUyxHQUFHLEtBQUssVUFBVTtFQUNyRCxNQUFNLGFBQWEsS0FBSyxNQUFNLEdBQUcsSUFBSSxHQUFHLEVBQUUsSUFBSSxLQUFLLEtBQUssSUFBSTtFQUM1RCxNQUFNLFdBQVcsS0FBSyxNQUFNLEdBQUcsSUFBSSxHQUFHLEVBQUUsSUFBSSxLQUFLLEtBQUssSUFBSTtFQUMxRCxJQUFJLE1BQU0sR0FDUixFQUFFLE9BQ0EsS0FBSyxLQUFLLElBQUksVUFBVSxJQUFJLFNBQzVCLEtBQUssS0FBSyxJQUFJLFVBQVUsSUFBSSxPQUM5QjtFQUVGLEVBQUUsSUFBSSxJQUFJLElBQUksU0FBUyxZQUFZLFVBQVUsYUFBYTtFQUMxRCxLQUFLO0NBQ1A7QUFDRjtBQUNBLFNBQVMsMkJBQTJCLEdBQUcsUUFBUSxRQUFRLFlBQVk7Q0FDakUsTUFBTSxZQUFZLElBQUksT0FBTyxLQUFLLE1BQU0sR0FBRyxJQUFJLEdBQUcsTUFBTSxLQUFLLEdBQUcsSUFBSSxHQUFHLE1BQU0sQ0FBQztDQUM5RSxNQUFNLGFBQWEsSUFBSSxJQUFJLE9BQU87RUFDaEMsR0FBRyxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsS0FBSztFQUMxQixHQUFHLEdBQUcsS0FBSyxHQUFHLElBQUksR0FBRyxLQUFLO0NBQzVCO0NBQ0EsTUFBTSxZQUFZLE9BQU87Q0FDekIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsS0FBSztFQUNsQyxNQUFNLFlBQVksUUFBUSxJQUFJLEtBQUs7RUFDbkMsTUFBTSxVQUFVLFVBQVUsVUFBVTtFQUNwQyxJQUFJLFdBQVcsR0FBRztHQUNoQixJQUFJLE1BQU0sR0FDUixFQUFFLE9BQU8sVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUVqQyxFQUFFLE9BQU8sVUFBVSxHQUFHLFVBQVUsQ0FBQztHQUVuQztFQUNGO0VBQ0EsTUFBTSxZQUFZLE9BQU87RUFDekIsTUFBTSxZQUFZLFFBQVEsSUFBSSxLQUFLO0VBQ25DLE1BQU0saUJBQWlCLFNBQVMsV0FBVyxTQUFTO0VBQ3BELElBQUk7RUFDSixJQUFJLGlCQUFpQixNQUNuQixRQUFRO09BR1IsUUFBUSxVQUNOLFdBQ0EsV0FIeUIsS0FBSyxJQUFJLGlCQUFpQixHQUFHLE9BSXJDLElBQUksY0FDdkI7RUFFRixNQUFNLGlCQUFpQixTQUFTLFdBQVcsU0FBUztFQUNwRCxJQUFJO0VBQ0osSUFBSSxpQkFBaUIsTUFDbkIsTUFBTTtPQUdOLE1BQU0sVUFDSixXQUNBLFdBSHlCLEtBQUssSUFBSSxpQkFBaUIsR0FBRyxPQUlyQyxJQUFJLGNBQ3ZCO0VBRUYsSUFBSSxNQUFNLEdBQ1IsRUFBRSxPQUFPLE1BQU0sR0FBRyxNQUFNLENBQUM7T0FFekIsRUFBRSxPQUFPLE1BQU0sR0FBRyxNQUFNLENBQUM7RUFFM0IsRUFBRSxpQkFBaUIsVUFBVSxHQUFHLFVBQVUsR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLFVBQVU7Q0FDdkU7QUFDRjs7O0FDL0dBLElBQU0sZ0JBQWdCLElBQUksVUFBVTtBQUNwQyxJQUFNLFlBQU4sTUFBZ0I7Q0FDZCxZQUFZLGdCQUFnQjs7RUFFMUIsS0FBSyxrQkFBa0IsQ0FBQztFQUN4QixLQUFLLGVBQWU7RUFDcEIsS0FBSyxVQUFVLElBQUksT0FBTztFQUMxQixLQUFLLGtCQUFrQjtFQUN2QixLQUFLLFNBQVMsZUFBZTtDQUMvQjs7Ozs7OztDQU9BLE9BQU8sR0FBRyxHQUFHO0VBQ1gsS0FBSyxVQUFVLEdBQUcsQ0FBQztFQUNuQixPQUFPO0NBQ1Q7Ozs7Ozs7Q0FPQSxPQUFPLEdBQUcsR0FBRztFQUNYLEtBQUssWUFBWTtFQUNqQixNQUFNLFNBQVMsS0FBSyxhQUFhO0VBQ2pDLE1BQU0sUUFBUSxPQUFPLE9BQU8sU0FBUztFQUNyQyxNQUFNLFFBQVEsT0FBTyxPQUFPLFNBQVM7RUFDckMsSUFBSSxVQUFVLEtBQUssVUFBVSxHQUMzQixPQUFPLEtBQUssR0FBRyxDQUFDO0VBRWxCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7O0NBWUEsSUFBSSxHQUFHLEdBQUcsUUFBUSxZQUFZLFVBQVUsa0JBQWtCO0VBQ3hELEtBQUssWUFBWSxLQUFLO0VBQ3RCLE1BQU0sU0FBUyxLQUFLLGFBQWE7RUFDakMsU0FBUyxRQUFRLEdBQUcsR0FBRyxRQUFRLFlBQVksVUFBVSxnQkFBZ0I7RUFDckUsT0FBTztDQUNUOzs7Ozs7Ozs7OztDQVdBLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRO0VBQzVCLEtBQUssWUFBWTtFQUNqQixNQUFNLFNBQVMsS0FBSyxhQUFhO0VBQ2pDLFdBQVcsUUFBUSxJQUFJLElBQUksSUFBSSxJQUFJLE1BQU07RUFDekMsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7O0NBYUEsU0FBUyxJQUFJLElBQUksZUFBZSxjQUFjLFdBQVcsR0FBRyxHQUFHO0VBQzdELE1BQU0sU0FBUyxLQUFLLGFBQWE7RUFDakMsY0FDRSxRQUNBLEtBQUssYUFBYSxPQUNsQixLQUFLLGFBQWEsT0FDbEIsR0FDQSxHQUNBLElBQ0EsSUFDQSxlQUNBLGNBQ0EsU0FDRjtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxjQUFjLE1BQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxHQUFHLFlBQVk7RUFDdEQsS0FBSyxZQUFZO0VBQ2pCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLG9CQUNFLEtBQUssYUFBYSxRQUNsQixZQUFZLE9BQ1osWUFBWSxPQUNaLE1BQ0EsTUFDQSxNQUNBLE1BQ0EsR0FDQSxHQUNBLFVBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7O0NBV0EsaUJBQWlCLE1BQU0sTUFBTSxHQUFHLEdBQUcsV0FBVztFQUM1QyxLQUFLLFlBQVk7RUFDakIsTUFBTSxjQUFjLEtBQUs7RUFDekIsdUJBQ0UsS0FBSyxhQUFhLFFBQ2xCLFlBQVksT0FDWixZQUFZLE9BQ1osTUFDQSxNQUNBLEdBQ0EsR0FDQSxTQUNGO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Q0FNQSxZQUFZO0VBQ1YsS0FBSyxRQUFRLElBQUk7RUFDakIsT0FBTztDQUNUOzs7Ozs7O0NBT0EsUUFBUSxNQUFNLFdBQVc7RUFDdkIsS0FBSyxRQUFRO0VBQ2IsSUFBSSxhQUFhLENBQUMsVUFBVSxXQUFXLEdBQUc7R0FDeEMsT0FBTyxLQUFLLE1BQU0sSUFBSTtHQUN0QixLQUFLLFVBQVUsU0FBUztFQUMxQjtFQUNBLE1BQU0sa0JBQWtCLEtBQUs7RUFDN0IsTUFBTSxRQUFRLGdCQUFnQjtFQUM5QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxhQUFhLFFBQVEsS0FBSztHQUNqRCxNQUFNLGNBQWMsS0FBSyxhQUFhO0dBQ3RDLEtBQUssWUFBWSxPQUFPLENBQUMsR0FBRyxZQUFZLElBQUk7RUFDOUM7RUFDQSxJQUFJLEtBQUssaUJBQWlCLGdCQUFnQixTQUFTLFFBQVEsR0FBRztHQUM1RCxJQUFJLFlBQVk7R0FDaEIsS0FBSyxJQUFJLElBQUksT0FBTyxJQUFJLGdCQUFnQixRQUFRLEtBQUs7SUFDbkQsTUFBTSxpQkFBaUIsZ0JBQWdCO0lBQ3ZDLElBQUksZUFBZSxNQUFNLFNBQVMsV0FBVztLQUMzQyxNQUFNLFVBQVUsZUFBZTtLQUMvQixNQUFNLGNBQWMsV0FBVztLQUMvQixJQUFJLGVBQWUsWUFBWSxnQkFBZ0IsT0FBTyxHQUFHO01BQ3ZELFVBQVUsVUFBVSxVQUFVLFFBQVEsQ0FBQztNQUN2QyxVQUFVLE1BQU0sS0FBSyxjQUFjO01BQ25DLGdCQUFnQixXQUFXLEdBQUcsSUFBSSxDQUFDO01BQ25DLGdCQUFnQjtNQUNoQjtLQUNGLE9BQ0UsWUFBWTtJQUVoQjtHQUNGO0VBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Ozs7O0NBS0EsT0FBTyxZQUFZLE9BQU87RUFDeEIsS0FBSyxRQUFRLFNBQVM7Q0FDeEI7Ozs7Ozs7Ozs7Q0FVQSxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUcsV0FBVztFQUMxQixLQUFLLFVBQVUsSUFBSSxVQUFVLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxTQUFTO0VBQ25ELE9BQU87Q0FDVDs7Ozs7Ozs7O0NBU0EsT0FBTyxHQUFHLEdBQUcsUUFBUSxXQUFXO0VBQzlCLEtBQUssVUFBVSxJQUFJLE9BQU8sR0FBRyxHQUFHLE1BQU0sR0FBRyxTQUFTO0VBQ2xELE9BQU87Q0FDVDs7Ozs7Ozs7O0NBU0EsS0FBSyxRQUFRLE9BQU8sV0FBVztFQUM3QixNQUFNLFVBQVUsSUFBSSxRQUFRLE1BQU07RUFDbEMsUUFBUSxZQUFZO0VBQ3BCLEtBQUssVUFBVSxTQUFTLFNBQVM7RUFDakMsT0FBTztDQUNUOzs7Ozs7Ozs7OztDQVdBLFlBQVksR0FBRyxHQUFHLFFBQVEsT0FBTyxXQUFXLEdBQUcsV0FBVztFQUN4RCxRQUFRLEtBQUssSUFBSSxRQUFRLEdBQUcsQ0FBQztFQUM3QixNQUFNLGFBQWEsS0FBSyxLQUFLLEtBQUssSUFBSTtFQUN0QyxNQUFNLFFBQVEsS0FBSyxLQUFLLElBQUk7RUFDNUIsTUFBTSxVQUFVLENBQUM7RUFDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSztHQUM5QixNQUFNLFFBQVEsYUFBYSxJQUFJO0dBQy9CLFFBQVEsS0FDTixJQUFJLFNBQVMsS0FBSyxJQUFJLEtBQUssR0FDM0IsSUFBSSxTQUFTLEtBQUssSUFBSSxLQUFLLENBQzdCO0VBQ0Y7RUFDQSxLQUFLLEtBQUssU0FBUyxNQUFNLFNBQVM7RUFDbEMsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7O0NBYUEsVUFBVSxHQUFHLEdBQUcsUUFBUSxPQUFPLFFBQVEsV0FBVyxHQUFHLFlBQVk7RUFDL0QsUUFBUSxLQUFLLElBQUksUUFBUSxHQUFHLENBQUM7RUFDN0IsSUFBSSxVQUFVLEdBQ1osT0FBTyxLQUFLLFlBQVksR0FBRyxHQUFHLFFBQVEsT0FBTyxRQUFRO0VBRXZELE1BQU0sYUFBYSxTQUFTLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJO0VBQ3hELFNBQVMsS0FBSyxJQUFJLFFBQVEsVUFBVTtFQUNwQyxNQUFNLGFBQWEsS0FBSyxLQUFLLEtBQUssSUFBSTtFQUN0QyxNQUFNLFFBQVEsS0FBSyxLQUFLLElBQUk7RUFDNUIsTUFBTSxpQkFBaUIsUUFBUSxLQUFLLEtBQUssS0FBSyxRQUFRO0VBQ3RELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLEtBQUs7R0FDOUIsTUFBTSxRQUFRLElBQUksUUFBUTtHQUMxQixNQUFNLEtBQUssSUFBSSxTQUFTLEtBQUssSUFBSSxLQUFLO0dBQ3RDLE1BQU0sS0FBSyxJQUFJLFNBQVMsS0FBSyxJQUFJLEtBQUs7R0FDdEMsTUFBTSxLQUFLLFFBQVEsS0FBSyxLQUFLO0dBQzdCLE1BQU0sS0FBSyxRQUFRLEtBQUssS0FBSztHQUM3QixNQUFNLEtBQUssS0FBSyxTQUFTLEtBQUssSUFBSSxFQUFFO0dBQ3BDLE1BQU0sS0FBSyxLQUFLLFNBQVMsS0FBSyxJQUFJLEVBQUU7R0FDcEMsTUFBTSxLQUFLLEtBQUssU0FBUyxLQUFLLElBQUksRUFBRTtHQUNwQyxNQUFNLEtBQUssS0FBSyxTQUFTLEtBQUssSUFBSSxFQUFFO0dBQ3BDLElBQUksTUFBTSxHQUNSLEtBQUssT0FBTyxJQUFJLEVBQUU7UUFFbEIsS0FBSyxPQUFPLElBQUksRUFBRTtHQUVwQixLQUFLLGlCQUFpQixJQUFJLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDbEQ7RUFDQSxPQUFPLEtBQUssVUFBVTtDQUN4Qjs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxXQUFXLFFBQVEsUUFBUSxlQUFlLE9BQU8sWUFBWTtFQUMzRCxJQUFJLE9BQU8sU0FBUyxHQUNsQixPQUFPO0VBRVQsSUFBSSxjQUNGLDJCQUEyQixNQUFNLFFBQVEsUUFBUSxVQUFVO09BRTNELGdCQUFnQixNQUFNLFFBQVEsTUFBTTtFQUV0QyxPQUFPLEtBQUssVUFBVTtDQUN4Qjs7Ozs7Ozs7OztDQVVBLFdBQVcsR0FBRyxHQUFHLE9BQU8sUUFBUSxRQUFRO0VBQ3RDLElBQUksV0FBVyxHQUNiLE9BQU8sS0FBSyxLQUFLLEdBQUcsR0FBRyxPQUFPLE1BQU07RUFFdEMsTUFBTSxZQUFZLEtBQUssSUFBSSxPQUFPLE1BQU0sSUFBSTtFQUM1QyxNQUFNLFFBQVEsS0FBSyxJQUFJLFdBQVcsS0FBSyxJQUFJLENBQUMsV0FBVyxNQUFNLENBQUM7RUFDOUQsTUFBTSxRQUFRLElBQUk7RUFDbEIsTUFBTSxTQUFTLElBQUk7RUFDbkIsTUFBTSxNQUFNLFFBQVEsSUFBSSxDQUFDLFFBQVE7RUFDakMsTUFBTSxPQUFPLEtBQUssSUFBSSxLQUFLO0VBQzNCLE9BQU8sS0FBSyxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLENBQUMsT0FBTyxRQUFRLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLLE9BQU8sSUFBSSxNQUFNLElBQUksQ0FBQyxDQUFDLE9BQU8sT0FBTyxTQUFTLElBQUksQ0FBQyxDQUFDLE1BQU0sUUFBUSxLQUFLLFNBQVMsS0FBSyxJQUFJLFFBQVEsTUFBTSxRQUFRLElBQUksQ0FBQyxDQUFDLE9BQU8sSUFBSSxNQUFNLE1BQU0sQ0FBQyxDQUFDLE1BQU0sSUFBSSxLQUFLLFNBQVMsS0FBSyxHQUFHLFNBQVMsTUFBTSxJQUFJLENBQUMsQ0FBQyxVQUFVO0NBQzlVOzs7Ozs7Ozs7O0NBVUEsWUFBWSxHQUFHLEdBQUcsT0FBTyxRQUFRLFNBQVMsV0FBVztFQUNuRCxJQUFJLFdBQVcsR0FDYixPQUFPLEtBQUssS0FBSyxHQUFHLEdBQUcsT0FBTyxNQUFNO0VBRXRDLE1BQU0sUUFBUSxLQUFLLElBQUksU0FBUyxLQUFLLElBQUksT0FBTyxNQUFNLElBQUksQ0FBQztFQUMzRCxNQUFNLFFBQVEsSUFBSTtFQUNsQixNQUFNLFNBQVMsSUFBSTtFQUNuQixNQUFNLFNBQVM7R0FDYixJQUFJO0dBQ0o7R0FDQSxRQUFRO0dBQ1I7R0FDQTtHQUNBLElBQUk7R0FDSjtHQUNBLFNBQVM7R0FDVCxRQUFRO0dBQ1I7R0FDQSxJQUFJO0dBQ0o7R0FDQTtHQUNBLFNBQVM7R0FDVDtHQUNBLElBQUk7RUFDTjtFQUNBLEtBQUssSUFBSSxJQUFJLE9BQU8sU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQzNDLElBQUksT0FBTyxPQUFPLE9BQU8sSUFBSSxNQUFNLE9BQU8sSUFBSSxPQUFPLE9BQU8sSUFBSSxJQUM5RCxPQUFPLE9BQU8sSUFBSSxHQUFHLENBQUM7RUFHMUIsT0FBTyxLQUFLLEtBQUssUUFBUSxNQUFNLFNBQVM7Q0FDMUM7Ozs7Ozs7Ozs7O0NBV0EsUUFBUSxHQUFHLEdBQUcsU0FBUyxTQUFTLFdBQVc7RUFDekMsS0FBSyxVQUFVLElBQUksUUFBUSxHQUFHLEdBQUcsU0FBUyxPQUFPLEdBQUcsU0FBUztFQUM3RCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Q0FhQSxVQUFVLEdBQUcsR0FBRyxHQUFHLEdBQUcsUUFBUSxXQUFXO0VBQ3ZDLEtBQUssVUFBVSxJQUFJLGlCQUFpQixHQUFHLEdBQUcsR0FBRyxHQUFHLE1BQU0sR0FBRyxTQUFTO0VBQ2xFLE9BQU87Q0FDVDs7Ozs7Ozs7OztDQVVBLFVBQVUsT0FBTyxRQUFRO0VBQ3ZCLEtBQUssUUFBUTtFQUNiLEtBQUssZ0JBQWdCLEtBQUs7R0FBRTtHQUFPLFdBQVc7RUFBTyxDQUFDO0VBQ3RELE9BQU87Q0FDVDs7Ozs7Ozs7Q0FRQSxVQUFVLEdBQUcsR0FBRztFQUNkLElBQUksY0FBYyxLQUFLO0VBQ3ZCLElBQUksYUFDRixLQUFLLFFBQVE7RUFFZixjQUFjLElBQUksUUFBUTtFQUMxQixZQUFZLE9BQU8sS0FBSyxHQUFHLENBQUM7RUFDNUIsS0FBSyxlQUFlO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7O0NBU0EsUUFBUSxZQUFZLE9BQU87RUFDekIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsSUFBSSxTQUFTLE1BQU0sT0FBTyxTQUFTLEdBQUc7R0FDcEMsTUFBTSxZQUFZO0dBQ2xCLEtBQUssZ0JBQWdCLEtBQUssRUFBRSxNQUFNLENBQUM7RUFDckM7RUFDQSxLQUFLLGVBQWU7RUFDcEIsT0FBTztDQUNUO0NBQ0EsWUFBWSxRQUFRLE1BQU07RUFDeEIsSUFBSSxLQUFLLGNBQWM7RUFDdkIsS0FBSyxlQUFlLElBQUksUUFBUTtFQUNoQyxJQUFJLE9BQU87R0FDVCxNQUFNLFlBQVksS0FBSyxnQkFBZ0IsS0FBSyxnQkFBZ0IsU0FBUztHQUNyRSxJQUFJLFdBQVc7SUFDYixJQUFJLEtBQUssVUFBVSxNQUFNO0lBQ3pCLElBQUksS0FBSyxVQUFVLE1BQU07SUFDekIsSUFBSSxVQUFVLGFBQWEsQ0FBQyxVQUFVLFVBQVUsV0FBVyxHQUFHO0tBQzVELE1BQU0sSUFBSSxVQUFVO0tBQ3BCLE1BQU0sUUFBUTtLQUNkLEtBQUssRUFBRSxJQUFJLEtBQUssRUFBRSxJQUFJLEtBQUssRUFBRTtLQUM3QixLQUFLLEVBQUUsSUFBSSxRQUFRLEVBQUUsSUFBSSxLQUFLLEVBQUU7SUFDbEM7SUFDQSxLQUFLLGFBQWEsT0FBTyxLQUFLLElBQUksRUFBRTtHQUN0QyxPQUNFLEtBQUssYUFBYSxPQUFPLEtBQUssR0FBRyxDQUFDO0VBRXRDO0NBQ0Y7O0NBRUEsWUFBWTtFQUNWLE1BQU0sT0FBTyxLQUFLO0VBQ2xCLEtBQUssZ0JBQWdCLFNBQVM7RUFDOUIsS0FBSyxlQUFlO0VBQ3BCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLGFBQWEsUUFBUSxLQUFLO0dBQ2pELE1BQU0sY0FBYyxLQUFLLGFBQWE7R0FDdEMsS0FBSyxZQUFZLE9BQU8sQ0FBQyxHQUFHLFlBQVksSUFBSTtFQUM5QztFQUNBLEtBQUssT0FBTztDQUNkOztDQUVBLElBQUksU0FBUztFQUNYLE1BQU0sU0FBUyxLQUFLO0VBQ3BCLE9BQU8sTUFBTTtFQUNiLE1BQU0sa0JBQWtCLEtBQUs7RUFDN0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGdCQUFnQixRQUFRLEtBQUs7R0FDL0MsTUFBTSxpQkFBaUIsZ0JBQWdCO0dBQ3ZDLE1BQU0sYUFBYSxlQUFlLE1BQU0sVUFBVSxhQUFhO0dBQy9ELElBQUksZUFBZSxXQUNqQixPQUFPLFFBQVEsWUFBWSxlQUFlLFNBQVM7UUFFbkQsT0FBTyxRQUFRLFVBQVU7RUFFN0I7RUFDQSxPQUFPO0NBQ1Q7QUFDRjs7O0FDbGhCQSxJQUFNLGVBQU4sTUFBTSxhQUFhOzs7Ozs7Q0FNakIsWUFBWSxjQUFjLFNBQVMsT0FBTztFQUN4QyxLQUFLLGVBQWUsQ0FBQzs7RUFFckIsS0FBSyxNQUFNLElBQUksY0FBYztFQUM3QixLQUFLLFNBQVM7RUFDZCxLQUFLLGdCQUFnQjtFQUNyQixJQUFJLE9BQU8saUJBQWlCLFVBQzFCLGFBQWEsY0FBYyxJQUFJO09BRS9CLEtBQUssZUFBZSxjQUFjLE1BQU0sS0FBSyxDQUFDO0NBRWxEOzs7OztDQUtBLElBQUksWUFBWTtFQUNkLElBQUksQ0FBQyxLQUFLLFlBQ1IsS0FBSyxhQUFhLElBQUksVUFBVSxJQUFJO0VBRXRDLElBQUksS0FBSyxRQUFRO0dBQ2YsS0FBSyxTQUFTO0dBQ2QsS0FBSyxXQUFXLFVBQVU7RUFDNUI7RUFDQSxPQUFPLEtBQUs7Q0FDZDs7Ozs7OztDQU9BLFFBQVEsTUFBTSxXQUFXO0VBQ3ZCLE9BQU8sS0FBSyxNQUFNO0VBQ2xCLEtBQUssYUFBYSxLQUFLO0dBQUUsUUFBUTtHQUFXLE1BQU0sQ0FBQyxNQUFNLFNBQVM7RUFBRSxDQUFDO0VBQ3JFLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDVDtDQUNBLElBQUksR0FBRyxNQUFNO0VBQ1gsS0FBSyxhQUFhLEtBQUs7R0FBRSxRQUFRO0dBQU8sTUFBTTtFQUFLLENBQUM7RUFDcEQsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNUO0NBQ0EsTUFBTSxHQUFHLE1BQU07RUFDYixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBUyxNQUFNO0VBQUssQ0FBQztFQUN0RCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLEdBQUcsTUFBTTtFQUNoQixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBWSxNQUFNO0VBQUssQ0FBQztFQUN6RCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxjQUFjLEdBQUcsTUFBTTtFQUNyQixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBaUIsTUFBTTtFQUFLLENBQUM7RUFDOUQsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Q0FZQSxtQkFBbUIsTUFBTSxNQUFNLEdBQUcsR0FBRyxZQUFZO0VBQy9DLE1BQU0sT0FBTyxLQUFLLGFBQWEsS0FBSyxhQUFhLFNBQVM7RUFDMUQsTUFBTSxZQUFZLEtBQUssYUFBYSxNQUFNLE1BQU07RUFDaEQsSUFBSSxPQUFPO0VBQ1gsSUFBSSxPQUFPO0VBQ1gsSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLGlCQUFpQjtHQUM1QyxPQUFPLFVBQVU7R0FDakIsT0FBTyxVQUFVO0VBQ25CLE9BQU87R0FDTCxPQUFPLEtBQUssS0FBSztHQUNqQixPQUFPLEtBQUssS0FBSztHQUNqQixNQUFNLFdBQVcsVUFBVTtHQUMzQixNQUFNLFdBQVcsVUFBVTtHQUMzQixPQUFPLFlBQVksV0FBVztHQUM5QixPQUFPLFlBQVksV0FBVztFQUNoQztFQUNBLEtBQUssYUFBYSxLQUFLO0dBQUUsUUFBUTtHQUFpQixNQUFNO0lBQUM7SUFBTTtJQUFNO0lBQU07SUFBTTtJQUFHO0lBQUc7R0FBVTtFQUFFLENBQUM7RUFDcEcsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNUOzs7Ozs7Q0FNQSxZQUFZO0VBQ1YsS0FBSyxhQUFhLEtBQUs7R0FBRSxRQUFRO0dBQWEsTUFBTSxDQUFDO0VBQUUsQ0FBQztFQUN4RCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxRQUFRLEdBQUcsTUFBTTtFQUNmLEtBQUssYUFBYSxLQUFLO0dBQUUsUUFBUTtHQUFXLE1BQU07RUFBSyxDQUFDO0VBQ3hELEtBQUssU0FBUztFQUNkLE9BQU87Q0FDVDtDQUNBLE9BQU8sR0FBRyxNQUFNO0VBQ2QsS0FBSyxhQUFhLEtBQUs7R0FBRSxRQUFRO0dBQVUsTUFBTTtFQUFLLENBQUM7RUFDdkQsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNUO0NBQ0EsT0FBTyxHQUFHLE1BQU07RUFDZCxLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBVSxNQUFNO0VBQUssQ0FBQztFQUN2RCxPQUFPO0NBQ1Q7Q0FDQSxpQkFBaUIsR0FBRyxNQUFNO0VBQ3hCLEtBQUssYUFBYSxLQUFLO0dBQUUsUUFBUTtHQUFvQixNQUFNO0VBQUssQ0FBQztFQUNqRSxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Ozs7Ozs7O0NBUUEsc0JBQXNCLEdBQUcsR0FBRyxZQUFZO0VBQ3RDLE1BQU0sT0FBTyxLQUFLLGFBQWEsS0FBSyxhQUFhLFNBQVM7RUFDMUQsTUFBTSxZQUFZLEtBQUssYUFBYSxNQUFNLE1BQU07RUFDaEQsSUFBSSxPQUFPO0VBQ1gsSUFBSSxPQUFPO0VBQ1gsSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLG9CQUFvQjtHQUMvQyxPQUFPLFVBQVU7R0FDakIsT0FBTyxVQUFVO0VBQ25CLE9BQU87R0FDTCxPQUFPLEtBQUssS0FBSztHQUNqQixPQUFPLEtBQUssS0FBSztHQUNqQixNQUFNLFdBQVcsVUFBVTtHQUMzQixNQUFNLFdBQVcsVUFBVTtHQUMzQixPQUFPLFlBQVksV0FBVztHQUM5QixPQUFPLFlBQVksV0FBVztFQUNoQztFQUNBLEtBQUssYUFBYSxLQUFLO0dBQUUsUUFBUTtHQUFvQixNQUFNO0lBQUM7SUFBTTtJQUFNO0lBQUc7SUFBRztHQUFVO0VBQUUsQ0FBQztFQUMzRixLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Q0FVQSxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUcsV0FBVztFQUMxQixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBUSxNQUFNO0lBQUM7SUFBRztJQUFHO0lBQUc7SUFBRztHQUFTO0VBQUUsQ0FBQztFQUN4RSxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Ozs7Ozs7OztDQVNBLE9BQU8sR0FBRyxHQUFHLFFBQVEsV0FBVztFQUM5QixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBVSxNQUFNO0lBQUM7SUFBRztJQUFHO0lBQVE7R0FBUztFQUFFLENBQUM7RUFDNUUsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNUO0NBQ0EsVUFBVSxHQUFHLE1BQU07RUFDakIsS0FBSyxhQUFhLEtBQUs7R0FBRSxRQUFRO0dBQWEsTUFBTTtFQUFLLENBQUM7RUFDMUQsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNUO0NBQ0EsS0FBSyxHQUFHLE1BQU07RUFDWixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBUSxNQUFNO0VBQUssQ0FBQztFQUNyRCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxZQUFZLEdBQUcsTUFBTTtFQUNuQixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBZSxNQUFNO0VBQUssQ0FBQztFQUM1RCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxVQUFVLEdBQUcsTUFBTTtFQUNqQixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBYSxNQUFNO0VBQUssQ0FBQztFQUMxRCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxXQUFXLEdBQUcsTUFBTTtFQUNsQixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBYyxNQUFNO0VBQUssQ0FBQztFQUMzRCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxXQUFXLEdBQUcsTUFBTTtFQUNsQixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBYyxNQUFNO0VBQUssQ0FBQztFQUMzRCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxZQUFZLEdBQUcsTUFBTTtFQUNuQixLQUFLLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBZSxNQUFNO0VBQUssQ0FBQztFQUM1RCxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvQkEsS0FBSyxHQUFHLEdBQUcsUUFBUSxRQUFRLGFBQWEsVUFBVSxXQUFXO0VBQzNELGdCQUFnQixjQUFjLFNBQVM7RUFDdkMsTUFBTSxhQUFhLEtBQUssS0FBSyxLQUFLLElBQUk7RUFDdEMsTUFBTSxNQUFNLFNBQVM7RUFDckIsTUFBTSxRQUFRLEtBQUssS0FBSyxJQUFJO0VBQzVCLE1BQU0sVUFBVSxDQUFDO0VBQ2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7R0FDNUIsTUFBTSxJQUFJLElBQUksSUFBSSxjQUFjO0dBQ2hDLE1BQU0sUUFBUSxJQUFJLFFBQVE7R0FDMUIsUUFBUSxLQUNOLElBQUksSUFBSSxLQUFLLElBQUksS0FBSyxHQUN0QixJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssQ0FDeEI7RUFDRjtFQUNBLEtBQUssS0FBSyxTQUFTLE1BQU0sU0FBUztFQUNsQyxPQUFPO0NBQ1Q7Ozs7Ozs7OztDQVNBLE1BQU0sT0FBTyxPQUFPO0VBQ2xCLE1BQU0sb0JBQW9CLElBQUksYUFBYTtFQUMzQyxrQkFBa0IsZ0JBQWdCLEtBQUs7RUFDdkMsSUFBSSxDQUFDLE1BQ0gsa0JBQWtCLGVBQWUsS0FBSyxhQUFhLE1BQU07T0FFekQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssYUFBYSxRQUFRLEtBQUs7R0FDakQsTUFBTSxjQUFjLEtBQUssYUFBYTtHQUN0QyxrQkFBa0IsYUFBYSxLQUFLO0lBQUUsUUFBUSxZQUFZO0lBQVEsTUFBTSxZQUFZLEtBQUssTUFBTTtHQUFFLENBQUM7RUFDcEc7RUFFRixPQUFPO0NBQ1Q7Q0FDQSxRQUFRO0VBQ04sS0FBSyxhQUFhLFNBQVM7RUFDM0IsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxVQUFVLFFBQVE7RUFDaEIsSUFBSSxPQUFPLFdBQVcsR0FBRyxPQUFPO0VBQ2hDLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sS0FBSyxPQUFPO0VBQ2xCLE1BQU0sS0FBSyxPQUFPO0VBQ2xCLElBQUksSUFBSTtFQUNSLElBQUksSUFBSTtFQUNSLElBQUksT0FBTztFQUNYLElBQUksT0FBTztFQUNYLElBQUksT0FBTztFQUNYLElBQUksT0FBTztFQUNYLElBQUksS0FBSztFQUNULElBQUksS0FBSztFQUNULEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLGFBQWEsUUFBUSxLQUFLO0dBQ2pELE1BQU0sY0FBYyxLQUFLLGFBQWE7R0FDdEMsTUFBTSxPQUFPLFlBQVk7R0FDekIsUUFBUSxZQUFZLFFBQXBCO0lBQ0UsS0FBSztJQUNMLEtBQUs7S0FDSCxJQUFJLEtBQUs7S0FDVCxJQUFJLEtBQUs7S0FDVCxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtLQUMxQixLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtLQUMxQjtJQUNGLEtBQUs7S0FDSCxPQUFPLEtBQUs7S0FDWixPQUFPLEtBQUs7S0FDWixPQUFPLEtBQUs7S0FDWixPQUFPLEtBQUs7S0FDWixJQUFJLEtBQUs7S0FDVCxJQUFJLEtBQUs7S0FDVCxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUksT0FBTztLQUNoQyxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUksT0FBTztLQUNoQyxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUksT0FBTztLQUNoQyxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUksT0FBTztLQUNoQyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtLQUMxQixLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtLQUMxQjtJQUNGLEtBQUs7S0FDSCxPQUFPLEtBQUs7S0FDWixPQUFPLEtBQUs7S0FDWixJQUFJLEtBQUs7S0FDVCxJQUFJLEtBQUs7S0FDVCxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUksT0FBTztLQUNoQyxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUksT0FBTztLQUNoQyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtLQUMxQixLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSTtLQUMxQjtJQUNGLEtBQUs7S0FDSCxJQUFJLEtBQUs7S0FDVCxJQUFJLEtBQUs7S0FDVCxLQUFLLEtBQUs7S0FDVixLQUFLLEtBQUs7S0FDVixLQUFLLEtBQUssSUFBSSxLQUFLLElBQUk7S0FDdkIsS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJO0tBQ3ZCLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJO0tBQzFCLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJO0tBQzFCO0lBQ0YsS0FBSztLQUNILEtBQUssS0FBSyxnQkFBZ0IsS0FBSyxJQUFJLE1BQU07S0FDekM7SUFDRixLQUFLO0tBQ0gsS0FBSyxLQUFLLGdCQUFnQixLQUFLLElBQUksTUFBTTtLQUN6QztJQUNGLEtBQUs7S0FDSCxLQUFLLEtBQUssZ0JBQWdCLEtBQUssSUFBSSxNQUFNO0tBQ3pDO0lBQ0YsS0FBSztLQUNILEtBQUssS0FBSyxnQkFBZ0IsS0FBSyxJQUFJLE1BQU07S0FDekM7SUFDRixLQUFLO0tBQ0gsS0FBSyxFQUFFLENBQUMsVUFBVSxNQUFNO0tBQ3hCO0lBQ0YsS0FBSztLQUNILEtBQUssS0FBSyxnQkFBZ0IsS0FBSyxJQUFJLE1BQU07S0FDekM7SUFDRixLQUFLO0lBQ0wsS0FBSztLQUNILEtBQUssS0FBSyxnQkFBZ0IsS0FBSyxJQUFJLE1BQU07S0FDekM7SUFDRixLQUFLLGFBQ0g7SUFDRixTQUNFLEtBQUssNEJBQTRCLFlBQVksTUFBTTtHQUV2RDtFQUNGO0VBQ0EsS0FBSyxTQUFTO0VBQ2QsT0FBTztDQUNUO0NBQ0EsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLLFVBQVU7Q0FDeEI7Ozs7Ozs7Ozs7Ozs7OztDQWVBLGFBQWEsS0FBSztFQUNoQixJQUFJLFFBQVEsS0FBSyxhQUFhLFNBQVM7RUFDdkMsSUFBSSxrQkFBa0IsS0FBSyxhQUFhO0VBQ3hDLElBQUksQ0FBQyxpQkFBaUI7R0FDcEIsSUFBSSxJQUFJO0dBQ1IsSUFBSSxJQUFJO0dBQ1IsT0FBTztFQUNUO0VBQ0EsT0FBTyxnQkFBZ0IsV0FBVyxhQUFhO0dBQzdDO0dBQ0EsSUFBSSxRQUFRLEdBQUc7SUFDYixJQUFJLElBQUk7SUFDUixJQUFJLElBQUk7SUFDUixPQUFPO0dBQ1Q7R0FDQSxrQkFBa0IsS0FBSyxhQUFhO0VBQ3RDO0VBQ0EsUUFBUSxnQkFBZ0IsUUFBeEI7R0FDRSxLQUFLO0dBQ0wsS0FBSztJQUNILElBQUksSUFBSSxnQkFBZ0IsS0FBSztJQUM3QixJQUFJLElBQUksZ0JBQWdCLEtBQUs7SUFDN0I7R0FDRixLQUFLO0lBQ0gsSUFBSSxJQUFJLGdCQUFnQixLQUFLO0lBQzdCLElBQUksSUFBSSxnQkFBZ0IsS0FBSztJQUM3QjtHQUNGLEtBQUs7SUFDSCxJQUFJLElBQUksZ0JBQWdCLEtBQUs7SUFDN0IsSUFBSSxJQUFJLGdCQUFnQixLQUFLO0lBQzdCO0dBQ0YsS0FBSztHQUNMLEtBQUs7SUFDSCxJQUFJLElBQUksZ0JBQWdCLEtBQUs7SUFDN0IsSUFBSSxJQUFJLGdCQUFnQixLQUFLO0lBQzdCO0dBQ0YsS0FBSyxXQUNILGdCQUFnQixLQUFLLEVBQUUsQ0FBQyxhQUFhLEdBQUc7RUFFNUM7RUFDQSxPQUFPO0NBQ1Q7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLGVBQWUsV0FBVztDQUNqRCxJQUFJLGVBQ0YsT0FBTyxjQUFjLFFBQVEsU0FBUztDQUV4QyxPQUFPLFVBQVUsTUFBTTtBQUN6Qjs7O0FDcmNBLFNBQVMsdUJBQXVCLEtBQUssSUFBSSxjQUFjO0NBQ3JELE1BQU0sUUFBUSxJQUFJLGFBQWEsRUFBRTtDQUNqQyxPQUFPLFFBQVEsT0FBTyxLQUFLLElBQUk7QUFDakM7OztBQ0NBLFNBQVMsb0JBQW9CLEtBQUssU0FBUztDQUN6QyxNQUFNLGNBQWMsSUFBSSxpQkFBaUIsTUFBTTtDQUMvQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxRQUFRLEtBQUs7RUFDM0MsTUFBTSxhQUFhLFlBQVk7RUFDL0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsU0FBUyxRQUFRLEtBQUs7R0FDbkQsTUFBTSxRQUFRLFdBQVcsU0FBUztHQUNsQyxRQUFRLE1BQU0sU0FBUyxZQUFZLEdBQW5DO0lBQ0UsS0FBSztLQUNILFFBQVEsS0FBSyxNQUFNLE1BQU0sb0JBQW9CLEtBQUs7S0FDbEQ7SUFDRixLQUFLLGtCQUNILFFBQVEsS0FBSyxNQUFNLE1BQU0sb0JBQW9CLEtBQUs7R0FJdEQ7RUFDRjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLHdCQUF3QixLQUFLLElBQUksY0FBYztDQUN0RCxNQUFNLFFBQVEsSUFBSSxhQUFhLEVBQUU7Q0FDakMsSUFBSSxPQUFPLEtBQUssQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0VBQy9CLE1BQU0sYUFBYSxPQUFPLE1BQU0sS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztFQUNuRCxPQUFPLE9BQU8sTUFBTSxVQUFVLElBQUksZUFBZSxhQUFhO0NBQ2hFO0NBQ0EsT0FBTyx1QkFBdUIsS0FBSyxJQUFJLFlBQVk7QUFDckQ7QUFDQSxTQUFTLDBCQUEwQixLQUFLO0NBQ3RDLFFBQVEsSUFBSSxhQUFhLGVBQWUsS0FBSyx5QkFBeUIsc0JBQXNCLFVBQVU7QUFDeEc7QUFDQSxTQUFTLHdCQUF3QixLQUFLO0NBQ3BDLE1BQU0sYUFBYSxDQUFDO0NBQ3BCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFNBQVMsUUFBUSxLQUFLO0VBQzVDLE1BQU0sT0FBTyxJQUFJLFNBQVM7RUFDMUIsTUFBTSxTQUFTLHdCQUF3QixNQUFNLFVBQVUsQ0FBQztFQUN4RCxNQUFNLFFBQVEsTUFBTSxPQUFPLFNBQVMsS0FBSyxhQUFhLFlBQVksQ0FBQyxDQUFDLENBQUMsU0FBUztFQUM5RSxXQUFXLEtBQUs7R0FBRTtHQUFRO0VBQU0sQ0FBQztDQUNuQztDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsb0JBQW9CLE9BQU87Q0FDbEMsTUFBTSxLQUFLLHdCQUF3QixPQUFPLE1BQU0sQ0FBQztDQUNqRCxNQUFNLEtBQUssd0JBQXdCLE9BQU8sTUFBTSxDQUFDO0NBQ2pELE1BQU0sS0FBSyx3QkFBd0IsT0FBTyxNQUFNLENBQUM7Q0FDakQsTUFBTSxLQUFLLHdCQUF3QixPQUFPLE1BQU0sQ0FBQztDQUNqRCxPQUFPLElBQUksYUFBYTtFQUN0QixNQUFNO0VBQ04sT0FBTztHQUFFLEdBQUc7R0FBSSxHQUFHO0VBQUc7RUFDdEIsS0FBSztHQUFFLEdBQUc7R0FBSSxHQUFHO0VBQUc7RUFDcEIsY0FBYywwQkFBMEIsS0FBSztFQUM3QyxZQUFZLHdCQUF3QixLQUFLO0NBQzNDLENBQUM7QUFDSDtBQUNBLFNBQVMsb0JBQW9CLE9BQU87Q0FDbEMsTUFBTSxLQUFLLHdCQUF3QixPQUFPLE1BQU0sRUFBRztDQUNuRCxNQUFNLEtBQUssd0JBQXdCLE9BQU8sTUFBTSxFQUFHO0NBQ25ELE1BQU0sSUFBSSx3QkFBd0IsT0FBTyxLQUFLLEVBQUc7Q0FDakQsTUFBTSxLQUFLLHdCQUF3QixPQUFPLE1BQU0sRUFBRTtDQUNsRCxNQUFNLEtBQUssd0JBQXdCLE9BQU8sTUFBTSxFQUFFO0NBQ2xELE1BQU0sS0FBSyx3QkFBd0IsT0FBTyxNQUFNLENBQUM7Q0FDakQsT0FBTyxJQUFJLGFBQWE7RUFDdEIsTUFBTTtFQUNOLFFBQVE7R0FBRSxHQUFHO0dBQUksR0FBRztFQUFHO0VBQ3ZCLGFBQWE7RUFDYixhQUFhO0dBQUUsR0FBRztHQUFJLEdBQUc7RUFBRztFQUM1QixhQUFhO0VBQ2IsY0FBYywwQkFBMEIsS0FBSztFQUM3QyxZQUFZLHdCQUF3QixLQUFLO0NBQzNDLENBQUM7QUFDSDs7O0FDekVBLFNBQVMsZ0JBQWdCLEtBQUs7Q0FDNUIsTUFBTSxRQUFRLElBQUksTUFBTSwrQ0FBK0M7Q0FDdkUsT0FBTyxRQUFRLE1BQU0sS0FBSztBQUM1Qjs7O0FDQUEsSUFBTSxrQkFBa0I7Q0FFdEIsTUFBTTtFQUFFLE1BQU07RUFBUyxTQUFTO0NBQUU7Q0FFbEMsZ0JBQWdCO0VBQUUsTUFBTTtFQUFVLFNBQVM7Q0FBRTtDQUc3QyxRQUFRO0VBQUUsTUFBTTtFQUFTLFNBQVM7Q0FBRTtDQUVwQyxnQkFBZ0I7RUFBRSxNQUFNO0VBQVUsU0FBUztDQUFFO0NBRTdDLGtCQUFrQjtFQUFFLE1BQU07RUFBVSxTQUFTO0NBQUU7Q0FFL0Msa0JBQWtCO0VBQUUsTUFBTTtFQUFVLFNBQVM7Q0FBTztDQUVwRCxtQkFBbUI7RUFBRSxNQUFNO0VBQVUsU0FBUztDQUFRO0NBRXRELHFCQUFxQjtFQUFFLE1BQU07RUFBVSxTQUFTO0NBQUc7Q0FFbkQsb0JBQW9CO0VBQUUsTUFBTTtFQUFVLFNBQVM7Q0FBTztDQUV0RCxxQkFBcUI7RUFBRSxNQUFNO0VBQVUsU0FBUztDQUFFO0NBR2xELFNBQVM7RUFBRSxNQUFNO0VBQVUsU0FBUztDQUFFO0FBRXhDO0FBQ0EsU0FBUyxjQUFjLEtBQUssU0FBUztDQUNuQyxNQUFNLFFBQVEsSUFBSSxhQUFhLE9BQU87Q0FDdEMsTUFBTSxjQUFjLENBQUM7Q0FDckIsTUFBTSxZQUFZLENBQUM7Q0FDbkIsTUFBTSxTQUFTO0VBQ2I7RUFDQTtFQUNBLFNBQVM7RUFDVCxXQUFXO0NBQ2I7Q0FDQSxLQUFLLE1BQU0sT0FBTyxpQkFBaUI7RUFDakMsTUFBTSxZQUFZLElBQUksYUFBYSxHQUFHO0VBQ3RDLElBQUksV0FDRixlQUFlLFNBQVMsUUFBUSxLQUFLLFVBQVUsS0FBSyxDQUFDO0NBRXpEO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsTUFBTSxhQUFhLE1BQU0sTUFBTSxHQUFHO0VBQ2xDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztHQUUxQyxNQUFNLENBQUMsS0FBSyxTQURNLFdBQVcsRUFBRSxDQUFDLEtBQ0gsQ0FBQyxDQUFDLE1BQU0sR0FBRztHQUN4QyxJQUFJLGdCQUFnQixNQUNsQixlQUFlLFNBQVMsUUFBUSxLQUFLLE1BQU0sS0FBSyxDQUFDO0VBRXJEO0NBQ0Y7Q0FDQSxPQUFPO0VBQ0wsYUFBYSxPQUFPLFlBQVksY0FBYztFQUM5QyxXQUFXLE9BQU8sVUFBVSxZQUFZO0VBQ3hDLFNBQVMsT0FBTztFQUNoQixXQUFXLE9BQU87Q0FDcEI7QUFDRjtBQUNBLFNBQVMsZUFBZSxTQUFTLFFBQVEsSUFBSSxPQUFPO0NBQ2xELFFBQVEsSUFBUjtFQUNFLEtBQUs7R0FDSCxJQUFJLFVBQVUsUUFBUTtJQUNwQixJQUFJLE1BQU0sV0FBVyxNQUFNLEdBQUc7S0FDNUIsTUFBTSxNQUFNLGdCQUFnQixLQUFLO0tBQ2pDLE9BQU8sWUFBWSxPQUFPLFFBQVEsS0FBSztJQUN6QyxPQUNFLE9BQU8sWUFBWSxRQUFRLE1BQU0sT0FBTyxTQUFTLEtBQUssQ0FBQyxDQUFDLFNBQVM7SUFFbkUsT0FBTyxZQUFZO0dBQ3JCO0dBQ0E7RUFDRixLQUFLO0dBQ0gsT0FBTyxZQUFZLFFBQVEsT0FBTyxLQUFLO0dBQ3ZDO0VBQ0YsS0FBSztHQUNILElBQUksVUFBVSxRQUFRO0lBQ3BCLElBQUksTUFBTSxXQUFXLE1BQU0sR0FBRztLQUM1QixNQUFNLE1BQU0sZ0JBQWdCLEtBQUs7S0FDakMsT0FBTyxVQUFVLE9BQU8sUUFBUSxLQUFLO0lBQ3ZDLE9BQ0UsT0FBTyxVQUFVLFFBQVEsTUFBTSxPQUFPLFNBQVMsS0FBSyxDQUFDLENBQUMsU0FBUztJQUVqRSxPQUFPLFVBQVU7R0FDbkI7R0FDQTtFQUNGLEtBQUs7R0FDSCxPQUFPLFVBQVUsUUFBUSxPQUFPLEtBQUs7R0FDckM7RUFDRixLQUFLO0dBQ0gsT0FBTyxZQUFZLFFBQVEsT0FBTyxLQUFLO0dBQ3ZDO0VBQ0YsS0FBSztHQUNILE9BQU8sVUFBVSxRQUFRLE9BQU8sS0FBSztHQUNyQyxPQUFPLFlBQVksUUFBUSxPQUFPLEtBQUs7Q0FFM0M7QUFDRjs7O0FDckdBLFNBQVMsc0JBQXNCLGtCQUFrQjtDQUMvQyxJQUFJLGlCQUFpQixVQUFVLEdBQzdCLE9BQU87Q0FFVCxNQUFNLFFBQVEsaUJBQWlCLEtBQUssTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQztDQUN0RSxNQUFNLENBQUMsYUFBYSxjQUFjO0NBQ2xDLE1BQU0sZUFBZSxNQUFNLE1BQU0sU0FBUztDQUMxQyxNQUFNLHVCQUF1QixjQUFjO0NBQzNDLE1BQU0sd0JBQXdCLGFBQWE7Q0FDM0MsSUFBSSx1QkFBdUIsS0FBSyx3QkFBd0IsR0FDdEQsT0FBTztDQUVULE9BQU87QUFDVDtBQUNBLFNBQVMsdUJBQXVCLFNBQVMsUUFBUSxHQUFHO0NBQ2xELE1BQU0sY0FBYyxRQUFRLGFBQWE7Q0FDekMsSUFBSSxDQUFDLGVBQWUsWUFBWSxXQUFXLFFBQ3pDLE1BQU0sSUFBSSxNQUFNLHNDQUFzQyxNQUFNLFFBQVEsYUFBYSxVQUFVLGFBQWE7Q0FFMUcsT0FBTyxZQUFZO0FBQ3JCOzs7QUNsQkEsU0FBUyxnQkFBZ0IsVUFBVTtDQUdqQyxPQUZjLFNBQVMsTUFBTSxVQUNSLENBQUMsQ0FBQyxRQUFRLFNBQVMsS0FBSyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQy9DO0FBQ2hCO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVTtDQUNuQyxNQUFNLFNBQVMsU0FBUyxNQUFNLHVCQUF1QjtDQUNyRCxJQUFJLENBQUMsVUFBVSxPQUFPLFNBQVMsR0FBRyxPQUFPO0NBQ3pDLE1BQU0sVUFBVSxPQUFPLElBQUksTUFBTTtDQUNqQyxNQUFNLEtBQUssQ0FBQztDQUNaLE1BQU0sS0FBSyxDQUFDO0NBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLLEdBQ3ZDLElBQUksSUFBSSxJQUFJLFFBQVEsUUFBUTtFQUMxQixHQUFHLEtBQUssUUFBUSxFQUFFO0VBQ2xCLEdBQUcsS0FBSyxRQUFRLElBQUksRUFBRTtDQUN4QjtDQUVGLElBQUksR0FBRyxXQUFXLEtBQUssR0FBRyxXQUFXLEdBQUcsT0FBTztDQUMvQyxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsRUFBRTtDQUMzQixNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsRUFBRTtDQUMzQixNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsRUFBRTtDQUMzQixNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsRUFBRTtDQUUzQixRQURjLE9BQU8sU0FBUyxPQUFPO0FBRXZDO0FBQ0EsU0FBUyxjQUFjLFVBQVUsY0FBYztDQUM3QyxNQUFNLFdBQVcsSUFBSSxhQUFhLFVBQVUsS0FBSztDQUNqRCxLQUFLLE1BQU0sZUFBZSxTQUFTLGNBQ2pDLGFBQWEsYUFBYSxLQUFLLFdBQVc7QUFFOUM7OztBQ3hCQSxTQUFTLFVBQVUsS0FBSyxpQkFBaUI7Q0FDdkMsSUFBSSxPQUFPLFFBQVEsVUFBVTtFQUMzQixNQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7RUFDeEMsSUFBSSxZQUFZLElBQUksS0FBSztFQUN6QixNQUFNLElBQUksY0FBYyxLQUFLO0NBQy9CO0NBQ0EsTUFBTSxVQUFVO0VBQ2QsU0FBUztFQUNULE1BQU0sQ0FBQztFQUNQLE1BQU0sSUFBSSxhQUFhO0NBQ3pCO0NBQ0Esb0JBQW9CLEtBQUssT0FBTztDQUNoQyxNQUFNLFdBQVcsSUFBSTtDQUNyQixNQUFNLEVBQUUsV0FBVyxnQkFBZ0IsY0FBYyxLQUFLLE9BQU87Q0FDN0QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0VBQ3hDLE1BQU0sUUFBUSxTQUFTO0VBQ3ZCLElBQUksTUFBTSxTQUFTLFlBQVksTUFBTSxRQUFRO0VBQzdDLGVBQWUsT0FBTyxTQUFTLFdBQVcsV0FBVztDQUN2RDtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxLQUFLLFNBQVMsV0FBVyxhQUFhO0NBQzVELE1BQU0sV0FBVyxJQUFJO0NBQ3JCLE1BQU0sRUFBRSxXQUFXLElBQUksYUFBYSxPQUFPLGNBQWMsS0FBSyxPQUFPO0NBQ3JFLElBQUksTUFBTSxXQUNSLFlBQVk7RUFBRSxHQUFHO0VBQVcsR0FBRztDQUFHO01BQzdCLElBQUksSUFDVCxZQUFZO0NBRWQsSUFBSSxNQUFNLGFBQ1IsY0FBYztFQUFFLEdBQUc7RUFBYSxHQUFHO0NBQUc7TUFDakMsSUFBSSxJQUNULGNBQWM7Q0FFaEIsTUFBTSxVQUFVLENBQUMsYUFBYSxDQUFDO0NBQy9CLElBQUksU0FDRixZQUFZLEVBQUUsT0FBTyxFQUFFO0NBRXpCLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osUUFBUSxJQUFJLFNBQVMsWUFBWSxHQUFqQztFQUNFLEtBQUssUUFBUTtHQUNYLElBQUksSUFBSSxhQUFhLEdBQUc7R0FDeEIsTUFBTSxXQUFXLElBQUksYUFBYSxXQUFXO0dBQzdDLE1BQU0sV0FBVyxnQkFBZ0IsQ0FBQztHQUNsQyxNQUFNLHFCQUFxQixhQUFhO0dBQ3hDLE1BQU0sc0JBQXNCLFNBQVMsU0FBUztHQUU5QyxJQUQyQixzQkFBc0IscUJBQ3pCO0lBQ3RCLE1BQU0sbUJBQW1CLFNBQVMsS0FBSyxhQUFhO0tBQ2xELE1BQU07S0FDTixNQUFNLGtCQUFrQixPQUFPO0lBQ2pDLEVBQUU7SUFDRixpQkFBaUIsTUFBTSxHQUFHLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSTtJQUUvQyxJQURpQyxTQUFTLFNBQVMsS0FBSyxDQUFDLHNCQUFzQixnQkFBZ0IsR0FFN0YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGlCQUFpQixRQUFRLEtBQUs7S0FDaEQsTUFBTSxVQUFVLGlCQUFpQjtLQUNqQyxNQUFNLGNBQWMsTUFBTTtLQUMxQixRQUFRLFFBQVEsVUFBVTtLQUMxQixNQUFNLFVBQVUsSUFBSSxhQUFhLEtBQUssR0FBRyxJQUFJO0tBQzdDLGNBQWMsUUFBUSxNQUFNLE9BQU87S0FDbkMsUUFBUSxRQUFRLEtBQUssT0FBTztLQUM1QixJQUFJLGFBQWE7TUFDZixJQUFJLFdBQVcsUUFBUSxRQUFRLEtBQUssU0FBUztNQUM3QyxJQUFJLGFBQWEsUUFBUSxRQUFRLE9BQU8sV0FBVztLQUNyRCxPQUNFLFFBQVEsUUFBUSxJQUFJO0lBRXhCO1NBRUEsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGlCQUFpQixRQUFRLEtBQUs7S0FDaEQsTUFBTSxVQUFVLGlCQUFpQjtLQUNqQyxNQUFNLFNBQVMsSUFBSSxNQUFNO0tBQ3pCLFFBQVEsUUFBUSxVQUFVO0tBQzFCLE1BQU0sVUFBVSxJQUFJLGFBQWEsS0FBSyxHQUFHLElBQUk7S0FDN0MsY0FBYyxRQUFRLE1BQU0sT0FBTztLQUNuQyxRQUFRLFFBQVEsS0FBSyxPQUFPO0tBQzVCLElBQUksUUFDRixRQUFRLFFBQVEsSUFBSTtVQUNmO01BQ0wsSUFBSSxXQUFXLFFBQVEsUUFBUSxLQUFLLFNBQVM7TUFDN0MsSUFBSSxhQUFhLFFBQVEsUUFBUSxPQUFPLFdBQVc7S0FDckQ7SUFDRjtHQUVKLE9BQU87SUFFTCxlQUFlLElBQUksYUFBYSxHQURFLFdBQVcsYUFBYSxZQUFZLElBQ1Y7SUFDNUQsUUFBUSxRQUFRLEtBQUssWUFBWTtJQUNqQyxJQUFJLFdBQVcsUUFBUSxRQUFRLEtBQUssU0FBUztJQUM3QyxJQUFJLGFBQWEsUUFBUSxRQUFRLE9BQU8sV0FBVztHQUNyRDtHQUNBO0VBQ0Y7RUFDQSxLQUFLO0dBQ0gsS0FBSyx1QkFBdUIsS0FBSyxNQUFNLENBQUM7R0FDeEMsS0FBSyx1QkFBdUIsS0FBSyxNQUFNLENBQUM7R0FDeEMsSUFBSSx1QkFBdUIsS0FBSyxLQUFLLENBQUM7R0FDdEMsUUFBUSxRQUFRLFFBQVEsSUFBSSxJQUFJLEdBQUcsQ0FBQztHQUNwQyxJQUFJLFdBQVcsUUFBUSxRQUFRLEtBQUssU0FBUztHQUM3QyxJQUFJLGFBQWEsUUFBUSxRQUFRLE9BQU8sV0FBVztHQUNuRDtFQUNGLEtBQUs7R0FDSCxJQUFJLHVCQUF1QixLQUFLLEtBQUssQ0FBQztHQUN0QyxJQUFJLHVCQUF1QixLQUFLLEtBQUssQ0FBQztHQUN0QyxRQUFRLHVCQUF1QixLQUFLLFNBQVMsQ0FBQztHQUM5QyxTQUFTLHVCQUF1QixLQUFLLFVBQVUsQ0FBQztHQUNoRCxLQUFLLHVCQUF1QixLQUFLLE1BQU0sQ0FBQztHQUN4QyxLQUFLLHVCQUF1QixLQUFLLE1BQU0sQ0FBQztHQUN4QyxJQUFJLE1BQU0sSUFDUixRQUFRLFFBQVEsVUFBVSxHQUFHLEdBQUcsT0FBTyxRQUFRLE1BQU0sRUFBRTtRQUV2RCxRQUFRLFFBQVEsS0FBSyxHQUFHLEdBQUcsT0FBTyxNQUFNO0dBRTFDLElBQUksV0FBVyxRQUFRLFFBQVEsS0FBSyxTQUFTO0dBQzdDLElBQUksYUFBYSxRQUFRLFFBQVEsT0FBTyxXQUFXO0dBQ25EO0VBQ0YsS0FBSztHQUNILEtBQUssdUJBQXVCLEtBQUssTUFBTSxDQUFDO0dBQ3hDLEtBQUssdUJBQXVCLEtBQUssTUFBTSxDQUFDO0dBQ3hDLEtBQUssdUJBQXVCLEtBQUssTUFBTSxDQUFDO0dBQ3hDLEtBQUssdUJBQXVCLEtBQUssTUFBTSxDQUFDO0dBQ3hDLFFBQVEsUUFBUSxVQUFVO0dBQzFCLFFBQVEsUUFBUSxRQUFRLElBQUksSUFBSSxJQUFJLEVBQUU7R0FDdEMsSUFBSSxXQUFXLFFBQVEsUUFBUSxLQUFLLFNBQVM7R0FDN0MsSUFBSSxhQUFhLFFBQVEsUUFBUSxPQUFPLFdBQVc7R0FDbkQ7RUFDRixLQUFLO0dBQ0gsS0FBSyx1QkFBdUIsS0FBSyxNQUFNLENBQUM7R0FDeEMsS0FBSyx1QkFBdUIsS0FBSyxNQUFNLENBQUM7R0FDeEMsS0FBSyx1QkFBdUIsS0FBSyxNQUFNLENBQUM7R0FDeEMsS0FBSyx1QkFBdUIsS0FBSyxNQUFNLENBQUM7R0FDeEMsUUFBUSxRQUFRLFVBQVU7R0FDMUIsUUFBUSxRQUFRLE9BQU8sSUFBSSxFQUFFO0dBQzdCLFFBQVEsUUFBUSxPQUFPLElBQUksRUFBRTtHQUM3QixJQUFJLGFBQWEsUUFBUSxRQUFRLE9BQU8sV0FBVztHQUNuRDtFQUNGLEtBQUs7R0FDSCxlQUFlLElBQUksYUFBYSxRQUFRO0dBQ3hDLFNBQVMsYUFBYSxNQUFNLFFBQVEsQ0FBQyxDQUFDLEtBQUssTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDO0dBQ2hFLFFBQVEsUUFBUSxLQUFLLFFBQVEsSUFBSTtHQUNqQyxJQUFJLFdBQVcsUUFBUSxRQUFRLEtBQUssU0FBUztHQUM3QyxJQUFJLGFBQWEsUUFBUSxRQUFRLE9BQU8sV0FBVztHQUNuRDtFQUNGLEtBQUs7R0FDSCxlQUFlLElBQUksYUFBYSxRQUFRO0dBQ3hDLFNBQVMsYUFBYSxNQUFNLFFBQVEsQ0FBQyxDQUFDLEtBQUssTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDO0dBQ2hFLFFBQVEsUUFBUSxLQUFLLFFBQVEsS0FBSztHQUNsQyxJQUFJLGFBQWEsUUFBUSxRQUFRLE9BQU8sV0FBVztHQUNuRDtFQUVGLEtBQUs7RUFDTCxLQUFLLE9BQ0g7RUFDRixTQUNFLEtBQUssaUJBQWlCLElBQUksU0FBUyx1QkFBdUI7Q0FHOUQ7Q0FDQSxJQUFJLFNBQ0YsWUFBWTtDQUVkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FDbkMsZUFBZSxTQUFTLElBQUksU0FBUyxXQUFXLFdBQVc7QUFFL0Q7OztBQzFMQSxTQUFTLHFCQUFxQixPQUFPO0NBQ25DLE9BQU8sTUFBTSxZQUFZLEtBQUs7QUFDaEM7QUFDQSxJQUFNLGdCQUFnQjtDQUNwQixRQUFRO0VBQ04sY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxZQUFZO0VBQ1YsY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxZQUFZO0VBQ1YsY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxhQUFhO0VBQ1gsY0FBYztFQUNkLGNBQWM7Q0FDaEI7QUFDRjtBQUNBLElBQU0sY0FBTixNQUFrQjtDQUNoQixZQUFZLGtCQUFrQixZQUFZOzs7OztFQUt4QyxLQUFLLE1BQU0sSUFBSSxhQUFhOzs7Ozs7RUFNNUIsS0FBSyxRQUFROztFQUViLEtBQUssWUFBWSxJQUFJLE9BQU87RUFDNUIsTUFBTSxVQUFVLHFCQUFxQixnQkFBZ0IsSUFBSSxtQkFBbUI7R0FBRSxTQUFTO0dBQWtCO0VBQVc7RUFDcEgsS0FBSyxVQUFVLFFBQVE7RUFDdkIsS0FBSyxlQUFlLFFBQVEsZ0JBQWdCO0VBQzVDLE1BQU0sTUFBTSxRQUFRO0VBQ3BCLElBQUksS0FBSztHQUNQLEtBQUssUUFBUSxPQUFPLE1BQU0sZUFBZSxjQUFjLElBQUksQ0FBQztHQUM1RCxLQUFLLFFBQVEsT0FBTyxNQUFNLGVBQWUsY0FBYyxJQUFJLENBQUM7RUFDOUQ7Q0FDRjs7Ozs7O0NBTUEsYUFBYSxXQUFXO0VBQ3RCLElBQUksV0FBVztHQUNiLElBQUksS0FBSyxVQUFVLE9BQU8sU0FBUyxHQUFHO0dBQ3RDLEtBQUssVUFBVSxTQUFTLFNBQVM7RUFDbkMsT0FBTztHQUNMLElBQUksS0FBSyxVQUFVLFdBQVcsR0FBRztHQUNqQyxLQUFLLFVBQVUsU0FBUztFQUMxQjtFQUNBLEtBQUs7Q0FDUDs7Q0FFQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksUUFBUSxPQUFPO0VBQ2pCLElBQUksS0FBSyxhQUFhLE9BQU87RUFDN0IsS0FBSyxXQUFXO0VBQ2hCLEtBQUs7Q0FDUDs7Ozs7O0NBTUEsSUFBSSxXQUFXO0VBQ2IsT0FBTyxnQkFBZ0IsS0FBSyxJQUFJLEdBQUcsS0FBSztDQUMxQzs7Q0FFQSxVQUFVO0VBQ1IsS0FBSyxRQUFRLFFBQVEsSUFBSTtFQUN6QixLQUFLLFVBQVU7Q0FDakI7QUFDRjs7O0FDaEZBLFNBQVMsWUFBWSxPQUFPO0NBQzFCLE9BQU8sTUFBTSxZQUFZLEtBQUs7QUFDaEM7QUFDQSxTQUFTLGNBQWMsT0FBTztDQUM1QixPQUFPLGlCQUFpQjtBQUMxQjtBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLE9BQU8saUJBQWlCO0FBQzFCO0FBQ0EsU0FBUyxVQUFVLE9BQU87Q0FDeEIsT0FBTyxpQkFBaUI7QUFDMUI7QUFDQSxTQUFTLGdCQUFnQixNQUFNLE9BQU8sY0FBYztDQUNsRCxNQUFNLE9BQU8sTUFBTSxPQUFPLFNBQVMsU0FBUyxDQUFDO0NBQzdDLEtBQUssUUFBUSxLQUFLLFNBQVM7Q0FDM0IsS0FBSyxRQUFRLEtBQUssVUFBVSxJQUFJLGFBQWEsUUFBUSxLQUFLO0NBQzFELEtBQUssVUFBVSxRQUFRO0NBQ3ZCLE9BQU87RUFBRSxHQUFHO0VBQWMsR0FBRztDQUFLO0FBQ3BDO0FBQ0EsU0FBUyxjQUFjLE1BQU0sT0FBTyxjQUFjO0NBQ2hELEtBQUssVUFBVTtDQUNmLE9BQU87RUFBRSxHQUFHO0VBQWMsR0FBRztDQUFLO0FBQ3BDO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTSxPQUFPLGNBQWM7Q0FDcEQsS0FBSyxPQUFPO0NBQ1osS0FBSyxRQUFRO0NBQ2IsS0FBSyxVQUFVLE1BQU07Q0FDckIsS0FBSyxTQUFTLE1BQU07Q0FDcEIsS0FBSyxlQUFlLE1BQU07Q0FDMUIsT0FBTztFQUFFLEdBQUc7RUFBYyxHQUFHO0NBQUs7QUFDcEM7QUFDQSxTQUFTLG1CQUFtQixNQUFNLE9BQU8sY0FBYztDQUNyRCxNQUFNLGNBQWM7Q0FDcEIsS0FBSyxPQUFPO0NBQ1osS0FBSyxRQUFRO0NBQ2IsS0FBSyxVQUFVLE1BQU07Q0FDckIsS0FBSyxTQUFTLE1BQU07Q0FDcEIsS0FBSyxlQUFlLE1BQU07Q0FDMUIsT0FBTztFQUFFLEdBQUc7RUFBYyxHQUFHO0NBQUs7QUFDcEM7QUFDQSxTQUFTLGlCQUFpQixPQUFPLGNBQWM7Q0FDN0MsTUFBTSxRQUFRO0VBQUUsR0FBRztFQUFjLEdBQUc7Q0FBTTtDQUMxQyxNQUFNLFFBQVEsTUFBTSxPQUFPLFNBQVMsTUFBTSxLQUFLO0NBQy9DLE1BQU0sU0FBUyxNQUFNO0NBQ3JCLE1BQU0sUUFBUSxNQUFNLFNBQVM7Q0FDN0IsT0FBTztBQUNUO0FBQ0EsU0FBUyxZQUFZLE9BQU8sY0FBYztDQUN4QyxJQUFJLFVBQVUsS0FBSyxLQUFLLFVBQVUsTUFDaEMsT0FBTztDQUVULE1BQU0sT0FBTyxDQUFDO0NBQ2QsTUFBTSxjQUFjO0NBQ3BCLElBQUksWUFBWSxLQUFLLEdBQ25CLE9BQU8sZ0JBQWdCLE1BQU0sT0FBTyxZQUFZO01BQzNDLElBQUksVUFBVSxLQUFLLEdBQ3hCLE9BQU8sY0FBYyxNQUFNLE9BQU8sWUFBWTtNQUN6QyxJQUFJLGNBQWMsS0FBSyxHQUM1QixPQUFPLGtCQUFrQixNQUFNLE9BQU8sWUFBWTtNQUM3QyxJQUFJLGVBQWUsS0FBSyxHQUM3QixPQUFPLG1CQUFtQixNQUFNLE9BQU8sWUFBWTtNQUM5QyxJQUFJLFlBQVksUUFBUSxjQUFjLFlBQVksSUFBSSxHQUMzRCxPQUFPLGtCQUFrQixhQUFhLFlBQVksTUFBTSxZQUFZO01BQy9ELElBQUksWUFBWSxRQUFRLGVBQWUsWUFBWSxJQUFJLEdBQzVELE9BQU8sbUJBQW1CLGFBQWEsWUFBWSxNQUFNLFlBQVk7Q0FFdkUsT0FBTyxpQkFBaUIsYUFBYSxZQUFZO0FBQ25EO0FBQ0EsU0FBUyxjQUFjLE9BQU8sY0FBYztDQUMxQyxNQUFNLEVBQUUsT0FBTyxXQUFXLFlBQVksS0FBSyxNQUFNLFdBQVcsR0FBRyxTQUFTO0NBQ3hFLE1BQU0sT0FBTyxZQUFZLE9BQU8sSUFBSTtDQUNwQyxJQUFJLENBQUMsTUFDSCxPQUFPO0NBRVQsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLEdBQUc7Q0FDTDtBQUNGOzs7QUN4RkEsU0FBUyxpQkFBaUIsTUFBTSxZQUFZO0NBQzFDLElBQUksV0FBVztDQUNmLE1BQU0sa0JBQWtCLEtBQUssVUFBVTtDQUN2QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksZ0JBQWdCLFFBQVEsS0FBSztFQUMvQyxNQUFNLFFBQVEsZ0JBQWdCLEVBQUUsQ0FBQztFQUNqQyxJQUFJLE1BQU0sU0FBUyxXQUFXO0VBQzlCLE1BQU0sU0FBUyxNQUFNO0VBQ3JCLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLElBQUksSUFBSSxHQUFHO0VBQ1gsTUFBTSxTQUFTLE1BQU07RUFDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHO0dBQzdCLElBQUksQ0FBQyxXQUFXLE1BQU0sS0FBSyxNQUFNLElBQUksSUFBSTtHQUN6QyxNQUFNLFdBQVcsSUFBSSxJQUFJLEtBQUs7R0FDOUIsTUFBTSxXQUFXLElBQUksS0FBSztHQUMxQixNQUFNLEtBQUssT0FBTztHQUNsQixNQUFNLEtBQUssT0FBTyxVQUFVO0dBQzVCLE1BQU0sS0FBSyxPQUFPO0dBQ2xCLE1BQU0sS0FBSyxPQUFPLElBQUk7R0FDdEIsTUFBTSxLQUFLLE9BQU87R0FDbEIsTUFBTSxLQUFLLE9BQU8sVUFBVTtHQUM1QixNQUFNLE1BQU0sS0FBSztHQUNqQixNQUFNLE1BQU0sS0FBSztHQUNqQixNQUFNLE1BQU0sS0FBSztHQUNqQixNQUFNLE1BQU0sS0FBSztHQUNqQixNQUFNLFNBQVMsTUFBTSxNQUFNLE1BQU07R0FDakMsTUFBTSxTQUFTLE1BQU0sTUFBTSxNQUFNO0dBQ2pDLElBQUksU0FBUyxTQUFTLFNBQVMsT0FBTztHQUd0QyxJQUFJLGNBRlEsTUFBTSxNQUFNLE1BQU0sT0FDUCxLQUFLLEtBQUssU0FBUyxNQUFNO0dBRWhELElBQUksYUFBYSxJQUFJLGFBQWE7UUFDN0IsSUFBSSxhQUFhLEdBQUcsYUFBYTtHQUN0QyxNQUFNLGVBQWUsS0FBSyxNQUFNLElBQUksY0FBYyxFQUFHO0dBQ3JELElBQUksZUFBZSxNQUFNO0dBQ3pCLE1BQU0sYUFBYSxLQUFLLElBQUksSUFBSSxjQUFjLFVBQVU7R0FDeEQsSUFBSSxhQUFhLFVBQVUsV0FBVztFQUN4QztDQUNGO0NBQ0EsT0FBTztBQUNUOzs7QUMxQkEsSUFBTSxXQUFXLElBQUksTUFBTTtBQUMzQixJQUFNLGFBQWEsSUFBSSxPQUFPO0FBQzlCLElBQU0sbUJBQW1CLE1BQU0seUJBQXlCSSxzQkFBYTtDQUNuRSxjQUFjO0VBQ1osTUFBTSxHQUFHLFNBQVM7O0VBRWxCLEtBQUssV0FBMkIsdUJBQU8sT0FBTyxJQUFJOztFQUVsRCxLQUFLLHFCQUFxQjs7RUFFMUIsS0FBSyxjQUFjOzs7OztFQUtuQixLQUFLLE1BQU0sSUFBSSxpQkFBaUI7Ozs7O0VBS2hDLEtBQUssUUFBUTs7RUFFYixLQUFLLFlBQVk7O0VBRWpCLEtBQUssZUFBZSxDQUFDOztFQUVyQixLQUFLLFlBQVk7RUFDakIsS0FBSyxjQUFjLElBQUksYUFBYTtFQUNwQyxLQUFLLGFBQWEsSUFBSSxPQUFPO0VBQzdCLEtBQUssYUFBYSxFQUFFLEdBQUcsaUJBQWlCLGlCQUFpQjtFQUN6RCxLQUFLLGVBQWUsRUFBRSxHQUFHLGlCQUFpQixtQkFBbUI7RUFDN0QsS0FBSyxjQUFjLENBQUM7RUFDcEIsS0FBSyxRQUFRO0VBQ2IsS0FBSyxVQUFVLElBQUksT0FBTztFQUMxQixLQUFLLGVBQWU7Q0FDdEI7Ozs7OztDQU1BLFFBQVE7RUFDTixNQUFNLFFBQVEsSUFBSSxpQkFBaUI7RUFDbkMsTUFBTSxZQUFZLEtBQUs7RUFDdkIsTUFBTSxlQUFlLEtBQUssYUFBYSxNQUFNO0VBQzdDLE1BQU0sY0FBYyxLQUFLLFlBQVksTUFBTTtFQUMzQyxNQUFNLGFBQWEsS0FBSyxXQUFXLE1BQU07RUFDekMsTUFBTSxhQUFhLEVBQUUsR0FBRyxLQUFLLFdBQVc7RUFDeEMsTUFBTSxlQUFlLEVBQUUsR0FBRyxLQUFLLGFBQWE7RUFDNUMsTUFBTSxjQUFjLEtBQUssWUFBWSxNQUFNO0VBQzNDLE1BQU0sVUFBVSxLQUFLLFFBQVEsTUFBTTtFQUNuQyxNQUFNLGVBQWU7RUFDckIsT0FBTztDQUNUOzs7O0NBSUEsSUFBSSxZQUFZO0VBQ2QsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFVBQVUsT0FBTztFQUNuQixLQUFLLGFBQWEsWUFBWSxPQUFPLGlCQUFpQixnQkFBZ0I7Q0FDeEU7Ozs7Q0FJQSxJQUFJLGNBQWM7RUFDaEIsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFlBQVksT0FBTztFQUNyQixLQUFLLGVBQWUsY0FBYyxPQUFPLGlCQUFpQixrQkFBa0I7Q0FDOUU7Ozs7Ozs7O0NBUUEsYUFBYSxPQUFPO0VBQ2xCLEtBQUssYUFBYSxZQUFZLE9BQU8saUJBQWlCLGdCQUFnQjtFQUN0RSxPQUFPO0NBQ1Q7Ozs7Ozs7O0NBUUEsZUFBZSxPQUFPO0VBQ3BCLEtBQUssZUFBZSxZQUFZLE9BQU8saUJBQWlCLGtCQUFrQjtFQUMxRSxPQUFPO0NBQ1Q7Q0FDQSxRQUFRLFNBQVMsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJO0VBQ3JDLEtBQUssYUFBYSxLQUFLO0dBQ3JCLFFBQVE7R0FDUixNQUFNO0lBQ0osT0FBTztJQUNQLElBQUksTUFBTTtJQUNWLElBQUksTUFBTTtJQUNWLElBQUksTUFBTSxRQUFRLE1BQU07SUFDeEIsSUFBSSxNQUFNLFFBQVEsTUFBTTtJQUN4QixXQUFXLEtBQUssV0FBVyxNQUFNO0lBQ2pDLE9BQU8sS0FBSyxXQUFXO0lBQ3ZCLE9BQU8sUUFBUSxTQUFTLElBQUksTUFBTSxPQUFPLFNBQVMsSUFBSSxDQUFDLENBQUMsU0FBUyxJQUFJO0dBQ3ZFO0VBQ0YsQ0FBQztFQUNELEtBQUssU0FBUztFQUNkLE9BQU87Q0FDVDs7Ozs7O0NBTUEsWUFBWTtFQUNWLEtBQUssY0FBYyxJQUFJLGFBQWE7RUFDcEMsT0FBTztDQUNUO0NBQ0EsS0FBSyxPQUFPLE9BQU87RUFDakIsSUFBSTtFQUNKLE1BQU0sa0JBQWtCLEtBQUssYUFBYSxLQUFLLGFBQWEsU0FBUztFQUNyRSxJQUFJLEtBQUssVUFBVSxLQUFLLGlCQUFpQixXQUFXLFVBQ2xELE9BQU8sZ0JBQWdCLEtBQUs7T0FFNUIsT0FBTyxLQUFLLFlBQVksTUFBTTtFQUVoQyxJQUFJLENBQUMsTUFBTSxPQUFPO0VBQ2xCLElBQUksU0FBUyxNQUFNO0dBQ2pCLElBQUksVUFBVSxLQUFLLEtBQUssT0FBTyxVQUFVLFVBQVU7SUFDakQsWUFBWSxRQUFRLHNHQUFzRztJQUMxSCxRQUFRO0tBQUUsT0FBTztLQUFPO0lBQU07R0FDaEM7R0FDQSxLQUFLLGFBQWEsWUFBWSxPQUFPLGlCQUFpQixnQkFBZ0I7RUFDeEU7RUFDQSxLQUFLLGFBQWEsS0FBSztHQUNyQixRQUFRO0dBRVIsTUFBTTtJQUFFLE9BQU8sS0FBSztJQUFXO0dBQUs7RUFDdEMsQ0FBQztFQUNELEtBQUssU0FBUztFQUNkLEtBQUssc0JBQXNCO0VBQzNCLEtBQUssUUFBUTtFQUNiLE9BQU87Q0FDVDtDQUNBLHdCQUF3QjtFQUN0QixNQUFNLEVBQUUsR0FBRyxNQUFNLEtBQUssWUFBWSxhQUFhLE1BQU0sTUFBTTtFQUMzRCxLQUFLLFlBQVksTUFBTTtFQUN2QixLQUFLLFlBQVksT0FBTyxHQUFHLENBQUM7Q0FDOUI7Ozs7Ozs7Q0FPQSxPQUFPLE9BQU87RUFDWixJQUFJO0VBQ0osTUFBTSxrQkFBa0IsS0FBSyxhQUFhLEtBQUssYUFBYSxTQUFTO0VBQ3JFLElBQUksS0FBSyxVQUFVLEtBQUssaUJBQWlCLFdBQVcsUUFDbEQsT0FBTyxnQkFBZ0IsS0FBSztPQUU1QixPQUFPLEtBQUssWUFBWSxNQUFNO0VBRWhDLElBQUksQ0FBQyxNQUFNLE9BQU87RUFDbEIsSUFBSSxTQUFTLE1BQ1gsS0FBSyxlQUFlLGNBQWMsT0FBTyxpQkFBaUIsa0JBQWtCO0VBRTlFLEtBQUssYUFBYSxLQUFLO0dBQ3JCLFFBQVE7R0FFUixNQUFNO0lBQUUsT0FBTyxLQUFLO0lBQWE7R0FBSztFQUN4QyxDQUFDO0VBQ0QsS0FBSyxTQUFTO0VBQ2QsS0FBSyxzQkFBc0I7RUFDM0IsS0FBSyxRQUFRO0VBQ2IsT0FBTztDQUNUOzs7Ozs7O0NBT0EsTUFBTTtFQUNKLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7R0FDMUIsTUFBTSxrQkFBa0IsS0FBSyxhQUFhLEtBQUssYUFBYSxTQUFTLElBQUk7R0FDekUsTUFBTSxXQUFXLEtBQUssWUFBWSxNQUFNO0dBQ3hDLElBQUksaUJBQ0U7UUFBQSxnQkFBZ0IsV0FBVyxZQUFZLGdCQUFnQixXQUFXLFFBQVE7S0FDNUUsSUFBSSxnQkFBZ0IsS0FBSyxNQUN2QixnQkFBZ0IsS0FBSyxLQUFLLFFBQVEsUUFBUTtVQUNyQztNQUNMLGdCQUFnQixLQUFLLE9BQU87TUFDNUI7S0FDRjtJQUNGOztFQUVKO0VBQ0EsS0FBSyxzQkFBc0I7RUFDM0IsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Q0FZQSxJQUFJLEdBQUcsR0FBRyxRQUFRLFlBQVksVUFBVSxrQkFBa0I7RUFDeEQsS0FBSztFQUNMLE1BQU0sSUFBSSxLQUFLO0VBQ2YsS0FBSyxZQUFZLElBQ2YsRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUN0QixFQUFFLElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLElBQ3RCLFFBQ0EsWUFDQSxVQUNBLGdCQUNGO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Ozs7OztDQVdBLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRO0VBQzVCLEtBQUs7RUFDTCxNQUFNLElBQUksS0FBSztFQUNmLEtBQUssWUFBWSxNQUNmLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFDeEIsRUFBRSxJQUFJLEtBQUssRUFBRSxJQUFJLEtBQUssRUFBRSxJQUN4QixFQUFFLElBQUksS0FBSyxFQUFFLElBQUksS0FBSyxFQUFFLElBQ3hCLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFDeEIsTUFDRjtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7OztDQWFBLFNBQVMsSUFBSSxJQUFJLGVBQWUsY0FBYyxXQUFXLEdBQUcsR0FBRztFQUM3RCxLQUFLO0VBQ0wsTUFBTSxJQUFJLEtBQUs7RUFDZixLQUFLLFlBQVksU0FDZixJQUNBLElBQ0EsZUFFQSxjQUNBLFdBQ0EsRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUN0QixFQUFFLElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLEVBQ3hCO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7OztDQWNBLGNBQWMsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLEdBQUcsWUFBWTtFQUN0RCxLQUFLO0VBQ0wsTUFBTSxJQUFJLEtBQUs7RUFDZixLQUFLLFlBQVksY0FDZixFQUFFLElBQUksT0FBTyxFQUFFLElBQUksT0FBTyxFQUFFLElBQzVCLEVBQUUsSUFBSSxPQUFPLEVBQUUsSUFBSSxPQUFPLEVBQUUsSUFDNUIsRUFBRSxJQUFJLE9BQU8sRUFBRSxJQUFJLE9BQU8sRUFBRSxJQUM1QixFQUFFLElBQUksT0FBTyxFQUFFLElBQUksT0FBTyxFQUFFLElBQzVCLEVBQUUsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsSUFDdEIsRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUN0QixVQUNGO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Q0FNQSxZQUFZO0VBQ1YsS0FBSztFQUNMLEtBQUssYUFBYSxVQUFVO0VBQzVCLE9BQU87Q0FDVDs7Ozs7Ozs7OztDQVVBLFFBQVEsR0FBRyxHQUFHLFNBQVMsU0FBUztFQUM5QixLQUFLO0VBQ0wsS0FBSyxZQUFZLFFBQVEsR0FBRyxHQUFHLFNBQVMsU0FBUyxLQUFLLFdBQVcsTUFBTSxDQUFDO0VBQ3hFLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FRQSxPQUFPLEdBQUcsR0FBRyxRQUFRO0VBQ25CLEtBQUs7RUFDTCxLQUFLLFlBQVksT0FBTyxHQUFHLEdBQUcsUUFBUSxLQUFLLFdBQVcsTUFBTSxDQUFDO0VBQzdELE9BQU87Q0FDVDs7Ozs7O0NBTUEsS0FBSyxNQUFNO0VBQ1QsS0FBSztFQUNMLEtBQUssWUFBWSxRQUFRLE1BQU0sS0FBSyxXQUFXLE1BQU0sQ0FBQztFQUN0RCxPQUFPO0NBQ1Q7Ozs7Ozs7Q0FPQSxPQUFPLEdBQUcsR0FBRztFQUNYLEtBQUs7RUFDTCxNQUFNLElBQUksS0FBSztFQUNmLEtBQUssWUFBWSxPQUNmLEVBQUUsSUFBSSxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsSUFDdEIsRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxFQUN4QjtFQUNBLE9BQU87Q0FDVDs7Ozs7OztDQU9BLE9BQU8sR0FBRyxHQUFHO0VBQ1gsS0FBSztFQUNMLE1BQU0sSUFBSSxLQUFLO0VBQ2YsTUFBTSxlQUFlLEtBQUssWUFBWTtFQUN0QyxNQUFNLGVBQWUsRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRTtFQUMzQyxNQUFNLGVBQWUsRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRTtFQUMzQyxJQUFJLGFBQWEsV0FBVyxLQUFLLGFBQWEsRUFBRSxDQUFDLFdBQVcsVUFBVTtHQUNwRSxhQUFhLEVBQUUsQ0FBQyxLQUFLLEtBQUs7R0FDMUIsYUFBYSxFQUFFLENBQUMsS0FBSyxLQUFLO0dBQzFCLE9BQU87RUFDVDtFQUNBLEtBQUssWUFBWSxPQUNmLGNBQ0EsWUFDRjtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Q0FXQSxpQkFBaUIsS0FBSyxLQUFLLEdBQUcsR0FBRyxZQUFZO0VBQzNDLEtBQUs7RUFDTCxNQUFNLElBQUksS0FBSztFQUNmLEtBQUssWUFBWSxpQkFDZixFQUFFLElBQUksTUFBTSxFQUFFLElBQUksTUFBTSxFQUFFLElBQzFCLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFDMUIsRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUN0QixFQUFFLElBQUksSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLElBQ3RCLFVBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7OztDQVNBLEtBQUssR0FBRyxHQUFHLEdBQUcsR0FBRztFQUNmLEtBQUs7RUFDTCxLQUFLLFlBQVksS0FBSyxHQUFHLEdBQUcsR0FBRyxHQUFHLEtBQUssV0FBVyxNQUFNLENBQUM7RUFDekQsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Q0FZQSxVQUFVLEdBQUcsR0FBRyxHQUFHLEdBQUcsUUFBUTtFQUM1QixLQUFLO0VBQ0wsS0FBSyxZQUFZLFVBQVUsR0FBRyxHQUFHLEdBQUcsR0FBRyxRQUFRLEtBQUssV0FBVyxNQUFNLENBQUM7RUFDdEUsT0FBTztDQUNUOzs7Ozs7Ozs7Q0FTQSxLQUFLLFFBQVEsT0FBTztFQUNsQixLQUFLO0VBQ0wsS0FBSyxZQUFZLEtBQUssUUFBUSxPQUFPLEtBQUssV0FBVyxNQUFNLENBQUM7RUFDNUQsT0FBTztDQUNUOzs7Ozs7Ozs7OztDQVdBLFlBQVksR0FBRyxHQUFHLFFBQVEsT0FBTyxXQUFXLEdBQUcsV0FBVztFQUN4RCxLQUFLO0VBQ0wsS0FBSyxZQUFZLFlBQVksR0FBRyxHQUFHLFFBQVEsT0FBTyxVQUFVLFNBQVM7RUFDckUsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Q0FZQSxVQUFVLEdBQUcsR0FBRyxRQUFRLE9BQU8sUUFBUSxVQUFVO0VBQy9DLEtBQUs7RUFDTCxLQUFLLFlBQVksVUFBVSxHQUFHLEdBQUcsUUFBUSxPQUFPLFFBQVEsUUFBUTtFQUNoRSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7O0NBY0EsV0FBVyxRQUFRLFFBQVEsY0FBYyxZQUFZO0VBQ25ELEtBQUs7RUFDTCxLQUFLLFlBQVksV0FBVyxRQUFRLFFBQVEsY0FBYyxVQUFVO0VBQ3BFLE9BQU87Q0FDVDs7Ozs7Ozs7OztDQVVBLFdBQVcsR0FBRyxHQUFHLE9BQU8sUUFBUSxRQUFRO0VBQ3RDLEtBQUs7RUFDTCxLQUFLLFlBQVksV0FBVyxHQUFHLEdBQUcsT0FBTyxRQUFRLE1BQU07RUFDdkQsT0FBTztDQUNUOzs7Ozs7Ozs7O0NBVUEsWUFBWSxHQUFHLEdBQUcsT0FBTyxRQUFRLFNBQVMsV0FBVztFQUNuRCxLQUFLO0VBQ0wsS0FBSyxZQUFZLFlBQVksR0FBRyxHQUFHLE9BQU8sUUFBUSxTQUFTLFNBQVM7RUFDcEUsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxLQUFLLEdBQUcsR0FBRyxRQUFRLFFBQVEsY0FBYyxHQUFHLFdBQVcsR0FBRztFQUN4RCxLQUFLO0VBQ0wsS0FBSyxZQUFZLEtBQUssR0FBRyxHQUFHLFFBQVEsUUFBUSxhQUFhLFVBQVUsS0FBSyxXQUFXLE1BQU0sQ0FBQztFQUMxRixPQUFPO0NBQ1Q7Ozs7OztDQU1BLElBQUksS0FBSztFQUNQLEtBQUs7RUFDTCxVQUFVLEtBQUssSUFBSTtFQUNuQixPQUFPO0NBQ1Q7Ozs7O0NBS0EsVUFBVTtFQUNSLE1BQU0sUUFBUSxLQUFLLFlBQVksSUFBSTtFQUNuQyxJQUFJLE9BQU87R0FDVCxLQUFLLGFBQWEsTUFBTTtHQUN4QixLQUFLLGFBQWEsTUFBTTtHQUN4QixLQUFLLGVBQWUsTUFBTTtFQUM1QjtFQUNBLE9BQU87Q0FDVDs7Q0FFQSxPQUFPO0VBQ0wsS0FBSyxZQUFZLEtBQUs7R0FDcEIsV0FBVyxLQUFLLFdBQVcsTUFBTTtHQUNqQyxXQUFXLEVBQUUsR0FBRyxLQUFLLFdBQVc7R0FDaEMsYUFBYSxFQUFFLEdBQUcsS0FBSyxhQUFhO0VBQ3RDLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Ozs7O0NBS0EsZUFBZTtFQUNiLE9BQU8sS0FBSztDQUNkOzs7OztDQUtBLGlCQUFpQjtFQUNmLEtBQUssV0FBVyxTQUFTO0VBQ3pCLE9BQU87Q0FDVDs7Ozs7O0NBTUEsT0FBTyxPQUFPO0VBQ1osS0FBSyxXQUFXLE9BQU8sS0FBSztFQUM1QixPQUFPO0NBQ1Q7Ozs7Ozs7Q0FPQSxNQUFNLEdBQUcsSUFBSSxHQUFHO0VBQ2QsS0FBSyxXQUFXLE1BQU0sR0FBRyxDQUFDO0VBQzFCLE9BQU87Q0FDVDtDQUNBLGFBQWEsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLElBQUk7RUFDL0IsSUFBSSxhQUFhLFFBQVE7R0FDdkIsS0FBSyxXQUFXLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7R0FDbEQsT0FBTztFQUNUO0VBQ0EsS0FBSyxXQUFXLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLEVBQUU7RUFDdEMsT0FBTztDQUNUO0NBQ0EsVUFBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksSUFBSTtFQUM1QixJQUFJLGFBQWEsUUFBUTtHQUN2QixLQUFLLFdBQVcsT0FBTyxDQUFDO0dBQ3hCLE9BQU87RUFDVDtFQUNBLFdBQVcsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksRUFBRTtFQUNqQyxLQUFLLFdBQVcsT0FBTyxVQUFVO0VBQ2pDLE9BQU87Q0FDVDs7Ozs7OztDQU9BLFVBQVUsR0FBRyxJQUFJLEdBQUc7RUFDbEIsS0FBSyxXQUFXLFVBQVUsR0FBRyxDQUFDO0VBQzlCLE9BQU87Q0FDVDs7Ozs7O0NBTUEsUUFBUTtFQUNOLEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssYUFBYSxTQUFTO0VBQzNCLEtBQUssZUFBZTtFQUNwQixLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxXQUFXO0VBQ1QsS0FBSyxlQUFlO0VBQ3BCLEtBQUssUUFBUTtFQUNiLEtBQUssS0FBSyxVQUFVLE1BQU0sRUFBRTtDQUM5Qjs7Q0FFQSxJQUFJLFNBQVM7RUFDWCxJQUFJLENBQUMsS0FBSyxjQUFjLE9BQU8sS0FBSztFQUNwQyxLQUFLLGVBQWU7RUFDcEIsTUFBTSxTQUFTLEtBQUs7RUFDcEIsT0FBTyxNQUFNO0VBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssYUFBYSxRQUFRLEtBQUs7R0FDakQsTUFBTSxjQUFjLEtBQUssYUFBYTtHQUN0QyxNQUFNLFNBQVMsWUFBWTtHQUMzQixJQUFJLFdBQVcsUUFBUTtJQUNyQixNQUFNLE9BQU8sWUFBWTtJQUN6QixPQUFPLFVBQVUsS0FBSyxLQUFLLE1BQU07R0FDbkMsT0FBTyxJQUFJLFdBQVcsV0FBVztJQUMvQixNQUFNLE9BQU8sWUFBWTtJQUN6QixPQUFPLFNBQVMsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxTQUFTO0dBQ3hGO0dBQ0EsSUFBSSxXQUFXLFVBQVU7SUFDdkIsTUFBTSxPQUFPLFlBQVk7SUFDekIsTUFBTSxZQUFZLEtBQUssTUFBTTtJQUM3QixJQUFJLGVBQWUsS0FBSyxNQUFNLFNBQVMsSUFBSTtJQUMzQyxJQUFJLEtBQUssTUFBTSxTQUFTLFNBQ3RCLGdCQUFnQixpQkFBaUIsS0FBSyxNQUFNLEtBQUssTUFBTSxVQUFVO0lBRW5FLE1BQU0sVUFBVSxLQUFLLEtBQUs7SUFDMUIsT0FBTyxTQUNMLFFBQVEsT0FBTyxjQUNmLFFBQVEsT0FBTyxjQUNmLFFBQVEsT0FBTyxjQUNmLFFBQVEsT0FBTyxZQUNqQjtHQUNGO0VBQ0Y7RUFDQSxJQUFJLENBQUMsT0FBTyxTQUNWLE9BQU8sSUFBSSxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBRXZCLE9BQU87Q0FDVDs7Ozs7O0NBTUEsY0FBYyxPQUFPO0VBQ25CLElBQUksQ0FBQyxLQUFLLE9BQU8sY0FBYyxNQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsT0FBTztFQUN6RCxNQUFNLGVBQWUsS0FBSztFQUMxQixJQUFJLFNBQVM7RUFDYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQUs7R0FDNUMsTUFBTSxjQUFjLGFBQWE7R0FDakMsTUFBTSxPQUFPLFlBQVk7R0FDekIsTUFBTSxPQUFPLEtBQUs7R0FDbEIsSUFBSSxDQUFDLFlBQVksVUFBVSxDQUFDLE1BQU07R0FDbEMsTUFBTSxRQUFRLEtBQUs7R0FDbkIsTUFBTSxTQUFTLEtBQUssVUFBVTtHQUM5QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7SUFDdEMsTUFBTSxRQUFRLE9BQU8sRUFBRSxDQUFDO0lBQ3hCLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTztJQUN0QixNQUFNLFlBQVksT0FBTyxFQUFFLENBQUM7SUFDNUIsTUFBTSxtQkFBbUIsWUFBWSxVQUFVLGFBQWEsT0FBTyxRQUFRLElBQUk7SUFDL0UsSUFBSSxZQUFZLFdBQVcsUUFDekIsU0FBUyxNQUFNLFNBQVMsaUJBQWlCLEdBQUcsaUJBQWlCLENBQUM7U0FDekQ7S0FDTCxNQUFNLGNBQWM7S0FDcEIsU0FBUyxNQUFNLGVBQWUsaUJBQWlCLEdBQUcsaUJBQWlCLEdBQUcsWUFBWSxPQUFPLFlBQVksU0FBUztJQUNoSDtJQUNBLE1BQU0sUUFBUSxLQUFLO0lBQ25CLElBQUksT0FBTztLQUNULE1BQU0sYUFBYSxNQUFNLFdBQVc7S0FDcEMsSUFBSSxZQUNHO1dBQUEsSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FDckMsSUFBSSxXQUFXLEVBQUUsQ0FBQyxNQUFNLFNBQVMsaUJBQWlCLEdBQUcsaUJBQWlCLENBQUMsR0FDckUsU0FBUztLQUFBO0lBSWpCO0lBQ0EsSUFBSSxRQUNGLE9BQU87R0FFWDtFQUNGO0VBQ0EsT0FBTztDQUNUOztDQUVBLFNBQVM7RUFDUCxLQUFLLEtBQUssVUFBVSxJQUFJO0VBQ3hCLEtBQUssTUFBTSxPQUFPLEtBQUssVUFDckIsS0FBSyxTQUFTLElBQUksRUFBRSxRQUFRO0VBRTlCLEtBQUssV0FBMkIsdUJBQU8sT0FBTyxJQUFJO0NBQ3BEOzs7Ozs7Ozs7O0NBVUEsUUFBUSxVQUFVLE9BQU87RUFDdkIsSUFBSSxLQUFLLFdBQVc7RUFDcEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssWUFBWSxTQUFTO0VBQzFCLEtBQUssYUFBYTtFQUNsQixLQUFLLE9BQU87RUFDWixLQUFLLEtBQUssV0FBVyxJQUFJO0VBQ3pCLEtBQUssbUJBQW1CO0VBRXhCLElBRHVCLE9BQU8sWUFBWSxZQUFZLFVBQVUsU0FBUyxTQUNyRDtHQUNsQixNQUFNLHVCQUF1QixPQUFPLFlBQVksWUFBWSxVQUFVLFNBQVM7R0FDL0UsSUFBSSxLQUFLLFdBQVcsU0FDbEIsS0FBSyxXQUFXLFFBQVEsU0FBUyxLQUFLLFdBQVcsT0FBTyxLQUFLLFdBQVcsS0FBSyxRQUFRLElBQUksS0FBSyxXQUFXLFFBQVEsUUFBUSxvQkFBb0I7R0FFL0ksSUFBSSxLQUFLLGFBQWEsU0FDcEIsS0FBSyxhQUFhLFFBQVEsU0FBUyxLQUFLLGFBQWEsT0FBTyxLQUFLLGFBQWEsS0FBSyxRQUFRLElBQUksS0FBSyxhQUFhLFFBQVEsUUFBUSxvQkFBb0I7RUFFeko7RUFDQSxLQUFLLGFBQWE7RUFDbEIsS0FBSyxlQUFlO0VBQ3BCLEtBQUssZUFBZTtFQUNwQixLQUFLLGNBQWM7RUFDbkIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxjQUFjO0VBQ25CLEtBQUssZUFBZTtFQUNwQixLQUFLLGFBQWE7Q0FDcEI7QUFDRjs7QUFFQSxpQkFBaUIsbUJBQW1COztDQUVsQyxPQUFPOztDQUVQLE9BQU87O0NBRVAsU0FBUyxRQUFROztDQUVqQixRQUFROztDQUVSLE1BQU07O0NBRU4sY0FBYztBQUNoQjs7QUFFQSxpQkFBaUIscUJBQXFCOztDQUVwQyxPQUFPOztDQUVQLE9BQU87O0NBRVAsT0FBTzs7Q0FFUCxXQUFXOztDQUVYLFlBQVk7O0NBRVosS0FBSzs7Q0FFTCxNQUFNOztDQUVOLFNBQVMsUUFBUTs7Q0FFakIsUUFBUTs7Q0FFUixNQUFNOztDQUVOLGNBQWM7O0NBRWQsV0FBVztBQUNiO0FBQ0EsSUFBSSxrQkFBa0IiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0M119