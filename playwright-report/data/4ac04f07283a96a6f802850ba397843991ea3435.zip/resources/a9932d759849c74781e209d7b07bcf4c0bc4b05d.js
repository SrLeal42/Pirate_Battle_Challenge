import { API_CONFIG } from "/src/core/config.ts";
const all = (b) => ({
	submit: b,
	history: b,
	leaderboard: b
});
const reads = (b) => ({
	history: b,
	leaderboard: b
});
const SCENARIO_DEFS = {
	success: {
		label: "Success",
		description: "Default behavior with short latency.",
		behaviors: {}
	},
	empty: {
		label: "Empty lists",
		description: "Ranking and history return no records.",
		behaviors: reads({ kind: "empty" })
	},
	"many-pages": {
		label: "Many pages",
		description: "Seeds 35 history records for the current player.",
		behaviors: {},
		historyFixtures: 35
	},
	slow: {
		label: "Slow network",
		description: "Every request takes 3 seconds.",
		behaviors: all({
			kind: "ok",
			latency: 3e3
		})
	},
	"variable-latency": {
		label: "Variable latency",
		description: "Seeded latency between 150ms and 2.5s.",
		behaviors: all({
			kind: "ok",
			latency: {
				min: 150,
				max: 2500
			}
		})
	},
	"out-of-order": {
		label: "Out-of-order responses",
		description: "Alternates slow/fast reads so older responses arrive last.",
		behaviors: reads({
			kind: "ok",
			latency: "out-of-order"
		})
	},
	timeout: {
		label: "Timeout",
		description: "Every request exceeds the client timeout.",
		behaviors: all({ kind: "timeout" })
	},
	"network-error": {
		label: "Connection failure",
		description: "Every request fails at network level.",
		behaviors: all({ kind: "network-error" })
	},
	"server-error": {
		label: "HTTP 500",
		description: "Every request returns 500.",
		behaviors: all({
			kind: "status",
			status: 500
		})
	},
	"client-error": {
		label: "HTTP 400",
		description: "Every request returns 400 (not retried).",
		behaviors: all({
			kind: "status",
			status: 400
		})
	},
	"leaderboard-error": {
		label: "Ranking failure",
		description: "Only the ranking query fails (503).",
		behaviors: { leaderboard: {
			kind: "status",
			status: 503
		} }
	},
	"history-error": {
		label: "History failure",
		description: "Only the history query fails (503).",
		behaviors: { history: {
			kind: "status",
			status: 503
		} }
	},
	"submit-timeout-after-save": {
		label: "Timeout after save",
		description: "First submit is stored but times out; the retry recovers it without duplicates.",
		behaviors: { submit: {
			kind: "fail-first",
			count: 1,
			failure: { kind: "save-then-timeout" },
			then: { kind: "ok" }
		} }
	},
	"submit-unavailable": {
		label: "Unavailable on match end",
		description: "Submit fails for one full retry cycle, then recovers. Use Retry or refresh.",
		behaviors: { submit: {
			kind: "fail-first",
			count: API_CONFIG.submitRetries + 1,
			failure: {
				kind: "status",
				status: 503
			},
			then: { kind: "ok" }
		} }
	}
};
export const SCENARIOS = SCENARIO_DEFS;
export const SCENARIO_IDS = Object.keys(SCENARIOS);
export const DEFAULT_SCENARIO = "success";
export const isScenarioId = (value) => typeof value === "string" && Object.hasOwn(SCENARIOS, value);

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUF3QjNCLE1BQU0sT0FBTyxPQUFpQjtDQUFFLFFBQVE7Q0FBRyxTQUFTO0NBQUcsYUFBYTtBQUFFO0FBQ3RFLE1BQU0sU0FBUyxPQUFpQjtDQUFFLFNBQVM7Q0FBRyxhQUFhO0FBQUU7QUFFN0QsTUFBTSxnQkFBZ0I7Q0FDbEIsU0FBUztFQUFFLE9BQU87RUFBVyxhQUFhO0VBQXdDLFdBQVcsQ0FBQztDQUFFO0NBQ2hHLE9BQU87RUFBRSxPQUFPO0VBQWUsYUFBYTtFQUEwQyxXQUFXLE1BQU0sRUFBRSxNQUFNLFFBQVEsQ0FBQztDQUFFO0NBQzFILGNBQWM7RUFBRSxPQUFPO0VBQWMsYUFBYTtFQUFvRCxXQUFXLENBQUM7RUFBRyxpQkFBaUI7Q0FBRztDQUN6SSxNQUFNO0VBQUUsT0FBTztFQUFnQixhQUFhO0VBQWtDLFdBQVcsSUFBSTtHQUFFLE1BQU07R0FBTSxTQUFTO0VBQUssQ0FBQztDQUFFO0NBQzVILG9CQUFvQjtFQUFFLE9BQU87RUFBb0IsYUFBYTtFQUEwQyxXQUFXLElBQUk7R0FBRSxNQUFNO0dBQU0sU0FBUztJQUFFLEtBQUs7SUFBSyxLQUFLO0dBQUs7RUFBRSxDQUFDO0NBQUU7Q0FDekssZ0JBQWdCO0VBQUUsT0FBTztFQUEwQixhQUFhO0VBQThELFdBQVcsTUFBTTtHQUFFLE1BQU07R0FBTSxTQUFTO0VBQWUsQ0FBQztDQUFFO0NBQ3hMLFNBQVM7RUFBRSxPQUFPO0VBQVcsYUFBYTtFQUE2QyxXQUFXLElBQUksRUFBRSxNQUFNLFVBQVUsQ0FBQztDQUFFO0NBQzNILGlCQUFpQjtFQUFFLE9BQU87RUFBc0IsYUFBYTtFQUF5QyxXQUFXLElBQUksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0NBQUU7Q0FDaEosZ0JBQWdCO0VBQUUsT0FBTztFQUFZLGFBQWE7RUFBOEIsV0FBVyxJQUFJO0dBQUUsTUFBTTtHQUFVLFFBQVE7RUFBSSxDQUFDO0NBQUU7Q0FDaEksZ0JBQWdCO0VBQUUsT0FBTztFQUFZLGFBQWE7RUFBNEMsV0FBVyxJQUFJO0dBQUUsTUFBTTtHQUFVLFFBQVE7RUFBSSxDQUFDO0NBQUU7Q0FDOUkscUJBQXFCO0VBQUUsT0FBTztFQUFtQixhQUFhO0VBQXVDLFdBQVcsRUFBRSxhQUFhO0dBQUUsTUFBTTtHQUFVLFFBQVE7RUFBSSxFQUFFO0NBQUU7Q0FDakssaUJBQWlCO0VBQUUsT0FBTztFQUFtQixhQUFhO0VBQXVDLFdBQVcsRUFBRSxTQUFTO0dBQUUsTUFBTTtHQUFVLFFBQVE7RUFBSSxFQUFFO0NBQUU7Q0FDekosNkJBQTZCO0VBQ3pCLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVyxFQUFFLFFBQVE7R0FBRSxNQUFNO0dBQWMsT0FBTztHQUFHLFNBQVMsRUFBRSxNQUFNLG9CQUFvQjtHQUFHLE1BQU0sRUFBRSxNQUFNLEtBQUs7RUFBRSxFQUFFO0NBQ3hIO0NBQ0Esc0JBQXNCO0VBQ2xCLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVyxFQUNQLFFBQVE7R0FBRSxNQUFNO0dBQWMsT0FBTyxXQUFXLGdCQUFnQjtHQUFHLFNBQVM7SUFBRSxNQUFNO0lBQVUsUUFBUTtHQUFJO0dBQUcsTUFBTSxFQUFFLE1BQU0sS0FBSztFQUFFLEVBQ3RJO0NBQ0o7QUFDSjtBQUdBLE9BQU8sTUFBTSxZQUF1RDtBQUNwRSxPQUFPLE1BQU0sZUFBZSxPQUFPLEtBQUssU0FBUztBQUNqRCxPQUFPLE1BQU0sbUJBQStCO0FBRTVDLE9BQU8sTUFBTSxnQkFBZ0IsVUFDekIsT0FBTyxVQUFVLFlBQVksT0FBTyxPQUFPLFdBQVcsS0FBSyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzY2VuYXJpb3MudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQVBJX0NPTkZJRyB9IGZyb20gJy4uL2NvcmUvY29uZmlnJztcclxuXHJcbmV4cG9ydCB0eXBlIEVuZHBvaW50ID0gJ3N1Ym1pdCcgfCAnaGlzdG9yeScgfCAnbGVhZGVyYm9hcmQnO1xyXG5leHBvcnQgdHlwZSBMYXRlbmN5ID0gbnVtYmVyIHwgeyBtaW46IG51bWJlcjsgbWF4OiBudW1iZXIgfSB8ICdvdXQtb2Ytb3JkZXInO1xyXG5cclxuZXhwb3J0IHR5cGUgQ29uY3JldGVCZWhhdmlvciA9XHJcbiAgICB8IHsga2luZDogJ29rJzsgbGF0ZW5jeT86IExhdGVuY3kgfVxyXG4gICAgfCB7IGtpbmQ6ICdlbXB0eSc7IGxhdGVuY3k/OiBMYXRlbmN5IH1cclxuICAgIHwgeyBraW5kOiAnc3RhdHVzJzsgc3RhdHVzOiBudW1iZXI7IGxhdGVuY3k/OiBMYXRlbmN5IH1cclxuICAgIHwgeyBraW5kOiAnbmV0d29yay1lcnJvcicgfVxyXG4gICAgfCB7IGtpbmQ6ICd0aW1lb3V0JyB9XHJcbiAgICB8IHsga2luZDogJ3NhdmUtdGhlbi10aW1lb3V0JyB9O1xyXG5cclxuZXhwb3J0IHR5cGUgQmVoYXZpb3IgPVxyXG4gICAgfCBDb25jcmV0ZUJlaGF2aW9yXHJcbiAgICB8IHsga2luZDogJ2ZhaWwtZmlyc3QnOyBjb3VudDogbnVtYmVyOyBmYWlsdXJlOiBDb25jcmV0ZUJlaGF2aW9yOyB0aGVuOiBDb25jcmV0ZUJlaGF2aW9yIH07XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFNjZW5hcmlvRGVmIHtcclxuICAgIGxhYmVsOiBzdHJpbmc7XHJcbiAgICBkZXNjcmlwdGlvbjogc3RyaW5nO1xyXG4gICAgYmVoYXZpb3JzOiBQYXJ0aWFsPFJlY29yZDxFbmRwb2ludCwgQmVoYXZpb3I+PjtcclxuICAgIGhpc3RvcnlGaXh0dXJlcz86IG51bWJlcjtcclxufVxyXG5cclxuY29uc3QgYWxsID0gKGI6IEJlaGF2aW9yKSA9PiAoeyBzdWJtaXQ6IGIsIGhpc3Rvcnk6IGIsIGxlYWRlcmJvYXJkOiBiIH0pO1xyXG5jb25zdCByZWFkcyA9IChiOiBCZWhhdmlvcikgPT4gKHsgaGlzdG9yeTogYiwgbGVhZGVyYm9hcmQ6IGIgfSk7XHJcblxyXG5jb25zdCBTQ0VOQVJJT19ERUZTID0ge1xyXG4gICAgc3VjY2VzczogeyBsYWJlbDogJ1N1Y2Nlc3MnLCBkZXNjcmlwdGlvbjogJ0RlZmF1bHQgYmVoYXZpb3Igd2l0aCBzaG9ydCBsYXRlbmN5LicsIGJlaGF2aW9yczoge30gfSxcclxuICAgIGVtcHR5OiB7IGxhYmVsOiAnRW1wdHkgbGlzdHMnLCBkZXNjcmlwdGlvbjogJ1JhbmtpbmcgYW5kIGhpc3RvcnkgcmV0dXJuIG5vIHJlY29yZHMuJywgYmVoYXZpb3JzOiByZWFkcyh7IGtpbmQ6ICdlbXB0eScgfSkgfSxcclxuICAgICdtYW55LXBhZ2VzJzogeyBsYWJlbDogJ01hbnkgcGFnZXMnLCBkZXNjcmlwdGlvbjogJ1NlZWRzIDM1IGhpc3RvcnkgcmVjb3JkcyBmb3IgdGhlIGN1cnJlbnQgcGxheWVyLicsIGJlaGF2aW9yczoge30sIGhpc3RvcnlGaXh0dXJlczogMzUgfSxcclxuICAgIHNsb3c6IHsgbGFiZWw6ICdTbG93IG5ldHdvcmsnLCBkZXNjcmlwdGlvbjogJ0V2ZXJ5IHJlcXVlc3QgdGFrZXMgMyBzZWNvbmRzLicsIGJlaGF2aW9yczogYWxsKHsga2luZDogJ29rJywgbGF0ZW5jeTogMzAwMCB9KSB9LFxyXG4gICAgJ3ZhcmlhYmxlLWxhdGVuY3knOiB7IGxhYmVsOiAnVmFyaWFibGUgbGF0ZW5jeScsIGRlc2NyaXB0aW9uOiAnU2VlZGVkIGxhdGVuY3kgYmV0d2VlbiAxNTBtcyBhbmQgMi41cy4nLCBiZWhhdmlvcnM6IGFsbCh7IGtpbmQ6ICdvaycsIGxhdGVuY3k6IHsgbWluOiAxNTAsIG1heDogMjUwMCB9IH0pIH0sXHJcbiAgICAnb3V0LW9mLW9yZGVyJzogeyBsYWJlbDogJ091dC1vZi1vcmRlciByZXNwb25zZXMnLCBkZXNjcmlwdGlvbjogJ0FsdGVybmF0ZXMgc2xvdy9mYXN0IHJlYWRzIHNvIG9sZGVyIHJlc3BvbnNlcyBhcnJpdmUgbGFzdC4nLCBiZWhhdmlvcnM6IHJlYWRzKHsga2luZDogJ29rJywgbGF0ZW5jeTogJ291dC1vZi1vcmRlcicgfSkgfSxcclxuICAgIHRpbWVvdXQ6IHsgbGFiZWw6ICdUaW1lb3V0JywgZGVzY3JpcHRpb246ICdFdmVyeSByZXF1ZXN0IGV4Y2VlZHMgdGhlIGNsaWVudCB0aW1lb3V0LicsIGJlaGF2aW9yczogYWxsKHsga2luZDogJ3RpbWVvdXQnIH0pIH0sXHJcbiAgICAnbmV0d29yay1lcnJvcic6IHsgbGFiZWw6ICdDb25uZWN0aW9uIGZhaWx1cmUnLCBkZXNjcmlwdGlvbjogJ0V2ZXJ5IHJlcXVlc3QgZmFpbHMgYXQgbmV0d29yayBsZXZlbC4nLCBiZWhhdmlvcnM6IGFsbCh7IGtpbmQ6ICduZXR3b3JrLWVycm9yJyB9KSB9LFxyXG4gICAgJ3NlcnZlci1lcnJvcic6IHsgbGFiZWw6ICdIVFRQIDUwMCcsIGRlc2NyaXB0aW9uOiAnRXZlcnkgcmVxdWVzdCByZXR1cm5zIDUwMC4nLCBiZWhhdmlvcnM6IGFsbCh7IGtpbmQ6ICdzdGF0dXMnLCBzdGF0dXM6IDUwMCB9KSB9LFxyXG4gICAgJ2NsaWVudC1lcnJvcic6IHsgbGFiZWw6ICdIVFRQIDQwMCcsIGRlc2NyaXB0aW9uOiAnRXZlcnkgcmVxdWVzdCByZXR1cm5zIDQwMCAobm90IHJldHJpZWQpLicsIGJlaGF2aW9yczogYWxsKHsga2luZDogJ3N0YXR1cycsIHN0YXR1czogNDAwIH0pIH0sXHJcbiAgICAnbGVhZGVyYm9hcmQtZXJyb3InOiB7IGxhYmVsOiAnUmFua2luZyBmYWlsdXJlJywgZGVzY3JpcHRpb246ICdPbmx5IHRoZSByYW5raW5nIHF1ZXJ5IGZhaWxzICg1MDMpLicsIGJlaGF2aW9yczogeyBsZWFkZXJib2FyZDogeyBraW5kOiAnc3RhdHVzJywgc3RhdHVzOiA1MDMgfSB9IH0sXHJcbiAgICAnaGlzdG9yeS1lcnJvcic6IHsgbGFiZWw6ICdIaXN0b3J5IGZhaWx1cmUnLCBkZXNjcmlwdGlvbjogJ09ubHkgdGhlIGhpc3RvcnkgcXVlcnkgZmFpbHMgKDUwMykuJywgYmVoYXZpb3JzOiB7IGhpc3Rvcnk6IHsga2luZDogJ3N0YXR1cycsIHN0YXR1czogNTAzIH0gfSB9LFxyXG4gICAgJ3N1Ym1pdC10aW1lb3V0LWFmdGVyLXNhdmUnOiB7XHJcbiAgICAgICAgbGFiZWw6ICdUaW1lb3V0IGFmdGVyIHNhdmUnLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnRmlyc3Qgc3VibWl0IGlzIHN0b3JlZCBidXQgdGltZXMgb3V0OyB0aGUgcmV0cnkgcmVjb3ZlcnMgaXQgd2l0aG91dCBkdXBsaWNhdGVzLicsXHJcbiAgICAgICAgYmVoYXZpb3JzOiB7IHN1Ym1pdDogeyBraW5kOiAnZmFpbC1maXJzdCcsIGNvdW50OiAxLCBmYWlsdXJlOiB7IGtpbmQ6ICdzYXZlLXRoZW4tdGltZW91dCcgfSwgdGhlbjogeyBraW5kOiAnb2snIH0gfSB9LFxyXG4gICAgfSxcclxuICAgICdzdWJtaXQtdW5hdmFpbGFibGUnOiB7XHJcbiAgICAgICAgbGFiZWw6ICdVbmF2YWlsYWJsZSBvbiBtYXRjaCBlbmQnLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnU3VibWl0IGZhaWxzIGZvciBvbmUgZnVsbCByZXRyeSBjeWNsZSwgdGhlbiByZWNvdmVycy4gVXNlIFJldHJ5IG9yIHJlZnJlc2guJyxcclxuICAgICAgICBiZWhhdmlvcnM6IHtcclxuICAgICAgICAgICAgc3VibWl0OiB7IGtpbmQ6ICdmYWlsLWZpcnN0JywgY291bnQ6IEFQSV9DT05GSUcuc3VibWl0UmV0cmllcyArIDEsIGZhaWx1cmU6IHsga2luZDogJ3N0YXR1cycsIHN0YXR1czogNTAzIH0sIHRoZW46IHsga2luZDogJ29rJyB9IH0sXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcbn0gc2F0aXNmaWVzIFJlY29yZDxzdHJpbmcsIFNjZW5hcmlvRGVmPjtcclxuXHJcbmV4cG9ydCB0eXBlIFNjZW5hcmlvSWQgPSBrZXlvZiB0eXBlb2YgU0NFTkFSSU9fREVGUztcclxuZXhwb3J0IGNvbnN0IFNDRU5BUklPUzogUmVhZG9ubHk8UmVjb3JkPFNjZW5hcmlvSWQsIFNjZW5hcmlvRGVmPj4gPSBTQ0VOQVJJT19ERUZTO1xyXG5leHBvcnQgY29uc3QgU0NFTkFSSU9fSURTID0gT2JqZWN0LmtleXMoU0NFTkFSSU9TKSBhcyBTY2VuYXJpb0lkW107XHJcbmV4cG9ydCBjb25zdCBERUZBVUxUX1NDRU5BUklPOiBTY2VuYXJpb0lkID0gJ3N1Y2Nlc3MnO1xyXG5cclxuZXhwb3J0IGNvbnN0IGlzU2NlbmFyaW9JZCA9ICh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIFNjZW5hcmlvSWQgPT5cclxuICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgJiYgT2JqZWN0Lmhhc093bihTQ0VOQVJJT1MsIHZhbHVlKTtcclxuIl19