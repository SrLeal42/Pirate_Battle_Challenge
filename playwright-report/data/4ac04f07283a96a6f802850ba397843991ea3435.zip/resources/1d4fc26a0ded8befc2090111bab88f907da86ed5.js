import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/index.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/index.css"
const __vite__css = "*:focus-visible {\r\n    outline: 3px solid #fde047;\r\n    outline-offset: 3px;\r\n    border-radius: 4px;\r\n}\r\n\r\n/* Visually hidden but available to assistive tech */\r\n.sr-only {\r\n    position: absolute;\r\n    width: 1px;\r\n    height: 1px;\r\n    padding: 0;\r\n    margin: -1px;\r\n    overflow: hidden;\r\n    clip-path: inset(50%);\r\n    white-space: nowrap;\r\n    border: 0;\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))