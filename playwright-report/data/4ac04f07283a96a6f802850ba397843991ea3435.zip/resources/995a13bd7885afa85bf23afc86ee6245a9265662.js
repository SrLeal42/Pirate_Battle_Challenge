import { C as getAttributeInfoFromFormat, H as warn, ct as uid, gt as eventemitter3_default, o as Buffer, s as BufferUsage } from "/node_modules/.vite/deps/CanvasPool-BcIVNj8Y.js?v=43418a0e";
import { Q as unsafeEvalSupported } from "/node_modules/.vite/deps/RenderTargetSystem-BtplTPyq.js?v=43418a0e";
import { F as STENCIL_MODES } from "/node_modules/.vite/deps/GCManagedHash-BlELPMdI.js?v=43418a0e";
//#region node_modules/pixi.js/lib/rendering/high-shader/shader-bits/localUniformBit.mjs
var localUniformBit = {
	name: "local-uniform-bit",
	vertex: {
		header: `

            struct LocalUniforms {
                uTransformMatrix:mat3x3<f32>,
                uColor:vec4<f32>,
                uRound:f32,
            }

            @group(1) @binding(0) var<uniform> localUniforms : LocalUniforms;
        `,
		main: `
            vColor *= localUniforms.uColor;
            modelMatrix *= localUniforms.uTransformMatrix;
        `,
		end: `
            if(localUniforms.uRound == 1)
            {
                vPosition = vec4(roundPixels(vPosition.xy, globalUniforms.uResolution), vPosition.zw);
            }
        `
	}
};
var localUniformBitGroup2 = {
	...localUniformBit,
	vertex: {
		...localUniformBit.vertex,
		header: localUniformBit.vertex.header.replace("group(1)", "group(2)")
	}
};
var localUniformBitGl = {
	name: "local-uniform-bit",
	vertex: {
		header: `

            uniform mat3 uTransformMatrix;
            uniform vec4 uColor;
            uniform float uRound;
        `,
		main: `
            vColor *= uColor;
            modelMatrix = uTransformMatrix;
        `,
		end: `
            if(uRound == 1.)
            {
                gl_Position.xy = roundPixels(gl_Position.xy, uResolution);
            }
        `
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/high-shader/shader-bits/textureBit.mjs
var textureBit = {
	name: "texture-bit",
	vertex: {
		header: `

        struct TextureUniforms {
            uTextureMatrix:mat3x3<f32>,
        }

        @group(2) @binding(2) var<uniform> textureUniforms : TextureUniforms;
        `,
		main: `
            uv = (textureUniforms.uTextureMatrix * vec3(uv, 1.0)).xy;
        `
	},
	fragment: {
		header: `
            @group(2) @binding(0) var uTexture: texture_2d<f32>;
            @group(2) @binding(1) var uSampler: sampler;


        `,
		main: `
            outColor = textureSample(uTexture, uSampler, vUV);
        `
	}
};
var textureBitGl = {
	name: "texture-bit",
	vertex: {
		header: `
            uniform mat3 uTextureMatrix;
        `,
		main: `
            uv = (uTextureMatrix * vec3(uv, 1.0)).xy;
        `
	},
	fragment: {
		header: `
        uniform sampler2D uTexture;


        `,
		main: `
            outColor = texture(uTexture, vUV);
        `
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/ensureAttributes.mjs
function ensureAttributes(geometry, extractedData) {
	for (const i in geometry.attributes) {
		const attribute = geometry.attributes[i];
		const attributeData = extractedData[i];
		if (attributeData) {
			attribute.format ?? (attribute.format = attributeData.format);
			attribute.offset ?? (attribute.offset = attributeData.offset);
			attribute.instance ?? (attribute.instance = attributeData.instance);
		} else if (!attribute.format) warn(`Attribute ${i} is not present in the shader, but is present in the geometry. Unable to infer attribute details.`);
	}
	ensureStartAndStride(geometry);
}
function ensureStartAndStride(geometry) {
	const { buffers, attributes } = geometry;
	const tempStride = {};
	const tempStart = {};
	for (const j in buffers) {
		const buffer = buffers[j];
		tempStride[buffer.uid] = 0;
		tempStart[buffer.uid] = 0;
	}
	for (const j in attributes) {
		const attribute = attributes[j];
		tempStride[attribute.buffer.uid] += getAttributeInfoFromFormat(attribute.format).stride;
	}
	for (const j in attributes) {
		const attribute = attributes[j];
		attribute.stride ?? (attribute.stride = tempStride[attribute.buffer.uid]);
		attribute.start ?? (attribute.start = tempStart[attribute.buffer.uid]);
		tempStart[attribute.buffer.uid] += getAttributeInfoFromFormat(attribute.format).stride;
	}
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/state/GpuStencilModesToPixi.mjs
var GpuStencilModesToPixi = [];
GpuStencilModesToPixi[STENCIL_MODES.NONE] = void 0;
GpuStencilModesToPixi[STENCIL_MODES.DISABLED] = {
	stencilWriteMask: 0,
	stencilReadMask: 0
};
GpuStencilModesToPixi[STENCIL_MODES.RENDERING_MASK_ADD] = {
	stencilFront: {
		compare: "equal",
		passOp: "increment-clamp"
	},
	stencilBack: {
		compare: "equal",
		passOp: "increment-clamp"
	}
};
GpuStencilModesToPixi[STENCIL_MODES.RENDERING_MASK_REMOVE] = {
	stencilFront: {
		compare: "equal",
		passOp: "decrement-clamp"
	},
	stencilBack: {
		compare: "equal",
		passOp: "decrement-clamp"
	}
};
GpuStencilModesToPixi[STENCIL_MODES.MASK_ACTIVE] = {
	stencilWriteMask: 0,
	stencilFront: {
		compare: "equal",
		passOp: "keep"
	},
	stencilBack: {
		compare: "equal",
		passOp: "keep"
	}
};
GpuStencilModesToPixi[STENCIL_MODES.INVERSE_MASK_ACTIVE] = {
	stencilWriteMask: 0,
	stencilFront: {
		compare: "not-equal",
		passOp: "keep"
	},
	stencilBack: {
		compare: "not-equal",
		passOp: "keep"
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/UboSystem.mjs
var UboSystem = class {
	constructor(adaptor) {
		/** Cache of uniform buffer layouts and sync functions, so we don't have to re-create them */
		this._syncFunctionHash = /* @__PURE__ */ Object.create(null);
		this._adaptor = adaptor;
		this._systemCheck();
	}
	/**
	* Overridable function by `pixi.js/unsafe-eval` to silence
	* throwing an error if platform doesn't support unsafe-evals.
	* @private
	*/
	_systemCheck() {
		if (!unsafeEvalSupported()) throw new Error("Current environment does not allow unsafe-eval, please use pixi.js/unsafe-eval module to enable support.");
	}
	ensureUniformGroup(uniformGroup) {
		const uniformData = this.getUniformGroupData(uniformGroup);
		uniformGroup.buffer || (uniformGroup.buffer = new Buffer({
			data: new Float32Array(uniformData.layout.size / 4),
			usage: BufferUsage.UNIFORM | BufferUsage.COPY_DST
		}));
	}
	getUniformGroupData(uniformGroup) {
		return this._syncFunctionHash[uniformGroup._signature] || this._initUniformGroup(uniformGroup);
	}
	_initUniformGroup(uniformGroup) {
		const uniformGroupSignature = uniformGroup._signature;
		let uniformData = this._syncFunctionHash[uniformGroupSignature];
		if (!uniformData) {
			const elements = Object.keys(uniformGroup.uniformStructures).map((i) => uniformGroup.uniformStructures[i]);
			const layout = this._adaptor.createUboElements(elements);
			const syncFunction = this._generateUboSync(layout.uboElements);
			uniformData = this._syncFunctionHash[uniformGroupSignature] = {
				layout,
				syncFunction
			};
		}
		return this._syncFunctionHash[uniformGroupSignature];
	}
	_generateUboSync(uboElements) {
		return this._adaptor.generateUboSync(uboElements);
	}
	syncUniformGroup(uniformGroup, data, offset) {
		const uniformGroupData = this.getUniformGroupData(uniformGroup);
		uniformGroup.buffer || (uniformGroup.buffer = new Buffer({
			data: new Float32Array(uniformGroupData.layout.size / 4),
			usage: BufferUsage.UNIFORM | BufferUsage.COPY_DST
		}));
		let dataInt32 = null;
		if (!data) {
			data = uniformGroup.buffer.data;
			dataInt32 = uniformGroup.buffer.dataInt32;
		}
		offset || (offset = 0);
		uniformGroupData.syncFunction(uniformGroup.uniforms, data, dataInt32, offset);
		return true;
	}
	updateUniformGroup(uniformGroup) {
		if (uniformGroup.isStatic && !uniformGroup._dirtyId) return false;
		uniformGroup._dirtyId = 0;
		const synced = this.syncUniformGroup(uniformGroup);
		uniformGroup.buffer.update();
		return synced;
	}
	destroy() {
		this._syncFunctionHash = null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/utils/uniformParsers.mjs
var uniformParsers = [
	{
		type: "mat3x3<f32>",
		test: (data) => {
			return data.value.a !== void 0;
		},
		ubo: `
            var matrix = uv[name].toArray(true);
            data[offset] = matrix[0];
            data[offset + 1] = matrix[1];
            data[offset + 2] = matrix[2];
            data[offset + 4] = matrix[3];
            data[offset + 5] = matrix[4];
            data[offset + 6] = matrix[5];
            data[offset + 8] = matrix[6];
            data[offset + 9] = matrix[7];
            data[offset + 10] = matrix[8];
        `,
		uniform: `
            gl.uniformMatrix3fv(ud[name].location, false, uv[name].toArray(true));
        `
	},
	{
		type: "vec4<f32>",
		test: (data) => data.type === "vec4<f32>" && data.size === 1 && data.value.width !== void 0,
		ubo: `
            v = uv[name];
            data[offset] = v.x;
            data[offset + 1] = v.y;
            data[offset + 2] = v.width;
            data[offset + 3] = v.height;
        `,
		uniform: `
            cv = ud[name].value;
            v = uv[name];
            if (cv[0] !== v.x || cv[1] !== v.y || cv[2] !== v.width || cv[3] !== v.height) {
                cv[0] = v.x;
                cv[1] = v.y;
                cv[2] = v.width;
                cv[3] = v.height;
                gl.uniform4f(ud[name].location, v.x, v.y, v.width, v.height);
            }
        `
	},
	{
		type: "vec2<f32>",
		test: (data) => data.type === "vec2<f32>" && data.size === 1 && data.value.x !== void 0,
		ubo: `
            v = uv[name];
            data[offset] = v.x;
            data[offset + 1] = v.y;
        `,
		uniform: `
            cv = ud[name].value;
            v = uv[name];
            if (cv[0] !== v.x || cv[1] !== v.y) {
                cv[0] = v.x;
                cv[1] = v.y;
                gl.uniform2f(ud[name].location, v.x, v.y);
            }
        `
	},
	{
		type: "vec4<f32>",
		test: (data) => data.type === "vec4<f32>" && data.size === 1 && data.value.red !== void 0,
		ubo: `
            v = uv[name];
            data[offset] = v.red;
            data[offset + 1] = v.green;
            data[offset + 2] = v.blue;
            data[offset + 3] = v.alpha;
        `,
		uniform: `
            cv = ud[name].value;
            v = uv[name];
            if (cv[0] !== v.red || cv[1] !== v.green || cv[2] !== v.blue || cv[3] !== v.alpha) {
                cv[0] = v.red;
                cv[1] = v.green;
                cv[2] = v.blue;
                cv[3] = v.alpha;
                gl.uniform4f(ud[name].location, v.red, v.green, v.blue, v.alpha);
            }
        `
	},
	{
		type: "vec3<f32>",
		test: (data) => data.type === "vec3<f32>" && data.size === 1 && data.value.red !== void 0,
		ubo: `
            v = uv[name];
            data[offset] = v.red;
            data[offset + 1] = v.green;
            data[offset + 2] = v.blue;
        `,
		uniform: `
            cv = ud[name].value;
            v = uv[name];
            if (cv[0] !== v.red || cv[1] !== v.green || cv[2] !== v.blue) {
                cv[0] = v.red;
                cv[1] = v.green;
                cv[2] = v.blue;
                gl.uniform3f(ud[name].location, v.red, v.green, v.blue);
            }
        `
	}
];
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/utils/compileBufferSync.mjs
function compileBufferSync(uboElements, singleSettersMap, arrayGenerationFunction) {
	const funcFragments = [`
        var v = null;
        var v2 = null;
        var t = 0;
        var index = 0;
        var name = null;
        var arrayOffset = null;
    `];
	let prev = 0;
	for (let i = 0; i < uboElements.length; i++) {
		const uboElement = uboElements[i];
		const name = uboElement.data.name;
		let parsed = false;
		let offset = 0;
		for (let j = 0; j < uniformParsers.length; j++) if (uniformParsers[j].test(uboElement.data)) {
			offset = uboElement.offset / 4;
			funcFragments.push(`name = "${name}";`, `offset += ${offset - prev};`, uniformParsers[j].ubo);
			parsed = true;
			break;
		}
		if (!parsed) {
			if (uboElement.data.size > 1) {
				offset = uboElement.offset / 4;
				funcFragments.push(arrayGenerationFunction(uboElement, offset - prev));
			} else {
				const template = singleSettersMap[uboElement.data.type];
				offset = uboElement.offset / 4;
				funcFragments.push(`
                    v = uv.${name};
                    offset += ${offset - prev};
                    ${template};
                `);
			}
		}
		prev = offset;
	}
	const fragmentSrc = funcFragments.join("\n");
	return new Function("uv", "data", "dataInt32", "offset", fragmentSrc);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/utils/uboSyncFunctions.mjs
function loopMatrix(col, row) {
	return `
        for (let i = 0; i < ${col * row}; i++) {
            data[offset + (((i / ${col})|0) * 4) + (i % ${col})] = v[i];
        }
    `;
}
var uboSyncFunctionsSTD40 = {
	f32: `
        data[offset] = v;`,
	i32: `
        dataInt32[offset] = v;`,
	u32: `
        dataInt32[offset] = v;`,
	"vec2<f32>": `
        data[offset] = v[0];
        data[offset + 1] = v[1];`,
	"vec3<f32>": `
        data[offset] = v[0];
        data[offset + 1] = v[1];
        data[offset + 2] = v[2];`,
	"vec4<f32>": `
        data[offset] = v[0];
        data[offset + 1] = v[1];
        data[offset + 2] = v[2];
        data[offset + 3] = v[3];`,
	"vec2<i32>": `
        dataInt32[offset] = v[0];
        dataInt32[offset + 1] = v[1];`,
	"vec3<i32>": `
        dataInt32[offset] = v[0];
        dataInt32[offset + 1] = v[1];
        dataInt32[offset + 2] = v[2];`,
	"vec4<i32>": `
        dataInt32[offset] = v[0];
        dataInt32[offset + 1] = v[1];
        dataInt32[offset + 2] = v[2];
        dataInt32[offset + 3] = v[3];`,
	"vec2<u32>": `
        dataInt32[offset] = v[0];
        dataInt32[offset + 1] = v[1];`,
	"vec3<u32>": `
        dataInt32[offset] = v[0];
        dataInt32[offset + 1] = v[1];
        dataInt32[offset + 2] = v[2];`,
	"vec4<u32>": `
        dataInt32[offset] = v[0];
        dataInt32[offset + 1] = v[1];
        dataInt32[offset + 2] = v[2];
        dataInt32[offset + 3] = v[3];`,
	"mat2x2<f32>": `
        data[offset] = v[0];
        data[offset + 1] = v[1];
        data[offset + 4] = v[2];
        data[offset + 5] = v[3];`,
	"mat3x3<f32>": `
        data[offset] = v[0];
        data[offset + 1] = v[1];
        data[offset + 2] = v[2];
        data[offset + 4] = v[3];
        data[offset + 5] = v[4];
        data[offset + 6] = v[5];
        data[offset + 8] = v[6];
        data[offset + 9] = v[7];
        data[offset + 10] = v[8];`,
	"mat4x4<f32>": `
        for (let i = 0; i < 16; i++) {
            data[offset + i] = v[i];
        }`,
	"mat3x2<f32>": loopMatrix(3, 2),
	"mat4x2<f32>": loopMatrix(4, 2),
	"mat2x3<f32>": loopMatrix(2, 3),
	"mat4x3<f32>": loopMatrix(4, 3),
	"mat2x4<f32>": loopMatrix(2, 4),
	"mat3x4<f32>": loopMatrix(3, 4)
};
var uboSyncFunctionsWGSL = {
	...uboSyncFunctionsSTD40,
	"mat2x2<f32>": `
        data[offset] = v[0];
        data[offset + 1] = v[1];
        data[offset + 2] = v[2];
        data[offset + 3] = v[3];
    `
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/buffer/BufferResource.mjs
var BufferResource = class extends eventemitter3_default {
	/**
	* Create a new Buffer Resource.
	* @param options - The options for the buffer resource
	* @param options.buffer - The underlying buffer that this resource is using
	* @param options.offset - The offset of the buffer this resource is using.
	* If not provided, then it will use the offset of the buffer.
	* @param options.size - The size of the buffer this resource is using.
	* If not provided, then it will use the size of the buffer.
	*/
	constructor({ buffer, offset, size }) {
		super();
		/**
		* emits when the underlying buffer has changed shape (i.e. resized)
		* letting the renderer know that it needs to discard the old buffer on the GPU and create a new one
		* @event change
		*/
		/** a unique id for this uniform group used through the renderer */
		this.uid = uid("buffer");
		/**
		* a resource type, used to identify how to handle it when its in a bind group / shader resource
		* @internal
		*/
		this._resourceType = "bufferResource";
		/**
		* the resource id used internally by the renderer to build bind group keys
		* @internal
		*/
		this._resourceId = uid("resource");
		/**
		* A cheeky hint to the GL renderer to let it know this is a BufferResource
		* @internal
		*/
		this._bufferResource = true;
		/**
		* Has the Buffer resource been destroyed?
		* @readonly
		*/
		this.destroyed = false;
		this.buffer = buffer;
		this.offset = offset | 0;
		this.size = size;
		this.buffer.on("change", this.onBufferChange, this);
	}
	/**
	* The GC tracks the underlying buffer, not this resource — a GC stamp here (see
	* BindGroup._touch) must land on the buffer, or the GC collects it while cached
	* bind groups still reference it.
	* @internal
	*/
	get _gcLastUsed() {
		return this.buffer?._gcLastUsed ?? -1;
	}
	set _gcLastUsed(value) {
		if (this.buffer) this.buffer._gcLastUsed = value;
	}
	onBufferChange() {
		this._resourceId = uid("resource");
		this.emit("change", this);
	}
	/**
	* Destroys this resource. Make sure the underlying buffer is not used anywhere else
	* if you want to destroy it as well, or code will explode
	* @param destroyBuffer - Should the underlying buffer be destroyed as well?
	*/
	destroy(destroyBuffer = false) {
		this.destroyed = true;
		if (destroyBuffer) this.buffer.destroy();
		this.emit("change", this);
		this.buffer = null;
		this.removeAllListeners();
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/utils/getTexelRangeRects.mjs
function getTexelRangeRects(start, end, width, height, out) {
	start = Math.max(0, start);
	end = Math.min(end, width * height);
	if (start >= end) return 0;
	const firstRow = Math.floor(start / width);
	const firstX = start - firstRow * width;
	const lastRow = Math.floor(end / width);
	const lastX = end - lastRow * width;
	if (firstRow === lastRow) {
		out[0].set(firstX, firstRow, lastX - firstX, 1);
		return 1;
	}
	let count = 0;
	let firstFullRow = firstRow;
	if (firstX > 0) {
		out[count++].set(firstX, firstRow, width - firstX, 1);
		firstFullRow++;
	}
	if (lastRow > firstFullRow) out[count++].set(0, firstFullRow, width, lastRow - firstFullRow);
	if (lastX > 0) out[count++].set(0, lastRow, lastX, 1);
	return count;
}
//#endregion
export { compileBufferSync as a, GpuStencilModesToPixi as c, textureBitGl as d, localUniformBit as f, uboSyncFunctionsWGSL as i, ensureAttributes as l, localUniformBitGroup2 as m, BufferResource as n, uniformParsers as o, localUniformBitGl as p, uboSyncFunctionsSTD40 as r, UboSystem as s, getTexelRangeRects as t, textureBit as u };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2V0VGV4ZWxSYW5nZVJlY3RzLUN6aTgwWWRuLmpzIiwibmFtZXMiOlsiRXZlbnRFbWl0dGVyIl0sInNvdXJjZXMiOlsiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2hpZ2gtc2hhZGVyL3NoYWRlci1iaXRzL2xvY2FsVW5pZm9ybUJpdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvaGlnaC1zaGFkZXIvc2hhZGVyLWJpdHMvdGV4dHVyZUJpdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL2dsL3NoYWRlci9wcm9ncmFtL2Vuc3VyZUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9ncHUvc3RhdGUvR3B1U3RlbmNpbE1vZGVzVG9QaXhpLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3NoYWRlci9VYm9TeXN0ZW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvc2hhZGVyL3V0aWxzL3VuaWZvcm1QYXJzZXJzLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3NoYWRlci91dGlscy9jb21waWxlQnVmZmVyU3luYy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9zaGFkZXIvdXRpbHMvdWJvU3luY0Z1bmN0aW9ucy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9idWZmZXIvQnVmZmVyUmVzb3VyY2UubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS91dGlscy9nZXRUZXhlbFJhbmdlUmVjdHMubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuY29uc3QgbG9jYWxVbmlmb3JtQml0ID0ge1xuICBuYW1lOiBcImxvY2FsLXVuaWZvcm0tYml0XCIsXG4gIHZlcnRleDoge1xuICAgIGhlYWRlcjogKFxuICAgICAgLyogd2dzbCAqL1xuICAgICAgYFxuXG4gICAgICAgICAgICBzdHJ1Y3QgTG9jYWxVbmlmb3JtcyB7XG4gICAgICAgICAgICAgICAgdVRyYW5zZm9ybU1hdHJpeDptYXQzeDM8ZjMyPixcbiAgICAgICAgICAgICAgICB1Q29sb3I6dmVjNDxmMzI+LFxuICAgICAgICAgICAgICAgIHVSb3VuZDpmMzIsXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIEBncm91cCgxKSBAYmluZGluZygwKSB2YXI8dW5pZm9ybT4gbG9jYWxVbmlmb3JtcyA6IExvY2FsVW5pZm9ybXM7XG4gICAgICAgIGBcbiAgICApLFxuICAgIG1haW46IChcbiAgICAgIC8qIHdnc2wgKi9cbiAgICAgIGBcbiAgICAgICAgICAgIHZDb2xvciAqPSBsb2NhbFVuaWZvcm1zLnVDb2xvcjtcbiAgICAgICAgICAgIG1vZGVsTWF0cml4ICo9IGxvY2FsVW5pZm9ybXMudVRyYW5zZm9ybU1hdHJpeDtcbiAgICAgICAgYFxuICAgICksXG4gICAgZW5kOiAoXG4gICAgICAvKiB3Z3NsICovXG4gICAgICBgXG4gICAgICAgICAgICBpZihsb2NhbFVuaWZvcm1zLnVSb3VuZCA9PSAxKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHZQb3NpdGlvbiA9IHZlYzQocm91bmRQaXhlbHModlBvc2l0aW9uLnh5LCBnbG9iYWxVbmlmb3Jtcy51UmVzb2x1dGlvbiksIHZQb3NpdGlvbi56dyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIGBcbiAgICApXG4gIH1cbn07XG5jb25zdCBsb2NhbFVuaWZvcm1CaXRHcm91cDIgPSB7XG4gIC4uLmxvY2FsVW5pZm9ybUJpdCxcbiAgdmVydGV4OiB7XG4gICAgLi4ubG9jYWxVbmlmb3JtQml0LnZlcnRleCxcbiAgICAvLyByZXBsYWNlIHRoZSBncm91cCFcbiAgICBoZWFkZXI6IGxvY2FsVW5pZm9ybUJpdC52ZXJ0ZXguaGVhZGVyLnJlcGxhY2UoXCJncm91cCgxKVwiLCBcImdyb3VwKDIpXCIpXG4gIH1cbn07XG5jb25zdCBsb2NhbFVuaWZvcm1CaXRHbCA9IHtcbiAgbmFtZTogXCJsb2NhbC11bmlmb3JtLWJpdFwiLFxuICB2ZXJ0ZXg6IHtcbiAgICBoZWFkZXI6IChcbiAgICAgIC8qIGdsc2wgKi9cbiAgICAgIGBcblxuICAgICAgICAgICAgdW5pZm9ybSBtYXQzIHVUcmFuc2Zvcm1NYXRyaXg7XG4gICAgICAgICAgICB1bmlmb3JtIHZlYzQgdUNvbG9yO1xuICAgICAgICAgICAgdW5pZm9ybSBmbG9hdCB1Um91bmQ7XG4gICAgICAgIGBcbiAgICApLFxuICAgIG1haW46IChcbiAgICAgIC8qIGdsc2wgKi9cbiAgICAgIGBcbiAgICAgICAgICAgIHZDb2xvciAqPSB1Q29sb3I7XG4gICAgICAgICAgICBtb2RlbE1hdHJpeCA9IHVUcmFuc2Zvcm1NYXRyaXg7XG4gICAgICAgIGBcbiAgICApLFxuICAgIGVuZDogKFxuICAgICAgLyogZ2xzbCAqL1xuICAgICAgYFxuICAgICAgICAgICAgaWYodVJvdW5kID09IDEuKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGdsX1Bvc2l0aW9uLnh5ID0gcm91bmRQaXhlbHMoZ2xfUG9zaXRpb24ueHksIHVSZXNvbHV0aW9uKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgYFxuICAgIClcbiAgfVxufTtcblxuZXhwb3J0IHsgbG9jYWxVbmlmb3JtQml0LCBsb2NhbFVuaWZvcm1CaXRHbCwgbG9jYWxVbmlmb3JtQml0R3JvdXAyIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1sb2NhbFVuaWZvcm1CaXQubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCB0ZXh0dXJlQml0ID0ge1xuICBuYW1lOiBcInRleHR1cmUtYml0XCIsXG4gIHZlcnRleDoge1xuICAgIGhlYWRlcjogKFxuICAgICAgLyogd2dzbCAqL1xuICAgICAgYFxuXG4gICAgICAgIHN0cnVjdCBUZXh0dXJlVW5pZm9ybXMge1xuICAgICAgICAgICAgdVRleHR1cmVNYXRyaXg6bWF0M3gzPGYzMj4sXG4gICAgICAgIH1cblxuICAgICAgICBAZ3JvdXAoMikgQGJpbmRpbmcoMikgdmFyPHVuaWZvcm0+IHRleHR1cmVVbmlmb3JtcyA6IFRleHR1cmVVbmlmb3JtcztcbiAgICAgICAgYFxuICAgICksXG4gICAgbWFpbjogKFxuICAgICAgLyogd2dzbCAqL1xuICAgICAgYFxuICAgICAgICAgICAgdXYgPSAodGV4dHVyZVVuaWZvcm1zLnVUZXh0dXJlTWF0cml4ICogdmVjMyh1diwgMS4wKSkueHk7XG4gICAgICAgIGBcbiAgICApXG4gIH0sXG4gIGZyYWdtZW50OiB7XG4gICAgaGVhZGVyOiAoXG4gICAgICAvKiB3Z3NsICovXG4gICAgICBgXG4gICAgICAgICAgICBAZ3JvdXAoMikgQGJpbmRpbmcoMCkgdmFyIHVUZXh0dXJlOiB0ZXh0dXJlXzJkPGYzMj47XG4gICAgICAgICAgICBAZ3JvdXAoMikgQGJpbmRpbmcoMSkgdmFyIHVTYW1wbGVyOiBzYW1wbGVyO1xuXG5cbiAgICAgICAgYFxuICAgICksXG4gICAgbWFpbjogKFxuICAgICAgLyogd2dzbCAqL1xuICAgICAgYFxuICAgICAgICAgICAgb3V0Q29sb3IgPSB0ZXh0dXJlU2FtcGxlKHVUZXh0dXJlLCB1U2FtcGxlciwgdlVWKTtcbiAgICAgICAgYFxuICAgIClcbiAgfVxufTtcbmNvbnN0IHRleHR1cmVCaXRHbCA9IHtcbiAgbmFtZTogXCJ0ZXh0dXJlLWJpdFwiLFxuICB2ZXJ0ZXg6IHtcbiAgICBoZWFkZXI6IChcbiAgICAgIC8qIGdsc2wgKi9cbiAgICAgIGBcbiAgICAgICAgICAgIHVuaWZvcm0gbWF0MyB1VGV4dHVyZU1hdHJpeDtcbiAgICAgICAgYFxuICAgICksXG4gICAgbWFpbjogKFxuICAgICAgLyogZ2xzbCAqL1xuICAgICAgYFxuICAgICAgICAgICAgdXYgPSAodVRleHR1cmVNYXRyaXggKiB2ZWMzKHV2LCAxLjApKS54eTtcbiAgICAgICAgYFxuICAgIClcbiAgfSxcbiAgZnJhZ21lbnQ6IHtcbiAgICBoZWFkZXI6IChcbiAgICAgIC8qIGdsc2wgKi9cbiAgICAgIGBcbiAgICAgICAgdW5pZm9ybSBzYW1wbGVyMkQgdVRleHR1cmU7XG5cblxuICAgICAgICBgXG4gICAgKSxcbiAgICBtYWluOiAoXG4gICAgICAvKiBnbHNsICovXG4gICAgICBgXG4gICAgICAgICAgICBvdXRDb2xvciA9IHRleHR1cmUodVRleHR1cmUsIHZVVik7XG4gICAgICAgIGBcbiAgICApXG4gIH1cbn07XG5cbmV4cG9ydCB7IHRleHR1cmVCaXQsIHRleHR1cmVCaXRHbCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dGV4dHVyZUJpdC5tanMubWFwXG4iLCJpbXBvcnQgeyB3YXJuIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy93YXJuLm1qcyc7XG5pbXBvcnQgeyBnZXRBdHRyaWJ1dGVJbmZvRnJvbUZvcm1hdCB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9nZW9tZXRyeS91dGlscy9nZXRBdHRyaWJ1dGVJbmZvRnJvbUZvcm1hdC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGVuc3VyZUF0dHJpYnV0ZXMoZ2VvbWV0cnksIGV4dHJhY3RlZERhdGEpIHtcbiAgZm9yIChjb25zdCBpIGluIGdlb21ldHJ5LmF0dHJpYnV0ZXMpIHtcbiAgICBjb25zdCBhdHRyaWJ1dGUgPSBnZW9tZXRyeS5hdHRyaWJ1dGVzW2ldO1xuICAgIGNvbnN0IGF0dHJpYnV0ZURhdGEgPSBleHRyYWN0ZWREYXRhW2ldO1xuICAgIGlmIChhdHRyaWJ1dGVEYXRhKSB7XG4gICAgICBhdHRyaWJ1dGUuZm9ybWF0ID8/IChhdHRyaWJ1dGUuZm9ybWF0ID0gYXR0cmlidXRlRGF0YS5mb3JtYXQpO1xuICAgICAgYXR0cmlidXRlLm9mZnNldCA/PyAoYXR0cmlidXRlLm9mZnNldCA9IGF0dHJpYnV0ZURhdGEub2Zmc2V0KTtcbiAgICAgIGF0dHJpYnV0ZS5pbnN0YW5jZSA/PyAoYXR0cmlidXRlLmluc3RhbmNlID0gYXR0cmlidXRlRGF0YS5pbnN0YW5jZSk7XG4gICAgfSBlbHNlIGlmICghYXR0cmlidXRlLmZvcm1hdCkge1xuICAgICAgd2FybihgQXR0cmlidXRlICR7aX0gaXMgbm90IHByZXNlbnQgaW4gdGhlIHNoYWRlciwgYnV0IGlzIHByZXNlbnQgaW4gdGhlIGdlb21ldHJ5LiBVbmFibGUgdG8gaW5mZXIgYXR0cmlidXRlIGRldGFpbHMuYCk7XG4gICAgfVxuICB9XG4gIGVuc3VyZVN0YXJ0QW5kU3RyaWRlKGdlb21ldHJ5KTtcbn1cbmZ1bmN0aW9uIGVuc3VyZVN0YXJ0QW5kU3RyaWRlKGdlb21ldHJ5KSB7XG4gIGNvbnN0IHsgYnVmZmVycywgYXR0cmlidXRlcyB9ID0gZ2VvbWV0cnk7XG4gIGNvbnN0IHRlbXBTdHJpZGUgPSB7fTtcbiAgY29uc3QgdGVtcFN0YXJ0ID0ge307XG4gIGZvciAoY29uc3QgaiBpbiBidWZmZXJzKSB7XG4gICAgY29uc3QgYnVmZmVyID0gYnVmZmVyc1tqXTtcbiAgICB0ZW1wU3RyaWRlW2J1ZmZlci51aWRdID0gMDtcbiAgICB0ZW1wU3RhcnRbYnVmZmVyLnVpZF0gPSAwO1xuICB9XG4gIGZvciAoY29uc3QgaiBpbiBhdHRyaWJ1dGVzKSB7XG4gICAgY29uc3QgYXR0cmlidXRlID0gYXR0cmlidXRlc1tqXTtcbiAgICB0ZW1wU3RyaWRlW2F0dHJpYnV0ZS5idWZmZXIudWlkXSArPSBnZXRBdHRyaWJ1dGVJbmZvRnJvbUZvcm1hdChhdHRyaWJ1dGUuZm9ybWF0KS5zdHJpZGU7XG4gIH1cbiAgZm9yIChjb25zdCBqIGluIGF0dHJpYnV0ZXMpIHtcbiAgICBjb25zdCBhdHRyaWJ1dGUgPSBhdHRyaWJ1dGVzW2pdO1xuICAgIGF0dHJpYnV0ZS5zdHJpZGUgPz8gKGF0dHJpYnV0ZS5zdHJpZGUgPSB0ZW1wU3RyaWRlW2F0dHJpYnV0ZS5idWZmZXIudWlkXSk7XG4gICAgYXR0cmlidXRlLnN0YXJ0ID8/IChhdHRyaWJ1dGUuc3RhcnQgPSB0ZW1wU3RhcnRbYXR0cmlidXRlLmJ1ZmZlci51aWRdKTtcbiAgICB0ZW1wU3RhcnRbYXR0cmlidXRlLmJ1ZmZlci51aWRdICs9IGdldEF0dHJpYnV0ZUluZm9Gcm9tRm9ybWF0KGF0dHJpYnV0ZS5mb3JtYXQpLnN0cmlkZTtcbiAgfVxufVxuXG5leHBvcnQgeyBlbnN1cmVBdHRyaWJ1dGVzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1lbnN1cmVBdHRyaWJ1dGVzLm1qcy5tYXBcbiIsImltcG9ydCB7IFNURU5DSUxfTU9ERVMgfSBmcm9tICcuLi8uLi9zaGFyZWQvc3RhdGUvY29uc3QubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBHcHVTdGVuY2lsTW9kZXNUb1BpeGkgPSBbXTtcbkdwdVN0ZW5jaWxNb2Rlc1RvUGl4aVtTVEVOQ0lMX01PREVTLk5PTkVdID0gdm9pZCAwO1xuR3B1U3RlbmNpbE1vZGVzVG9QaXhpW1NURU5DSUxfTU9ERVMuRElTQUJMRURdID0ge1xuICBzdGVuY2lsV3JpdGVNYXNrOiAwLFxuICBzdGVuY2lsUmVhZE1hc2s6IDBcbn07XG5HcHVTdGVuY2lsTW9kZXNUb1BpeGlbU1RFTkNJTF9NT0RFUy5SRU5ERVJJTkdfTUFTS19BRERdID0ge1xuICBzdGVuY2lsRnJvbnQ6IHtcbiAgICBjb21wYXJlOiBcImVxdWFsXCIsXG4gICAgcGFzc09wOiBcImluY3JlbWVudC1jbGFtcFwiXG4gIH0sXG4gIHN0ZW5jaWxCYWNrOiB7XG4gICAgY29tcGFyZTogXCJlcXVhbFwiLFxuICAgIHBhc3NPcDogXCJpbmNyZW1lbnQtY2xhbXBcIlxuICB9XG59O1xuR3B1U3RlbmNpbE1vZGVzVG9QaXhpW1NURU5DSUxfTU9ERVMuUkVOREVSSU5HX01BU0tfUkVNT1ZFXSA9IHtcbiAgc3RlbmNpbEZyb250OiB7XG4gICAgY29tcGFyZTogXCJlcXVhbFwiLFxuICAgIHBhc3NPcDogXCJkZWNyZW1lbnQtY2xhbXBcIlxuICB9LFxuICBzdGVuY2lsQmFjazoge1xuICAgIGNvbXBhcmU6IFwiZXF1YWxcIixcbiAgICBwYXNzT3A6IFwiZGVjcmVtZW50LWNsYW1wXCJcbiAgfVxufTtcbkdwdVN0ZW5jaWxNb2Rlc1RvUGl4aVtTVEVOQ0lMX01PREVTLk1BU0tfQUNUSVZFXSA9IHtcbiAgc3RlbmNpbFdyaXRlTWFzazogMCxcbiAgc3RlbmNpbEZyb250OiB7XG4gICAgY29tcGFyZTogXCJlcXVhbFwiLFxuICAgIHBhc3NPcDogXCJrZWVwXCJcbiAgfSxcbiAgc3RlbmNpbEJhY2s6IHtcbiAgICBjb21wYXJlOiBcImVxdWFsXCIsXG4gICAgcGFzc09wOiBcImtlZXBcIlxuICB9XG59O1xuR3B1U3RlbmNpbE1vZGVzVG9QaXhpW1NURU5DSUxfTU9ERVMuSU5WRVJTRV9NQVNLX0FDVElWRV0gPSB7XG4gIHN0ZW5jaWxXcml0ZU1hc2s6IDAsXG4gIHN0ZW5jaWxGcm9udDoge1xuICAgIGNvbXBhcmU6IFwibm90LWVxdWFsXCIsXG4gICAgcGFzc09wOiBcImtlZXBcIlxuICB9LFxuICBzdGVuY2lsQmFjazoge1xuICAgIGNvbXBhcmU6IFwibm90LWVxdWFsXCIsXG4gICAgcGFzc09wOiBcImtlZXBcIlxuICB9XG59O1xuXG5leHBvcnQgeyBHcHVTdGVuY2lsTW9kZXNUb1BpeGkgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUdwdVN0ZW5jaWxNb2Rlc1RvUGl4aS5tanMubWFwXG4iLCJpbXBvcnQgeyB1bnNhZmVFdmFsU3VwcG9ydGVkIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvYnJvd3Nlci91bnNhZmVFdmFsU3VwcG9ydGVkLm1qcyc7XG5pbXBvcnQgeyBCdWZmZXIgfSBmcm9tICcuLi9idWZmZXIvQnVmZmVyLm1qcyc7XG5pbXBvcnQgeyBCdWZmZXJVc2FnZSB9IGZyb20gJy4uL2J1ZmZlci9jb25zdC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIFVib1N5c3RlbSB7XG4gIGNvbnN0cnVjdG9yKGFkYXB0b3IpIHtcbiAgICAvKiogQ2FjaGUgb2YgdW5pZm9ybSBidWZmZXIgbGF5b3V0cyBhbmQgc3luYyBmdW5jdGlvbnMsIHNvIHdlIGRvbid0IGhhdmUgdG8gcmUtY3JlYXRlIHRoZW0gKi9cbiAgICB0aGlzLl9zeW5jRnVuY3Rpb25IYXNoID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgdGhpcy5fYWRhcHRvciA9IGFkYXB0b3I7XG4gICAgdGhpcy5fc3lzdGVtQ2hlY2soKTtcbiAgfVxuICAvKipcbiAgICogT3ZlcnJpZGFibGUgZnVuY3Rpb24gYnkgYHBpeGkuanMvdW5zYWZlLWV2YWxgIHRvIHNpbGVuY2VcbiAgICogdGhyb3dpbmcgYW4gZXJyb3IgaWYgcGxhdGZvcm0gZG9lc24ndCBzdXBwb3J0IHVuc2FmZS1ldmFscy5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9zeXN0ZW1DaGVjaygpIHtcbiAgICBpZiAoIXVuc2FmZUV2YWxTdXBwb3J0ZWQoKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ3VycmVudCBlbnZpcm9ubWVudCBkb2VzIG5vdCBhbGxvdyB1bnNhZmUtZXZhbCwgcGxlYXNlIHVzZSBwaXhpLmpzL3Vuc2FmZS1ldmFsIG1vZHVsZSB0byBlbmFibGUgc3VwcG9ydC5cIik7XG4gICAgfVxuICB9XG4gIGVuc3VyZVVuaWZvcm1Hcm91cCh1bmlmb3JtR3JvdXApIHtcbiAgICBjb25zdCB1bmlmb3JtRGF0YSA9IHRoaXMuZ2V0VW5pZm9ybUdyb3VwRGF0YSh1bmlmb3JtR3JvdXApO1xuICAgIHVuaWZvcm1Hcm91cC5idWZmZXIgfHwgKHVuaWZvcm1Hcm91cC5idWZmZXIgPSBuZXcgQnVmZmVyKHtcbiAgICAgIGRhdGE6IG5ldyBGbG9hdDMyQXJyYXkodW5pZm9ybURhdGEubGF5b3V0LnNpemUgLyA0KSxcbiAgICAgIHVzYWdlOiBCdWZmZXJVc2FnZS5VTklGT1JNIHwgQnVmZmVyVXNhZ2UuQ09QWV9EU1RcbiAgICB9KSk7XG4gIH1cbiAgZ2V0VW5pZm9ybUdyb3VwRGF0YSh1bmlmb3JtR3JvdXApIHtcbiAgICByZXR1cm4gdGhpcy5fc3luY0Z1bmN0aW9uSGFzaFt1bmlmb3JtR3JvdXAuX3NpZ25hdHVyZV0gfHwgdGhpcy5faW5pdFVuaWZvcm1Hcm91cCh1bmlmb3JtR3JvdXApO1xuICB9XG4gIF9pbml0VW5pZm9ybUdyb3VwKHVuaWZvcm1Hcm91cCkge1xuICAgIGNvbnN0IHVuaWZvcm1Hcm91cFNpZ25hdHVyZSA9IHVuaWZvcm1Hcm91cC5fc2lnbmF0dXJlO1xuICAgIGxldCB1bmlmb3JtRGF0YSA9IHRoaXMuX3N5bmNGdW5jdGlvbkhhc2hbdW5pZm9ybUdyb3VwU2lnbmF0dXJlXTtcbiAgICBpZiAoIXVuaWZvcm1EYXRhKSB7XG4gICAgICBjb25zdCBlbGVtZW50cyA9IE9iamVjdC5rZXlzKHVuaWZvcm1Hcm91cC51bmlmb3JtU3RydWN0dXJlcykubWFwKChpKSA9PiB1bmlmb3JtR3JvdXAudW5pZm9ybVN0cnVjdHVyZXNbaV0pO1xuICAgICAgY29uc3QgbGF5b3V0ID0gdGhpcy5fYWRhcHRvci5jcmVhdGVVYm9FbGVtZW50cyhlbGVtZW50cyk7XG4gICAgICBjb25zdCBzeW5jRnVuY3Rpb24gPSB0aGlzLl9nZW5lcmF0ZVVib1N5bmMobGF5b3V0LnVib0VsZW1lbnRzKTtcbiAgICAgIHVuaWZvcm1EYXRhID0gdGhpcy5fc3luY0Z1bmN0aW9uSGFzaFt1bmlmb3JtR3JvdXBTaWduYXR1cmVdID0ge1xuICAgICAgICBsYXlvdXQsXG4gICAgICAgIHN5bmNGdW5jdGlvblxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX3N5bmNGdW5jdGlvbkhhc2hbdW5pZm9ybUdyb3VwU2lnbmF0dXJlXTtcbiAgfVxuICBfZ2VuZXJhdGVVYm9TeW5jKHVib0VsZW1lbnRzKSB7XG4gICAgcmV0dXJuIHRoaXMuX2FkYXB0b3IuZ2VuZXJhdGVVYm9TeW5jKHVib0VsZW1lbnRzKTtcbiAgfVxuICBzeW5jVW5pZm9ybUdyb3VwKHVuaWZvcm1Hcm91cCwgZGF0YSwgb2Zmc2V0KSB7XG4gICAgY29uc3QgdW5pZm9ybUdyb3VwRGF0YSA9IHRoaXMuZ2V0VW5pZm9ybUdyb3VwRGF0YSh1bmlmb3JtR3JvdXApO1xuICAgIHVuaWZvcm1Hcm91cC5idWZmZXIgfHwgKHVuaWZvcm1Hcm91cC5idWZmZXIgPSBuZXcgQnVmZmVyKHtcbiAgICAgIGRhdGE6IG5ldyBGbG9hdDMyQXJyYXkodW5pZm9ybUdyb3VwRGF0YS5sYXlvdXQuc2l6ZSAvIDQpLFxuICAgICAgdXNhZ2U6IEJ1ZmZlclVzYWdlLlVOSUZPUk0gfCBCdWZmZXJVc2FnZS5DT1BZX0RTVFxuICAgIH0pKTtcbiAgICBsZXQgZGF0YUludDMyID0gbnVsbDtcbiAgICBpZiAoIWRhdGEpIHtcbiAgICAgIGRhdGEgPSB1bmlmb3JtR3JvdXAuYnVmZmVyLmRhdGE7XG4gICAgICBkYXRhSW50MzIgPSB1bmlmb3JtR3JvdXAuYnVmZmVyLmRhdGFJbnQzMjtcbiAgICB9XG4gICAgb2Zmc2V0IHx8IChvZmZzZXQgPSAwKTtcbiAgICB1bmlmb3JtR3JvdXBEYXRhLnN5bmNGdW5jdGlvbih1bmlmb3JtR3JvdXAudW5pZm9ybXMsIGRhdGEsIGRhdGFJbnQzMiwgb2Zmc2V0KTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICB1cGRhdGVVbmlmb3JtR3JvdXAodW5pZm9ybUdyb3VwKSB7XG4gICAgaWYgKHVuaWZvcm1Hcm91cC5pc1N0YXRpYyAmJiAhdW5pZm9ybUdyb3VwLl9kaXJ0eUlkKSByZXR1cm4gZmFsc2U7XG4gICAgdW5pZm9ybUdyb3VwLl9kaXJ0eUlkID0gMDtcbiAgICBjb25zdCBzeW5jZWQgPSB0aGlzLnN5bmNVbmlmb3JtR3JvdXAodW5pZm9ybUdyb3VwKTtcbiAgICB1bmlmb3JtR3JvdXAuYnVmZmVyLnVwZGF0ZSgpO1xuICAgIHJldHVybiBzeW5jZWQ7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLl9zeW5jRnVuY3Rpb25IYXNoID0gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgeyBVYm9TeXN0ZW0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVVib1N5c3RlbS5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IHVuaWZvcm1QYXJzZXJzID0gW1xuICAvLyB1cGxvYWRpbmcgcGl4aSBtYXRyaXggb2JqZWN0IHRvIG1hdDNcbiAge1xuICAgIHR5cGU6IFwibWF0M3gzPGYzMj5cIixcbiAgICB0ZXN0OiAoZGF0YSkgPT4ge1xuICAgICAgY29uc3QgdmFsdWUgPSBkYXRhLnZhbHVlO1xuICAgICAgcmV0dXJuIHZhbHVlLmEgIT09IHZvaWQgMDtcbiAgICB9LFxuICAgIHVibzogYFxuICAgICAgICAgICAgdmFyIG1hdHJpeCA9IHV2W25hbWVdLnRvQXJyYXkodHJ1ZSk7XG4gICAgICAgICAgICBkYXRhW29mZnNldF0gPSBtYXRyaXhbMF07XG4gICAgICAgICAgICBkYXRhW29mZnNldCArIDFdID0gbWF0cml4WzFdO1xuICAgICAgICAgICAgZGF0YVtvZmZzZXQgKyAyXSA9IG1hdHJpeFsyXTtcbiAgICAgICAgICAgIGRhdGFbb2Zmc2V0ICsgNF0gPSBtYXRyaXhbM107XG4gICAgICAgICAgICBkYXRhW29mZnNldCArIDVdID0gbWF0cml4WzRdO1xuICAgICAgICAgICAgZGF0YVtvZmZzZXQgKyA2XSA9IG1hdHJpeFs1XTtcbiAgICAgICAgICAgIGRhdGFbb2Zmc2V0ICsgOF0gPSBtYXRyaXhbNl07XG4gICAgICAgICAgICBkYXRhW29mZnNldCArIDldID0gbWF0cml4WzddO1xuICAgICAgICAgICAgZGF0YVtvZmZzZXQgKyAxMF0gPSBtYXRyaXhbOF07XG4gICAgICAgIGAsXG4gICAgdW5pZm9ybTogYFxuICAgICAgICAgICAgZ2wudW5pZm9ybU1hdHJpeDNmdih1ZFtuYW1lXS5sb2NhdGlvbiwgZmFsc2UsIHV2W25hbWVdLnRvQXJyYXkodHJ1ZSkpO1xuICAgICAgICBgXG4gIH0sXG4gIC8vIHVwbG9hZGluZyBhIHBpeGkgcmVjdGFuZ2xlIGFzIGEgdmVjNFxuICB7XG4gICAgdHlwZTogXCJ2ZWM0PGYzMj5cIixcbiAgICB0ZXN0OiAoZGF0YSkgPT4gZGF0YS50eXBlID09PSBcInZlYzQ8ZjMyPlwiICYmIGRhdGEuc2l6ZSA9PT0gMSAmJiBkYXRhLnZhbHVlLndpZHRoICE9PSB2b2lkIDAsXG4gICAgdWJvOiBgXG4gICAgICAgICAgICB2ID0gdXZbbmFtZV07XG4gICAgICAgICAgICBkYXRhW29mZnNldF0gPSB2Lng7XG4gICAgICAgICAgICBkYXRhW29mZnNldCArIDFdID0gdi55O1xuICAgICAgICAgICAgZGF0YVtvZmZzZXQgKyAyXSA9IHYud2lkdGg7XG4gICAgICAgICAgICBkYXRhW29mZnNldCArIDNdID0gdi5oZWlnaHQ7XG4gICAgICAgIGAsXG4gICAgdW5pZm9ybTogYFxuICAgICAgICAgICAgY3YgPSB1ZFtuYW1lXS52YWx1ZTtcbiAgICAgICAgICAgIHYgPSB1dltuYW1lXTtcbiAgICAgICAgICAgIGlmIChjdlswXSAhPT0gdi54IHx8IGN2WzFdICE9PSB2LnkgfHwgY3ZbMl0gIT09IHYud2lkdGggfHwgY3ZbM10gIT09IHYuaGVpZ2h0KSB7XG4gICAgICAgICAgICAgICAgY3ZbMF0gPSB2Lng7XG4gICAgICAgICAgICAgICAgY3ZbMV0gPSB2Lnk7XG4gICAgICAgICAgICAgICAgY3ZbMl0gPSB2LndpZHRoO1xuICAgICAgICAgICAgICAgIGN2WzNdID0gdi5oZWlnaHQ7XG4gICAgICAgICAgICAgICAgZ2wudW5pZm9ybTRmKHVkW25hbWVdLmxvY2F0aW9uLCB2LngsIHYueSwgdi53aWR0aCwgdi5oZWlnaHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICBgXG4gIH0sXG4gIC8vIHVwbG9hZGluZyBhIHBpeGkgcG9pbnQgYXMgYSB2ZWMyXG4gIHtcbiAgICB0eXBlOiBcInZlYzI8ZjMyPlwiLFxuICAgIHRlc3Q6IChkYXRhKSA9PiBkYXRhLnR5cGUgPT09IFwidmVjMjxmMzI+XCIgJiYgZGF0YS5zaXplID09PSAxICYmIGRhdGEudmFsdWUueCAhPT0gdm9pZCAwLFxuICAgIHVibzogYFxuICAgICAgICAgICAgdiA9IHV2W25hbWVdO1xuICAgICAgICAgICAgZGF0YVtvZmZzZXRdID0gdi54O1xuICAgICAgICAgICAgZGF0YVtvZmZzZXQgKyAxXSA9IHYueTtcbiAgICAgICAgYCxcbiAgICB1bmlmb3JtOiBgXG4gICAgICAgICAgICBjdiA9IHVkW25hbWVdLnZhbHVlO1xuICAgICAgICAgICAgdiA9IHV2W25hbWVdO1xuICAgICAgICAgICAgaWYgKGN2WzBdICE9PSB2LnggfHwgY3ZbMV0gIT09IHYueSkge1xuICAgICAgICAgICAgICAgIGN2WzBdID0gdi54O1xuICAgICAgICAgICAgICAgIGN2WzFdID0gdi55O1xuICAgICAgICAgICAgICAgIGdsLnVuaWZvcm0yZih1ZFtuYW1lXS5sb2NhdGlvbiwgdi54LCB2LnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICBgXG4gIH0sXG4gIC8vIHVwbG9hZGluZyBhIHBpeGkgY29sb3IgYXMgYSB2ZWM0XG4gIHtcbiAgICB0eXBlOiBcInZlYzQ8ZjMyPlwiLFxuICAgIHRlc3Q6IChkYXRhKSA9PiBkYXRhLnR5cGUgPT09IFwidmVjNDxmMzI+XCIgJiYgZGF0YS5zaXplID09PSAxICYmIGRhdGEudmFsdWUucmVkICE9PSB2b2lkIDAsXG4gICAgdWJvOiBgXG4gICAgICAgICAgICB2ID0gdXZbbmFtZV07XG4gICAgICAgICAgICBkYXRhW29mZnNldF0gPSB2LnJlZDtcbiAgICAgICAgICAgIGRhdGFbb2Zmc2V0ICsgMV0gPSB2LmdyZWVuO1xuICAgICAgICAgICAgZGF0YVtvZmZzZXQgKyAyXSA9IHYuYmx1ZTtcbiAgICAgICAgICAgIGRhdGFbb2Zmc2V0ICsgM10gPSB2LmFscGhhO1xuICAgICAgICBgLFxuICAgIHVuaWZvcm06IGBcbiAgICAgICAgICAgIGN2ID0gdWRbbmFtZV0udmFsdWU7XG4gICAgICAgICAgICB2ID0gdXZbbmFtZV07XG4gICAgICAgICAgICBpZiAoY3ZbMF0gIT09IHYucmVkIHx8IGN2WzFdICE9PSB2LmdyZWVuIHx8IGN2WzJdICE9PSB2LmJsdWUgfHwgY3ZbM10gIT09IHYuYWxwaGEpIHtcbiAgICAgICAgICAgICAgICBjdlswXSA9IHYucmVkO1xuICAgICAgICAgICAgICAgIGN2WzFdID0gdi5ncmVlbjtcbiAgICAgICAgICAgICAgICBjdlsyXSA9IHYuYmx1ZTtcbiAgICAgICAgICAgICAgICBjdlszXSA9IHYuYWxwaGE7XG4gICAgICAgICAgICAgICAgZ2wudW5pZm9ybTRmKHVkW25hbWVdLmxvY2F0aW9uLCB2LnJlZCwgdi5ncmVlbiwgdi5ibHVlLCB2LmFscGhhKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgYFxuICB9LFxuICAvLyB1cGxvYWRpbmcgYSBwaXhpIGNvbG9yIGFzIGEgdmVjM1xuICB7XG4gICAgdHlwZTogXCJ2ZWMzPGYzMj5cIixcbiAgICB0ZXN0OiAoZGF0YSkgPT4gZGF0YS50eXBlID09PSBcInZlYzM8ZjMyPlwiICYmIGRhdGEuc2l6ZSA9PT0gMSAmJiBkYXRhLnZhbHVlLnJlZCAhPT0gdm9pZCAwLFxuICAgIHVibzogYFxuICAgICAgICAgICAgdiA9IHV2W25hbWVdO1xuICAgICAgICAgICAgZGF0YVtvZmZzZXRdID0gdi5yZWQ7XG4gICAgICAgICAgICBkYXRhW29mZnNldCArIDFdID0gdi5ncmVlbjtcbiAgICAgICAgICAgIGRhdGFbb2Zmc2V0ICsgMl0gPSB2LmJsdWU7XG4gICAgICAgIGAsXG4gICAgdW5pZm9ybTogYFxuICAgICAgICAgICAgY3YgPSB1ZFtuYW1lXS52YWx1ZTtcbiAgICAgICAgICAgIHYgPSB1dltuYW1lXTtcbiAgICAgICAgICAgIGlmIChjdlswXSAhPT0gdi5yZWQgfHwgY3ZbMV0gIT09IHYuZ3JlZW4gfHwgY3ZbMl0gIT09IHYuYmx1ZSkge1xuICAgICAgICAgICAgICAgIGN2WzBdID0gdi5yZWQ7XG4gICAgICAgICAgICAgICAgY3ZbMV0gPSB2LmdyZWVuO1xuICAgICAgICAgICAgICAgIGN2WzJdID0gdi5ibHVlO1xuICAgICAgICAgICAgICAgIGdsLnVuaWZvcm0zZih1ZFtuYW1lXS5sb2NhdGlvbiwgdi5yZWQsIHYuZ3JlZW4sIHYuYmx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIGBcbiAgfVxuXTtcblxuZXhwb3J0IHsgdW5pZm9ybVBhcnNlcnMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVuaWZvcm1QYXJzZXJzLm1qcy5tYXBcbiIsImltcG9ydCB7IHVuaWZvcm1QYXJzZXJzIH0gZnJvbSAnLi91bmlmb3JtUGFyc2Vycy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGNvbXBpbGVCdWZmZXJTeW5jKHVib0VsZW1lbnRzLCBzaW5nbGVTZXR0ZXJzTWFwLCBhcnJheUdlbmVyYXRpb25GdW5jdGlvbikge1xuICBjb25zdCBmdW5jRnJhZ21lbnRzID0gW2BcbiAgICAgICAgdmFyIHYgPSBudWxsO1xuICAgICAgICB2YXIgdjIgPSBudWxsO1xuICAgICAgICB2YXIgdCA9IDA7XG4gICAgICAgIHZhciBpbmRleCA9IDA7XG4gICAgICAgIHZhciBuYW1lID0gbnVsbDtcbiAgICAgICAgdmFyIGFycmF5T2Zmc2V0ID0gbnVsbDtcbiAgICBgXTtcbiAgbGV0IHByZXYgPSAwO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHVib0VsZW1lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgdWJvRWxlbWVudCA9IHVib0VsZW1lbnRzW2ldO1xuICAgIGNvbnN0IG5hbWUgPSB1Ym9FbGVtZW50LmRhdGEubmFtZTtcbiAgICBsZXQgcGFyc2VkID0gZmFsc2U7XG4gICAgbGV0IG9mZnNldCA9IDA7XG4gICAgZm9yIChsZXQgaiA9IDA7IGogPCB1bmlmb3JtUGFyc2Vycy5sZW5ndGg7IGorKykge1xuICAgICAgY29uc3QgdW5pZm9ybVBhcnNlciA9IHVuaWZvcm1QYXJzZXJzW2pdO1xuICAgICAgaWYgKHVuaWZvcm1QYXJzZXIudGVzdCh1Ym9FbGVtZW50LmRhdGEpKSB7XG4gICAgICAgIG9mZnNldCA9IHVib0VsZW1lbnQub2Zmc2V0IC8gNDtcbiAgICAgICAgZnVuY0ZyYWdtZW50cy5wdXNoKFxuICAgICAgICAgIGBuYW1lID0gXCIke25hbWV9XCI7YCxcbiAgICAgICAgICBgb2Zmc2V0ICs9ICR7b2Zmc2V0IC0gcHJldn07YCxcbiAgICAgICAgICB1bmlmb3JtUGFyc2Vyc1tqXS51Ym9cbiAgICAgICAgKTtcbiAgICAgICAgcGFyc2VkID0gdHJ1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghcGFyc2VkKSB7XG4gICAgICBpZiAodWJvRWxlbWVudC5kYXRhLnNpemUgPiAxKSB7XG4gICAgICAgIG9mZnNldCA9IHVib0VsZW1lbnQub2Zmc2V0IC8gNDtcbiAgICAgICAgZnVuY0ZyYWdtZW50cy5wdXNoKGFycmF5R2VuZXJhdGlvbkZ1bmN0aW9uKHVib0VsZW1lbnQsIG9mZnNldCAtIHByZXYpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHRlbXBsYXRlID0gc2luZ2xlU2V0dGVyc01hcFt1Ym9FbGVtZW50LmRhdGEudHlwZV07XG4gICAgICAgIG9mZnNldCA9IHVib0VsZW1lbnQub2Zmc2V0IC8gNDtcbiAgICAgICAgZnVuY0ZyYWdtZW50cy5wdXNoKFxuICAgICAgICAgIC8qIHdnc2wgKi9cbiAgICAgICAgICBgXG4gICAgICAgICAgICAgICAgICAgIHYgPSB1di4ke25hbWV9O1xuICAgICAgICAgICAgICAgICAgICBvZmZzZXQgKz0gJHtvZmZzZXQgLSBwcmV2fTtcbiAgICAgICAgICAgICAgICAgICAgJHt0ZW1wbGF0ZX07XG4gICAgICAgICAgICAgICAgYFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgICBwcmV2ID0gb2Zmc2V0O1xuICB9XG4gIGNvbnN0IGZyYWdtZW50U3JjID0gZnVuY0ZyYWdtZW50cy5qb2luKFwiXFxuXCIpO1xuICByZXR1cm4gbmV3IEZ1bmN0aW9uKFxuICAgIFwidXZcIixcbiAgICBcImRhdGFcIixcbiAgICBcImRhdGFJbnQzMlwiLFxuICAgIFwib2Zmc2V0XCIsXG4gICAgZnJhZ21lbnRTcmNcbiAgKTtcbn1cblxuZXhwb3J0IHsgY29tcGlsZUJ1ZmZlclN5bmMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbXBpbGVCdWZmZXJTeW5jLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gbG9vcE1hdHJpeChjb2wsIHJvdykge1xuICBjb25zdCB0b3RhbCA9IGNvbCAqIHJvdztcbiAgcmV0dXJuIGBcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAke3RvdGFsfTsgaSsrKSB7XG4gICAgICAgICAgICBkYXRhW29mZnNldCArICgoKGkgLyAke2NvbH0pfDApICogNCkgKyAoaSAlICR7Y29sfSldID0gdltpXTtcbiAgICAgICAgfVxuICAgIGA7XG59XG5jb25zdCB1Ym9TeW5jRnVuY3Rpb25zU1RENDAgPSB7XG4gIGYzMjogYFxuICAgICAgICBkYXRhW29mZnNldF0gPSB2O2AsXG4gIGkzMjogYFxuICAgICAgICBkYXRhSW50MzJbb2Zmc2V0XSA9IHY7YCxcbiAgdTMyOiBgXG4gICAgICAgIGRhdGFJbnQzMltvZmZzZXRdID0gdjtgLFxuICBcInZlYzI8ZjMyPlwiOiBgXG4gICAgICAgIGRhdGFbb2Zmc2V0XSA9IHZbMF07XG4gICAgICAgIGRhdGFbb2Zmc2V0ICsgMV0gPSB2WzFdO2AsXG4gIFwidmVjMzxmMzI+XCI6IGBcbiAgICAgICAgZGF0YVtvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YVtvZmZzZXQgKyAxXSA9IHZbMV07XG4gICAgICAgIGRhdGFbb2Zmc2V0ICsgMl0gPSB2WzJdO2AsXG4gIFwidmVjNDxmMzI+XCI6IGBcbiAgICAgICAgZGF0YVtvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YVtvZmZzZXQgKyAxXSA9IHZbMV07XG4gICAgICAgIGRhdGFbb2Zmc2V0ICsgMl0gPSB2WzJdO1xuICAgICAgICBkYXRhW29mZnNldCArIDNdID0gdlszXTtgLFxuICBcInZlYzI8aTMyPlwiOiBgXG4gICAgICAgIGRhdGFJbnQzMltvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDFdID0gdlsxXTtgLFxuICBcInZlYzM8aTMyPlwiOiBgXG4gICAgICAgIGRhdGFJbnQzMltvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDFdID0gdlsxXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDJdID0gdlsyXTtgLFxuICBcInZlYzQ8aTMyPlwiOiBgXG4gICAgICAgIGRhdGFJbnQzMltvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDFdID0gdlsxXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDJdID0gdlsyXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDNdID0gdlszXTtgLFxuICBcInZlYzI8dTMyPlwiOiBgXG4gICAgICAgIGRhdGFJbnQzMltvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDFdID0gdlsxXTtgLFxuICBcInZlYzM8dTMyPlwiOiBgXG4gICAgICAgIGRhdGFJbnQzMltvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDFdID0gdlsxXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDJdID0gdlsyXTtgLFxuICBcInZlYzQ8dTMyPlwiOiBgXG4gICAgICAgIGRhdGFJbnQzMltvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDFdID0gdlsxXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDJdID0gdlsyXTtcbiAgICAgICAgZGF0YUludDMyW29mZnNldCArIDNdID0gdlszXTtgLFxuICBcIm1hdDJ4MjxmMzI+XCI6IGBcbiAgICAgICAgZGF0YVtvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YVtvZmZzZXQgKyAxXSA9IHZbMV07XG4gICAgICAgIGRhdGFbb2Zmc2V0ICsgNF0gPSB2WzJdO1xuICAgICAgICBkYXRhW29mZnNldCArIDVdID0gdlszXTtgLFxuICBcIm1hdDN4MzxmMzI+XCI6IGBcbiAgICAgICAgZGF0YVtvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YVtvZmZzZXQgKyAxXSA9IHZbMV07XG4gICAgICAgIGRhdGFbb2Zmc2V0ICsgMl0gPSB2WzJdO1xuICAgICAgICBkYXRhW29mZnNldCArIDRdID0gdlszXTtcbiAgICAgICAgZGF0YVtvZmZzZXQgKyA1XSA9IHZbNF07XG4gICAgICAgIGRhdGFbb2Zmc2V0ICsgNl0gPSB2WzVdO1xuICAgICAgICBkYXRhW29mZnNldCArIDhdID0gdls2XTtcbiAgICAgICAgZGF0YVtvZmZzZXQgKyA5XSA9IHZbN107XG4gICAgICAgIGRhdGFbb2Zmc2V0ICsgMTBdID0gdls4XTtgLFxuICBcIm1hdDR4NDxmMzI+XCI6IGBcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAxNjsgaSsrKSB7XG4gICAgICAgICAgICBkYXRhW29mZnNldCArIGldID0gdltpXTtcbiAgICAgICAgfWAsXG4gIFwibWF0M3gyPGYzMj5cIjogbG9vcE1hdHJpeCgzLCAyKSxcbiAgXCJtYXQ0eDI8ZjMyPlwiOiBsb29wTWF0cml4KDQsIDIpLFxuICBcIm1hdDJ4MzxmMzI+XCI6IGxvb3BNYXRyaXgoMiwgMyksXG4gIFwibWF0NHgzPGYzMj5cIjogbG9vcE1hdHJpeCg0LCAzKSxcbiAgXCJtYXQyeDQ8ZjMyPlwiOiBsb29wTWF0cml4KDIsIDQpLFxuICBcIm1hdDN4NDxmMzI+XCI6IGxvb3BNYXRyaXgoMywgNClcbn07XG5jb25zdCB1Ym9TeW5jRnVuY3Rpb25zV0dTTCA9IHtcbiAgLi4udWJvU3luY0Z1bmN0aW9uc1NURDQwLFxuICBcIm1hdDJ4MjxmMzI+XCI6IGBcbiAgICAgICAgZGF0YVtvZmZzZXRdID0gdlswXTtcbiAgICAgICAgZGF0YVtvZmZzZXQgKyAxXSA9IHZbMV07XG4gICAgICAgIGRhdGFbb2Zmc2V0ICsgMl0gPSB2WzJdO1xuICAgICAgICBkYXRhW29mZnNldCArIDNdID0gdlszXTtcbiAgICBgXG59O1xuXG5leHBvcnQgeyB1Ym9TeW5jRnVuY3Rpb25zU1RENDAsIHVib1N5bmNGdW5jdGlvbnNXR1NMIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11Ym9TeW5jRnVuY3Rpb25zLm1qcy5tYXBcbiIsImltcG9ydCBFdmVudEVtaXR0ZXIgZnJvbSAnZXZlbnRlbWl0dGVyMyc7XG5pbXBvcnQgeyB1aWQgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9kYXRhL3VpZC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIEJ1ZmZlclJlc291cmNlIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBCdWZmZXIgUmVzb3VyY2UuXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgZm9yIHRoZSBidWZmZXIgcmVzb3VyY2VcbiAgICogQHBhcmFtIG9wdGlvbnMuYnVmZmVyIC0gVGhlIHVuZGVybHlpbmcgYnVmZmVyIHRoYXQgdGhpcyByZXNvdXJjZSBpcyB1c2luZ1xuICAgKiBAcGFyYW0gb3B0aW9ucy5vZmZzZXQgLSBUaGUgb2Zmc2V0IG9mIHRoZSBidWZmZXIgdGhpcyByZXNvdXJjZSBpcyB1c2luZy5cbiAgICogSWYgbm90IHByb3ZpZGVkLCB0aGVuIGl0IHdpbGwgdXNlIHRoZSBvZmZzZXQgb2YgdGhlIGJ1ZmZlci5cbiAgICogQHBhcmFtIG9wdGlvbnMuc2l6ZSAtIFRoZSBzaXplIG9mIHRoZSBidWZmZXIgdGhpcyByZXNvdXJjZSBpcyB1c2luZy5cbiAgICogSWYgbm90IHByb3ZpZGVkLCB0aGVuIGl0IHdpbGwgdXNlIHRoZSBzaXplIG9mIHRoZSBidWZmZXIuXG4gICAqL1xuICBjb25zdHJ1Y3Rvcih7IGJ1ZmZlciwgb2Zmc2V0LCBzaXplIH0pIHtcbiAgICBzdXBlcigpO1xuICAgIC8qKlxuICAgICAqIGVtaXRzIHdoZW4gdGhlIHVuZGVybHlpbmcgYnVmZmVyIGhhcyBjaGFuZ2VkIHNoYXBlIChpLmUuIHJlc2l6ZWQpXG4gICAgICogbGV0dGluZyB0aGUgcmVuZGVyZXIga25vdyB0aGF0IGl0IG5lZWRzIHRvIGRpc2NhcmQgdGhlIG9sZCBidWZmZXIgb24gdGhlIEdQVSBhbmQgY3JlYXRlIGEgbmV3IG9uZVxuICAgICAqIEBldmVudCBjaGFuZ2VcbiAgICAgKi9cbiAgICAvKiogYSB1bmlxdWUgaWQgZm9yIHRoaXMgdW5pZm9ybSBncm91cCB1c2VkIHRocm91Z2ggdGhlIHJlbmRlcmVyICovXG4gICAgdGhpcy51aWQgPSB1aWQoXCJidWZmZXJcIik7XG4gICAgLyoqXG4gICAgICogYSByZXNvdXJjZSB0eXBlLCB1c2VkIHRvIGlkZW50aWZ5IGhvdyB0byBoYW5kbGUgaXQgd2hlbiBpdHMgaW4gYSBiaW5kIGdyb3VwIC8gc2hhZGVyIHJlc291cmNlXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fcmVzb3VyY2VUeXBlID0gXCJidWZmZXJSZXNvdXJjZVwiO1xuICAgIC8qKlxuICAgICAqIHRoZSByZXNvdXJjZSBpZCB1c2VkIGludGVybmFsbHkgYnkgdGhlIHJlbmRlcmVyIHRvIGJ1aWxkIGJpbmQgZ3JvdXAga2V5c1xuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX3Jlc291cmNlSWQgPSB1aWQoXCJyZXNvdXJjZVwiKTtcbiAgICAvKipcbiAgICAgKiBBIGNoZWVreSBoaW50IHRvIHRoZSBHTCByZW5kZXJlciB0byBsZXQgaXQga25vdyB0aGlzIGlzIGEgQnVmZmVyUmVzb3VyY2VcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9idWZmZXJSZXNvdXJjZSA9IHRydWU7XG4gICAgLyoqXG4gICAgICogSGFzIHRoZSBCdWZmZXIgcmVzb3VyY2UgYmVlbiBkZXN0cm95ZWQ/XG4gICAgICogQHJlYWRvbmx5XG4gICAgICovXG4gICAgdGhpcy5kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICB0aGlzLmJ1ZmZlciA9IGJ1ZmZlcjtcbiAgICB0aGlzLm9mZnNldCA9IG9mZnNldCB8IDA7XG4gICAgdGhpcy5zaXplID0gc2l6ZTtcbiAgICB0aGlzLmJ1ZmZlci5vbihcImNoYW5nZVwiLCB0aGlzLm9uQnVmZmVyQ2hhbmdlLCB0aGlzKTtcbiAgfVxuICAvKipcbiAgICogVGhlIEdDIHRyYWNrcyB0aGUgdW5kZXJseWluZyBidWZmZXIsIG5vdCB0aGlzIHJlc291cmNlIOKAlCBhIEdDIHN0YW1wIGhlcmUgKHNlZVxuICAgKiBCaW5kR3JvdXAuX3RvdWNoKSBtdXN0IGxhbmQgb24gdGhlIGJ1ZmZlciwgb3IgdGhlIEdDIGNvbGxlY3RzIGl0IHdoaWxlIGNhY2hlZFxuICAgKiBiaW5kIGdyb3VwcyBzdGlsbCByZWZlcmVuY2UgaXQuXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgZ2V0IF9nY0xhc3RVc2VkKCkge1xuICAgIHJldHVybiB0aGlzLmJ1ZmZlcj8uX2djTGFzdFVzZWQgPz8gLTE7XG4gIH1cbiAgc2V0IF9nY0xhc3RVc2VkKHZhbHVlKSB7XG4gICAgaWYgKHRoaXMuYnVmZmVyKSB0aGlzLmJ1ZmZlci5fZ2NMYXN0VXNlZCA9IHZhbHVlO1xuICB9XG4gIG9uQnVmZmVyQ2hhbmdlKCkge1xuICAgIHRoaXMuX3Jlc291cmNlSWQgPSB1aWQoXCJyZXNvdXJjZVwiKTtcbiAgICB0aGlzLmVtaXQoXCJjaGFuZ2VcIiwgdGhpcyk7XG4gIH1cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoaXMgcmVzb3VyY2UuIE1ha2Ugc3VyZSB0aGUgdW5kZXJseWluZyBidWZmZXIgaXMgbm90IHVzZWQgYW55d2hlcmUgZWxzZVxuICAgKiBpZiB5b3Ugd2FudCB0byBkZXN0cm95IGl0IGFzIHdlbGwsIG9yIGNvZGUgd2lsbCBleHBsb2RlXG4gICAqIEBwYXJhbSBkZXN0cm95QnVmZmVyIC0gU2hvdWxkIHRoZSB1bmRlcmx5aW5nIGJ1ZmZlciBiZSBkZXN0cm95ZWQgYXMgd2VsbD9cbiAgICovXG4gIGRlc3Ryb3koZGVzdHJveUJ1ZmZlciA9IGZhbHNlKSB7XG4gICAgdGhpcy5kZXN0cm95ZWQgPSB0cnVlO1xuICAgIGlmIChkZXN0cm95QnVmZmVyKSB7XG4gICAgICB0aGlzLmJ1ZmZlci5kZXN0cm95KCk7XG4gICAgfVxuICAgIHRoaXMuZW1pdChcImNoYW5nZVwiLCB0aGlzKTtcbiAgICB0aGlzLmJ1ZmZlciA9IG51bGw7XG4gICAgdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcbiAgfVxufVxuXG5leHBvcnQgeyBCdWZmZXJSZXNvdXJjZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QnVmZmVyUmVzb3VyY2UubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBnZXRUZXhlbFJhbmdlUmVjdHMoc3RhcnQsIGVuZCwgd2lkdGgsIGhlaWdodCwgb3V0KSB7XG4gIHN0YXJ0ID0gTWF0aC5tYXgoMCwgc3RhcnQpO1xuICBlbmQgPSBNYXRoLm1pbihlbmQsIHdpZHRoICogaGVpZ2h0KTtcbiAgaWYgKHN0YXJ0ID49IGVuZCkgcmV0dXJuIDA7XG4gIGNvbnN0IGZpcnN0Um93ID0gTWF0aC5mbG9vcihzdGFydCAvIHdpZHRoKTtcbiAgY29uc3QgZmlyc3RYID0gc3RhcnQgLSBmaXJzdFJvdyAqIHdpZHRoO1xuICBjb25zdCBsYXN0Um93ID0gTWF0aC5mbG9vcihlbmQgLyB3aWR0aCk7XG4gIGNvbnN0IGxhc3RYID0gZW5kIC0gbGFzdFJvdyAqIHdpZHRoO1xuICBpZiAoZmlyc3RSb3cgPT09IGxhc3RSb3cpIHtcbiAgICBvdXRbMF0uc2V0KGZpcnN0WCwgZmlyc3RSb3csIGxhc3RYIC0gZmlyc3RYLCAxKTtcbiAgICByZXR1cm4gMTtcbiAgfVxuICBsZXQgY291bnQgPSAwO1xuICBsZXQgZmlyc3RGdWxsUm93ID0gZmlyc3RSb3c7XG4gIGlmIChmaXJzdFggPiAwKSB7XG4gICAgb3V0W2NvdW50KytdLnNldChmaXJzdFgsIGZpcnN0Um93LCB3aWR0aCAtIGZpcnN0WCwgMSk7XG4gICAgZmlyc3RGdWxsUm93Kys7XG4gIH1cbiAgaWYgKGxhc3RSb3cgPiBmaXJzdEZ1bGxSb3cpIHtcbiAgICBvdXRbY291bnQrK10uc2V0KDAsIGZpcnN0RnVsbFJvdywgd2lkdGgsIGxhc3RSb3cgLSBmaXJzdEZ1bGxSb3cpO1xuICB9XG4gIGlmIChsYXN0WCA+IDApIHtcbiAgICBvdXRbY291bnQrK10uc2V0KDAsIGxhc3RSb3csIGxhc3RYLCAxKTtcbiAgfVxuICByZXR1cm4gY291bnQ7XG59XG5cbmV4cG9ydCB7IGdldFRleGVsUmFuZ2VSZWN0cyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Z2V0VGV4ZWxSYW5nZVJlY3RzLm1qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUNBLElBQU0sa0JBQWtCO0NBQ3RCLE1BQU07Q0FDTixRQUFRO0VBQ04sUUFFRTs7Ozs7Ozs7OztFQVdGLE1BRUU7Ozs7RUFLRixLQUVFOzs7Ozs7Q0FPSjtBQUNGO0FBQ0EsSUFBTSx3QkFBd0I7Q0FDNUIsR0FBRztDQUNILFFBQVE7RUFDTixHQUFHLGdCQUFnQjtFQUVuQixRQUFRLGdCQUFnQixPQUFPLE9BQU8sUUFBUSxZQUFZLFVBQVU7Q0FDdEU7QUFDRjtBQUNBLElBQU0sb0JBQW9CO0NBQ3hCLE1BQU07Q0FDTixRQUFRO0VBQ04sUUFFRTs7Ozs7O0VBT0YsTUFFRTs7OztFQUtGLEtBRUU7Ozs7OztDQU9KO0FBQ0Y7OztBQ3ZFQSxJQUFNLGFBQWE7Q0FDakIsTUFBTTtDQUNOLFFBQVE7RUFDTixRQUVFOzs7Ozs7OztFQVNGLE1BRUU7OztDQUlKO0NBQ0EsVUFBVTtFQUNSLFFBRUU7Ozs7OztFQU9GLE1BRUU7OztDQUlKO0FBQ0Y7QUFDQSxJQUFNLGVBQWU7Q0FDbkIsTUFBTTtDQUNOLFFBQVE7RUFDTixRQUVFOzs7RUFJRixNQUVFOzs7Q0FJSjtDQUNBLFVBQVU7RUFDUixRQUVFOzs7OztFQU1GLE1BRUU7OztDQUlKO0FBQ0Y7OztBQ3BFQSxTQUFTLGlCQUFpQixVQUFVLGVBQWU7Q0FDakQsS0FBSyxNQUFNLEtBQUssU0FBUyxZQUFZO0VBQ25DLE1BQU0sWUFBWSxTQUFTLFdBQVc7RUFDdEMsTUFBTSxnQkFBZ0IsY0FBYztFQUNwQyxJQUFJLGVBQWU7R0FDakIsVUFBVSxXQUFXLFVBQVUsU0FBUyxjQUFjO0dBQ3RELFVBQVUsV0FBVyxVQUFVLFNBQVMsY0FBYztHQUN0RCxVQUFVLGFBQWEsVUFBVSxXQUFXLGNBQWM7RUFDNUQsT0FBTyxJQUFJLENBQUMsVUFBVSxRQUNwQixLQUFLLGFBQWEsRUFBRSxrR0FBa0c7Q0FFMUg7Q0FDQSxxQkFBcUIsUUFBUTtBQUMvQjtBQUNBLFNBQVMscUJBQXFCLFVBQVU7Q0FDdEMsTUFBTSxFQUFFLFNBQVMsZUFBZTtDQUNoQyxNQUFNLGFBQWEsQ0FBQztDQUNwQixNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sS0FBSyxTQUFTO0VBQ3ZCLE1BQU0sU0FBUyxRQUFRO0VBQ3ZCLFdBQVcsT0FBTyxPQUFPO0VBQ3pCLFVBQVUsT0FBTyxPQUFPO0NBQzFCO0NBQ0EsS0FBSyxNQUFNLEtBQUssWUFBWTtFQUMxQixNQUFNLFlBQVksV0FBVztFQUM3QixXQUFXLFVBQVUsT0FBTyxRQUFRLDJCQUEyQixVQUFVLE1BQU0sQ0FBQyxDQUFDO0NBQ25GO0NBQ0EsS0FBSyxNQUFNLEtBQUssWUFBWTtFQUMxQixNQUFNLFlBQVksV0FBVztFQUM3QixVQUFVLFdBQVcsVUFBVSxTQUFTLFdBQVcsVUFBVSxPQUFPO0VBQ3BFLFVBQVUsVUFBVSxVQUFVLFFBQVEsVUFBVSxVQUFVLE9BQU87RUFDakUsVUFBVSxVQUFVLE9BQU8sUUFBUSwyQkFBMkIsVUFBVSxNQUFNLENBQUMsQ0FBQztDQUNsRjtBQUNGOzs7QUNsQ0EsSUFBTSx3QkFBd0IsQ0FBQztBQUMvQixzQkFBc0IsY0FBYyxRQUFRLEtBQUs7QUFDakQsc0JBQXNCLGNBQWMsWUFBWTtDQUM5QyxrQkFBa0I7Q0FDbEIsaUJBQWlCO0FBQ25CO0FBQ0Esc0JBQXNCLGNBQWMsc0JBQXNCO0NBQ3hELGNBQWM7RUFDWixTQUFTO0VBQ1QsUUFBUTtDQUNWO0NBQ0EsYUFBYTtFQUNYLFNBQVM7RUFDVCxRQUFRO0NBQ1Y7QUFDRjtBQUNBLHNCQUFzQixjQUFjLHlCQUF5QjtDQUMzRCxjQUFjO0VBQ1osU0FBUztFQUNULFFBQVE7Q0FDVjtDQUNBLGFBQWE7RUFDWCxTQUFTO0VBQ1QsUUFBUTtDQUNWO0FBQ0Y7QUFDQSxzQkFBc0IsY0FBYyxlQUFlO0NBQ2pELGtCQUFrQjtDQUNsQixjQUFjO0VBQ1osU0FBUztFQUNULFFBQVE7Q0FDVjtDQUNBLGFBQWE7RUFDWCxTQUFTO0VBQ1QsUUFBUTtDQUNWO0FBQ0Y7QUFDQSxzQkFBc0IsY0FBYyx1QkFBdUI7Q0FDekQsa0JBQWtCO0NBQ2xCLGNBQWM7RUFDWixTQUFTO0VBQ1QsUUFBUTtDQUNWO0NBQ0EsYUFBYTtFQUNYLFNBQVM7RUFDVCxRQUFRO0NBQ1Y7QUFDRjs7O0FDN0NBLElBQU0sWUFBTixNQUFnQjtDQUNkLFlBQVksU0FBUzs7RUFFbkIsS0FBSyxvQkFBb0MsdUJBQU8sT0FBTyxJQUFJO0VBQzNELEtBQUssV0FBVztFQUNoQixLQUFLLGFBQWE7Q0FDcEI7Ozs7OztDQU1BLGVBQWU7RUFDYixJQUFJLENBQUMsb0JBQW9CLEdBQ3ZCLE1BQU0sSUFBSSxNQUFNLDBHQUEwRztDQUU5SDtDQUNBLG1CQUFtQixjQUFjO0VBQy9CLE1BQU0sY0FBYyxLQUFLLG9CQUFvQixZQUFZO0VBQ3pELGFBQWEsV0FBVyxhQUFhLFNBQVMsSUFBSSxPQUFPO0dBQ3ZELE1BQU0sSUFBSSxhQUFhLFlBQVksT0FBTyxPQUFPLENBQUM7R0FDbEQsT0FBTyxZQUFZLFVBQVUsWUFBWTtFQUMzQyxDQUFDO0NBQ0g7Q0FDQSxvQkFBb0IsY0FBYztFQUNoQyxPQUFPLEtBQUssa0JBQWtCLGFBQWEsZUFBZSxLQUFLLGtCQUFrQixZQUFZO0NBQy9GO0NBQ0Esa0JBQWtCLGNBQWM7RUFDOUIsTUFBTSx3QkFBd0IsYUFBYTtFQUMzQyxJQUFJLGNBQWMsS0FBSyxrQkFBa0I7RUFDekMsSUFBSSxDQUFDLGFBQWE7R0FDaEIsTUFBTSxXQUFXLE9BQU8sS0FBSyxhQUFhLGlCQUFpQixDQUFDLENBQUMsS0FBSyxNQUFNLGFBQWEsa0JBQWtCLEVBQUU7R0FDekcsTUFBTSxTQUFTLEtBQUssU0FBUyxrQkFBa0IsUUFBUTtHQUN2RCxNQUFNLGVBQWUsS0FBSyxpQkFBaUIsT0FBTyxXQUFXO0dBQzdELGNBQWMsS0FBSyxrQkFBa0IseUJBQXlCO0lBQzVEO0lBQ0E7R0FDRjtFQUNGO0VBQ0EsT0FBTyxLQUFLLGtCQUFrQjtDQUNoQztDQUNBLGlCQUFpQixhQUFhO0VBQzVCLE9BQU8sS0FBSyxTQUFTLGdCQUFnQixXQUFXO0NBQ2xEO0NBQ0EsaUJBQWlCLGNBQWMsTUFBTSxRQUFRO0VBQzNDLE1BQU0sbUJBQW1CLEtBQUssb0JBQW9CLFlBQVk7RUFDOUQsYUFBYSxXQUFXLGFBQWEsU0FBUyxJQUFJLE9BQU87R0FDdkQsTUFBTSxJQUFJLGFBQWEsaUJBQWlCLE9BQU8sT0FBTyxDQUFDO0dBQ3ZELE9BQU8sWUFBWSxVQUFVLFlBQVk7RUFDM0MsQ0FBQztFQUNELElBQUksWUFBWTtFQUNoQixJQUFJLENBQUMsTUFBTTtHQUNULE9BQU8sYUFBYSxPQUFPO0dBQzNCLFlBQVksYUFBYSxPQUFPO0VBQ2xDO0VBQ0EsV0FBVyxTQUFTO0VBQ3BCLGlCQUFpQixhQUFhLGFBQWEsVUFBVSxNQUFNLFdBQVcsTUFBTTtFQUM1RSxPQUFPO0NBQ1Q7Q0FDQSxtQkFBbUIsY0FBYztFQUMvQixJQUFJLGFBQWEsWUFBWSxDQUFDLGFBQWEsVUFBVSxPQUFPO0VBQzVELGFBQWEsV0FBVztFQUN4QixNQUFNLFNBQVMsS0FBSyxpQkFBaUIsWUFBWTtFQUNqRCxhQUFhLE9BQU8sT0FBTztFQUMzQixPQUFPO0NBQ1Q7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxvQkFBb0I7Q0FDM0I7QUFDRjs7O0FDekVBLElBQU0saUJBQWlCO0NBRXJCO0VBQ0UsTUFBTTtFQUNOLE9BQU8sU0FBUztHQUVkLE9BRGMsS0FBSyxNQUNOLE1BQU0sS0FBSztFQUMxQjtFQUNBLEtBQUs7Ozs7Ozs7Ozs7OztFQVlMLFNBQVM7OztDQUdYO0NBRUE7RUFDRSxNQUFNO0VBQ04sT0FBTyxTQUFTLEtBQUssU0FBUyxlQUFlLEtBQUssU0FBUyxLQUFLLEtBQUssTUFBTSxVQUFVLEtBQUs7RUFDMUYsS0FBSzs7Ozs7OztFQU9MLFNBQVM7Ozs7Ozs7Ozs7O0NBV1g7Q0FFQTtFQUNFLE1BQU07RUFDTixPQUFPLFNBQVMsS0FBSyxTQUFTLGVBQWUsS0FBSyxTQUFTLEtBQUssS0FBSyxNQUFNLE1BQU0sS0FBSztFQUN0RixLQUFLOzs7OztFQUtMLFNBQVM7Ozs7Ozs7OztDQVNYO0NBRUE7RUFDRSxNQUFNO0VBQ04sT0FBTyxTQUFTLEtBQUssU0FBUyxlQUFlLEtBQUssU0FBUyxLQUFLLEtBQUssTUFBTSxRQUFRLEtBQUs7RUFDeEYsS0FBSzs7Ozs7OztFQU9MLFNBQVM7Ozs7Ozs7Ozs7O0NBV1g7Q0FFQTtFQUNFLE1BQU07RUFDTixPQUFPLFNBQVMsS0FBSyxTQUFTLGVBQWUsS0FBSyxTQUFTLEtBQUssS0FBSyxNQUFNLFFBQVEsS0FBSztFQUN4RixLQUFLOzs7Ozs7RUFNTCxTQUFTOzs7Ozs7Ozs7O0NBVVg7QUFDRjs7O0FDNUdBLFNBQVMsa0JBQWtCLGFBQWEsa0JBQWtCLHlCQUF5QjtDQUNqRixNQUFNLGdCQUFnQixDQUFDOzs7Ozs7O0tBT3BCO0NBQ0gsSUFBSSxPQUFPO0NBQ1gsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFlBQVksUUFBUSxLQUFLO0VBQzNDLE1BQU0sYUFBYSxZQUFZO0VBQy9CLE1BQU0sT0FBTyxXQUFXLEtBQUs7RUFDN0IsSUFBSSxTQUFTO0VBQ2IsSUFBSSxTQUFTO0VBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGVBQWUsUUFBUSxLQUV6QyxJQURzQixlQUFlLEVBQ3BCLENBQUMsS0FBSyxXQUFXLElBQUksR0FBRztHQUN2QyxTQUFTLFdBQVcsU0FBUztHQUM3QixjQUFjLEtBQ1osV0FBVyxLQUFLLEtBQ2hCLGFBQWEsU0FBUyxLQUFLLElBQzNCLGVBQWUsRUFBRSxDQUFDLEdBQ3BCO0dBQ0EsU0FBUztHQUNUO0VBQ0Y7RUFFRixJQUFJLENBQUMsUUFBUTtHQUNYLElBQUksV0FBVyxLQUFLLE9BQU8sR0FBRztJQUM1QixTQUFTLFdBQVcsU0FBUztJQUM3QixjQUFjLEtBQUssd0JBQXdCLFlBQVksU0FBUyxJQUFJLENBQUM7R0FDdkUsT0FBTztJQUNMLE1BQU0sV0FBVyxpQkFBaUIsV0FBVyxLQUFLO0lBQ2xELFNBQVMsV0FBVyxTQUFTO0lBQzdCLGNBQWMsS0FFWjs2QkFDbUIsS0FBSztnQ0FDRixTQUFTLEtBQUs7c0JBQ3hCLFNBQVM7aUJBRXZCO0dBQ0Y7RUFDRjtFQUNBLE9BQU87Q0FDVDtDQUNBLE1BQU0sY0FBYyxjQUFjLEtBQUssSUFBSTtDQUMzQyxPQUFPLElBQUksU0FDVCxNQUNBLFFBQ0EsYUFDQSxVQUNBLFdBQ0Y7QUFDRjs7O0FDekRBLFNBQVMsV0FBVyxLQUFLLEtBQUs7Q0FFNUIsT0FBTzs4QkFETyxNQUFNLElBRWM7bUNBQ0QsSUFBSSxtQkFBbUIsSUFBSTs7O0FBRzlEO0FBQ0EsSUFBTSx3QkFBd0I7Q0FDNUIsS0FBSzs7Q0FFTCxLQUFLOztDQUVMLEtBQUs7O0NBRUwsYUFBYTs7O0NBR2IsYUFBYTs7OztDQUliLGFBQWE7Ozs7O0NBS2IsYUFBYTs7O0NBR2IsYUFBYTs7OztDQUliLGFBQWE7Ozs7O0NBS2IsYUFBYTs7O0NBR2IsYUFBYTs7OztDQUliLGFBQWE7Ozs7O0NBS2IsZUFBZTs7Ozs7Q0FLZixlQUFlOzs7Ozs7Ozs7O0NBVWYsZUFBZTs7OztDQUlmLGVBQWUsV0FBVyxHQUFHLENBQUM7Q0FDOUIsZUFBZSxXQUFXLEdBQUcsQ0FBQztDQUM5QixlQUFlLFdBQVcsR0FBRyxDQUFDO0NBQzlCLGVBQWUsV0FBVyxHQUFHLENBQUM7Q0FDOUIsZUFBZSxXQUFXLEdBQUcsQ0FBQztDQUM5QixlQUFlLFdBQVcsR0FBRyxDQUFDO0FBQ2hDO0FBQ0EsSUFBTSx1QkFBdUI7Q0FDM0IsR0FBRztDQUNILGVBQWU7Ozs7OztBQU1qQjs7O0FDbEZBLElBQU0saUJBQU4sY0FBNkJBLHNCQUFhOzs7Ozs7Ozs7O0NBVXhDLFlBQVksRUFBRSxRQUFRLFFBQVEsUUFBUTtFQUNwQyxNQUFNOzs7Ozs7O0VBT04sS0FBSyxNQUFNLElBQUksUUFBUTs7Ozs7RUFLdkIsS0FBSyxnQkFBZ0I7Ozs7O0VBS3JCLEtBQUssY0FBYyxJQUFJLFVBQVU7Ozs7O0VBS2pDLEtBQUssa0JBQWtCOzs7OztFQUt2QixLQUFLLFlBQVk7RUFDakIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxTQUFTLFNBQVM7RUFDdkIsS0FBSyxPQUFPO0VBQ1osS0FBSyxPQUFPLEdBQUcsVUFBVSxLQUFLLGdCQUFnQixJQUFJO0NBQ3BEOzs7Ozs7O0NBT0EsSUFBSSxjQUFjO0VBQ2hCLE9BQU8sS0FBSyxRQUFRLGVBQWU7Q0FDckM7Q0FDQSxJQUFJLFlBQVksT0FBTztFQUNyQixJQUFJLEtBQUssUUFBUSxLQUFLLE9BQU8sY0FBYztDQUM3QztDQUNBLGlCQUFpQjtFQUNmLEtBQUssY0FBYyxJQUFJLFVBQVU7RUFDakMsS0FBSyxLQUFLLFVBQVUsSUFBSTtDQUMxQjs7Ozs7O0NBTUEsUUFBUSxnQkFBZ0IsT0FBTztFQUM3QixLQUFLLFlBQVk7RUFDakIsSUFBSSxlQUNGLEtBQUssT0FBTyxRQUFRO0VBRXRCLEtBQUssS0FBSyxVQUFVLElBQUk7RUFDeEIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxtQkFBbUI7Q0FDMUI7QUFDRjs7O0FDN0VBLFNBQVMsbUJBQW1CLE9BQU8sS0FBSyxPQUFPLFFBQVEsS0FBSztDQUMxRCxRQUFRLEtBQUssSUFBSSxHQUFHLEtBQUs7Q0FDekIsTUFBTSxLQUFLLElBQUksS0FBSyxRQUFRLE1BQU07Q0FDbEMsSUFBSSxTQUFTLEtBQUssT0FBTztDQUN6QixNQUFNLFdBQVcsS0FBSyxNQUFNLFFBQVEsS0FBSztDQUN6QyxNQUFNLFNBQVMsUUFBUSxXQUFXO0NBQ2xDLE1BQU0sVUFBVSxLQUFLLE1BQU0sTUFBTSxLQUFLO0NBQ3RDLE1BQU0sUUFBUSxNQUFNLFVBQVU7Q0FDOUIsSUFBSSxhQUFhLFNBQVM7RUFDeEIsSUFBSSxFQUFFLENBQUMsSUFBSSxRQUFRLFVBQVUsUUFBUSxRQUFRLENBQUM7RUFDOUMsT0FBTztDQUNUO0NBQ0EsSUFBSSxRQUFRO0NBQ1osSUFBSSxlQUFlO0NBQ25CLElBQUksU0FBUyxHQUFHO0VBQ2QsSUFBSSxRQUFRLENBQUMsSUFBSSxRQUFRLFVBQVUsUUFBUSxRQUFRLENBQUM7RUFDcEQ7Q0FDRjtDQUNBLElBQUksVUFBVSxjQUNaLElBQUksUUFBUSxDQUFDLElBQUksR0FBRyxjQUFjLE9BQU8sVUFBVSxZQUFZO0NBRWpFLElBQUksUUFBUSxHQUNWLElBQUksUUFBUSxDQUFDLElBQUksR0FBRyxTQUFTLE9BQU8sQ0FBQztDQUV2QyxPQUFPO0FBQ1QiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOV19