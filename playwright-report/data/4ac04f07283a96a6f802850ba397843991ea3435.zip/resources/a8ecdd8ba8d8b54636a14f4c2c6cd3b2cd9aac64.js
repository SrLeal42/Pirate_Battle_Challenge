import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/MockDevPanel.tsx");const React = __vite__cjsImport0_react; const useId = __vite__cjsImport0_react["useId"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=1e3034c0";
import { SCENARIOS, SCENARIO_IDS } from "/src/mocks/scenarios.ts";
import { getMockSettings, setScenario, resetMocks } from "/src/mocks/control.ts";
import { usePendingMatches } from "/src/features/matches/hooks.ts";
import styles from "/src/ui/components/MockDevPanel.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/MockDevPanel.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
export const MockDevPanel = () => {
	_s();
	const [open, setOpen] = useState(false);
	const [scenario, setScenarioState] = useState(() => getMockSettings().scenario);
	const queryClient = useQueryClient();
	const pending = usePendingMatches();
	const panelId = useId();
	const selectId = useId();
	const handleChange = (e) => {
		const next = e.target.value;
		setScenario(next);
		setScenarioState(next);
		void queryClient.invalidateQueries();
	};
	const handleReset = () => {
		resetMocks();
		window.location.reload();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: styles.root,
		children: [/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: styles.toggle,
			"aria-expanded": open,
			"aria-controls": panelId,
			"aria-label": "Network scenarios",
			title: "Network scenarios",
			onClick: () => setOpen((o) => !o),
			children: "⚙"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 13
		}, this), open && /* @__PURE__ */ _jsxDEV("section", {
			id: panelId,
			className: styles.panel,
			"aria-label": "Network scenario controls",
			children: [
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: selectId,
					children: "Scenario"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("select", {
					id: selectId,
					value: scenario,
					onChange: handleChange,
					children: SCENARIO_IDS.map((id) => /* @__PURE__ */ _jsxDEV("option", {
						value: id,
						children: SCENARIOS[id].label
					}, id, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 29
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: styles.description,
					children: SCENARIOS[scenario].description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: styles.meta,
					children: ["Pending matches: ", pending.length]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: handleReset,
					children: "Reset mock state"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 21
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 17
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 9
	}, this);
};
_s(MockDevPanel, "zbVXNaaUeGv/yvsiE2xWm4RxAKA=", false, function() {
	return [useQueryClient, usePendingMatches];
});
_c = MockDevPanel;
var _c;
$RefreshReg$(_c, "MockDevPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/MockDevPanel.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/MockDevPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/MockDevPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/MockDevPanel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLE9BQU8sZ0JBQWdCO0FBQ3ZDLFNBQVMsc0JBQXNCO0FBRS9CLFNBQVMsV0FBVyxvQkFBcUM7QUFDekQsU0FBUyxpQkFBaUIsYUFBYSxrQkFBa0I7QUFDekQsU0FBUyx5QkFBeUI7QUFFbEMsT0FBTyxZQUFZOzs7O0FBRW5CLE9BQU8sTUFBTSxxQkFBK0I7O0NBQ3hDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxLQUFLO0NBQ3RDLE1BQU0sQ0FBQyxVQUFVLG9CQUFvQixlQUEyQixnQkFBZ0IsQ0FBQyxDQUFDLFFBQVE7Q0FDMUYsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxVQUFVLGtCQUFrQjtDQUNsQyxNQUFNLFVBQVUsTUFBTTtDQUN0QixNQUFNLFdBQVcsTUFBTTtDQUV2QixNQUFNLGdCQUFnQixNQUE0QztFQUM5RCxNQUFNLE9BQU8sRUFBRSxPQUFPO0VBQ3RCLFlBQVksSUFBSTtFQUNoQixpQkFBaUIsSUFBSTtFQUNyQixLQUFLLFlBQVksa0JBQWtCO0NBQ3ZDO0NBRUEsTUFBTSxvQkFBb0I7RUFDdEIsV0FBVztFQUNYLE9BQU8sU0FBUyxPQUFPO0NBQzNCO0NBRUEsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVyxPQUFPO1lBQXZCLENBQ0ksd0JBQUMsVUFBRDtHQUNJLE1BQUs7R0FDTCxXQUFXLE9BQU87R0FDbEIsaUJBQWU7R0FDZixpQkFBZTtHQUNmLGNBQVc7R0FDWCxPQUFNO0dBQ04sZUFBZSxTQUFTLE1BQU0sQ0FBQyxDQUFDO2FBQ25DO0VBRU87Ozs7WUFFUCxRQUNHLHdCQUFDLFdBQUQ7R0FBUyxJQUFJO0dBQVMsV0FBVyxPQUFPO0dBQU8sY0FBVzthQUExRDtJQUNJLHdCQUFDLFNBQUQ7S0FBTyxTQUFTO2VBQVU7SUFBZTs7Ozs7SUFDekMsd0JBQUMsVUFBRDtLQUFRLElBQUk7S0FBVSxPQUFPO0tBQVUsVUFBVTtlQUM1QyxhQUFhLEtBQUssT0FDZix3QkFBQyxVQUFEO01BQWlCLE9BQU87Z0JBQUssVUFBVSxHQUFHLENBQUM7S0FBYyxHQUE1Qzs7OztZQUE0QyxDQUM1RDtJQUNHOzs7OztJQUNSLHdCQUFDLEtBQUQ7S0FBRyxXQUFXLE9BQU87ZUFBYyxVQUFVLFNBQVMsQ0FBQztJQUFlOzs7OztJQUN0RSx3QkFBQyxLQUFEO0tBQUcsV0FBVyxPQUFPO2VBQXJCLENBQTJCLHFCQUFrQixRQUFRLE1BQVU7Ozs7OztJQUMvRCx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFNBQVM7ZUFBYTtJQUF3Qjs7Ozs7R0FDL0Q7Ozs7O1VBRVo7Ozs7OztBQUdiIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1vY2tEZXZQYW5lbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUlkLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknO1xyXG5cclxuaW1wb3J0IHsgU0NFTkFSSU9TLCBTQ0VOQVJJT19JRFMsIHR5cGUgU2NlbmFyaW9JZCB9IGZyb20gJy4uLy4uL21vY2tzL3NjZW5hcmlvcyc7XHJcbmltcG9ydCB7IGdldE1vY2tTZXR0aW5ncywgc2V0U2NlbmFyaW8sIHJlc2V0TW9ja3MgfSBmcm9tICcuLi8uLi9tb2Nrcy9jb250cm9sJztcclxuaW1wb3J0IHsgdXNlUGVuZGluZ01hdGNoZXMgfSBmcm9tICcuLi8uLi9mZWF0dXJlcy9tYXRjaGVzL2hvb2tzJztcclxuXHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi9Nb2NrRGV2UGFuZWwubW9kdWxlLmNzcyc7XHJcblxyXG5leHBvcnQgY29uc3QgTW9ja0RldlBhbmVsOiBSZWFjdC5GQyA9ICgpID0+IHtcclxuICAgIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtzY2VuYXJpbywgc2V0U2NlbmFyaW9TdGF0ZV0gPSB1c2VTdGF0ZTxTY2VuYXJpb0lkPigoKSA9PiBnZXRNb2NrU2V0dGluZ3MoKS5zY2VuYXJpbyk7XHJcbiAgICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XHJcbiAgICBjb25zdCBwZW5kaW5nID0gdXNlUGVuZGluZ01hdGNoZXMoKTtcclxuICAgIGNvbnN0IHBhbmVsSWQgPSB1c2VJZCgpO1xyXG4gICAgY29uc3Qgc2VsZWN0SWQgPSB1c2VJZCgpO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MU2VsZWN0RWxlbWVudD4pID0+IHtcclxuICAgICAgICBjb25zdCBuZXh0ID0gZS50YXJnZXQudmFsdWUgYXMgU2NlbmFyaW9JZDtcclxuICAgICAgICBzZXRTY2VuYXJpbyhuZXh0KTtcclxuICAgICAgICBzZXRTY2VuYXJpb1N0YXRlKG5leHQpO1xyXG4gICAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUmVzZXQgPSAoKSA9PiB7XHJcbiAgICAgICAgcmVzZXRNb2NrcygpO1xyXG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTsgLy8gYWxzbyBjbGVhcnMgdGhlIHF1ZXJ5IGNhY2hlXHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5yb290fT5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy50b2dnbGV9XHJcbiAgICAgICAgICAgICAgICBhcmlhLWV4cGFuZGVkPXtvcGVufVxyXG4gICAgICAgICAgICAgICAgYXJpYS1jb250cm9scz17cGFuZWxJZH1cclxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJOZXR3b3JrIHNjZW5hcmlvc1wiXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIk5ldHdvcmsgc2NlbmFyaW9zXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oKG8pID0+ICFvKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAg4pqZXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAge29wZW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNlY3Rpb24gaWQ9e3BhbmVsSWR9IGNsYXNzTmFtZT17c3R5bGVzLnBhbmVsfSBhcmlhLWxhYmVsPVwiTmV0d29yayBzY2VuYXJpbyBjb250cm9sc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPXtzZWxlY3RJZH0+U2NlbmFyaW88L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgaWQ9e3NlbGVjdElkfSB2YWx1ZT17c2NlbmFyaW99IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7U0NFTkFSSU9fSURTLm1hcCgoaWQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtpZH0gdmFsdWU9e2lkfT57U0NFTkFSSU9TW2lkXS5sYWJlbH08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPXtzdHlsZXMuZGVzY3JpcHRpb259PntTQ0VOQVJJT1Nbc2NlbmFyaW9dLmRlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5tZXRhfT5QZW5kaW5nIG1hdGNoZXM6IHtwZW5kaW5nLmxlbmd0aH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlUmVzZXR9PlJlc2V0IG1vY2sgc3RhdGU8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcblxyXG59O1xyXG4iXX0=