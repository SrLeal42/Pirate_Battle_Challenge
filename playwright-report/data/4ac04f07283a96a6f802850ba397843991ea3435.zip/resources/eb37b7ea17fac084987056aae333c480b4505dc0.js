/** Mulberry32: fast 32-bit PRNG suitable for seeded deterministic simulations. */
export function mulberry32(seed) {
	return function() {
		let t = seed += 1831565813;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
export class RNG {
	nextFloat;
	constructor(seed) {
		this.nextFloat = mulberry32(seed);
	}
	/** Returns a float in [0, 1) */
	random() {
		return this.nextFloat();
	}
	/** Returns a float in [min, max) */
	range(min, max) {
		return min + this.random() * (max - min);
	}
	/** Returns an integer in [min, max] (inclusive) */
	rangeInt(min, max) {
		return Math.floor(this.range(min, max + 1));
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IjtBQUNBLE9BQU8sU0FBUyxXQUFXLE1BQWM7Q0FDdkMsT0FBTyxXQUFZO0VBQ2pCLElBQUksSUFBSSxRQUFRO0VBQ2hCLElBQUksS0FBSyxLQUFLLElBQUksTUFBTSxJQUFJLElBQUksQ0FBQztFQUNqQyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksTUFBTSxHQUFHLElBQUksRUFBRTtFQUN0QyxTQUFTLElBQUksTUFBTSxRQUFRLEtBQUs7Q0FDbEM7QUFDRjtBQUVBLE9BQU8sTUFBTSxJQUFJO0NBQ2YsQUFBUTtDQUVSLFlBQVksTUFBYztFQUN4QixLQUFLLFlBQVksV0FBVyxJQUFJO0NBQ2xDOztDQUdBLFNBQWlCO0VBQ2YsT0FBTyxLQUFLLFVBQVU7Q0FDeEI7O0NBR0EsTUFBTSxLQUFhLEtBQXFCO0VBQ3RDLE9BQU8sTUFBTSxLQUFLLE9BQU8sS0FBSyxNQUFNO0NBQ3RDOztDQUdBLFNBQVMsS0FBYSxLQUFxQjtFQUN6QyxPQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQztDQUM1QztBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInJuZy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKiogTXVsYmVycnkzMjogZmFzdCAzMi1iaXQgUFJORyBzdWl0YWJsZSBmb3Igc2VlZGVkIGRldGVybWluaXN0aWMgc2ltdWxhdGlvbnMuICovXG5leHBvcnQgZnVuY3Rpb24gbXVsYmVycnkzMihzZWVkOiBudW1iZXIpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICBsZXQgdCA9IHNlZWQgKz0gMHg2RDJCNzlGNTtcbiAgICB0ID0gTWF0aC5pbXVsKHQgXiB0ID4+PiAxNSwgdCB8IDEpO1xuICAgIHQgXj0gdCArIE1hdGguaW11bCh0IF4gdCA+Pj4gNywgdCB8IDYxKTtcbiAgICByZXR1cm4gKCh0IF4gdCA+Pj4gMTQpID4+PiAwKSAvIDQyOTQ5NjcyOTY7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIFJORyB7XG4gIHByaXZhdGUgbmV4dEZsb2F0OiAoKSA9PiBudW1iZXI7XG5cbiAgY29uc3RydWN0b3Ioc2VlZDogbnVtYmVyKSB7XG4gICAgdGhpcy5uZXh0RmxvYXQgPSBtdWxiZXJyeTMyKHNlZWQpO1xuICB9XG5cbiAgLyoqIFJldHVybnMgYSBmbG9hdCBpbiBbMCwgMSkgKi9cbiAgcmFuZG9tKCk6IG51bWJlciB7XG4gICAgcmV0dXJuIHRoaXMubmV4dEZsb2F0KCk7XG4gIH1cblxuICAvKiogUmV0dXJucyBhIGZsb2F0IGluIFttaW4sIG1heCkgKi9cbiAgcmFuZ2UobWluOiBudW1iZXIsIG1heDogbnVtYmVyKTogbnVtYmVyIHtcbiAgICByZXR1cm4gbWluICsgdGhpcy5yYW5kb20oKSAqIChtYXggLSBtaW4pO1xuICB9XG5cbiAgLyoqIFJldHVybnMgYW4gaW50ZWdlciBpbiBbbWluLCBtYXhdIChpbmNsdXNpdmUpICovXG4gIHJhbmdlSW50KG1pbjogbnVtYmVyLCBtYXg6IG51bWJlcik6IG51bWJlciB7XG4gICAgcmV0dXJuIE1hdGguZmxvb3IodGhpcy5yYW5nZShtaW4sIG1heCArIDEpKTtcbiAgfVxufVxuIl19