import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/MockDevPanel.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/MockDevPanel.module.css"
const __vite__css = "._root_7qwh1_1 {\r\n    position: fixed;\r\n    left: 12px;\r\n    bottom: 12px;\r\n    z-index: 50;\r\n}\r\n\r\n._toggle_7qwh1_15 {\r\n    width: 36px;\r\n    height: 36px;\r\n    border-radius: 50%;\r\n    border: 1px solid rgba(255, 255, 255, 0.25);\r\n    background: rgba(10, 20, 35, 0.55);\r\n    color: #f5e6c8;\r\n    font-size: 18px;\r\n    cursor: pointer;\r\n    opacity: 0.6;\r\n    transition: opacity 0.2s, transform 0.2s;\r\n}\r\n\r\n._toggle_7qwh1_15:hover,\r\n._toggle_7qwh1_15:focus-visible {\r\n    opacity: 1;\r\n    transform: rotate(30deg);\r\n}\r\n\r\n._toggle_7qwh1_15:focus-visible,\r\n._panel_7qwh1_55 select:focus-visible,\r\n._panel_7qwh1_55 button:focus-visible {\r\n    outline: 2px solid #ffd27a;\r\n    outline-offset: 2px;\r\n}\r\n\r\n._panel_7qwh1_55 {\r\n    position: absolute;\r\n    left: 0;\r\n    bottom: 46px;\r\n    width: min(280px, calc(100vw - 24px));\r\n    display: grid;\r\n    gap: 8px;\r\n    padding: 12px;\r\n    border-radius: 10px;\r\n    background: rgba(10, 20, 35, 0.92);\r\n    color: #f5e6c8;\r\n    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);\r\n    font-size: 13px;\r\n}\r\n\r\n._panel_7qwh1_55 select,\r\n._panel_7qwh1_55 button {\r\n    min-height: 32px;\r\n    font: inherit;\r\n}\r\n\r\n._description_7qwh1_109 {\r\n    margin: 0;\r\n    opacity: 0.8;\r\n}\r\n\r\n._meta_7qwh1_119 {\r\n    margin: 0;\r\n    font-size: 12px;\r\n    opacity: 0.7;\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const root = "_root_7qwh1_1";
export const toggle = "_toggle_7qwh1_15";
export const panel = "_panel_7qwh1_55";
export const description = "_description_7qwh1_109";
export const meta = "_meta_7qwh1_119";
export default {
	root: root,
	toggle: toggle,
	panel: panel,
	description: description,
	meta: meta
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))