import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/StartScreen.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/StartScreen.module.css"
const __vite__css = "._overlay_1vgwg_1 {\r\n    position: absolute;\r\n    inset: 0;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    background: rgba(15, 23, 42, 0.6);\r\n    animation: _fadeIn_1vgwg_1 0.5s ease-out;\r\n}\r\n\r\n._card_1vgwg_21 {\r\n    background-image: url('/assets/png/default/ui/menu/panel_menu.png');\r\n    background-size: 100% 100%;\r\n    background-position: center;\r\n    background-repeat: no-repeat;\r\n\r\n    width: 600px;\r\n    min-height: 700px;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    justify-content: center;\r\n    padding: 3rem 4rem;\r\n    box-sizing: border-box;\r\n    gap: 2rem;\r\n}\r\n\r\n._titleImage_1vgwg_55 {\r\n    width: 105%;\r\n    margin-top: -30px;\r\n    filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.5));\r\n}\r\n\r\n._inputWrapper_1vgwg_67 {\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 0.5rem;\r\n    width: 100%;\r\n    text-align: center;\r\n}\r\n\r\n._label_1vgwg_83 {\r\n    color: #fde047;\r\n    font-size: 1rem;\r\n    text-transform: uppercase;\r\n    font-weight: 800;\r\n    text-shadow: 2px 2px 0px #000;\r\n}\r\n\r\n._input_1vgwg_67 {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    color: #fff;\r\n\r\n    width: 280px;\r\n    height: 65px;\r\n    margin: 0 auto;\r\n    padding: 0 1.5rem;\r\n\r\n    font-size: 1.25rem;\r\n    text-align: center;\r\n    outline: none;\r\n    font-weight: bold;\r\n}\r\n\r\n\r\n._input_1vgwg_67::placeholder {\r\n    color: rgba(255, 255, 255, 0.5);\r\n}\r\n\r\n._button_1vgwg_145 {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 230px;\r\n    height: 75px;\r\n    color: white;\r\n    font-size: 1.25rem;\r\n    font-weight: 900;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n    text-shadow: 0px 2px 0px rgba(0, 0, 0, 0.5);\r\n    transition: transform 0.1s;\r\n}\r\n\r\n._button_1vgwg_145:hover:not(:disabled) {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_hover.png');\r\n}\r\n\r\n._button_1vgwg_145:active:not(:disabled) {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_pressed.png');\r\n    transform: translateY(2px);\r\n}\r\n\r\n._button_1vgwg_145:disabled {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_disabled.png');\r\n    color: rgba(255, 255, 255, 0.6);\r\n    cursor: not-allowed;\r\n}\r\n\r\n@keyframes _fadeIn_1vgwg_1 {\r\n    from {\r\n        opacity: 0;\r\n    }\r\n\r\n    to {\r\n        opacity: 1;\r\n    }\r\n}\r\n\r\n\r\n._form_1vgwg_229 {\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 2rem;\r\n    align-items: center;\r\n    width: 100%;\r\n}\r\n\r\n\r\n._buttonGroup_1vgwg_247 {\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 1rem;\r\n    width: 100%;\r\n    align-items: center;\r\n}\r\n\r\n._buttonSecondary_1vgwg_263 {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 230px;\r\n    height: 75px;\r\n    color: #fde047;\r\n    font-size: 1.25rem;\r\n    font-weight: 900;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n    text-shadow: 0px 2px 0px rgba(0, 0, 0, 0.5);\r\n    transition: transform 0.1s;\r\n}\r\n\r\n._buttonSecondary_1vgwg_263:hover {\r\n    filter: brightness(1.1);\r\n}\r\n\r\n._buttonSecondary_1vgwg_263:active {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_pressed.png');\r\n    transform: translateY(2px);\r\n}\r\n\r\n\r\n._footerButtons_1vgwg_315 {\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    gap: 1.5rem;\r\n    margin-top: 1rem;\r\n    width: 100%;\r\n    justify-content: center;\r\n}\r\n\r\n._smallButton_1vgwg_333 {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 160px;\r\n    height: 55px;\r\n    color: #fde047;\r\n    font-size: 1rem;\r\n    font-weight: 900;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n    text-shadow: 0px 2px 0px rgba(0, 0, 0, 0.5);\r\n    transition: transform 0.1s, filter 0.1s;\r\n}\r\n\r\n._smallButton_1vgwg_333:hover {\r\n    filter: brightness(1.2);\r\n}\r\n\r\n._smallButton_1vgwg_333:active {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_pressed.png');\r\n    transform: translateY(2px);\r\n}\r\n\r\n/* --- Last match --- */\r\n._lastMatch_1vgwg_385 {\r\n    width: 100%;\r\n    padding: 0.75rem 1rem;\r\n    border-radius: 8px;\r\n    background: rgba(0, 0, 0, 0.35);\r\n    text-align: center;\r\n    margin-bottom: 20px;\r\n}\r\n\r\n._lastMatchTitle_1vgwg_403 {\r\n    margin: 0 0 0.5rem;\r\n    color: #fde047;\r\n    font-size: 0.9rem;\r\n    font-weight: 800;\r\n    text-transform: uppercase;\r\n    letter-spacing: 0.05em;\r\n    text-shadow: 1px 1px 0 #000;\r\n}\r\n\r\n._lastMatchDetails_1vgwg_423 {\r\n    display: flex;\r\n    justify-content: space-around;\r\n    gap: 1rem;\r\n    margin: 0;\r\n}\r\n\r\n._lastMatchDetails_1vgwg_423 dt {\r\n    color: #cbd5e1;\r\n    font-size: 0.75rem;\r\n    font-weight: 700;\r\n    text-transform: uppercase;\r\n}\r\n\r\n._lastMatchDetails_1vgwg_423 dd {\r\n    margin: 0;\r\n    color: #fff;\r\n    font-size: 1.1rem;\r\n    font-weight: 900;\r\n    text-shadow: 1px 1px 0 #000;\r\n}\r\n\r\n/* --- Pending sync --- */\r\n._pendingNotice_1vgwg_469 {\r\n    display: flex;\r\n    align-items: center;\r\n    gap: 1rem;\r\n    color: #fde047;\r\n    font-weight: 800;\r\n    text-shadow: 1px 1px 0 #000;\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const overlay = "_overlay_1vgwg_1";
export const fadeIn = "_fadeIn_1vgwg_1";
export const card = "_card_1vgwg_21";
export const titleImage = "_titleImage_1vgwg_55";
export const inputWrapper = "_inputWrapper_1vgwg_67";
export const label = "_label_1vgwg_83";
export const input = "_input_1vgwg_67";
export const button = "_button_1vgwg_145";
export const form = "_form_1vgwg_229";
export const buttonGroup = "_buttonGroup_1vgwg_247";
export const buttonSecondary = "_buttonSecondary_1vgwg_263";
export const footerButtons = "_footerButtons_1vgwg_315";
export const smallButton = "_smallButton_1vgwg_333";
export const lastMatch = "_lastMatch_1vgwg_385";
export const lastMatchTitle = "_lastMatchTitle_1vgwg_403";
export const lastMatchDetails = "_lastMatchDetails_1vgwg_423";
export const pendingNotice = "_pendingNotice_1vgwg_469";
export default {
	overlay: overlay,
	fadeIn: fadeIn,
	card: card,
	titleImage: titleImage,
	inputWrapper: inputWrapper,
	label: label,
	input: input,
	button: button,
	form: form,
	buttonGroup: buttonGroup,
	buttonSecondary: buttonSecondary,
	footerButtons: footerButtons,
	smallButton: smallButton,
	lastMatch: lastMatch,
	lastMatchTitle: lastMatchTitle,
	lastMatchDetails: lastMatchDetails,
	pendingNotice: pendingNotice
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))