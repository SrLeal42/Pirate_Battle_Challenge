import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { GameCanvas } from "/src/ui/components/GameCanvas.tsx";
import { MockDevPanel } from "/src/ui/components/MockDevPanel.tsx";
import { usePendingSync } from "/src/features/matches/hooks.ts";
import { useGameStore, RuntimeStateEnum } from "/src/stores/gameStore.ts";
import "/src/App.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/App.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
export function App() {
	_s();
	usePendingSync();
	const runtimeState = useGameStore((s) => s.runtimeState);
	const inCombat = runtimeState === RuntimeStateEnum.Playing || runtimeState === RuntimeStateEnum.Paused;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-container",
		children: [/* @__PURE__ */ _jsxDEV(GameCanvas, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 7
		}, this), !inCombat && /* @__PURE__ */ _jsxDEV(MockDevPanel, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 21
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
}
_s(App, "Kkg/H9NV62/sXtoyKgvP1iC7KuQ=", false, function() {
	return [usePendingSync, useGameStore];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxjQUFjLHdCQUF3QjtBQUUvQyxPQUFPOzs7O0FBRVAsT0FBTyxTQUFTLE1BQU07O0NBQ3BCLGVBQWU7Q0FFZixNQUFNLGVBQWUsY0FBYyxNQUFNLEVBQUUsWUFBWTtDQUN2RCxNQUFNLFdBQVcsaUJBQWlCLGlCQUFpQixXQUFXLGlCQUFpQixpQkFBaUI7Q0FFaEcsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsWUFBRCxDQUFhOzs7O1lBQ1osQ0FBQyxZQUFZLHdCQUFDLGNBQUQsQ0FBZTs7OztVQUMxQjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBHYW1lQ2FudmFzIH0gZnJvbSAnLi91aS9jb21wb25lbnRzL0dhbWVDYW52YXMnO1xuaW1wb3J0IHsgTW9ja0RldlBhbmVsIH0gZnJvbSAnLi91aS9jb21wb25lbnRzL01vY2tEZXZQYW5lbCc7XG5pbXBvcnQgeyB1c2VQZW5kaW5nU3luYyB9IGZyb20gJy4vZmVhdHVyZXMvbWF0Y2hlcy9ob29rcyc7XG5pbXBvcnQgeyB1c2VHYW1lU3RvcmUsIFJ1bnRpbWVTdGF0ZUVudW0gfSBmcm9tICcuL3N0b3Jlcy9nYW1lU3RvcmUnO1xuXG5pbXBvcnQgJy4vQXBwLmNzcyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBBcHAoKSB7XG4gIHVzZVBlbmRpbmdTeW5jKCk7XG5cbiAgY29uc3QgcnVudGltZVN0YXRlID0gdXNlR2FtZVN0b3JlKChzKSA9PiBzLnJ1bnRpbWVTdGF0ZSk7XG4gIGNvbnN0IGluQ29tYmF0ID0gcnVudGltZVN0YXRlID09PSBSdW50aW1lU3RhdGVFbnVtLlBsYXlpbmcgfHwgcnVudGltZVN0YXRlID09PSBSdW50aW1lU3RhdGVFbnVtLlBhdXNlZDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBwLWNvbnRhaW5lclwiPlxuICAgICAgPEdhbWVDYW52YXMgLz5cbiAgICAgIHshaW5Db21iYXQgJiYgPE1vY2tEZXZQYW5lbCAvPn1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==