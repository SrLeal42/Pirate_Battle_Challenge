import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/HUD.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/HUD.module.css"
const __vite__css = "._container_152lp_1 {\r\n    position: absolute;\r\n    inset: 0;\r\n    pointer-events: none;\r\n    display: flex;\r\n    justify-content: space-between;\r\n    padding: 2rem;\r\n}\r\n\r\n/* --- Health Bar --- */\r\n._healthWrapper_152lp_21 {\r\n    width: 300px;\r\n}\r\n\r\n/* --- Status Counters (Time & Score) --- */\r\n._statsWrapper_152lp_31 {\r\n    display: flex;\r\n    gap: 1.5rem;\r\n}\r\n\r\n._counter_152lp_41 {\r\n    width: 160px;\r\n    height: 60px;\r\n    background-image: url('/assets/png/default/ui/hud/counter_panel.png');\r\n    background-size: 100% 100%;\r\n\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    gap: 2rem;\r\n    padding: 0;\r\n}\r\n\r\n\r\n._icon_152lp_69 {\r\n    width: 32px;\r\n    height: 32px;\r\n    object-fit: contain;\r\n}\r\n\r\n._value_152lp_81 {\r\n    color: #fff;\r\n    font-size: 1.5rem;\r\n    font-weight: 900;\r\n    font-family: 'Inter', system-ui, sans-serif;\r\n    text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);\r\n}\r\n\r\n\r\n._pauseIcon_152lp_99 {\r\n    width: 24px;\r\n    height: 24px;\r\n    pointer-events: none;\r\n}\r\n\r\n._pauseContainer_152lp_111 {\r\n    position: absolute;\r\n    top: 2rem;\r\n    left: 50%;\r\n    transform: translateX(-50%);\r\n    pointer-events: auto;\r\n}\r\n\r\n._pauseButton_152lp_127 {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 60px;\r\n    height: 60px;\r\n    cursor: pointer;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n}\r\n\r\n._pauseButton_152lp_127:active {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_pressed.png');\r\n}\r\n\r\n._touchControls_152lp_161 {\r\n    position: absolute;\r\n    inset: 0;\r\n    pointer-events: none;\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: flex-end;\r\n    padding: 2rem;\r\n    z-index: 10;\r\n}\r\n\r\n._leftControls_152lp_183,\r\n._rightControls_152lp_185 {\r\n    pointer-events: auto;\r\n    display: grid;\r\n    gap: 1rem;\r\n}\r\n\r\n._leftControls_152lp_183 {\r\n    grid-template-columns: 60px 60px 60px;\r\n    grid-template-areas:\r\n        \". up .\"\r\n        \"left . right\";\r\n}\r\n\r\n._rightControls_152lp_185 {\r\n    grid-template-columns: 60px 60px 60px;\r\n    grid-template-areas:\r\n        \". front .\"\r\n        \"left . right\";\r\n}\r\n\r\n._touchButton_152lp_225 {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 60px;\r\n    height: 60px;\r\n    cursor: pointer;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    user-select: none;\r\n    -webkit-user-select: none;\r\n    touch-action: none;\r\n}\r\n\r\n._touchButton_152lp_225:active {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_pressed.png');\r\n    transform: translateY(2px);\r\n}\r\n\r\n._touchIcon_152lp_267 {\r\n    width: 28px;\r\n    height: 28px;\r\n    pointer-events: none;\r\n}\r\n\r\n@media screen and (hover: hover) and (pointer: fine) {\r\n    ._touchControls_152lp_161 {\r\n        display: none;\r\n    }\r\n}\r\n\r\n\r\n@media screen and (max-width: 850px),\r\nscreen and (max-height: 500px) {\r\n    ._container_152lp_1 {\r\n        padding: 1rem;\r\n    }\r\n\r\n    ._healthWrapper_152lp_21 {\r\n        transform: scale(0.65);\r\n        transform-origin: top left;\r\n    }\r\n\r\n    ._statsWrapper_152lp_31 {\r\n        transform: scale(0.65);\r\n        transform-origin: top right;\r\n    }\r\n\r\n    ._pauseButton_152lp_127 {\r\n        width: 45px;\r\n        height: 45px;\r\n    }\r\n\r\n    ._pauseIcon_152lp_99 {\r\n        width: 18px;\r\n        height: 18px;\r\n    }\r\n\r\n    ._touchButton_152lp_225 {\r\n        width: 50px;\r\n        height: 50px;\r\n    }\r\n\r\n    ._touchIcon_152lp_267 {\r\n        width: 22px;\r\n        height: 22px;\r\n    }\r\n\r\n    ._leftControls_152lp_183,\r\n    ._rightControls_152lp_185 {\r\n        gap: 0.5rem;\r\n    }\r\n\r\n    ._leftControls_152lp_183 {\r\n        grid-template-columns: 50px 50px 50px;\r\n    }\r\n\r\n    ._rightControls_152lp_185 {\r\n        grid-template-columns: 50px 50px 50px;\r\n    }\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const container = "_container_152lp_1";
export const healthWrapper = "_healthWrapper_152lp_21";
export const statsWrapper = "_statsWrapper_152lp_31";
export const counter = "_counter_152lp_41";
export const icon = "_icon_152lp_69";
export const value = "_value_152lp_81";
export const pauseIcon = "_pauseIcon_152lp_99";
export const pauseContainer = "_pauseContainer_152lp_111";
export const pauseButton = "_pauseButton_152lp_127";
export const touchControls = "_touchControls_152lp_161";
export const leftControls = "_leftControls_152lp_183";
export const rightControls = "_rightControls_152lp_185";
export const touchButton = "_touchButton_152lp_225";
export const touchIcon = "_touchIcon_152lp_267";
export default {
	container: container,
	healthWrapper: healthWrapper,
	statsWrapper: statsWrapper,
	counter: counter,
	icon: icon,
	value: value,
	pauseIcon: pauseIcon,
	pauseContainer: pauseContainer,
	pauseButton: pauseButton,
	touchControls: touchControls,
	leftControls: leftControls,
	rightControls: rightControls,
	touchButton: touchButton,
	touchIcon: touchIcon
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))