import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/LoadingScreen.tsx");const React = __vite__cjsImport0_react; const useId = __vite__cjsImport0_react["useId"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import { useGameStore, RuntimeStateEnum } from "/src/stores/gameStore.ts";
import { AssetBar } from "/src/ui/components/AssetBar.tsx";
import styles from "/src/ui/components/LoadingScreen.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LoadingScreen.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
export const LoadingScreen = ({ onRetry }) => {
	_s();
	const runtimeState = useGameStore((s) => s.runtimeState);
	const progress = useGameStore((s) => s.loadProgress);
	const errorMessage = useGameStore((s) => s.errorMessage);
	const labelId = useId();
	const failed = runtimeState === RuntimeStateEnum.Error;
	const percent = Math.round(progress * 100);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: styles.overlay,
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: `${styles.card} responsive-card`,
			"aria-busy": !failed,
			children: [/* @__PURE__ */ _jsxDEV("img", {
				src: "/assets/png/default/ui/menu/title_pirate_battle.png",
				alt: "Pirate Battle",
				className: styles.title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 17
			}, this), failed ? /* @__PURE__ */ _jsxDEV("div", {
				className: styles.error,
				role: "alert",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: styles.errorTitle,
						children: "Couldn't load the game assets"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 25
					}, this),
					errorMessage && /* @__PURE__ */ _jsxDEV("p", {
						className: styles.errorDetail,
						children: errorMessage
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 42
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: styles.retryButton,
						onClick: onRetry,
						autoFocus: true,
						children: "Retry"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 25
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 21
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: styles.progress,
				children: [/* @__PURE__ */ _jsxDEV("span", {
					id: labelId,
					className: styles.label,
					children: "Loading assets"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 25
				}, this), /* @__PURE__ */ _jsxDEV(AssetBar, {
					ratio: progress,
					color: "green",
					label: `${percent}%`,
					role: "progressbar",
					"aria-labelledby": labelId,
					"aria-valuemin": 0,
					"aria-valuemax": 100,
					"aria-valuenow": percent
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 25
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 21
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 9
	}, this);
};
_s(LoadingScreen, "klmOAxk9hCUBq+58YOeF5Jumh1c=", false, function() {
	return [
		useGameStore,
		useGameStore,
		useGameStore
	];
});
_c = LoadingScreen;
var _c;
$RefreshReg$(_c, "LoadingScreen");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/LoadingScreen.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LoadingScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LoadingScreen.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LoadingScreen.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGFBQWE7QUFDN0IsU0FBUyxjQUFjLHdCQUF3QjtBQUMvQyxTQUFTLGdCQUFnQjtBQUN6QixPQUFPLFlBQVk7Ozs7QUFNbkIsT0FBTyxNQUFNLGlCQUErQyxFQUFFLGNBQWM7O0NBQ3hFLE1BQU0sZUFBZSxjQUFjLE1BQU0sRUFBRSxZQUFZO0NBQ3ZELE1BQU0sV0FBVyxjQUFjLE1BQU0sRUFBRSxZQUFZO0NBQ25ELE1BQU0sZUFBZSxjQUFjLE1BQU0sRUFBRSxZQUFZO0NBQ3ZELE1BQU0sVUFBVSxNQUFNO0NBRXRCLE1BQU0sU0FBUyxpQkFBaUIsaUJBQWlCO0NBQ2pELE1BQU0sVUFBVSxLQUFLLE1BQU0sV0FBVyxHQUFHO0NBRXpDLE9BQ0ksd0JBQUMsT0FBRDtFQUFLLFdBQVcsT0FBTztZQUNuQix3QkFBQyxPQUFEO0dBQUssV0FBVyxHQUFHLE9BQU8sS0FBSztHQUFtQixhQUFXLENBQUM7YUFBOUQsQ0FDSSx3QkFBQyxPQUFEO0lBQUssS0FBSTtJQUFzRCxLQUFJO0lBQWdCLFdBQVcsT0FBTztHQUFROzs7O2FBRTVHLFNBQ0csd0JBQUMsT0FBRDtJQUFLLFdBQVcsT0FBTztJQUFPLE1BQUs7Y0FBbkM7S0FDSSx3QkFBQyxLQUFEO01BQUcsV0FBVyxPQUFPO2dCQUFZO0tBQWdDOzs7OztLQUNoRSxnQkFBZ0Isd0JBQUMsS0FBRDtNQUFHLFdBQVcsT0FBTztnQkFBYztLQUFnQjs7Ozs7S0FDcEUsd0JBQUMsVUFBRDtNQUFRLE1BQUs7TUFBUyxXQUFXLE9BQU87TUFBYSxTQUFTO01BQVM7Z0JBQVU7S0FFekU7Ozs7O0lBQ1A7Ozs7O2NBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVcsT0FBTztjQUF2QixDQUNJLHdCQUFDLFFBQUQ7S0FBTSxJQUFJO0tBQVMsV0FBVyxPQUFPO2VBQU87SUFBb0I7Ozs7Y0FDaEUsd0JBQUMsVUFBRDtLQUNJLE9BQU87S0FDUCxPQUFNO0tBQ04sT0FBTyxHQUFHLFFBQVE7S0FDbEIsTUFBSztLQUNMLG1CQUFpQjtLQUNqQixpQkFBZTtLQUNmLGlCQUFlO0tBQ2YsaUJBQWU7SUFDbEI7Ozs7WUFDQTs7Ozs7V0FFUjs7Ozs7O0NBQ0o7Ozs7O0FBR2IiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9hZGluZ1NjcmVlbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUlkIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VHYW1lU3RvcmUsIFJ1bnRpbWVTdGF0ZUVudW0gfSBmcm9tICcuLi8uLi9zdG9yZXMvZ2FtZVN0b3JlJztcclxuaW1wb3J0IHsgQXNzZXRCYXIgfSBmcm9tICcuL0Fzc2V0QmFyJztcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuL0xvYWRpbmdTY3JlZW4ubW9kdWxlLmNzcyc7XHJcblxyXG5pbnRlcmZhY2UgTG9hZGluZ1NjcmVlblByb3BzIHtcclxuICAgIG9uUmV0cnk6ICgpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBMb2FkaW5nU2NyZWVuOiBSZWFjdC5GQzxMb2FkaW5nU2NyZWVuUHJvcHM+ID0gKHsgb25SZXRyeSB9KSA9PiB7XHJcbiAgICBjb25zdCBydW50aW1lU3RhdGUgPSB1c2VHYW1lU3RvcmUoKHMpID0+IHMucnVudGltZVN0YXRlKTtcclxuICAgIGNvbnN0IHByb2dyZXNzID0gdXNlR2FtZVN0b3JlKChzKSA9PiBzLmxvYWRQcm9ncmVzcyk7XHJcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSB1c2VHYW1lU3RvcmUoKHMpID0+IHMuZXJyb3JNZXNzYWdlKTtcclxuICAgIGNvbnN0IGxhYmVsSWQgPSB1c2VJZCgpO1xyXG5cclxuICAgIGNvbnN0IGZhaWxlZCA9IHJ1bnRpbWVTdGF0ZSA9PT0gUnVudGltZVN0YXRlRW51bS5FcnJvcjtcclxuICAgIGNvbnN0IHBlcmNlbnQgPSBNYXRoLnJvdW5kKHByb2dyZXNzICogMTAwKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMub3ZlcmxheX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtzdHlsZXMuY2FyZH0gcmVzcG9uc2l2ZS1jYXJkYH0gYXJpYS1idXN5PXshZmFpbGVkfT5cclxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPVwiL2Fzc2V0cy9wbmcvZGVmYXVsdC91aS9tZW51L3RpdGxlX3BpcmF0ZV9iYXR0bGUucG5nXCIgYWx0PVwiUGlyYXRlIEJhdHRsZVwiIGNsYXNzTmFtZT17c3R5bGVzLnRpdGxlfSAvPlxyXG5cclxuICAgICAgICAgICAgICAgIHtmYWlsZWQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5lcnJvcn0gcm9sZT1cImFsZXJ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17c3R5bGVzLmVycm9yVGl0bGV9PkNvdWxkbid0IGxvYWQgdGhlIGdhbWUgYXNzZXRzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JNZXNzYWdlICYmIDxwIGNsYXNzTmFtZT17c3R5bGVzLmVycm9yRGV0YWlsfT57ZXJyb3JNZXNzYWdlfTwvcD59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT17c3R5bGVzLnJldHJ5QnV0dG9ufSBvbkNsaWNrPXtvblJldHJ5fSBhdXRvRm9jdXM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXRyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5wcm9ncmVzc30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGlkPXtsYWJlbElkfSBjbGFzc05hbWU9e3N0eWxlcy5sYWJlbH0+TG9hZGluZyBhc3NldHM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxBc3NldEJhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmF0aW89e3Byb2dyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJncmVlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17YCR7cGVyY2VudH0lYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvbGU9XCJwcm9ncmVzc2JhclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsbGVkYnk9e2xhYmVsSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLXZhbHVlbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS12YWx1ZW1heD17MTAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS12YWx1ZW5vdz17cGVyY2VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuXHJcbn07XHJcbiJdfQ==