import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};const StrictMode = __vite__cjsImport0_react["StrictMode"];const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=22985b1a";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=1e3034c0";
import { App } from "/src/App.tsx";
import { isRetryableError } from "/src/features/matches/api.ts";
import "/src/index.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/main.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
const queryClient = new QueryClient({ defaultOptions: { queries: {
	retry: (failureCount, error) => failureCount < 1 && isRetryableError(error),
	refetchOnWindowFocus: false
} } });
async function enableMocking() {
	const [{ worker }, { applyUrlOverrides, exposeMockControls }] = await Promise.all([import("/src/mocks/browser.ts"), import("/src/mocks/control.ts")]);
	applyUrlOverrides();
	exposeMockControls();
	return worker.start({
		onUnhandledFrame: "bypass",
		quiet: import.meta.env.PROD,
		serviceWorker: { url: `${import.meta.env.BASE_URL}mockServiceWorker.js` }
	});
}
enableMocking().then(() => {
	createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 5
	}, this));
});

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxhQUFhLDJCQUEyQjtBQUVqRCxTQUFTLFdBQVc7QUFFcEIsU0FBUyx3QkFBd0I7QUFFakMsT0FBTzs7O0FBRVAsTUFBTSxjQUFjLElBQUksWUFBWSxFQUNsQyxnQkFBZ0IsRUFDZCxTQUFTO0NBQ1AsUUFBUSxjQUFjLFVBQVUsZUFBZSxLQUFLLGlCQUFpQixLQUFLO0NBQzFFLHNCQUFzQjtBQUN4QixFQUNGLEVBQ0YsQ0FBQztBQUVELGVBQWUsZ0JBQWdCO0NBRTdCLE1BQU0sQ0FBQyxFQUFFLFVBQVUsRUFBRSxtQkFBbUIsd0JBQXdCLE1BQU0sUUFBUSxJQUFJLENBQ2hGLE9BQU8sb0JBQ1AsT0FBTyxrQkFDVCxDQUFDO0NBRUQsa0JBQWtCO0NBQ2xCLG1CQUFtQjtDQUVuQixPQUFPLE9BQU8sTUFBTTtFQUNsQixrQkFBa0I7RUFDbEIsT0FBTyxZQUFZLElBQUk7RUFDdkIsZUFBZSxFQUFFLEtBQUssR0FBRyxZQUFZLElBQUksU0FBUyxzQkFBc0I7Q0FDMUUsQ0FBQztBQUVIO0FBRUEsY0FBYyxDQUFDLENBQUMsV0FBVztDQUN6QixXQUFXLFNBQVMsZUFBZSxNQUFNLENBQUUsQ0FBQyxDQUFDLE9BQzNDLHdCQUFDLFlBQUQsWUFDRSx3QkFBQyxxQkFBRDtFQUFxQixRQUFRO1lBQzNCLHdCQUFDLEtBQUQsQ0FBTTs7Ozs7Q0FDYTs7OztVQUNYOzs7O1NBQ2Q7QUFDRixDQUFDIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSc7XG5cbmltcG9ydCB7IEFwcCB9IGZyb20gJy4vQXBwJztcblxuaW1wb3J0IHsgaXNSZXRyeWFibGVFcnJvciB9IGZyb20gJy4vZmVhdHVyZXMvbWF0Y2hlcy9hcGknO1xuXG5pbXBvcnQgJy4vaW5kZXguY3NzJztcblxuY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoe1xuICBkZWZhdWx0T3B0aW9uczoge1xuICAgIHF1ZXJpZXM6IHtcbiAgICAgIHJldHJ5OiAoZmFpbHVyZUNvdW50LCBlcnJvcikgPT4gZmFpbHVyZUNvdW50IDwgMSAmJiBpc1JldHJ5YWJsZUVycm9yKGVycm9yKSxcbiAgICAgIHJlZmV0Y2hPbldpbmRvd0ZvY3VzOiBmYWxzZSxcbiAgICB9LFxuICB9LFxufSk7XG5cbmFzeW5jIGZ1bmN0aW9uIGVuYWJsZU1vY2tpbmcoKSB7XG5cbiAgY29uc3QgW3sgd29ya2VyIH0sIHsgYXBwbHlVcmxPdmVycmlkZXMsIGV4cG9zZU1vY2tDb250cm9scyB9XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICBpbXBvcnQoJy4vbW9ja3MvYnJvd3NlcicpLFxuICAgIGltcG9ydCgnLi9tb2Nrcy9jb250cm9sJyksXG4gIF0pO1xuXG4gIGFwcGx5VXJsT3ZlcnJpZGVzKCk7XG4gIGV4cG9zZU1vY2tDb250cm9scygpO1xuXG4gIHJldHVybiB3b3JrZXIuc3RhcnQoe1xuICAgIG9uVW5oYW5kbGVkRnJhbWU6ICdieXBhc3MnLFxuICAgIHF1aWV0OiBpbXBvcnQubWV0YS5lbnYuUFJPRCxcbiAgICBzZXJ2aWNlV29ya2VyOiB7IHVybDogYCR7aW1wb3J0Lm1ldGEuZW52LkJBU0VfVVJMfW1vY2tTZXJ2aWNlV29ya2VyLmpzYCB9LFxuICB9KTtcblxufVxuXG5lbmFibGVNb2NraW5nKCkudGhlbigoKSA9PiB7XG4gIGNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSEpLnJlbmRlcihcbiAgICA8U3RyaWN0TW9kZT5cbiAgICAgIDxRdWVyeUNsaWVudFByb3ZpZGVyIGNsaWVudD17cXVlcnlDbGllbnR9PlxuICAgICAgICA8QXBwIC8+XG4gICAgICA8L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4gICAgPC9TdHJpY3RNb2RlPixcbiAgKTtcbn0pO1xuIl19