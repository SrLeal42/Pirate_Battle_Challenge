import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/OptionsScreen.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/OptionsScreen.module.css"
const __vite__css = "._card_xmguq_1 {\r\n    background-image: url('/assets/png/default/ui/menu/panel_menu.png');\r\n    background-size: 100% 100%;\r\n    width: 450px;\r\n    min-height: 550px;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    padding: 3rem 4rem;\r\n    box-sizing: border-box;\r\n    gap: 2rem;\r\n}\r\n\r\n._title_xmguq_27 {\r\n    color: #fde047;\r\n    font-size: 2.5rem;\r\n    text-transform: uppercase;\r\n    font-weight: 900;\r\n    text-shadow: 3px 3px 0px #000;\r\n    margin: 0;\r\n    margin-top: -10px;\r\n}\r\n\r\n._optionGroup_xmguq_47 {\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    width: 100%;\r\n    gap: 0.5rem;\r\n}\r\n\r\n._label_xmguq_63 {\r\n    color: #f8fafc;\r\n    font-size: 1.25rem;\r\n    font-weight: bold;\r\n    text-shadow: 1px 1px 0px #000;\r\n}\r\n\r\n._selector_xmguq_77 {\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: space-between;\r\n    width: 100%;\r\n    background: rgba(0, 0, 0, 0.4);\r\n    border: 2px solid #334155;\r\n    border-radius: 8px;\r\n    padding: 0.5rem;\r\n}\r\n\r\n._stepButton_xmguq_99 {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 55px;\r\n    height: 55px;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    cursor: pointer;\r\n}\r\n\r\n._stepButton_xmguq_99:hover {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_hover.png');\r\n}\r\n\r\n._stepButton_xmguq_99:active {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_pressed.png');\r\n}\r\n\r\n._stepIcon_xmguq_141 {\r\n    width: 24px;\r\n    height: 24px;\r\n    object-fit: contain;\r\n}\r\n\r\n._valueDisplay_xmguq_153 {\r\n    color: #4ade80;\r\n    font-size: 1.5rem;\r\n    font-weight: 900;\r\n    text-shadow: 1px 1px 0px #000;\r\n    min-width: 80px;\r\n    text-align: center;\r\n}\r\n\r\n._saveButton_xmguq_171 {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 250px;\r\n    height: 70px;\r\n    color: white;\r\n    font-size: 1.25rem;\r\n    font-weight: 900;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n    text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);\r\n    transition: transform 0.1s;\r\n    margin-top: auto;\r\n}\r\n\r\n._saveButton_xmguq_171:active {\r\n    transform: translateY(2px);\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const card = "_card_xmguq_1";
export const title = "_title_xmguq_27";
export const optionGroup = "_optionGroup_xmguq_47";
export const label = "_label_xmguq_63";
export const selector = "_selector_xmguq_77";
export const stepButton = "_stepButton_xmguq_99";
export const stepIcon = "_stepIcon_xmguq_141";
export const valueDisplay = "_valueDisplay_xmguq_153";
export const saveButton = "_saveButton_xmguq_171";
export default {
	card: card,
	title: title,
	optionGroup: optionGroup,
	label: label,
	selector: selector,
	stepButton: stepButton,
	stepIcon: stepIcon,
	valueDisplay: valueDisplay,
	saveButton: saveButton
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))