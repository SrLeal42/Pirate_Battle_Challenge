import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/GameAnnouncer.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import { useGameStore, RuntimeStateEnum } from "/src/stores/gameStore.ts";
import { GAME_CONFIG } from "/src/core/config.ts";
import { HEALTH_TIER_THRESHOLDS } from "/src/core/health.ts";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameAnnouncer.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
const TIME_MARKS_S = [
	60,
	30,
	10
];
const END_REASON_TEXT = {
	time_up: "Time is up",
	player_died: "Your ship was destroyed"
};
const LOW_HEALTH = GAME_CONFIG.playerMaxHealth * HEALTH_TIER_THRESHOLDS.low;
function describe(state, prev) {
	if (state.runtimeState !== prev.runtimeState) {
		switch (state.runtimeState) {
			case RuntimeStateEnum.Playing: return prev.runtimeState === RuntimeStateEnum.Paused ? "Game resumed." : `Match started. ${state.sessionTime} seconds on the clock.`;
			case RuntimeStateEnum.Paused: return "Game paused.";
			case RuntimeStateEnum.Ended: return `Match over. ${state.endReason ? END_REASON_TEXT[state.endReason] : ""}. Final score: ${state.score}.`;
			default: return null;
		}
	}
	if (state.runtimeState !== RuntimeStateEnum.Playing) return null;
	if (state.playerHealth > 0 && state.playerHealth <= LOW_HEALTH && prev.playerHealth > LOW_HEALTH) {
		return `Warning: low health, ${Math.ceil(state.playerHealth)} left.`;
	}
	const mark = TIME_MARKS_S.find((s) => prev.timeRemaining > s * 1e3 && state.timeRemaining <= s * 1e3);
	return mark ? `${mark} seconds remaining.` : null;
}
/** Polite live region for discrete game events. */
export const GameAnnouncer = () => {
	_s();
	const [announcement, setAnnouncement] = useState({
		id: 0,
		text: ""
	});
	useEffect(() => useGameStore.subscribe((state, prev) => {
		const text = describe(state, prev);
		if (text) setAnnouncement((a) => ({
			id: a.id + 1,
			text
		}));
	}), []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "sr-only",
		role: "status",
		"aria-live": "polite",
		"aria-atomic": "true",
		children: /* @__PURE__ */ _jsxDEV("span", { children: announcement.text }, announcement.id, false, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 9
	}, this);
};
_s(GameAnnouncer, "OdepmK+RYkOeQmlr9QhJU65ho/Q=");
_c = GameAnnouncer;
var _c;
$RefreshReg$(_c, "GameAnnouncer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/GameAnnouncer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameAnnouncer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameAnnouncer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameAnnouncer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsZ0JBQWdCO0FBQzNDLFNBQVMsY0FBYyx3QkFBNkM7QUFDcEUsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyw4QkFBOEI7Ozs7QUFFdkMsTUFBTSxlQUFlO0NBQUM7Q0FBSTtDQUFJO0FBQUU7QUFDaEMsTUFBTSxrQkFBa0I7Q0FBRSxTQUFTO0NBQWMsYUFBYTtBQUEwQjtBQUN4RixNQUFNLGFBQWEsWUFBWSxrQkFBa0IsdUJBQXVCO0FBRXhFLFNBQVMsU0FBUyxPQUF1QixNQUFxQztDQUMxRSxJQUFJLE1BQU0saUJBQWlCLEtBQUssY0FBYztFQUMxQyxRQUFRLE1BQU0sY0FBZDtHQUNJLEtBQUssaUJBQWlCLFNBQ2xCLE9BQU8sS0FBSyxpQkFBaUIsaUJBQWlCLFNBQ3hDLGtCQUNBLGtCQUFrQixNQUFNLFlBQVk7R0FDOUMsS0FBSyxpQkFBaUIsUUFDbEIsT0FBTztHQUNYLEtBQUssaUJBQWlCLE9BQ2xCLE9BQU8sZUFBZSxNQUFNLFlBQVksZ0JBQWdCLE1BQU0sYUFBYSxHQUFHLGlCQUFpQixNQUFNLE1BQU07R0FDL0csU0FDSSxPQUFPO0VBQ2Y7Q0FDSjtDQUVBLElBQUksTUFBTSxpQkFBaUIsaUJBQWlCLFNBQVMsT0FBTztDQUU1RCxJQUFJLE1BQU0sZUFBZSxLQUFLLE1BQU0sZ0JBQWdCLGNBQWMsS0FBSyxlQUFlLFlBQVk7RUFDOUYsT0FBTyx3QkFBd0IsS0FBSyxLQUFLLE1BQU0sWUFBWSxFQUFFO0NBQ2pFO0NBRUEsTUFBTSxPQUFPLGFBQWEsTUFBTSxNQUFNLEtBQUssZ0JBQWdCLElBQUksT0FBUSxNQUFNLGlCQUFpQixJQUFJLEdBQUk7Q0FDdEcsT0FBTyxPQUFPLEdBQUcsS0FBSyx1QkFBdUI7QUFDakQ7O0FBR0EsT0FBTyxNQUFNLHNCQUFnQzs7Q0FDekMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVM7RUFBRSxJQUFJO0VBQUcsTUFBTTtDQUFHLENBQUM7Q0FFcEUsZ0JBQWdCLGFBQWEsV0FBVyxPQUFPLFNBQVM7RUFDcEQsTUFBTSxPQUFPLFNBQVMsT0FBTyxJQUFJO0VBQ2pDLElBQUksTUFBTSxpQkFBaUIsT0FBTztHQUFFLElBQUksRUFBRSxLQUFLO0dBQUc7RUFBSyxFQUFFO0NBQzdELENBQUMsR0FBRyxDQUFDLENBQUM7Q0FFTixPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQVUsTUFBSztFQUFTLGFBQVU7RUFBUyxlQUFZO1lBRWxFLHdCQUFDLFFBQUQsWUFBNkIsYUFBYSxLQUFXLEdBQTFDLGFBQWE7Ozs7U0FBNkI7Q0FDcEQ7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR2FtZUFubm91bmNlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZUdhbWVTdG9yZSwgUnVudGltZVN0YXRlRW51bSwgdHlwZSBHYW1lU3RvcmVTdGF0ZSB9IGZyb20gJy4uLy4uL3N0b3Jlcy9nYW1lU3RvcmUnO1xyXG5pbXBvcnQgeyBHQU1FX0NPTkZJRyB9IGZyb20gJy4uLy4uL2NvcmUvY29uZmlnJztcclxuaW1wb3J0IHsgSEVBTFRIX1RJRVJfVEhSRVNIT0xEUyB9IGZyb20gJy4uLy4uL2NvcmUvaGVhbHRoJztcclxuXHJcbmNvbnN0IFRJTUVfTUFSS1NfUyA9IFs2MCwgMzAsIDEwXSBhcyBjb25zdDtcclxuY29uc3QgRU5EX1JFQVNPTl9URVhUID0geyB0aW1lX3VwOiAnVGltZSBpcyB1cCcsIHBsYXllcl9kaWVkOiAnWW91ciBzaGlwIHdhcyBkZXN0cm95ZWQnIH0gYXMgY29uc3Q7XHJcbmNvbnN0IExPV19IRUFMVEggPSBHQU1FX0NPTkZJRy5wbGF5ZXJNYXhIZWFsdGggKiBIRUFMVEhfVElFUl9USFJFU0hPTERTLmxvdztcclxuXHJcbmZ1bmN0aW9uIGRlc2NyaWJlKHN0YXRlOiBHYW1lU3RvcmVTdGF0ZSwgcHJldjogR2FtZVN0b3JlU3RhdGUpOiBzdHJpbmcgfCBudWxsIHtcclxuICAgIGlmIChzdGF0ZS5ydW50aW1lU3RhdGUgIT09IHByZXYucnVudGltZVN0YXRlKSB7XHJcbiAgICAgICAgc3dpdGNoIChzdGF0ZS5ydW50aW1lU3RhdGUpIHtcclxuICAgICAgICAgICAgY2FzZSBSdW50aW1lU3RhdGVFbnVtLlBsYXlpbmc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcHJldi5ydW50aW1lU3RhdGUgPT09IFJ1bnRpbWVTdGF0ZUVudW0uUGF1c2VkXHJcbiAgICAgICAgICAgICAgICAgICAgPyAnR2FtZSByZXN1bWVkLidcclxuICAgICAgICAgICAgICAgICAgICA6IGBNYXRjaCBzdGFydGVkLiAke3N0YXRlLnNlc3Npb25UaW1lfSBzZWNvbmRzIG9uIHRoZSBjbG9jay5gO1xyXG4gICAgICAgICAgICBjYXNlIFJ1bnRpbWVTdGF0ZUVudW0uUGF1c2VkOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICdHYW1lIHBhdXNlZC4nO1xyXG4gICAgICAgICAgICBjYXNlIFJ1bnRpbWVTdGF0ZUVudW0uRW5kZWQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYE1hdGNoIG92ZXIuICR7c3RhdGUuZW5kUmVhc29uID8gRU5EX1JFQVNPTl9URVhUW3N0YXRlLmVuZFJlYXNvbl0gOiAnJ30uIEZpbmFsIHNjb3JlOiAke3N0YXRlLnNjb3JlfS5gO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGlmIChzdGF0ZS5ydW50aW1lU3RhdGUgIT09IFJ1bnRpbWVTdGF0ZUVudW0uUGxheWluZykgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgaWYgKHN0YXRlLnBsYXllckhlYWx0aCA+IDAgJiYgc3RhdGUucGxheWVySGVhbHRoIDw9IExPV19IRUFMVEggJiYgcHJldi5wbGF5ZXJIZWFsdGggPiBMT1dfSEVBTFRIKSB7XHJcbiAgICAgICAgcmV0dXJuIGBXYXJuaW5nOiBsb3cgaGVhbHRoLCAke01hdGguY2VpbChzdGF0ZS5wbGF5ZXJIZWFsdGgpfSBsZWZ0LmA7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbWFyayA9IFRJTUVfTUFSS1NfUy5maW5kKChzKSA9PiBwcmV2LnRpbWVSZW1haW5pbmcgPiBzICogMTAwMCAmJiBzdGF0ZS50aW1lUmVtYWluaW5nIDw9IHMgKiAxMDAwKTtcclxuICAgIHJldHVybiBtYXJrID8gYCR7bWFya30gc2Vjb25kcyByZW1haW5pbmcuYCA6IG51bGw7XHJcbn1cclxuXHJcbi8qKiBQb2xpdGUgbGl2ZSByZWdpb24gZm9yIGRpc2NyZXRlIGdhbWUgZXZlbnRzLiAqL1xyXG5leHBvcnQgY29uc3QgR2FtZUFubm91bmNlcjogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbYW5ub3VuY2VtZW50LCBzZXRBbm5vdW5jZW1lbnRdID0gdXNlU3RhdGUoeyBpZDogMCwgdGV4dDogJycgfSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHVzZUdhbWVTdG9yZS5zdWJzY3JpYmUoKHN0YXRlLCBwcmV2KSA9PiB7XHJcbiAgICAgICAgY29uc3QgdGV4dCA9IGRlc2NyaWJlKHN0YXRlLCBwcmV2KTtcclxuICAgICAgICBpZiAodGV4dCkgc2V0QW5ub3VuY2VtZW50KChhKSA9PiAoeyBpZDogYS5pZCArIDEsIHRleHQgfSkpO1xyXG4gICAgfSksIFtdKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3Itb25seVwiIHJvbGU9XCJzdGF0dXNcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIiBhcmlhLWF0b21pYz1cInRydWVcIj5cclxuICAgICAgICAgICAgey8qIE5ldyBrZXkgZm9yY2VzIHJlLWFubm91bmNlbWVudCBvZiByZXBlYXRlZCBtZXNzYWdlcyAqL31cclxuICAgICAgICAgICAgPHNwYW4ga2V5PXthbm5vdW5jZW1lbnQuaWR9Pnthbm5vdW5jZW1lbnQudGV4dH08L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG4iXX0=