import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/PauseScreen.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/PauseScreen.module.css"
const __vite__css = "._overlay_xqgz9_1 {\r\n    position: absolute;\r\n    inset: 0;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    background: rgba(15, 23, 42, 0.7);\r\n    backdrop-filter: blur(4px);\r\n    animation: _fadeIn_xqgz9_1 0.15s ease-out;\r\n    z-index: 10;\r\n}\r\n\r\n._card_xqgz9_25 {\r\n    background-image: url('/assets/png/default/ui/menu/panel_menu.png');\r\n    background-size: 100% 100%;\r\n    width: 400px;\r\n    min-height: 450px;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    justify-content: center;\r\n    padding: 3rem;\r\n    box-sizing: border-box;\r\n    gap: 2rem;\r\n}\r\n\r\n._title_xqgz9_53 {\r\n    color: #fde047;\r\n    font-size: 2.5rem;\r\n    text-transform: uppercase;\r\n    font-weight: 900;\r\n    text-shadow: 3px 3px 0px #000;\r\n    margin: 0;\r\n    margin-top: -30px;\r\n}\r\n\r\n._button_xqgz9_73 {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 250px;\r\n    height: 70px;\r\n    color: white;\r\n    font-size: 1.25rem;\r\n    font-weight: 900;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n    text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);\r\n    transition: transform 0.1s;\r\n}\r\n\r\n._button_xqgz9_73:hover {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_hover.png');\r\n}\r\n\r\n._button_xqgz9_73:active {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_pressed.png');\r\n    transform: translateY(2px);\r\n}\r\n\r\n._secondaryButton_xqgz9_123 {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 250px;\r\n    height: 60px;\r\n    color: #fde047;\r\n    font-size: 1.1rem;\r\n    font-weight: 900;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n    text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);\r\n    transition: transform 0.1s, filter 0.1s;\r\n}\r\n\r\n._secondaryButton_xqgz9_123:hover {\r\n    filter: brightness(1.1);\r\n}\r\n\r\n._secondaryButton_xqgz9_123:active {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_pressed.png');\r\n    transform: translateY(2px);\r\n}\r\n\r\n._buttonGroup_xqgz9_173 {\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 1.5rem;\r\n    margin-top: 1rem;\r\n}\r\n\r\n\r\n@keyframes _fadeIn_xqgz9_1 {\r\n    from {\r\n        opacity: 0;\r\n    }\r\n\r\n    to {\r\n        opacity: 1;\r\n    }\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const overlay = "_overlay_xqgz9_1";
export const fadeIn = "_fadeIn_xqgz9_1";
export const card = "_card_xqgz9_25";
export const title = "_title_xqgz9_53";
export const button = "_button_xqgz9_73";
export const secondaryButton = "_secondaryButton_xqgz9_123";
export const buttonGroup = "_buttonGroup_xqgz9_173";
export default {
	overlay: overlay,
	fadeIn: fadeIn,
	card: card,
	title: title,
	button: button,
	secondaryButton: secondaryButton,
	buttonGroup: buttonGroup
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))