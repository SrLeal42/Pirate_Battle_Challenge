import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/LeaderboardScreen.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LeaderboardScreen.module.css"
const __vite__css = "._card_1veag_1 {\r\n    background-image: url('/assets/png/default/ui/menu/panel_menu.png');\r\n    background-size: 100% 100%;\r\n    background-position: center;\r\n    background-repeat: no-repeat;\r\n    width: 650px;\r\n    min-height: 650px;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    padding: 3.5rem 4rem;\r\n    box-sizing: border-box;\r\n    gap: 1.5rem;\r\n}\r\n\r\n._title_1veag_31 {\r\n    color: #fde047;\r\n    font-size: 2.5rem;\r\n    text-transform: uppercase;\r\n    font-weight: 900;\r\n    text-shadow: 2px 2px 0px #000;\r\n    margin: 0;\r\n}\r\n\r\n._tabButtons_1veag_49 {\r\n    display: flex;\r\n    gap: 1rem;\r\n    margin-bottom: 1rem;\r\n}\r\n\r\n._tabActive_1veag_61 {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 160px;\r\n    height: 50px;\r\n    color: white;\r\n    font-size: 1rem;\r\n    font-weight: bold;\r\n    cursor: default;\r\n    text-transform: uppercase;\r\n}\r\n\r\n._tabInactive_1veag_89 {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 160px;\r\n    height: 50px;\r\n    color: #fde047;\r\n    font-size: 1rem;\r\n    font-weight: bold;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n    transition: filter 0.1s;\r\n}\r\n\r\n._tabInactive_1veag_89:hover {\r\n    filter: brightness(1.2);\r\n}\r\n\r\n._tableContainer_1veag_127 {\r\n    flex: 1;\r\n    width: 100%;\r\n    background: rgba(0, 0, 0, 0.3);\r\n    border-radius: 8px;\r\n    padding: 1rem;\r\n}\r\n\r\n._table_1veag_127 {\r\n    width: 100%;\r\n    border-collapse: collapse;\r\n    color: white;\r\n    text-align: left;\r\n}\r\n\r\n._table_1veag_127 th {\r\n    color: #fde047;\r\n    border-bottom: 2px solid rgba(255, 255, 255, 0.2);\r\n    padding: 0.5rem;\r\n    text-transform: uppercase;\r\n}\r\n\r\n._table_1veag_127 td {\r\n    padding: 0.5rem;\r\n    border-bottom: 1px solid rgba(255, 255, 255, 0.1);\r\n}\r\n\r\n._highlightRow_1veag_181 {\r\n    background-color: rgba(253, 224, 71, 0.15);\r\n    font-weight: bold;\r\n}\r\n\r\n._textGreen_1veag_191 {\r\n    color: #4ade80;\r\n}\r\n\r\n._textRed_1veag_199 {\r\n    color: #f87171;\r\n}\r\n\r\n._loading_1veag_207,\r\n._empty_1veag_209 {\r\n    text-align: center;\r\n    color: white;\r\n    font-weight: bold;\r\n    margin-top: 2rem;\r\n}\r\n\r\n._pagination_1veag_223 {\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: center;\r\n    width: 100%;\r\n}\r\n\r\n._closeButton_1veag_237 {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 200px;\r\n    height: 60px;\r\n    color: #fde047;\r\n    font-size: 1.1rem;\r\n    font-weight: 900;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n}\r\n\r\n._categoryInfo_1veag_265 {\r\n    color: #c5c5c5;\r\n    font-size: 0.9rem;\r\n    font-weight: bold;\r\n    text-transform: uppercase;\r\n    margin-top: -0.5rem;\r\n    margin-bottom: 1.5rem;\r\n    text-shadow: 1px 1px 0px #000;\r\n}\r\n\r\n\r\n\r\n\r\n._pageButton_1veag_291 {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 60px;\r\n    height: 60px;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    cursor: pointer;\r\n    transition: transform 0.1s;\r\n}\r\n\r\n._pageButton_1veag_291:hover:not(:disabled) {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_hover.png');\r\n}\r\n\r\n._pageButton_1veag_291:active:not(:disabled) {\r\n    background-image: url('/assets/png/default/ui/controls/button_round_pressed.png');\r\n    transform: translateY(2px);\r\n}\r\n\r\n._pageButton_1veag_291:disabled {\r\n    filter: grayscale(1) opacity(0.5);\r\n    cursor: not-allowed;\r\n}\r\n\r\n._pageIcon_1veag_347 {\r\n    width: 24px;\r\n    height: 24px;\r\n}\r\n\r\n._iconFlipped_1veag_357 {\r\n    transform: scaleX(-1);\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const card = "_card_1veag_1";
export const title = "_title_1veag_31";
export const tabButtons = "_tabButtons_1veag_49";
export const tabActive = "_tabActive_1veag_61";
export const tabInactive = "_tabInactive_1veag_89";
export const tableContainer = "_tableContainer_1veag_127";
export const table = "_table_1veag_127";
export const highlightRow = "_highlightRow_1veag_181";
export const textGreen = "_textGreen_1veag_191";
export const textRed = "_textRed_1veag_199";
export const loading = "_loading_1veag_207";
export const empty = "_empty_1veag_209";
export const pagination = "_pagination_1veag_223";
export const closeButton = "_closeButton_1veag_237";
export const categoryInfo = "_categoryInfo_1veag_265";
export const pageButton = "_pageButton_1veag_291";
export const pageIcon = "_pageIcon_1veag_347";
export const iconFlipped = "_iconFlipped_1veag_357";
export default {
	card: card,
	title: title,
	tabButtons: tabButtons,
	tabActive: tabActive,
	tabInactive: tabInactive,
	tableContainer: tableContainer,
	table: table,
	highlightRow: highlightRow,
	textGreen: textGreen,
	textRed: textRed,
	loading: loading,
	empty: empty,
	pagination: pagination,
	closeButton: closeButton,
	categoryInfo: categoryInfo,
	pageButton: pageButton,
	pageIcon: pageIcon,
	iconFlipped: iconFlipped
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))