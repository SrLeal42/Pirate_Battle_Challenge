import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/GameOverScreen.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/GameOverScreen.module.css"
const __vite__css = "._overlay_1xjvh_1 {\r\n    position: absolute;\r\n    inset: 0;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    background: rgba(15, 23, 42, 0.7);\r\n    backdrop-filter: blur(4px);\r\n    /* Desfoca o jogo no fundo */\r\n    animation: _fadeIn_1xjvh_1 0.5s ease-out;\r\n}\r\n\r\n._card_1xjvh_25 {\r\n    background-image: url('/assets/png/default/ui/menu/panel_menu.png');\r\n    background-size: 100% 100%;\r\n    background-position: center;\r\n    background-repeat: no-repeat;\r\n\r\n    width: 450px;\r\n    min-height: 550px;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    justify-content: center;\r\n    padding: 3rem 4rem;\r\n    box-sizing: border-box;\r\n    gap: 1.5rem;\r\n}\r\n\r\n._title_1xjvh_59 {\r\n    color: #fde047;\r\n    font-size: 3rem;\r\n    text-transform: uppercase;\r\n    font-weight: 900;\r\n    text-shadow: 3px 3px 0px #000;\r\n    margin: 0;\r\n    margin-top: -20px;\r\n    text-align: center;\r\n}\r\n\r\n._subtitle_1xjvh_81 {\r\n    color: #fff;\r\n    font-size: 1.2rem;\r\n    font-weight: bold;\r\n    text-shadow: 1px 1px 0px #000;\r\n    text-align: center;\r\n}\r\n\r\n._scoreLabel_1xjvh_97 {\r\n    color: #fde047;\r\n    font-size: 1.5rem;\r\n    font-weight: 800;\r\n    text-transform: uppercase;\r\n    text-shadow: 1px 1px 0px #000;\r\n    margin-top: 1rem;\r\n}\r\n\r\n._scoreValue_1xjvh_115 {\r\n    font-size: 4.5rem;\r\n    font-weight: 900;\r\n    text-shadow: 3px 3px 0px #000;\r\n    margin-bottom: 0.5rem;\r\n}\r\n\r\n._button_1xjvh_129 {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 250px;\r\n    height: 75px;\r\n    color: white;\r\n    font-size: 1.25rem;\r\n    font-weight: 900;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n    text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);\r\n    transition: transform 0.1s;\r\n}\r\n\r\n._button_1xjvh_129:hover {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_hover.png');\r\n}\r\n\r\n._button_1xjvh_129:active {\r\n    background-image: url('/assets/png/default/ui/menu/button_primary_pressed.png');\r\n    transform: translateY(2px);\r\n}\r\n\r\n\r\n._scoreWrapper_1xjvh_181 {\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n}\r\n\r\n._buttonGroup_1xjvh_193 {\r\n    display: flex;\r\n    flex-direction: column;\r\n    gap: 1rem;\r\n}\r\n\r\n\r\n@keyframes _fadeIn_1xjvh_1 {\r\n    from {\r\n        opacity: 0;\r\n    }\r\n\r\n    to {\r\n        opacity: 1;\r\n    }\r\n}\r\n\r\n._secondaryButton_1xjvh_227 {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_normal.png');\r\n    background-size: 100% 100%;\r\n    background-color: transparent;\r\n    border: none;\r\n    width: 250px;\r\n    height: 65px;\r\n    color: #fde047;\r\n    font-size: 1.1rem;\r\n    font-weight: 900;\r\n    cursor: pointer;\r\n    text-transform: uppercase;\r\n    text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);\r\n    transition: transform 0.1s, filter 0.1s;\r\n}\r\n\r\n._secondaryButton_1xjvh_227:hover {\r\n    filter: brightness(1.1);\r\n}\r\n\r\n._secondaryButton_1xjvh_227:active {\r\n    background-image: url('/assets/png/default/ui/menu/button_secondary_pressed.png');\r\n    transform: translateY(2px);\r\n}\r\n\r\n\r\n\r\n._scoreVictory_1xjvh_281 {\r\n    color: #4ade80;\r\n}\r\n\r\n._scoreDefeat_1xjvh_289 {\r\n    color: #f87171;\r\n}\r\n\r\n._statusMessage_1xjvh_297 {\r\n    margin-top: 0.5rem;\r\n    font-weight: bold;\r\n    color: #fde047;\r\n    text-align: center;\r\n}\r\n\r\n._details_1xjvh_311 {\r\n    display: grid;\r\n    grid-template-columns: auto auto;\r\n    column-gap: 1.5rem;\r\n    row-gap: 0.4rem;\r\n    margin: 0;\r\n    padding: 0.75rem 1.25rem;\r\n    width: 100%;\r\n    box-sizing: border-box;\r\n    background: rgba(0, 0, 0, 0.4);\r\n    border: 2px solid #334155;\r\n    border-radius: 8px;\r\n}\r\n\r\n._details_1xjvh_311 dt {\r\n    color: #fde047;\r\n    font-size: 0.9rem;\r\n    font-weight: 800;\r\n    text-transform: uppercase;\r\n    letter-spacing: 0.04em;\r\n    text-shadow: 1px 1px 0 #000;\r\n    align-self: center;\r\n}\r\n\r\n._details_1xjvh_311 dd {\r\n    margin: 0;\r\n    color: #f8fafc;\r\n    font-size: 1.1rem;\r\n    font-weight: 900;\r\n    text-align: right;\r\n    font-variant-numeric: tabular-nums;\r\n    text-shadow: 1px 1px 0 #000;\r\n}\r\n\r\n@media (max-height: 500px) {\r\n    ._details_1xjvh_311 {\r\n        padding: 0.4rem 0.9rem;\r\n        row-gap: 0.2rem;\r\n    }\r\n\r\n    ._details_1xjvh_311 dt {\r\n        font-size: 0.75rem;\r\n    }\r\n\r\n    ._details_1xjvh_311 dd {\r\n        font-size: 0.95rem;\r\n    }\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const overlay = "_overlay_1xjvh_1";
export const fadeIn = "_fadeIn_1xjvh_1";
export const card = "_card_1xjvh_25";
export const title = "_title_1xjvh_59";
export const subtitle = "_subtitle_1xjvh_81";
export const scoreLabel = "_scoreLabel_1xjvh_97";
export const scoreValue = "_scoreValue_1xjvh_115";
export const button = "_button_1xjvh_129";
export const scoreWrapper = "_scoreWrapper_1xjvh_181";
export const buttonGroup = "_buttonGroup_1xjvh_193";
export const secondaryButton = "_secondaryButton_1xjvh_227";
export const scoreVictory = "_scoreVictory_1xjvh_281";
export const scoreDefeat = "_scoreDefeat_1xjvh_289";
export const statusMessage = "_statusMessage_1xjvh_297";
export const details = "_details_1xjvh_311";
export default {
	overlay: overlay,
	fadeIn: fadeIn,
	card: card,
	title: title,
	subtitle: subtitle,
	scoreLabel: scoreLabel,
	scoreValue: scoreValue,
	button: button,
	scoreWrapper: scoreWrapper,
	buttonGroup: buttonGroup,
	secondaryButton: secondaryButton,
	scoreVictory: scoreVictory,
	scoreDefeat: scoreDefeat,
	statusMessage: statusMessage,
	details: details
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))