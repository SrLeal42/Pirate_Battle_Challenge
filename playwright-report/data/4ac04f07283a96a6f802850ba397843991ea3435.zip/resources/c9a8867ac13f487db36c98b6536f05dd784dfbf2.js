import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/ControlsGuide.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/ControlsGuide.module.css"
const __vite__css = "._card_nmrl5_1 {\r\n    background-image: url('/assets/png/default/ui/menu/panel_menu.png');\r\n    background-size: 100% 100%;\r\n    width: 540px;\r\n    max-width: 100%;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    gap: 1.25rem;\r\n    padding: 3rem 3.5rem;\r\n    box-sizing: border-box;\r\n}\r\n\r\n._title_nmrl5_27 {\r\n    margin: -10px 0 0;\r\n    color: #fde047;\r\n    font-size: 2.5rem;\r\n    font-weight: 900;\r\n    text-transform: uppercase;\r\n    text-shadow: 3px 3px 0 #000;\r\n}\r\n\r\n._table_nmrl5_45 {\r\n    width: 100%;\r\n    border-collapse: collapse;\r\n    color: #f8fafc;\r\n    font-size: 0.95rem;\r\n}\r\n\r\n._table_nmrl5_45 th,\r\n._table_nmrl5_45 td {\r\n    padding: 0.4rem 0.5rem;\r\n    text-align: left;\r\n    border-bottom: 1px solid rgba(255, 255, 255, 0.12);\r\n}\r\n\r\n._table_nmrl5_45 thead th {\r\n    color: #fde047;\r\n    font-size: 0.8rem;\r\n    letter-spacing: 0.05em;\r\n    text-transform: uppercase;\r\n}\r\n\r\n._table_nmrl5_45 tbody th {\r\n    font-weight: 700;\r\n}\r\n\r\n._key_nmrl5_95 {\r\n    display: inline-block;\r\n    min-width: 1.8em;\r\n    margin-right: 0.3rem;\r\n    padding: 0.15rem 0.45rem;\r\n    border: 1px solid rgba(253, 224, 71, 0.5);\r\n    border-radius: 6px;\r\n    background: rgba(0, 0, 0, 0.45);\r\n    box-shadow: 0 2px 0 rgba(0, 0, 0, 0.6);\r\n    color: #fff;\r\n    font: 700 0.85rem/1.2 'Inter', system-ui, sans-serif;\r\n    text-align: center;\r\n}\r\n\r\n._icon_nmrl5_123 {\r\n    width: 28px;\r\n    height: 28px;\r\n    object-fit: contain;\r\n    vertical-align: middle;\r\n}\r\n\r\n._hint_nmrl5_137 {\r\n    margin: 0;\r\n    color: #cbd5e1;\r\n    font-size: 0.9rem;\r\n    text-align: center;\r\n    text-shadow: 1px 1px 0 #000;\r\n}\r\n\r\n._closeButton_nmrl5_153 {\r\n    background: url('/assets/png/default/ui/menu/button_primary_normal.png') center / 100% 100% no-repeat transparent;\r\n    border: none;\r\n    width: 220px;\r\n    height: 66px;\r\n    color: #fff;\r\n    font-size: 1.2rem;\r\n    font-weight: 900;\r\n    text-transform: uppercase;\r\n    text-shadow: 2px 2px 0 rgba(0, 0, 0, 0.5);\r\n    cursor: pointer;\r\n}\r\n\r\n._closeButton_nmrl5_153:active {\r\n    transform: translateY(2px);\r\n}\r\n\r\n@media (max-height: 500px) {\r\n    ._card_nmrl5_1 {\r\n        gap: 0.6rem;\r\n        padding: 1.5rem 2rem;\r\n    }\r\n\r\n    ._title_nmrl5_27 {\r\n        font-size: 1.6rem;\r\n    }\r\n\r\n    ._table_nmrl5_45 th,\r\n    ._table_nmrl5_45 td {\r\n        padding: 0.2rem 0.4rem;\r\n    }\r\n\r\n    ._closeButton_nmrl5_153 {\r\n        height: 50px;\r\n    }\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const card = "_card_nmrl5_1";
export const title = "_title_nmrl5_27";
export const table = "_table_nmrl5_45";
export const key = "_key_nmrl5_95";
export const icon = "_icon_nmrl5_123";
export const hint = "_hint_nmrl5_137";
export const closeButton = "_closeButton_nmrl5_153";
export default {
	card: card,
	title: title,
	table: table,
	key: key,
	icon: icon,
	hint: hint,
	closeButton: closeButton
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))