import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/AssetBar.module.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/AssetBar.module.css"
const __vite__css = "._bar_1pq5n_1 {\r\n    position: relative;\r\n    width: 100%;\r\n    aspect-ratio: 256 / 48;\r\n    container-type: inline-size;\r\n    /* label scales with bar width */\r\n    user-select: none;\r\n}\r\n\r\n._layer_1pq5n_19 {\r\n    position: absolute;\r\n    inset: 0;\r\n    width: 100%;\r\n    height: 100%;\r\n    pointer-events: none;\r\n}\r\n\r\n._fill_1pq5n_35 {\r\n    transition: clip-path 0.2s ease-out;\r\n}\r\n\r\n._label_1pq5n_43 {\r\n    position: absolute;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    color: #fff;\r\n    font-family: 'Inter', system-ui, sans-serif;\r\n    font-weight: 800;\r\n    font-size: 6.5cqw;\r\n    line-height: 1;\r\n    font-variant-numeric: tabular-nums;\r\n    text-shadow: 1px 1px 0 rgba(0, 0, 0, 0.85), -1px -1px 0 rgba(0, 0, 0, 0.85);\r\n}\r\n\r\n@media (prefers-reduced-motion: reduce) {\r\n    ._fill_1pq5n_35 {\r\n        transition: none;\r\n    }\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
export const bar = "_bar_1pq5n_1";
export const layer = "_layer_1pq5n_19";
export const fill = "_fill_1pq5n_35";
export const label = "_label_1pq5n_43";
export default {
	bar: bar,
	layer: layer,
	fill: fill,
	label: label
};

import.meta.hot.prune(() => __vite__removeStyle(__vite__id))