import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/AssetBar.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import styles from "/src/ui/components/AssetBar.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/AssetBar.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
// From ui_sheet.json → "player_health" layout (logical px)
const FRAME = {
	w: 256,
	h: 48
};
const FILL = {
	x: 30,
	y: 15,
	w: 196,
	h: 20
};
const HUD_PATH = "/assets/png/default/ui/hud/";
const pct = (value, total) => `${value / total * 100}%`;
const LABEL_BOX = {
	left: pct(FILL.x, FRAME.w),
	top: pct(FILL.y, FRAME.h),
	width: pct(FILL.w, FRAME.w),
	height: pct(FILL.h, FRAME.h)
};
export const AssetBar = ({ ratio, color, label, className, ...rest }) => {
	const clamped = Math.min(1, Math.max(0, ratio));
	const rightInset = FRAME.w - FILL.x - FILL.w * clamped;
	return /* @__PURE__ */ _jsxDEV("div", {
		...rest,
		className: `${styles.bar} ${className ?? ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("img", {
				src: `${HUD_PATH}health_frame.png`,
				className: styles.layer,
				alt: "",
				"aria-hidden": "true",
				draggable: false
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("img", {
				src: `${HUD_PATH}health_fill_${color}.png`,
				className: `${styles.layer} ${styles.fill}`,
				style: { clipPath: `inset(0 ${pct(rightInset, FRAME.w)} 0 0)` },
				alt: "",
				"aria-hidden": "true",
				draggable: false
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 13
			}, this),
			label !== undefined && /* @__PURE__ */ _jsxDEV("span", {
				className: styles.label,
				style: LABEL_BOX,
				"aria-hidden": "true",
				children: label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 9
	}, this);
};
_c = AssetBar;
var _c;
$RefreshReg$(_c, "AssetBar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/AssetBar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/AssetBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/AssetBar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/AssetBar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sWUFBWTs7OztBQUduQixNQUFNLFFBQVE7Q0FBRSxHQUFHO0NBQUssR0FBRztBQUFHO0FBQzlCLE1BQU0sT0FBTztDQUFFLEdBQUc7Q0FBSSxHQUFHO0NBQUksR0FBRztDQUFLLEdBQUc7QUFBRztBQUMzQyxNQUFNLFdBQVc7QUFVakIsTUFBTSxPQUFPLE9BQWUsVUFBMEIsR0FBSSxRQUFRLFFBQVMsSUFBSTtBQUUvRSxNQUFNLFlBQWlDO0NBQ25DLE1BQU0sSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO0NBQ3pCLEtBQUssSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO0NBQ3hCLE9BQU8sSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO0NBQzFCLFFBQVEsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDO0FBQy9CO0FBRUEsT0FBTyxNQUFNLFlBQXFDLEVBQUUsT0FBTyxPQUFPLE9BQU8sV0FBVyxHQUFHLFdBQVc7Q0FDOUYsTUFBTSxVQUFVLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssQ0FBQztDQUM5QyxNQUFNLGFBQWEsTUFBTSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUk7Q0FFL0MsT0FDSSx3QkFBQyxPQUFEO0VBQUssR0FBSTtFQUFNLFdBQVcsR0FBRyxPQUFPLElBQUksR0FBRyxhQUFhO1lBQXhEO0dBRUksd0JBQUMsT0FBRDtJQUFLLEtBQUssR0FBRyxTQUFTO0lBQW1CLFdBQVcsT0FBTztJQUFPLEtBQUk7SUFBRyxlQUFZO0lBQU8sV0FBVztHQUFROzs7OztHQUMvRyx3QkFBQyxPQUFEO0lBQ0ksS0FBSyxHQUFHLFNBQVMsY0FBYyxNQUFNO0lBQ3JDLFdBQVcsR0FBRyxPQUFPLE1BQU0sR0FBRyxPQUFPO0lBQ3JDLE9BQU8sRUFBRSxVQUFVLFdBQVcsSUFBSSxZQUFZLE1BQU0sQ0FBQyxFQUFFLE9BQU87SUFDOUQsS0FBSTtJQUNKLGVBQVk7SUFDWixXQUFXO0dBQ2Q7Ozs7O0dBQ0EsVUFBVSxhQUNQLHdCQUFDLFFBQUQ7SUFBTSxXQUFXLE9BQU87SUFBTyxPQUFPO0lBQVcsZUFBWTtjQUFRO0dBQVk7Ozs7O0VBRXBGOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBc3NldEJhci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuL0Fzc2V0QmFyLm1vZHVsZS5jc3MnO1xyXG5cclxuLy8gRnJvbSB1aV9zaGVldC5qc29uIOKGkiBcInBsYXllcl9oZWFsdGhcIiBsYXlvdXQgKGxvZ2ljYWwgcHgpXHJcbmNvbnN0IEZSQU1FID0geyB3OiAyNTYsIGg6IDQ4IH0gYXMgY29uc3Q7XHJcbmNvbnN0IEZJTEwgPSB7IHg6IDMwLCB5OiAxNSwgdzogMTk2LCBoOiAyMCB9IGFzIGNvbnN0O1xyXG5jb25zdCBIVURfUEFUSCA9ICcvYXNzZXRzL3BuZy9kZWZhdWx0L3VpL2h1ZC8nO1xyXG5cclxuZXhwb3J0IHR5cGUgQmFyQ29sb3IgPSAnZ3JlZW4nIHwgJ2FtYmVyJyB8ICdyZWQnO1xyXG5cclxudHlwZSBBc3NldEJhclByb3BzID0gUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTERpdkVsZW1lbnQ+ICYge1xyXG4gICAgcmF0aW86IG51bWJlcjtcclxuICAgIGNvbG9yOiBCYXJDb2xvcjtcclxuICAgIGxhYmVsPzogUmVhY3QuUmVhY3ROb2RlO1xyXG59O1xyXG5cclxuY29uc3QgcGN0ID0gKHZhbHVlOiBudW1iZXIsIHRvdGFsOiBudW1iZXIpOiBzdHJpbmcgPT4gYCR7KHZhbHVlIC8gdG90YWwpICogMTAwfSVgO1xyXG5cclxuY29uc3QgTEFCRUxfQk9YOiBSZWFjdC5DU1NQcm9wZXJ0aWVzID0ge1xyXG4gICAgbGVmdDogcGN0KEZJTEwueCwgRlJBTUUudyksXHJcbiAgICB0b3A6IHBjdChGSUxMLnksIEZSQU1FLmgpLFxyXG4gICAgd2lkdGg6IHBjdChGSUxMLncsIEZSQU1FLncpLFxyXG4gICAgaGVpZ2h0OiBwY3QoRklMTC5oLCBGUkFNRS5oKSxcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBBc3NldEJhcjogUmVhY3QuRkM8QXNzZXRCYXJQcm9wcz4gPSAoeyByYXRpbywgY29sb3IsIGxhYmVsLCBjbGFzc05hbWUsIC4uLnJlc3QgfSkgPT4ge1xyXG4gICAgY29uc3QgY2xhbXBlZCA9IE1hdGgubWluKDEsIE1hdGgubWF4KDAsIHJhdGlvKSk7XHJcbiAgICBjb25zdCByaWdodEluc2V0ID0gRlJBTUUudyAtIEZJTEwueCAtIEZJTEwudyAqIGNsYW1wZWQ7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IHsuLi5yZXN0fSBjbGFzc05hbWU9e2Ake3N0eWxlcy5iYXJ9ICR7Y2xhc3NOYW1lID8/ICcnfWB9PlxyXG4gICAgICAgICAgICB7LyogRHJhdyBvcmRlciBmcm9tIGF0bGFzIG1ldGFkYXRhOiBmcmFtZSDihpIgZmlsbCAqL31cclxuICAgICAgICAgICAgPGltZyBzcmM9e2Ake0hVRF9QQVRIfWhlYWx0aF9mcmFtZS5wbmdgfSBjbGFzc05hbWU9e3N0eWxlcy5sYXllcn0gYWx0PVwiXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgZHJhZ2dhYmxlPXtmYWxzZX0gLz5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgc3JjPXtgJHtIVURfUEFUSH1oZWFsdGhfZmlsbF8ke2NvbG9yfS5wbmdgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtzdHlsZXMubGF5ZXJ9ICR7c3R5bGVzLmZpbGx9YH1cclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNsaXBQYXRoOiBgaW5zZXQoMCAke3BjdChyaWdodEluc2V0LCBGUkFNRS53KX0gMCAwKWAgfX1cclxuICAgICAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgICAgICAgICAgICAgZHJhZ2dhYmxlPXtmYWxzZX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAge2xhYmVsICE9PSB1bmRlZmluZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtzdHlsZXMubGFiZWx9IHN0eWxlPXtMQUJFTF9CT1h9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiPntsYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG4iXX0=