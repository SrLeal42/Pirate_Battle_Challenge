import { r as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=43418a0e";
//#region node_modules/pixi.js/lib/extensions/Extensions.mjs
var ExtensionType = /* @__PURE__ */ ((ExtensionType2) => {
	ExtensionType2["Application"] = "application";
	ExtensionType2["WebGLPipes"] = "webgl-pipes";
	ExtensionType2["WebGLPipesAdaptor"] = "webgl-pipes-adaptor";
	ExtensionType2["WebGLSystem"] = "webgl-system";
	ExtensionType2["WebGLLoader"] = "webgl-loader";
	ExtensionType2["WebGPUPipes"] = "webgpu-pipes";
	ExtensionType2["WebGPUPipesAdaptor"] = "webgpu-pipes-adaptor";
	ExtensionType2["WebGPUSystem"] = "webgpu-system";
	ExtensionType2["WebGPULoader"] = "webgpu-loader";
	ExtensionType2["CanvasSystem"] = "canvas-system";
	ExtensionType2["CanvasPipesAdaptor"] = "canvas-pipes-adaptor";
	ExtensionType2["CanvasPipes"] = "canvas-pipes";
	ExtensionType2["CanvasLoader"] = "canvas-loader";
	ExtensionType2["Asset"] = "asset";
	ExtensionType2["LoadParser"] = "load-parser";
	ExtensionType2["ResolveParser"] = "resolve-parser";
	ExtensionType2["CacheParser"] = "cache-parser";
	ExtensionType2["DetectionParser"] = "detection-parser";
	ExtensionType2["MaskEffect"] = "mask-effect";
	ExtensionType2["BlendMode"] = "blend-mode";
	ExtensionType2["TextureSource"] = "texture-source";
	ExtensionType2["TextureUploaderWebGL"] = "texture-uploader-webgl";
	ExtensionType2["TextureUploaderWebGPU"] = "texture-uploader-webgpu";
	ExtensionType2["Environment"] = "environment";
	ExtensionType2["ShapeBuilder"] = "shape-builder";
	ExtensionType2["Batcher"] = "batcher";
	return ExtensionType2;
})(ExtensionType || {});
var normalizeExtension = (ext) => {
	if (typeof ext === "function" || typeof ext === "object" && ext.extension) {
		if (!ext.extension) throw new Error("Extension class must have an extension object");
		ext = {
			...typeof ext.extension !== "object" ? { type: ext.extension } : ext.extension,
			ref: ext
		};
	}
	if (typeof ext === "object") ext = { ...ext };
	else throw new Error("Invalid extension type");
	if (typeof ext.type === "string") ext.type = [ext.type];
	return ext;
};
var normalizeExtensionPriority = (ext, defaultPriority) => normalizeExtension(ext).priority ?? defaultPriority;
var extensions = {
	/** @ignore */
	_addHandlers: {},
	/** @ignore */
	_removeHandlers: {},
	/** @ignore */
	_queue: {},
	/**
	* Remove extensions from PixiJS.
	* @param extensions - Extensions to be removed. Can be:
	* - Extension class with static `extension` property
	* - Extension format object with `type` and `ref`
	* - Multiple extensions as separate arguments
	* @returns {extensions} this for chaining
	* @example
	* ```ts
	* // Remove a single extension
	* extensions.remove(MyRendererPlugin);
	*
	* // Remove multiple extensions
	* extensions.remove(
	*     MyRendererPlugin,
	*     MySystemPlugin
	* );
	* ```
	* @see {@link ExtensionType} For available extension types
	* @see {@link ExtensionFormat} For extension format details
	*/
	remove(...extensions2) {
		extensions2.map(normalizeExtension).forEach((ext) => {
			ext.type.forEach((type) => this._removeHandlers[type]?.(ext));
		});
		return this;
	},
	/**
	* Register new extensions with PixiJS. Extensions can be registered in multiple formats:
	* - As a class with a static `extension` property
	* - As an extension format object
	* - As multiple extensions passed as separate arguments
	* @param extensions - Extensions to add to PixiJS. Each can be:
	* - A class with static `extension` property
	* - An extension format object with `type` and `ref`
	* - Multiple extensions as separate arguments
	* @returns This extensions instance for chaining
	* @example
	* ```ts
	* // Register a simple extension
	* extensions.add(MyRendererPlugin);
	*
	* // Register multiple extensions
	* extensions.add(
	*     MyRendererPlugin,
	*     MySystemPlugin,
	* });
	* ```
	* @see {@link ExtensionType} For available extension types
	* @see {@link ExtensionFormat} For extension format details
	* @see {@link extensions.remove} For removing registered extensions
	*/
	add(...extensions2) {
		extensions2.map(normalizeExtension).forEach((ext) => {
			ext.type.forEach((type) => {
				const handlers = this._addHandlers;
				const queue = this._queue;
				if (!handlers[type]) {
					queue[type] = queue[type] || [];
					queue[type]?.push(ext);
				} else handlers[type]?.(ext);
			});
		});
		return this;
	},
	/**
	* Internal method to handle extensions by name.
	* @param type - The extension type.
	* @param onAdd  - Function handler when extensions are added/registered {@link StrictExtensionFormat}.
	* @param onRemove  - Function handler when extensions are removed/unregistered {@link StrictExtensionFormat}.
	* @returns this for chaining.
	* @internal
	* @ignore
	*/
	handle(type, onAdd, onRemove) {
		const addHandlers = this._addHandlers;
		const removeHandlers = this._removeHandlers;
		if (addHandlers[type] || removeHandlers[type]) throw new Error(`Extension type ${type} already has a handler`);
		addHandlers[type] = onAdd;
		removeHandlers[type] = onRemove;
		const queue = this._queue;
		if (queue[type]) {
			queue[type]?.forEach((ext) => onAdd(ext));
			delete queue[type];
		}
		return this;
	},
	/**
	* Handle a type, but using a map by `name` property.
	* @param type - Type of extension to handle.
	* @param map - The object map of named extensions.
	* @returns this for chaining.
	* @ignore
	*/
	handleByMap(type, map) {
		return this.handle(type, (extension) => {
			if (extension.name) map[extension.name] = extension.ref;
		}, (extension) => {
			if (extension.name) delete map[extension.name];
		});
	},
	/**
	* Handle a type, but using a list of extensions with a `name` property.
	* @param type - Type of extension to handle.
	* @param map - The array of named extensions.
	* @param defaultPriority - Fallback priority if none is defined.
	* @returns this for chaining.
	* @ignore
	*/
	handleByNamedList(type, map, defaultPriority = -1) {
		return this.handle(type, (extension) => {
			if (map.findIndex((item) => item.name === extension.name) >= 0) return;
			map.push({
				name: extension.name,
				value: extension.ref
			});
			map.sort((a, b) => normalizeExtensionPriority(b.value, defaultPriority) - normalizeExtensionPriority(a.value, defaultPriority));
		}, (extension) => {
			const index = map.findIndex((item) => item.name === extension.name);
			if (index !== -1) map.splice(index, 1);
		});
	},
	/**
	* Handle a type, but using a list of extensions.
	* @param type - Type of extension to handle.
	* @param list - The list of extensions.
	* @param defaultPriority - The default priority to use if none is specified.
	* @returns this for chaining.
	* @ignore
	*/
	handleByList(type, list, defaultPriority = -1) {
		return this.handle(type, (extension) => {
			if (list.includes(extension.ref)) return;
			list.push(extension.ref);
			list.sort((a, b) => normalizeExtensionPriority(b, defaultPriority) - normalizeExtensionPriority(a, defaultPriority));
		}, (extension) => {
			const index = list.indexOf(extension.ref);
			if (index !== -1) list.splice(index, 1);
		});
	},
	/**
	* Mixin the source object(s) properties into the target class's prototype.
	* Copies all property descriptors from source objects to the target's prototype.
	* @param Target - The target class to mix properties into
	* @param sources - One or more source objects containing properties to mix in
	* @example
	* ```ts
	* // Create a mixin with shared properties
	* const moveable = {
	*     x: 0,
	*     y: 0,
	*     move(x: number, y: number) {
	*         this.x += x;
	*         this.y += y;
	*     }
	* };
	*
	* // Create a mixin with computed properties
	* const scalable = {
	*     scale: 1,
	*     get scaled() {
	*         return this.scale > 1;
	*     }
	* };
	*
	* // Apply mixins to a class
	* extensions.mixin(Sprite, moveable, scalable);
	*
	* // Use mixed-in properties
	* const sprite = new Sprite();
	* sprite.move(10, 20);
	* console.log(sprite.x, sprite.y); // 10, 20
	* ```
	* @remarks
	* - Copies all properties including getters/setters
	* - Does not modify source objects
	* - Preserves property descriptors
	* @see {@link Object.defineProperties} For details on property descriptors
	* @see {@link Object.getOwnPropertyDescriptors} For details on property copying
	*/
	mixin(Target, ...sources) {
		for (const source of sources) Object.defineProperties(Target.prototype, Object.getOwnPropertyDescriptors(source));
	}
};
var eventemitter3_default = (/* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	var has = Object.prototype.hasOwnProperty;
	var prefix = "~";
	/**
	* Constructor to create a storage for our `EE` objects.
	* An `Events` instance is a plain object whose properties are event names.
	*
	* @constructor
	* @private
	*/
	function Events() {}
	if (Object.create) {
		Events.prototype = Object.create(null);
		if (!new Events().__proto__) prefix = false;
	}
	/**
	* Representation of a single event listener.
	*
	* @param {Function} fn The listener function.
	* @param {*} context The context to invoke the listener with.
	* @param {Boolean} [once=false] Specify if the listener is a one-time listener.
	* @constructor
	* @private
	*/
	function EE(fn, context, once) {
		this.fn = fn;
		this.context = context;
		this.once = once || false;
	}
	/**
	* Add a listener for a given event.
	*
	* @param {EventEmitter} emitter Reference to the `EventEmitter` instance.
	* @param {(String|Symbol)} event The event name.
	* @param {Function} fn The listener function.
	* @param {*} context The context to invoke the listener with.
	* @param {Boolean} once Specify if the listener is a one-time listener.
	* @returns {EventEmitter}
	* @private
	*/
	function addListener(emitter, event, fn, context, once) {
		if (typeof fn !== "function") throw new TypeError("The listener must be a function");
		var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
		if (!emitter._events[evt]) emitter._events[evt] = listener, emitter._eventsCount++;
		else if (!emitter._events[evt].fn) emitter._events[evt].push(listener);
		else emitter._events[evt] = [emitter._events[evt], listener];
		return emitter;
	}
	/**
	* Clear event by name.
	*
	* @param {EventEmitter} emitter Reference to the `EventEmitter` instance.
	* @param {(String|Symbol)} evt The Event name.
	* @private
	*/
	function clearEvent(emitter, evt) {
		if (--emitter._eventsCount === 0) emitter._events = new Events();
		else delete emitter._events[evt];
	}
	/**
	* Minimal `EventEmitter` interface that is molded against the Node.js
	* `EventEmitter` interface.
	*
	* @constructor
	* @public
	*/
	function EventEmitter() {
		this._events = new Events();
		this._eventsCount = 0;
	}
	/**
	* Return an array listing the events for which the emitter has registered
	* listeners.
	*
	* @returns {Array}
	* @public
	*/
	EventEmitter.prototype.eventNames = function eventNames() {
		var names = [], events, name;
		if (this._eventsCount === 0) return names;
		for (name in events = this._events) if (has.call(events, name)) names.push(prefix ? name.slice(1) : name);
		if (Object.getOwnPropertySymbols) return names.concat(Object.getOwnPropertySymbols(events));
		return names;
	};
	/**
	* Return the listeners registered for a given event.
	*
	* @param {(String|Symbol)} event The event name.
	* @returns {Array} The registered listeners.
	* @public
	*/
	EventEmitter.prototype.listeners = function listeners(event) {
		var evt = prefix ? prefix + event : event, handlers = this._events[evt];
		if (!handlers) return [];
		if (handlers.fn) return [handlers.fn];
		for (var i = 0, l = handlers.length, ee = new Array(l); i < l; i++) ee[i] = handlers[i].fn;
		return ee;
	};
	/**
	* Return the number of listeners listening to a given event.
	*
	* @param {(String|Symbol)} event The event name.
	* @returns {Number} The number of listeners.
	* @public
	*/
	EventEmitter.prototype.listenerCount = function listenerCount(event) {
		var evt = prefix ? prefix + event : event, listeners = this._events[evt];
		if (!listeners) return 0;
		if (listeners.fn) return 1;
		return listeners.length;
	};
	/**
	* Calls each of the listeners registered for a given event.
	*
	* @param {(String|Symbol)} event The event name.
	* @returns {Boolean} `true` if the event had listeners, else `false`.
	* @public
	*/
	EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
		var evt = prefix ? prefix + event : event;
		if (!this._events[evt]) return false;
		var listeners = this._events[evt], len = arguments.length, args, i;
		if (listeners.fn) {
			if (listeners.once) this.removeListener(event, listeners.fn, void 0, true);
			switch (len) {
				case 1: return listeners.fn.call(listeners.context), true;
				case 2: return listeners.fn.call(listeners.context, a1), true;
				case 3: return listeners.fn.call(listeners.context, a1, a2), true;
				case 4: return listeners.fn.call(listeners.context, a1, a2, a3), true;
				case 5: return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
				case 6: return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
			}
			for (i = 1, args = new Array(len - 1); i < len; i++) args[i - 1] = arguments[i];
			listeners.fn.apply(listeners.context, args);
		} else {
			var length = listeners.length, j;
			for (i = 0; i < length; i++) {
				if (listeners[i].once) this.removeListener(event, listeners[i].fn, void 0, true);
				switch (len) {
					case 1:
						listeners[i].fn.call(listeners[i].context);
						break;
					case 2:
						listeners[i].fn.call(listeners[i].context, a1);
						break;
					case 3:
						listeners[i].fn.call(listeners[i].context, a1, a2);
						break;
					case 4:
						listeners[i].fn.call(listeners[i].context, a1, a2, a3);
						break;
					default:
						if (!args) for (j = 1, args = new Array(len - 1); j < len; j++) args[j - 1] = arguments[j];
						listeners[i].fn.apply(listeners[i].context, args);
				}
			}
		}
		return true;
	};
	/**
	* Add a listener for a given event.
	*
	* @param {(String|Symbol)} event The event name.
	* @param {Function} fn The listener function.
	* @param {*} [context=this] The context to invoke the listener with.
	* @returns {EventEmitter} `this`.
	* @public
	*/
	EventEmitter.prototype.on = function on(event, fn, context) {
		return addListener(this, event, fn, context, false);
	};
	/**
	* Add a one-time listener for a given event.
	*
	* @param {(String|Symbol)} event The event name.
	* @param {Function} fn The listener function.
	* @param {*} [context=this] The context to invoke the listener with.
	* @returns {EventEmitter} `this`.
	* @public
	*/
	EventEmitter.prototype.once = function once(event, fn, context) {
		return addListener(this, event, fn, context, true);
	};
	/**
	* Remove the listeners of a given event.
	*
	* @param {(String|Symbol)} event The event name.
	* @param {Function} fn Only remove the listeners that match this function.
	* @param {*} context Only remove the listeners that have this context.
	* @param {Boolean} once Only remove one-time listeners.
	* @returns {EventEmitter} `this`.
	* @public
	*/
	EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
		var evt = prefix ? prefix + event : event;
		if (!this._events[evt]) return this;
		if (!fn) {
			clearEvent(this, evt);
			return this;
		}
		var listeners = this._events[evt];
		if (listeners.fn) {
			if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) clearEvent(this, evt);
		} else {
			for (var i = 0, events = [], length = listeners.length; i < length; i++) if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) events.push(listeners[i]);
			if (events.length) this._events[evt] = events.length === 1 ? events[0] : events;
			else clearEvent(this, evt);
		}
		return this;
	};
	/**
	* Remove all listeners, or those of the specified event.
	*
	* @param {(String|Symbol)} [event] The event name.
	* @returns {EventEmitter} `this`.
	* @public
	*/
	EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
		var evt;
		if (event) {
			evt = prefix ? prefix + event : event;
			if (this._events[evt]) clearEvent(this, evt);
		} else {
			this._events = new Events();
			this._eventsCount = 0;
		}
		return this;
	};
	EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
	EventEmitter.prototype.addListener = EventEmitter.prototype.on;
	EventEmitter.prefixed = prefix;
	EventEmitter.EventEmitter = EventEmitter;
	if ("undefined" !== typeof module) module.exports = EventEmitter;
})))(), 1)).default;
//#endregion
//#region node_modules/pixi.js/lib/maths/misc/const.mjs
var PI_2 = Math.PI * 2;
var RAD_TO_DEG = 180 / Math.PI;
var DEG_TO_RAD = Math.PI / 180;
//#endregion
//#region node_modules/pixi.js/lib/maths/point/Point.mjs
var Point = class Point {
	/**
	* Creates a new `Point`
	* @param {number} [x=0] - position of the point on the x axis
	* @param {number} [y=0] - position of the point on the y axis
	*/
	constructor(x = 0, y = 0) {
		/**
		* Position of the point on the x axis
		* @example
		* ```ts
		* // Set x position
		* const point = new Point();
		* point.x = 100;
		*
		* // Use in calculations
		* const width = rightPoint.x - leftPoint.x;
		* ```
		*/
		this.x = 0;
		/**
		* Position of the point on the y axis
		* @example
		* ```ts
		* // Set y position
		* const point = new Point();
		* point.y = 200;
		*
		* // Use in calculations
		* const height = bottomPoint.y - topPoint.y;
		* ```
		*/
		this.y = 0;
		this.x = x;
		this.y = y;
	}
	/**
	* Creates a clone of this point, which is a new instance with the same `x` and `y` values.
	* @example
	* ```ts
	* // Basic point cloning
	* const original = new Point(100, 200);
	* const copy = original.clone();
	*
	* // Clone and modify
	* const modified = original.clone();
	* modified.set(300, 400);
	*
	* // Verify independence
	* console.log(original); // Point(100, 200)
	* console.log(modified); // Point(300, 400)
	* ```
	* @remarks
	* - Creates new Point instance
	* - Deep copies x and y values
	* - Independent from original
	* - Useful for preserving values
	* @returns A clone of this point
	* @see {@link Point.copyFrom} For copying into existing point
	* @see {@link Point.copyTo} For copying to existing point
	*/
	clone() {
		return new Point(this.x, this.y);
	}
	/**
	* Copies x and y from the given point into this point.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Point(100, 200);
	* const target = new Point();
	* target.copyFrom(source);
	*
	* // Copy and chain operations
	* const point = new Point()
	*     .copyFrom(source)
	*     .set(x + 50, y + 50);
	*
	* // Copy from any PointData
	* const data = { x: 10, y: 20 };
	* point.copyFrom(data);
	* ```
	* @param p - The point to copy from
	* @returns The point instance itself
	* @see {@link Point.copyTo} For copying to another point
	* @see {@link Point.clone} For creating new point copy
	*/
	copyFrom(p) {
		this.set(p.x, p.y);
		return this;
	}
	/**
	* Copies this point's x and y into the given point.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Point(100, 200);
	* const target = new Point();
	* source.copyTo(target);
	* ```
	* @param p - The point to copy to. Can be any type that is or extends `PointLike`
	* @returns The point (`p`) with values updated
	* @see {@link Point.copyFrom} For copying from another point
	* @see {@link Point.clone} For creating new point copy
	*/
	copyTo(p) {
		p.set(this.x, this.y);
		return p;
	}
	/**
	* Checks if another point is equal to this point.
	*
	* Compares x and y values using strict equality.
	* @example
	* ```ts
	* // Basic equality check
	* const p1 = new Point(100, 200);
	* const p2 = new Point(100, 200);
	* console.log(p1.equals(p2)); // true
	*
	* // Compare with PointData
	* const data = { x: 100, y: 200 };
	* console.log(p1.equals(data)); // true
	*
	* // Check different points
	* const p3 = new Point(200, 300);
	* console.log(p1.equals(p3)); // false
	* ```
	* @param p - The point to check
	* @returns `true` if both `x` and `y` are equal
	* @see {@link Point.copyFrom} For making points equal
	* @see {@link PointData} For point data interface
	*/
	equals(p) {
		return p.x === this.x && p.y === this.y;
	}
	/**
	* Sets the point to a new x and y position.
	*
	* If y is omitted, both x and y will be set to x.
	* @example
	* ```ts
	* // Basic position setting
	* const point = new Point();
	* point.set(100, 200);
	*
	* // Set both x and y to same value
	* point.set(50); // x=50, y=50
	*
	* // Chain with other operations
	* point
	*     .set(10, 20)
	*     .copyTo(otherPoint);
	* ```
	* @param x - Position on the x axis
	* @param y - Position on the y axis, defaults to x
	* @returns The point instance itself
	* @see {@link Point.copyFrom} For copying from another point
	* @see {@link Point.equals} For comparing positions
	*/
	set(x = 0, y = x) {
		this.x = x;
		this.y = y;
		return this;
	}
	toString() {
		return `[pixi.js/math:Point x=${this.x} y=${this.y}]`;
	}
	/**
	* A static Point object with `x` and `y` values of `0`.
	*
	* This shared instance is reset to zero values when accessed.
	*
	* > [!IMPORTANT] This point is shared and temporary. Do not store references to it.
	* @example
	* ```ts
	* // Use for temporary calculations
	* const tempPoint = Point.shared;
	* tempPoint.set(100, 200);
	* matrix.apply(tempPoint);
	*
	* // Will be reset to (0,0) on next access
	* const fresh = Point.shared; // x=0, y=0
	* ```
	* @readonly
	* @returns A fresh zeroed point for temporary use
	* @see {@link Point.constructor} For creating new points
	* @see {@link PointData} For basic point interface
	*/
	static get shared() {
		tempPoint.x = 0;
		tempPoint.y = 0;
		return tempPoint;
	}
};
var tempPoint = new Point();
//#endregion
//#region node_modules/pixi.js/lib/maths/matrix/Matrix.mjs
var Matrix = class Matrix {
	/**
	* @param a - x scale
	* @param b - y skew
	* @param c - x skew
	* @param d - y scale
	* @param tx - x translation
	* @param ty - y translation
	*/
	constructor(a = 1, b = 0, c = 0, d = 1, tx = 0, ty = 0) {
		/**
		* Array representation of the matrix.
		* Only populated when `toArray()` is called.
		* @default null
		* @see {@link Matrix.toArray} For filling this array
		*/
		this.array = null;
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.tx = tx;
		this.ty = ty;
	}
	/**
	* Creates a Matrix object based on the given array.
	* Populates matrix components from a flat array in column-major order.
	*
	* > [!NOTE] Array mapping order:
	* > ```
	* > array[0] = a  (x scale)
	* > array[1] = b  (y skew)
	* > array[2] = tx (x translation)
	* > array[3] = c  (x skew)
	* > array[4] = d  (y scale)
	* > array[5] = ty (y translation)
	* > ```
	* @example
	* ```ts
	* // Create matrix from array
	* const matrix = new Matrix();
	* matrix.fromArray([
	*     2, 0,  100,  // a, b, tx
	*     0, 2,  100   // c, d, ty
	* ]);
	*
	* // Create matrix from typed array
	* const float32Array = new Float32Array([
	*     1, 0, 0,     // Scale x1, no skew
	*     0, 1, 0      // No skew, scale x1
	* ]);
	* matrix.fromArray(float32Array);
	* ```
	* @param array - The array to populate the matrix from
	* @see {@link Matrix.toArray} For converting matrix to array
	* @see {@link Matrix.set} For setting values directly
	*/
	fromArray(array) {
		this.a = array[0];
		this.b = array[1];
		this.c = array[3];
		this.d = array[4];
		this.tx = array[2];
		this.ty = array[5];
	}
	/**
	* Sets the matrix properties directly.
	* All matrix components can be set in one call.
	* @example
	* ```ts
	* // Set to identity matrix
	* matrix.set(1, 0, 0, 1, 0, 0);
	*
	* // Set to scale matrix
	* matrix.set(2, 0, 0, 2, 0, 0); // Scale 2x
	*
	* // Set to translation matrix
	* matrix.set(1, 0, 0, 1, 100, 50); // Move 100,50
	* ```
	* @param a - Scale on x axis
	* @param b - Shear on y axis
	* @param c - Shear on x axis
	* @param d - Scale on y axis
	* @param tx - Translation on x axis
	* @param ty - Translation on y axis
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.identity} For resetting to identity
	* @see {@link Matrix.fromArray} For setting from array
	*/
	set(a, b, c, d, tx, ty) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.tx = tx;
		this.ty = ty;
		return this;
	}
	/**
	* Creates an array from the current Matrix object.
	*
	* > [!NOTE] The array format is:
	* > ```
	* > Non-transposed:
	* > [a, c, tx,
	* > b, d, ty,
	* > 0, 0, 1]
	* >
	* > Transposed:
	* > [a, b, 0,
	* > c, d, 0,
	* > tx,ty,1]
	* > ```
	* @example
	* ```ts
	* // Basic array conversion
	* const matrix = new Matrix(2, 0, 0, 2, 100, 100);
	* const array = matrix.toArray();
	*
	* // Using existing array
	* const float32Array = new Float32Array(9);
	* matrix.toArray(false, float32Array);
	*
	* // Get transposed array
	* const transposed = matrix.toArray(true);
	* ```
	* @param transpose - Whether to transpose the matrix
	* @param out - Optional Float32Array to store the result
	* @returns The array containing the matrix values
	* @see {@link Matrix.fromArray} For creating matrix from array
	* @see {@link Matrix.array} For cached array storage
	*/
	toArray(transpose, out) {
		if (!this.array) this.array = /* @__PURE__ */ new Float32Array(9);
		const array = out || this.array;
		if (transpose) {
			array[0] = this.a;
			array[1] = this.b;
			array[2] = 0;
			array[3] = this.c;
			array[4] = this.d;
			array[5] = 0;
			array[6] = this.tx;
			array[7] = this.ty;
			array[8] = 1;
		} else {
			array[0] = this.a;
			array[1] = this.c;
			array[2] = this.tx;
			array[3] = this.b;
			array[4] = this.d;
			array[5] = this.ty;
			array[6] = 0;
			array[7] = 0;
			array[8] = 1;
		}
		return array;
	}
	/**
	* Get a new position with the current transformation applied.
	*
	* Can be used to go from a child's coordinate space to the world coordinate space. (e.g. rendering)
	* @example
	* ```ts
	* // Basic point transformation
	* const matrix = new Matrix().translate(100, 50).rotate(Math.PI / 4);
	* const point = new Point(10, 20);
	* const transformed = matrix.apply(point);
	*
	* // Reuse existing point
	* const output = new Point();
	* matrix.apply(point, output);
	* ```
	* @param pos - The origin point to transform
	* @param newPos - Optional point to store the result
	* @returns The transformed point
	* @see {@link Matrix.applyInverse} For inverse transformation
	* @see {@link Point} For point operations
	*/
	apply(pos, newPos) {
		newPos = newPos || new Point();
		const x = pos.x;
		const y = pos.y;
		newPos.x = this.a * x + this.c * y + this.tx;
		newPos.y = this.b * x + this.d * y + this.ty;
		return newPos;
	}
	/**
	* Get a new position with the inverse of the current transformation applied.
	*
	* Can be used to go from the world coordinate space to a child's coordinate space. (e.g. input)
	* @example
	* ```ts
	* // Basic inverse transformation
	* const matrix = new Matrix().translate(100, 50).rotate(Math.PI / 4);
	* const worldPoint = new Point(150, 100);
	* const localPoint = matrix.applyInverse(worldPoint);
	*
	* // Reuse existing point
	* const output = new Point();
	* matrix.applyInverse(worldPoint, output);
	*
	* // Convert mouse position to local space
	* const mousePoint = new Point(mouseX, mouseY);
	* const localMouse = matrix.applyInverse(mousePoint);
	* ```
	* @param pos - The origin point to inverse-transform
	* @param newPos - Optional point to store the result
	* @returns The inverse-transformed point
	* @see {@link Matrix.apply} For forward transformation
	* @see {@link Matrix.invert} For getting inverse matrix
	*/
	applyInverse(pos, newPos) {
		newPos = newPos || new Point();
		const a = this.a;
		const b = this.b;
		const c = this.c;
		const d = this.d;
		const tx = this.tx;
		const ty = this.ty;
		const id = 1 / (a * d + c * -b);
		const x = pos.x;
		const y = pos.y;
		newPos.x = d * id * x + -c * id * y + (ty * c - tx * d) * id;
		newPos.y = a * id * y + -b * id * x + (-ty * a + tx * b) * id;
		return newPos;
	}
	/**
	* Translates the matrix on the x and y axes.
	* Adds to the position values while preserving scale, rotation and skew.
	* @example
	* ```ts
	* // Basic translation
	* const matrix = new Matrix();
	* matrix.translate(100, 50); // Move right 100, down 50
	*
	* // Chain with other transformations
	* matrix
	*     .scale(2, 2)
	*     .translate(100, 0)
	*     .rotate(Math.PI / 4);
	* ```
	* @param x - How much to translate on the x axis
	* @param y - How much to translate on the y axis
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.set} For setting position directly
	* @see {@link Matrix.setTransform} For complete transform setup
	*/
	translate(x, y) {
		this.tx += x;
		this.ty += y;
		return this;
	}
	/**
	* Applies a scale transformation to the matrix.
	* Multiplies the scale values with existing matrix components.
	* @example
	* ```ts
	* // Basic scaling
	* const matrix = new Matrix();
	* matrix.scale(2, 3); // Scale 2x horizontally, 3x vertically
	*
	* // Chain with other transformations
	* matrix
	*     .translate(100, 100)
	*     .scale(2, 2)     // Scales after translation
	*     .rotate(Math.PI / 4);
	* ```
	* @param x - The amount to scale horizontally
	* @param y - The amount to scale vertically
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.setTransform} For setting scale directly
	* @see {@link Matrix.append} For combining transformations
	*/
	scale(x, y) {
		this.a *= x;
		this.d *= y;
		this.c *= x;
		this.b *= y;
		this.tx *= x;
		this.ty *= y;
		return this;
	}
	/**
	* Applies a rotation transformation to the matrix.
	*
	* Rotates around the origin (0,0) by the given angle in radians.
	* @example
	* ```ts
	* // Basic rotation
	* const matrix = new Matrix();
	* matrix.rotate(Math.PI / 4); // Rotate 45 degrees
	*
	* // Chain with other transformations
	* matrix
	*     .translate(100, 100) // Move to rotation center
	*     .rotate(Math.PI)     // Rotate 180 degrees
	*     .scale(2, 2);        // Scale after rotation
	*
	* // Common angles
	* matrix.rotate(Math.PI / 2);  // 90 degrees
	* matrix.rotate(Math.PI);      // 180 degrees
	* matrix.rotate(Math.PI * 2);  // 360 degrees
	* ```
	* @remarks
	* - Rotates around origin point (0,0)
	* - Affects position if translation was set
	* - Uses counter-clockwise rotation
	* - Order of operations matters when chaining
	* @param angle - The angle in radians
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.setTransform} For setting rotation directly
	* @see {@link Matrix.append} For combining transformations
	*/
	rotate(angle) {
		const cos = Math.cos(angle);
		const sin = Math.sin(angle);
		const a1 = this.a;
		const c1 = this.c;
		const tx1 = this.tx;
		this.a = a1 * cos - this.b * sin;
		this.b = a1 * sin + this.b * cos;
		this.c = c1 * cos - this.d * sin;
		this.d = c1 * sin + this.d * cos;
		this.tx = tx1 * cos - this.ty * sin;
		this.ty = tx1 * sin + this.ty * cos;
		return this;
	}
	/**
	* Appends the given Matrix to this Matrix.
	* Combines two matrices by multiplying them together: this = this * matrix
	* @example
	* ```ts
	* // Basic matrix combination
	* const matrix = new Matrix();
	* const other = new Matrix().translate(100, 0).rotate(Math.PI / 4);
	* matrix.append(other);
	* ```
	* @remarks
	* - Order matters: A.append(B) !== B.append(A)
	* - Modifies current matrix
	* - Preserves transformation order
	* - Commonly used for combining transforms
	* @param matrix - The matrix to append
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.prepend} For prepending transformations
	* @see {@link Matrix.appendFrom} For appending two external matrices
	*/
	append(matrix) {
		const a1 = this.a;
		const b1 = this.b;
		const c1 = this.c;
		const d1 = this.d;
		this.a = matrix.a * a1 + matrix.b * c1;
		this.b = matrix.a * b1 + matrix.b * d1;
		this.c = matrix.c * a1 + matrix.d * c1;
		this.d = matrix.c * b1 + matrix.d * d1;
		this.tx = matrix.tx * a1 + matrix.ty * c1 + this.tx;
		this.ty = matrix.tx * b1 + matrix.ty * d1 + this.ty;
		return this;
	}
	/**
	* Appends two matrices and sets the result to this matrix.
	* Performs matrix multiplication: this = A * B
	* @example
	* ```ts
	* // Basic matrix multiplication
	* const result = new Matrix();
	* const matrixA = new Matrix().scale(2, 2);
	* const matrixB = new Matrix().rotate(Math.PI / 4);
	* result.appendFrom(matrixA, matrixB);
	* ```
	* @remarks
	* - Order matters: A * B !== B * A
	* - Creates a new transformation from two others
	* - More efficient than append() for multiple operations
	* - Does not modify input matrices
	* @param a - The first matrix to multiply
	* @param b - The second matrix to multiply
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.append} For single matrix combination
	* @see {@link Matrix.prepend} For reverse order multiplication
	*/
	appendFrom(a, b) {
		const a1 = a.a;
		const b1 = a.b;
		const c1 = a.c;
		const d1 = a.d;
		const tx = a.tx;
		const ty = a.ty;
		const a2 = b.a;
		const b2 = b.b;
		const c2 = b.c;
		const d2 = b.d;
		this.a = a1 * a2 + b1 * c2;
		this.b = a1 * b2 + b1 * d2;
		this.c = c1 * a2 + d1 * c2;
		this.d = c1 * b2 + d1 * d2;
		this.tx = tx * a2 + ty * c2 + b.tx;
		this.ty = tx * b2 + ty * d2 + b.ty;
		return this;
	}
	/**
	* Sets the matrix based on all the available properties.
	* Combines position, scale, rotation, skew and pivot in a single operation.
	* @example
	* ```ts
	* // Basic transform setup
	* const matrix = new Matrix();
	* matrix.setTransform(
	*     100, 100,    // position
	*     0, 0,        // pivot
	*     2, 2,        // scale
	*     Math.PI / 4, // rotation (45 degrees)
	*     0, 0         // skew
	* );
	* ```
	* @remarks
	* - Updates all matrix components at once
	* - More efficient than separate transform calls
	* - Uses radians for rotation and skew
	* - Pivot affects rotation center
	* @param x - Position on the x axis
	* @param y - Position on the y axis
	* @param pivotX - Pivot on the x axis
	* @param pivotY - Pivot on the y axis
	* @param scaleX - Scale on the x axis
	* @param scaleY - Scale on the y axis
	* @param rotation - Rotation in radians
	* @param skewX - Skew on the x axis
	* @param skewY - Skew on the y axis
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.decompose} For extracting transform properties
	* @see {@link TransformableObject} For transform data structure
	*/
	setTransform(x, y, pivotX, pivotY, scaleX, scaleY, rotation, skewX, skewY) {
		this.a = Math.cos(rotation + skewY) * scaleX;
		this.b = Math.sin(rotation + skewY) * scaleX;
		this.c = -Math.sin(rotation - skewX) * scaleY;
		this.d = Math.cos(rotation - skewX) * scaleY;
		this.tx = x - (pivotX * this.a + pivotY * this.c);
		this.ty = y - (pivotX * this.b + pivotY * this.d);
		return this;
	}
	/**
	* Prepends the given Matrix to this Matrix.
	* Combines two matrices by multiplying them together: this = matrix * this
	* @example
	* ```ts
	* // Basic matrix prepend
	* const matrix = new Matrix().scale(2, 2);
	* const other = new Matrix().translate(100, 0);
	* matrix.prepend(other); // Translation happens before scaling
	* ```
	* @remarks
	* - Order matters: A.prepend(B) !== B.prepend(A)
	* - Modifies current matrix
	* - Reverses transformation order compared to append()
	* @param matrix - The matrix to prepend
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.append} For appending transformations
	* @see {@link Matrix.appendFrom} For combining external matrices
	*/
	prepend(matrix) {
		const tx1 = this.tx;
		if (matrix.a !== 1 || matrix.b !== 0 || matrix.c !== 0 || matrix.d !== 1) {
			const a1 = this.a;
			const c1 = this.c;
			this.a = a1 * matrix.a + this.b * matrix.c;
			this.b = a1 * matrix.b + this.b * matrix.d;
			this.c = c1 * matrix.a + this.d * matrix.c;
			this.d = c1 * matrix.b + this.d * matrix.d;
		}
		this.tx = tx1 * matrix.a + this.ty * matrix.c + matrix.tx;
		this.ty = tx1 * matrix.b + this.ty * matrix.d + matrix.ty;
		return this;
	}
	/**
	* Decomposes the matrix into its individual transform components.
	* Extracts position, scale, rotation and skew values from the matrix.
	* @example
	* ```ts
	* // Basic decomposition
	* const matrix = new Matrix()
	*     .translate(100, 100)
	*     .rotate(Math.PI / 4)
	*     .scale(2, 2);
	*
	* const transform = {
	*     position: new Point(),
	*     scale: new Point(),
	*     pivot: new Point(),
	*     skew: new Point(),
	*     rotation: 0
	* };
	*
	* matrix.decompose(transform);
	* console.log(transform.position); // Point(100, 100)
	* console.log(transform.rotation); // ~0.785 (PI/4)
	* console.log(transform.scale); // Point(2, 2)
	* ```
	* @remarks
	* - Handles combined transformations
	* - Accounts for pivot points
	* - Chooses between rotation/skew based on transform type
	* - Uses radians for rotation and skew
	* @param transform - The transform object to store the decomposed values
	* @returns The transform with the newly applied properties
	* @see {@link Matrix.setTransform} For composing from components
	* @see {@link TransformableObject} For transform structure
	*/
	decompose(transform) {
		const a = this.a;
		const b = this.b;
		const c = this.c;
		const d = this.d;
		const pivot = transform.pivot;
		const skewX = -Math.atan2(-c, d);
		const skewY = Math.atan2(b, a);
		const delta = Math.abs(skewX + skewY);
		let scaleX = Math.sqrt(a * a + b * b);
		if (delta < 1e-5 || Math.abs(PI_2 - delta) < 1e-5) {
			transform.rotation = skewY;
			transform.skew.x = transform.skew.y = 0;
		} else if (Math.abs(Math.PI - delta) < 1e-5) {
			transform.rotation = skewY - Math.PI;
			transform.skew.x = transform.skew.y = 0;
			scaleX = -scaleX;
		} else {
			transform.rotation = 0;
			transform.skew.x = skewX;
			transform.skew.y = skewY;
		}
		transform.scale.x = scaleX;
		transform.scale.y = Math.sqrt(c * c + d * d);
		transform.position.x = this.tx + (pivot.x * a + pivot.y * c);
		transform.position.y = this.ty + (pivot.x * b + pivot.y * d);
		return transform;
	}
	/**
	* Inverts this matrix.
	* Creates the matrix that when multiplied with this matrix results in an identity matrix.
	* @example
	* ```ts
	* // Basic matrix inversion
	* const matrix = new Matrix()
	*     .translate(100, 50)
	*     .scale(2, 2);
	*
	* matrix.invert(); // Now transforms in opposite direction
	*
	* // Verify inversion
	* const point = new Point(50, 50);
	* const transformed = matrix.apply(point);
	* const original = matrix.invert().apply(transformed);
	* // original ≈ point
	* ```
	* @remarks
	* - Modifies the current matrix
	* - Useful for reversing transformations
	* - Cannot invert matrices with zero determinant
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.identity} For resetting to identity
	* @see {@link Matrix.applyInverse} For inverse transformations
	*/
	invert() {
		const a1 = this.a;
		const b1 = this.b;
		const c1 = this.c;
		const d1 = this.d;
		const tx1 = this.tx;
		const n = a1 * d1 - b1 * c1;
		this.a = d1 / n;
		this.b = -b1 / n;
		this.c = -c1 / n;
		this.d = a1 / n;
		this.tx = (c1 * this.ty - d1 * tx1) / n;
		this.ty = -(a1 * this.ty - b1 * tx1) / n;
		return this;
	}
	/**
	* Checks if this matrix is an identity matrix.
	*
	* An identity matrix has no transformations applied (default state).
	* @example
	* ```ts
	* // Check if matrix is identity
	* const matrix = new Matrix();
	* console.log(matrix.isIdentity()); // true
	*
	* // Check after transformations
	* matrix.translate(100, 0);
	* console.log(matrix.isIdentity()); // false
	*
	* // Reset and verify
	* matrix.identity();
	* console.log(matrix.isIdentity()); // true
	* ```
	* @remarks
	* - Verifies a = 1, d = 1 (no scale)
	* - Verifies b = 0, c = 0 (no skew)
	* - Verifies tx = 0, ty = 0 (no translation)
	* @returns True if matrix has no transformations
	* @see {@link Matrix.identity} For resetting to identity
	* @see {@link Matrix.IDENTITY} For constant identity matrix
	*/
	isIdentity() {
		return this.a === 1 && this.b === 0 && this.c === 0 && this.d === 1 && this.tx === 0 && this.ty === 0;
	}
	/**
	* Resets this Matrix to an identity (default) matrix.
	* Sets all components to their default values: scale=1, no skew, no translation.
	* @example
	* ```ts
	* // Reset transformed matrix
	* const matrix = new Matrix()
	*     .scale(2, 2)
	*     .rotate(Math.PI / 4);
	* matrix.identity(); // Back to default state
	*
	* // Chain after reset
	* matrix
	*     .identity()
	*     .translate(100, 100)
	*     .scale(2, 2);
	*
	* // Compare with identity constant
	* const isDefault = matrix.equals(Matrix.IDENTITY);
	* ```
	* @remarks
	* - Sets a=1, d=1 (default scale)
	* - Sets b=0, c=0 (no skew)
	* - Sets tx=0, ty=0 (no translation)
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.IDENTITY} For constant identity matrix
	* @see {@link Matrix.isIdentity} For checking identity state
	*/
	identity() {
		this.a = 1;
		this.b = 0;
		this.c = 0;
		this.d = 1;
		this.tx = 0;
		this.ty = 0;
		return this;
	}
	/**
	* Creates a new Matrix object with the same values as this one.
	* @returns A copy of this matrix. Good for chaining method calls.
	*/
	clone() {
		const matrix = new Matrix();
		matrix.a = this.a;
		matrix.b = this.b;
		matrix.c = this.c;
		matrix.d = this.d;
		matrix.tx = this.tx;
		matrix.ty = this.ty;
		return matrix;
	}
	/**
	* Creates a new Matrix object with the same values as this one.
	* @param matrix
	* @example
	* ```ts
	* // Basic matrix cloning
	* const matrix = new Matrix()
	*     .translate(100, 100)
	*     .rotate(Math.PI / 4);
	* const copy = matrix.clone();
	*
	* // Clone and modify
	* const modified = matrix.clone()
	*     .scale(2, 2);
	*
	* // Compare matrices
	* console.log(matrix.equals(copy));     // true
	* console.log(matrix.equals(modified)); // false
	* ```
	* @returns A copy of this matrix. Good for chaining method calls.
	* @see {@link Matrix.copyTo} For copying to existing matrix
	* @see {@link Matrix.copyFrom} For copying from another matrix
	*/
	copyTo(matrix) {
		matrix.a = this.a;
		matrix.b = this.b;
		matrix.c = this.c;
		matrix.d = this.d;
		matrix.tx = this.tx;
		matrix.ty = this.ty;
		return matrix;
	}
	/**
	* Changes the values of the matrix to be the same as the ones in given matrix.
	* @example
	* ```ts
	* // Basic matrix copying
	* const source = new Matrix()
	*     .translate(100, 100)
	*     .rotate(Math.PI / 4);
	* const target = new Matrix();
	* target.copyFrom(source);
	* ```
	* @param matrix - The matrix to copy from
	* @returns This matrix. Good for chaining method calls.
	* @see {@link Matrix.clone} For creating new matrix copy
	* @see {@link Matrix.copyTo} For copying to another matrix
	*/
	copyFrom(matrix) {
		this.a = matrix.a;
		this.b = matrix.b;
		this.c = matrix.c;
		this.d = matrix.d;
		this.tx = matrix.tx;
		this.ty = matrix.ty;
		return this;
	}
	/**
	* Checks if this matrix equals another matrix.
	* Compares all components for exact equality.
	* @example
	* ```ts
	* // Basic equality check
	* const m1 = new Matrix();
	* const m2 = new Matrix();
	* console.log(m1.equals(m2)); // true
	*
	* // Compare transformed matrices
	* const transform = new Matrix()
	*     .translate(100, 100)
	* const clone = new Matrix()
	*     .scale(2, 2);
	* console.log(transform.equals(clone)); // false
	* ```
	* @param matrix - The matrix to compare to
	* @returns True if matrices are identical
	* @see {@link Matrix.copyFrom} For copying matrix values
	* @see {@link Matrix.isIdentity} For identity comparison
	*/
	equals(matrix) {
		return matrix.a === this.a && matrix.b === this.b && matrix.c === this.c && matrix.d === this.d && matrix.tx === this.tx && matrix.ty === this.ty;
	}
	toString() {
		return `[pixi.js:Matrix a=${this.a} b=${this.b} c=${this.c} d=${this.d} tx=${this.tx} ty=${this.ty}]`;
	}
	/**
	* A default (identity) matrix with no transformations applied.
	*
	* > [!IMPORTANT] This is a shared read-only object. Create a new Matrix if you need to modify it.
	* @example
	* ```ts
	* // Get identity matrix reference
	* const identity = Matrix.IDENTITY;
	* console.log(identity.isIdentity()); // true
	*
	* // Compare with identity
	* const matrix = new Matrix();
	* console.log(matrix.equals(Matrix.IDENTITY)); // true
	*
	* // Create new matrix instead of modifying IDENTITY
	* const transform = new Matrix()
	*     .copyFrom(Matrix.IDENTITY)
	*     .translate(100, 100);
	* ```
	* @readonly
	* @returns A read-only identity matrix
	* @see {@link Matrix.shared} For temporary calculations
	* @see {@link Matrix.identity} For resetting matrices
	*/
	static get IDENTITY() {
		return identityMatrix.identity();
	}
	/**
	* A static Matrix that can be used to avoid creating new objects.
	* Will always ensure the matrix is reset to identity when requested.
	*
	* > [!IMPORTANT] This matrix is shared and temporary. Do not store references to it.
	* @example
	* ```ts
	* // Use for temporary calculations
	* const tempMatrix = Matrix.shared;
	* tempMatrix.translate(100, 100).rotate(Math.PI / 4);
	* const point = tempMatrix.apply({ x: 10, y: 20 });
	*
	* // Will be reset to identity on next access
	* const fresh = Matrix.shared; // Back to identity
	* ```
	* @remarks
	* - Always returns identity matrix
	* - Safe to modify temporarily
	* - Not safe to store references
	* - Useful for one-off calculations
	* @readonly
	* @returns A fresh identity matrix for temporary use
	* @see {@link Matrix.IDENTITY} For immutable identity matrix
	* @see {@link Matrix.identity} For resetting matrices
	*/
	static get shared() {
		return tempMatrix.identity();
	}
};
var tempMatrix = new Matrix();
var identityMatrix = new Matrix();
//#endregion
//#region node_modules/pixi.js/lib/maths/matrix/groupD8.mjs
var ux = [
	1,
	1,
	0,
	-1,
	-1,
	-1,
	0,
	1,
	1,
	1,
	0,
	-1,
	-1,
	-1,
	0,
	1
];
var uy = [
	0,
	1,
	1,
	1,
	0,
	-1,
	-1,
	-1,
	0,
	1,
	1,
	1,
	0,
	-1,
	-1,
	-1
];
var vx = [
	0,
	-1,
	-1,
	-1,
	0,
	1,
	1,
	1,
	0,
	1,
	1,
	1,
	0,
	-1,
	-1,
	-1
];
var vy = [
	1,
	1,
	0,
	-1,
	-1,
	-1,
	0,
	1,
	-1,
	-1,
	0,
	1,
	1,
	1,
	0,
	-1
];
var rotationCayley = [];
var rotationMatrices = [];
var signum = Math.sign;
function init() {
	for (let i = 0; i < 16; i++) {
		const row = [];
		rotationCayley.push(row);
		for (let j = 0; j < 16; j++) {
			const _ux = signum(ux[i] * ux[j] + vx[i] * uy[j]);
			const _uy = signum(uy[i] * ux[j] + vy[i] * uy[j]);
			const _vx = signum(ux[i] * vx[j] + vx[i] * vy[j]);
			const _vy = signum(uy[i] * vx[j] + vy[i] * vy[j]);
			for (let k = 0; k < 16; k++) if (ux[k] === _ux && uy[k] === _uy && vx[k] === _vx && vy[k] === _vy) {
				row.push(k);
				break;
			}
		}
	}
	for (let i = 0; i < 16; i++) {
		const mat = new Matrix();
		mat.set(ux[i], uy[i], vx[i], vy[i], 0, 0);
		rotationMatrices.push(mat);
	}
}
init();
var groupD8 = {
	/**
	* | Rotation | Direction |
	* |----------|-----------|
	* | 0°       | East      |
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	E: 0,
	/**
	* | Rotation | Direction |
	* |----------|-----------|
	* | 45°↻     | Southeast |
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	SE: 1,
	/**
	* | Rotation | Direction |
	* |----------|-----------|
	* | 90°↻     | South     |
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	S: 2,
	/**
	* | Rotation | Direction |
	* |----------|-----------|
	* | 135°↻    | Southwest |
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	SW: 3,
	/**
	* | Rotation | Direction |
	* |----------|-----------|
	* | 180°     | West      |
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	W: 4,
	/**
	* | Rotation    | Direction    |
	* |-------------|--------------|
	* | -135°/225°↻ | Northwest    |
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	NW: 5,
	/**
	* | Rotation    | Direction    |
	* |-------------|--------------|
	* | -90°/270°↻  | North        |
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	N: 6,
	/**
	* | Rotation    | Direction    |
	* |-------------|--------------|
	* | -45°/315°↻  | Northeast    |
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	NE: 7,
	/**
	* Reflection about Y-axis.
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	MIRROR_VERTICAL: 8,
	/**
	* Reflection about the main diagonal.
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	MAIN_DIAGONAL: 10,
	/**
	* Reflection about X-axis.
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	MIRROR_HORIZONTAL: 12,
	/**
	* Reflection about reverse diagonal.
	* @group groupD8
	* @type {GD8Symmetry}
	*/
	REVERSE_DIAGONAL: 14,
	/**
	* @group groupD8
	* @param {GD8Symmetry} ind - sprite rotation angle.
	* @returns {GD8Symmetry} The X-component of the U-axis
	*    after rotating the axes.
	*/
	uX: (ind) => ux[ind],
	/**
	* @group groupD8
	* @param {GD8Symmetry} ind - sprite rotation angle.
	* @returns {GD8Symmetry} The Y-component of the U-axis
	*    after rotating the axes.
	*/
	uY: (ind) => uy[ind],
	/**
	* @group groupD8
	* @param {GD8Symmetry} ind - sprite rotation angle.
	* @returns {GD8Symmetry} The X-component of the V-axis
	*    after rotating the axes.
	*/
	vX: (ind) => vx[ind],
	/**
	* @group groupD8
	* @param {GD8Symmetry} ind - sprite rotation angle.
	* @returns {GD8Symmetry} The Y-component of the V-axis
	*    after rotating the axes.
	*/
	vY: (ind) => vy[ind],
	/**
	* @group groupD8
	* @param {GD8Symmetry} rotation - symmetry whose opposite
	*   is needed. Only rotations have opposite symmetries while
	*   reflections don't.
	* @returns {GD8Symmetry} The opposite symmetry of `rotation`
	*/
	inv: (rotation) => {
		if (rotation & 8) return rotation & 15;
		return -rotation & 7;
	},
	/**
	* Composes the two D8 operations.
	*
	* Taking `^` as reflection:
	*
	* |       | E=0 | S=2 | W=4 | N=6 | E^=8 | S^=10 | W^=12 | N^=14 |
	* |-------|-----|-----|-----|-----|------|-------|-------|-------|
	* | E=0   | E   | S   | W   | N   | E^   | S^    | W^    | N^    |
	* | S=2   | S   | W   | N   | E   | S^   | W^    | N^    | E^    |
	* | W=4   | W   | N   | E   | S   | W^   | N^    | E^    | S^    |
	* | N=6   | N   | E   | S   | W   | N^   | E^    | S^    | W^    |
	* | E^=8  | E^  | N^  | W^  | S^  | E    | N     | W     | S     |
	* | S^=10 | S^  | E^  | N^  | W^  | S    | E     | N     | W     |
	* | W^=12 | W^  | S^  | E^  | N^  | W    | S     | E     | N     |
	* | N^=14 | N^  | W^  | S^  | E^  | N    | W     | S     | E     |
	*
	* [This is a Cayley table]{@link https://en.wikipedia.org/wiki/Cayley_table}
	* @group groupD8
	* @param {GD8Symmetry} rotationSecond - Second operation, which
	*   is the row in the above cayley table.
	* @param {GD8Symmetry} rotationFirst - First operation, which
	*   is the column in the above cayley table.
	* @returns {GD8Symmetry} Composed operation
	*/
	add: (rotationSecond, rotationFirst) => rotationCayley[rotationSecond][rotationFirst],
	/**
	* Reverse of `add`.
	* @group groupD8
	* @param {GD8Symmetry} rotationSecond - Second operation
	* @param {GD8Symmetry} rotationFirst - First operation
	* @returns {GD8Symmetry} Result
	*/
	sub: (rotationSecond, rotationFirst) => rotationCayley[rotationSecond][groupD8.inv(rotationFirst)],
	/**
	* Adds 180 degrees to rotation, which is a commutative
	* operation.
	* @group groupD8
	* @param {number} rotation - The number to rotate.
	* @returns {number} Rotated number
	*/
	rotate180: (rotation) => rotation ^ 4,
	/**
	* Checks if the rotation angle is vertical, i.e. south
	* or north. It doesn't work for reflections.
	* @group groupD8
	* @param {GD8Symmetry} rotation - The number to check.
	* @returns {boolean} Whether or not the direction is vertical
	*/
	isVertical: (rotation) => (rotation & 3) === 2,
	/**
	* Approximates the vector `V(dx,dy)` into one of the
	* eight directions provided by `groupD8`.
	* @group groupD8
	* @param {number} dx - X-component of the vector
	* @param {number} dy - Y-component of the vector
	* @returns {GD8Symmetry} Approximation of the vector into
	*  one of the eight symmetries.
	*/
	byDirection: (dx, dy) => {
		if (Math.abs(dx) * 2 <= Math.abs(dy)) {
			if (dy >= 0) return groupD8.S;
			return groupD8.N;
		} else if (Math.abs(dy) * 2 <= Math.abs(dx)) {
			if (dx > 0) return groupD8.E;
			return groupD8.W;
		} else if (dy > 0) {
			if (dx > 0) return groupD8.SE;
			return groupD8.SW;
		} else if (dx > 0) return groupD8.NE;
		return groupD8.NW;
	},
	/**
	* Helps sprite to compensate texture packer rotation.
	* @group groupD8
	* @param {Matrix} matrix - sprite world matrix
	* @param {GD8Symmetry} rotation - The rotation factor to use.
	* @param {number} tx - sprite anchoring
	* @param {number} ty - sprite anchoring
	* @param {number} dw - sprite width
	* @param {number} dh - sprite height
	*/
	matrixAppendRotationInv: (matrix, rotation, tx = 0, ty = 0, dw = 0, dh = 0) => {
		const mat = rotationMatrices[groupD8.inv(rotation)];
		const a = mat.a;
		const b = mat.b;
		const c = mat.c;
		const d = mat.d;
		const finalTx = tx - Math.min(0, a * dw, c * dh, a * dw + c * dh);
		const finalTy = ty - Math.min(0, b * dw, d * dh, b * dw + d * dh);
		const a1 = matrix.a;
		const b1 = matrix.b;
		const c1 = matrix.c;
		const d1 = matrix.d;
		matrix.a = a * a1 + b * c1;
		matrix.b = a * b1 + b * d1;
		matrix.c = c * a1 + d * c1;
		matrix.d = c * b1 + d * d1;
		matrix.tx = finalTx * a1 + finalTy * c1 + matrix.tx;
		matrix.ty = finalTx * b1 + finalTy * d1 + matrix.ty;
	},
	/**
	* Transforms rectangle coordinates based on texture packer rotation.
	* Used when texture atlas pages are rotated and coordinates need to be adjusted.
	* @group groupD8
	* @param {RectangleLike} rect - Rectangle with original coordinates to transform
	* @param {RectangleLike} sourceFrame - Source texture frame (includes offset and dimensions)
	* @param {GD8Symmetry} rotation - The groupD8 rotation value
	* @param {Rectangle} out - Rectangle to store the result
	* @returns {Rectangle} Transformed coordinates (includes source frame offset)
	*/
	transformRectCoords: (rect, sourceFrame, rotation, out) => {
		const { x, y, width, height } = rect;
		const { x: frameX, y: frameY, width: frameWidth, height: frameHeight } = sourceFrame;
		if (rotation === groupD8.E) {
			out.set(x + frameX, y + frameY, width, height);
			return out;
		} else if (rotation === groupD8.S) return out.set(frameWidth - y - height + frameX, x + frameY, height, width);
		else if (rotation === groupD8.W) return out.set(frameWidth - x - width + frameX, frameHeight - y - height + frameY, width, height);
		else if (rotation === groupD8.N) return out.set(y + frameX, frameHeight - x - width + frameY, height, width);
		return out.set(x + frameX, y + frameY, width, height);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/maths/shapes/Rectangle.mjs
var tempPoints = [
	new Point(),
	new Point(),
	new Point(),
	new Point()
];
var Rectangle = class Rectangle {
	/**
	* @param x - The X coordinate of the upper-left corner of the rectangle
	* @param y - The Y coordinate of the upper-left corner of the rectangle
	* @param width - The overall width of the rectangle
	* @param height - The overall height of the rectangle
	*/
	constructor(x = 0, y = 0, width = 0, height = 0) {
		/**
		* The type of the object, mainly used to avoid `instanceof` checks
		* @example
		* ```ts
		* // Check shape type
		* const shape = new Rectangle(0, 0, 100, 100);
		* console.log(shape.type); // 'rectangle'
		*
		* // Use in type guards
		* if (shape.type === 'rectangle') {
		*     console.log(shape.width, shape.height);
		* }
		* ```
		* @readonly
		* @default 'rectangle'
		* @see {@link SHAPE_PRIMITIVE} For all shape types
		*/
		this.type = "rectangle";
		this.x = Number(x);
		this.y = Number(y);
		this.width = Number(width);
		this.height = Number(height);
	}
	/**
	* Returns the left edge (x-coordinate) of the rectangle.
	* @example
	* ```ts
	* // Get left edge position
	* const rect = new Rectangle(100, 100, 200, 150);
	* console.log(rect.left); // 100
	*
	* // Use in alignment calculations
	* sprite.x = rect.left + padding;
	*
	* // Compare positions
	* if (point.x > rect.left) {
	*     console.log('Point is right of rectangle');
	* }
	* ```
	* @readonly
	* @returns The x-coordinate of the left edge
	* @see {@link Rectangle.right} For right edge position
	* @see {@link Rectangle.x} For direct x-coordinate access
	*/
	get left() {
		return this.x;
	}
	/**
	* Returns the right edge (x + width) of the rectangle.
	* @example
	* ```ts
	* // Get right edge position
	* const rect = new Rectangle(100, 100, 200, 150);
	* console.log(rect.right); // 300
	*
	* // Align to right edge
	* sprite.x = rect.right - sprite.width;
	*
	* // Check boundaries
	* if (point.x < rect.right) {
	*     console.log('Point is inside right bound');
	* }
	* ```
	* @readonly
	* @returns The x-coordinate of the right edge
	* @see {@link Rectangle.left} For left edge position
	* @see {@link Rectangle.width} For width value
	*/
	get right() {
		return this.x + this.width;
	}
	/**
	* Returns the top edge (y-coordinate) of the rectangle.
	* @example
	* ```ts
	* // Get top edge position
	* const rect = new Rectangle(100, 100, 200, 150);
	* console.log(rect.top); // 100
	*
	* // Position above rectangle
	* sprite.y = rect.top - sprite.height;
	*
	* // Check vertical position
	* if (point.y > rect.top) {
	*     console.log('Point is below top edge');
	* }
	* ```
	* @readonly
	* @returns The y-coordinate of the top edge
	* @see {@link Rectangle.bottom} For bottom edge position
	* @see {@link Rectangle.y} For direct y-coordinate access
	*/
	get top() {
		return this.y;
	}
	/**
	* Returns the bottom edge (y + height) of the rectangle.
	* @example
	* ```ts
	* // Get bottom edge position
	* const rect = new Rectangle(100, 100, 200, 150);
	* console.log(rect.bottom); // 250
	*
	* // Stack below rectangle
	* sprite.y = rect.bottom + margin;
	*
	* // Check vertical bounds
	* if (point.y < rect.bottom) {
	*     console.log('Point is above bottom edge');
	* }
	* ```
	* @readonly
	* @returns The y-coordinate of the bottom edge
	* @see {@link Rectangle.top} For top edge position
	* @see {@link Rectangle.height} For height value
	*/
	get bottom() {
		return this.y + this.height;
	}
	/**
	* Determines whether the Rectangle is empty (has no area).
	* @example
	* ```ts
	* // Check zero dimensions
	* const rect = new Rectangle(100, 100, 0, 50);
	* console.log(rect.isEmpty()); // true
	* ```
	* @returns True if the rectangle has no area
	* @see {@link Rectangle.width} For width value
	* @see {@link Rectangle.height} For height value
	*/
	isEmpty() {
		return this.left === this.right || this.top === this.bottom;
	}
	/**
	* A constant empty rectangle. This is a new object every time the property is accessed.
	* @example
	* ```ts
	* // Get fresh empty rectangle
	* const empty = Rectangle.EMPTY;
	* console.log(empty.isEmpty()); // true
	* ```
	* @returns A new empty rectangle instance
	* @see {@link Rectangle.isEmpty} For empty state testing
	*/
	static get EMPTY() {
		return new Rectangle(0, 0, 0, 0);
	}
	/**
	* Creates a clone of this Rectangle
	* @example
	* ```ts
	* // Basic cloning
	* const original = new Rectangle(100, 100, 200, 150);
	* const copy = original.clone();
	*
	* // Clone and modify
	* const modified = original.clone();
	* modified.width *= 2;
	* modified.height += 50;
	*
	* // Verify independence
	* console.log(original.width);  // 200
	* console.log(modified.width);  // 400
	* ```
	* @returns A copy of the rectangle
	* @see {@link Rectangle.copyFrom} For copying into existing rectangle
	* @see {@link Rectangle.copyTo} For copying to another rectangle
	*/
	clone() {
		return new Rectangle(this.x, this.y, this.width, this.height);
	}
	/**
	* Converts a Bounds object to a Rectangle object.
	* @example
	* ```ts
	* // Convert bounds to rectangle
	* const bounds = container.getBounds();
	* const rect = new Rectangle().copyFromBounds(bounds);
	* ```
	* @param bounds - The bounds to copy and convert to a rectangle
	* @returns Returns itself
	* @see {@link Bounds} For bounds object structure
	* @see {@link Rectangle.getBounds} For getting rectangle bounds
	*/
	copyFromBounds(bounds) {
		this.x = bounds.minX;
		this.y = bounds.minY;
		this.width = bounds.maxX - bounds.minX;
		this.height = bounds.maxY - bounds.minY;
		return this;
	}
	/**
	* Copies another rectangle to this one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Rectangle(100, 100, 200, 150);
	* const target = new Rectangle();
	* target.copyFrom(source);
	*
	* // Chain with other operations
	* const rect = new Rectangle()
	*     .copyFrom(source)
	*     .pad(10);
	* ```
	* @param rectangle - The rectangle to copy from
	* @returns Returns itself
	* @see {@link Rectangle.copyTo} For copying to another rectangle
	* @see {@link Rectangle.clone} For creating new rectangle copy
	*/
	copyFrom(rectangle) {
		this.x = rectangle.x;
		this.y = rectangle.y;
		this.width = rectangle.width;
		this.height = rectangle.height;
		return this;
	}
	/**
	* Copies this rectangle to another one.
	* @example
	* ```ts
	* // Basic copying
	* const source = new Rectangle(100, 100, 200, 150);
	* const target = new Rectangle();
	* source.copyTo(target);
	*
	* // Chain with other operations
	* const result = source
	*     .copyTo(new Rectangle())
	*     .getBounds();
	* ```
	* @param rectangle - The rectangle to copy to
	* @returns Returns given parameter
	* @see {@link Rectangle.copyFrom} For copying from another rectangle
	* @see {@link Rectangle.clone} For creating new rectangle copy
	*/
	copyTo(rectangle) {
		rectangle.copyFrom(this);
		return rectangle;
	}
	/**
	* Checks whether the x and y coordinates given are contained within this Rectangle
	* @example
	* ```ts
	* // Basic containment check
	* const rect = new Rectangle(100, 100, 200, 150);
	* const isInside = rect.contains(150, 125); // true
	* // Check edge cases
	* console.log(rect.contains(100, 100)); // true (on edge)
	* console.log(rect.contains(300, 250)); // false (outside)
	* ```
	* @param x - The X coordinate of the point to test
	* @param y - The Y coordinate of the point to test
	* @returns Whether the x/y coordinates are within this Rectangle
	* @see {@link Rectangle.containsRect} For rectangle containment
	* @see {@link Rectangle.strokeContains} For checking stroke intersection
	*/
	contains(x, y) {
		if (this.width <= 0 || this.height <= 0) return false;
		if (x >= this.x && x < this.x + this.width) {
			if (y >= this.y && y < this.y + this.height) return true;
		}
		return false;
	}
	/**
	* Checks whether the x and y coordinates given are contained within this rectangle including the stroke.
	* @example
	* ```ts
	* // Basic stroke check
	* const rect = new Rectangle(100, 100, 200, 150);
	* const isOnStroke = rect.strokeContains(150, 100, 4); // 4px line width
	*
	* // Check with different alignments
	* const innerStroke = rect.strokeContains(150, 100, 4, 1);   // Inside
	* const centerStroke = rect.strokeContains(150, 100, 4, 0.5); // Centered
	* const outerStroke = rect.strokeContains(150, 100, 4, 0);   // Outside
	* ```
	* @param x - The X coordinate of the point to test
	* @param y - The Y coordinate of the point to test
	* @param strokeWidth - The width of the line to check
	* @param alignment - The alignment of the stroke (1 = inner, 0.5 = centered, 0 = outer)
	* @returns Whether the x/y coordinates are within this rectangle's stroke
	* @see {@link Rectangle.contains} For checking fill containment
	* @see {@link Rectangle.getBounds} For getting stroke bounds
	*/
	strokeContains(x, y, strokeWidth, alignment = .5) {
		const { width, height } = this;
		if (width <= 0 || height <= 0) return false;
		const _x = this.x;
		const _y = this.y;
		const strokeWidthOuter = strokeWidth * (1 - alignment);
		const strokeWidthInner = strokeWidth - strokeWidthOuter;
		const outerLeft = _x - strokeWidthOuter;
		const outerRight = _x + width + strokeWidthOuter;
		const outerTop = _y - strokeWidthOuter;
		const outerBottom = _y + height + strokeWidthOuter;
		const innerLeft = _x + strokeWidthInner;
		const innerRight = _x + width - strokeWidthInner;
		const innerTop = _y + strokeWidthInner;
		const innerBottom = _y + height - strokeWidthInner;
		return x >= outerLeft && x <= outerRight && y >= outerTop && y <= outerBottom && !(x > innerLeft && x < innerRight && y > innerTop && y < innerBottom);
	}
	/**
	* Determines whether the `other` Rectangle transformed by `transform` intersects with `this` Rectangle object.
	* Returns true only if the area of the intersection is >0, this means that Rectangles
	* sharing a side are not overlapping. Another side effect is that an arealess rectangle
	* (width or height equal to zero) can't intersect any other rectangle.
	* @param {Rectangle} other - The Rectangle to intersect with `this`.
	* @param {Matrix} transform - The transformation matrix of `other`.
	* @returns {boolean} A value of `true` if the transformed `other` Rectangle intersects with `this`; otherwise `false`.
	*/
	/**
	* Determines whether the `other` Rectangle transformed by `transform` intersects with `this` Rectangle object.
	*
	* Returns true only if the area of the intersection is greater than 0.
	* This means that rectangles sharing only a side are not considered intersecting.
	* @example
	* ```ts
	* // Basic intersection check
	* const rect1 = new Rectangle(0, 0, 100, 100);
	* const rect2 = new Rectangle(50, 50, 100, 100);
	* console.log(rect1.intersects(rect2)); // true
	*
	* // With transformation matrix
	* const matrix = new Matrix();
	* matrix.rotate(Math.PI / 4); // 45 degrees
	* console.log(rect1.intersects(rect2, matrix)); // Checks with rotation
	*
	* // Edge cases
	* const zeroWidth = new Rectangle(0, 0, 0, 100);
	* console.log(rect1.intersects(zeroWidth)); // false (no area)
	* ```
	* @remarks
	* - Returns true only if intersection area is > 0
	* - Rectangles sharing only a side are not intersecting
	* - Zero-area rectangles cannot intersect anything
	* - Supports optional transformation matrix
	* @param other - The Rectangle to intersect with `this`
	* @param transform - Optional transformation matrix of `other`
	* @returns True if the transformed `other` Rectangle intersects with `this`
	* @see {@link Rectangle.containsRect} For containment testing
	* @see {@link Rectangle.contains} For point testing
	*/
	intersects(other, transform) {
		if (!transform) {
			const x02 = this.x < other.x ? other.x : this.x;
			if ((this.right > other.right ? other.right : this.right) <= x02) return false;
			const y02 = this.y < other.y ? other.y : this.y;
			return (this.bottom > other.bottom ? other.bottom : this.bottom) > y02;
		}
		const x0 = this.left;
		const x1 = this.right;
		const y0 = this.top;
		const y1 = this.bottom;
		if (x1 <= x0 || y1 <= y0) return false;
		const lt = tempPoints[0].set(other.left, other.top);
		const lb = tempPoints[1].set(other.left, other.bottom);
		const rt = tempPoints[2].set(other.right, other.top);
		const rb = tempPoints[3].set(other.right, other.bottom);
		if (rt.x <= lt.x || lb.y <= lt.y) return false;
		const s = Math.sign(transform.a * transform.d - transform.b * transform.c);
		if (s === 0) return false;
		transform.apply(lt, lt);
		transform.apply(lb, lb);
		transform.apply(rt, rt);
		transform.apply(rb, rb);
		if (Math.max(lt.x, lb.x, rt.x, rb.x) <= x0 || Math.min(lt.x, lb.x, rt.x, rb.x) >= x1 || Math.max(lt.y, lb.y, rt.y, rb.y) <= y0 || Math.min(lt.y, lb.y, rt.y, rb.y) >= y1) return false;
		const nx = s * (lb.y - lt.y);
		const ny = s * (lt.x - lb.x);
		const n00 = nx * x0 + ny * y0;
		const n10 = nx * x1 + ny * y0;
		const n01 = nx * x0 + ny * y1;
		const n11 = nx * x1 + ny * y1;
		if (Math.max(n00, n10, n01, n11) <= nx * lt.x + ny * lt.y || Math.min(n00, n10, n01, n11) >= nx * rb.x + ny * rb.y) return false;
		const mx = s * (lt.y - rt.y);
		const my = s * (rt.x - lt.x);
		const m00 = mx * x0 + my * y0;
		const m10 = mx * x1 + my * y0;
		const m01 = mx * x0 + my * y1;
		const m11 = mx * x1 + my * y1;
		if (Math.max(m00, m10, m01, m11) <= mx * lt.x + my * lt.y || Math.min(m00, m10, m01, m11) >= mx * rb.x + my * rb.y) return false;
		return true;
	}
	/**
	* Pads the rectangle making it grow in all directions.
	*
	* If paddingY is omitted, both paddingX and paddingY will be set to paddingX.
	* @example
	* ```ts
	* // Basic padding
	* const rect = new Rectangle(100, 100, 200, 150);
	* rect.pad(10); // Adds 10px padding on all sides
	*
	* // Different horizontal and vertical padding
	* const uiRect = new Rectangle(0, 0, 100, 50);
	* uiRect.pad(20, 10); // 20px horizontal, 10px vertical
	* ```
	* @remarks
	* - Adjusts x/y by subtracting padding
	* - Increases width/height by padding * 2
	* - Common in UI layout calculations
	* - Chainable with other methods
	* @param paddingX - The horizontal padding amount
	* @param paddingY - The vertical padding amount
	* @returns Returns itself
	* @see {@link Rectangle.enlarge} For growing to include another rectangle
	* @see {@link Rectangle.fit} For shrinking to fit within another rectangle
	*/
	pad(paddingX = 0, paddingY = paddingX) {
		this.x -= paddingX;
		this.y -= paddingY;
		this.width += paddingX * 2;
		this.height += paddingY * 2;
		return this;
	}
	/**
	* Fits this rectangle around the passed one.
	* @example
	* ```ts
	* // Basic fitting
	* const container = new Rectangle(0, 0, 100, 100);
	* const content = new Rectangle(25, 25, 200, 200);
	* content.fit(container); // Clips to container bounds
	* ```
	* @param rectangle - The rectangle to fit around
	* @returns Returns itself
	* @see {@link Rectangle.enlarge} For growing to include another rectangle
	* @see {@link Rectangle.pad} For adding padding around the rectangle
	*/
	fit(rectangle) {
		const x1 = Math.max(this.x, rectangle.x);
		const x2 = Math.min(this.x + this.width, rectangle.x + rectangle.width);
		const y1 = Math.max(this.y, rectangle.y);
		const y2 = Math.min(this.y + this.height, rectangle.y + rectangle.height);
		this.x = x1;
		this.width = Math.max(x2 - x1, 0);
		this.y = y1;
		this.height = Math.max(y2 - y1, 0);
		return this;
	}
	/**
	* Enlarges rectangle so that its corners lie on a grid defined by resolution.
	* @example
	* ```ts
	* // Basic grid alignment
	* const rect = new Rectangle(10.2, 10.6, 100.8, 100.4);
	* rect.ceil(); // Aligns to whole pixels
	*
	* // Custom resolution grid
	* const uiRect = new Rectangle(5.3, 5.7, 50.2, 50.8);
	* uiRect.ceil(0.5); // Aligns to half pixels
	*
	* // Use with precision value
	* const preciseRect = new Rectangle(20.001, 20.999, 100.001, 100.999);
	* preciseRect.ceil(1, 0.01); // Handles small decimal variations
	* ```
	* @param resolution - The grid size to align to (1 = whole pixels)
	* @param eps - Small number to prevent floating point errors
	* @returns Returns itself
	* @see {@link Rectangle.fit} For constraining to bounds
	* @see {@link Rectangle.enlarge} For growing dimensions
	*/
	ceil(resolution = 1, eps = .001) {
		const x2 = Math.ceil((this.x + this.width - eps) * resolution) / resolution;
		const y2 = Math.ceil((this.y + this.height - eps) * resolution) / resolution;
		this.x = Math.floor((this.x + eps) * resolution) / resolution;
		this.y = Math.floor((this.y + eps) * resolution) / resolution;
		this.width = x2 - this.x;
		this.height = y2 - this.y;
		return this;
	}
	/**
	* Scales the rectangle's dimensions and position by the specified factors.
	* @example
	* ```ts
	* const rect = new Rectangle(50, 50, 100, 100);
	*
	* // Scale uniformly
	* rect.scale(0.5, 0.5);
	* // rect is now: x=25, y=25, width=50, height=50
	*
	* // non-uniformly
	* rect.scale(0.5, 1);
	* // rect is now: x=25, y=50, width=50, height=100
	* ```
	* @param x - The factor by which to scale the horizontal properties (x, width).
	* @param y - The factor by which to scale the vertical properties (y, height).
	* @returns Returns itself
	*/
	scale(x, y = x) {
		this.x *= x;
		this.y *= y;
		this.width *= x;
		this.height *= y;
		return this;
	}
	/**
	* Enlarges this rectangle to include the passed rectangle.
	* @example
	* ```ts
	* // Basic enlargement
	* const rect = new Rectangle(50, 50, 100, 100);
	* const other = new Rectangle(0, 0, 200, 75);
	* rect.enlarge(other);
	* // rect is now: x=0, y=0, width=200, height=150
	*
	* // Use for bounding box calculation
	* const bounds = new Rectangle();
	* objects.forEach((obj) => {
	*     bounds.enlarge(obj.getBounds());
	* });
	* ```
	* @param rectangle - The rectangle to include
	* @returns Returns itself
	* @see {@link Rectangle.fit} For shrinking to fit within another rectangle
	* @see {@link Rectangle.pad} For adding padding around the rectangle
	*/
	enlarge(rectangle) {
		const x1 = Math.min(this.x, rectangle.x);
		const x2 = Math.max(this.x + this.width, rectangle.x + rectangle.width);
		const y1 = Math.min(this.y, rectangle.y);
		const y2 = Math.max(this.y + this.height, rectangle.y + rectangle.height);
		this.x = x1;
		this.width = x2 - x1;
		this.y = y1;
		this.height = y2 - y1;
		return this;
	}
	/**
	* Returns the framing rectangle of the rectangle as a Rectangle object
	* @example
	* ```ts
	* // Basic bounds retrieval
	* const rect = new Rectangle(100, 100, 200, 150);
	* const bounds = rect.getBounds();
	*
	* // Reuse existing rectangle
	* const out = new Rectangle();
	* rect.getBounds(out);
	* ```
	* @param out - Optional rectangle to store the result
	* @returns The framing rectangle
	* @see {@link Rectangle.copyFrom} For direct copying
	* @see {@link Rectangle.clone} For creating new copy
	*/
	getBounds(out) {
		out || (out = new Rectangle());
		out.copyFrom(this);
		return out;
	}
	/**
	* Determines whether another Rectangle is fully contained within this Rectangle.
	*
	* Rectangles that occupy the same space are considered to be containing each other.
	*
	* Rectangles without area (width or height equal to zero) can't contain anything,
	* not even other arealess rectangles.
	* @example
	* ```ts
	* // Check if one rectangle contains another
	* const container = new Rectangle(0, 0, 100, 100);
	* const inner = new Rectangle(25, 25, 50, 50);
	*
	* console.log(container.containsRect(inner)); // true
	*
	* // Check overlapping rectangles
	* const partial = new Rectangle(75, 75, 50, 50);
	* console.log(container.containsRect(partial)); // false
	*
	* // Zero-area rectangles can't contain anything
	* const empty = new Rectangle(0, 0, 0, 100);
	* console.log(empty.containsRect(inner)); // false
	* ```
	* @param other - The Rectangle to check for containment
	* @returns True if other is fully contained within this Rectangle
	* @see {@link Rectangle.contains} For point containment
	* @see {@link Rectangle.intersects} For overlap testing
	*/
	containsRect(other) {
		if (this.width <= 0 || this.height <= 0) return false;
		const x1 = other.x;
		const y1 = other.y;
		const x2 = other.x + other.width;
		const y2 = other.y + other.height;
		return x1 >= this.x && x1 < this.x + this.width && y1 >= this.y && y1 < this.y + this.height && x2 >= this.x && x2 <= this.x + this.width && y2 >= this.y && y2 <= this.y + this.height;
	}
	/**
	* Sets the position and dimensions of the rectangle.
	* @example
	* ```ts
	* // Basic usage
	* const rect = new Rectangle();
	* rect.set(100, 100, 200, 150);
	*
	* // Chain with other operations
	* const bounds = new Rectangle()
	*     .set(0, 0, 100, 100)
	*     .pad(10);
	* ```
	* @param x - The X coordinate of the upper-left corner of the rectangle
	* @param y - The Y coordinate of the upper-left corner of the rectangle
	* @param width - The overall width of the rectangle
	* @param height - The overall height of the rectangle
	* @returns Returns itself for method chaining
	* @see {@link Rectangle.copyFrom} For copying from another rectangle
	* @see {@link Rectangle.clone} For creating a new copy
	*/
	set(x, y, width, height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		return this;
	}
	toString() {
		return `[pixi.js/math:Rectangle x=${this.x} y=${this.y} width=${this.width} height=${this.height}]`;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/utils/data/uid.mjs
var uidCache = { default: -1 };
function uid(name = "default") {
	if (uidCache[name] === void 0) uidCache[name] = -1;
	return ++uidCache[name];
}
function resetUids() {
	for (const key in uidCache) delete uidCache[key];
}
//#endregion
//#region node_modules/pixi.js/lib/utils/logging/deprecation.mjs
var warnings = /* @__PURE__ */ new Set();
var v8_0_0 = "8.0.0";
var v8_3_4 = "8.3.4";
var v8_21_0 = "8.21.0";
var v8_22_0 = "8.22.0";
var deprecationState = {
	quiet: false,
	noColor: false
};
var deprecation = ((version, message, ignoreDepth = 3) => {
	if (deprecationState.quiet || warnings.has(message)) return;
	let stack = (/* @__PURE__ */ new Error()).stack;
	const deprecationMessage = `${message}
Deprecated since v${version}`;
	const useGroup = typeof console.groupCollapsed === "function" && !deprecationState.noColor;
	if (typeof stack === "undefined") console.warn("PixiJS Deprecation Warning: ", deprecationMessage);
	else {
		stack = stack.split("\n").splice(ignoreDepth).join("\n");
		if (useGroup) {
			console.groupCollapsed("%cPixiJS Deprecation Warning: %c%s", "color:#614108;background:#fffbe6", "font-weight:normal;color:#614108;background:#fffbe6", deprecationMessage);
			console.warn(stack);
			console.groupEnd();
		} else {
			console.warn("PixiJS Deprecation Warning: ", deprecationMessage);
			console.warn(stack);
		}
	}
	warnings.add(message);
});
Object.defineProperties(deprecation, {
	quiet: {
		get: () => deprecationState.quiet,
		set: (value) => {
			deprecationState.quiet = value;
		},
		enumerable: true,
		configurable: false
	},
	noColor: {
		get: () => deprecationState.noColor,
		set: (value) => {
			deprecationState.noColor = value;
		},
		enumerable: true,
		configurable: false
	}
});
//#endregion
//#region node_modules/pixi.js/lib/utils/misc/NOOP.mjs
var NOOP = () => {};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/utils/isIntegerFormat.mjs
function isIntegerFormat(format) {
	return format.endsWith("int");
}
//#endregion
//#region node_modules/pixi.js/lib/maths/misc/pow2.mjs
function nextPow2(v) {
	v += v === 0 ? 1 : 0;
	--v;
	v |= v >>> 1;
	v |= v >>> 2;
	v |= v >>> 4;
	v |= v >>> 8;
	v |= v >>> 16;
	return v + 1;
}
function isPow2(v) {
	return !(v & v - 1) && !!v;
}
function log2(v) {
	let r = (v > 65535 ? 1 : 0) << 4;
	v >>>= r;
	let shift = (v > 255 ? 1 : 0) << 3;
	v >>>= shift;
	r |= shift;
	shift = (v > 15 ? 1 : 0) << 2;
	v >>>= shift;
	r |= shift;
	shift = (v > 3 ? 1 : 0) << 1;
	v >>>= shift;
	r |= shift;
	return r | v >> 1;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/definedProps.mjs
function definedProps(obj) {
	const result = {};
	for (const key in obj) if (obj[key] !== void 0) result[key] = obj[key];
	return result;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/TextureStyle.mjs
var idHash$1 = /* @__PURE__ */ Object.create(null);
function createResourceIdFromString(value) {
	const id = idHash$1[value];
	if (id === void 0) idHash$1[value] = uid("resource");
	return id;
}
var _TextureStyle = class _TextureStyle extends eventemitter3_default {
	/**
	* @param options - options for the style
	*/
	constructor(options = {}) {
		super();
		/** @internal */
		this._resourceType = "textureSampler";
		/**
		* Specifies the maximum anisotropy value clamp used by the sampler.
		* Note: Most implementations support {@link TextureStyle#maxAnisotropy} values in range
		* between 1 and 16, inclusive. The used value of {@link TextureStyle#maxAnisotropy} will
		* be clamped to the maximum value that the platform supports.
		* @internal
		*/
		this._maxAnisotropy = 1;
		/**
		* Has the style been destroyed?
		* @readonly
		*/
		this.destroyed = false;
		options = {
			..._TextureStyle.defaultOptions,
			...options
		};
		this.addressMode = options.addressMode;
		this.addressModeU = options.addressModeU ?? this.addressModeU;
		this.addressModeV = options.addressModeV ?? this.addressModeV;
		this.addressModeW = options.addressModeW ?? this.addressModeW;
		this.scaleMode = options.scaleMode;
		this.magFilter = options.magFilter ?? this.magFilter;
		this.minFilter = options.minFilter ?? this.minFilter;
		this.mipmapFilter = options.mipmapFilter ?? this.mipmapFilter;
		this.lodMinClamp = options.lodMinClamp;
		this.lodMaxClamp = options.lodMaxClamp;
		this.compare = options.compare;
		this.maxAnisotropy = options.maxAnisotropy ?? 1;
	}
	set addressMode(value) {
		this.addressModeU = value;
		this.addressModeV = value;
		this.addressModeW = value;
	}
	/** setting this will set wrapModeU,wrapModeV and wrapModeW all at once! */
	get addressMode() {
		return this.addressModeU;
	}
	set wrapMode(value) {
		deprecation(v8_0_0, "TextureStyle.wrapMode is now TextureStyle.addressMode");
		this.addressMode = value;
	}
	get wrapMode() {
		return this.addressMode;
	}
	set scaleMode(value) {
		this.magFilter = value;
		this.minFilter = value;
		this.mipmapFilter = value;
	}
	/** setting this will set magFilter,minFilter and mipmapFilter all at once!  */
	get scaleMode() {
		return this.magFilter;
	}
	/** Specifies the maximum anisotropy value clamp used by the sampler. */
	set maxAnisotropy(value) {
		this._maxAnisotropy = Math.min(value, 16);
		if (this._maxAnisotropy > 1) this.scaleMode = "linear";
	}
	get maxAnisotropy() {
		return this._maxAnisotropy;
	}
	get _resourceId() {
		return this._sharedResourceId || this._generateResourceId();
	}
	update() {
		this._sharedResourceId = null;
		this.emit("change", this);
	}
	_generateResourceId() {
		const bigKey = `${this.addressModeU}-${this.addressModeV}-${this.addressModeW}-${this.magFilter}-${this.minFilter}-${this.mipmapFilter}-${this.lodMinClamp}-${this.lodMaxClamp}-${this.compare}-${this._maxAnisotropy}`;
		this._sharedResourceId = createResourceIdFromString(bigKey);
		return this._resourceId;
	}
	/** Destroys the style */
	destroy() {
		this.destroyed = true;
		this.emit("destroy", this);
		this.emit("change", this);
		this.removeAllListeners();
	}
};
/** default options for the style */
_TextureStyle.defaultOptions = {
	addressMode: "clamp-to-edge",
	scaleMode: "linear"
};
var TextureStyle = _TextureStyle;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/sources/TextureSource.mjs
var _TextureSource = class _TextureSource extends eventemitter3_default {
	/**
	* @param options - options for creating a new TextureSource
	*/
	constructor(options = {}) {
		super();
		this.options = options;
		/** @internal */
		this._gpuData = /* @__PURE__ */ Object.create(null);
		/** @internal */
		this._gcLastUsed = -1;
		/** unique id for this Texture source */
		this.uid = uid("textureSource");
		/**
		* The resource type used by this TextureSource. This is used by the bind groups to determine
		* how to handle this resource.
		* @internal
		*/
		this._resourceType = "textureSource";
		/**
		* i unique resource id, used by the bind group systems.
		* This can change if the texture is resized or its resource changes
		* @internal
		*/
		this._resourceId = uid("resource");
		/**
		* this is how the backends know how to upload this texture to the GPU
		* It changes depending on the resource type. Classes that extend TextureSource
		* should override this property.
		* @internal
		*/
		this.uploadMethodId = "unknown";
		/** @internal */
		this._resolution = 1;
		/** the pixel width of this texture source. This is the REAL pure number, not accounting resolution */
		this.pixelWidth = 1;
		/** the pixel height of this texture source. This is the REAL pure number, not accounting resolution */
		this.pixelHeight = 1;
		/**
		* the width of this texture source, accounting for resolution
		* eg pixelWidth 200, resolution 2, then width will be 100
		*/
		this.width = 1;
		/**
		* the height of this texture source, accounting for resolution
		* eg pixelHeight 200, resolution 2, then height will be 100
		*/
		this.height = 1;
		/**
		* The number of samples of a multisample texture. This is always 1 for non-multisample textures.
		* To enable multisample for a texture, set antialias to true
		* @internal
		*/
		this.sampleCount = 1;
		/**
		* The number of mip levels to generate for this texture.
		* this is overridden if autoGenerateMipmaps is true. it is read only!
		*/
		this.mipLevelCount = 1;
		/**
		* Should we auto generate mipmaps for this texture? This will automatically generate mipmaps
		* for this texture when uploading to the GPU. Mipmapped textures take up more memory, but
		* can look better when scaled down.
		*
		* For performance reasons, it is recommended to NOT use this with RenderTextures, as they are often updated every frame.
		* If you do, make sure to call `updateMipmaps` after you update the texture.
		*
		* A 3D texture on WebGPU needs {@link TextureSourceOptions.storage} and `rgba8unorm` or `rgba16float`,
		* because a compute shader writes the mips. WebGL fills the chain with `gl.generateMipmap`.
		*/
		this.autoGenerateMipmaps = false;
		/** the format that the texture data has */
		this.format = "rgba8unorm";
		/** how the texture is stored (WebGPU texture dimension), derived from {@link TextureSource#viewDimension} */
		this.dimension = "2d";
		/** how this texture is viewed/sampled by shaders (WebGPU view dimension) */
		this.viewDimension = "2d";
		/** how many array layers this texture has; 1 for a 3D texture */
		this.arrayLayerCount = 1;
		/** the depth of a 3D texture in texels; 1 for every other texture */
		this.depth = 1;
		this._ownsStyle = false;
		/**
		* Only really affects RenderTextures.
		* Should we use antialiasing for this texture. It will look better, but may impact performance as a
		* Blit operation will be required to resolve the texture.
		*/
		this.antialias = false;
		/**
		* Treat the underlying GPU texture as transient — see {@link TextureSourceOptions.transient}.
		* Internal flag, populated from options.
		* @internal
		*/
		this.transient = false;
		/**
		* Whether compute shaders can write to this texture on WebGPU. See {@link TextureSourceOptions.storage}.
		* Read when the GPU texture is created.
		*/
		this.storage = false;
		/**
		* Used by the batcher to build texture batches. faster to have the variable here!
		* @protected
		*/
		this._batchTick = -1;
		/**
		* A temporary batch location for the texture batching. Here for performance reasons only!
		* @protected
		*/
		this._textureBindLocation = -1;
		const passedOptions = options;
		options = {
			..._TextureSource.defaultOptions,
			...options
		};
		const viewDimension = resolveViewDimension(options);
		const dimension = viewDimension === "3d" || viewDimension === "1d" ? viewDimension : "2d";
		validateTextureShape(passedOptions, viewDimension, dimension);
		this.label = options.label ?? "";
		this.resource = options.resource;
		this.autoGarbageCollect = options.autoGarbageCollect;
		this._resolution = options.resolution;
		if (options.width) this.pixelWidth = options.width * this._resolution;
		else this.pixelWidth = this.resource ? this.resourceWidth ?? 1 : 1;
		if (options.height) this.pixelHeight = options.height * this._resolution;
		else this.pixelHeight = this.resource ? this.resourceHeight ?? 1 : 1;
		this.width = this.pixelWidth / this._resolution;
		this.height = this.pixelHeight / this._resolution;
		this.format = options.format;
		this.dimension = dimension;
		this.viewDimension = viewDimension;
		this.arrayLayerCount = options.arrayLayerCount;
		this.depth = dimension === "3d" ? options.depth ?? 1 : 1;
		this.mipLevelCount = options.mipLevelCount;
		this.autoGenerateMipmaps = options.autoGenerateMipmaps;
		this.sampleCount = options.sampleCount;
		this.antialias = dimension === "3d" ? false : options.antialias;
		this.transient = options.transient ?? false;
		this.storage = options.storage ?? false;
		this.alphaMode = options.alphaMode;
		this.style = new TextureStyle(definedProps(options));
		this._ownsStyle = true;
		this.destroyed = false;
		this._refreshPOT();
	}
	/**
	* The size along z that the GPU allocates: {@link TextureSource#depth} for a 3D texture,
	* {@link TextureSource#arrayLayerCount} otherwise. WebGPU's `depthOrArrayLayers`.
	*/
	get depthOrArrayLayers() {
		return this.dimension === "3d" ? this.depth : this.arrayLayerCount || 1;
	}
	/** returns itself */
	get source() {
		return this;
	}
	/** the style of the texture */
	get style() {
		return this._style;
	}
	set style(value) {
		if (this.style === value) return;
		this._ownsStyle = false;
		this._style?.off("change", this._onStyleChange, this);
		this._style = value;
		this._style?.on("change", this._onStyleChange, this);
		this._onStyleChange();
	}
	/** Specifies the maximum anisotropy value clamp used by the sampler. */
	set maxAnisotropy(value) {
		this._style.maxAnisotropy = value;
	}
	get maxAnisotropy() {
		return this._style.maxAnisotropy;
	}
	/** setting this will set wrapModeU, wrapModeV and wrapModeW all at once! */
	get addressMode() {
		return this._style.addressMode;
	}
	set addressMode(value) {
		this._style.addressMode = value;
	}
	/** setting this will set wrapModeU, wrapModeV and wrapModeW all at once! */
	get repeatMode() {
		return this._style.addressMode;
	}
	set repeatMode(value) {
		this._style.addressMode = value;
	}
	/** Specifies the sampling behavior when the sample footprint is smaller than or equal to one texel. */
	get magFilter() {
		return this._style.magFilter;
	}
	set magFilter(value) {
		this._style.magFilter = value;
	}
	/** Specifies the sampling behavior when the sample footprint is larger than one texel. */
	get minFilter() {
		return this._style.minFilter;
	}
	set minFilter(value) {
		this._style.minFilter = value;
	}
	/** Specifies behavior for sampling between mipmap levels. */
	get mipmapFilter() {
		return this._style.mipmapFilter;
	}
	set mipmapFilter(value) {
		this._style.mipmapFilter = value;
	}
	/** Specifies the minimum and maximum levels of detail, respectively, used internally when sampling a texture. */
	get lodMinClamp() {
		return this._style.lodMinClamp;
	}
	set lodMinClamp(value) {
		this._style.lodMinClamp = value;
	}
	/** Specifies the minimum and maximum levels of detail, respectively, used internally when sampling a texture. */
	get lodMaxClamp() {
		return this._style.lodMaxClamp;
	}
	set lodMaxClamp(value) {
		this._style.lodMaxClamp = value;
	}
	_onStyleChange() {
		this.emit("styleChange", this);
	}
	/** call this if you have modified the texture outside of the constructor */
	update() {
		if (this.resource) {
			const resolution = this._resolution;
			if (this.resize(this.resourceWidth / resolution, this.resourceHeight / resolution)) return;
		}
		this.emit("update", this);
	}
	/** Destroys this texture source */
	destroy() {
		this.destroyed = true;
		this.unload();
		this.emit("destroy", this);
		if (this._style) {
			if (this._ownsStyle) this._style.destroy();
			this._style = null;
		}
		this.uploadMethodId = null;
		this.resource = null;
		this.removeAllListeners();
	}
	/**
	* This will unload the Texture source from the GPU. This will free up the GPU memory
	* As soon as it is required fore rendering, it will be re-uploaded.
	*/
	unload() {
		this._resourceId = uid("resource");
		this.emit("change", this);
		this.emit("unload", this);
		for (const key in this._gpuData) this._gpuData[key]?.destroy?.();
		this._gpuData = /* @__PURE__ */ Object.create(null);
	}
	/** the width of the resource. This is the REAL pure number, not accounting resolution   */
	get resourceWidth() {
		const { resource } = this;
		return resource.naturalWidth || resource.videoWidth || resource.displayWidth || resource.width;
	}
	/** the height of the resource. This is the REAL pure number, not accounting resolution */
	get resourceHeight() {
		const { resource } = this;
		return resource.naturalHeight || resource.videoHeight || resource.displayHeight || resource.height;
	}
	/**
	* the resolution of the texture. Changing this number, will not change the number of pixels in the actual texture
	* but will the size of the texture when rendered.
	*
	* changing the resolution of this texture to 2 for example will make it appear twice as small when rendered (as pixel
	* density will have increased)
	*/
	get resolution() {
		return this._resolution;
	}
	set resolution(resolution) {
		if (this._resolution === resolution) return;
		this._resolution = resolution;
		this.width = this.pixelWidth / resolution;
		this.height = this.pixelHeight / resolution;
	}
	/**
	* Resize the texture, this is handy if you want to use the texture as a render texture
	* @param width - the new width of the texture
	* @param height - the new height of the texture
	* @param resolution - the new resolution of the texture
	* @returns - if the texture was resized
	*/
	resize(width, height, resolution) {
		resolution || (resolution = this._resolution);
		width || (width = this.width);
		height || (height = this.height);
		const newPixelWidth = Math.round(width * resolution);
		const newPixelHeight = Math.round(height * resolution);
		this.width = newPixelWidth / resolution;
		this.height = newPixelHeight / resolution;
		this._resolution = resolution;
		if (this.pixelWidth === newPixelWidth && this.pixelHeight === newPixelHeight) return false;
		this._refreshPOT();
		this.pixelWidth = newPixelWidth;
		this.pixelHeight = newPixelHeight;
		this.emit("resize", this);
		this._resourceId = uid("resource");
		this.emit("change", this);
		return true;
	}
	/**
	* Lets the renderer know that this texture has been updated and its mipmaps should be re-generated.
	* This is only important for RenderTexture instances, as standard Texture instances will have their
	* mipmaps generated on upload. You should call this method after you make any change to the texture
	*
	* The reason for this is is can be quite expensive to update mipmaps for a texture. So by default,
	* We want you, the developer to specify when this action should happen.
	*
	* Generally you don't want to have mipmaps generated on Render targets that are changed every frame,
	*/
	updateMipmaps() {
		if (this.autoGenerateMipmaps && this.mipLevelCount > 1) this.emit("updateMipmaps", this);
	}
	set wrapMode(value) {
		this._style.wrapMode = value;
	}
	get wrapMode() {
		return this._style.wrapMode;
	}
	set scaleMode(value) {
		this._style.scaleMode = value;
	}
	/** setting this will set magFilter,minFilter and mipmapFilter all at once!  */
	get scaleMode() {
		return this._style.scaleMode;
	}
	/**
	* Refresh check for isPowerOfTwo texture based on size
	* @private
	*/
	_refreshPOT() {
		this.isPowerOfTwo = isPow2(this.pixelWidth) && isPow2(this.pixelHeight);
	}
	static test(_resource) {
		throw new Error("Unimplemented");
	}
};
/** The default options used when creating a new TextureSource. override these to add your own defaults */
_TextureSource.defaultOptions = {
	resolution: 1,
	format: "bgra8unorm",
	alphaMode: "premultiply-alpha-on-upload",
	arrayLayerCount: 1,
	mipLevelCount: 1,
	autoGenerateMipmaps: false,
	sampleCount: 1,
	antialias: false,
	autoGarbageCollect: false
};
var TextureSource = _TextureSource;
function resolveViewDimension(options) {
	if (options.viewDimension) return options.viewDimension;
	if (options.depth) return "3d";
	return options.arrayLayerCount > 1 ? "2d-array" : "2d";
}
function validateTextureShape(options, viewDimension, dimension) {
	if (options.depth !== void 0 && typeof options.depth !== "number") throw new Error(`[TextureSource] depth is a 3D texture's depth in texels, but got ${options.depth}. For a depth buffer, use the depth option of a RenderTarget or the renderer.`);
	if (options.depth && options.arrayLayerCount > 1) throw new Error("[TextureSource] depth and arrayLayerCount can't be combined: use depth for a 3D texture or arrayLayerCount for a 2D array.");
	if (options.depth && viewDimension !== "3d") throw new Error(`[TextureSource] depth makes a 3D texture, but viewDimension is '${viewDimension}'. Use arrayLayerCount for layered textures.`);
	if (viewDimension === "3d" && options.arrayLayerCount > 1) throw new Error("[TextureSource] a 3D texture takes depth, not arrayLayerCount.");
	if (options.dimensions && options.dimensions !== dimension) throw new Error(`[TextureSource] dimensions '${options.dimensions}' doesn't match viewDimension '${viewDimension}'. Leave dimensions out; it is derived from the view.`);
	else if (options.dimensions) deprecation(v8_22_0, "TextureSource dimensions is derived from viewDimension and depth; leave it out.");
	if (dimension === "3d" && options.antialias) throw new Error("[TextureSource] a 3D texture can't be antialiased: WebGPU has no multisampled 3D textures.");
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/sources/BufferImageSource.mjs
var BufferImageSource = class extends TextureSource {
	constructor(options) {
		const depthOrArrayLayers = options.depth ?? options.arrayLayerCount ?? 1;
		const buffer = options.resource || new Float32Array(options.width * options.height * depthOrArrayLayers * 4);
		let format = options.format;
		if (!format) {
			if (buffer instanceof Float32Array) format = "rgba32float";
			else if (buffer instanceof Int32Array) format = "rgba32uint";
			else if (buffer instanceof Uint32Array) format = "rgba32uint";
			else if (buffer instanceof Int16Array) format = "rgba16uint";
			else if (buffer instanceof Uint16Array) format = "rgba16uint";
			else if (buffer instanceof Int8Array) format = "bgra8unorm";
			else format = "bgra8unorm";
		}
		const noPremultiply = isIntegerFormat(format) || depthOrArrayLayers > 1;
		super({
			...noPremultiply && { alphaMode: "no-premultiply-alpha" },
			...options,
			resource: buffer,
			format
		});
		this.uploadMethodId = "buffer";
		/**
		* First texel of the range being uploaded by the current {@link BufferImageSource#update} call.
		* @internal
		*/
		this._updateStart = 0;
		/**
		* One past the last texel of the range being uploaded by the current
		* {@link BufferImageSource#update} call. `Infinity` means the whole texture.
		* @internal
		*/
		this._updateEnd = Infinity;
	}
	/**
	* Uploads the buffer to the GPU. Call this after changing the data in {@link TextureSource#resource}.
	*
	* The buffer is a flat list of texels in row-major order, so texel `i` sits at
	* `x = i % width`, `y = floor(i / width)`. Pass a texel range to upload only that part of
	* the texture; leave it out to upload everything.
	*
	* The upload happens immediately for every renderer that already holds the texture, and the
	* range applies to this call only. If you change several parts of the buffer, track the dirty
	* span yourself and call `update` once with the combined range. Each call has a fixed cost on
	* top of the bytes it moves, which reaches tens of microseconds on some mobile GPUs. One span
	* usually beats many small calls.
	*
	* Partial uploads assume the buffer holds exactly `width * height` texels. A 3D texture or 2D array
	* always uploads whole, so it takes no range.
	* @example
	* ```ts
	* const data = new Float32Array(4096 * 64 * 4);
	* const source = new BufferImageSource({ resource: data, width: 4096, height: 64 });
	*
	* // change texels 100 to 115 (4 floats per rgba32float texel)
	* data.fill(1, 100 * 4, 116 * 4);
	*
	* // upload only those 16 texels
	* source.update(100, 116);
	* ```
	* @param start - index of the first texel to upload
	* @param end - index one past the last texel to upload (exclusive, like `TypedArray.subarray`)
	*/
	update(start = 0, end = Infinity) {
		if ((start > 0 || end < Infinity) && this.depthOrArrayLayers > 1) throw new Error("[BufferImageSource] a 3D texture or 2D array uploads whole: call update() with no range.");
		this._updateStart = start;
		this._updateEnd = end;
		super.update();
		this._updateStart = 0;
		this._updateEnd = Infinity;
	}
	static test(resource) {
		return resource instanceof Int8Array || resource instanceof Uint8Array || resource instanceof Uint8ClampedArray || resource instanceof Int16Array || resource instanceof Uint16Array || resource instanceof Int32Array || resource instanceof Uint32Array || resource instanceof Float32Array;
	}
};
BufferImageSource.extension = ExtensionType.TextureSource;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/TextureMatrix.mjs
var tempMat = new Matrix();
var TextureMatrix = class {
	/**
	* @param texture - observed texture
	* @param clampMargin - Changes frame clamping, 0.5 by default. Use -0.5 for extra border.
	*/
	constructor(texture, clampMargin) {
		this.mapCoord = new Matrix();
		this.uClampFrame = /* @__PURE__ */ new Float32Array(4);
		this.uClampOffset = /* @__PURE__ */ new Float32Array(2);
		this._updateID = 0;
		this.clampOffset = 0;
		if (typeof clampMargin === "undefined") this.clampMargin = texture.width < 10 ? 0 : .5;
		else this.clampMargin = clampMargin;
		this.isSimple = false;
		this.texture = texture;
	}
	/** Texture property. */
	get texture() {
		return this._texture;
	}
	set texture(value) {
		if (this._texture !== value) {
			this._texture?.removeListener("update", this.update, this);
			this._texture = value;
			this._texture.addListener("update", this.update, this);
		}
		this.update();
	}
	/** Releases the observed texture, removing the `update` listener from it. */
	destroy() {
		this._texture?.removeListener("update", this.update, this);
		this._texture = null;
	}
	/**
	* Multiplies uvs array to transform
	* @param uvs - mesh uvs
	* @param [out=uvs] - output
	* @returns - output
	*/
	multiplyUvs(uvs, out) {
		if (out === void 0) out = uvs;
		const mat = this.mapCoord;
		for (let i = 0; i < uvs.length; i += 2) {
			const x = uvs[i];
			const y = uvs[i + 1];
			out[i] = x * mat.a + y * mat.c + mat.tx;
			out[i + 1] = x * mat.b + y * mat.d + mat.ty;
		}
		return out;
	}
	/**
	* Updates matrices if texture was changed
	* @returns - whether or not it was updated
	*/
	update() {
		const tex = this._texture;
		this._updateID++;
		const uvs = tex.uvs;
		this.mapCoord.set(uvs.x1 - uvs.x0, uvs.y1 - uvs.y0, uvs.x3 - uvs.x0, uvs.y3 - uvs.y0, uvs.x0, uvs.y0);
		const orig = tex.orig;
		const trim = tex.trim;
		if (trim) {
			tempMat.set(orig.width / trim.width, 0, 0, orig.height / trim.height, -trim.x / trim.width, -trim.y / trim.height);
			this.mapCoord.append(tempMat);
		}
		const texBase = tex.source;
		const frame = this.uClampFrame;
		const margin = this.clampMargin / texBase._resolution;
		const offset = this.clampOffset / texBase._resolution;
		frame[0] = (tex.frame.x + margin + offset) / texBase.width;
		frame[1] = (tex.frame.y + margin + offset) / texBase.height;
		frame[2] = (tex.frame.x + tex.frame.width - margin + offset) / texBase.width;
		frame[3] = (tex.frame.y + tex.frame.height - margin + offset) / texBase.height;
		this.uClampOffset[0] = this.clampOffset / texBase.pixelWidth;
		this.uClampOffset[1] = this.clampOffset / texBase.pixelHeight;
		this.isSimple = tex.frame.width === texBase.width && tex.frame.height === texBase.height && tex.rotate === 0;
		return true;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/Texture.mjs
var Texture = class extends eventemitter3_default {
	/**
	* @param {TextureOptions} options - Options for the texture
	*/
	constructor({ source, label, frame, orig, trim, defaultAnchor, defaultBorders, rotate, dynamic } = {}) {
		super();
		/** unique id for this texture */
		this.uid = uid("texture");
		/** A uvs object based on the given frame and the texture source */
		this.uvs = {
			x0: 0,
			y0: 0,
			x1: 0,
			y1: 0,
			x2: 0,
			y2: 0,
			x3: 0,
			y3: 0
		};
		/**
		* This is the area of the BaseTexture image to actually copy to the Canvas / WebGL when rendering,
		* irrespective of the actual frame size or placement (which can be influenced by trimmed texture atlases)
		*/
		this.frame = new Rectangle();
		/**
		* Does this Texture have any frame data assigned to it?
		*
		* This mode is enabled automatically if no frame was passed inside constructor.
		*
		* In this mode texture is subscribed to baseTexture events, and fires `update` on any change.
		*
		* Beware, after loading or resize of baseTexture event can fired two times!
		* If you want more control, subscribe on baseTexture itself.
		* @example
		* texture.on('update', () => {});
		*/
		this.noFrame = false;
		/**
		* Set to true if you plan on modifying the uvs of this texture.
		* When this is the case, sprites and other objects using the texture will
		* make sure to listen for changes to the uvs and update their vertices accordingly.
		*/
		this.dynamic = false;
		/** is it a texture? yes! used for type checking */
		this.isTexture = true;
		this.label = label;
		this.source = source?.source ?? new TextureSource();
		this.noFrame = !frame;
		if (frame) this.frame.copyFrom(frame);
		else {
			const { width, height } = this._source;
			this.frame.width = width;
			this.frame.height = height;
		}
		this.orig = orig || this.frame;
		this.trim = trim;
		this.rotate = rotate ?? 0;
		this.defaultAnchor = defaultAnchor;
		this.defaultBorders = defaultBorders;
		this.destroyed = false;
		this.dynamic = dynamic || false;
		this.updateUvs();
	}
	set source(value) {
		if (this._source) this._source.off("resize", this.update, this);
		this._source = value;
		value.on("resize", this.update, this);
		this.emit("update", this);
	}
	/** the underlying source of the texture (equivalent of baseTexture in v7) */
	get source() {
		return this._source;
	}
	/** returns a TextureMatrix instance for this texture. By default, that object is not created because its heavy. */
	get textureMatrix() {
		if (!this._textureMatrix) this._textureMatrix = new TextureMatrix(this);
		return this._textureMatrix;
	}
	/** The width of the Texture in pixels. */
	get width() {
		return this.orig.width;
	}
	/** The height of the Texture in pixels. */
	get height() {
		return this.orig.height;
	}
	/** Call this function when you have modified the frame of this texture. */
	updateUvs() {
		const { uvs, frame } = this;
		const { width, height } = this._source;
		const nX = frame.x / width;
		const nY = frame.y / height;
		const nW = frame.width / width;
		const nH = frame.height / height;
		let rotate = this.rotate;
		if (rotate) {
			const w2 = nW / 2;
			const h2 = nH / 2;
			const cX = nX + w2;
			const cY = nY + h2;
			rotate = groupD8.add(rotate, groupD8.NW);
			uvs.x0 = cX + w2 * groupD8.uX(rotate);
			uvs.y0 = cY + h2 * groupD8.uY(rotate);
			rotate = groupD8.add(rotate, 2);
			uvs.x1 = cX + w2 * groupD8.uX(rotate);
			uvs.y1 = cY + h2 * groupD8.uY(rotate);
			rotate = groupD8.add(rotate, 2);
			uvs.x2 = cX + w2 * groupD8.uX(rotate);
			uvs.y2 = cY + h2 * groupD8.uY(rotate);
			rotate = groupD8.add(rotate, 2);
			uvs.x3 = cX + w2 * groupD8.uX(rotate);
			uvs.y3 = cY + h2 * groupD8.uY(rotate);
		} else {
			uvs.x0 = nX;
			uvs.y0 = nY;
			uvs.x1 = nX + nW;
			uvs.y1 = nY;
			uvs.x2 = nX + nW;
			uvs.y2 = nY + nH;
			uvs.x3 = nX;
			uvs.y3 = nY + nH;
		}
	}
	/**
	* Destroys this texture
	* @param destroySource - Destroy the source when the texture is destroyed.
	*/
	destroy(destroySource = false) {
		if (this._source) {
			this._source.off("resize", this.update, this);
			if (destroySource) {
				this._source.destroy();
				this._source = null;
			}
		}
		this._textureMatrix = null;
		this.destroyed = true;
		this.emit("destroy", this);
		this.removeAllListeners();
	}
	/**
	* Call this if you have modified the `texture outside` of the constructor.
	*
	* If you have modified this texture's source, you must separately call `texture.source.update()` to see those changes.
	*/
	update() {
		if (this.noFrame) {
			this.frame.width = this._source.width;
			this.frame.height = this._source.height;
		}
		this.updateUvs();
		this.emit("update", this);
	}
	/** @deprecated since 8.0.0 */
	get baseTexture() {
		deprecation(v8_0_0, "Texture.baseTexture is now Texture.source");
		return this._source;
	}
};
Texture.EMPTY = new Texture({
	label: "EMPTY",
	source: new TextureSource({ label: "EMPTY" })
});
Texture.EMPTY.destroy = NOOP;
Texture.WHITE = new Texture({
	source: new BufferImageSource({
		resource: new Uint8Array([
			255,
			255,
			255,
			255
		]),
		width: 1,
		height: 1,
		alphaMode: "premultiply-alpha-on-upload",
		label: "WHITE"
	}),
	label: "WHITE"
});
Texture.WHITE.destroy = NOOP;
//#endregion
//#region node_modules/pixi.js/lib/scene/container/bounds/Bounds.mjs
var defaultMatrix = new Matrix();
var Bounds = class Bounds {
	/**
	* Creates a new Bounds object.
	* @param minX - The minimum X coordinate of the bounds.
	* @param minY - The minimum Y coordinate of the bounds.
	* @param maxX - The maximum X coordinate of the bounds.
	* @param maxY - The maximum Y coordinate of the bounds.
	*/
	constructor(minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity) {
		/**
		* The minimum X coordinate of the bounds.
		* Represents the leftmost edge of the bounding box.
		* @example
		* ```ts
		* const bounds = new Bounds();
		* // Set left edge
		* bounds.minX = 100;
		* ```
		* @default Infinity
		*/
		this.minX = Infinity;
		/**
		* The minimum Y coordinate of the bounds.
		* Represents the topmost edge of the bounding box.
		* @example
		* ```ts
		* const bounds = new Bounds();
		* // Set top edge
		* bounds.minY = 100;
		* ```
		* @default Infinity
		*/
		this.minY = Infinity;
		/**
		* The maximum X coordinate of the bounds.
		* Represents the rightmost edge of the bounding box.
		* @example
		* ```ts
		* const bounds = new Bounds();
		* // Set right edge
		* bounds.maxX = 200;
		* // Get width
		* const width = bounds.maxX - bounds.minX;
		* ```
		* @default -Infinity
		*/
		this.maxX = -Infinity;
		/**
		* The maximum Y coordinate of the bounds.
		* Represents the bottommost edge of the bounding box.
		* @example
		* ```ts
		* const bounds = new Bounds();
		* // Set bottom edge
		* bounds.maxY = 200;
		* // Get height
		* const height = bounds.maxY - bounds.minY;
		* ```
		* @default -Infinity
		*/
		this.maxY = -Infinity;
		/**
		* The transformation matrix applied to this bounds object.
		* Used when calculating bounds with transforms.
		* @example
		* ```ts
		* const bounds = new Bounds();
		*
		* // Apply translation matrix
		* bounds.matrix = new Matrix()
		*     .translate(100, 100);
		*
		* // Combine transformations
		* bounds.matrix = new Matrix()
		*     .translate(50, 50)
		*     .rotate(Math.PI / 4)
		*     .scale(2, 2);
		*
		* // Use in bounds calculations
		* bounds.addFrame(0, 0, 100, 100); // Uses current matrix
		* bounds.addFrame(0, 0, 100, 100, customMatrix); // Override matrix
		* ```
		* @advanced
		*/
		this.matrix = defaultMatrix;
		this.minX = minX;
		this.minY = minY;
		this.maxX = maxX;
		this.maxY = maxY;
	}
	/**
	* Checks if bounds are empty, meaning either width or height is zero or negative.
	* Empty bounds occur when min values exceed max values on either axis.
	* @example
	* ```ts
	* const bounds = new Bounds();
	*
	* // Check if newly created bounds are empty
	* console.log(bounds.isEmpty()); // true, default bounds are empty
	*
	* // Add frame and check again
	* bounds.addFrame(0, 0, 100, 100);
	* console.log(bounds.isEmpty()); // false, bounds now have area
	*
	* // Clear bounds
	* bounds.clear();
	* console.log(bounds.isEmpty()); // true, bounds are empty again
	* ```
	* @returns True if bounds are empty (have no area)
	* @see {@link Bounds#clear} For resetting bounds
	* @see {@link Bounds#isValid} For checking validity
	*/
	isEmpty() {
		return this.minX > this.maxX || this.minY > this.maxY;
	}
	/**
	* The bounding rectangle representation of these bounds.
	* Lazily creates and updates a Rectangle instance based on the current bounds.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	*
	* // Get rectangle representation
	* const rect = bounds.rectangle;
	* console.log(rect.x, rect.y, rect.width, rect.height);
	*
	* // Use for hit testing
	* if (bounds.rectangle.contains(mouseX, mouseY)) {
	*     console.log('Mouse is inside bounds!');
	* }
	* ```
	* @see {@link Rectangle} For rectangle methods
	* @see {@link Bounds.isEmpty} For bounds validation
	*/
	get rectangle() {
		if (!this._rectangle) this._rectangle = new Rectangle();
		const rectangle = this._rectangle;
		if (this.minX > this.maxX || this.minY > this.maxY) {
			rectangle.x = 0;
			rectangle.y = 0;
			rectangle.width = 0;
			rectangle.height = 0;
		} else rectangle.copyFromBounds(this);
		return rectangle;
	}
	/**
	* Clears the bounds and resets all coordinates to their default values.
	* Resets the transformation matrix back to identity.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* console.log(bounds.isEmpty()); // false
	* // Clear the bounds
	* bounds.clear();
	* console.log(bounds.isEmpty()); // true
	* ```
	* @returns This bounds object for chaining
	*/
	clear() {
		this.minX = Infinity;
		this.minY = Infinity;
		this.maxX = -Infinity;
		this.maxY = -Infinity;
		this.matrix = defaultMatrix;
		return this;
	}
	/**
	* Sets the bounds directly using coordinate values.
	* Provides a way to set all bounds values at once.
	* @example
	* ```ts
	* const bounds = new Bounds();
	* bounds.set(0, 0, 100, 100);
	* ```
	* @param x0 - Left X coordinate of frame
	* @param y0 - Top Y coordinate of frame
	* @param x1 - Right X coordinate of frame
	* @param y1 - Bottom Y coordinate of frame
	* @see {@link Bounds#addFrame} For matrix-aware bounds setting
	* @see {@link Bounds#clear} For resetting bounds
	*/
	set(x0, y0, x1, y1) {
		this.minX = x0;
		this.minY = y0;
		this.maxX = x1;
		this.maxY = y1;
	}
	/**
	* Adds a rectangular frame to the bounds, optionally transformed by a matrix.
	* Updates the bounds to encompass the new frame coordinates.
	* @example
	* ```ts
	* const bounds = new Bounds();
	* bounds.addFrame(0, 0, 100, 100);
	*
	* // Add transformed frame
	* const matrix = new Matrix()
	*     .translate(50, 50)
	*     .rotate(Math.PI / 4);
	* bounds.addFrame(0, 0, 100, 100, matrix);
	* ```
	* @param x0 - Left X coordinate of frame
	* @param y0 - Top Y coordinate of frame
	* @param x1 - Right X coordinate of frame
	* @param y1 - Bottom Y coordinate of frame
	* @param matrix - Optional transformation matrix
	* @see {@link Bounds#addRect} For adding Rectangle objects
	* @see {@link Bounds#addBounds} For adding other Bounds
	*/
	addFrame(x0, y0, x1, y1, matrix) {
		matrix || (matrix = this.matrix);
		const a = matrix.a;
		const b = matrix.b;
		const c = matrix.c;
		const d = matrix.d;
		const tx = matrix.tx;
		const ty = matrix.ty;
		let minX = this.minX;
		let minY = this.minY;
		let maxX = this.maxX;
		let maxY = this.maxY;
		let x = a * x0 + c * y0 + tx;
		let y = b * x0 + d * y0 + ty;
		if (x < minX) minX = x;
		if (y < minY) minY = y;
		if (x > maxX) maxX = x;
		if (y > maxY) maxY = y;
		x = a * x1 + c * y0 + tx;
		y = b * x1 + d * y0 + ty;
		if (x < minX) minX = x;
		if (y < minY) minY = y;
		if (x > maxX) maxX = x;
		if (y > maxY) maxY = y;
		x = a * x0 + c * y1 + tx;
		y = b * x0 + d * y1 + ty;
		if (x < minX) minX = x;
		if (y < minY) minY = y;
		if (x > maxX) maxX = x;
		if (y > maxY) maxY = y;
		x = a * x1 + c * y1 + tx;
		y = b * x1 + d * y1 + ty;
		if (x < minX) minX = x;
		if (y < minY) minY = y;
		if (x > maxX) maxX = x;
		if (y > maxY) maxY = y;
		this.minX = minX;
		this.minY = minY;
		this.maxX = maxX;
		this.maxY = maxY;
	}
	/**
	* Adds a rectangle to the bounds, optionally transformed by a matrix.
	* Updates the bounds to encompass the given rectangle.
	* @example
	* ```ts
	* const bounds = new Bounds();
	* // Add simple rectangle
	* const rect = new Rectangle(0, 0, 100, 100);
	* bounds.addRect(rect);
	*
	* // Add transformed rectangle
	* const matrix = new Matrix()
	*     .translate(50, 50)
	*     .rotate(Math.PI / 4);
	* bounds.addRect(rect, matrix);
	* ```
	* @param rect - The rectangle to be added
	* @param matrix - Optional transformation matrix
	* @see {@link Bounds#addFrame} For adding raw coordinates
	* @see {@link Bounds#addBounds} For adding other bounds
	*/
	addRect(rect, matrix) {
		this.addFrame(rect.x, rect.y, rect.x + rect.width, rect.y + rect.height, matrix);
	}
	/**
	* Adds another bounds object to this one, optionally transformed by a matrix.
	* Expands the bounds to include the given bounds' area.
	* @example
	* ```ts
	* const bounds = new Bounds();
	*
	* // Add child bounds
	* const childBounds = sprite.getBounds();
	* bounds.addBounds(childBounds);
	*
	* // Add transformed bounds
	* const matrix = new Matrix()
	*     .scale(2, 2);
	* bounds.addBounds(childBounds, matrix);
	* ```
	* @param bounds - The bounds to be added
	* @param matrix - Optional transformation matrix
	* @see {@link Bounds#addFrame} For adding raw coordinates
	* @see {@link Bounds#addRect} For adding rectangles
	*/
	addBounds(bounds, matrix) {
		this.addFrame(bounds.minX, bounds.minY, bounds.maxX, bounds.maxY, matrix);
	}
	/**
	* Adds other Bounds as a mask, creating an intersection of the two bounds.
	* Only keeps the overlapping region between current bounds and mask bounds.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* // Create mask bounds
	* const mask = new Bounds();
	* mask.addFrame(50, 50, 150, 150);
	* // Apply mask - results in bounds of (50,50,100,100)
	* bounds.addBoundsMask(mask);
	* ```
	* @param mask - The Bounds to use as a mask
	* @see {@link Bounds#addBounds} For union operation
	* @see {@link Bounds#fit} For fitting to rectangle
	*/
	addBoundsMask(mask) {
		this.minX = this.minX > mask.minX ? this.minX : mask.minX;
		this.minY = this.minY > mask.minY ? this.minY : mask.minY;
		this.maxX = this.maxX < mask.maxX ? this.maxX : mask.maxX;
		this.maxY = this.maxY < mask.maxY ? this.maxY : mask.maxY;
	}
	/**
	* Applies a transformation matrix to the bounds, updating its coordinates.
	* Transforms all corners of the bounds using the given matrix.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* // Apply translation
	* const translateMatrix = new Matrix()
	*     .translate(50, 50);
	* bounds.applyMatrix(translateMatrix);
	* ```
	* @param matrix - The matrix to apply to the bounds
	* @see {@link Matrix} For matrix operations
	* @see {@link Bounds#addFrame} For adding transformed frames
	*/
	applyMatrix(matrix) {
		const minX = this.minX;
		const minY = this.minY;
		const maxX = this.maxX;
		const maxY = this.maxY;
		const { a, b, c, d, tx, ty } = matrix;
		let x = a * minX + c * minY + tx;
		let y = b * minX + d * minY + ty;
		this.minX = x;
		this.minY = y;
		this.maxX = x;
		this.maxY = y;
		x = a * maxX + c * minY + tx;
		y = b * maxX + d * minY + ty;
		this.minX = x < this.minX ? x : this.minX;
		this.minY = y < this.minY ? y : this.minY;
		this.maxX = x > this.maxX ? x : this.maxX;
		this.maxY = y > this.maxY ? y : this.maxY;
		x = a * minX + c * maxY + tx;
		y = b * minX + d * maxY + ty;
		this.minX = x < this.minX ? x : this.minX;
		this.minY = y < this.minY ? y : this.minY;
		this.maxX = x > this.maxX ? x : this.maxX;
		this.maxY = y > this.maxY ? y : this.maxY;
		x = a * maxX + c * maxY + tx;
		y = b * maxX + d * maxY + ty;
		this.minX = x < this.minX ? x : this.minX;
		this.minY = y < this.minY ? y : this.minY;
		this.maxX = x > this.maxX ? x : this.maxX;
		this.maxY = y > this.maxY ? y : this.maxY;
	}
	/**
	* Resizes the bounds object to fit within the given rectangle.
	* Clips the bounds if they extend beyond the rectangle's edges.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 200, 200);
	* // Fit within viewport
	* const viewport = new Rectangle(50, 50, 100, 100);
	* bounds.fit(viewport);
	* // bounds are now (50, 50, 150, 150)
	* ```
	* @param rect - The rectangle to fit within
	* @returns This bounds object for chaining
	* @see {@link Bounds#addBoundsMask} For intersection
	* @see {@link Bounds#pad} For expanding bounds
	*/
	fit(rect) {
		if (this.minX < rect.left) this.minX = rect.left;
		if (this.maxX > rect.right) this.maxX = rect.right;
		if (this.minY < rect.top) this.minY = rect.top;
		if (this.maxY > rect.bottom) this.maxY = rect.bottom;
		return this;
	}
	/**
	* Resizes the bounds object to include the given bounds.
	* Similar to fit() but works with raw coordinate values instead of a Rectangle.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 200, 200);
	* // Fit to specific coordinates
	* bounds.fitBounds(50, 150, 50, 150);
	* // bounds are now (50, 50, 150, 150)
	* ```
	* @param left - The left value of the bounds
	* @param right - The right value of the bounds
	* @param top - The top value of the bounds
	* @param bottom - The bottom value of the bounds
	* @returns This bounds object for chaining
	* @see {@link Bounds#fit} For fitting to Rectangle
	* @see {@link Bounds#addBoundsMask} For intersection
	*/
	fitBounds(left, right, top, bottom) {
		if (this.minX < left) this.minX = left;
		if (this.maxX > right) this.maxX = right;
		if (this.minY < top) this.minY = top;
		if (this.maxY > bottom) this.maxY = bottom;
		return this;
	}
	/**
	* Pads bounds object, making it grow in all directions.
	* If paddingY is omitted, both paddingX and paddingY will be set to paddingX.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	*
	* // Add equal padding
	* bounds.pad(10);
	* // bounds are now (-10, -10, 110, 110)
	*
	* // Add different padding for x and y
	* bounds.pad(20, 10);
	* // bounds are now (-30, -20, 130, 120)
	* ```
	* @param paddingX - The horizontal padding amount
	* @param paddingY - The vertical padding amount
	* @returns This bounds object for chaining
	* @see {@link Bounds#fit} For constraining bounds
	* @see {@link Bounds#scale} For uniform scaling
	*/
	pad(paddingX, paddingY = paddingX) {
		this.minX -= paddingX;
		this.maxX += paddingX;
		this.minY -= paddingY;
		this.maxY += paddingY;
		return this;
	}
	/**
	* Ceils the bounds by rounding up max values and rounding down min values.
	* Useful for pixel-perfect calculations and avoiding fractional pixels.
	* @example
	* ```ts
	* const bounds = new Bounds();
	* bounds.set(10.2, 10.9, 50.1, 50.8);
	*
	* // Round to whole pixels
	* bounds.ceil();
	* // bounds are now (10, 10, 51, 51)
	* ```
	* @returns This bounds object for chaining
	* @see {@link Bounds#scale} For size adjustments
	* @see {@link Bounds#fit} For constraining bounds
	*/
	ceil() {
		this.minX = Math.floor(this.minX);
		this.minY = Math.floor(this.minY);
		this.maxX = Math.ceil(this.maxX);
		this.maxY = Math.ceil(this.maxY);
		return this;
	}
	/**
	* Creates a new Bounds instance with the same values.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	*
	* // Create a copy
	* const copy = bounds.clone();
	*
	* // Original and copy are independent
	* bounds.pad(10);
	* console.log(copy.width === bounds.width); // false
	* ```
	* @returns A new Bounds instance with the same values
	* @see {@link Bounds#copyFrom} For reusing existing bounds
	*/
	clone() {
		return new Bounds(this.minX, this.minY, this.maxX, this.maxY);
	}
	/**
	* Scales the bounds by the given values, adjusting all edges proportionally.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	*
	* // Scale uniformly
	* bounds.scale(2);
	* // bounds are now (0, 0, 200, 200)
	*
	* // Scale non-uniformly
	* bounds.scale(0.5, 2);
	* // bounds are now (0, 0, 100, 400)
	* ```
	* @param x - The X value to scale by
	* @param y - The Y value to scale by (defaults to x)
	* @returns This bounds object for chaining
	* @see {@link Bounds#pad} For adding padding
	* @see {@link Bounds#fit} For constraining size
	*/
	scale(x, y = x) {
		this.minX *= x;
		this.minY *= y;
		this.maxX *= x;
		this.maxY *= y;
		return this;
	}
	/**
	* The x position of the bounds in local space.
	* Setting this value will move the bounds while maintaining its width.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* // Get x position
	* console.log(bounds.x); // 0
	*
	* // Move bounds horizontally
	* bounds.x = 50;
	* console.log(bounds.minX, bounds.maxX); // 50, 150
	*
	* // Width stays the same
	* console.log(bounds.width); // Still 100
	* ```
	*/
	get x() {
		return this.minX;
	}
	set x(value) {
		const width = this.maxX - this.minX;
		this.minX = value;
		this.maxX = value + width;
	}
	/**
	* The y position of the bounds in local space.
	* Setting this value will move the bounds while maintaining its height.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* // Get y position
	* console.log(bounds.y); // 0
	*
	* // Move bounds vertically
	* bounds.y = 50;
	* console.log(bounds.minY, bounds.maxY); // 50, 150
	*
	* // Height stays the same
	* console.log(bounds.height); // Still 100
	* ```
	*/
	get y() {
		return this.minY;
	}
	set y(value) {
		const height = this.maxY - this.minY;
		this.minY = value;
		this.maxY = value + height;
	}
	/**
	* The width value of the bounds.
	* Represents the distance between minX and maxX coordinates.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* // Get width
	* console.log(bounds.width); // 100
	* // Resize width
	* bounds.width = 200;
	* console.log(bounds.maxX - bounds.minX); // 200
	* ```
	*/
	get width() {
		return this.maxX - this.minX;
	}
	set width(value) {
		this.maxX = this.minX + value;
	}
	/**
	* The height value of the bounds.
	* Represents the distance between minY and maxY coordinates.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* // Get height
	* console.log(bounds.height); // 100
	* // Resize height
	* bounds.height = 150;
	* console.log(bounds.maxY - bounds.minY); // 150
	* ```
	*/
	get height() {
		return this.maxY - this.minY;
	}
	set height(value) {
		this.maxY = this.minY + value;
	}
	/**
	* The left edge coordinate of the bounds.
	* Alias for minX.
	* @example
	* ```ts
	* const bounds = new Bounds(50, 0, 150, 100);
	* console.log(bounds.left); // 50
	* console.log(bounds.left === bounds.minX); // true
	* ```
	* @readonly
	*/
	get left() {
		return this.minX;
	}
	/**
	* The right edge coordinate of the bounds.
	* Alias for maxX.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* console.log(bounds.right); // 100
	* console.log(bounds.right === bounds.maxX); // true
	* ```
	* @readonly
	*/
	get right() {
		return this.maxX;
	}
	/**
	* The top edge coordinate of the bounds.
	* Alias for minY.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 25, 100, 125);
	* console.log(bounds.top); // 25
	* console.log(bounds.top === bounds.minY); // true
	* ```
	* @readonly
	*/
	get top() {
		return this.minY;
	}
	/**
	* The bottom edge coordinate of the bounds.
	* Alias for maxY.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 200);
	* console.log(bounds.bottom); // 200
	* console.log(bounds.bottom === bounds.maxY); // true
	* ```
	* @readonly
	*/
	get bottom() {
		return this.maxY;
	}
	/**
	* Whether the bounds has positive width and height.
	* Checks if both dimensions are greater than zero.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* // Check if bounds are positive
	* console.log(bounds.isPositive); // true
	*
	* // Negative bounds
	* bounds.maxX = bounds.minX;
	* console.log(bounds.isPositive); // false, width is 0
	* ```
	* @readonly
	* @see {@link Bounds#isEmpty} For checking empty state
	* @see {@link Bounds#isValid} For checking validity
	*/
	get isPositive() {
		return this.maxX - this.minX > 0 && this.maxY - this.minY > 0;
	}
	/**
	* Whether the bounds has valid coordinates.
	* Checks if the bounds has been initialized with real values.
	* @example
	* ```ts
	* const bounds = new Bounds();
	* console.log(bounds.isValid); // false, default state
	*
	* // Set valid bounds
	* bounds.addFrame(0, 0, 100, 100);
	* console.log(bounds.isValid); // true
	* ```
	* @readonly
	* @see {@link Bounds#isEmpty} For checking empty state
	* @see {@link Bounds#isPositive} For checking dimensions
	*/
	get isValid() {
		return this.minX + this.minY !== Infinity;
	}
	/**
	* Adds vertices from a Float32Array to the bounds, optionally transformed by a matrix.
	* Used for efficiently updating bounds from raw vertex data.
	* @example
	* ```ts
	* const bounds = new Bounds();
	*
	* // Add vertices from geometry
	* const vertices = new Float32Array([
	*     0, 0,    // Vertex 1
	*     100, 0,  // Vertex 2
	*     100, 100 // Vertex 3
	* ]);
	* bounds.addVertexData(vertices, 0, 6);
	*
	* // Add transformed vertices
	* const matrix = new Matrix()
	*     .translate(50, 50)
	*     .rotate(Math.PI / 4);
	* bounds.addVertexData(vertices, 0, 6, matrix);
	*
	* // Add subset of vertices
	* bounds.addVertexData(vertices, 2, 4); // Only second vertex
	* ```
	* @param vertexData - The array of vertices to add
	* @param beginOffset - Starting index in the vertex array
	* @param endOffset - Ending index in the vertex array (excluded)
	* @param matrix - Optional transformation matrix
	* @see {@link Bounds#addFrame} For adding rectangular frames
	* @see {@link Matrix} For transformation details
	*/
	addVertexData(vertexData, beginOffset, endOffset, matrix) {
		let minX = this.minX;
		let minY = this.minY;
		let maxX = this.maxX;
		let maxY = this.maxY;
		matrix || (matrix = this.matrix);
		const a = matrix.a;
		const b = matrix.b;
		const c = matrix.c;
		const d = matrix.d;
		const tx = matrix.tx;
		const ty = matrix.ty;
		for (let i = beginOffset; i < endOffset; i += 2) {
			const localX = vertexData[i];
			const localY = vertexData[i + 1];
			const x = a * localX + c * localY + tx;
			const y = b * localX + d * localY + ty;
			minX = x < minX ? x : minX;
			minY = y < minY ? y : minY;
			maxX = x > maxX ? x : maxX;
			maxY = y > maxY ? y : maxY;
		}
		this.minX = minX;
		this.minY = minY;
		this.maxX = maxX;
		this.maxY = maxY;
	}
	/**
	* Checks if a point is contained within the bounds.
	* Returns true if the point's coordinates fall within the bounds' area.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* // Basic point check
	* console.log(bounds.containsPoint(50, 50)); // true
	* console.log(bounds.containsPoint(150, 150)); // false
	*
	* // Check edges
	* console.log(bounds.containsPoint(0, 0));   // true, includes edges
	* console.log(bounds.containsPoint(100, 100)); // true, includes edges
	* ```
	* @param x - x coordinate to check
	* @param y - y coordinate to check
	* @returns True if the point is inside the bounds
	* @see {@link Bounds#isPositive} For valid bounds check
	* @see {@link Bounds#rectangle} For Rectangle representation
	*/
	containsPoint(x, y) {
		if (this.minX <= x && this.minY <= y && this.maxX >= x && this.maxY >= y) return true;
		return false;
	}
	/**
	* Returns a string representation of the bounds.
	* Useful for debugging and logging bounds information.
	* @example
	* ```ts
	* const bounds = new Bounds(0, 0, 100, 100);
	* console.log(bounds.toString()); // "[pixi.js:Bounds minX=0 minY=0 maxX=100 maxY=100 width=100 height=100]"
	* ```
	* @returns A string describing the bounds
	* @see {@link Bounds#copyFrom} For copying bounds
	* @see {@link Bounds#clone} For creating a new instance
	*/
	toString() {
		return `[pixi.js:Bounds minX=${this.minX} minY=${this.minY} maxX=${this.maxX} maxY=${this.maxY} width=${this.width} height=${this.height}]`;
	}
	/**
	* Copies the bounds from another bounds object.
	* Useful for reusing bounds objects and avoiding allocations.
	* @example
	* ```ts
	* const sourceBounds = new Bounds(0, 0, 100, 100);
	* // Copy bounds
	* const targetBounds = new Bounds();
	* targetBounds.copyFrom(sourceBounds);
	* ```
	* @param bounds - The bounds to copy from
	* @returns This bounds object for chaining
	* @see {@link Bounds#clone} For creating new instances
	*/
	copyFrom(bounds) {
		this.minX = bounds.minX;
		this.minY = bounds.minY;
		this.maxX = bounds.maxX;
		this.maxY = bounds.maxY;
		return this;
	}
};
//#endregion
//#region node_modules/@pixi/colord/index.mjs
var r = {
	grad: .9,
	turn: 360,
	rad: 360 / (2 * Math.PI)
};
var t = function(r) {
	return "string" == typeof r ? r.length > 0 : "number" == typeof r;
};
var n = function(r, t, n) {
	return void 0 === t && (t = 0), void 0 === n && (n = Math.pow(10, t)), Math.round(n * r) / n + 0;
};
var e = function(r, t, n) {
	return void 0 === t && (t = 0), void 0 === n && (n = 1), r > n ? n : r > t ? r : t;
};
var u = function(r) {
	return (r = isFinite(r) ? r % 360 : 0) > 0 ? r : r + 360;
};
var a = function(r) {
	return {
		r: e(r.r, 0, 255),
		g: e(r.g, 0, 255),
		b: e(r.b, 0, 255),
		a: e(r.a)
	};
};
var o = function(r) {
	return {
		r: n(r.r),
		g: n(r.g),
		b: n(r.b),
		a: n(r.a, 3)
	};
};
var i = /^#([0-9a-f]{3,8})$/i;
var s = function(r) {
	var t = r.toString(16);
	return t.length < 2 ? "0" + t : t;
};
var h = function(r) {
	var t = r.r, n = r.g, e = r.b, u = r.a, a = Math.max(t, n, e), o = a - Math.min(t, n, e), i = o ? a === t ? (n - e) / o : a === n ? 2 + (e - t) / o : 4 + (t - n) / o : 0;
	return {
		h: 60 * (i < 0 ? i + 6 : i),
		s: a ? o / a * 100 : 0,
		v: a / 255 * 100,
		a: u
	};
};
var b = function(r) {
	var t = r.h, n = r.s, e = r.v, u = r.a;
	t = t / 360 * 6, n /= 100, e /= 100;
	var a = Math.floor(t), o = e * (1 - n), i = e * (1 - (t - a) * n), s = e * (1 - (1 - t + a) * n), h = a % 6;
	return {
		r: 255 * [
			e,
			i,
			o,
			o,
			s,
			e
		][h],
		g: 255 * [
			s,
			e,
			e,
			i,
			o,
			o
		][h],
		b: 255 * [
			o,
			o,
			s,
			e,
			e,
			i
		][h],
		a: u
	};
};
var g = function(r) {
	return {
		h: u(r.h),
		s: e(r.s, 0, 100),
		l: e(r.l, 0, 100),
		a: e(r.a)
	};
};
var d = function(r) {
	return {
		h: n(r.h),
		s: n(r.s),
		l: n(r.l),
		a: n(r.a, 3)
	};
};
var f = function(r) {
	return b((n = (t = r).s, {
		h: t.h,
		s: (n *= ((e = t.l) < 50 ? e : 100 - e) / 100) > 0 ? 2 * n / (e + n) * 100 : 0,
		v: e + n,
		a: t.a
	}));
	var t, n, e;
};
var c = function(r) {
	return {
		h: (t = h(r)).h,
		s: (u = (200 - (n = t.s)) * (e = t.v) / 100) > 0 && u < 200 ? n * e / 100 / (u <= 100 ? u : 200 - u) * 100 : 0,
		l: u / 2,
		a: t.a
	};
	var t, n, e, u;
};
var l = /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s*,\s*([+-]?\d*\.?\d+)%\s*,\s*([+-]?\d*\.?\d+)%\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i;
var p = /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s+([+-]?\d*\.?\d+)%\s+([+-]?\d*\.?\d+)%\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i;
var v = /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i;
var m = /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i;
var y = {
	string: [
		[function(r) {
			var t = i.exec(r);
			return t ? (r = t[1]).length <= 4 ? {
				r: parseInt(r[0] + r[0], 16),
				g: parseInt(r[1] + r[1], 16),
				b: parseInt(r[2] + r[2], 16),
				a: 4 === r.length ? n(parseInt(r[3] + r[3], 16) / 255, 2) : 1
			} : 6 === r.length || 8 === r.length ? {
				r: parseInt(r.substr(0, 2), 16),
				g: parseInt(r.substr(2, 2), 16),
				b: parseInt(r.substr(4, 2), 16),
				a: 8 === r.length ? n(parseInt(r.substr(6, 2), 16) / 255, 2) : 1
			} : null : null;
		}, "hex"],
		[function(r) {
			var t = v.exec(r) || m.exec(r);
			return t ? t[2] !== t[4] || t[4] !== t[6] ? null : a({
				r: Number(t[1]) / (t[2] ? 100 / 255 : 1),
				g: Number(t[3]) / (t[4] ? 100 / 255 : 1),
				b: Number(t[5]) / (t[6] ? 100 / 255 : 1),
				a: void 0 === t[7] ? 1 : Number(t[7]) / (t[8] ? 100 : 1)
			}) : null;
		}, "rgb"],
		[function(t) {
			var n = l.exec(t) || p.exec(t);
			if (!n) return null;
			var e, u;
			return f(g({
				h: (e = n[1], u = n[2], void 0 === u && (u = "deg"), Number(e) * (r[u] || 1)),
				s: Number(n[3]),
				l: Number(n[4]),
				a: void 0 === n[5] ? 1 : Number(n[5]) / (n[6] ? 100 : 1)
			}));
		}, "hsl"]
	],
	object: [
		[function(r) {
			var n = r.r, e = r.g, u = r.b, o = r.a, i = void 0 === o ? 1 : o;
			return t(n) && t(e) && t(u) ? a({
				r: Number(n),
				g: Number(e),
				b: Number(u),
				a: Number(i)
			}) : null;
		}, "rgb"],
		[function(r) {
			var n = r.h, e = r.s, u = r.l, a = r.a, o = void 0 === a ? 1 : a;
			if (!t(n) || !t(e) || !t(u)) return null;
			return f(g({
				h: Number(n),
				s: Number(e),
				l: Number(u),
				a: Number(o)
			}));
		}, "hsl"],
		[function(r) {
			var n = r.h, a = r.s, o = r.v, i = r.a, s = void 0 === i ? 1 : i;
			if (!t(n) || !t(a) || !t(o)) return null;
			return b(function(r) {
				return {
					h: u(r.h),
					s: e(r.s, 0, 100),
					v: e(r.v, 0, 100),
					a: e(r.a)
				};
			}({
				h: Number(n),
				s: Number(a),
				v: Number(o),
				a: Number(s)
			}));
		}, "hsv"]
	]
};
var N = function(r, t) {
	for (var n = 0; n < t.length; n++) {
		var e = t[n][0](r);
		if (e) return [e, t[n][1]];
	}
	return [null, void 0];
};
var x = function(r) {
	return "string" == typeof r ? N(r.trim(), y.string) : "object" == typeof r && null !== r ? N(r, y.object) : [null, void 0];
};
var M = function(r, t) {
	var n = c(r);
	return {
		h: n.h,
		s: e(n.s + 100 * t, 0, 100),
		l: n.l,
		a: n.a
	};
};
var H = function(r) {
	return (299 * r.r + 587 * r.g + 114 * r.b) / 1e3 / 255;
};
var $ = function(r, t) {
	var n = c(r);
	return {
		h: n.h,
		s: n.s,
		l: e(n.l + 100 * t, 0, 100),
		a: n.a
	};
};
var j = function() {
	function r(r) {
		this.parsed = x(r)[0], this.rgba = this.parsed || {
			r: 0,
			g: 0,
			b: 0,
			a: 1
		};
	}
	return r.prototype.isValid = function() {
		return null !== this.parsed;
	}, r.prototype.brightness = function() {
		return n(H(this.rgba), 2);
	}, r.prototype.isDark = function() {
		return H(this.rgba) < .5;
	}, r.prototype.isLight = function() {
		return H(this.rgba) >= .5;
	}, r.prototype.toHex = function() {
		return r = o(this.rgba), t = r.r, e = r.g, u = r.b, i = (a = r.a) < 1 ? s(n(255 * a)) : "", "#" + s(t) + s(e) + s(u) + i;
		var r, t, e, u, a, i;
	}, r.prototype.toRgb = function() {
		return o(this.rgba);
	}, r.prototype.toRgbString = function() {
		return r = o(this.rgba), t = r.r, n = r.g, e = r.b, (u = r.a) < 1 ? "rgba(" + t + ", " + n + ", " + e + ", " + u + ")" : "rgb(" + t + ", " + n + ", " + e + ")";
		var r, t, n, e, u;
	}, r.prototype.toHsl = function() {
		return d(c(this.rgba));
	}, r.prototype.toHslString = function() {
		return r = d(c(this.rgba)), t = r.h, n = r.s, e = r.l, (u = r.a) < 1 ? "hsla(" + t + ", " + n + "%, " + e + "%, " + u + ")" : "hsl(" + t + ", " + n + "%, " + e + "%)";
		var r, t, n, e, u;
	}, r.prototype.toHsv = function() {
		return r = h(this.rgba), {
			h: n(r.h),
			s: n(r.s),
			v: n(r.v),
			a: n(r.a, 3)
		};
		var r;
	}, r.prototype.invert = function() {
		return w({
			r: 255 - (r = this.rgba).r,
			g: 255 - r.g,
			b: 255 - r.b,
			a: r.a
		});
		var r;
	}, r.prototype.saturate = function(r) {
		return void 0 === r && (r = .1), w(M(this.rgba, r));
	}, r.prototype.desaturate = function(r) {
		return void 0 === r && (r = .1), w(M(this.rgba, -r));
	}, r.prototype.grayscale = function() {
		return w(M(this.rgba, -1));
	}, r.prototype.lighten = function(r) {
		return void 0 === r && (r = .1), w($(this.rgba, r));
	}, r.prototype.darken = function(r) {
		return void 0 === r && (r = .1), w($(this.rgba, -r));
	}, r.prototype.rotate = function(r) {
		return void 0 === r && (r = 15), this.hue(this.hue() + r);
	}, r.prototype.alpha = function(r) {
		return "number" == typeof r ? w({
			r: (t = this.rgba).r,
			g: t.g,
			b: t.b,
			a: r
		}) : n(this.rgba.a, 3);
		var t;
	}, r.prototype.hue = function(r) {
		var t = c(this.rgba);
		return "number" == typeof r ? w({
			h: r,
			s: t.s,
			l: t.l,
			a: t.a
		}) : n(t.h);
	}, r.prototype.isEqual = function(r) {
		return this.toHex() === w(r).toHex();
	}, r;
}();
var w = function(r) {
	return r instanceof j ? r : new j(r);
};
var S = [];
var k = function(r) {
	r.forEach(function(r) {
		S.indexOf(r) < 0 && (r(j, y), S.push(r));
	});
};
//#endregion
//#region node_modules/@pixi/colord/plugins/names.mjs
function names_default(e, f) {
	var a = {
		white: "#ffffff",
		bisque: "#ffe4c4",
		blue: "#0000ff",
		cadetblue: "#5f9ea0",
		chartreuse: "#7fff00",
		chocolate: "#d2691e",
		coral: "#ff7f50",
		antiquewhite: "#faebd7",
		aqua: "#00ffff",
		azure: "#f0ffff",
		whitesmoke: "#f5f5f5",
		papayawhip: "#ffefd5",
		plum: "#dda0dd",
		blanchedalmond: "#ffebcd",
		black: "#000000",
		gold: "#ffd700",
		goldenrod: "#daa520",
		gainsboro: "#dcdcdc",
		cornsilk: "#fff8dc",
		cornflowerblue: "#6495ed",
		burlywood: "#deb887",
		aquamarine: "#7fffd4",
		beige: "#f5f5dc",
		crimson: "#dc143c",
		cyan: "#00ffff",
		darkblue: "#00008b",
		darkcyan: "#008b8b",
		darkgoldenrod: "#b8860b",
		darkkhaki: "#bdb76b",
		darkgray: "#a9a9a9",
		darkgreen: "#006400",
		darkgrey: "#a9a9a9",
		peachpuff: "#ffdab9",
		darkmagenta: "#8b008b",
		darkred: "#8b0000",
		darkorchid: "#9932cc",
		darkorange: "#ff8c00",
		darkslateblue: "#483d8b",
		gray: "#808080",
		darkslategray: "#2f4f4f",
		darkslategrey: "#2f4f4f",
		deeppink: "#ff1493",
		deepskyblue: "#00bfff",
		wheat: "#f5deb3",
		firebrick: "#b22222",
		floralwhite: "#fffaf0",
		ghostwhite: "#f8f8ff",
		darkviolet: "#9400d3",
		magenta: "#ff00ff",
		green: "#008000",
		dodgerblue: "#1e90ff",
		grey: "#808080",
		honeydew: "#f0fff0",
		hotpink: "#ff69b4",
		blueviolet: "#8a2be2",
		forestgreen: "#228b22",
		lawngreen: "#7cfc00",
		indianred: "#cd5c5c",
		indigo: "#4b0082",
		fuchsia: "#ff00ff",
		brown: "#a52a2a",
		maroon: "#800000",
		mediumblue: "#0000cd",
		lightcoral: "#f08080",
		darkturquoise: "#00ced1",
		lightcyan: "#e0ffff",
		ivory: "#fffff0",
		lightyellow: "#ffffe0",
		lightsalmon: "#ffa07a",
		lightseagreen: "#20b2aa",
		linen: "#faf0e6",
		mediumaquamarine: "#66cdaa",
		lemonchiffon: "#fffacd",
		lime: "#00ff00",
		khaki: "#f0e68c",
		mediumseagreen: "#3cb371",
		limegreen: "#32cd32",
		mediumspringgreen: "#00fa9a",
		lightskyblue: "#87cefa",
		lightblue: "#add8e6",
		midnightblue: "#191970",
		lightpink: "#ffb6c1",
		mistyrose: "#ffe4e1",
		moccasin: "#ffe4b5",
		mintcream: "#f5fffa",
		lightslategray: "#778899",
		lightslategrey: "#778899",
		navajowhite: "#ffdead",
		navy: "#000080",
		mediumvioletred: "#c71585",
		powderblue: "#b0e0e6",
		palegoldenrod: "#eee8aa",
		oldlace: "#fdf5e6",
		paleturquoise: "#afeeee",
		mediumturquoise: "#48d1cc",
		mediumorchid: "#ba55d3",
		rebeccapurple: "#663399",
		lightsteelblue: "#b0c4de",
		mediumslateblue: "#7b68ee",
		thistle: "#d8bfd8",
		tan: "#d2b48c",
		orchid: "#da70d6",
		mediumpurple: "#9370db",
		purple: "#800080",
		pink: "#ffc0cb",
		skyblue: "#87ceeb",
		springgreen: "#00ff7f",
		palegreen: "#98fb98",
		red: "#ff0000",
		yellow: "#ffff00",
		slateblue: "#6a5acd",
		lavenderblush: "#fff0f5",
		peru: "#cd853f",
		palevioletred: "#db7093",
		violet: "#ee82ee",
		teal: "#008080",
		slategray: "#708090",
		slategrey: "#708090",
		aliceblue: "#f0f8ff",
		darkseagreen: "#8fbc8f",
		darkolivegreen: "#556b2f",
		greenyellow: "#adff2f",
		seagreen: "#2e8b57",
		seashell: "#fff5ee",
		tomato: "#ff6347",
		silver: "#c0c0c0",
		sienna: "#a0522d",
		lavender: "#e6e6fa",
		lightgreen: "#90ee90",
		orange: "#ffa500",
		orangered: "#ff4500",
		steelblue: "#4682b4",
		royalblue: "#4169e1",
		turquoise: "#40e0d0",
		yellowgreen: "#9acd32",
		salmon: "#fa8072",
		saddlebrown: "#8b4513",
		sandybrown: "#f4a460",
		rosybrown: "#bc8f8f",
		darksalmon: "#e9967a",
		lightgoldenrodyellow: "#fafad2",
		snow: "#fffafa",
		lightgrey: "#d3d3d3",
		lightgray: "#d3d3d3",
		dimgray: "#696969",
		dimgrey: "#696969",
		olivedrab: "#6b8e23",
		olive: "#808000"
	}, r = {};
	for (var d in a) r[a[d]] = d;
	var l = {};
	e.prototype.toName = function(f) {
		if (!(this.rgba.a || this.rgba.r || this.rgba.g || this.rgba.b)) return "transparent";
		var d, i, n = r[this.toHex()];
		if (n) return n;
		if (null == f ? void 0 : f.closest) {
			var o = this.toRgb(), t = 1 / 0, b = "black";
			if (!l.length) for (var c in a) l[c] = new e(a[c]).toRgb();
			for (var g in a) {
				var u = (d = o, i = l[g], Math.pow(d.r - i.r, 2) + Math.pow(d.g - i.g, 2) + Math.pow(d.b - i.b, 2));
				u < t && (t = u, b = g);
			}
			return b;
		}
	};
	f.string.push([function(f) {
		var r = f.toLowerCase(), d = "transparent" === r ? "#0000" : a[r];
		return d ? new e(d).toRgb() : null;
	}, "name"]);
}
//#endregion
//#region node_modules/pixi.js/lib/color/Color.mjs
k([names_default]);
var _Color = class _Color {
	/**
	* @param {ColorSource} value - Optional value to use, if not provided, white is used.
	*/
	constructor(value = 16777215) {
		this._value = null;
		this._components = /* @__PURE__ */ new Float32Array(4);
		this._components.fill(1);
		this._int = 16777215;
		this.value = value;
	}
	/**
	* Get the red component of the color, normalized between 0 and 1.
	* @example
	* ```ts
	* const color = new Color('red');
	* console.log(color.red); // 1
	*
	* const green = new Color('#00ff00');
	* console.log(green.red); // 0
	* ```
	*/
	get red() {
		return this._components[0];
	}
	/**
	* Get the green component of the color, normalized between 0 and 1.
	* @example
	* ```ts
	* const color = new Color('lime');
	* console.log(color.green); // 1
	*
	* const red = new Color('#ff0000');
	* console.log(red.green); // 0
	* ```
	*/
	get green() {
		return this._components[1];
	}
	/**
	* Get the blue component of the color, normalized between 0 and 1.
	* @example
	* ```ts
	* const color = new Color('blue');
	* console.log(color.blue); // 1
	*
	* const yellow = new Color('#ffff00');
	* console.log(yellow.blue); // 0
	* ```
	*/
	get blue() {
		return this._components[2];
	}
	/**
	* Get the alpha component of the color, normalized between 0 and 1.
	* @example
	* ```ts
	* const color = new Color('red');
	* console.log(color.alpha); // 1 (fully opaque)
	*
	* const transparent = new Color('rgba(255, 0, 0, 0.5)');
	* console.log(transparent.alpha); // 0.5 (semi-transparent)
	* ```
	*/
	get alpha() {
		return this._components[3];
	}
	/**
	* Sets the color value and returns the instance for chaining.
	*
	* This is a chainable version of setting the `value` property.
	* @param value - The color to set. Accepts various formats:
	* - Hex strings/numbers (e.g., '#ff0000', 0xff0000)
	* - RGB/RGBA values (arrays, objects)
	* - CSS color names
	* - HSL/HSLA values
	* - HSV/HSVA values
	* @returns The Color instance for chaining
	* @example
	* ```ts
	* // Basic usage
	* const color = new Color();
	* color.setValue('#ff0000')
	*     .setAlpha(0.5)
	*     .premultiply(0.8);
	*
	* // Different formats
	* color.setValue(0xff0000);          // Hex number
	* color.setValue('#ff0000');         // Hex string
	* color.setValue([1, 0, 0]);         // RGB array
	* color.setValue([1, 0, 0, 0.5]);    // RGBA array
	* color.setValue({ r: 1, g: 0, b: 0 }); // RGB object
	*
	* // Copy from another color
	* const red = new Color('red');
	* color.setValue(red);
	* ```
	* @throws {Error} If the color value is invalid or null
	* @see {@link Color.value} For the underlying value property
	*/
	setValue(value) {
		this.value = value;
		return this;
	}
	/**
	* The current color source. This property allows getting and setting the color value
	* while preserving the original format where possible.
	* @remarks
	* When setting:
	* - Setting to a `Color` instance copies its source and components
	* - Setting to other valid sources normalizes and stores the value
	* - Setting to `null` throws an Error
	* - The color remains unchanged if normalization fails
	*
	* When getting:
	* - Returns `null` if color was modified by {@link Color.multiply} or {@link Color.premultiply}
	* - Otherwise returns the original color source
	* @example
	* ```ts
	* // Setting different color formats
	* const color = new Color();
	*
	* color.value = 0xff0000;         // Hex number
	* color.value = '#ff0000';        // Hex string
	* color.value = [1, 0, 0];        // RGB array
	* color.value = [1, 0, 0, 0.5];   // RGBA array
	* color.value = { r: 1, g: 0, b: 0 }; // RGB object
	*
	* // Copying from another color
	* const red = new Color('red');
	* color.value = red;  // Copies red's components
	*
	* // Getting the value
	* console.log(color.value);  // Returns original format
	*
	* // After modifications
	* color.multiply([0.5, 0.5, 0.5]);
	* console.log(color.value);  // Returns null
	* ```
	* @throws {Error} When attempting to set `null`
	*/
	set value(value) {
		if (value instanceof _Color) {
			this._value = this._cloneSource(value._value);
			this._int = value._int;
			this._components.set(value._components);
		} else if (value === null) throw new Error("Cannot set Color#value to null");
		else if (this._value === null || !this._isSourceEqual(this._value, value)) {
			this._value = this._cloneSource(value);
			this._normalize(this._value);
		}
	}
	get value() {
		return this._value;
	}
	/**
	* Copy a color source internally.
	* @param value - Color source
	*/
	_cloneSource(value) {
		if (typeof value === "string" || typeof value === "number" || value instanceof Number || value === null) return value;
		else if (Array.isArray(value) || ArrayBuffer.isView(value)) return value.slice(0);
		else if (typeof value === "object" && value !== null) return { ...value };
		return value;
	}
	/**
	* Equality check for color sources.
	* @param value1 - First color source
	* @param value2 - Second color source
	* @returns `true` if the color sources are equal, `false` otherwise.
	*/
	_isSourceEqual(value1, value2) {
		const type1 = typeof value1;
		if (type1 !== typeof value2) return false;
		else if (type1 === "number" || type1 === "string" || value1 instanceof Number) return value1 === value2;
		else if (Array.isArray(value1) && Array.isArray(value2) || ArrayBuffer.isView(value1) && ArrayBuffer.isView(value2)) {
			if (value1.length !== value2.length) return false;
			return value1.every((v, i) => v === value2[i]);
		} else if (value1 !== null && value2 !== null) {
			const keys1 = Object.keys(value1);
			const keys2 = Object.keys(value2);
			if (keys1.length !== keys2.length) return false;
			return keys1.every((key) => value1[key] === value2[key]);
		}
		return value1 === value2;
	}
	/**
	* Convert to a RGBA color object with normalized components (0-1).
	* @example
	* ```ts
	* import { Color } from 'pixi.js';
	*
	* // Convert colors to RGBA objects
	* new Color('white').toRgba();     // returns { r: 1, g: 1, b: 1, a: 1 }
	* new Color('#ff0000').toRgba();   // returns { r: 1, g: 0, b: 0, a: 1 }
	*
	* // With transparency
	* new Color('rgba(255,0,0,0.5)').toRgba(); // returns { r: 1, g: 0, b: 0, a: 0.5 }
	* ```
	* @returns An RGBA object with normalized components
	*/
	toRgba() {
		const [r, g, b, a] = this._components;
		return {
			r,
			g,
			b,
			a
		};
	}
	/**
	* Convert to a RGB color object with normalized components (0-1).
	*
	* Alpha component is omitted in the output.
	* @example
	* ```ts
	* import { Color } from 'pixi.js';
	*
	* // Convert colors to RGB objects
	* new Color('white').toRgb();     // returns { r: 1, g: 1, b: 1 }
	* new Color('#ff0000').toRgb();   // returns { r: 1, g: 0, b: 0 }
	*
	* // Alpha is ignored
	* new Color('rgba(255,0,0,0.5)').toRgb(); // returns { r: 1, g: 0, b: 0 }
	* ```
	* @returns An RGB object with normalized components
	*/
	toRgb() {
		const [r, g, b] = this._components;
		return {
			r,
			g,
			b
		};
	}
	/**
	* Convert to a CSS-style rgba string representation.
	*
	* RGB components are scaled to 0-255 range, alpha remains 0-1.
	* @example
	* ```ts
	* import { Color } from 'pixi.js';
	*
	* // Convert colors to RGBA strings
	* new Color('white').toRgbaString();     // returns "rgba(255,255,255,1)"
	* new Color('#ff0000').toRgbaString();   // returns "rgba(255,0,0,1)"
	*
	* // With transparency
	* new Color([1, 0, 0, 0.5]).toRgbaString(); // returns "rgba(255,0,0,0.5)"
	* ```
	* @returns A CSS-compatible rgba string
	*/
	toRgbaString() {
		const [r, g, b] = this.toUint8RgbArray();
		return `rgba(${r},${g},${b},${this.alpha})`;
	}
	/**
	* Convert to an [R, G, B] array of clamped uint8 values (0 to 255).
	* @param {number[]|Uint8Array|Uint8ClampedArray} [out] - Optional output array. If not provided,
	* a cached array will be used and returned.
	* @returns Array containing RGB components as integers between 0-255
	* @example
	* ```ts
	* // Basic usage
	* new Color('white').toUint8RgbArray(); // returns [255, 255, 255]
	* new Color('#ff0000').toUint8RgbArray(); // returns [255, 0, 0]
	*
	* // Using custom output array
	* const rgb = new Uint8Array(3);
	* new Color('blue').toUint8RgbArray(rgb); // rgb is now [0, 0, 255]
	*
	* // Using different array types
	* new Color('red').toUint8RgbArray(new Uint8ClampedArray(3)); // [255, 0, 0]
	* new Color('red').toUint8RgbArray([]); // [255, 0, 0]
	* ```
	* @remarks
	* - Output values are always clamped between 0-255
	* - Alpha component is not included in output
	* - Reuses internal cache array if no output array provided
	*/
	toUint8RgbArray(out) {
		const [r, g, b] = this._components;
		if (!this._arrayRgb) this._arrayRgb = [];
		out || (out = this._arrayRgb);
		out[0] = Math.round(r * 255);
		out[1] = Math.round(g * 255);
		out[2] = Math.round(b * 255);
		return out;
	}
	/**
	* Convert to an [R, G, B, A] array of normalized floats (numbers from 0.0 to 1.0).
	* @param {number[]|Float32Array} [out] - Optional output array. If not provided,
	* a cached array will be used and returned.
	* @returns Array containing RGBA components as floats between 0-1
	* @example
	* ```ts
	* // Basic usage
	* new Color('white').toArray();  // returns [1, 1, 1, 1]
	* new Color('red').toArray();    // returns [1, 0, 0, 1]
	*
	* // With alpha
	* new Color('rgba(255,0,0,0.5)').toArray(); // returns [1, 0, 0, 0.5]
	*
	* // Using custom output array
	* const rgba = new Float32Array(4);
	* new Color('blue').toArray(rgba); // rgba is now [0, 0, 1, 1]
	* ```
	* @remarks
	* - Output values are normalized between 0-1
	* - Includes alpha component as the fourth value
	* - Reuses internal cache array if no output array provided
	*/
	toArray(out) {
		if (!this._arrayRgba) this._arrayRgba = [];
		out || (out = this._arrayRgba);
		const [r, g, b, a] = this._components;
		out[0] = r;
		out[1] = g;
		out[2] = b;
		out[3] = a;
		return out;
	}
	/**
	* Convert to an [R, G, B] array of normalized floats (numbers from 0.0 to 1.0).
	* @param {number[]|Float32Array} [out] - Optional output array. If not provided,
	* a cached array will be used and returned.
	* @returns Array containing RGB components as floats between 0-1
	* @example
	* ```ts
	* // Basic usage
	* new Color('white').toRgbArray(); // returns [1, 1, 1]
	* new Color('red').toRgbArray();   // returns [1, 0, 0]
	*
	* // Using custom output array
	* const rgb = new Float32Array(3);
	* new Color('blue').toRgbArray(rgb); // rgb is now [0, 0, 1]
	* ```
	* @remarks
	* - Output values are normalized between 0-1
	* - Alpha component is omitted from output
	* - Reuses internal cache array if no output array provided
	*/
	toRgbArray(out) {
		if (!this._arrayRgb) this._arrayRgb = [];
		out || (out = this._arrayRgb);
		const [r, g, b] = this._components;
		out[0] = r;
		out[1] = g;
		out[2] = b;
		return out;
	}
	/**
	* Convert to a hexadecimal number.
	* @returns The color as a 24-bit RGB integer
	* @example
	* ```ts
	* // Basic usage
	* new Color('white').toNumber(); // returns 0xffffff
	* new Color('red').toNumber();   // returns 0xff0000
	*
	* // Store as hex
	* const color = new Color('blue');
	* const hex = color.toNumber(); // 0x0000ff
	* ```
	*/
	toNumber() {
		return this._int;
	}
	/**
	* Convert to a BGR number.
	*
	* Useful for platforms that expect colors in BGR format.
	* @returns The color as a 24-bit BGR integer
	* @example
	* ```ts
	* // Convert RGB to BGR
	* new Color(0xffcc99).toBgrNumber(); // returns 0x99ccff
	*
	* // Common use case: platform-specific color format
	* const color = new Color('orange');
	* const bgrColor = color.toBgrNumber(); // Color with swapped R/B channels
	* ```
	* @remarks
	* This swaps the red and blue channels compared to the normal RGB format:
	* - RGB 0xRRGGBB becomes BGR 0xBBGGRR
	*/
	toBgrNumber() {
		const [r, g, b] = this.toUint8RgbArray();
		return (b << 16) + (g << 8) + r;
	}
	/**
	* Convert to a hexadecimal number in little endian format (e.g., BBGGRR).
	*
	* Useful for platforms that expect colors in little endian byte order.
	* @example
	* ```ts
	* import { Color } from 'pixi.js';
	*
	* // Convert RGB color to little endian format
	* new Color(0xffcc99).toLittleEndianNumber(); // returns 0x99ccff
	*
	* // Common use cases:
	* const color = new Color('orange');
	* const leColor = color.toLittleEndianNumber(); // Swaps byte order for LE systems
	*
	* // Multiple conversions
	* const colors = {
	*     normal: 0xffcc99,
	*     littleEndian: new Color(0xffcc99).toLittleEndianNumber(), // 0x99ccff
	*     backToNormal: new Color(0x99ccff).toLittleEndianNumber()  // 0xffcc99
	* };
	* ```
	* @remarks
	* - Swaps R and B channels in the color value
	* - RGB 0xRRGGBB becomes 0xBBGGRR
	* - Useful for systems that use little endian byte order
	* - Can be used to convert back and forth between formats
	* @returns The color as a number in little endian format (BBGGRR)
	* @see {@link Color.toBgrNumber} For BGR format without byte swapping
	*/
	toLittleEndianNumber() {
		const value = this._int;
		return (value >> 16) + (value & 65280) + ((value & 255) << 16);
	}
	/**
	* Multiply with another color.
	*
	* This action is destructive and modifies the original color.
	* @param {ColorSource} value - The color to multiply by. Accepts any valid color format:
	* - Hex strings/numbers (e.g., '#ff0000', 0xff0000)
	* - RGB/RGBA arrays ([1, 0, 0], [1, 0, 0, 1])
	* - Color objects ({ r: 1, g: 0, b: 0 })
	* - CSS color names ('red', 'blue')
	* @returns this - The Color instance for chaining
	* @example
	* ```ts
	* // Basic multiplication
	* const color = new Color('#ff0000');
	* color.multiply(0x808080); // 50% darker red
	*
	* // With transparency
	* color.multiply([1, 1, 1, 0.5]); // 50% transparent
	*
	* // Chain operations
	* color
	*     .multiply('#808080')
	*     .multiply({ r: 1, g: 1, b: 1, a: 0.5 });
	* ```
	* @remarks
	* - Multiplies each RGB component and alpha separately
	* - Values are clamped between 0-1
	* - Original color format is lost (value becomes null)
	* - Operation cannot be undone
	*/
	multiply(value) {
		const [r, g, b, a] = _Color._temp.setValue(value)._components;
		this._components[0] *= r;
		this._components[1] *= g;
		this._components[2] *= b;
		this._components[3] *= a;
		this._refreshInt();
		this._value = null;
		return this;
	}
	/**
	* Converts color to a premultiplied alpha format.
	*
	* This action is destructive and modifies the original color.
	* @param alpha - The alpha value to multiply by (0-1)
	* @param {boolean} [applyToRGB=true] - Whether to premultiply RGB channels
	* @returns {Color} The Color instance for chaining
	* @example
	* ```ts
	* // Basic premultiplication
	* const color = new Color('red');
	* color.premultiply(0.5); // 50% transparent red with premultiplied RGB
	*
	* // Alpha only (RGB unchanged)
	* color.premultiply(0.5, false); // 50% transparent, original RGB
	*
	* // Chain with other operations
	* color
	*     .multiply(0x808080)
	*     .premultiply(0.5)
	*     .toNumber();
	* ```
	* @remarks
	* - RGB channels are multiplied by alpha when applyToRGB is true
	* - Alpha is always set to the provided value
	* - Values are clamped between 0-1
	* - Original color format is lost (value becomes null)
	* - Operation cannot be undone
	*/
	premultiply(alpha, applyToRGB = true) {
		if (applyToRGB) {
			this._components[0] *= alpha;
			this._components[1] *= alpha;
			this._components[2] *= alpha;
		}
		this._components[3] = alpha;
		this._refreshInt();
		this._value = null;
		return this;
	}
	/**
	* Returns the color as a 32-bit premultiplied alpha integer.
	*
	* Format: 0xAARRGGBB
	* @param {number} alpha - The alpha value to multiply by (0-1)
	* @param {boolean} [applyToRGB=true] - Whether to premultiply RGB channels
	* @returns {number} The premultiplied color as a 32-bit integer
	* @example
	* ```ts
	* // Convert to premultiplied format
	* const color = new Color('red');
	*
	* // Full opacity (0xFFRRGGBB)
	* color.toPremultiplied(1.0); // 0xFFFF0000
	*
	* // 50% transparency with premultiplied RGB
	* color.toPremultiplied(0.5); // 0x7F7F0000
	*
	* // 50% transparency without RGB premultiplication
	* color.toPremultiplied(0.5, false); // 0x7FFF0000
	* ```
	* @remarks
	* - Returns full opacity (0xFF000000) when alpha is 1.0
	* - Returns 0 when alpha is 0.0 and applyToRGB is true
	* - RGB values are rounded during premultiplication
	*/
	toPremultiplied(alpha, applyToRGB = true) {
		if (alpha === 1) return (255 << 24) + this._int;
		if (alpha === 0) return applyToRGB ? 0 : this._int;
		let r = this._int >> 16 & 255;
		let g = this._int >> 8 & 255;
		let b = this._int & 255;
		if (applyToRGB) {
			r = r * alpha + .5 | 0;
			g = g * alpha + .5 | 0;
			b = b * alpha + .5 | 0;
		}
		return (alpha * 255 << 24) + (r << 16) + (g << 8) + b;
	}
	/**
	* Convert to a hexadecimal string (6 characters).
	* @returns A CSS-compatible hex color string (e.g., "#ff0000")
	* @example
	* ```ts
	* import { Color } from 'pixi.js';
	*
	* // Basic colors
	* new Color('red').toHex();    // returns "#ff0000"
	* new Color('white').toHex();  // returns "#ffffff"
	* new Color('black').toHex();  // returns "#000000"
	*
	* // From different formats
	* new Color(0xff0000).toHex(); // returns "#ff0000"
	* new Color([1, 0, 0]).toHex(); // returns "#ff0000"
	* new Color({ r: 1, g: 0, b: 0 }).toHex(); // returns "#ff0000"
	* ```
	* @remarks
	* - Always returns a 6-character hex string
	* - Includes leading "#" character
	* - Alpha channel is ignored
	* - Values are rounded to nearest hex value
	*/
	toHex() {
		const hexString = this._int.toString(16);
		return `#${"000000".substring(0, 6 - hexString.length) + hexString}`;
	}
	/**
	* Convert to a hexadecimal string with alpha (8 characters).
	* @returns A CSS-compatible hex color string with alpha (e.g., "#ff0000ff")
	* @example
	* ```ts
	* import { Color } from 'pixi.js';
	*
	* // Fully opaque colors
	* new Color('red').toHexa();   // returns "#ff0000ff"
	* new Color('white').toHexa(); // returns "#ffffffff"
	*
	* // With transparency
	* new Color('rgba(255, 0, 0, 0.5)').toHexa(); // returns "#ff00007f"
	* new Color([1, 0, 0, 0]).toHexa(); // returns "#ff000000"
	* ```
	* @remarks
	* - Returns an 8-character hex string
	* - Includes leading "#" character
	* - Alpha is encoded in last two characters
	* - Values are rounded to nearest hex value
	*/
	toHexa() {
		const alphaString = Math.round(this._components[3] * 255).toString(16);
		return this.toHex() + "00".substring(0, 2 - alphaString.length) + alphaString;
	}
	/**
	* Set alpha (transparency) value while preserving color components.
	*
	* Provides a chainable interface for setting alpha.
	* @param alpha - Alpha value between 0 (fully transparent) and 1 (fully opaque)
	* @returns The Color instance for chaining
	* @example
	* ```ts
	* // Basic alpha setting
	* const color = new Color('red');
	* color.setAlpha(0.5);  // 50% transparent red
	*
	* // Chain with other operations
	* color
	*     .setValue('#ff0000')
	*     .setAlpha(0.8)    // 80% opaque
	*     .premultiply(0.5); // Further modify alpha
	*
	* // Reset to fully opaque
	* color.setAlpha(1);
	* ```
	* @remarks
	* - Alpha value is clamped between 0-1
	* - Can be chained with other color operations
	*/
	setAlpha(alpha) {
		this._components[3] = this._clamp(alpha);
		this._value = null;
		return this;
	}
	/**
	* Normalize the input value into rgba
	* @param value - Input value
	*/
	_normalize(value) {
		let r;
		let g;
		let b;
		let a;
		if ((typeof value === "number" || value instanceof Number) && value >= 0 && value <= 16777215) {
			const int = value;
			r = (int >> 16 & 255) / 255;
			g = (int >> 8 & 255) / 255;
			b = (int & 255) / 255;
			a = 1;
		} else if ((Array.isArray(value) || value instanceof Float32Array) && value.length >= 3 && value.length <= 4) {
			value = this._clamp(value);
			[r, g, b, a = 1] = value;
		} else if ((value instanceof Uint8Array || value instanceof Uint8ClampedArray) && value.length >= 3 && value.length <= 4) {
			value = this._clamp(value, 0, 255);
			[r, g, b, a = 255] = value;
			r /= 255;
			g /= 255;
			b /= 255;
			a /= 255;
		} else if (typeof value === "string" || typeof value === "object") {
			if (typeof value === "string") {
				const match = _Color.HEX_PATTERN.exec(value);
				if (match) value = `#${match[2]}`;
			}
			const color = w(value);
			if (color.isValid()) {
				({r, g, b, a} = color.rgba);
				r /= 255;
				g /= 255;
				b /= 255;
			}
		}
		if (r !== void 0) {
			this._components[0] = r;
			this._components[1] = g;
			this._components[2] = b;
			this._components[3] = a;
			this._refreshInt();
		} else throw new Error(`Unable to convert color ${value}`);
	}
	/** Refresh the internal color rgb number */
	_refreshInt() {
		this._clamp(this._components);
		const [r, g, b] = this._components;
		this._int = (r * 255 << 16) + (g * 255 << 8) + (b * 255 | 0);
	}
	/**
	* Clamps values to a range. Will override original values
	* @param value - Value(s) to clamp
	* @param min - Minimum value
	* @param max - Maximum value
	*/
	_clamp(value, min = 0, max = 1) {
		if (typeof value === "number") return Math.min(Math.max(value, min), max);
		value.forEach((v, i) => {
			value[i] = Math.min(Math.max(v, min), max);
		});
		return value;
	}
	/**
	* Check if a value can be interpreted as a valid color format.
	* Supports all color formats that can be used with the Color class.
	* @param value - Value to check
	* @returns True if the value can be used as a color
	* @example
	* ```ts
	* import { Color } from 'pixi.js';
	*
	* // CSS colors and hex values
	* Color.isColorLike('red');          // true
	* Color.isColorLike('#ff0000');      // true
	* Color.isColorLike(0xff0000);       // true
	*
	* // Arrays (RGB/RGBA)
	* Color.isColorLike([1, 0, 0]);      // true
	* Color.isColorLike([1, 0, 0, 0.5]); // true
	*
	* // TypedArrays
	* Color.isColorLike(new Float32Array([1, 0, 0]));          // true
	* Color.isColorLike(new Uint8Array([255, 0, 0]));          // true
	* Color.isColorLike(new Uint8ClampedArray([255, 0, 0]));   // true
	*
	* // Object formats
	* Color.isColorLike({ r: 1, g: 0, b: 0 });            // true (RGB)
	* Color.isColorLike({ r: 1, g: 0, b: 0, a: 0.5 });    // true (RGBA)
	* Color.isColorLike({ h: 0, s: 100, l: 50 });         // true (HSL)
	* Color.isColorLike({ h: 0, s: 100, l: 50, a: 0.5 }); // true (HSLA)
	* Color.isColorLike({ h: 0, s: 100, v: 100 });        // true (HSV)
	* Color.isColorLike({ h: 0, s: 100, v: 100, a: 0.5 });// true (HSVA)
	*
	* // Color instances
	* Color.isColorLike(new Color('red')); // true
	*
	* // Invalid values
	* Color.isColorLike(null);           // false
	* Color.isColorLike(undefined);      // false
	* Color.isColorLike({});             // false
	* Color.isColorLike([]);             // false
	* Color.isColorLike('not-a-color');  // false
	* ```
	* @remarks
	* Checks for the following formats:
	* - Numbers (0x000000 to 0xffffff)
	* - CSS color strings
	* - RGB/RGBA arrays and objects
	* - HSL/HSLA objects
	* - HSV/HSVA objects
	* - TypedArrays (Float32Array, Uint8Array, Uint8ClampedArray)
	* - Color instances
	* @see {@link ColorSource} For supported color format types
	* @see {@link Color.setValue} For setting color values
	* @category utility
	*/
	static isColorLike(value) {
		return typeof value === "number" || typeof value === "string" || value instanceof Number || value instanceof _Color || Array.isArray(value) || value instanceof Uint8Array || value instanceof Uint8ClampedArray || value instanceof Float32Array || value.r !== void 0 && value.g !== void 0 && value.b !== void 0 || value.r !== void 0 && value.g !== void 0 && value.b !== void 0 && value.a !== void 0 || value.h !== void 0 && value.s !== void 0 && value.l !== void 0 || value.h !== void 0 && value.s !== void 0 && value.l !== void 0 && value.a !== void 0 || value.h !== void 0 && value.s !== void 0 && value.v !== void 0 || value.h !== void 0 && value.s !== void 0 && value.v !== void 0 && value.a !== void 0;
	}
};
/**
* Static shared Color instance used for utility operations. This is a singleton color object
* that can be reused to avoid creating unnecessary Color instances.
* > [!IMPORTANT] You should be careful when using this shared instance, as it is mutable and can be
* > changed by any code that uses it.
* >
* > It is best used for one-off color operations or temporary transformations.
* > For persistent colors, create your own Color instance instead.
* @example
* ```ts
* import { Color } from 'pixi.js';
*
* // Use shared instance for one-off color operations
* Color.shared.setValue(0xff0000);
* const redHex = Color.shared.toHex();     // "#ff0000"
* const redRgb = Color.shared.toRgbArray(); // [1, 0, 0]
*
* // Temporary color transformations
* const colorNumber = Color.shared
*     .setValue('#ff0000')     // Set to red
*     .setAlpha(0.5)          // Make semi-transparent
*     .premultiply(0.8)       // Apply premultiplication
*     .toNumber();            // Convert to number
*
* // Chain multiple operations
* const result = Color.shared
*     .setValue(someColor)
*     .multiply(tintColor)
*     .toPremultiplied(alpha);
* ```
* @remarks
* - This is a shared instance - be careful about multiple code paths using it simultaneously
* - Use for temporary color operations to avoid allocating new Color instances
* - The value is preserved between operations, so reset if needed
* - For persistent colors, create your own Color instance instead
*/
_Color.shared = new _Color();
/**
* Temporary Color object for static uses internally.
* As to not conflict with Color.shared.
* @ignore
*/
_Color._temp = new _Color();
/** Pattern for hex strings */
_Color.HEX_PATTERN = /^(#|0x)?(([a-f0-9]{3}){1,2}([a-f0-9]{2})?)$/i;
var Color = _Color;
//#endregion
//#region node_modules/pixi.js/lib/utils/logging/warn.mjs
var warnCount = 0;
var maxWarnings = 500;
function warn(...args) {
	if (warnCount === maxWarnings) return;
	warnCount++;
	if (warnCount === maxWarnings) console.warn("PixiJS Warning: too many warnings, no more warnings will be reported to the console by PixiJS.");
	else console.warn("PixiJS Warning: ", ...args);
}
//#endregion
//#region node_modules/pixi.js/lib/utils/pool/GlobalResourceRegistry.mjs
var GlobalResourceRegistry = {
	/**
	* Set of registered pools and cleanable objects.
	* @private
	*/
	_registeredResources: /* @__PURE__ */ new Set(),
	/**
	* Registers a pool or cleanable object for cleanup.
	* @param {Cleanable} pool - The pool or object to register.
	*/
	register(pool) {
		this._registeredResources.add(pool);
	},
	/**
	* Unregisters a pool or cleanable object from cleanup.
	* @param {Cleanable} pool - The pool or object to unregister.
	*/
	unregister(pool) {
		this._registeredResources.delete(pool);
	},
	/** Clears all registered pools and cleanable objects. This will call clear() on each registered item. */
	release() {
		this._registeredResources.forEach((pool) => pool.clear());
	},
	/**
	* Gets the number of registered pools and cleanable objects.
	* @returns {number} The count of registered items.
	*/
	get registeredCount() {
		return this._registeredResources.size;
	},
	/**
	* Checks if a specific pool or cleanable object is registered.
	* @param {Cleanable} pool - The pool or object to check.
	* @returns {boolean} True if the item is registered, false otherwise.
	*/
	isRegistered(pool) {
		return this._registeredResources.has(pool);
	},
	/**
	* Removes all registrations without clearing the pools.
	* Useful if you want to reset the collector without affecting the pools.
	*/
	reset() {
		this._registeredResources.clear();
	}
};
//#endregion
//#region node_modules/pixi.js/lib/utils/pool/Pool.mjs
var Pool = class {
	/**
	* Constructs a new Pool.
	* @param ClassType - The constructor of the items in the pool.
	* @param {number} [initialSize] - The initial size of the pool.
	*/
	constructor(ClassType, initialSize) {
		this._pool = [];
		this._count = 0;
		this._index = 0;
		this._classType = ClassType;
		if (initialSize) this.prepopulate(initialSize);
	}
	/**
	* Prepopulates the pool with a given number of items.
	* @param total - The number of items to add to the pool.
	*/
	prepopulate(total) {
		for (let i = 0; i < total; i++) this._pool[this._index++] = new this._classType();
		this._count += total;
	}
	/**
	* Gets an item from the pool. Calls the item's `init` method if it exists.
	* If there are no items left in the pool, a new one will be created.
	* @param {I} [data] - Optional data to pass to the item's constructor.
	* @returns {T} The item from the pool.
	*/
	get(data) {
		let item;
		if (this._index > 0) item = this._pool[--this._index];
		else {
			item = new this._classType();
			this._count++;
		}
		item.init?.(data);
		return item;
	}
	/**
	* Returns an item to the pool. Calls the item's `reset` method if it exists.
	* @param {T} item - The item to return to the pool.
	*/
	return(item) {
		item.reset?.();
		this._pool[this._index++] = item;
	}
	/**
	* Gets the number of items in the pool.
	* @readonly
	*/
	get totalSize() {
		return this._count;
	}
	/**
	* Gets the number of items in the pool that are free to use without needing to create more.
	* @readonly
	*/
	get totalFree() {
		return this._index;
	}
	/**
	* Gets the number of items in the pool that are currently in use.
	* @readonly
	*/
	get totalUsed() {
		return this._count - this._index;
	}
	/** clears the pool */
	clear() {
		if (this._pool.length > 0 && this._pool[0].destroy) for (let i = 0; i < this._index; i++) this._pool[i].destroy();
		this._pool.length = 0;
		this._count = 0;
		this._index = 0;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/utils/pool/PoolGroup.mjs
var PoolGroupClass = class {
	constructor() {
		/**
		* A map to store the pools by their class type.
		* @private
		*/
		this._poolsByClass = /* @__PURE__ */ new Map();
	}
	/**
	* Prepopulates a specific pool with a given number of items.
	* @template T The type of items in the pool. Must extend PoolItem.
	* @param {PoolItemConstructor<T>} Class - The constructor of the items in the pool.
	* @param {number} total - The number of items to add to the pool.
	*/
	prepopulate(Class, total) {
		this.getPool(Class).prepopulate(total);
	}
	/**
	* Gets an item from a specific pool.
	* @template T The type of items in the pool. Must extend PoolItem.
	* @param {PoolItemConstructor<T>} Class - The constructor of the items in the pool.
	* @param {unknown} [data] - Optional data to pass to the item's constructor.
	* @returns {T} The item from the pool.
	*/
	get(Class, data) {
		return this.getPool(Class).get(data);
	}
	/**
	* Returns an item to its respective pool.
	* @param {PoolItem} item - The item to return to the pool.
	*/
	return(item) {
		this.getPool(item.constructor).return(item);
	}
	/**
	* Gets a specific pool based on the class type.
	* @template T The type of items in the pool. Must extend PoolItem.
	* @param {PoolItemConstructor<T>} ClassType - The constructor of the items in the pool.
	* @returns {Pool<T>} The pool of the given class type.
	*/
	getPool(ClassType) {
		if (!this._poolsByClass.has(ClassType)) this._poolsByClass.set(ClassType, new Pool(ClassType));
		return this._poolsByClass.get(ClassType);
	}
	/** gets the usage stats of each pool in the system */
	stats() {
		const stats = {};
		this._poolsByClass.forEach((pool) => {
			const name = stats[pool._classType.name] ? pool._classType.name + pool._classType.ID : pool._classType.name;
			stats[name] = {
				free: pool.totalFree,
				used: pool.totalUsed,
				size: pool.totalSize
			};
		});
		return stats;
	}
	/** Clears all pools in the group. This will reset all pools and free their resources. */
	clear() {
		this._poolsByClass.forEach((pool) => pool.clear());
		this._poolsByClass.clear();
	}
};
var BigPool = new PoolGroupClass();
GlobalResourceRegistry.register(BigPool);
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/multiplyHexColors.mjs
function multiplyHexColors(color1, color2) {
	if (color1 === 16777215 || !color2) return color2;
	if (color2 === 16777215 || !color1) return color1;
	const r1 = color1 >> 16 & 255;
	const g1 = color1 >> 8 & 255;
	const b1 = color1 & 255;
	const r2 = color2 >> 16 & 255;
	const g2 = color2 >> 8 & 255;
	const b2 = color2 & 255;
	const r = r1 * r2 / 255 | 0;
	const g = g1 * g2 / 255 | 0;
	const b = b1 * b2 / 255 | 0;
	return (r << 16) + (g << 8) + b;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/instructions/InstructionSet.mjs
var InstructionSet = class {
	constructor() {
		/** a unique id for this instruction set used through the renderer */
		this.uid = uid("instructionSet");
		/** the array of instructions */
		this.instructions = [];
		/** the actual size of the array (any instructions passed this should be ignored) */
		this.instructionSize = 0;
		this.renderables = [];
		/** used by the garbage collector to track when the instruction set was last used */
		this.gcTick = 0;
	}
	/** reset the instruction set so it can be reused set size back to 0 */
	reset() {
		this.instructionSize = 0;
	}
	/**
	* Destroy the instruction set, clearing the instructions and renderables and notifying
	* each render pipe so it can release any per-InstructionSet cached resources.
	* @internal
	*/
	destroy() {
		if (this.renderPipes) for (const i in this.renderPipes) this.renderPipes[i].destroyInstructionSet?.(this);
		this.instructions.length = 0;
		this.renderables.length = 0;
		this.renderPipes = null;
		this.gcTick = 0;
	}
	/**
	* Add an instruction to the set
	* @param instruction - add an instruction to the set
	*/
	add(instruction) {
		this.instructions[this.instructionSize++] = instruction;
	}
	/**
	* Log the instructions to the console (for debugging)
	* @internal
	*/
	log() {
		this.instructions.length = this.instructionSize;
		console.table(this.instructions, ["type", "action"]);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/utils/ScreenSizeRegistry.mjs
var ScreenSizeRegistry = class {
	constructor() {
		/** the live screen sizes in physical pixels, keyed by renderer uid */
		this._screenSizes = /* @__PURE__ */ new Map();
		/** the unique registered screen widths in physical pixels, sorted ascending */
		this._widths = [];
		/** the unique registered screen heights in physical pixels, sorted ascending */
		this._heights = [];
	}
	/** The number of renderers with a registered screen. */
	get size() {
		return this._screenSizes.size;
	}
	/**
	* Registers, or updates, the screen size of a renderer.
	* @param rendererUid - The uid of the renderer, used to update or remove this screen later.
	* @param pixelWidth - The width of the screen in physical pixels.
	* @param pixelHeight - The height of the screen in physical pixels.
	* @returns `true` if this changed the registered screens, `false` if the size was already registered.
	*/
	set(rendererUid, pixelWidth, pixelHeight) {
		const current = this._screenSizes.get(rendererUid);
		if (current && current.pixelWidth === pixelWidth && current.pixelHeight === pixelHeight) return false;
		this._screenSizes.set(rendererUid, {
			pixelWidth,
			pixelHeight
		});
		this._update();
		return true;
	}
	/**
	* Removes the screen of a renderer.
	* @param rendererUid - The uid the screen was registered with.
	* @returns `true` if a screen was removed, `false` if the renderer had none registered.
	*/
	remove(rendererUid) {
		if (!this._screenSizes.delete(rendererUid)) return false;
		this._update();
		return true;
	}
	/**
	* The smallest registered screen width the request fits in.
	* @param pixelWidth - The requested width in physical pixels.
	* @returns The smallest live screen width that is at least `pixelWidth`, or `undefined` if none.
	*/
	getFittingWidth(pixelWidth) {
		return this._getFittingAxis(pixelWidth, this._widths);
	}
	/**
	* The smallest registered screen height the request fits in.
	* @param pixelHeight - The requested height in physical pixels.
	* @returns The smallest live screen height that is at least `pixelHeight`, or `undefined` if none.
	*/
	getFittingHeight(pixelHeight) {
		return this._getFittingAxis(pixelHeight, this._heights);
	}
	/**
	* Whether a live screen uses this width.
	* @param width - The width in physical pixels.
	*/
	hasWidth(width) {
		return this._widths.includes(width);
	}
	/**
	* Whether a live screen uses this height.
	* @param height - The height in physical pixels.
	*/
	hasHeight(height) {
		return this._heights.includes(height);
	}
	/**
	* The smallest registered screen on this axis that the request still fits in.
	* @param pixelSize - The requested size on this axis in physical pixels.
	* @param screenSizes - The live screen sizes on this axis, sorted ascending.
	* @returns The smallest screen size that is at least `pixelSize`, or `undefined` if none.
	*/
	_getFittingAxis(pixelSize, screenSizes) {
		for (let i = 0; i < screenSizes.length; i++) {
			const screenSize = screenSizes[i];
			if (screenSize >= pixelSize) return screenSize;
		}
	}
	/** Rebuilds the sorted unique sizes for each axis. */
	_update() {
		this._widths = [...this._screenSizes.values()].map((screenSize) => screenSize.pixelWidth).filter((width, i, widths) => widths.indexOf(width) === i).sort((a, b) => a - b);
		this._heights = [...this._screenSizes.values()].map((screenSize) => screenSize.pixelHeight).filter((height, i, heights) => heights.indexOf(height) === i).sort((a, b) => a - b);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/environment-browser/BrowserAdapter.mjs
var BrowserAdapter = {
	createCanvas: (width, height) => {
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		return canvas;
	},
	createImage: () => new Image(),
	getCanvasRenderingContext2D: () => CanvasRenderingContext2D,
	getWebGLRenderingContext: () => WebGLRenderingContext,
	getNavigator: () => navigator,
	getBaseUrl: () => document.baseURI ?? window.location.href,
	getFontFaceSet: () => document.fonts,
	fetch: (url, options) => fetch(url, options),
	parseXML: (xml) => {
		return new DOMParser().parseFromString(xml, "text/xml");
	}
};
//#endregion
//#region node_modules/pixi.js/lib/environment/adapter.mjs
var currentAdapter = BrowserAdapter;
var DOMAdapter = {
	/**
	* Returns the current adapter.
	* @returns {environment.Adapter} The current adapter.
	*/
	get() {
		return currentAdapter;
	},
	/**
	* Sets the current adapter.
	* @param adapter - The new adapter.
	*/
	set(adapter) {
		currentAdapter = adapter;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/utils/createIdFromString.mjs
var idCounts = /* @__PURE__ */ Object.create(null);
var idHash = /* @__PURE__ */ Object.create(null);
function createIdFromString(value, groupId) {
	let id = idHash[value];
	if (id === void 0) {
		if (idCounts[groupId] === void 0) idCounts[groupId] = 1;
		idHash[value] = id = idCounts[groupId]++;
	}
	return id;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/getTestContext.mjs
var context;
function getTestContext() {
	if (!context || context?.isContextLost()) context = DOMAdapter.get().createCanvas().getContext("webgl", {});
	return context;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/getMaxFragmentPrecision.mjs
var maxFragmentPrecision;
function getMaxFragmentPrecision() {
	if (!maxFragmentPrecision) {
		maxFragmentPrecision = "mediump";
		const gl = getTestContext();
		if (gl) {
			if (gl.getShaderPrecisionFormat) maxFragmentPrecision = gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT).precision ? "highp" : "mediump";
		}
	}
	return maxFragmentPrecision;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/addProgramDefines.mjs
function addProgramDefines(src, isES300, isFragment) {
	if (isES300) return src;
	if (isFragment) {
		src = src.replace("out vec4 finalColor;", "");
		return `

        #ifdef GL_ES // This checks if it is WebGL1
        #define in varying
        #define finalColor gl_FragColor
        #define texture texture2D
        #endif
        ${src}
        `;
	}
	return `

        #ifdef GL_ES // This checks if it is WebGL1
        #define in attribute
        #define out varying
        #endif
        ${src}
        `;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/ensurePrecision.mjs
var unqualifiedSamplerPattern = /\buniform\s+([iu]?sampler\w+)/g;
var declaredSamplerPattern = /\bprecision\s+\w+\s+([iu]?sampler\w+)\s*;/g;
var defaultSamplerPrecisions = {
	sampler2D: "lowp",
	samplerCube: "lowp"
};
function ensurePrecision(src, options, isFragment) {
	const maxSupportedPrecision = isFragment ? options.maxSupportedFragmentPrecision : options.maxSupportedVertexPrecision;
	if (src.substring(0, 9) !== "precision") {
		let precision = isFragment ? options.requestedFragmentPrecision : options.requestedVertexPrecision;
		if (precision === "highp" && maxSupportedPrecision !== "highp") precision = "mediump";
		src = `precision ${precision} float;
${src}`;
	} else if (maxSupportedPrecision !== "highp" && src.substring(0, 15) === "precision highp") src = src.replace("precision highp", "precision mediump");
	const samplerPrecision = options.maxSupportedFragmentPrecision === "highp" ? "highp" : "mediump";
	return ensureSamplerPrecision(src, samplerPrecision);
}
function ensureSamplerPrecision(src, dataPrecision) {
	const done = /* @__PURE__ */ new Set();
	let header = "";
	for (const [, type] of src.matchAll(declaredSamplerPattern)) done.add(type);
	for (const [, type] of src.matchAll(unqualifiedSamplerPattern)) {
		if (done.has(type)) continue;
		done.add(type);
		header += `precision ${defaultSamplerPrecisions[type] ?? dataPrecision} ${type};
`;
	}
	return header + src;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/insertVersion.mjs
function insertVersion(src, isES300) {
	if (!isES300) return src;
	return `#version 300 es
${src}`;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/setProgramName.mjs
var fragmentNameCache = {};
var VertexNameCache = {};
function setProgramName(src, { name = `pixi-program` }, isFragment = true) {
	name = name.replace(/\s+/g, "-");
	name += isFragment ? "-fragment" : "-vertex";
	const nameCache = isFragment ? fragmentNameCache : VertexNameCache;
	if (nameCache[name]) {
		nameCache[name]++;
		name += `-${nameCache[name]}`;
	} else nameCache[name] = 1;
	if (src.indexOf("#define SHADER_NAME") !== -1) return src;
	return `${`#define SHADER_NAME ${name}`}
${src}`;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/program/preprocessors/stripVersion.mjs
function stripVersion(src, isES300) {
	if (!isES300) return src;
	return src.replace("#version 300 es", "");
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/shader/GlProgram.mjs
var processes = {
	stripVersion,
	ensurePrecision,
	addProgramDefines,
	setProgramName,
	insertVersion
};
var programCache$1 = /* @__PURE__ */ Object.create(null);
var _GlProgram = class _GlProgram {
	/**
	* Creates a shiny new GlProgram. Used by WebGL renderer.
	* @param options - The options for the program.
	*/
	constructor(options) {
		options = {
			..._GlProgram.defaultOptions,
			...options
		};
		const isES300 = options.fragment.indexOf("#version 300 es") !== -1;
		const preprocessorOptions = {
			stripVersion: isES300,
			ensurePrecision: {
				requestedFragmentPrecision: options.preferredFragmentPrecision,
				requestedVertexPrecision: options.preferredVertexPrecision,
				maxSupportedVertexPrecision: "highp",
				maxSupportedFragmentPrecision: getMaxFragmentPrecision()
			},
			setProgramName: { name: options.name },
			addProgramDefines: isES300,
			insertVersion: isES300
		};
		let fragment = options.fragment;
		let vertex = options.vertex;
		Object.keys(processes).forEach((processKey) => {
			const processOptions = preprocessorOptions[processKey];
			fragment = processes[processKey](fragment, processOptions, true);
			vertex = processes[processKey](vertex, processOptions, false);
		});
		this.fragment = fragment;
		this.vertex = vertex;
		this.transformFeedbackVaryings = options.transformFeedbackVaryings;
		this._key = createIdFromString(`${this.vertex}:${this.fragment}`, "gl-program");
	}
	/** destroys the program */
	destroy() {
		this.fragment = null;
		this.vertex = null;
		this._attributeData = null;
		this._uniformData = null;
		this._uniformBlockData = null;
		this.transformFeedbackVaryings = null;
		programCache$1[this._cacheKey] = null;
	}
	/**
	* Helper function that creates a program for a given source.
	* It will check the program cache if the program has already been created.
	* If it has that one will be returned, if not a new one will be created and cached.
	* @param options - The options for the program.
	* @returns A program using the same source
	*/
	static from(options) {
		const key = `${options.vertex}:${options.fragment}`;
		if (!programCache$1[key]) {
			programCache$1[key] = new _GlProgram(options);
			programCache$1[key]._cacheKey = key;
		}
		return programCache$1[key];
	}
};
/** The default options used by the program. */
_GlProgram.defaultOptions = {
	preferredVertexPrecision: "highp",
	preferredFragmentPrecision: "mediump"
};
var GlProgram = _GlProgram;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/utils/getAttributeInfoFromFormat.mjs
var attributeFormatData = {
	uint8x2: {
		size: 2,
		stride: 2,
		normalised: false
	},
	uint8x4: {
		size: 4,
		stride: 4,
		normalised: false
	},
	sint8x2: {
		size: 2,
		stride: 2,
		normalised: false
	},
	sint8x4: {
		size: 4,
		stride: 4,
		normalised: false
	},
	unorm8x2: {
		size: 2,
		stride: 2,
		normalised: true
	},
	unorm8x4: {
		size: 4,
		stride: 4,
		normalised: true
	},
	snorm8x2: {
		size: 2,
		stride: 2,
		normalised: true
	},
	snorm8x4: {
		size: 4,
		stride: 4,
		normalised: true
	},
	uint16x2: {
		size: 2,
		stride: 4,
		normalised: false
	},
	uint16x4: {
		size: 4,
		stride: 8,
		normalised: false
	},
	sint16x2: {
		size: 2,
		stride: 4,
		normalised: false
	},
	sint16x4: {
		size: 4,
		stride: 8,
		normalised: false
	},
	unorm16x2: {
		size: 2,
		stride: 4,
		normalised: true
	},
	unorm16x4: {
		size: 4,
		stride: 8,
		normalised: true
	},
	snorm16x2: {
		size: 2,
		stride: 4,
		normalised: true
	},
	snorm16x4: {
		size: 4,
		stride: 8,
		normalised: true
	},
	float16x2: {
		size: 2,
		stride: 4,
		normalised: false
	},
	float16x4: {
		size: 4,
		stride: 8,
		normalised: false
	},
	float32: {
		size: 1,
		stride: 4,
		normalised: false
	},
	float32x2: {
		size: 2,
		stride: 8,
		normalised: false
	},
	float32x3: {
		size: 3,
		stride: 12,
		normalised: false
	},
	float32x4: {
		size: 4,
		stride: 16,
		normalised: false
	},
	uint32: {
		size: 1,
		stride: 4,
		normalised: false
	},
	uint32x2: {
		size: 2,
		stride: 8,
		normalised: false
	},
	uint32x3: {
		size: 3,
		stride: 12,
		normalised: false
	},
	uint32x4: {
		size: 4,
		stride: 16,
		normalised: false
	},
	sint32: {
		size: 1,
		stride: 4,
		normalised: false
	},
	sint32x2: {
		size: 2,
		stride: 8,
		normalised: false
	},
	sint32x3: {
		size: 3,
		stride: 12,
		normalised: false
	},
	sint32x4: {
		size: 4,
		stride: 16,
		normalised: false
	}
};
function getAttributeInfoFromFormat(format) {
	return attributeFormatData[format] ?? attributeFormatData.float32;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/extractAttributesFromGpuProgram.mjs
var WGSL_TO_VERTEX_TYPES = {
	f32: "float32",
	"vec2<f32>": "float32x2",
	"vec3<f32>": "float32x3",
	"vec4<f32>": "float32x4",
	vec2f: "float32x2",
	vec3f: "float32x3",
	vec4f: "float32x4",
	i32: "sint32",
	"vec2<i32>": "sint32x2",
	"vec3<i32>": "sint32x3",
	"vec4<i32>": "sint32x4",
	vec2i: "sint32x2",
	vec3i: "sint32x3",
	vec4i: "sint32x4",
	u32: "uint32",
	"vec2<u32>": "uint32x2",
	"vec3<u32>": "uint32x3",
	"vec4<u32>": "uint32x4",
	vec2u: "uint32x2",
	vec3u: "uint32x3",
	vec4u: "uint32x4",
	bool: "uint32",
	"vec2<bool>": "uint32x2",
	"vec3<bool>": "uint32x3",
	"vec4<bool>": "uint32x4"
};
var LOCATION_REGEX = /@location\((\d+)\)\s+([a-zA-Z0-9_]+)\s*:\s*([a-zA-Z0-9_<>]+)(?:,|\s|\)|$)/g;
function parseLocations(str, results) {
	let match;
	while ((match = LOCATION_REGEX.exec(str)) !== null) {
		const format = WGSL_TO_VERTEX_TYPES[match[3]] ?? "float32";
		results[match[2]] = {
			location: parseInt(match[1], 10),
			format,
			stride: getAttributeInfoFromFormat(format).stride,
			offset: 0,
			instance: false,
			start: 0
		};
	}
	LOCATION_REGEX.lastIndex = 0;
}
function stripComments(source) {
	return source.replace(/\/\/.*$/gm, "").replace(/\/\*[\s\S]*?\*\//g, "");
}
function extractAttributesFromGpuProgram({ source, entryPoint }) {
	const results = {};
	const cleanSource = stripComments(source);
	const mainVertStart = cleanSource.indexOf(`fn ${entryPoint}(`);
	if (mainVertStart === -1) return results;
	const arrowFunctionStart = cleanSource.indexOf("->", mainVertStart);
	if (arrowFunctionStart === -1) return results;
	const functionArgsSubstring = cleanSource.substring(mainVertStart, arrowFunctionStart);
	parseLocations(functionArgsSubstring, results);
	if (Object.keys(results).length === 0) {
		const structMatch = functionArgsSubstring.match(/\(\s*\w+\s*:\s*(\w+)/);
		if (structMatch) {
			const structName = structMatch[1];
			const structRegex = new RegExp(`struct\\s+${structName}\\s*\\{([^}]+)\\}`, "s");
			const structBody = cleanSource.match(structRegex);
			if (structBody) parseLocations(structBody[1], results);
		}
	}
	return results;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/extractStructAndGroups.mjs
function extractStructAndGroups(wgsl) {
	const linePattern = /(^|[^/])@(group|binding)\(\d+\)[^;]+;/g;
	const groupPattern = /@group\((\d+)\)/;
	const bindingPattern = /@binding\((\d+)\)/;
	const namePattern = /var(<[^>]+>)? (\w+)/;
	const typePattern = /:\s*([\w<>]+)/;
	const structPattern = /struct\s+(\w+)\s*{([^}]+)}/g;
	const structMemberPattern = /(\w+)\s*:\s*([\w\<\>]+)/g;
	const structName = /struct\s+(\w+)/;
	const groups = wgsl.match(linePattern)?.map((item) => {
		const varMatch = item.match(namePattern);
		const varQualifier = varMatch?.[1] ?? "";
		let accessMode;
		if (varQualifier === "<uniform>") accessMode = "uniform";
		else if (varQualifier.startsWith("<storage")) accessMode = "storage";
		return {
			group: parseInt(item.match(groupPattern)[1], 10),
			binding: parseInt(item.match(bindingPattern)[1], 10),
			name: varMatch[2],
			accessMode,
			type: item.match(typePattern)[1]
		};
	});
	if (!groups) return {
		groups: [],
		structs: []
	};
	return {
		groups,
		structs: wgsl.match(structPattern)?.map((struct) => {
			const name = struct.match(structName)[1];
			const members = struct.match(structMemberPattern).reduce((acc, member) => {
				const [name2, type] = member.split(":");
				acc[name2.trim()] = type.trim();
				return acc;
			}, {});
			if (!members) return null;
			return {
				name,
				members
			};
		}).filter(({ name }) => groups.some((group) => group.type === name || group.type.includes(`<${name}>`))) ?? []
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/const.mjs
var ShaderStage = /* @__PURE__ */ ((ShaderStage2) => {
	ShaderStage2[ShaderStage2["VERTEX"] = 1] = "VERTEX";
	ShaderStage2[ShaderStage2["FRAGMENT"] = 2] = "FRAGMENT";
	ShaderStage2[ShaderStage2["COMPUTE"] = 4] = "COMPUTE";
	return ShaderStage2;
})(ShaderStage || {});
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/generateGpuLayoutGroups.mjs
function getTextureSampleType(type) {
	if (type.endsWith("<u32>")) return "uint";
	if (type.endsWith("<i32>")) return "sint";
	return "float";
}
function generateGpuLayoutGroups({ groups }) {
	const layout = [];
	for (let i = 0; i < groups.length; i++) {
		const group = groups[i];
		if (!layout[group.group]) layout[group.group] = [];
		if (group.accessMode === "uniform") layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			buffer: { type: "uniform" }
		});
		else if (group.accessMode === "storage") layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			buffer: { type: "read-only-storage" }
		});
		else if (group.type === "sampler") layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			sampler: { type: "filtering" }
		});
		else if (group.type === "sampler_comparison") layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			sampler: { type: "comparison" }
		});
		else if (group.type === "texture_2d" || group.type.startsWith("texture_2d<")) layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			texture: {
				sampleType: getTextureSampleType(group.type),
				viewDimension: "2d",
				multisampled: false
			}
		});
		else if (group.type === "texture_depth_2d") layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			texture: {
				sampleType: "depth",
				viewDimension: "2d",
				multisampled: false
			}
		});
		else if (group.type === "texture_depth_2d_array") layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			texture: {
				sampleType: "depth",
				viewDimension: "2d-array",
				multisampled: false
			}
		});
		else if (group.type === "texture_2d_array" || group.type.startsWith("texture_2d_array<")) layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			texture: {
				sampleType: getTextureSampleType(group.type),
				viewDimension: "2d-array",
				multisampled: false
			}
		});
		else if (group.type === "texture_3d" || group.type.startsWith("texture_3d<")) layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			texture: {
				sampleType: getTextureSampleType(group.type),
				viewDimension: "3d",
				multisampled: false
			}
		});
		else if (group.type === "texture_cube" || group.type.startsWith("texture_cube<")) layout[group.group].push({
			binding: group.binding,
			visibility: ShaderStage.VERTEX | ShaderStage.FRAGMENT,
			texture: {
				sampleType: getTextureSampleType(group.type),
				viewDimension: "cube",
				multisampled: false
			}
		});
	}
	for (let i = 0; i < layout.length; i++) layout[i] || (layout[i] = []);
	return layout;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/generateLayoutHash.mjs
function generateLayoutHash({ groups }) {
	const layout = [];
	for (let i = 0; i < groups.length; i++) {
		const group = groups[i];
		if (!layout[group.group]) layout[group.group] = {};
		layout[group.group][group.name] = group.binding;
	}
	return layout;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/utils/removeStructAndGroupDuplicates.mjs
function removeStructAndGroupDuplicates(vertexStructsAndGroups, fragmentStructsAndGroups) {
	const structNameSet = /* @__PURE__ */ new Set();
	const dupeGroupKeySet = /* @__PURE__ */ new Set();
	return {
		structs: [...vertexStructsAndGroups.structs, ...fragmentStructsAndGroups.structs].filter((struct) => {
			if (structNameSet.has(struct.name)) return false;
			structNameSet.add(struct.name);
			return true;
		}),
		groups: [...vertexStructsAndGroups.groups, ...fragmentStructsAndGroups.groups].filter((group) => {
			const key = `${group.name}-${group.binding}`;
			if (dupeGroupKeySet.has(key)) return false;
			dupeGroupKeySet.add(key);
			return true;
		})
	};
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/GpuProgram.mjs
var programCache = /* @__PURE__ */ Object.create(null);
var GpuProgram = class GpuProgram {
	/**
	* Create a new GpuProgram
	* @param options - The options for the gpu program
	*/
	constructor(options) {
		/** @internal */
		this._layoutKey = 0;
		/** @internal */
		this._attributeLocationsKey = 0;
		const { fragment, vertex, layout, gpuLayout, name } = options;
		this.name = name;
		this.fragment = fragment;
		this.vertex = vertex;
		if (fragment.source === vertex.source) {
			const structsAndGroups = extractStructAndGroups(fragment.source);
			this.structsAndGroups = structsAndGroups;
		} else {
			const vertexStructsAndGroups = extractStructAndGroups(vertex.source);
			const fragmentStructsAndGroups = extractStructAndGroups(fragment.source);
			this.structsAndGroups = removeStructAndGroupDuplicates(vertexStructsAndGroups, fragmentStructsAndGroups);
		}
		this.layout = layout ?? generateLayoutHash(this.structsAndGroups);
		this.gpuLayout = gpuLayout ?? generateGpuLayoutGroups(this.structsAndGroups);
		this.autoAssignGlobalUniforms = !!(this.layout[0]?.globalUniforms !== void 0);
		this.autoAssignLocalUniforms = !!(this.layout[1]?.localUniforms !== void 0);
		this._generateProgramKey();
	}
	_generateProgramKey() {
		const { vertex, fragment } = this;
		const bigKey = vertex.source + fragment.source + vertex.entryPoint + fragment.entryPoint;
		this._layoutKey = createIdFromString(bigKey, "program");
	}
	get attributeData() {
		this._attributeData ?? (this._attributeData = extractAttributesFromGpuProgram(this.vertex));
		return this._attributeData;
	}
	/** destroys the program */
	destroy() {
		this.gpuLayout = null;
		this.layout = null;
		this.structsAndGroups = null;
		this.fragment = null;
		this.vertex = null;
		programCache[this._cacheKey] = null;
	}
	/**
	* Helper function that creates a program for a given source.
	* It will check the program cache if the program has already been created.
	* If it has that one will be returned, if not a new one will be created and cached.
	* @param options - The options for the program.
	* @returns A program using the same source
	*/
	static from(options) {
		const key = `${options.vertex.source}:${options.fragment.source}:${options.fragment.entryPoint}:${options.vertex.entryPoint}`;
		if (!programCache[key]) {
			programCache[key] = new GpuProgram(options);
			programCache[key]._cacheKey = key;
		}
		return programCache[key];
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/types.mjs
var UNIFORM_TYPES_VALUES = [
	"f32",
	"i32",
	"u32",
	"vec2<f32>",
	"vec3<f32>",
	"vec4<f32>",
	"mat2x2<f32>",
	"mat3x3<f32>",
	"mat4x4<f32>",
	"mat3x2<f32>",
	"mat4x2<f32>",
	"mat2x3<f32>",
	"mat4x3<f32>",
	"mat2x4<f32>",
	"mat3x4<f32>",
	"vec2<i32>",
	"vec3<i32>",
	"vec4<i32>",
	"vec2<u32>",
	"vec3<u32>",
	"vec4<u32>"
];
var UNIFORM_TYPES_MAP = UNIFORM_TYPES_VALUES.reduce((acc, type) => {
	acc[type] = true;
	return acc;
}, {});
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/utils/getDefaultUniformValue.mjs
function getDefaultUniformValue(type, size) {
	switch (type) {
		case "f32": return 0;
		case "vec2<f32>": return new Float32Array(2 * size);
		case "vec3<f32>": return new Float32Array(3 * size);
		case "vec4<f32>": return new Float32Array(4 * size);
		case "mat2x2<f32>": return new Float32Array([
			1,
			0,
			0,
			1
		]);
		case "mat3x3<f32>": return new Float32Array([
			1,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			1
		]);
		case "mat4x4<f32>": return new Float32Array([
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			0,
			1
		]);
	}
	return null;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/UniformGroup.mjs
var _UniformGroup = class _UniformGroup extends eventemitter3_default {
	/**
	* Create a new Uniform group
	* @param uniformStructures - The structures of the uniform group
	* @param options - The optional parameters of this uniform group
	*/
	constructor(uniformStructures, options) {
		super();
		/** a unique id for this uniform group used through the renderer */
		this.uid = uid("uniform");
		/**
		* a resource type, used to identify how to handle it when its in a bind group / shader resource
		* @internal
		*/
		this._resourceType = "uniformGroup";
		/**
		* the resource id used internally by the renderer to build bind group keys
		* @internal
		*/
		this._resourceId = uid("resource");
		/** used ito identify if this is a uniform group */
		this.isUniformGroup = true;
		/**
		* used to flag if this Uniform groups data is different from what it has stored in its buffer / on the GPU
		* @internal
		*/
		this._dirtyId = 0;
		this.destroyed = false;
		options = {
			..._UniformGroup.defaultOptions,
			...options
		};
		this.uniformStructures = uniformStructures;
		const uniforms = {};
		for (const i in uniformStructures) {
			const uniformData = uniformStructures[i];
			uniformData.name = i;
			uniformData.size = uniformData.size ?? 1;
			if (!UNIFORM_TYPES_MAP[uniformData.type]) {
				const arrayMatch = uniformData.type.match(/^array<(\w+(?:<\w+>)?),\s*(\d+)>$/);
				if (arrayMatch) {
					const [, innerType, size] = arrayMatch;
					throw new Error(`Uniform type ${uniformData.type} is not supported. Use type: '${innerType}', size: ${size} instead.`);
				}
				throw new Error(`Uniform type ${uniformData.type} is not supported. Supported uniform types are: ${UNIFORM_TYPES_VALUES.join(", ")}`);
			}
			uniformData.value ?? (uniformData.value = getDefaultUniformValue(uniformData.type, uniformData.size));
			uniforms[i] = uniformData.value;
		}
		this.uniforms = uniforms;
		this._dirtyId = 1;
		this.ubo = options.ubo;
		this.isStatic = options.isStatic;
		this._signature = createIdFromString(Object.keys(uniforms).map((i) => `${i}-${uniformStructures[i].type}`).join("-"), "uniform-group");
	}
	/**
	* an underlying buffer that will be uploaded to the GPU when using this UniformGroup.
	* It is created lazily by the renderer's ubo system on first use.
	*/
	get buffer() {
		return this._buffer;
	}
	set buffer(value) {
		if (this._buffer === value) return;
		this._buffer?.off("change", this.onBufferChange, this);
		this._buffer = value;
		value?.on("change", this.onBufferChange, this);
	}
	/**
	* The GC tracks this group's underlying buffer, not the group itself — a GC stamp on the
	* group (see BindGroup._touch) must land on the buffer, or the GC collects it while
	* cached bind groups still reference it.
	* @internal
	*/
	get _gcLastUsed() {
		return this._buffer?._gcLastUsed ?? -1;
	}
	set _gcLastUsed(value) {
		if (this._buffer) this._buffer._gcLastUsed = value;
	}
	/**
	* Bind group keys are built from this group's _resourceId, not the buffer's — so when the
	* buffer re-keys (it resized, or the GC unloaded its GPU copy), this group must re-key too,
	* or cached GPUBindGroups keep referencing the destroyed GPU buffer.
	*/
	onBufferChange() {
		this._resourceId = uid("resource");
		this.emit("change", this);
	}
	/** Call this if you want the uniform groups data to be uploaded to the GPU only useful if `isStatic` is true. */
	update() {
		this._dirtyId++;
	}
};
/**
* emits when the underlying buffer needs to be re-bound (it resized or was unloaded),
* letting cached bind groups know they must rebuild
* @event change
*/
/** The default options used by the uniform group. */
_UniformGroup.defaultOptions = {
	/** if true the UniformGroup is handled as an Uniform buffer object. */
	ubo: false,
	/** if true, then you are responsible for when the data is uploaded to the GPU by calling `update()` */
	isStatic: false
};
var UniformGroup = _UniformGroup;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/shader/BindGroup.mjs
var BindGroup = class {
	/**
	* Create a new instance of the Bind Group.
	* @param resources - The resources that are bound together for use by a shader.
	*/
	constructor(resources) {
		/**
		* The resources that are bound together for use by a shader, keyed by binding number.
		*
		* Treat this as read-only and use {@link BindGroup#setResource} to add or replace a resource.
		* A direct write skips the bind group's change tracking: the GPU bind group is not rebuilt,
		* and the renderer never syncs the new resource's uniforms or marks it as in use.
		* @readonly
		*/
		this.resources = /* @__PURE__ */ Object.create(null);
		this._resourceKeysValue = null;
		this._dirty = true;
		let index = 0;
		for (const i in resources) {
			const resource = resources[i];
			this.setResource(resource, index++);
		}
	}
	/**
	* The binding numbers in use in {@link BindGroup#resources}, ascending. Binding numbers can
	* have gaps, so per-draw loops index this list instead of running `for...in` over
	* `resources`, which builds a fresh key list on every call for integer keys.
	* @internal
	*/
	get _resourceKeys() {
		this._resourceKeysValue ?? (this._resourceKeysValue = Object.keys(this.resources).map(Number));
		return this._resourceKeysValue;
	}
	/**
	* A key used internally to match it up to a WebGPU BindGroup.
	* Lazily rebuilt from resource IDs when dirty.
	* @internal
	*/
	get _key() {
		if (this._dirty) {
			this._dirty = false;
			const keyParts = [];
			let index = 0;
			for (const i in this.resources) keyParts[index++] = this.resources[i] ? this.resources[i]._resourceId : -1;
			this._keyValue = keyParts.join("|");
		}
		return this._keyValue;
	}
	/**
	* Set a resource at a given index. This function will
	* ensure that listeners will be removed from the current resource
	* and added to the new resource.
	* @param resource - The resource to set.
	* @param index - The index to set the resource at.
	*/
	setResource(resource, index) {
		const currentResource = this.resources[index];
		if (resource === currentResource) return;
		if (currentResource) currentResource.off?.("change", this.onResourceChange, this);
		resource.on?.("change", this.onResourceChange, this);
		if (currentResource === void 0) this._resourceKeysValue = null;
		this.resources[index] = resource;
		this._dirty = true;
	}
	/**
	* Returns the resource at the current specified index.
	* @param index - The index of the resource to get.
	* @returns - The resource at the specified index.
	*/
	getResource(index) {
		return this.resources[index];
	}
	/**
	* Used internally to 'touch' each resource, to ensure that the GC
	* knows that all resources in this bind group are still being used.
	* @param now - The current time in milliseconds.
	* @internal
	*/
	_touch(now) {
		const resources = this.resources;
		const keys = this._resourceKeys;
		for (let i = 0; i < keys.length; i++) {
			const resource = resources[keys[i]];
			if (!resource) continue;
			resource._gcLastUsed = now;
		}
	}
	/** Destroys this bind group and removes all listeners. */
	destroy() {
		const resources = this.resources;
		for (const i in resources) resources[i]?.off?.("change", this.onResourceChange, this);
		this.resources = null;
		this._resourceKeysValue = null;
	}
	onResourceChange(resource) {
		this._dirty = true;
		if (resource.destroyed) {
			const resources = this.resources;
			for (const i in resources) if (resources[i] === resource) resources[i] = null;
			warn(`[BindGroup] a '${resource._resourceType}' was destroyed while still bound to a shader. Remove it from the shader before destroying it.`);
		}
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/types.mjs
var RendererType = /* @__PURE__ */ ((RendererType2) => {
	RendererType2[RendererType2["WEBGL"] = 1] = "WEBGL";
	RendererType2[RendererType2["WEBGPU"] = 2] = "WEBGPU";
	RendererType2[RendererType2["CANVAS"] = 4] = "CANVAS";
	RendererType2[RendererType2["BOTH"] = 3] = "BOTH";
	return RendererType2;
})(RendererType || {});
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/ShaderOverrides.mjs
var ShaderOverrides = class ShaderOverrides {
	/**
	* @param data - A dictionary of constants to set on the shader.
	* Keys should match the constant names in the WGSL shader.
	*/
	constructor(data) {
		this.data = { ...data };
		const key = Object.keys(data).sort().map((k) => `${k}:${data[k]}`).join("|");
		this.id = createIdFromString(key, "shader-overrides");
	}
	/**
	* Creates a ShaderOverrides instance from a plain object or existing instance.
	* @param overrides - The overrides to convert.
	* @returns A ShaderOverrides instance.
	*/
	static from(overrides) {
		if (overrides instanceof ShaderOverrides) return overrides;
		return new ShaderOverrides(overrides);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/shader/Shader.mjs
var Shader = class Shader extends eventemitter3_default {
	constructor(options) {
		super();
		/** A unique identifier for the shader */
		this.uid = uid("shader");
		/**
		* A record of the uniform groups and resources used by the shader.
		* This is used by WebGL renderer to sync uniform data.
		* @internal
		*/
		this._uniformBindMap = /* @__PURE__ */ Object.create(null);
		this._ownedBindGroups = [];
		/** @internal */
		this._destroyed = false;
		let { gpuProgram, glProgram, groups, resources, compatibleRenderers, groupMap, overrides } = options;
		this._overrides = overrides ? ShaderOverrides.from(overrides) : null;
		this.gpuProgram = gpuProgram;
		this.glProgram = glProgram;
		if (compatibleRenderers === void 0) {
			compatibleRenderers = 0;
			if (gpuProgram) compatibleRenderers |= RendererType.WEBGPU;
			if (glProgram) compatibleRenderers |= RendererType.WEBGL;
		}
		this.compatibleRenderers = compatibleRenderers;
		const nameHash = {};
		if (groupMap) for (const i in groupMap) for (const j in groupMap[i]) {
			const uniformName = groupMap[i][j];
			nameHash[uniformName] = {
				group: i,
				binding: j,
				name: uniformName
			};
		}
		if (!resources && !groups) resources = {};
		if (resources && groups) throw new Error("[Shader] Cannot have both resources and groups");
		else if (!gpuProgram && groups && !groupMap) throw new Error("[Shader] No group map or WebGPU shader provided - consider using resources instead.");
		else if (gpuProgram && groups && !groupMap) {
			const groupData = gpuProgram.structsAndGroups.groups;
			groupMap = {};
			groupData.forEach((data) => {
				groupMap[data.group] = groupMap[data.group] || {};
				groupMap[data.group][data.binding] = data.name;
				nameHash[data.name] = data;
			});
		} else if (resources) {
			groups = {};
			groupMap || (groupMap = {});
			if (gpuProgram) gpuProgram.structsAndGroups.groups.forEach((data) => {
				groupMap[data.group] = groupMap[data.group] || {};
				groupMap[data.group][data.binding] = data.name;
				nameHash[data.name] = data;
			});
			let bindTick = 0;
			for (const i in resources) {
				if (nameHash[i]) continue;
				if (gpuProgram && !glProgram) warn(`[Shader] the resource '${i}' matches no binding in the WGSL source \u2014 is the name correct?`);
				if (!groups[99]) {
					groups[99] = new BindGroup();
					this._ownedBindGroups.push(groups[99]);
				}
				nameHash[i] = {
					group: 99,
					binding: bindTick,
					name: i
				};
				groupMap[99] = groupMap[99] || {};
				groupMap[99][bindTick] = i;
				bindTick++;
			}
			for (const i in resources) {
				const name = i;
				let value = resources[i];
				if (!value.source && !value._resourceType) value = new UniformGroup(value);
				const data = nameHash[name];
				if (data) {
					if (!groups[data.group]) {
						groups[data.group] = new BindGroup();
						this._ownedBindGroups.push(groups[data.group]);
					}
					groups[data.group].setResource(value, data.binding);
				}
			}
		}
		this.groups = groups;
		this._uniformBindMap = groupMap;
		this.resources = this._buildResourceAccessor(groups, nameHash);
	}
	/**
	* Sometimes a resource group will be provided later (for example global uniforms)
	* In such cases, this method can be used to let the shader know about the group.
	* @param name - the name of the resource group
	* @param groupIndex - the index of the group (should match the webGPU shader group location)
	* @param bindIndex - the index of the bind point (should match the webGPU shader bind point)
	*/
	addResource(name, groupIndex, bindIndex) {
		var _a, _b;
		(_a = this._uniformBindMap)[groupIndex] || (_a[groupIndex] = {});
		(_b = this._uniformBindMap[groupIndex])[bindIndex] || (_b[bindIndex] = name);
		if (!this.groups[groupIndex]) {
			this.groups[groupIndex] = new BindGroup();
			this._ownedBindGroups.push(this.groups[groupIndex]);
		}
	}
	_buildResourceAccessor(groups, nameHash) {
		const uniformsOut = {};
		for (const i in nameHash) {
			const data = nameHash[i];
			Object.defineProperty(uniformsOut, data.name, {
				get() {
					return groups[data.group].getResource(data.binding);
				},
				set(value) {
					groups[data.group].setResource(value, data.binding);
				}
			});
		}
		return uniformsOut;
	}
	/**
	* Use to destroy the shader when its not longer needed.
	* It will destroy the resources and remove listeners.
	* @param destroyPrograms - if the programs should be destroyed as well.
	* Make sure its not being used by other shaders!
	*/
	destroy(destroyPrograms = false) {
		if (this._destroyed) return;
		this._destroyed = true;
		this.emit("destroy", this);
		if (destroyPrograms) {
			this.gpuProgram?.destroy();
			this.glProgram?.destroy();
		}
		this.gpuProgram = null;
		this.glProgram = null;
		this.removeAllListeners();
		this._uniformBindMap = null;
		this._ownedBindGroups.forEach((bindGroup) => {
			bindGroup.destroy();
		});
		this._ownedBindGroups = null;
		this.resources = null;
		this.groups = null;
		this._overrides = null;
	}
	static from(options) {
		const { gpu, gl, ...rest } = options;
		let gpuProgram;
		let glProgram;
		if (gpu) gpuProgram = GpuProgram.from(gpu);
		if (gl) glProgram = GlProgram.from(gl);
		return new Shader({
			gpuProgram,
			glProgram,
			...rest
		});
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/buffer/const.mjs
var BufferUsage = /* @__PURE__ */ ((BufferUsage2) => {
	BufferUsage2[BufferUsage2["MAP_READ"] = 1] = "MAP_READ";
	BufferUsage2[BufferUsage2["MAP_WRITE"] = 2] = "MAP_WRITE";
	BufferUsage2[BufferUsage2["COPY_SRC"] = 4] = "COPY_SRC";
	BufferUsage2[BufferUsage2["COPY_DST"] = 8] = "COPY_DST";
	BufferUsage2[BufferUsage2["INDEX"] = 16] = "INDEX";
	BufferUsage2[BufferUsage2["VERTEX"] = 32] = "VERTEX";
	BufferUsage2[BufferUsage2["UNIFORM"] = 64] = "UNIFORM";
	BufferUsage2[BufferUsage2["STORAGE"] = 128] = "STORAGE";
	BufferUsage2[BufferUsage2["INDIRECT"] = 256] = "INDIRECT";
	BufferUsage2[BufferUsage2["QUERY_RESOLVE"] = 512] = "QUERY_RESOLVE";
	BufferUsage2[BufferUsage2["STATIC"] = 1024] = "STATIC";
	return BufferUsage2;
})(BufferUsage || {});
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/buffer/Buffer.mjs
var Buffer = class extends eventemitter3_default {
	/**
	* Creates a new Buffer with the given options
	* @param options - the options for the buffer
	*/
	constructor(options) {
		let { data, size } = options;
		const { usage, label, shrinkToFit } = options;
		super();
		/**
		* emits when the underlying buffer has changed shape (i.e. resized) or been unloaded,
		* letting the renderer know that it needs to discard the old buffer on the GPU and create a new one
		* @event change
		*/
		/**
		* emits when the underlying buffer data has been updated. letting the renderer know
		* that it needs to update the buffer on the GPU
		* @event update
		*/
		/**
		* emits when the buffer is destroyed. letting the renderer know that it needs to destroy the buffer on the GPU
		* @event destroy
		*/
		/** @internal */
		this._gpuData = /* @__PURE__ */ Object.create(null);
		/** @internal */
		this._gcLastUsed = -1;
		/** If set to true, the buffer will be garbage collected automatically when it is not used. */
		this.autoGarbageCollect = true;
		/** a unique id for this uniform group used through the renderer */
		this.uid = uid("buffer");
		/**
		* a resource type, used to identify how to handle it when its in a bind group / shader resource
		* @internal
		*/
		this._resourceType = "buffer";
		/**
		* the resource id used internally by the renderer to build bind group keys
		* @internal
		*/
		this._resourceId = uid("resource");
		/** @internal */
		this._updateID = 1;
		/** @internal */
		this._updateOffset = 0;
		this._dataInt32 = null;
		/**
		* should the GPU buffer be shrunk when the data becomes smaller?
		* changing this will cause the buffer to be destroyed and a new one created on the GPU
		* this can be expensive, especially if the buffer is already big enough!
		* setting this to false will prevent the buffer from being shrunk. This will yield better performance
		* if you are constantly setting data that is changing size often.
		* @default true
		*/
		this.shrinkToFit = true;
		/**
		* Has the buffer been destroyed?
		* @readonly
		*/
		this.destroyed = false;
		if (data instanceof Array) data = new Float32Array(data);
		this._data = data;
		size ?? (size = data?.byteLength);
		const mappedAtCreation = !!data;
		this.descriptor = {
			size,
			usage,
			mappedAtCreation,
			label
		};
		this.shrinkToFit = shrinkToFit ?? true;
	}
	/** the data in the buffer */
	get data() {
		return this._data;
	}
	set data(value) {
		this.setDataWithSize(value, value.length, true);
	}
	get dataInt32() {
		if (!this._dataInt32) this._dataInt32 = new Int32Array(this.data.buffer);
		return this._dataInt32;
	}
	/** whether the buffer is static or not */
	get static() {
		return !!(this.descriptor.usage & BufferUsage.STATIC);
	}
	set static(value) {
		if (value) this.descriptor.usage |= BufferUsage.STATIC;
		else this.descriptor.usage &= ~BufferUsage.STATIC;
	}
	/**
	* Sets the data in the buffer to the given value. This will immediately update the buffer on the GPU.
	* If you only want to update a subset of the buffer, you can pass in the size of the data.
	* @param value - the data to set
	* @param size - the size of the data in bytes
	* @param syncGPU - should the buffer be updated on the GPU immediately?
	*/
	setDataWithSize(value, size, syncGPU) {
		this._updateID++;
		this._updateSize = size * value.BYTES_PER_ELEMENT;
		this._updateOffset = 0;
		if (this._data === value) {
			if (syncGPU) this.emit("update", this);
			return;
		}
		const oldData = this._data;
		this._data = value;
		this._dataInt32 = null;
		if (!oldData || oldData.length !== value.length) {
			if (!this.shrinkToFit && oldData && value.byteLength < oldData.byteLength) {
				if (syncGPU) this.emit("update", this);
			} else {
				this.descriptor.size = value.byteLength;
				this._resourceId = uid("resource");
				this.emit("change", this);
			}
			return;
		}
		if (syncGPU) this.emit("update", this);
	}
	/**
	* updates the buffer on the GPU to reflect the data in the buffer.
	* By default it will update the entire buffer. If you only want to update a subset of the buffer,
	* you can pass in the size of the buffer to update.
	* @param sizeInBytes - the new size of the buffer in bytes
	* @param offsetInBytes - the offset to start updating from
	*/
	update(sizeInBytes, offsetInBytes) {
		this._updateSize = sizeInBytes ?? this._updateSize;
		this._updateOffset = offsetInBytes || 0;
		this._updateID++;
		this.emit("update", this);
	}
	/** Unloads the buffer from the GPU */
	unload() {
		this.emit("unload", this);
		for (const key in this._gpuData) this._gpuData[key]?.destroy();
		this._gpuData = /* @__PURE__ */ Object.create(null);
		if (!this.destroyed) {
			this._resourceId = uid("resource");
			this.emit("change", this);
		}
	}
	/** Destroys the buffer */
	destroy() {
		this.destroyed = true;
		this.unload();
		this.emit("destroy", this);
		this.emit("change", this);
		this._data = null;
		this.descriptor = null;
		this.removeAllListeners();
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/utils/ensureIsBuffer.mjs
function ensureIsBuffer(buffer, index) {
	if (!(buffer instanceof Buffer)) {
		let usage = index ? BufferUsage.INDEX : BufferUsage.VERTEX;
		if (buffer instanceof Array) {
			if (index) {
				buffer = new Uint32Array(buffer);
				usage = BufferUsage.INDEX | BufferUsage.COPY_DST;
			} else {
				buffer = new Float32Array(buffer);
				usage = BufferUsage.VERTEX | BufferUsage.COPY_DST;
			}
		}
		buffer = new Buffer({
			data: buffer,
			label: index ? "index-mesh-buffer" : "vertex-mesh-buffer",
			usage
		});
	}
	return buffer;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/utils/getGeometryBounds.mjs
function getGeometryBounds(geometry, attributeId, bounds) {
	const attribute = geometry.getAttribute(attributeId);
	if (!attribute) {
		bounds.minX = 0;
		bounds.minY = 0;
		bounds.maxX = 0;
		bounds.maxY = 0;
		return bounds;
	}
	const data = attribute.buffer.data;
	let minX = Infinity;
	let minY = Infinity;
	let maxX = -Infinity;
	let maxY = -Infinity;
	const byteSize = data.BYTES_PER_ELEMENT;
	const offset = (attribute.offset || 0) / byteSize;
	const stride = (attribute.stride || 8) / byteSize;
	for (let i = offset; i < data.length; i += stride) {
		const x = data[i];
		const y = data[i + 1];
		if (x > maxX) maxX = x;
		if (y > maxY) maxY = y;
		if (x < minX) minX = x;
		if (y < minY) minY = y;
	}
	bounds.minX = minX;
	bounds.minY = minY;
	bounds.maxX = maxX;
	bounds.maxY = maxY;
	return bounds;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/geometry/Geometry.mjs
function ensureIsAttribute(attribute) {
	if (attribute instanceof Buffer || Array.isArray(attribute) || attribute.BYTES_PER_ELEMENT) attribute = { buffer: attribute };
	attribute.buffer = ensureIsBuffer(attribute.buffer, false);
	return attribute;
}
var Geometry = class extends eventemitter3_default {
	/**
	* Create a new instance of a geometry
	* @param options - The options for the geometry.
	*/
	constructor(options = {}) {
		super();
		/** @internal */
		this._gpuData = /* @__PURE__ */ Object.create(null);
		/** If set to true, the resource will be garbage collected automatically when it is not used. */
		this.autoGarbageCollect = true;
		/** @internal */
		this._gcLastUsed = -1;
		/** The unique id of the geometry. */
		this.uid = uid("geometry");
		/**
		* the layout key will be generated by WebGPU all geometries that have the same structure
		* will have the same layout key. This is used to cache the pipeline layout
		* @internal
		*/
		this._layoutKey = 0;
		/** the instance count of the geometry to draw */
		this.instanceCount = 1;
		/**
		* The number of indices to draw, or `0` to draw the whole index buffer.
		*
		* Set this when a geometry only covers a prefix of an index buffer it shares with others - a
		* pool of identical quads, say, where one buffer holds the six indices per quad for the largest
		* batch and each geometry draws as many quads as it currently holds. A `size` passed to the
		* draw call still wins, and a geometry with no index buffer ignores this entirely
		* ({@link Geometry.vertexCount} drives those). Read at draw time only, so changing it never
		* re-uploads or re-lays-out anything.
		* @default 0
		*/
		this.indexCount = 0;
		this._bounds = new Bounds();
		this._boundsDirty = true;
		this._vertexCount = 0;
		this._vertexCountDirty = true;
		const { attributes, indexBuffer, topology } = options;
		this.buffers = [];
		this.attributes = {};
		if (attributes) for (const i in attributes) this.addAttribute(i, attributes[i]);
		this.instanceCount = options.instanceCount ?? 1;
		this.indexCount = options.indexCount ?? 0;
		if (indexBuffer) this.addIndex(indexBuffer);
		this.topology = topology || "triangle-list";
	}
	onBufferUpdate() {
		this._boundsDirty = true;
		this._vertexCountDirty = true;
		this.emit("update", this);
	}
	/**
	* Returns the requested attribute.
	* @param id - The name of the attribute required
	* @returns - The attribute requested.
	*/
	getAttribute(id) {
		return this.attributes[id];
	}
	/**
	* Returns the index buffer
	* @returns - The index buffer.
	*/
	getIndex() {
		return this.indexBuffer;
	}
	/**
	* Returns the requested buffer.
	* @param id - The name of the buffer required.
	* @returns - The buffer requested.
	*/
	getBuffer(id) {
		return this.getAttribute(id).buffer;
	}
	/**
	* The number of vertices in this geometry, derived from the first non-instanced attribute.
	* The value is cached and only recalculated when the geometry's buffers or attributes change.
	*/
	get vertexCount() {
		if (!this._vertexCountDirty) return this._vertexCount;
		this._vertexCountDirty = false;
		const attributes = this.attributes;
		for (const i in attributes) {
			const attribute = attributes[i];
			if (attribute.instance) continue;
			const buffer = attribute.buffer;
			this._vertexCount = buffer.data.length / (attribute.stride / 4 || attribute.size);
			return this._vertexCount;
		}
		this._vertexCount = 0;
		return 0;
	}
	/**
	* Used to figure out how many vertices there are in this geometry
	* @returns the number of vertices in the geometry
	* @deprecated since 8.20.0, use {@link Geometry.vertexCount} instead
	*/
	getSize() {
		deprecation("8.20.0", "Geometry.getSize is deprecated, please use Geometry.vertexCount instead.");
		return this.vertexCount;
	}
	/**
	* Adds an attribute to the geometry.
	* @param name - The name of the attribute to add.
	* @param attributeOption - The attribute option to add.
	*/
	addAttribute(name, attributeOption) {
		const attribute = ensureIsAttribute(attributeOption);
		if (this.buffers.indexOf(attribute.buffer) === -1) {
			this.buffers.push(attribute.buffer);
			attribute.buffer.on("update", this.onBufferUpdate, this);
			attribute.buffer.on("change", this.onBufferUpdate, this);
		}
		this.attributes[name] = attribute;
		this._vertexCountDirty = true;
	}
	/**
	* Adds an index buffer to the geometry.
	* @param indexBuffer - The index buffer to add. Can be a Buffer, TypedArray, or an array of numbers.
	*/
	addIndex(indexBuffer) {
		this.indexBuffer = ensureIsBuffer(indexBuffer, true);
		this.buffers.push(this.indexBuffer);
	}
	/** Returns the bounds of the geometry. */
	get bounds() {
		if (!this._boundsDirty) return this._bounds;
		this._boundsDirty = false;
		return getGeometryBounds(this, "aPosition", this._bounds);
	}
	/** Unloads the geometry from the GPU. */
	unload() {
		this.emit("unload", this);
		for (const key in this._gpuData) this._gpuData[key]?.destroy();
		this._gpuData = /* @__PURE__ */ Object.create(null);
	}
	/**
	* destroys the geometry.
	* @param destroyBuffers - destroy the buffers associated with this geometry
	*/
	destroy(destroyBuffers = false) {
		this.emit("destroy", this);
		for (const buffer of this.buffers) {
			buffer.off("update", this.onBufferUpdate, this);
			buffer.off("change", this.onBufferUpdate, this);
			if (destroyBuffers) buffer.destroy();
		}
		this.unload();
		this.removeAllListeners();
		this.attributes = null;
		this.buffers = null;
		this.indexBuffer = null;
		this._bounds = null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/CanvasPool.mjs
var maxKeyDimension = 32767;
function bucketKey(width, height) {
	return (width << 17) + (height << 2);
}
var CanvasPoolClass = class {
	constructor(canvasOptions) {
		/** idle canvases, keyed by size */
		this._buckets = /* @__PURE__ */ new Map();
		/** the screens this pool is sizing its canvases for */
		this._screens = new ScreenSizeRegistry();
		this._enableFullScreen = false;
		this.canvasOptions = canvasOptions || {};
	}
	/**
	* Has no effect. The pool sizes canvases to the screens registered with
	* {@link CanvasPoolClass#setScreenSize|setScreenSize}.
	* @deprecated since 8.21.0
	*/
	get enableFullScreen() {
		deprecation(v8_21_0, "CanvasPool.enableFullScreen is no longer used, the pool sizes canvases to the screens registered with setScreenSize.");
		return this._enableFullScreen;
	}
	set enableFullScreen(value) {
		deprecation(v8_21_0, "CanvasPool.enableFullScreen is no longer used, the pool sizes canvases to the screens registered with setScreenSize.");
		this._enableFullScreen = value;
	}
	/**
	* Creates texture with params that were specified in pool constructor.
	* @param pixelWidth - Width of texture in pixels.
	* @param pixelHeight - Height of texture in pixels.
	*/
	_createCanvasAndContext(pixelWidth, pixelHeight) {
		const canvas = DOMAdapter.get().createCanvas();
		canvas.width = pixelWidth;
		canvas.height = pixelHeight;
		return {
			canvas,
			context: canvas.getContext("2d")
		};
	}
	/**
	* Gets a Power-of-Two canvas or screen sized canvas
	* @param minWidth - The minimum width of the canvas.
	* @param minHeight - The minimum height of the canvas.
	* @param resolution - The resolution of the canvas.
	* @returns The new canvas and its context.
	*/
	getOptimalCanvasAndContext(minWidth, minHeight, resolution = 1) {
		const { width: canvasWidth, height: canvasHeight } = this.getOptimalSize(minWidth, minHeight, resolution);
		if (canvasWidth > maxKeyDimension || canvasHeight > maxKeyDimension) warn(`CanvasPool: ${canvasWidth}x${canvasHeight} is larger than the ${maxKeyDimension}px pool key limit, canvases of this size may be pooled together`);
		const key = bucketKey(canvasWidth, canvasHeight);
		let bucket = this._buckets.get(key);
		if (!bucket) {
			bucket = [];
			this._buckets.set(key, bucket);
		}
		let canvasAndContext = bucket.pop();
		if (!canvasAndContext) canvasAndContext = this._createCanvasAndContext(canvasWidth, canvasHeight);
		return canvasAndContext;
	}
	/**
	* The backing size, in physical pixels, that
	* {@link CanvasPoolClass#getOptimalCanvasAndContext|getOptimalCanvasAndContext} would allocate for a request,
	* without taking a canvas from the pool.
	*
	* Each axis is the next power of two, or the smallest registered screen the request fits inside
	* (see {@link CanvasPoolClass#setScreenSize|setScreenSize}).
	* @param minWidth - The minimum width of the canvas.
	* @param minHeight - The minimum height of the canvas.
	* @param resolution - The resolution of the canvas.
	* @returns The width and height the pooled canvas would have, in physical pixels.
	*/
	getOptimalSize(minWidth, minHeight, resolution = 1) {
		const pixelWidth = Math.ceil(minWidth * resolution - 1e-6);
		const pixelHeight = Math.ceil(minHeight * resolution - 1e-6);
		const po2Width = nextPow2(pixelWidth);
		const screenWidth = this._screens.getFittingWidth(pixelWidth);
		const po2Height = nextPow2(pixelHeight);
		const screenHeight = this._screens.getFittingHeight(pixelHeight);
		return {
			width: screenWidth !== void 0 ? Math.min(screenWidth, po2Width) : po2Width,
			height: screenHeight !== void 0 ? Math.min(screenHeight, po2Height) : po2Height
		};
	}
	/**
	* Place a canvas back into the pool.
	* @param canvasAndContext
	*/
	returnCanvasAndContext(canvasAndContext) {
		const { width, height } = canvasAndContext.canvas;
		const canvases = this._buckets.get(bucketKey(width, height));
		if (!canvases) return;
		canvasAndContext.context.resetTransform();
		canvasAndContext.context.clearRect(0, 0, width, height);
		canvases.push(canvasAndContext);
	}
	/**
	* Registers the screen size of a renderer with the pool, in physical pixels.
	*
	* While a screen is registered, a request that fits inside it on an axis is given that screen's size on
	* that axis instead of the next power of two, which stops a full screen canvas from being allocated far
	* larger than the screen. Requests larger than every registered screen on an axis keep the power of two
	* size - the pool never rounds a request up to a screen it does not fit in.
	* @param rendererUid - The uid of the renderer, used to update or remove this screen later.
	* @param pixelWidth - The width of the screen in physical pixels.
	* @param pixelHeight - The height of the screen in physical pixels.
	*/
	setScreenSize(rendererUid, pixelWidth, pixelHeight) {
		if (!this._screens.set(rendererUid, pixelWidth, pixelHeight)) return;
		this._pruneScreenCanvases();
	}
	/**
	* Removes a screen previously registered with
	* {@link CanvasPoolClass#setScreenSize|setScreenSize}, dropping any idle canvases that were
	* only being kept for it.
	* @param rendererUid - The uid the screen was registered with.
	*/
	removeScreen(rendererUid) {
		if (!this._screens.remove(rendererUid)) return;
		this._pruneScreenCanvases();
	}
	/** Clears the pool. */
	clear() {
		this._buckets.clear();
	}
	/**
	* Drops the idle canvases in every bucket that has a non power of two dimension matching no live
	* screen. Power of two buckets are always kept, as any request can fall back to them.
	*/
	_pruneScreenCanvases() {
		for (const [key] of this._buckets) {
			const width = key >>> 17;
			const height = key >>> 2 & 32767;
			if ((isPow2(width) || this._screens.hasWidth(width)) && (isPow2(height) || this._screens.hasHeight(height))) continue;
			this._buckets.delete(key);
		}
	}
};
var CanvasPool = new CanvasPoolClass();
GlobalResourceRegistry.register(CanvasPool);
//#endregion
export { nextPow2 as $, getMaxFragmentPrecision as A, Pool as B, getAttributeInfoFromFormat as C, insertVersion as D, setProgramName as E, ScreenSizeRegistry as F, Texture as G, warn as H, InstructionSet as I, TextureSource as J, TextureMatrix as K, multiplyHexColors as L, createIdFromString as M, DOMAdapter as N, ensurePrecision as O, BrowserAdapter as P, log2 as Q, BigPool as R, extractAttributesFromGpuProgram as S, stripVersion as T, Color as U, GlobalResourceRegistry as V, Bounds as W, definedProps as X, TextureStyle as Y, isPow2 as Z, removeStructAndGroupDuplicates as _, ExtensionType as _t, ensureIsBuffer as a, v8_22_0 as at, ShaderStage as b, Shader as c, uid as ct, BindGroup as d, Matrix as dt, isIntegerFormat as et, UniformGroup as f, Point as ft, GpuProgram as g, eventemitter3_default as gt, UNIFORM_TYPES_VALUES as h, RAD_TO_DEG as ht, getGeometryBounds as i, v8_21_0 as it, getTestContext as j, addProgramDefines as k, ShaderOverrides as l, Rectangle as lt, UNIFORM_TYPES_MAP as m, PI_2 as mt, CanvasPoolClass as n, deprecation as nt, Buffer as o, v8_3_4 as ot, getDefaultUniformValue as p, DEG_TO_RAD as pt, BufferImageSource as q, Geometry as r, v8_0_0 as rt, BufferUsage as s, resetUids as st, CanvasPool as t, NOOP as tt, RendererType as u, groupD8 as ut, generateLayoutHash as v, extensions as vt, GlProgram as w, extractStructAndGroups as x, generateGpuLayoutGroups as y, normalizeExtensionPriority as yt, PoolGroupClass as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ2FudmFzUG9vbC1CY0lWTmo4WS5qcyIsIm5hbWVzIjpbIkV2ZW50RW1pdHRlciIsImlkSGFzaCIsIkV2ZW50RW1pdHRlciIsIkV2ZW50RW1pdHRlciIsIkV2ZW50RW1pdHRlciIsImV4dGVuZCIsIm5hbWVzUGx1Z2luIiwiY29sb3JkIiwicHJvZ3JhbUNhY2hlIiwiRXZlbnRFbWl0dGVyIiwiRXZlbnRFbWl0dGVyIiwiRXZlbnRFbWl0dGVyIiwiRXZlbnRFbWl0dGVyIl0sInNvdXJjZXMiOlsiLi4vLi4vcGl4aS5qcy9saWIvZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyIsIi4uLy4uL2V2ZW50ZW1pdHRlcjMvaW5kZXguanMiLCIuLi8uLi9ldmVudGVtaXR0ZXIzL2luZGV4Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL21hdGhzL21pc2MvY29uc3QubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvbWF0aHMvcG9pbnQvUG9pbnQubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvbWF0aHMvbWF0cml4L01hdHJpeC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9tYXRocy9tYXRyaXgvZ3JvdXBEOC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9tYXRocy9zaGFwZXMvUmVjdGFuZ2xlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3V0aWxzL2RhdGEvdWlkLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3V0aWxzL2xvZ2dpbmcvZGVwcmVjYXRpb24ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvdXRpbHMvbWlzYy9OT09QLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvdXRpbHMvaXNJbnRlZ2VyRm9ybWF0Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL21hdGhzL21pc2MvcG93Mi5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvdXRpbHMvZGVmaW5lZFByb3BzLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvVGV4dHVyZVN0eWxlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvc291cmNlcy9UZXh0dXJlU291cmNlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvc291cmNlcy9CdWZmZXJJbWFnZVNvdXJjZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL1RleHR1cmVNYXRyaXgubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9UZXh0dXJlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvQm91bmRzLm1qcyIsIi4uLy4uL0BwaXhpL2NvbG9yZC9pbmRleC5tanMiLCIuLi8uLi9AcGl4aS9jb2xvcmQvcGx1Z2lucy9uYW1lcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9jb2xvci9Db2xvci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi91dGlscy9sb2dnaW5nL3dhcm4ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvdXRpbHMvcG9vbC9HbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3V0aWxzL3Bvb2wvUG9vbC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi91dGlscy9wb29sL1Bvb2xHcm91cC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvdXRpbHMvbXVsdGlwbHlIZXhDb2xvcnMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvaW5zdHJ1Y3Rpb25zL0luc3RydWN0aW9uU2V0Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvdXRpbHMvU2NyZWVuU2l6ZVJlZ2lzdHJ5Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2Vudmlyb25tZW50LWJyb3dzZXIvQnJvd3NlckFkYXB0ZXIubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvZW52aXJvbm1lbnQvYWRhcHRlci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC91dGlscy9jcmVhdGVJZEZyb21TdHJpbmcubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9nbC9zaGFkZXIvcHJvZ3JhbS9nZXRUZXN0Q29udGV4dC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL2dsL3NoYWRlci9wcm9ncmFtL2dldE1heEZyYWdtZW50UHJlY2lzaW9uLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvZ2wvc2hhZGVyL3Byb2dyYW0vcHJlcHJvY2Vzc29ycy9hZGRQcm9ncmFtRGVmaW5lcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL2dsL3NoYWRlci9wcm9ncmFtL3ByZXByb2Nlc3NvcnMvZW5zdXJlUHJlY2lzaW9uLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvZ2wvc2hhZGVyL3Byb2dyYW0vcHJlcHJvY2Vzc29ycy9pbnNlcnRWZXJzaW9uLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvZ2wvc2hhZGVyL3Byb2dyYW0vcHJlcHJvY2Vzc29ycy9zZXRQcm9ncmFtTmFtZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL2dsL3NoYWRlci9wcm9ncmFtL3ByZXByb2Nlc3NvcnMvc3RyaXBWZXJzaW9uLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvZ2wvc2hhZGVyL0dsUHJvZ3JhbS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9nZW9tZXRyeS91dGlscy9nZXRBdHRyaWJ1dGVJbmZvRnJvbUZvcm1hdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL2dwdS9zaGFkZXIvdXRpbHMvZXh0cmFjdEF0dHJpYnV0ZXNGcm9tR3B1UHJvZ3JhbS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL2dwdS9zaGFkZXIvdXRpbHMvZXh0cmFjdFN0cnVjdEFuZEdyb3Vwcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9zaGFkZXIvY29uc3QubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9ncHUvc2hhZGVyL3V0aWxzL2dlbmVyYXRlR3B1TGF5b3V0R3JvdXBzLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvZ3B1L3NoYWRlci91dGlscy9nZW5lcmF0ZUxheW91dEhhc2gubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9ncHUvc2hhZGVyL3V0aWxzL3JlbW92ZVN0cnVjdEFuZEdyb3VwRHVwbGljYXRlcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL2dwdS9zaGFkZXIvR3B1UHJvZ3JhbS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9zaGFkZXIvdHlwZXMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvc2hhZGVyL3V0aWxzL2dldERlZmF1bHRVbmlmb3JtVmFsdWUubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvc2hhZGVyL1VuaWZvcm1Hcm91cC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL2dwdS9zaGFkZXIvQmluZEdyb3VwLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvdHlwZXMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvc2hhZGVyL1NoYWRlck92ZXJyaWRlcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9zaGFkZXIvU2hhZGVyLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL2J1ZmZlci9jb25zdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9idWZmZXIvQnVmZmVyLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL2dlb21ldHJ5L3V0aWxzL2Vuc3VyZUlzQnVmZmVyLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL2dlb21ldHJ5L3V0aWxzL2dldEdlb21ldHJ5Qm91bmRzLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL2dlb21ldHJ5L0dlb21ldHJ5Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvQ2FudmFzUG9vbC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgRXh0ZW5zaW9uVHlwZSA9IC8qIEBfX1BVUkVfXyAqLyAoKEV4dGVuc2lvblR5cGUyKSA9PiB7XG4gIEV4dGVuc2lvblR5cGUyW1wiQXBwbGljYXRpb25cIl0gPSBcImFwcGxpY2F0aW9uXCI7XG4gIEV4dGVuc2lvblR5cGUyW1wiV2ViR0xQaXBlc1wiXSA9IFwid2ViZ2wtcGlwZXNcIjtcbiAgRXh0ZW5zaW9uVHlwZTJbXCJXZWJHTFBpcGVzQWRhcHRvclwiXSA9IFwid2ViZ2wtcGlwZXMtYWRhcHRvclwiO1xuICBFeHRlbnNpb25UeXBlMltcIldlYkdMU3lzdGVtXCJdID0gXCJ3ZWJnbC1zeXN0ZW1cIjtcbiAgRXh0ZW5zaW9uVHlwZTJbXCJXZWJHTExvYWRlclwiXSA9IFwid2ViZ2wtbG9hZGVyXCI7XG4gIEV4dGVuc2lvblR5cGUyW1wiV2ViR1BVUGlwZXNcIl0gPSBcIndlYmdwdS1waXBlc1wiO1xuICBFeHRlbnNpb25UeXBlMltcIldlYkdQVVBpcGVzQWRhcHRvclwiXSA9IFwid2ViZ3B1LXBpcGVzLWFkYXB0b3JcIjtcbiAgRXh0ZW5zaW9uVHlwZTJbXCJXZWJHUFVTeXN0ZW1cIl0gPSBcIndlYmdwdS1zeXN0ZW1cIjtcbiAgRXh0ZW5zaW9uVHlwZTJbXCJXZWJHUFVMb2FkZXJcIl0gPSBcIndlYmdwdS1sb2FkZXJcIjtcbiAgRXh0ZW5zaW9uVHlwZTJbXCJDYW52YXNTeXN0ZW1cIl0gPSBcImNhbnZhcy1zeXN0ZW1cIjtcbiAgRXh0ZW5zaW9uVHlwZTJbXCJDYW52YXNQaXBlc0FkYXB0b3JcIl0gPSBcImNhbnZhcy1waXBlcy1hZGFwdG9yXCI7XG4gIEV4dGVuc2lvblR5cGUyW1wiQ2FudmFzUGlwZXNcIl0gPSBcImNhbnZhcy1waXBlc1wiO1xuICBFeHRlbnNpb25UeXBlMltcIkNhbnZhc0xvYWRlclwiXSA9IFwiY2FudmFzLWxvYWRlclwiO1xuICBFeHRlbnNpb25UeXBlMltcIkFzc2V0XCJdID0gXCJhc3NldFwiO1xuICBFeHRlbnNpb25UeXBlMltcIkxvYWRQYXJzZXJcIl0gPSBcImxvYWQtcGFyc2VyXCI7XG4gIEV4dGVuc2lvblR5cGUyW1wiUmVzb2x2ZVBhcnNlclwiXSA9IFwicmVzb2x2ZS1wYXJzZXJcIjtcbiAgRXh0ZW5zaW9uVHlwZTJbXCJDYWNoZVBhcnNlclwiXSA9IFwiY2FjaGUtcGFyc2VyXCI7XG4gIEV4dGVuc2lvblR5cGUyW1wiRGV0ZWN0aW9uUGFyc2VyXCJdID0gXCJkZXRlY3Rpb24tcGFyc2VyXCI7XG4gIEV4dGVuc2lvblR5cGUyW1wiTWFza0VmZmVjdFwiXSA9IFwibWFzay1lZmZlY3RcIjtcbiAgRXh0ZW5zaW9uVHlwZTJbXCJCbGVuZE1vZGVcIl0gPSBcImJsZW5kLW1vZGVcIjtcbiAgRXh0ZW5zaW9uVHlwZTJbXCJUZXh0dXJlU291cmNlXCJdID0gXCJ0ZXh0dXJlLXNvdXJjZVwiO1xuICBFeHRlbnNpb25UeXBlMltcIlRleHR1cmVVcGxvYWRlcldlYkdMXCJdID0gXCJ0ZXh0dXJlLXVwbG9hZGVyLXdlYmdsXCI7XG4gIEV4dGVuc2lvblR5cGUyW1wiVGV4dHVyZVVwbG9hZGVyV2ViR1BVXCJdID0gXCJ0ZXh0dXJlLXVwbG9hZGVyLXdlYmdwdVwiO1xuICBFeHRlbnNpb25UeXBlMltcIkVudmlyb25tZW50XCJdID0gXCJlbnZpcm9ubWVudFwiO1xuICBFeHRlbnNpb25UeXBlMltcIlNoYXBlQnVpbGRlclwiXSA9IFwic2hhcGUtYnVpbGRlclwiO1xuICBFeHRlbnNpb25UeXBlMltcIkJhdGNoZXJcIl0gPSBcImJhdGNoZXJcIjtcbiAgcmV0dXJuIEV4dGVuc2lvblR5cGUyO1xufSkoRXh0ZW5zaW9uVHlwZSB8fCB7fSk7XG5jb25zdCBub3JtYWxpemVFeHRlbnNpb24gPSAoZXh0KSA9PiB7XG4gIGlmICh0eXBlb2YgZXh0ID09PSBcImZ1bmN0aW9uXCIgfHwgdHlwZW9mIGV4dCA9PT0gXCJvYmplY3RcIiAmJiBleHQuZXh0ZW5zaW9uKSB7XG4gICAgaWYgKCFleHQuZXh0ZW5zaW9uKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJFeHRlbnNpb24gY2xhc3MgbXVzdCBoYXZlIGFuIGV4dGVuc2lvbiBvYmplY3RcIik7XG4gICAgfVxuICAgIGNvbnN0IG1ldGFkYXRhID0gdHlwZW9mIGV4dC5leHRlbnNpb24gIT09IFwib2JqZWN0XCIgPyB7IHR5cGU6IGV4dC5leHRlbnNpb24gfSA6IGV4dC5leHRlbnNpb247XG4gICAgZXh0ID0geyAuLi5tZXRhZGF0YSwgcmVmOiBleHQgfTtcbiAgfVxuICBpZiAodHlwZW9mIGV4dCA9PT0gXCJvYmplY3RcIikge1xuICAgIGV4dCA9IHsgLi4uZXh0IH07XG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBleHRlbnNpb24gdHlwZVwiKTtcbiAgfVxuICBpZiAodHlwZW9mIGV4dC50eXBlID09PSBcInN0cmluZ1wiKSB7XG4gICAgZXh0LnR5cGUgPSBbZXh0LnR5cGVdO1xuICB9XG4gIHJldHVybiBleHQ7XG59O1xuY29uc3Qgbm9ybWFsaXplRXh0ZW5zaW9uUHJpb3JpdHkgPSAoZXh0LCBkZWZhdWx0UHJpb3JpdHkpID0+IG5vcm1hbGl6ZUV4dGVuc2lvbihleHQpLnByaW9yaXR5ID8/IGRlZmF1bHRQcmlvcml0eTtcbmNvbnN0IGV4dGVuc2lvbnMgPSB7XG4gIC8qKiBAaWdub3JlICovXG4gIF9hZGRIYW5kbGVyczoge30sXG4gIC8qKiBAaWdub3JlICovXG4gIF9yZW1vdmVIYW5kbGVyczoge30sXG4gIC8qKiBAaWdub3JlICovXG4gIF9xdWV1ZToge30sXG4gIC8qKlxuICAgKiBSZW1vdmUgZXh0ZW5zaW9ucyBmcm9tIFBpeGlKUy5cbiAgICogQHBhcmFtIGV4dGVuc2lvbnMgLSBFeHRlbnNpb25zIHRvIGJlIHJlbW92ZWQuIENhbiBiZTpcbiAgICogLSBFeHRlbnNpb24gY2xhc3Mgd2l0aCBzdGF0aWMgYGV4dGVuc2lvbmAgcHJvcGVydHlcbiAgICogLSBFeHRlbnNpb24gZm9ybWF0IG9iamVjdCB3aXRoIGB0eXBlYCBhbmQgYHJlZmBcbiAgICogLSBNdWx0aXBsZSBleHRlbnNpb25zIGFzIHNlcGFyYXRlIGFyZ3VtZW50c1xuICAgKiBAcmV0dXJucyB7ZXh0ZW5zaW9uc30gdGhpcyBmb3IgY2hhaW5pbmdcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gUmVtb3ZlIGEgc2luZ2xlIGV4dGVuc2lvblxuICAgKiBleHRlbnNpb25zLnJlbW92ZShNeVJlbmRlcmVyUGx1Z2luKTtcbiAgICpcbiAgICogLy8gUmVtb3ZlIG11bHRpcGxlIGV4dGVuc2lvbnNcbiAgICogZXh0ZW5zaW9ucy5yZW1vdmUoXG4gICAqICAgICBNeVJlbmRlcmVyUGx1Z2luLFxuICAgKiAgICAgTXlTeXN0ZW1QbHVnaW5cbiAgICogKTtcbiAgICogYGBgXG4gICAqIEBzZWUge0BsaW5rIEV4dGVuc2lvblR5cGV9IEZvciBhdmFpbGFibGUgZXh0ZW5zaW9uIHR5cGVzXG4gICAqIEBzZWUge0BsaW5rIEV4dGVuc2lvbkZvcm1hdH0gRm9yIGV4dGVuc2lvbiBmb3JtYXQgZGV0YWlsc1xuICAgKi9cbiAgcmVtb3ZlKC4uLmV4dGVuc2lvbnMyKSB7XG4gICAgZXh0ZW5zaW9uczIubWFwKG5vcm1hbGl6ZUV4dGVuc2lvbikuZm9yRWFjaCgoZXh0KSA9PiB7XG4gICAgICBleHQudHlwZS5mb3JFYWNoKCh0eXBlKSA9PiB0aGlzLl9yZW1vdmVIYW5kbGVyc1t0eXBlXT8uKGV4dCkpO1xuICAgIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9LFxuICAvKipcbiAgICogUmVnaXN0ZXIgbmV3IGV4dGVuc2lvbnMgd2l0aCBQaXhpSlMuIEV4dGVuc2lvbnMgY2FuIGJlIHJlZ2lzdGVyZWQgaW4gbXVsdGlwbGUgZm9ybWF0czpcbiAgICogLSBBcyBhIGNsYXNzIHdpdGggYSBzdGF0aWMgYGV4dGVuc2lvbmAgcHJvcGVydHlcbiAgICogLSBBcyBhbiBleHRlbnNpb24gZm9ybWF0IG9iamVjdFxuICAgKiAtIEFzIG11bHRpcGxlIGV4dGVuc2lvbnMgcGFzc2VkIGFzIHNlcGFyYXRlIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0gZXh0ZW5zaW9ucyAtIEV4dGVuc2lvbnMgdG8gYWRkIHRvIFBpeGlKUy4gRWFjaCBjYW4gYmU6XG4gICAqIC0gQSBjbGFzcyB3aXRoIHN0YXRpYyBgZXh0ZW5zaW9uYCBwcm9wZXJ0eVxuICAgKiAtIEFuIGV4dGVuc2lvbiBmb3JtYXQgb2JqZWN0IHdpdGggYHR5cGVgIGFuZCBgcmVmYFxuICAgKiAtIE11bHRpcGxlIGV4dGVuc2lvbnMgYXMgc2VwYXJhdGUgYXJndW1lbnRzXG4gICAqIEByZXR1cm5zIFRoaXMgZXh0ZW5zaW9ucyBpbnN0YW5jZSBmb3IgY2hhaW5pbmdcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gUmVnaXN0ZXIgYSBzaW1wbGUgZXh0ZW5zaW9uXG4gICAqIGV4dGVuc2lvbnMuYWRkKE15UmVuZGVyZXJQbHVnaW4pO1xuICAgKlxuICAgKiAvLyBSZWdpc3RlciBtdWx0aXBsZSBleHRlbnNpb25zXG4gICAqIGV4dGVuc2lvbnMuYWRkKFxuICAgKiAgICAgTXlSZW5kZXJlclBsdWdpbixcbiAgICogICAgIE15U3lzdGVtUGx1Z2luLFxuICAgKiB9KTtcbiAgICogYGBgXG4gICAqIEBzZWUge0BsaW5rIEV4dGVuc2lvblR5cGV9IEZvciBhdmFpbGFibGUgZXh0ZW5zaW9uIHR5cGVzXG4gICAqIEBzZWUge0BsaW5rIEV4dGVuc2lvbkZvcm1hdH0gRm9yIGV4dGVuc2lvbiBmb3JtYXQgZGV0YWlsc1xuICAgKiBAc2VlIHtAbGluayBleHRlbnNpb25zLnJlbW92ZX0gRm9yIHJlbW92aW5nIHJlZ2lzdGVyZWQgZXh0ZW5zaW9uc1xuICAgKi9cbiAgYWRkKC4uLmV4dGVuc2lvbnMyKSB7XG4gICAgZXh0ZW5zaW9uczIubWFwKG5vcm1hbGl6ZUV4dGVuc2lvbikuZm9yRWFjaCgoZXh0KSA9PiB7XG4gICAgICBleHQudHlwZS5mb3JFYWNoKCh0eXBlKSA9PiB7XG4gICAgICAgIGNvbnN0IGhhbmRsZXJzID0gdGhpcy5fYWRkSGFuZGxlcnM7XG4gICAgICAgIGNvbnN0IHF1ZXVlID0gdGhpcy5fcXVldWU7XG4gICAgICAgIGlmICghaGFuZGxlcnNbdHlwZV0pIHtcbiAgICAgICAgICBxdWV1ZVt0eXBlXSA9IHF1ZXVlW3R5cGVdIHx8IFtdO1xuICAgICAgICAgIHF1ZXVlW3R5cGVdPy5wdXNoKGV4dCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaGFuZGxlcnNbdHlwZV0/LihleHQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcztcbiAgfSxcbiAgLyoqXG4gICAqIEludGVybmFsIG1ldGhvZCB0byBoYW5kbGUgZXh0ZW5zaW9ucyBieSBuYW1lLlxuICAgKiBAcGFyYW0gdHlwZSAtIFRoZSBleHRlbnNpb24gdHlwZS5cbiAgICogQHBhcmFtIG9uQWRkICAtIEZ1bmN0aW9uIGhhbmRsZXIgd2hlbiBleHRlbnNpb25zIGFyZSBhZGRlZC9yZWdpc3RlcmVkIHtAbGluayBTdHJpY3RFeHRlbnNpb25Gb3JtYXR9LlxuICAgKiBAcGFyYW0gb25SZW1vdmUgIC0gRnVuY3Rpb24gaGFuZGxlciB3aGVuIGV4dGVuc2lvbnMgYXJlIHJlbW92ZWQvdW5yZWdpc3RlcmVkIHtAbGluayBTdHJpY3RFeHRlbnNpb25Gb3JtYXR9LlxuICAgKiBAcmV0dXJucyB0aGlzIGZvciBjaGFpbmluZy5cbiAgICogQGludGVybmFsXG4gICAqIEBpZ25vcmVcbiAgICovXG4gIGhhbmRsZSh0eXBlLCBvbkFkZCwgb25SZW1vdmUpIHtcbiAgICBjb25zdCBhZGRIYW5kbGVycyA9IHRoaXMuX2FkZEhhbmRsZXJzO1xuICAgIGNvbnN0IHJlbW92ZUhhbmRsZXJzID0gdGhpcy5fcmVtb3ZlSGFuZGxlcnM7XG4gICAgaWYgKGFkZEhhbmRsZXJzW3R5cGVdIHx8IHJlbW92ZUhhbmRsZXJzW3R5cGVdKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4dGVuc2lvbiB0eXBlICR7dHlwZX0gYWxyZWFkeSBoYXMgYSBoYW5kbGVyYCk7XG4gICAgfVxuICAgIGFkZEhhbmRsZXJzW3R5cGVdID0gb25BZGQ7XG4gICAgcmVtb3ZlSGFuZGxlcnNbdHlwZV0gPSBvblJlbW92ZTtcbiAgICBjb25zdCBxdWV1ZSA9IHRoaXMuX3F1ZXVlO1xuICAgIGlmIChxdWV1ZVt0eXBlXSkge1xuICAgICAgcXVldWVbdHlwZV0/LmZvckVhY2goKGV4dCkgPT4gb25BZGQoZXh0KSk7XG4gICAgICBkZWxldGUgcXVldWVbdHlwZV07XG4gICAgfVxuICAgIHJldHVybiB0aGlzO1xuICB9LFxuICAvKipcbiAgICogSGFuZGxlIGEgdHlwZSwgYnV0IHVzaW5nIGEgbWFwIGJ5IGBuYW1lYCBwcm9wZXJ0eS5cbiAgICogQHBhcmFtIHR5cGUgLSBUeXBlIG9mIGV4dGVuc2lvbiB0byBoYW5kbGUuXG4gICAqIEBwYXJhbSBtYXAgLSBUaGUgb2JqZWN0IG1hcCBvZiBuYW1lZCBleHRlbnNpb25zLlxuICAgKiBAcmV0dXJucyB0aGlzIGZvciBjaGFpbmluZy5cbiAgICogQGlnbm9yZVxuICAgKi9cbiAgaGFuZGxlQnlNYXAodHlwZSwgbWFwKSB7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlKFxuICAgICAgdHlwZSxcbiAgICAgIChleHRlbnNpb24pID0+IHtcbiAgICAgICAgaWYgKGV4dGVuc2lvbi5uYW1lKSB7XG4gICAgICAgICAgbWFwW2V4dGVuc2lvbi5uYW1lXSA9IGV4dGVuc2lvbi5yZWY7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICAoZXh0ZW5zaW9uKSA9PiB7XG4gICAgICAgIGlmIChleHRlbnNpb24ubmFtZSkge1xuICAgICAgICAgIGRlbGV0ZSBtYXBbZXh0ZW5zaW9uLm5hbWVdO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgKTtcbiAgfSxcbiAgLyoqXG4gICAqIEhhbmRsZSBhIHR5cGUsIGJ1dCB1c2luZyBhIGxpc3Qgb2YgZXh0ZW5zaW9ucyB3aXRoIGEgYG5hbWVgIHByb3BlcnR5LlxuICAgKiBAcGFyYW0gdHlwZSAtIFR5cGUgb2YgZXh0ZW5zaW9uIHRvIGhhbmRsZS5cbiAgICogQHBhcmFtIG1hcCAtIFRoZSBhcnJheSBvZiBuYW1lZCBleHRlbnNpb25zLlxuICAgKiBAcGFyYW0gZGVmYXVsdFByaW9yaXR5IC0gRmFsbGJhY2sgcHJpb3JpdHkgaWYgbm9uZSBpcyBkZWZpbmVkLlxuICAgKiBAcmV0dXJucyB0aGlzIGZvciBjaGFpbmluZy5cbiAgICogQGlnbm9yZVxuICAgKi9cbiAgaGFuZGxlQnlOYW1lZExpc3QodHlwZSwgbWFwLCBkZWZhdWx0UHJpb3JpdHkgPSAtMSkge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZShcbiAgICAgIHR5cGUsXG4gICAgICAoZXh0ZW5zaW9uKSA9PiB7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gbWFwLmZpbmRJbmRleCgoaXRlbSkgPT4gaXRlbS5uYW1lID09PSBleHRlbnNpb24ubmFtZSk7XG4gICAgICAgIGlmIChpbmRleCA+PSAwKSByZXR1cm47XG4gICAgICAgIG1hcC5wdXNoKHsgbmFtZTogZXh0ZW5zaW9uLm5hbWUsIHZhbHVlOiBleHRlbnNpb24ucmVmIH0pO1xuICAgICAgICBtYXAuc29ydCgoYSwgYikgPT4gbm9ybWFsaXplRXh0ZW5zaW9uUHJpb3JpdHkoYi52YWx1ZSwgZGVmYXVsdFByaW9yaXR5KSAtIG5vcm1hbGl6ZUV4dGVuc2lvblByaW9yaXR5KGEudmFsdWUsIGRlZmF1bHRQcmlvcml0eSkpO1xuICAgICAgfSxcbiAgICAgIChleHRlbnNpb24pID0+IHtcbiAgICAgICAgY29uc3QgaW5kZXggPSBtYXAuZmluZEluZGV4KChpdGVtKSA9PiBpdGVtLm5hbWUgPT09IGV4dGVuc2lvbi5uYW1lKTtcbiAgICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICAgIG1hcC5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgKTtcbiAgfSxcbiAgLyoqXG4gICAqIEhhbmRsZSBhIHR5cGUsIGJ1dCB1c2luZyBhIGxpc3Qgb2YgZXh0ZW5zaW9ucy5cbiAgICogQHBhcmFtIHR5cGUgLSBUeXBlIG9mIGV4dGVuc2lvbiB0byBoYW5kbGUuXG4gICAqIEBwYXJhbSBsaXN0IC0gVGhlIGxpc3Qgb2YgZXh0ZW5zaW9ucy5cbiAgICogQHBhcmFtIGRlZmF1bHRQcmlvcml0eSAtIFRoZSBkZWZhdWx0IHByaW9yaXR5IHRvIHVzZSBpZiBub25lIGlzIHNwZWNpZmllZC5cbiAgICogQHJldHVybnMgdGhpcyBmb3IgY2hhaW5pbmcuXG4gICAqIEBpZ25vcmVcbiAgICovXG4gIGhhbmRsZUJ5TGlzdCh0eXBlLCBsaXN0LCBkZWZhdWx0UHJpb3JpdHkgPSAtMSkge1xuICAgIHJldHVybiB0aGlzLmhhbmRsZShcbiAgICAgIHR5cGUsXG4gICAgICAoZXh0ZW5zaW9uKSA9PiB7XG4gICAgICAgIGlmIChsaXN0LmluY2x1ZGVzKGV4dGVuc2lvbi5yZWYpKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGxpc3QucHVzaChleHRlbnNpb24ucmVmKTtcbiAgICAgICAgbGlzdC5zb3J0KChhLCBiKSA9PiBub3JtYWxpemVFeHRlbnNpb25Qcmlvcml0eShiLCBkZWZhdWx0UHJpb3JpdHkpIC0gbm9ybWFsaXplRXh0ZW5zaW9uUHJpb3JpdHkoYSwgZGVmYXVsdFByaW9yaXR5KSk7XG4gICAgICB9LFxuICAgICAgKGV4dGVuc2lvbikgPT4ge1xuICAgICAgICBjb25zdCBpbmRleCA9IGxpc3QuaW5kZXhPZihleHRlbnNpb24ucmVmKTtcbiAgICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICAgIGxpc3Quc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gIH0sXG4gIC8qKlxuICAgKiBNaXhpbiB0aGUgc291cmNlIG9iamVjdChzKSBwcm9wZXJ0aWVzIGludG8gdGhlIHRhcmdldCBjbGFzcydzIHByb3RvdHlwZS5cbiAgICogQ29waWVzIGFsbCBwcm9wZXJ0eSBkZXNjcmlwdG9ycyBmcm9tIHNvdXJjZSBvYmplY3RzIHRvIHRoZSB0YXJnZXQncyBwcm90b3R5cGUuXG4gICAqIEBwYXJhbSBUYXJnZXQgLSBUaGUgdGFyZ2V0IGNsYXNzIHRvIG1peCBwcm9wZXJ0aWVzIGludG9cbiAgICogQHBhcmFtIHNvdXJjZXMgLSBPbmUgb3IgbW9yZSBzb3VyY2Ugb2JqZWN0cyBjb250YWluaW5nIHByb3BlcnRpZXMgdG8gbWl4IGluXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIENyZWF0ZSBhIG1peGluIHdpdGggc2hhcmVkIHByb3BlcnRpZXNcbiAgICogY29uc3QgbW92ZWFibGUgPSB7XG4gICAqICAgICB4OiAwLFxuICAgKiAgICAgeTogMCxcbiAgICogICAgIG1vdmUoeDogbnVtYmVyLCB5OiBudW1iZXIpIHtcbiAgICogICAgICAgICB0aGlzLnggKz0geDtcbiAgICogICAgICAgICB0aGlzLnkgKz0geTtcbiAgICogICAgIH1cbiAgICogfTtcbiAgICpcbiAgICogLy8gQ3JlYXRlIGEgbWl4aW4gd2l0aCBjb21wdXRlZCBwcm9wZXJ0aWVzXG4gICAqIGNvbnN0IHNjYWxhYmxlID0ge1xuICAgKiAgICAgc2NhbGU6IDEsXG4gICAqICAgICBnZXQgc2NhbGVkKCkge1xuICAgKiAgICAgICAgIHJldHVybiB0aGlzLnNjYWxlID4gMTtcbiAgICogICAgIH1cbiAgICogfTtcbiAgICpcbiAgICogLy8gQXBwbHkgbWl4aW5zIHRvIGEgY2xhc3NcbiAgICogZXh0ZW5zaW9ucy5taXhpbihTcHJpdGUsIG1vdmVhYmxlLCBzY2FsYWJsZSk7XG4gICAqXG4gICAqIC8vIFVzZSBtaXhlZC1pbiBwcm9wZXJ0aWVzXG4gICAqIGNvbnN0IHNwcml0ZSA9IG5ldyBTcHJpdGUoKTtcbiAgICogc3ByaXRlLm1vdmUoMTAsIDIwKTtcbiAgICogY29uc29sZS5sb2coc3ByaXRlLngsIHNwcml0ZS55KTsgLy8gMTAsIDIwXG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIENvcGllcyBhbGwgcHJvcGVydGllcyBpbmNsdWRpbmcgZ2V0dGVycy9zZXR0ZXJzXG4gICAqIC0gRG9lcyBub3QgbW9kaWZ5IHNvdXJjZSBvYmplY3RzXG4gICAqIC0gUHJlc2VydmVzIHByb3BlcnR5IGRlc2NyaXB0b3JzXG4gICAqIEBzZWUge0BsaW5rIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzfSBGb3IgZGV0YWlscyBvbiBwcm9wZXJ0eSBkZXNjcmlwdG9yc1xuICAgKiBAc2VlIHtAbGluayBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yc30gRm9yIGRldGFpbHMgb24gcHJvcGVydHkgY29weWluZ1xuICAgKi9cbiAgbWl4aW4oVGFyZ2V0LCAuLi5zb3VyY2VzKSB7XG4gICAgZm9yIChjb25zdCBzb3VyY2Ugb2Ygc291cmNlcykge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoVGFyZ2V0LnByb3RvdHlwZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMoc291cmNlKSk7XG4gICAgfVxuICB9XG59O1xuXG5leHBvcnQgeyBFeHRlbnNpb25UeXBlLCBleHRlbnNpb25zLCBub3JtYWxpemVFeHRlbnNpb25Qcmlvcml0eSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9RXh0ZW5zaW9ucy5tanMubWFwXG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBoYXMgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5XG4gICwgcHJlZml4ID0gJ34nO1xuXG4vKipcbiAqIENvbnN0cnVjdG9yIHRvIGNyZWF0ZSBhIHN0b3JhZ2UgZm9yIG91ciBgRUVgIG9iamVjdHMuXG4gKiBBbiBgRXZlbnRzYCBpbnN0YW5jZSBpcyBhIHBsYWluIG9iamVjdCB3aG9zZSBwcm9wZXJ0aWVzIGFyZSBldmVudCBuYW1lcy5cbiAqXG4gKiBAY29uc3RydWN0b3JcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIEV2ZW50cygpIHt9XG5cbi8vXG4vLyBXZSB0cnkgdG8gbm90IGluaGVyaXQgZnJvbSBgT2JqZWN0LnByb3RvdHlwZWAuIEluIHNvbWUgZW5naW5lcyBjcmVhdGluZyBhblxuLy8gaW5zdGFuY2UgaW4gdGhpcyB3YXkgaXMgZmFzdGVyIHRoYW4gY2FsbGluZyBgT2JqZWN0LmNyZWF0ZShudWxsKWAgZGlyZWN0bHkuXG4vLyBJZiBgT2JqZWN0LmNyZWF0ZShudWxsKWAgaXMgbm90IHN1cHBvcnRlZCB3ZSBwcmVmaXggdGhlIGV2ZW50IG5hbWVzIHdpdGggYVxuLy8gY2hhcmFjdGVyIHRvIG1ha2Ugc3VyZSB0aGF0IHRoZSBidWlsdC1pbiBvYmplY3QgcHJvcGVydGllcyBhcmUgbm90XG4vLyBvdmVycmlkZGVuIG9yIHVzZWQgYXMgYW4gYXR0YWNrIHZlY3Rvci5cbi8vXG5pZiAoT2JqZWN0LmNyZWF0ZSkge1xuICBFdmVudHMucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblxuICAvL1xuICAvLyBUaGlzIGhhY2sgaXMgbmVlZGVkIGJlY2F1c2UgdGhlIGBfX3Byb3RvX19gIHByb3BlcnR5IGlzIHN0aWxsIGluaGVyaXRlZCBpblxuICAvLyBzb21lIG9sZCBicm93c2VycyBsaWtlIEFuZHJvaWQgNCwgaVBob25lIDUuMSwgT3BlcmEgMTEgYW5kIFNhZmFyaSA1LlxuICAvL1xuICBpZiAoIW5ldyBFdmVudHMoKS5fX3Byb3RvX18pIHByZWZpeCA9IGZhbHNlO1xufVxuXG4vKipcbiAqIFJlcHJlc2VudGF0aW9uIG9mIGEgc2luZ2xlIGV2ZW50IGxpc3RlbmVyLlxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIFRoZSBsaXN0ZW5lciBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7Kn0gY29udGV4dCBUaGUgY29udGV4dCB0byBpbnZva2UgdGhlIGxpc3RlbmVyIHdpdGguXG4gKiBAcGFyYW0ge0Jvb2xlYW59IFtvbmNlPWZhbHNlXSBTcGVjaWZ5IGlmIHRoZSBsaXN0ZW5lciBpcyBhIG9uZS10aW1lIGxpc3RlbmVyLlxuICogQGNvbnN0cnVjdG9yXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBFRShmbiwgY29udGV4dCwgb25jZSkge1xuICB0aGlzLmZuID0gZm47XG4gIHRoaXMuY29udGV4dCA9IGNvbnRleHQ7XG4gIHRoaXMub25jZSA9IG9uY2UgfHwgZmFsc2U7XG59XG5cbi8qKlxuICogQWRkIGEgbGlzdGVuZXIgZm9yIGEgZ2l2ZW4gZXZlbnQuXG4gKlxuICogQHBhcmFtIHtFdmVudEVtaXR0ZXJ9IGVtaXR0ZXIgUmVmZXJlbmNlIHRvIHRoZSBgRXZlbnRFbWl0dGVyYCBpbnN0YW5jZS5cbiAqIEBwYXJhbSB7KFN0cmluZ3xTeW1ib2wpfSBldmVudCBUaGUgZXZlbnQgbmFtZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIFRoZSBsaXN0ZW5lciBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7Kn0gY29udGV4dCBUaGUgY29udGV4dCB0byBpbnZva2UgdGhlIGxpc3RlbmVyIHdpdGguXG4gKiBAcGFyYW0ge0Jvb2xlYW59IG9uY2UgU3BlY2lmeSBpZiB0aGUgbGlzdGVuZXIgaXMgYSBvbmUtdGltZSBsaXN0ZW5lci5cbiAqIEByZXR1cm5zIHtFdmVudEVtaXR0ZXJ9XG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBhZGRMaXN0ZW5lcihlbWl0dGVyLCBldmVudCwgZm4sIGNvbnRleHQsIG9uY2UpIHtcbiAgaWYgKHR5cGVvZiBmbiAhPT0gJ2Z1bmN0aW9uJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RoZSBsaXN0ZW5lciBtdXN0IGJlIGEgZnVuY3Rpb24nKTtcbiAgfVxuXG4gIHZhciBsaXN0ZW5lciA9IG5ldyBFRShmbiwgY29udGV4dCB8fCBlbWl0dGVyLCBvbmNlKVxuICAgICwgZXZ0ID0gcHJlZml4ID8gcHJlZml4ICsgZXZlbnQgOiBldmVudDtcblxuICBpZiAoIWVtaXR0ZXIuX2V2ZW50c1tldnRdKSBlbWl0dGVyLl9ldmVudHNbZXZ0XSA9IGxpc3RlbmVyLCBlbWl0dGVyLl9ldmVudHNDb3VudCsrO1xuICBlbHNlIGlmICghZW1pdHRlci5fZXZlbnRzW2V2dF0uZm4pIGVtaXR0ZXIuX2V2ZW50c1tldnRdLnB1c2gobGlzdGVuZXIpO1xuICBlbHNlIGVtaXR0ZXIuX2V2ZW50c1tldnRdID0gW2VtaXR0ZXIuX2V2ZW50c1tldnRdLCBsaXN0ZW5lcl07XG5cbiAgcmV0dXJuIGVtaXR0ZXI7XG59XG5cbi8qKlxuICogQ2xlYXIgZXZlbnQgYnkgbmFtZS5cbiAqXG4gKiBAcGFyYW0ge0V2ZW50RW1pdHRlcn0gZW1pdHRlciBSZWZlcmVuY2UgdG8gdGhlIGBFdmVudEVtaXR0ZXJgIGluc3RhbmNlLlxuICogQHBhcmFtIHsoU3RyaW5nfFN5bWJvbCl9IGV2dCBUaGUgRXZlbnQgbmFtZS5cbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIGNsZWFyRXZlbnQoZW1pdHRlciwgZXZ0KSB7XG4gIGlmICgtLWVtaXR0ZXIuX2V2ZW50c0NvdW50ID09PSAwKSBlbWl0dGVyLl9ldmVudHMgPSBuZXcgRXZlbnRzKCk7XG4gIGVsc2UgZGVsZXRlIGVtaXR0ZXIuX2V2ZW50c1tldnRdO1xufVxuXG4vKipcbiAqIE1pbmltYWwgYEV2ZW50RW1pdHRlcmAgaW50ZXJmYWNlIHRoYXQgaXMgbW9sZGVkIGFnYWluc3QgdGhlIE5vZGUuanNcbiAqIGBFdmVudEVtaXR0ZXJgIGludGVyZmFjZS5cbiAqXG4gKiBAY29uc3RydWN0b3JcbiAqIEBwdWJsaWNcbiAqL1xuZnVuY3Rpb24gRXZlbnRFbWl0dGVyKCkge1xuICB0aGlzLl9ldmVudHMgPSBuZXcgRXZlbnRzKCk7XG4gIHRoaXMuX2V2ZW50c0NvdW50ID0gMDtcbn1cblxuLyoqXG4gKiBSZXR1cm4gYW4gYXJyYXkgbGlzdGluZyB0aGUgZXZlbnRzIGZvciB3aGljaCB0aGUgZW1pdHRlciBoYXMgcmVnaXN0ZXJlZFxuICogbGlzdGVuZXJzLlxuICpcbiAqIEByZXR1cm5zIHtBcnJheX1cbiAqIEBwdWJsaWNcbiAqL1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5ldmVudE5hbWVzID0gZnVuY3Rpb24gZXZlbnROYW1lcygpIHtcbiAgdmFyIG5hbWVzID0gW11cbiAgICAsIGV2ZW50c1xuICAgICwgbmFtZTtcblxuICBpZiAodGhpcy5fZXZlbnRzQ291bnQgPT09IDApIHJldHVybiBuYW1lcztcblxuICBmb3IgKG5hbWUgaW4gKGV2ZW50cyA9IHRoaXMuX2V2ZW50cykpIHtcbiAgICBpZiAoaGFzLmNhbGwoZXZlbnRzLCBuYW1lKSkgbmFtZXMucHVzaChwcmVmaXggPyBuYW1lLnNsaWNlKDEpIDogbmFtZSk7XG4gIH1cblxuICBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykge1xuICAgIHJldHVybiBuYW1lcy5jb25jYXQoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhldmVudHMpKTtcbiAgfVxuXG4gIHJldHVybiBuYW1lcztcbn07XG5cbi8qKlxuICogUmV0dXJuIHRoZSBsaXN0ZW5lcnMgcmVnaXN0ZXJlZCBmb3IgYSBnaXZlbiBldmVudC5cbiAqXG4gKiBAcGFyYW0geyhTdHJpbmd8U3ltYm9sKX0gZXZlbnQgVGhlIGV2ZW50IG5hbWUuXG4gKiBAcmV0dXJucyB7QXJyYXl9IFRoZSByZWdpc3RlcmVkIGxpc3RlbmVycy5cbiAqIEBwdWJsaWNcbiAqL1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5saXN0ZW5lcnMgPSBmdW5jdGlvbiBsaXN0ZW5lcnMoZXZlbnQpIHtcbiAgdmFyIGV2dCA9IHByZWZpeCA/IHByZWZpeCArIGV2ZW50IDogZXZlbnRcbiAgICAsIGhhbmRsZXJzID0gdGhpcy5fZXZlbnRzW2V2dF07XG5cbiAgaWYgKCFoYW5kbGVycykgcmV0dXJuIFtdO1xuICBpZiAoaGFuZGxlcnMuZm4pIHJldHVybiBbaGFuZGxlcnMuZm5dO1xuXG4gIGZvciAodmFyIGkgPSAwLCBsID0gaGFuZGxlcnMubGVuZ3RoLCBlZSA9IG5ldyBBcnJheShsKTsgaSA8IGw7IGkrKykge1xuICAgIGVlW2ldID0gaGFuZGxlcnNbaV0uZm47XG4gIH1cblxuICByZXR1cm4gZWU7XG59O1xuXG4vKipcbiAqIFJldHVybiB0aGUgbnVtYmVyIG9mIGxpc3RlbmVycyBsaXN0ZW5pbmcgdG8gYSBnaXZlbiBldmVudC5cbiAqXG4gKiBAcGFyYW0geyhTdHJpbmd8U3ltYm9sKX0gZXZlbnQgVGhlIGV2ZW50IG5hbWUuXG4gKiBAcmV0dXJucyB7TnVtYmVyfSBUaGUgbnVtYmVyIG9mIGxpc3RlbmVycy5cbiAqIEBwdWJsaWNcbiAqL1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5saXN0ZW5lckNvdW50ID0gZnVuY3Rpb24gbGlzdGVuZXJDb3VudChldmVudCkge1xuICB2YXIgZXZ0ID0gcHJlZml4ID8gcHJlZml4ICsgZXZlbnQgOiBldmVudFxuICAgICwgbGlzdGVuZXJzID0gdGhpcy5fZXZlbnRzW2V2dF07XG5cbiAgaWYgKCFsaXN0ZW5lcnMpIHJldHVybiAwO1xuICBpZiAobGlzdGVuZXJzLmZuKSByZXR1cm4gMTtcbiAgcmV0dXJuIGxpc3RlbmVycy5sZW5ndGg7XG59O1xuXG4vKipcbiAqIENhbGxzIGVhY2ggb2YgdGhlIGxpc3RlbmVycyByZWdpc3RlcmVkIGZvciBhIGdpdmVuIGV2ZW50LlxuICpcbiAqIEBwYXJhbSB7KFN0cmluZ3xTeW1ib2wpfSBldmVudCBUaGUgZXZlbnQgbmFtZS5cbiAqIEByZXR1cm5zIHtCb29sZWFufSBgdHJ1ZWAgaWYgdGhlIGV2ZW50IGhhZCBsaXN0ZW5lcnMsIGVsc2UgYGZhbHNlYC5cbiAqIEBwdWJsaWNcbiAqL1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5lbWl0ID0gZnVuY3Rpb24gZW1pdChldmVudCwgYTEsIGEyLCBhMywgYTQsIGE1KSB7XG4gIHZhciBldnQgPSBwcmVmaXggPyBwcmVmaXggKyBldmVudCA6IGV2ZW50O1xuXG4gIGlmICghdGhpcy5fZXZlbnRzW2V2dF0pIHJldHVybiBmYWxzZTtcblxuICB2YXIgbGlzdGVuZXJzID0gdGhpcy5fZXZlbnRzW2V2dF1cbiAgICAsIGxlbiA9IGFyZ3VtZW50cy5sZW5ndGhcbiAgICAsIGFyZ3NcbiAgICAsIGk7XG5cbiAgaWYgKGxpc3RlbmVycy5mbikge1xuICAgIGlmIChsaXN0ZW5lcnMub25jZSkgdGhpcy5yZW1vdmVMaXN0ZW5lcihldmVudCwgbGlzdGVuZXJzLmZuLCB1bmRlZmluZWQsIHRydWUpO1xuXG4gICAgc3dpdGNoIChsZW4pIHtcbiAgICAgIGNhc2UgMTogcmV0dXJuIGxpc3RlbmVycy5mbi5jYWxsKGxpc3RlbmVycy5jb250ZXh0KSwgdHJ1ZTtcbiAgICAgIGNhc2UgMjogcmV0dXJuIGxpc3RlbmVycy5mbi5jYWxsKGxpc3RlbmVycy5jb250ZXh0LCBhMSksIHRydWU7XG4gICAgICBjYXNlIDM6IHJldHVybiBsaXN0ZW5lcnMuZm4uY2FsbChsaXN0ZW5lcnMuY29udGV4dCwgYTEsIGEyKSwgdHJ1ZTtcbiAgICAgIGNhc2UgNDogcmV0dXJuIGxpc3RlbmVycy5mbi5jYWxsKGxpc3RlbmVycy5jb250ZXh0LCBhMSwgYTIsIGEzKSwgdHJ1ZTtcbiAgICAgIGNhc2UgNTogcmV0dXJuIGxpc3RlbmVycy5mbi5jYWxsKGxpc3RlbmVycy5jb250ZXh0LCBhMSwgYTIsIGEzLCBhNCksIHRydWU7XG4gICAgICBjYXNlIDY6IHJldHVybiBsaXN0ZW5lcnMuZm4uY2FsbChsaXN0ZW5lcnMuY29udGV4dCwgYTEsIGEyLCBhMywgYTQsIGE1KSwgdHJ1ZTtcbiAgICB9XG5cbiAgICBmb3IgKGkgPSAxLCBhcmdzID0gbmV3IEFycmF5KGxlbiAtMSk7IGkgPCBsZW47IGkrKykge1xuICAgICAgYXJnc1tpIC0gMV0gPSBhcmd1bWVudHNbaV07XG4gICAgfVxuXG4gICAgbGlzdGVuZXJzLmZuLmFwcGx5KGxpc3RlbmVycy5jb250ZXh0LCBhcmdzKTtcbiAgfSBlbHNlIHtcbiAgICB2YXIgbGVuZ3RoID0gbGlzdGVuZXJzLmxlbmd0aFxuICAgICAgLCBqO1xuXG4gICAgZm9yIChpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAobGlzdGVuZXJzW2ldLm9uY2UpIHRoaXMucmVtb3ZlTGlzdGVuZXIoZXZlbnQsIGxpc3RlbmVyc1tpXS5mbiwgdW5kZWZpbmVkLCB0cnVlKTtcblxuICAgICAgc3dpdGNoIChsZW4pIHtcbiAgICAgICAgY2FzZSAxOiBsaXN0ZW5lcnNbaV0uZm4uY2FsbChsaXN0ZW5lcnNbaV0uY29udGV4dCk7IGJyZWFrO1xuICAgICAgICBjYXNlIDI6IGxpc3RlbmVyc1tpXS5mbi5jYWxsKGxpc3RlbmVyc1tpXS5jb250ZXh0LCBhMSk7IGJyZWFrO1xuICAgICAgICBjYXNlIDM6IGxpc3RlbmVyc1tpXS5mbi5jYWxsKGxpc3RlbmVyc1tpXS5jb250ZXh0LCBhMSwgYTIpOyBicmVhaztcbiAgICAgICAgY2FzZSA0OiBsaXN0ZW5lcnNbaV0uZm4uY2FsbChsaXN0ZW5lcnNbaV0uY29udGV4dCwgYTEsIGEyLCBhMyk7IGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIGlmICghYXJncykgZm9yIChqID0gMSwgYXJncyA9IG5ldyBBcnJheShsZW4gLTEpOyBqIDwgbGVuOyBqKyspIHtcbiAgICAgICAgICAgIGFyZ3NbaiAtIDFdID0gYXJndW1lbnRzW2pdO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGxpc3RlbmVyc1tpXS5mbi5hcHBseShsaXN0ZW5lcnNbaV0uY29udGV4dCwgYXJncyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRydWU7XG59O1xuXG4vKipcbiAqIEFkZCBhIGxpc3RlbmVyIGZvciBhIGdpdmVuIGV2ZW50LlxuICpcbiAqIEBwYXJhbSB7KFN0cmluZ3xTeW1ib2wpfSBldmVudCBUaGUgZXZlbnQgbmFtZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIFRoZSBsaXN0ZW5lciBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7Kn0gW2NvbnRleHQ9dGhpc10gVGhlIGNvbnRleHQgdG8gaW52b2tlIHRoZSBsaXN0ZW5lciB3aXRoLlxuICogQHJldHVybnMge0V2ZW50RW1pdHRlcn0gYHRoaXNgLlxuICogQHB1YmxpY1xuICovXG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLm9uID0gZnVuY3Rpb24gb24oZXZlbnQsIGZuLCBjb250ZXh0KSB7XG4gIHJldHVybiBhZGRMaXN0ZW5lcih0aGlzLCBldmVudCwgZm4sIGNvbnRleHQsIGZhbHNlKTtcbn07XG5cbi8qKlxuICogQWRkIGEgb25lLXRpbWUgbGlzdGVuZXIgZm9yIGEgZ2l2ZW4gZXZlbnQuXG4gKlxuICogQHBhcmFtIHsoU3RyaW5nfFN5bWJvbCl9IGV2ZW50IFRoZSBldmVudCBuYW1lLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZm4gVGhlIGxpc3RlbmVyIGZ1bmN0aW9uLlxuICogQHBhcmFtIHsqfSBbY29udGV4dD10aGlzXSBUaGUgY29udGV4dCB0byBpbnZva2UgdGhlIGxpc3RlbmVyIHdpdGguXG4gKiBAcmV0dXJucyB7RXZlbnRFbWl0dGVyfSBgdGhpc2AuXG4gKiBAcHVibGljXG4gKi9cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUub25jZSA9IGZ1bmN0aW9uIG9uY2UoZXZlbnQsIGZuLCBjb250ZXh0KSB7XG4gIHJldHVybiBhZGRMaXN0ZW5lcih0aGlzLCBldmVudCwgZm4sIGNvbnRleHQsIHRydWUpO1xufTtcblxuLyoqXG4gKiBSZW1vdmUgdGhlIGxpc3RlbmVycyBvZiBhIGdpdmVuIGV2ZW50LlxuICpcbiAqIEBwYXJhbSB7KFN0cmluZ3xTeW1ib2wpfSBldmVudCBUaGUgZXZlbnQgbmFtZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIE9ubHkgcmVtb3ZlIHRoZSBsaXN0ZW5lcnMgdGhhdCBtYXRjaCB0aGlzIGZ1bmN0aW9uLlxuICogQHBhcmFtIHsqfSBjb250ZXh0IE9ubHkgcmVtb3ZlIHRoZSBsaXN0ZW5lcnMgdGhhdCBoYXZlIHRoaXMgY29udGV4dC5cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gb25jZSBPbmx5IHJlbW92ZSBvbmUtdGltZSBsaXN0ZW5lcnMuXG4gKiBAcmV0dXJucyB7RXZlbnRFbWl0dGVyfSBgdGhpc2AuXG4gKiBAcHVibGljXG4gKi9cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUucmVtb3ZlTGlzdGVuZXIgPSBmdW5jdGlvbiByZW1vdmVMaXN0ZW5lcihldmVudCwgZm4sIGNvbnRleHQsIG9uY2UpIHtcbiAgdmFyIGV2dCA9IHByZWZpeCA/IHByZWZpeCArIGV2ZW50IDogZXZlbnQ7XG5cbiAgaWYgKCF0aGlzLl9ldmVudHNbZXZ0XSkgcmV0dXJuIHRoaXM7XG4gIGlmICghZm4pIHtcbiAgICBjbGVhckV2ZW50KHRoaXMsIGV2dCk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICB2YXIgbGlzdGVuZXJzID0gdGhpcy5fZXZlbnRzW2V2dF07XG5cbiAgaWYgKGxpc3RlbmVycy5mbikge1xuICAgIGlmIChcbiAgICAgIGxpc3RlbmVycy5mbiA9PT0gZm4gJiZcbiAgICAgICghb25jZSB8fCBsaXN0ZW5lcnMub25jZSkgJiZcbiAgICAgICghY29udGV4dCB8fCBsaXN0ZW5lcnMuY29udGV4dCA9PT0gY29udGV4dClcbiAgICApIHtcbiAgICAgIGNsZWFyRXZlbnQodGhpcywgZXZ0KTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZm9yICh2YXIgaSA9IDAsIGV2ZW50cyA9IFtdLCBsZW5ndGggPSBsaXN0ZW5lcnMubGVuZ3RoOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChcbiAgICAgICAgbGlzdGVuZXJzW2ldLmZuICE9PSBmbiB8fFxuICAgICAgICAob25jZSAmJiAhbGlzdGVuZXJzW2ldLm9uY2UpIHx8XG4gICAgICAgIChjb250ZXh0ICYmIGxpc3RlbmVyc1tpXS5jb250ZXh0ICE9PSBjb250ZXh0KVxuICAgICAgKSB7XG4gICAgICAgIGV2ZW50cy5wdXNoKGxpc3RlbmVyc1tpXSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy9cbiAgICAvLyBSZXNldCB0aGUgYXJyYXksIG9yIHJlbW92ZSBpdCBjb21wbGV0ZWx5IGlmIHdlIGhhdmUgbm8gbW9yZSBsaXN0ZW5lcnMuXG4gICAgLy9cbiAgICBpZiAoZXZlbnRzLmxlbmd0aCkgdGhpcy5fZXZlbnRzW2V2dF0gPSBldmVudHMubGVuZ3RoID09PSAxID8gZXZlbnRzWzBdIDogZXZlbnRzO1xuICAgIGVsc2UgY2xlYXJFdmVudCh0aGlzLCBldnQpO1xuICB9XG5cbiAgcmV0dXJuIHRoaXM7XG59O1xuXG4vKipcbiAqIFJlbW92ZSBhbGwgbGlzdGVuZXJzLCBvciB0aG9zZSBvZiB0aGUgc3BlY2lmaWVkIGV2ZW50LlxuICpcbiAqIEBwYXJhbSB7KFN0cmluZ3xTeW1ib2wpfSBbZXZlbnRdIFRoZSBldmVudCBuYW1lLlxuICogQHJldHVybnMge0V2ZW50RW1pdHRlcn0gYHRoaXNgLlxuICogQHB1YmxpY1xuICovXG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLnJlbW92ZUFsbExpc3RlbmVycyA9IGZ1bmN0aW9uIHJlbW92ZUFsbExpc3RlbmVycyhldmVudCkge1xuICB2YXIgZXZ0O1xuXG4gIGlmIChldmVudCkge1xuICAgIGV2dCA9IHByZWZpeCA/IHByZWZpeCArIGV2ZW50IDogZXZlbnQ7XG4gICAgaWYgKHRoaXMuX2V2ZW50c1tldnRdKSBjbGVhckV2ZW50KHRoaXMsIGV2dCk7XG4gIH0gZWxzZSB7XG4gICAgdGhpcy5fZXZlbnRzID0gbmV3IEV2ZW50cygpO1xuICAgIHRoaXMuX2V2ZW50c0NvdW50ID0gMDtcbiAgfVxuXG4gIHJldHVybiB0aGlzO1xufTtcblxuLy9cbi8vIEFsaWFzIG1ldGhvZHMgbmFtZXMgYmVjYXVzZSBwZW9wbGUgcm9sbCBsaWtlIHRoYXQuXG4vL1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5vZmYgPSBFdmVudEVtaXR0ZXIucHJvdG90eXBlLnJlbW92ZUxpc3RlbmVyO1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5hZGRMaXN0ZW5lciA9IEV2ZW50RW1pdHRlci5wcm90b3R5cGUub247XG5cbi8vXG4vLyBFeHBvc2UgdGhlIHByZWZpeC5cbi8vXG5FdmVudEVtaXR0ZXIucHJlZml4ZWQgPSBwcmVmaXg7XG5cbi8vXG4vLyBBbGxvdyBgRXZlbnRFbWl0dGVyYCB0byBiZSBpbXBvcnRlZCBhcyBtb2R1bGUgbmFtZXNwYWNlLlxuLy9cbkV2ZW50RW1pdHRlci5FdmVudEVtaXR0ZXIgPSBFdmVudEVtaXR0ZXI7XG5cbi8vXG4vLyBFeHBvc2UgdGhlIG1vZHVsZS5cbi8vXG5pZiAoJ3VuZGVmaW5lZCcgIT09IHR5cGVvZiBtb2R1bGUpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBFdmVudEVtaXR0ZXI7XG59XG4iLCJpbXBvcnQgRXZlbnRFbWl0dGVyIGZyb20gJy4vaW5kZXguanMnXG5cbmV4cG9ydCB7IEV2ZW50RW1pdHRlciB9XG5leHBvcnQgZGVmYXVsdCBFdmVudEVtaXR0ZXJcbiIsIlwidXNlIHN0cmljdFwiO1xuY29uc3QgUElfMiA9IE1hdGguUEkgKiAyO1xuY29uc3QgUkFEX1RPX0RFRyA9IDE4MCAvIE1hdGguUEk7XG5jb25zdCBERUdfVE9fUkFEID0gTWF0aC5QSSAvIDE4MDtcblxuZXhwb3J0IHsgREVHX1RPX1JBRCwgUElfMiwgUkFEX1RPX0RFRyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29uc3QubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBQb2ludCB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGBQb2ludGBcbiAgICogQHBhcmFtIHtudW1iZXJ9IFt4PTBdIC0gcG9zaXRpb24gb2YgdGhlIHBvaW50IG9uIHRoZSB4IGF4aXNcbiAgICogQHBhcmFtIHtudW1iZXJ9IFt5PTBdIC0gcG9zaXRpb24gb2YgdGhlIHBvaW50IG9uIHRoZSB5IGF4aXNcbiAgICovXG4gIGNvbnN0cnVjdG9yKHggPSAwLCB5ID0gMCkge1xuICAgIC8qKlxuICAgICAqIFBvc2l0aW9uIG9mIHRoZSBwb2ludCBvbiB0aGUgeCBheGlzXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIC8vIFNldCB4IHBvc2l0aW9uXG4gICAgICogY29uc3QgcG9pbnQgPSBuZXcgUG9pbnQoKTtcbiAgICAgKiBwb2ludC54ID0gMTAwO1xuICAgICAqXG4gICAgICogLy8gVXNlIGluIGNhbGN1bGF0aW9uc1xuICAgICAqIGNvbnN0IHdpZHRoID0gcmlnaHRQb2ludC54IC0gbGVmdFBvaW50Lng7XG4gICAgICogYGBgXG4gICAgICovXG4gICAgdGhpcy54ID0gMDtcbiAgICAvKipcbiAgICAgKiBQb3NpdGlvbiBvZiB0aGUgcG9pbnQgb24gdGhlIHkgYXhpc1xuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiAvLyBTZXQgeSBwb3NpdGlvblxuICAgICAqIGNvbnN0IHBvaW50ID0gbmV3IFBvaW50KCk7XG4gICAgICogcG9pbnQueSA9IDIwMDtcbiAgICAgKlxuICAgICAqIC8vIFVzZSBpbiBjYWxjdWxhdGlvbnNcbiAgICAgKiBjb25zdCBoZWlnaHQgPSBib3R0b21Qb2ludC55IC0gdG9wUG9pbnQueTtcbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICB0aGlzLnkgPSAwO1xuICAgIHRoaXMueCA9IHg7XG4gICAgdGhpcy55ID0geTtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBhIGNsb25lIG9mIHRoaXMgcG9pbnQsIHdoaWNoIGlzIGEgbmV3IGluc3RhbmNlIHdpdGggdGhlIHNhbWUgYHhgIGFuZCBgeWAgdmFsdWVzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBwb2ludCBjbG9uaW5nXG4gICAqIGNvbnN0IG9yaWdpbmFsID0gbmV3IFBvaW50KDEwMCwgMjAwKTtcbiAgICogY29uc3QgY29weSA9IG9yaWdpbmFsLmNsb25lKCk7XG4gICAqXG4gICAqIC8vIENsb25lIGFuZCBtb2RpZnlcbiAgICogY29uc3QgbW9kaWZpZWQgPSBvcmlnaW5hbC5jbG9uZSgpO1xuICAgKiBtb2RpZmllZC5zZXQoMzAwLCA0MDApO1xuICAgKlxuICAgKiAvLyBWZXJpZnkgaW5kZXBlbmRlbmNlXG4gICAqIGNvbnNvbGUubG9nKG9yaWdpbmFsKTsgLy8gUG9pbnQoMTAwLCAyMDApXG4gICAqIGNvbnNvbGUubG9nKG1vZGlmaWVkKTsgLy8gUG9pbnQoMzAwLCA0MDApXG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIENyZWF0ZXMgbmV3IFBvaW50IGluc3RhbmNlXG4gICAqIC0gRGVlcCBjb3BpZXMgeCBhbmQgeSB2YWx1ZXNcbiAgICogLSBJbmRlcGVuZGVudCBmcm9tIG9yaWdpbmFsXG4gICAqIC0gVXNlZnVsIGZvciBwcmVzZXJ2aW5nIHZhbHVlc1xuICAgKiBAcmV0dXJucyBBIGNsb25lIG9mIHRoaXMgcG9pbnRcbiAgICogQHNlZSB7QGxpbmsgUG9pbnQuY29weUZyb219IEZvciBjb3B5aW5nIGludG8gZXhpc3RpbmcgcG9pbnRcbiAgICogQHNlZSB7QGxpbmsgUG9pbnQuY29weVRvfSBGb3IgY29weWluZyB0byBleGlzdGluZyBwb2ludFxuICAgKi9cbiAgY2xvbmUoKSB7XG4gICAgcmV0dXJuIG5ldyBQb2ludCh0aGlzLngsIHRoaXMueSk7XG4gIH1cbiAgLyoqXG4gICAqIENvcGllcyB4IGFuZCB5IGZyb20gdGhlIGdpdmVuIHBvaW50IGludG8gdGhpcyBwb2ludC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY29weWluZ1xuICAgKiBjb25zdCBzb3VyY2UgPSBuZXcgUG9pbnQoMTAwLCAyMDApO1xuICAgKiBjb25zdCB0YXJnZXQgPSBuZXcgUG9pbnQoKTtcbiAgICogdGFyZ2V0LmNvcHlGcm9tKHNvdXJjZSk7XG4gICAqXG4gICAqIC8vIENvcHkgYW5kIGNoYWluIG9wZXJhdGlvbnNcbiAgICogY29uc3QgcG9pbnQgPSBuZXcgUG9pbnQoKVxuICAgKiAgICAgLmNvcHlGcm9tKHNvdXJjZSlcbiAgICogICAgIC5zZXQoeCArIDUwLCB5ICsgNTApO1xuICAgKlxuICAgKiAvLyBDb3B5IGZyb20gYW55IFBvaW50RGF0YVxuICAgKiBjb25zdCBkYXRhID0geyB4OiAxMCwgeTogMjAgfTtcbiAgICogcG9pbnQuY29weUZyb20oZGF0YSk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcCAtIFRoZSBwb2ludCB0byBjb3B5IGZyb21cbiAgICogQHJldHVybnMgVGhlIHBvaW50IGluc3RhbmNlIGl0c2VsZlxuICAgKiBAc2VlIHtAbGluayBQb2ludC5jb3B5VG99IEZvciBjb3B5aW5nIHRvIGFub3RoZXIgcG9pbnRcbiAgICogQHNlZSB7QGxpbmsgUG9pbnQuY2xvbmV9IEZvciBjcmVhdGluZyBuZXcgcG9pbnQgY29weVxuICAgKi9cbiAgY29weUZyb20ocCkge1xuICAgIHRoaXMuc2V0KHAueCwgcC55KTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQ29waWVzIHRoaXMgcG9pbnQncyB4IGFuZCB5IGludG8gdGhlIGdpdmVuIHBvaW50LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb3B5aW5nXG4gICAqIGNvbnN0IHNvdXJjZSA9IG5ldyBQb2ludCgxMDAsIDIwMCk7XG4gICAqIGNvbnN0IHRhcmdldCA9IG5ldyBQb2ludCgpO1xuICAgKiBzb3VyY2UuY29weVRvKHRhcmdldCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcCAtIFRoZSBwb2ludCB0byBjb3B5IHRvLiBDYW4gYmUgYW55IHR5cGUgdGhhdCBpcyBvciBleHRlbmRzIGBQb2ludExpa2VgXG4gICAqIEByZXR1cm5zIFRoZSBwb2ludCAoYHBgKSB3aXRoIHZhbHVlcyB1cGRhdGVkXG4gICAqIEBzZWUge0BsaW5rIFBvaW50LmNvcHlGcm9tfSBGb3IgY29weWluZyBmcm9tIGFub3RoZXIgcG9pbnRcbiAgICogQHNlZSB7QGxpbmsgUG9pbnQuY2xvbmV9IEZvciBjcmVhdGluZyBuZXcgcG9pbnQgY29weVxuICAgKi9cbiAgY29weVRvKHApIHtcbiAgICBwLnNldCh0aGlzLngsIHRoaXMueSk7XG4gICAgcmV0dXJuIHA7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyBpZiBhbm90aGVyIHBvaW50IGlzIGVxdWFsIHRvIHRoaXMgcG9pbnQuXG4gICAqXG4gICAqIENvbXBhcmVzIHggYW5kIHkgdmFsdWVzIHVzaW5nIHN0cmljdCBlcXVhbGl0eS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgZXF1YWxpdHkgY2hlY2tcbiAgICogY29uc3QgcDEgPSBuZXcgUG9pbnQoMTAwLCAyMDApO1xuICAgKiBjb25zdCBwMiA9IG5ldyBQb2ludCgxMDAsIDIwMCk7XG4gICAqIGNvbnNvbGUubG9nKHAxLmVxdWFscyhwMikpOyAvLyB0cnVlXG4gICAqXG4gICAqIC8vIENvbXBhcmUgd2l0aCBQb2ludERhdGFcbiAgICogY29uc3QgZGF0YSA9IHsgeDogMTAwLCB5OiAyMDAgfTtcbiAgICogY29uc29sZS5sb2cocDEuZXF1YWxzKGRhdGEpKTsgLy8gdHJ1ZVxuICAgKlxuICAgKiAvLyBDaGVjayBkaWZmZXJlbnQgcG9pbnRzXG4gICAqIGNvbnN0IHAzID0gbmV3IFBvaW50KDIwMCwgMzAwKTtcbiAgICogY29uc29sZS5sb2cocDEuZXF1YWxzKHAzKSk7IC8vIGZhbHNlXG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcCAtIFRoZSBwb2ludCB0byBjaGVja1xuICAgKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYm90aCBgeGAgYW5kIGB5YCBhcmUgZXF1YWxcbiAgICogQHNlZSB7QGxpbmsgUG9pbnQuY29weUZyb219IEZvciBtYWtpbmcgcG9pbnRzIGVxdWFsXG4gICAqIEBzZWUge0BsaW5rIFBvaW50RGF0YX0gRm9yIHBvaW50IGRhdGEgaW50ZXJmYWNlXG4gICAqL1xuICBlcXVhbHMocCkge1xuICAgIHJldHVybiBwLnggPT09IHRoaXMueCAmJiBwLnkgPT09IHRoaXMueTtcbiAgfVxuICAvKipcbiAgICogU2V0cyB0aGUgcG9pbnQgdG8gYSBuZXcgeCBhbmQgeSBwb3NpdGlvbi5cbiAgICpcbiAgICogSWYgeSBpcyBvbWl0dGVkLCBib3RoIHggYW5kIHkgd2lsbCBiZSBzZXQgdG8geC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgcG9zaXRpb24gc2V0dGluZ1xuICAgKiBjb25zdCBwb2ludCA9IG5ldyBQb2ludCgpO1xuICAgKiBwb2ludC5zZXQoMTAwLCAyMDApO1xuICAgKlxuICAgKiAvLyBTZXQgYm90aCB4IGFuZCB5IHRvIHNhbWUgdmFsdWVcbiAgICogcG9pbnQuc2V0KDUwKTsgLy8geD01MCwgeT01MFxuICAgKlxuICAgKiAvLyBDaGFpbiB3aXRoIG90aGVyIG9wZXJhdGlvbnNcbiAgICogcG9pbnRcbiAgICogICAgIC5zZXQoMTAsIDIwKVxuICAgKiAgICAgLmNvcHlUbyhvdGhlclBvaW50KTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSB4IC0gUG9zaXRpb24gb24gdGhlIHggYXhpc1xuICAgKiBAcGFyYW0geSAtIFBvc2l0aW9uIG9uIHRoZSB5IGF4aXMsIGRlZmF1bHRzIHRvIHhcbiAgICogQHJldHVybnMgVGhlIHBvaW50IGluc3RhbmNlIGl0c2VsZlxuICAgKiBAc2VlIHtAbGluayBQb2ludC5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgZnJvbSBhbm90aGVyIHBvaW50XG4gICAqIEBzZWUge0BsaW5rIFBvaW50LmVxdWFsc30gRm9yIGNvbXBhcmluZyBwb3NpdGlvbnNcbiAgICovXG4gIHNldCh4ID0gMCwgeSA9IHgpIHtcbiAgICB0aGlzLnggPSB4O1xuICAgIHRoaXMueSA9IHk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIGBbcGl4aS5qcy9tYXRoOlBvaW50IHg9JHt0aGlzLnh9IHk9JHt0aGlzLnl9XWA7XG4gIH1cbiAgLyoqXG4gICAqIEEgc3RhdGljIFBvaW50IG9iamVjdCB3aXRoIGB4YCBhbmQgYHlgIHZhbHVlcyBvZiBgMGAuXG4gICAqXG4gICAqIFRoaXMgc2hhcmVkIGluc3RhbmNlIGlzIHJlc2V0IHRvIHplcm8gdmFsdWVzIHdoZW4gYWNjZXNzZWQuXG4gICAqXG4gICAqID4gWyFJTVBPUlRBTlRdIFRoaXMgcG9pbnQgaXMgc2hhcmVkIGFuZCB0ZW1wb3JhcnkuIERvIG5vdCBzdG9yZSByZWZlcmVuY2VzIHRvIGl0LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBVc2UgZm9yIHRlbXBvcmFyeSBjYWxjdWxhdGlvbnNcbiAgICogY29uc3QgdGVtcFBvaW50ID0gUG9pbnQuc2hhcmVkO1xuICAgKiB0ZW1wUG9pbnQuc2V0KDEwMCwgMjAwKTtcbiAgICogbWF0cml4LmFwcGx5KHRlbXBQb2ludCk7XG4gICAqXG4gICAqIC8vIFdpbGwgYmUgcmVzZXQgdG8gKDAsMCkgb24gbmV4dCBhY2Nlc3NcbiAgICogY29uc3QgZnJlc2ggPSBQb2ludC5zaGFyZWQ7IC8vIHg9MCwgeT0wXG4gICAqIGBgYFxuICAgKiBAcmVhZG9ubHlcbiAgICogQHJldHVybnMgQSBmcmVzaCB6ZXJvZWQgcG9pbnQgZm9yIHRlbXBvcmFyeSB1c2VcbiAgICogQHNlZSB7QGxpbmsgUG9pbnQuY29uc3RydWN0b3J9IEZvciBjcmVhdGluZyBuZXcgcG9pbnRzXG4gICAqIEBzZWUge0BsaW5rIFBvaW50RGF0YX0gRm9yIGJhc2ljIHBvaW50IGludGVyZmFjZVxuICAgKi9cbiAgc3RhdGljIGdldCBzaGFyZWQoKSB7XG4gICAgdGVtcFBvaW50LnggPSAwO1xuICAgIHRlbXBQb2ludC55ID0gMDtcbiAgICByZXR1cm4gdGVtcFBvaW50O1xuICB9XG59XG5jb25zdCB0ZW1wUG9pbnQgPSBuZXcgUG9pbnQoKTtcblxuZXhwb3J0IHsgUG9pbnQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVBvaW50Lm1qcy5tYXBcbiIsImltcG9ydCB7IFBJXzIgfSBmcm9tICcuLi9taXNjL2NvbnN0Lm1qcyc7XG5pbXBvcnQgeyBQb2ludCB9IGZyb20gJy4uL3BvaW50L1BvaW50Lm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgTWF0cml4IHtcbiAgLyoqXG4gICAqIEBwYXJhbSBhIC0geCBzY2FsZVxuICAgKiBAcGFyYW0gYiAtIHkgc2tld1xuICAgKiBAcGFyYW0gYyAtIHggc2tld1xuICAgKiBAcGFyYW0gZCAtIHkgc2NhbGVcbiAgICogQHBhcmFtIHR4IC0geCB0cmFuc2xhdGlvblxuICAgKiBAcGFyYW0gdHkgLSB5IHRyYW5zbGF0aW9uXG4gICAqL1xuICBjb25zdHJ1Y3RvcihhID0gMSwgYiA9IDAsIGMgPSAwLCBkID0gMSwgdHggPSAwLCB0eSA9IDApIHtcbiAgICAvKipcbiAgICAgKiBBcnJheSByZXByZXNlbnRhdGlvbiBvZiB0aGUgbWF0cml4LlxuICAgICAqIE9ubHkgcG9wdWxhdGVkIHdoZW4gYHRvQXJyYXkoKWAgaXMgY2FsbGVkLlxuICAgICAqIEBkZWZhdWx0IG51bGxcbiAgICAgKiBAc2VlIHtAbGluayBNYXRyaXgudG9BcnJheX0gRm9yIGZpbGxpbmcgdGhpcyBhcnJheVxuICAgICAqL1xuICAgIHRoaXMuYXJyYXkgPSBudWxsO1xuICAgIHRoaXMuYSA9IGE7XG4gICAgdGhpcy5iID0gYjtcbiAgICB0aGlzLmMgPSBjO1xuICAgIHRoaXMuZCA9IGQ7XG4gICAgdGhpcy50eCA9IHR4O1xuICAgIHRoaXMudHkgPSB0eTtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBhIE1hdHJpeCBvYmplY3QgYmFzZWQgb24gdGhlIGdpdmVuIGFycmF5LlxuICAgKiBQb3B1bGF0ZXMgbWF0cml4IGNvbXBvbmVudHMgZnJvbSBhIGZsYXQgYXJyYXkgaW4gY29sdW1uLW1ham9yIG9yZGVyLlxuICAgKlxuICAgKiA+IFshTk9URV0gQXJyYXkgbWFwcGluZyBvcmRlcjpcbiAgICogPiBgYGBcbiAgICogPiBhcnJheVswXSA9IGEgICh4IHNjYWxlKVxuICAgKiA+IGFycmF5WzFdID0gYiAgKHkgc2tldylcbiAgICogPiBhcnJheVsyXSA9IHR4ICh4IHRyYW5zbGF0aW9uKVxuICAgKiA+IGFycmF5WzNdID0gYyAgKHggc2tldylcbiAgICogPiBhcnJheVs0XSA9IGQgICh5IHNjYWxlKVxuICAgKiA+IGFycmF5WzVdID0gdHkgKHkgdHJhbnNsYXRpb24pXG4gICAqID4gYGBgXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIENyZWF0ZSBtYXRyaXggZnJvbSBhcnJheVxuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KCk7XG4gICAqIG1hdHJpeC5mcm9tQXJyYXkoW1xuICAgKiAgICAgMiwgMCwgIDEwMCwgIC8vIGEsIGIsIHR4XG4gICAqICAgICAwLCAyLCAgMTAwICAgLy8gYywgZCwgdHlcbiAgICogXSk7XG4gICAqXG4gICAqIC8vIENyZWF0ZSBtYXRyaXggZnJvbSB0eXBlZCBhcnJheVxuICAgKiBjb25zdCBmbG9hdDMyQXJyYXkgPSBuZXcgRmxvYXQzMkFycmF5KFtcbiAgICogICAgIDEsIDAsIDAsICAgICAvLyBTY2FsZSB4MSwgbm8gc2tld1xuICAgKiAgICAgMCwgMSwgMCAgICAgIC8vIE5vIHNrZXcsIHNjYWxlIHgxXG4gICAqIF0pO1xuICAgKiBtYXRyaXguZnJvbUFycmF5KGZsb2F0MzJBcnJheSk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gYXJyYXkgLSBUaGUgYXJyYXkgdG8gcG9wdWxhdGUgdGhlIG1hdHJpeCBmcm9tXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC50b0FycmF5fSBGb3IgY29udmVydGluZyBtYXRyaXggdG8gYXJyYXlcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LnNldH0gRm9yIHNldHRpbmcgdmFsdWVzIGRpcmVjdGx5XG4gICAqL1xuICBmcm9tQXJyYXkoYXJyYXkpIHtcbiAgICB0aGlzLmEgPSBhcnJheVswXTtcbiAgICB0aGlzLmIgPSBhcnJheVsxXTtcbiAgICB0aGlzLmMgPSBhcnJheVszXTtcbiAgICB0aGlzLmQgPSBhcnJheVs0XTtcbiAgICB0aGlzLnR4ID0gYXJyYXlbMl07XG4gICAgdGhpcy50eSA9IGFycmF5WzVdO1xuICB9XG4gIC8qKlxuICAgKiBTZXRzIHRoZSBtYXRyaXggcHJvcGVydGllcyBkaXJlY3RseS5cbiAgICogQWxsIG1hdHJpeCBjb21wb25lbnRzIGNhbiBiZSBzZXQgaW4gb25lIGNhbGwuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIFNldCB0byBpZGVudGl0eSBtYXRyaXhcbiAgICogbWF0cml4LnNldCgxLCAwLCAwLCAxLCAwLCAwKTtcbiAgICpcbiAgICogLy8gU2V0IHRvIHNjYWxlIG1hdHJpeFxuICAgKiBtYXRyaXguc2V0KDIsIDAsIDAsIDIsIDAsIDApOyAvLyBTY2FsZSAyeFxuICAgKlxuICAgKiAvLyBTZXQgdG8gdHJhbnNsYXRpb24gbWF0cml4XG4gICAqIG1hdHJpeC5zZXQoMSwgMCwgMCwgMSwgMTAwLCA1MCk7IC8vIE1vdmUgMTAwLDUwXG4gICAqIGBgYFxuICAgKiBAcGFyYW0gYSAtIFNjYWxlIG9uIHggYXhpc1xuICAgKiBAcGFyYW0gYiAtIFNoZWFyIG9uIHkgYXhpc1xuICAgKiBAcGFyYW0gYyAtIFNoZWFyIG9uIHggYXhpc1xuICAgKiBAcGFyYW0gZCAtIFNjYWxlIG9uIHkgYXhpc1xuICAgKiBAcGFyYW0gdHggLSBUcmFuc2xhdGlvbiBvbiB4IGF4aXNcbiAgICogQHBhcmFtIHR5IC0gVHJhbnNsYXRpb24gb24geSBheGlzXG4gICAqIEByZXR1cm5zIFRoaXMgbWF0cml4LiBHb29kIGZvciBjaGFpbmluZyBtZXRob2QgY2FsbHMuXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5pZGVudGl0eX0gRm9yIHJlc2V0dGluZyB0byBpZGVudGl0eVxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguZnJvbUFycmF5fSBGb3Igc2V0dGluZyBmcm9tIGFycmF5XG4gICAqL1xuICBzZXQoYSwgYiwgYywgZCwgdHgsIHR5KSB7XG4gICAgdGhpcy5hID0gYTtcbiAgICB0aGlzLmIgPSBiO1xuICAgIHRoaXMuYyA9IGM7XG4gICAgdGhpcy5kID0gZDtcbiAgICB0aGlzLnR4ID0gdHg7XG4gICAgdGhpcy50eSA9IHR5O1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIGFycmF5IGZyb20gdGhlIGN1cnJlbnQgTWF0cml4IG9iamVjdC5cbiAgICpcbiAgICogPiBbIU5PVEVdIFRoZSBhcnJheSBmb3JtYXQgaXM6XG4gICAqID4gYGBgXG4gICAqID4gTm9uLXRyYW5zcG9zZWQ6XG4gICAqID4gW2EsIGMsIHR4LFxuICAgKiA+IGIsIGQsIHR5LFxuICAgKiA+IDAsIDAsIDFdXG4gICAqID5cbiAgICogPiBUcmFuc3Bvc2VkOlxuICAgKiA+IFthLCBiLCAwLFxuICAgKiA+IGMsIGQsIDAsXG4gICAqID4gdHgsdHksMV1cbiAgICogPiBgYGBcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgYXJyYXkgY29udmVyc2lvblxuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KDIsIDAsIDAsIDIsIDEwMCwgMTAwKTtcbiAgICogY29uc3QgYXJyYXkgPSBtYXRyaXgudG9BcnJheSgpO1xuICAgKlxuICAgKiAvLyBVc2luZyBleGlzdGluZyBhcnJheVxuICAgKiBjb25zdCBmbG9hdDMyQXJyYXkgPSBuZXcgRmxvYXQzMkFycmF5KDkpO1xuICAgKiBtYXRyaXgudG9BcnJheShmYWxzZSwgZmxvYXQzMkFycmF5KTtcbiAgICpcbiAgICogLy8gR2V0IHRyYW5zcG9zZWQgYXJyYXlcbiAgICogY29uc3QgdHJhbnNwb3NlZCA9IG1hdHJpeC50b0FycmF5KHRydWUpO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIHRyYW5zcG9zZSAtIFdoZXRoZXIgdG8gdHJhbnNwb3NlIHRoZSBtYXRyaXhcbiAgICogQHBhcmFtIG91dCAtIE9wdGlvbmFsIEZsb2F0MzJBcnJheSB0byBzdG9yZSB0aGUgcmVzdWx0XG4gICAqIEByZXR1cm5zIFRoZSBhcnJheSBjb250YWluaW5nIHRoZSBtYXRyaXggdmFsdWVzXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5mcm9tQXJyYXl9IEZvciBjcmVhdGluZyBtYXRyaXggZnJvbSBhcnJheVxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguYXJyYXl9IEZvciBjYWNoZWQgYXJyYXkgc3RvcmFnZVxuICAgKi9cbiAgdG9BcnJheSh0cmFuc3Bvc2UsIG91dCkge1xuICAgIGlmICghdGhpcy5hcnJheSkge1xuICAgICAgdGhpcy5hcnJheSA9IG5ldyBGbG9hdDMyQXJyYXkoOSk7XG4gICAgfVxuICAgIGNvbnN0IGFycmF5ID0gb3V0IHx8IHRoaXMuYXJyYXk7XG4gICAgaWYgKHRyYW5zcG9zZSkge1xuICAgICAgYXJyYXlbMF0gPSB0aGlzLmE7XG4gICAgICBhcnJheVsxXSA9IHRoaXMuYjtcbiAgICAgIGFycmF5WzJdID0gMDtcbiAgICAgIGFycmF5WzNdID0gdGhpcy5jO1xuICAgICAgYXJyYXlbNF0gPSB0aGlzLmQ7XG4gICAgICBhcnJheVs1XSA9IDA7XG4gICAgICBhcnJheVs2XSA9IHRoaXMudHg7XG4gICAgICBhcnJheVs3XSA9IHRoaXMudHk7XG4gICAgICBhcnJheVs4XSA9IDE7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFycmF5WzBdID0gdGhpcy5hO1xuICAgICAgYXJyYXlbMV0gPSB0aGlzLmM7XG4gICAgICBhcnJheVsyXSA9IHRoaXMudHg7XG4gICAgICBhcnJheVszXSA9IHRoaXMuYjtcbiAgICAgIGFycmF5WzRdID0gdGhpcy5kO1xuICAgICAgYXJyYXlbNV0gPSB0aGlzLnR5O1xuICAgICAgYXJyYXlbNl0gPSAwO1xuICAgICAgYXJyYXlbN10gPSAwO1xuICAgICAgYXJyYXlbOF0gPSAxO1xuICAgIH1cbiAgICByZXR1cm4gYXJyYXk7XG4gIH1cbiAgLyoqXG4gICAqIEdldCBhIG5ldyBwb3NpdGlvbiB3aXRoIHRoZSBjdXJyZW50IHRyYW5zZm9ybWF0aW9uIGFwcGxpZWQuXG4gICAqXG4gICAqIENhbiBiZSB1c2VkIHRvIGdvIGZyb20gYSBjaGlsZCdzIGNvb3JkaW5hdGUgc3BhY2UgdG8gdGhlIHdvcmxkIGNvb3JkaW5hdGUgc3BhY2UuIChlLmcuIHJlbmRlcmluZylcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgcG9pbnQgdHJhbnNmb3JtYXRpb25cbiAgICogY29uc3QgbWF0cml4ID0gbmV3IE1hdHJpeCgpLnRyYW5zbGF0ZSgxMDAsIDUwKS5yb3RhdGUoTWF0aC5QSSAvIDQpO1xuICAgKiBjb25zdCBwb2ludCA9IG5ldyBQb2ludCgxMCwgMjApO1xuICAgKiBjb25zdCB0cmFuc2Zvcm1lZCA9IG1hdHJpeC5hcHBseShwb2ludCk7XG4gICAqXG4gICAqIC8vIFJldXNlIGV4aXN0aW5nIHBvaW50XG4gICAqIGNvbnN0IG91dHB1dCA9IG5ldyBQb2ludCgpO1xuICAgKiBtYXRyaXguYXBwbHkocG9pbnQsIG91dHB1dCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcG9zIC0gVGhlIG9yaWdpbiBwb2ludCB0byB0cmFuc2Zvcm1cbiAgICogQHBhcmFtIG5ld1BvcyAtIE9wdGlvbmFsIHBvaW50IHRvIHN0b3JlIHRoZSByZXN1bHRcbiAgICogQHJldHVybnMgVGhlIHRyYW5zZm9ybWVkIHBvaW50XG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5hcHBseUludmVyc2V9IEZvciBpbnZlcnNlIHRyYW5zZm9ybWF0aW9uXG4gICAqIEBzZWUge0BsaW5rIFBvaW50fSBGb3IgcG9pbnQgb3BlcmF0aW9uc1xuICAgKi9cbiAgYXBwbHkocG9zLCBuZXdQb3MpIHtcbiAgICBuZXdQb3MgPSBuZXdQb3MgfHwgbmV3IFBvaW50KCk7XG4gICAgY29uc3QgeCA9IHBvcy54O1xuICAgIGNvbnN0IHkgPSBwb3MueTtcbiAgICBuZXdQb3MueCA9IHRoaXMuYSAqIHggKyB0aGlzLmMgKiB5ICsgdGhpcy50eDtcbiAgICBuZXdQb3MueSA9IHRoaXMuYiAqIHggKyB0aGlzLmQgKiB5ICsgdGhpcy50eTtcbiAgICByZXR1cm4gbmV3UG9zO1xuICB9XG4gIC8qKlxuICAgKiBHZXQgYSBuZXcgcG9zaXRpb24gd2l0aCB0aGUgaW52ZXJzZSBvZiB0aGUgY3VycmVudCB0cmFuc2Zvcm1hdGlvbiBhcHBsaWVkLlxuICAgKlxuICAgKiBDYW4gYmUgdXNlZCB0byBnbyBmcm9tIHRoZSB3b3JsZCBjb29yZGluYXRlIHNwYWNlIHRvIGEgY2hpbGQncyBjb29yZGluYXRlIHNwYWNlLiAoZS5nLiBpbnB1dClcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgaW52ZXJzZSB0cmFuc2Zvcm1hdGlvblxuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KCkudHJhbnNsYXRlKDEwMCwgNTApLnJvdGF0ZShNYXRoLlBJIC8gNCk7XG4gICAqIGNvbnN0IHdvcmxkUG9pbnQgPSBuZXcgUG9pbnQoMTUwLCAxMDApO1xuICAgKiBjb25zdCBsb2NhbFBvaW50ID0gbWF0cml4LmFwcGx5SW52ZXJzZSh3b3JsZFBvaW50KTtcbiAgICpcbiAgICogLy8gUmV1c2UgZXhpc3RpbmcgcG9pbnRcbiAgICogY29uc3Qgb3V0cHV0ID0gbmV3IFBvaW50KCk7XG4gICAqIG1hdHJpeC5hcHBseUludmVyc2Uod29ybGRQb2ludCwgb3V0cHV0KTtcbiAgICpcbiAgICogLy8gQ29udmVydCBtb3VzZSBwb3NpdGlvbiB0byBsb2NhbCBzcGFjZVxuICAgKiBjb25zdCBtb3VzZVBvaW50ID0gbmV3IFBvaW50KG1vdXNlWCwgbW91c2VZKTtcbiAgICogY29uc3QgbG9jYWxNb3VzZSA9IG1hdHJpeC5hcHBseUludmVyc2UobW91c2VQb2ludCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcG9zIC0gVGhlIG9yaWdpbiBwb2ludCB0byBpbnZlcnNlLXRyYW5zZm9ybVxuICAgKiBAcGFyYW0gbmV3UG9zIC0gT3B0aW9uYWwgcG9pbnQgdG8gc3RvcmUgdGhlIHJlc3VsdFxuICAgKiBAcmV0dXJucyBUaGUgaW52ZXJzZS10cmFuc2Zvcm1lZCBwb2ludFxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguYXBwbHl9IEZvciBmb3J3YXJkIHRyYW5zZm9ybWF0aW9uXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5pbnZlcnR9IEZvciBnZXR0aW5nIGludmVyc2UgbWF0cml4XG4gICAqL1xuICBhcHBseUludmVyc2UocG9zLCBuZXdQb3MpIHtcbiAgICBuZXdQb3MgPSBuZXdQb3MgfHwgbmV3IFBvaW50KCk7XG4gICAgY29uc3QgYSA9IHRoaXMuYTtcbiAgICBjb25zdCBiID0gdGhpcy5iO1xuICAgIGNvbnN0IGMgPSB0aGlzLmM7XG4gICAgY29uc3QgZCA9IHRoaXMuZDtcbiAgICBjb25zdCB0eCA9IHRoaXMudHg7XG4gICAgY29uc3QgdHkgPSB0aGlzLnR5O1xuICAgIGNvbnN0IGlkID0gMSAvIChhICogZCArIGMgKiAtYik7XG4gICAgY29uc3QgeCA9IHBvcy54O1xuICAgIGNvbnN0IHkgPSBwb3MueTtcbiAgICBuZXdQb3MueCA9IGQgKiBpZCAqIHggKyAtYyAqIGlkICogeSArICh0eSAqIGMgLSB0eCAqIGQpICogaWQ7XG4gICAgbmV3UG9zLnkgPSBhICogaWQgKiB5ICsgLWIgKiBpZCAqIHggKyAoLXR5ICogYSArIHR4ICogYikgKiBpZDtcbiAgICByZXR1cm4gbmV3UG9zO1xuICB9XG4gIC8qKlxuICAgKiBUcmFuc2xhdGVzIHRoZSBtYXRyaXggb24gdGhlIHggYW5kIHkgYXhlcy5cbiAgICogQWRkcyB0byB0aGUgcG9zaXRpb24gdmFsdWVzIHdoaWxlIHByZXNlcnZpbmcgc2NhbGUsIHJvdGF0aW9uIGFuZCBza2V3LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyB0cmFuc2xhdGlvblxuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KCk7XG4gICAqIG1hdHJpeC50cmFuc2xhdGUoMTAwLCA1MCk7IC8vIE1vdmUgcmlnaHQgMTAwLCBkb3duIDUwXG4gICAqXG4gICAqIC8vIENoYWluIHdpdGggb3RoZXIgdHJhbnNmb3JtYXRpb25zXG4gICAqIG1hdHJpeFxuICAgKiAgICAgLnNjYWxlKDIsIDIpXG4gICAqICAgICAudHJhbnNsYXRlKDEwMCwgMClcbiAgICogICAgIC5yb3RhdGUoTWF0aC5QSSAvIDQpO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIHggLSBIb3cgbXVjaCB0byB0cmFuc2xhdGUgb24gdGhlIHggYXhpc1xuICAgKiBAcGFyYW0geSAtIEhvdyBtdWNoIHRvIHRyYW5zbGF0ZSBvbiB0aGUgeSBheGlzXG4gICAqIEByZXR1cm5zIFRoaXMgbWF0cml4LiBHb29kIGZvciBjaGFpbmluZyBtZXRob2QgY2FsbHMuXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5zZXR9IEZvciBzZXR0aW5nIHBvc2l0aW9uIGRpcmVjdGx5XG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5zZXRUcmFuc2Zvcm19IEZvciBjb21wbGV0ZSB0cmFuc2Zvcm0gc2V0dXBcbiAgICovXG4gIHRyYW5zbGF0ZSh4LCB5KSB7XG4gICAgdGhpcy50eCArPSB4O1xuICAgIHRoaXMudHkgKz0geTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQXBwbGllcyBhIHNjYWxlIHRyYW5zZm9ybWF0aW9uIHRvIHRoZSBtYXRyaXguXG4gICAqIE11bHRpcGxpZXMgdGhlIHNjYWxlIHZhbHVlcyB3aXRoIGV4aXN0aW5nIG1hdHJpeCBjb21wb25lbnRzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBzY2FsaW5nXG4gICAqIGNvbnN0IG1hdHJpeCA9IG5ldyBNYXRyaXgoKTtcbiAgICogbWF0cml4LnNjYWxlKDIsIDMpOyAvLyBTY2FsZSAyeCBob3Jpem9udGFsbHksIDN4IHZlcnRpY2FsbHlcbiAgICpcbiAgICogLy8gQ2hhaW4gd2l0aCBvdGhlciB0cmFuc2Zvcm1hdGlvbnNcbiAgICogbWF0cml4XG4gICAqICAgICAudHJhbnNsYXRlKDEwMCwgMTAwKVxuICAgKiAgICAgLnNjYWxlKDIsIDIpICAgICAvLyBTY2FsZXMgYWZ0ZXIgdHJhbnNsYXRpb25cbiAgICogICAgIC5yb3RhdGUoTWF0aC5QSSAvIDQpO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIHggLSBUaGUgYW1vdW50IHRvIHNjYWxlIGhvcml6b250YWxseVxuICAgKiBAcGFyYW0geSAtIFRoZSBhbW91bnQgdG8gc2NhbGUgdmVydGljYWxseVxuICAgKiBAcmV0dXJucyBUaGlzIG1hdHJpeC4gR29vZCBmb3IgY2hhaW5pbmcgbWV0aG9kIGNhbGxzLlxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguc2V0VHJhbnNmb3JtfSBGb3Igc2V0dGluZyBzY2FsZSBkaXJlY3RseVxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguYXBwZW5kfSBGb3IgY29tYmluaW5nIHRyYW5zZm9ybWF0aW9uc1xuICAgKi9cbiAgc2NhbGUoeCwgeSkge1xuICAgIHRoaXMuYSAqPSB4O1xuICAgIHRoaXMuZCAqPSB5O1xuICAgIHRoaXMuYyAqPSB4O1xuICAgIHRoaXMuYiAqPSB5O1xuICAgIHRoaXMudHggKj0geDtcbiAgICB0aGlzLnR5ICo9IHk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEFwcGxpZXMgYSByb3RhdGlvbiB0cmFuc2Zvcm1hdGlvbiB0byB0aGUgbWF0cml4LlxuICAgKlxuICAgKiBSb3RhdGVzIGFyb3VuZCB0aGUgb3JpZ2luICgwLDApIGJ5IHRoZSBnaXZlbiBhbmdsZSBpbiByYWRpYW5zLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyByb3RhdGlvblxuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KCk7XG4gICAqIG1hdHJpeC5yb3RhdGUoTWF0aC5QSSAvIDQpOyAvLyBSb3RhdGUgNDUgZGVncmVlc1xuICAgKlxuICAgKiAvLyBDaGFpbiB3aXRoIG90aGVyIHRyYW5zZm9ybWF0aW9uc1xuICAgKiBtYXRyaXhcbiAgICogICAgIC50cmFuc2xhdGUoMTAwLCAxMDApIC8vIE1vdmUgdG8gcm90YXRpb24gY2VudGVyXG4gICAqICAgICAucm90YXRlKE1hdGguUEkpICAgICAvLyBSb3RhdGUgMTgwIGRlZ3JlZXNcbiAgICogICAgIC5zY2FsZSgyLCAyKTsgICAgICAgIC8vIFNjYWxlIGFmdGVyIHJvdGF0aW9uXG4gICAqXG4gICAqIC8vIENvbW1vbiBhbmdsZXNcbiAgICogbWF0cml4LnJvdGF0ZShNYXRoLlBJIC8gMik7ICAvLyA5MCBkZWdyZWVzXG4gICAqIG1hdHJpeC5yb3RhdGUoTWF0aC5QSSk7ICAgICAgLy8gMTgwIGRlZ3JlZXNcbiAgICogbWF0cml4LnJvdGF0ZShNYXRoLlBJICogMik7ICAvLyAzNjAgZGVncmVlc1xuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBSb3RhdGVzIGFyb3VuZCBvcmlnaW4gcG9pbnQgKDAsMClcbiAgICogLSBBZmZlY3RzIHBvc2l0aW9uIGlmIHRyYW5zbGF0aW9uIHdhcyBzZXRcbiAgICogLSBVc2VzIGNvdW50ZXItY2xvY2t3aXNlIHJvdGF0aW9uXG4gICAqIC0gT3JkZXIgb2Ygb3BlcmF0aW9ucyBtYXR0ZXJzIHdoZW4gY2hhaW5pbmdcbiAgICogQHBhcmFtIGFuZ2xlIC0gVGhlIGFuZ2xlIGluIHJhZGlhbnNcbiAgICogQHJldHVybnMgVGhpcyBtYXRyaXguIEdvb2QgZm9yIGNoYWluaW5nIG1ldGhvZCBjYWxscy5cbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LnNldFRyYW5zZm9ybX0gRm9yIHNldHRpbmcgcm90YXRpb24gZGlyZWN0bHlcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LmFwcGVuZH0gRm9yIGNvbWJpbmluZyB0cmFuc2Zvcm1hdGlvbnNcbiAgICovXG4gIHJvdGF0ZShhbmdsZSkge1xuICAgIGNvbnN0IGNvcyA9IE1hdGguY29zKGFuZ2xlKTtcbiAgICBjb25zdCBzaW4gPSBNYXRoLnNpbihhbmdsZSk7XG4gICAgY29uc3QgYTEgPSB0aGlzLmE7XG4gICAgY29uc3QgYzEgPSB0aGlzLmM7XG4gICAgY29uc3QgdHgxID0gdGhpcy50eDtcbiAgICB0aGlzLmEgPSBhMSAqIGNvcyAtIHRoaXMuYiAqIHNpbjtcbiAgICB0aGlzLmIgPSBhMSAqIHNpbiArIHRoaXMuYiAqIGNvcztcbiAgICB0aGlzLmMgPSBjMSAqIGNvcyAtIHRoaXMuZCAqIHNpbjtcbiAgICB0aGlzLmQgPSBjMSAqIHNpbiArIHRoaXMuZCAqIGNvcztcbiAgICB0aGlzLnR4ID0gdHgxICogY29zIC0gdGhpcy50eSAqIHNpbjtcbiAgICB0aGlzLnR5ID0gdHgxICogc2luICsgdGhpcy50eSAqIGNvcztcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQXBwZW5kcyB0aGUgZ2l2ZW4gTWF0cml4IHRvIHRoaXMgTWF0cml4LlxuICAgKiBDb21iaW5lcyB0d28gbWF0cmljZXMgYnkgbXVsdGlwbHlpbmcgdGhlbSB0b2dldGhlcjogdGhpcyA9IHRoaXMgKiBtYXRyaXhcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgbWF0cml4IGNvbWJpbmF0aW9uXG4gICAqIGNvbnN0IG1hdHJpeCA9IG5ldyBNYXRyaXgoKTtcbiAgICogY29uc3Qgb3RoZXIgPSBuZXcgTWF0cml4KCkudHJhbnNsYXRlKDEwMCwgMCkucm90YXRlKE1hdGguUEkgLyA0KTtcbiAgICogbWF0cml4LmFwcGVuZChvdGhlcik7XG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIE9yZGVyIG1hdHRlcnM6IEEuYXBwZW5kKEIpICE9PSBCLmFwcGVuZChBKVxuICAgKiAtIE1vZGlmaWVzIGN1cnJlbnQgbWF0cml4XG4gICAqIC0gUHJlc2VydmVzIHRyYW5zZm9ybWF0aW9uIG9yZGVyXG4gICAqIC0gQ29tbW9ubHkgdXNlZCBmb3IgY29tYmluaW5nIHRyYW5zZm9ybXNcbiAgICogQHBhcmFtIG1hdHJpeCAtIFRoZSBtYXRyaXggdG8gYXBwZW5kXG4gICAqIEByZXR1cm5zIFRoaXMgbWF0cml4LiBHb29kIGZvciBjaGFpbmluZyBtZXRob2QgY2FsbHMuXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5wcmVwZW5kfSBGb3IgcHJlcGVuZGluZyB0cmFuc2Zvcm1hdGlvbnNcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LmFwcGVuZEZyb219IEZvciBhcHBlbmRpbmcgdHdvIGV4dGVybmFsIG1hdHJpY2VzXG4gICAqL1xuICBhcHBlbmQobWF0cml4KSB7XG4gICAgY29uc3QgYTEgPSB0aGlzLmE7XG4gICAgY29uc3QgYjEgPSB0aGlzLmI7XG4gICAgY29uc3QgYzEgPSB0aGlzLmM7XG4gICAgY29uc3QgZDEgPSB0aGlzLmQ7XG4gICAgdGhpcy5hID0gbWF0cml4LmEgKiBhMSArIG1hdHJpeC5iICogYzE7XG4gICAgdGhpcy5iID0gbWF0cml4LmEgKiBiMSArIG1hdHJpeC5iICogZDE7XG4gICAgdGhpcy5jID0gbWF0cml4LmMgKiBhMSArIG1hdHJpeC5kICogYzE7XG4gICAgdGhpcy5kID0gbWF0cml4LmMgKiBiMSArIG1hdHJpeC5kICogZDE7XG4gICAgdGhpcy50eCA9IG1hdHJpeC50eCAqIGExICsgbWF0cml4LnR5ICogYzEgKyB0aGlzLnR4O1xuICAgIHRoaXMudHkgPSBtYXRyaXgudHggKiBiMSArIG1hdHJpeC50eSAqIGQxICsgdGhpcy50eTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQXBwZW5kcyB0d28gbWF0cmljZXMgYW5kIHNldHMgdGhlIHJlc3VsdCB0byB0aGlzIG1hdHJpeC5cbiAgICogUGVyZm9ybXMgbWF0cml4IG11bHRpcGxpY2F0aW9uOiB0aGlzID0gQSAqIEJcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgbWF0cml4IG11bHRpcGxpY2F0aW9uXG4gICAqIGNvbnN0IHJlc3VsdCA9IG5ldyBNYXRyaXgoKTtcbiAgICogY29uc3QgbWF0cml4QSA9IG5ldyBNYXRyaXgoKS5zY2FsZSgyLCAyKTtcbiAgICogY29uc3QgbWF0cml4QiA9IG5ldyBNYXRyaXgoKS5yb3RhdGUoTWF0aC5QSSAvIDQpO1xuICAgKiByZXN1bHQuYXBwZW5kRnJvbShtYXRyaXhBLCBtYXRyaXhCKTtcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gT3JkZXIgbWF0dGVyczogQSAqIEIgIT09IEIgKiBBXG4gICAqIC0gQ3JlYXRlcyBhIG5ldyB0cmFuc2Zvcm1hdGlvbiBmcm9tIHR3byBvdGhlcnNcbiAgICogLSBNb3JlIGVmZmljaWVudCB0aGFuIGFwcGVuZCgpIGZvciBtdWx0aXBsZSBvcGVyYXRpb25zXG4gICAqIC0gRG9lcyBub3QgbW9kaWZ5IGlucHV0IG1hdHJpY2VzXG4gICAqIEBwYXJhbSBhIC0gVGhlIGZpcnN0IG1hdHJpeCB0byBtdWx0aXBseVxuICAgKiBAcGFyYW0gYiAtIFRoZSBzZWNvbmQgbWF0cml4IHRvIG11bHRpcGx5XG4gICAqIEByZXR1cm5zIFRoaXMgbWF0cml4LiBHb29kIGZvciBjaGFpbmluZyBtZXRob2QgY2FsbHMuXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5hcHBlbmR9IEZvciBzaW5nbGUgbWF0cml4IGNvbWJpbmF0aW9uXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5wcmVwZW5kfSBGb3IgcmV2ZXJzZSBvcmRlciBtdWx0aXBsaWNhdGlvblxuICAgKi9cbiAgYXBwZW5kRnJvbShhLCBiKSB7XG4gICAgY29uc3QgYTEgPSBhLmE7XG4gICAgY29uc3QgYjEgPSBhLmI7XG4gICAgY29uc3QgYzEgPSBhLmM7XG4gICAgY29uc3QgZDEgPSBhLmQ7XG4gICAgY29uc3QgdHggPSBhLnR4O1xuICAgIGNvbnN0IHR5ID0gYS50eTtcbiAgICBjb25zdCBhMiA9IGIuYTtcbiAgICBjb25zdCBiMiA9IGIuYjtcbiAgICBjb25zdCBjMiA9IGIuYztcbiAgICBjb25zdCBkMiA9IGIuZDtcbiAgICB0aGlzLmEgPSBhMSAqIGEyICsgYjEgKiBjMjtcbiAgICB0aGlzLmIgPSBhMSAqIGIyICsgYjEgKiBkMjtcbiAgICB0aGlzLmMgPSBjMSAqIGEyICsgZDEgKiBjMjtcbiAgICB0aGlzLmQgPSBjMSAqIGIyICsgZDEgKiBkMjtcbiAgICB0aGlzLnR4ID0gdHggKiBhMiArIHR5ICogYzIgKyBiLnR4O1xuICAgIHRoaXMudHkgPSB0eCAqIGIyICsgdHkgKiBkMiArIGIudHk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgdGhlIG1hdHJpeCBiYXNlZCBvbiBhbGwgdGhlIGF2YWlsYWJsZSBwcm9wZXJ0aWVzLlxuICAgKiBDb21iaW5lcyBwb3NpdGlvbiwgc2NhbGUsIHJvdGF0aW9uLCBza2V3IGFuZCBwaXZvdCBpbiBhIHNpbmdsZSBvcGVyYXRpb24uXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHRyYW5zZm9ybSBzZXR1cFxuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KCk7XG4gICAqIG1hdHJpeC5zZXRUcmFuc2Zvcm0oXG4gICAqICAgICAxMDAsIDEwMCwgICAgLy8gcG9zaXRpb25cbiAgICogICAgIDAsIDAsICAgICAgICAvLyBwaXZvdFxuICAgKiAgICAgMiwgMiwgICAgICAgIC8vIHNjYWxlXG4gICAqICAgICBNYXRoLlBJIC8gNCwgLy8gcm90YXRpb24gKDQ1IGRlZ3JlZXMpXG4gICAqICAgICAwLCAwICAgICAgICAgLy8gc2tld1xuICAgKiApO1xuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBVcGRhdGVzIGFsbCBtYXRyaXggY29tcG9uZW50cyBhdCBvbmNlXG4gICAqIC0gTW9yZSBlZmZpY2llbnQgdGhhbiBzZXBhcmF0ZSB0cmFuc2Zvcm0gY2FsbHNcbiAgICogLSBVc2VzIHJhZGlhbnMgZm9yIHJvdGF0aW9uIGFuZCBza2V3XG4gICAqIC0gUGl2b3QgYWZmZWN0cyByb3RhdGlvbiBjZW50ZXJcbiAgICogQHBhcmFtIHggLSBQb3NpdGlvbiBvbiB0aGUgeCBheGlzXG4gICAqIEBwYXJhbSB5IC0gUG9zaXRpb24gb24gdGhlIHkgYXhpc1xuICAgKiBAcGFyYW0gcGl2b3RYIC0gUGl2b3Qgb24gdGhlIHggYXhpc1xuICAgKiBAcGFyYW0gcGl2b3RZIC0gUGl2b3Qgb24gdGhlIHkgYXhpc1xuICAgKiBAcGFyYW0gc2NhbGVYIC0gU2NhbGUgb24gdGhlIHggYXhpc1xuICAgKiBAcGFyYW0gc2NhbGVZIC0gU2NhbGUgb24gdGhlIHkgYXhpc1xuICAgKiBAcGFyYW0gcm90YXRpb24gLSBSb3RhdGlvbiBpbiByYWRpYW5zXG4gICAqIEBwYXJhbSBza2V3WCAtIFNrZXcgb24gdGhlIHggYXhpc1xuICAgKiBAcGFyYW0gc2tld1kgLSBTa2V3IG9uIHRoZSB5IGF4aXNcbiAgICogQHJldHVybnMgVGhpcyBtYXRyaXguIEdvb2QgZm9yIGNoYWluaW5nIG1ldGhvZCBjYWxscy5cbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LmRlY29tcG9zZX0gRm9yIGV4dHJhY3RpbmcgdHJhbnNmb3JtIHByb3BlcnRpZXNcbiAgICogQHNlZSB7QGxpbmsgVHJhbnNmb3JtYWJsZU9iamVjdH0gRm9yIHRyYW5zZm9ybSBkYXRhIHN0cnVjdHVyZVxuICAgKi9cbiAgc2V0VHJhbnNmb3JtKHgsIHksIHBpdm90WCwgcGl2b3RZLCBzY2FsZVgsIHNjYWxlWSwgcm90YXRpb24sIHNrZXdYLCBza2V3WSkge1xuICAgIHRoaXMuYSA9IE1hdGguY29zKHJvdGF0aW9uICsgc2tld1kpICogc2NhbGVYO1xuICAgIHRoaXMuYiA9IE1hdGguc2luKHJvdGF0aW9uICsgc2tld1kpICogc2NhbGVYO1xuICAgIHRoaXMuYyA9IC1NYXRoLnNpbihyb3RhdGlvbiAtIHNrZXdYKSAqIHNjYWxlWTtcbiAgICB0aGlzLmQgPSBNYXRoLmNvcyhyb3RhdGlvbiAtIHNrZXdYKSAqIHNjYWxlWTtcbiAgICB0aGlzLnR4ID0geCAtIChwaXZvdFggKiB0aGlzLmEgKyBwaXZvdFkgKiB0aGlzLmMpO1xuICAgIHRoaXMudHkgPSB5IC0gKHBpdm90WCAqIHRoaXMuYiArIHBpdm90WSAqIHRoaXMuZCk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFByZXBlbmRzIHRoZSBnaXZlbiBNYXRyaXggdG8gdGhpcyBNYXRyaXguXG4gICAqIENvbWJpbmVzIHR3byBtYXRyaWNlcyBieSBtdWx0aXBseWluZyB0aGVtIHRvZ2V0aGVyOiB0aGlzID0gbWF0cml4ICogdGhpc1xuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBtYXRyaXggcHJlcGVuZFxuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KCkuc2NhbGUoMiwgMik7XG4gICAqIGNvbnN0IG90aGVyID0gbmV3IE1hdHJpeCgpLnRyYW5zbGF0ZSgxMDAsIDApO1xuICAgKiBtYXRyaXgucHJlcGVuZChvdGhlcik7IC8vIFRyYW5zbGF0aW9uIGhhcHBlbnMgYmVmb3JlIHNjYWxpbmdcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gT3JkZXIgbWF0dGVyczogQS5wcmVwZW5kKEIpICE9PSBCLnByZXBlbmQoQSlcbiAgICogLSBNb2RpZmllcyBjdXJyZW50IG1hdHJpeFxuICAgKiAtIFJldmVyc2VzIHRyYW5zZm9ybWF0aW9uIG9yZGVyIGNvbXBhcmVkIHRvIGFwcGVuZCgpXG4gICAqIEBwYXJhbSBtYXRyaXggLSBUaGUgbWF0cml4IHRvIHByZXBlbmRcbiAgICogQHJldHVybnMgVGhpcyBtYXRyaXguIEdvb2QgZm9yIGNoYWluaW5nIG1ldGhvZCBjYWxscy5cbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LmFwcGVuZH0gRm9yIGFwcGVuZGluZyB0cmFuc2Zvcm1hdGlvbnNcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LmFwcGVuZEZyb219IEZvciBjb21iaW5pbmcgZXh0ZXJuYWwgbWF0cmljZXNcbiAgICovXG4gIHByZXBlbmQobWF0cml4KSB7XG4gICAgY29uc3QgdHgxID0gdGhpcy50eDtcbiAgICBpZiAobWF0cml4LmEgIT09IDEgfHwgbWF0cml4LmIgIT09IDAgfHwgbWF0cml4LmMgIT09IDAgfHwgbWF0cml4LmQgIT09IDEpIHtcbiAgICAgIGNvbnN0IGExID0gdGhpcy5hO1xuICAgICAgY29uc3QgYzEgPSB0aGlzLmM7XG4gICAgICB0aGlzLmEgPSBhMSAqIG1hdHJpeC5hICsgdGhpcy5iICogbWF0cml4LmM7XG4gICAgICB0aGlzLmIgPSBhMSAqIG1hdHJpeC5iICsgdGhpcy5iICogbWF0cml4LmQ7XG4gICAgICB0aGlzLmMgPSBjMSAqIG1hdHJpeC5hICsgdGhpcy5kICogbWF0cml4LmM7XG4gICAgICB0aGlzLmQgPSBjMSAqIG1hdHJpeC5iICsgdGhpcy5kICogbWF0cml4LmQ7XG4gICAgfVxuICAgIHRoaXMudHggPSB0eDEgKiBtYXRyaXguYSArIHRoaXMudHkgKiBtYXRyaXguYyArIG1hdHJpeC50eDtcbiAgICB0aGlzLnR5ID0gdHgxICogbWF0cml4LmIgKyB0aGlzLnR5ICogbWF0cml4LmQgKyBtYXRyaXgudHk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIERlY29tcG9zZXMgdGhlIG1hdHJpeCBpbnRvIGl0cyBpbmRpdmlkdWFsIHRyYW5zZm9ybSBjb21wb25lbnRzLlxuICAgKiBFeHRyYWN0cyBwb3NpdGlvbiwgc2NhbGUsIHJvdGF0aW9uIGFuZCBza2V3IHZhbHVlcyBmcm9tIHRoZSBtYXRyaXguXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGRlY29tcG9zaXRpb25cbiAgICogY29uc3QgbWF0cml4ID0gbmV3IE1hdHJpeCgpXG4gICAqICAgICAudHJhbnNsYXRlKDEwMCwgMTAwKVxuICAgKiAgICAgLnJvdGF0ZShNYXRoLlBJIC8gNClcbiAgICogICAgIC5zY2FsZSgyLCAyKTtcbiAgICpcbiAgICogY29uc3QgdHJhbnNmb3JtID0ge1xuICAgKiAgICAgcG9zaXRpb246IG5ldyBQb2ludCgpLFxuICAgKiAgICAgc2NhbGU6IG5ldyBQb2ludCgpLFxuICAgKiAgICAgcGl2b3Q6IG5ldyBQb2ludCgpLFxuICAgKiAgICAgc2tldzogbmV3IFBvaW50KCksXG4gICAqICAgICByb3RhdGlvbjogMFxuICAgKiB9O1xuICAgKlxuICAgKiBtYXRyaXguZGVjb21wb3NlKHRyYW5zZm9ybSk7XG4gICAqIGNvbnNvbGUubG9nKHRyYW5zZm9ybS5wb3NpdGlvbik7IC8vIFBvaW50KDEwMCwgMTAwKVxuICAgKiBjb25zb2xlLmxvZyh0cmFuc2Zvcm0ucm90YXRpb24pOyAvLyB+MC43ODUgKFBJLzQpXG4gICAqIGNvbnNvbGUubG9nKHRyYW5zZm9ybS5zY2FsZSk7IC8vIFBvaW50KDIsIDIpXG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIEhhbmRsZXMgY29tYmluZWQgdHJhbnNmb3JtYXRpb25zXG4gICAqIC0gQWNjb3VudHMgZm9yIHBpdm90IHBvaW50c1xuICAgKiAtIENob29zZXMgYmV0d2VlbiByb3RhdGlvbi9za2V3IGJhc2VkIG9uIHRyYW5zZm9ybSB0eXBlXG4gICAqIC0gVXNlcyByYWRpYW5zIGZvciByb3RhdGlvbiBhbmQgc2tld1xuICAgKiBAcGFyYW0gdHJhbnNmb3JtIC0gVGhlIHRyYW5zZm9ybSBvYmplY3QgdG8gc3RvcmUgdGhlIGRlY29tcG9zZWQgdmFsdWVzXG4gICAqIEByZXR1cm5zIFRoZSB0cmFuc2Zvcm0gd2l0aCB0aGUgbmV3bHkgYXBwbGllZCBwcm9wZXJ0aWVzXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5zZXRUcmFuc2Zvcm19IEZvciBjb21wb3NpbmcgZnJvbSBjb21wb25lbnRzXG4gICAqIEBzZWUge0BsaW5rIFRyYW5zZm9ybWFibGVPYmplY3R9IEZvciB0cmFuc2Zvcm0gc3RydWN0dXJlXG4gICAqL1xuICBkZWNvbXBvc2UodHJhbnNmb3JtKSB7XG4gICAgY29uc3QgYSA9IHRoaXMuYTtcbiAgICBjb25zdCBiID0gdGhpcy5iO1xuICAgIGNvbnN0IGMgPSB0aGlzLmM7XG4gICAgY29uc3QgZCA9IHRoaXMuZDtcbiAgICBjb25zdCBwaXZvdCA9IHRyYW5zZm9ybS5waXZvdDtcbiAgICBjb25zdCBza2V3WCA9IC1NYXRoLmF0YW4yKC1jLCBkKTtcbiAgICBjb25zdCBza2V3WSA9IE1hdGguYXRhbjIoYiwgYSk7XG4gICAgY29uc3QgZGVsdGEgPSBNYXRoLmFicyhza2V3WCArIHNrZXdZKTtcbiAgICBsZXQgc2NhbGVYID0gTWF0aC5zcXJ0KGEgKiBhICsgYiAqIGIpO1xuICAgIGlmIChkZWx0YSA8IDFlLTUgfHwgTWF0aC5hYnMoUElfMiAtIGRlbHRhKSA8IDFlLTUpIHtcbiAgICAgIHRyYW5zZm9ybS5yb3RhdGlvbiA9IHNrZXdZO1xuICAgICAgdHJhbnNmb3JtLnNrZXcueCA9IHRyYW5zZm9ybS5za2V3LnkgPSAwO1xuICAgIH0gZWxzZSBpZiAoTWF0aC5hYnMoTWF0aC5QSSAtIGRlbHRhKSA8IDFlLTUpIHtcbiAgICAgIHRyYW5zZm9ybS5yb3RhdGlvbiA9IHNrZXdZIC0gTWF0aC5QSTtcbiAgICAgIHRyYW5zZm9ybS5za2V3LnggPSB0cmFuc2Zvcm0uc2tldy55ID0gMDtcbiAgICAgIHNjYWxlWCA9IC1zY2FsZVg7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRyYW5zZm9ybS5yb3RhdGlvbiA9IDA7XG4gICAgICB0cmFuc2Zvcm0uc2tldy54ID0gc2tld1g7XG4gICAgICB0cmFuc2Zvcm0uc2tldy55ID0gc2tld1k7XG4gICAgfVxuICAgIHRyYW5zZm9ybS5zY2FsZS54ID0gc2NhbGVYO1xuICAgIHRyYW5zZm9ybS5zY2FsZS55ID0gTWF0aC5zcXJ0KGMgKiBjICsgZCAqIGQpO1xuICAgIHRyYW5zZm9ybS5wb3NpdGlvbi54ID0gdGhpcy50eCArIChwaXZvdC54ICogYSArIHBpdm90LnkgKiBjKTtcbiAgICB0cmFuc2Zvcm0ucG9zaXRpb24ueSA9IHRoaXMudHkgKyAocGl2b3QueCAqIGIgKyBwaXZvdC55ICogZCk7XG4gICAgcmV0dXJuIHRyYW5zZm9ybTtcbiAgfVxuICAvKipcbiAgICogSW52ZXJ0cyB0aGlzIG1hdHJpeC5cbiAgICogQ3JlYXRlcyB0aGUgbWF0cml4IHRoYXQgd2hlbiBtdWx0aXBsaWVkIHdpdGggdGhpcyBtYXRyaXggcmVzdWx0cyBpbiBhbiBpZGVudGl0eSBtYXRyaXguXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIG1hdHJpeCBpbnZlcnNpb25cbiAgICogY29uc3QgbWF0cml4ID0gbmV3IE1hdHJpeCgpXG4gICAqICAgICAudHJhbnNsYXRlKDEwMCwgNTApXG4gICAqICAgICAuc2NhbGUoMiwgMik7XG4gICAqXG4gICAqIG1hdHJpeC5pbnZlcnQoKTsgLy8gTm93IHRyYW5zZm9ybXMgaW4gb3Bwb3NpdGUgZGlyZWN0aW9uXG4gICAqXG4gICAqIC8vIFZlcmlmeSBpbnZlcnNpb25cbiAgICogY29uc3QgcG9pbnQgPSBuZXcgUG9pbnQoNTAsIDUwKTtcbiAgICogY29uc3QgdHJhbnNmb3JtZWQgPSBtYXRyaXguYXBwbHkocG9pbnQpO1xuICAgKiBjb25zdCBvcmlnaW5hbCA9IG1hdHJpeC5pbnZlcnQoKS5hcHBseSh0cmFuc2Zvcm1lZCk7XG4gICAqIC8vIG9yaWdpbmFsIOKJiCBwb2ludFxuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBNb2RpZmllcyB0aGUgY3VycmVudCBtYXRyaXhcbiAgICogLSBVc2VmdWwgZm9yIHJldmVyc2luZyB0cmFuc2Zvcm1hdGlvbnNcbiAgICogLSBDYW5ub3QgaW52ZXJ0IG1hdHJpY2VzIHdpdGggemVybyBkZXRlcm1pbmFudFxuICAgKiBAcmV0dXJucyBUaGlzIG1hdHJpeC4gR29vZCBmb3IgY2hhaW5pbmcgbWV0aG9kIGNhbGxzLlxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguaWRlbnRpdHl9IEZvciByZXNldHRpbmcgdG8gaWRlbnRpdHlcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LmFwcGx5SW52ZXJzZX0gRm9yIGludmVyc2UgdHJhbnNmb3JtYXRpb25zXG4gICAqL1xuICBpbnZlcnQoKSB7XG4gICAgY29uc3QgYTEgPSB0aGlzLmE7XG4gICAgY29uc3QgYjEgPSB0aGlzLmI7XG4gICAgY29uc3QgYzEgPSB0aGlzLmM7XG4gICAgY29uc3QgZDEgPSB0aGlzLmQ7XG4gICAgY29uc3QgdHgxID0gdGhpcy50eDtcbiAgICBjb25zdCBuID0gYTEgKiBkMSAtIGIxICogYzE7XG4gICAgdGhpcy5hID0gZDEgLyBuO1xuICAgIHRoaXMuYiA9IC1iMSAvIG47XG4gICAgdGhpcy5jID0gLWMxIC8gbjtcbiAgICB0aGlzLmQgPSBhMSAvIG47XG4gICAgdGhpcy50eCA9IChjMSAqIHRoaXMudHkgLSBkMSAqIHR4MSkgLyBuO1xuICAgIHRoaXMudHkgPSAtKGExICogdGhpcy50eSAtIGIxICogdHgxKSAvIG47XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyBpZiB0aGlzIG1hdHJpeCBpcyBhbiBpZGVudGl0eSBtYXRyaXguXG4gICAqXG4gICAqIEFuIGlkZW50aXR5IG1hdHJpeCBoYXMgbm8gdHJhbnNmb3JtYXRpb25zIGFwcGxpZWQgKGRlZmF1bHQgc3RhdGUpLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBDaGVjayBpZiBtYXRyaXggaXMgaWRlbnRpdHlcbiAgICogY29uc3QgbWF0cml4ID0gbmV3IE1hdHJpeCgpO1xuICAgKiBjb25zb2xlLmxvZyhtYXRyaXguaXNJZGVudGl0eSgpKTsgLy8gdHJ1ZVxuICAgKlxuICAgKiAvLyBDaGVjayBhZnRlciB0cmFuc2Zvcm1hdGlvbnNcbiAgICogbWF0cml4LnRyYW5zbGF0ZSgxMDAsIDApO1xuICAgKiBjb25zb2xlLmxvZyhtYXRyaXguaXNJZGVudGl0eSgpKTsgLy8gZmFsc2VcbiAgICpcbiAgICogLy8gUmVzZXQgYW5kIHZlcmlmeVxuICAgKiBtYXRyaXguaWRlbnRpdHkoKTtcbiAgICogY29uc29sZS5sb2cobWF0cml4LmlzSWRlbnRpdHkoKSk7IC8vIHRydWVcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gVmVyaWZpZXMgYSA9IDEsIGQgPSAxIChubyBzY2FsZSlcbiAgICogLSBWZXJpZmllcyBiID0gMCwgYyA9IDAgKG5vIHNrZXcpXG4gICAqIC0gVmVyaWZpZXMgdHggPSAwLCB0eSA9IDAgKG5vIHRyYW5zbGF0aW9uKVxuICAgKiBAcmV0dXJucyBUcnVlIGlmIG1hdHJpeCBoYXMgbm8gdHJhbnNmb3JtYXRpb25zXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5pZGVudGl0eX0gRm9yIHJlc2V0dGluZyB0byBpZGVudGl0eVxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguSURFTlRJVFl9IEZvciBjb25zdGFudCBpZGVudGl0eSBtYXRyaXhcbiAgICovXG4gIGlzSWRlbnRpdHkoKSB7XG4gICAgcmV0dXJuIHRoaXMuYSA9PT0gMSAmJiB0aGlzLmIgPT09IDAgJiYgdGhpcy5jID09PSAwICYmIHRoaXMuZCA9PT0gMSAmJiB0aGlzLnR4ID09PSAwICYmIHRoaXMudHkgPT09IDA7XG4gIH1cbiAgLyoqXG4gICAqIFJlc2V0cyB0aGlzIE1hdHJpeCB0byBhbiBpZGVudGl0eSAoZGVmYXVsdCkgbWF0cml4LlxuICAgKiBTZXRzIGFsbCBjb21wb25lbnRzIHRvIHRoZWlyIGRlZmF1bHQgdmFsdWVzOiBzY2FsZT0xLCBubyBza2V3LCBubyB0cmFuc2xhdGlvbi5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gUmVzZXQgdHJhbnNmb3JtZWQgbWF0cml4XG4gICAqIGNvbnN0IG1hdHJpeCA9IG5ldyBNYXRyaXgoKVxuICAgKiAgICAgLnNjYWxlKDIsIDIpXG4gICAqICAgICAucm90YXRlKE1hdGguUEkgLyA0KTtcbiAgICogbWF0cml4LmlkZW50aXR5KCk7IC8vIEJhY2sgdG8gZGVmYXVsdCBzdGF0ZVxuICAgKlxuICAgKiAvLyBDaGFpbiBhZnRlciByZXNldFxuICAgKiBtYXRyaXhcbiAgICogICAgIC5pZGVudGl0eSgpXG4gICAqICAgICAudHJhbnNsYXRlKDEwMCwgMTAwKVxuICAgKiAgICAgLnNjYWxlKDIsIDIpO1xuICAgKlxuICAgKiAvLyBDb21wYXJlIHdpdGggaWRlbnRpdHkgY29uc3RhbnRcbiAgICogY29uc3QgaXNEZWZhdWx0ID0gbWF0cml4LmVxdWFscyhNYXRyaXguSURFTlRJVFkpO1xuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBTZXRzIGE9MSwgZD0xIChkZWZhdWx0IHNjYWxlKVxuICAgKiAtIFNldHMgYj0wLCBjPTAgKG5vIHNrZXcpXG4gICAqIC0gU2V0cyB0eD0wLCB0eT0wIChubyB0cmFuc2xhdGlvbilcbiAgICogQHJldHVybnMgVGhpcyBtYXRyaXguIEdvb2QgZm9yIGNoYWluaW5nIG1ldGhvZCBjYWxscy5cbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LklERU5USVRZfSBGb3IgY29uc3RhbnQgaWRlbnRpdHkgbWF0cml4XG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5pc0lkZW50aXR5fSBGb3IgY2hlY2tpbmcgaWRlbnRpdHkgc3RhdGVcbiAgICovXG4gIGlkZW50aXR5KCkge1xuICAgIHRoaXMuYSA9IDE7XG4gICAgdGhpcy5iID0gMDtcbiAgICB0aGlzLmMgPSAwO1xuICAgIHRoaXMuZCA9IDE7XG4gICAgdGhpcy50eCA9IDA7XG4gICAgdGhpcy50eSA9IDA7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgTWF0cml4IG9iamVjdCB3aXRoIHRoZSBzYW1lIHZhbHVlcyBhcyB0aGlzIG9uZS5cbiAgICogQHJldHVybnMgQSBjb3B5IG9mIHRoaXMgbWF0cml4LiBHb29kIGZvciBjaGFpbmluZyBtZXRob2QgY2FsbHMuXG4gICAqL1xuICBjbG9uZSgpIHtcbiAgICBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KCk7XG4gICAgbWF0cml4LmEgPSB0aGlzLmE7XG4gICAgbWF0cml4LmIgPSB0aGlzLmI7XG4gICAgbWF0cml4LmMgPSB0aGlzLmM7XG4gICAgbWF0cml4LmQgPSB0aGlzLmQ7XG4gICAgbWF0cml4LnR4ID0gdGhpcy50eDtcbiAgICBtYXRyaXgudHkgPSB0aGlzLnR5O1xuICAgIHJldHVybiBtYXRyaXg7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgTWF0cml4IG9iamVjdCB3aXRoIHRoZSBzYW1lIHZhbHVlcyBhcyB0aGlzIG9uZS5cbiAgICogQHBhcmFtIG1hdHJpeFxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBtYXRyaXggY2xvbmluZ1xuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KClcbiAgICogICAgIC50cmFuc2xhdGUoMTAwLCAxMDApXG4gICAqICAgICAucm90YXRlKE1hdGguUEkgLyA0KTtcbiAgICogY29uc3QgY29weSA9IG1hdHJpeC5jbG9uZSgpO1xuICAgKlxuICAgKiAvLyBDbG9uZSBhbmQgbW9kaWZ5XG4gICAqIGNvbnN0IG1vZGlmaWVkID0gbWF0cml4LmNsb25lKClcbiAgICogICAgIC5zY2FsZSgyLCAyKTtcbiAgICpcbiAgICogLy8gQ29tcGFyZSBtYXRyaWNlc1xuICAgKiBjb25zb2xlLmxvZyhtYXRyaXguZXF1YWxzKGNvcHkpKTsgICAgIC8vIHRydWVcbiAgICogY29uc29sZS5sb2cobWF0cml4LmVxdWFscyhtb2RpZmllZCkpOyAvLyBmYWxzZVxuICAgKiBgYGBcbiAgICogQHJldHVybnMgQSBjb3B5IG9mIHRoaXMgbWF0cml4LiBHb29kIGZvciBjaGFpbmluZyBtZXRob2QgY2FsbHMuXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5jb3B5VG99IEZvciBjb3B5aW5nIHRvIGV4aXN0aW5nIG1hdHJpeFxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguY29weUZyb219IEZvciBjb3B5aW5nIGZyb20gYW5vdGhlciBtYXRyaXhcbiAgICovXG4gIGNvcHlUbyhtYXRyaXgpIHtcbiAgICBtYXRyaXguYSA9IHRoaXMuYTtcbiAgICBtYXRyaXguYiA9IHRoaXMuYjtcbiAgICBtYXRyaXguYyA9IHRoaXMuYztcbiAgICBtYXRyaXguZCA9IHRoaXMuZDtcbiAgICBtYXRyaXgudHggPSB0aGlzLnR4O1xuICAgIG1hdHJpeC50eSA9IHRoaXMudHk7XG4gICAgcmV0dXJuIG1hdHJpeDtcbiAgfVxuICAvKipcbiAgICogQ2hhbmdlcyB0aGUgdmFsdWVzIG9mIHRoZSBtYXRyaXggdG8gYmUgdGhlIHNhbWUgYXMgdGhlIG9uZXMgaW4gZ2l2ZW4gbWF0cml4LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBtYXRyaXggY29weWluZ1xuICAgKiBjb25zdCBzb3VyY2UgPSBuZXcgTWF0cml4KClcbiAgICogICAgIC50cmFuc2xhdGUoMTAwLCAxMDApXG4gICAqICAgICAucm90YXRlKE1hdGguUEkgLyA0KTtcbiAgICogY29uc3QgdGFyZ2V0ID0gbmV3IE1hdHJpeCgpO1xuICAgKiB0YXJnZXQuY29weUZyb20oc291cmNlKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSBtYXRyaXggLSBUaGUgbWF0cml4IHRvIGNvcHkgZnJvbVxuICAgKiBAcmV0dXJucyBUaGlzIG1hdHJpeC4gR29vZCBmb3IgY2hhaW5pbmcgbWV0aG9kIGNhbGxzLlxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguY2xvbmV9IEZvciBjcmVhdGluZyBuZXcgbWF0cml4IGNvcHlcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LmNvcHlUb30gRm9yIGNvcHlpbmcgdG8gYW5vdGhlciBtYXRyaXhcbiAgICovXG4gIGNvcHlGcm9tKG1hdHJpeCkge1xuICAgIHRoaXMuYSA9IG1hdHJpeC5hO1xuICAgIHRoaXMuYiA9IG1hdHJpeC5iO1xuICAgIHRoaXMuYyA9IG1hdHJpeC5jO1xuICAgIHRoaXMuZCA9IG1hdHJpeC5kO1xuICAgIHRoaXMudHggPSBtYXRyaXgudHg7XG4gICAgdGhpcy50eSA9IG1hdHJpeC50eTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQ2hlY2tzIGlmIHRoaXMgbWF0cml4IGVxdWFscyBhbm90aGVyIG1hdHJpeC5cbiAgICogQ29tcGFyZXMgYWxsIGNvbXBvbmVudHMgZm9yIGV4YWN0IGVxdWFsaXR5LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBlcXVhbGl0eSBjaGVja1xuICAgKiBjb25zdCBtMSA9IG5ldyBNYXRyaXgoKTtcbiAgICogY29uc3QgbTIgPSBuZXcgTWF0cml4KCk7XG4gICAqIGNvbnNvbGUubG9nKG0xLmVxdWFscyhtMikpOyAvLyB0cnVlXG4gICAqXG4gICAqIC8vIENvbXBhcmUgdHJhbnNmb3JtZWQgbWF0cmljZXNcbiAgICogY29uc3QgdHJhbnNmb3JtID0gbmV3IE1hdHJpeCgpXG4gICAqICAgICAudHJhbnNsYXRlKDEwMCwgMTAwKVxuICAgKiBjb25zdCBjbG9uZSA9IG5ldyBNYXRyaXgoKVxuICAgKiAgICAgLnNjYWxlKDIsIDIpO1xuICAgKiBjb25zb2xlLmxvZyh0cmFuc2Zvcm0uZXF1YWxzKGNsb25lKSk7IC8vIGZhbHNlXG4gICAqIGBgYFxuICAgKiBAcGFyYW0gbWF0cml4IC0gVGhlIG1hdHJpeCB0byBjb21wYXJlIHRvXG4gICAqIEByZXR1cm5zIFRydWUgaWYgbWF0cmljZXMgYXJlIGlkZW50aWNhbFxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguY29weUZyb219IEZvciBjb3B5aW5nIG1hdHJpeCB2YWx1ZXNcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LmlzSWRlbnRpdHl9IEZvciBpZGVudGl0eSBjb21wYXJpc29uXG4gICAqL1xuICBlcXVhbHMobWF0cml4KSB7XG4gICAgcmV0dXJuIG1hdHJpeC5hID09PSB0aGlzLmEgJiYgbWF0cml4LmIgPT09IHRoaXMuYiAmJiBtYXRyaXguYyA9PT0gdGhpcy5jICYmIG1hdHJpeC5kID09PSB0aGlzLmQgJiYgbWF0cml4LnR4ID09PSB0aGlzLnR4ICYmIG1hdHJpeC50eSA9PT0gdGhpcy50eTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYFtwaXhpLmpzOk1hdHJpeCBhPSR7dGhpcy5hfSBiPSR7dGhpcy5ifSBjPSR7dGhpcy5jfSBkPSR7dGhpcy5kfSB0eD0ke3RoaXMudHh9IHR5PSR7dGhpcy50eX1dYDtcbiAgfVxuICAvKipcbiAgICogQSBkZWZhdWx0IChpZGVudGl0eSkgbWF0cml4IHdpdGggbm8gdHJhbnNmb3JtYXRpb25zIGFwcGxpZWQuXG4gICAqXG4gICAqID4gWyFJTVBPUlRBTlRdIFRoaXMgaXMgYSBzaGFyZWQgcmVhZC1vbmx5IG9iamVjdC4gQ3JlYXRlIGEgbmV3IE1hdHJpeCBpZiB5b3UgbmVlZCB0byBtb2RpZnkgaXQuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEdldCBpZGVudGl0eSBtYXRyaXggcmVmZXJlbmNlXG4gICAqIGNvbnN0IGlkZW50aXR5ID0gTWF0cml4LklERU5USVRZO1xuICAgKiBjb25zb2xlLmxvZyhpZGVudGl0eS5pc0lkZW50aXR5KCkpOyAvLyB0cnVlXG4gICAqXG4gICAqIC8vIENvbXBhcmUgd2l0aCBpZGVudGl0eVxuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KCk7XG4gICAqIGNvbnNvbGUubG9nKG1hdHJpeC5lcXVhbHMoTWF0cml4LklERU5USVRZKSk7IC8vIHRydWVcbiAgICpcbiAgICogLy8gQ3JlYXRlIG5ldyBtYXRyaXggaW5zdGVhZCBvZiBtb2RpZnlpbmcgSURFTlRJVFlcbiAgICogY29uc3QgdHJhbnNmb3JtID0gbmV3IE1hdHJpeCgpXG4gICAqICAgICAuY29weUZyb20oTWF0cml4LklERU5USVRZKVxuICAgKiAgICAgLnRyYW5zbGF0ZSgxMDAsIDEwMCk7XG4gICAqIGBgYFxuICAgKiBAcmVhZG9ubHlcbiAgICogQHJldHVybnMgQSByZWFkLW9ubHkgaWRlbnRpdHkgbWF0cml4XG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5zaGFyZWR9IEZvciB0ZW1wb3JhcnkgY2FsY3VsYXRpb25zXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeC5pZGVudGl0eX0gRm9yIHJlc2V0dGluZyBtYXRyaWNlc1xuICAgKi9cbiAgc3RhdGljIGdldCBJREVOVElUWSgpIHtcbiAgICByZXR1cm4gaWRlbnRpdHlNYXRyaXguaWRlbnRpdHkoKTtcbiAgfVxuICAvKipcbiAgICogQSBzdGF0aWMgTWF0cml4IHRoYXQgY2FuIGJlIHVzZWQgdG8gYXZvaWQgY3JlYXRpbmcgbmV3IG9iamVjdHMuXG4gICAqIFdpbGwgYWx3YXlzIGVuc3VyZSB0aGUgbWF0cml4IGlzIHJlc2V0IHRvIGlkZW50aXR5IHdoZW4gcmVxdWVzdGVkLlxuICAgKlxuICAgKiA+IFshSU1QT1JUQU5UXSBUaGlzIG1hdHJpeCBpcyBzaGFyZWQgYW5kIHRlbXBvcmFyeS4gRG8gbm90IHN0b3JlIHJlZmVyZW5jZXMgdG8gaXQuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIFVzZSBmb3IgdGVtcG9yYXJ5IGNhbGN1bGF0aW9uc1xuICAgKiBjb25zdCB0ZW1wTWF0cml4ID0gTWF0cml4LnNoYXJlZDtcbiAgICogdGVtcE1hdHJpeC50cmFuc2xhdGUoMTAwLCAxMDApLnJvdGF0ZShNYXRoLlBJIC8gNCk7XG4gICAqIGNvbnN0IHBvaW50ID0gdGVtcE1hdHJpeC5hcHBseSh7IHg6IDEwLCB5OiAyMCB9KTtcbiAgICpcbiAgICogLy8gV2lsbCBiZSByZXNldCB0byBpZGVudGl0eSBvbiBuZXh0IGFjY2Vzc1xuICAgKiBjb25zdCBmcmVzaCA9IE1hdHJpeC5zaGFyZWQ7IC8vIEJhY2sgdG8gaWRlbnRpdHlcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gQWx3YXlzIHJldHVybnMgaWRlbnRpdHkgbWF0cml4XG4gICAqIC0gU2FmZSB0byBtb2RpZnkgdGVtcG9yYXJpbHlcbiAgICogLSBOb3Qgc2FmZSB0byBzdG9yZSByZWZlcmVuY2VzXG4gICAqIC0gVXNlZnVsIGZvciBvbmUtb2ZmIGNhbGN1bGF0aW9uc1xuICAgKiBAcmVhZG9ubHlcbiAgICogQHJldHVybnMgQSBmcmVzaCBpZGVudGl0eSBtYXRyaXggZm9yIHRlbXBvcmFyeSB1c2VcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4LklERU5USVRZfSBGb3IgaW1tdXRhYmxlIGlkZW50aXR5IG1hdHJpeFxuICAgKiBAc2VlIHtAbGluayBNYXRyaXguaWRlbnRpdHl9IEZvciByZXNldHRpbmcgbWF0cmljZXNcbiAgICovXG4gIHN0YXRpYyBnZXQgc2hhcmVkKCkge1xuICAgIHJldHVybiB0ZW1wTWF0cml4LmlkZW50aXR5KCk7XG4gIH1cbn1cbmNvbnN0IHRlbXBNYXRyaXggPSBuZXcgTWF0cml4KCk7XG5jb25zdCBpZGVudGl0eU1hdHJpeCA9IG5ldyBNYXRyaXgoKTtcblxuZXhwb3J0IHsgTWF0cml4IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1NYXRyaXgubWpzLm1hcFxuIiwiaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi9NYXRyaXgubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCB1eCA9IFsxLCAxLCAwLCAtMSwgLTEsIC0xLCAwLCAxLCAxLCAxLCAwLCAtMSwgLTEsIC0xLCAwLCAxXTtcbmNvbnN0IHV5ID0gWzAsIDEsIDEsIDEsIDAsIC0xLCAtMSwgLTEsIDAsIDEsIDEsIDEsIDAsIC0xLCAtMSwgLTFdO1xuY29uc3QgdnggPSBbMCwgLTEsIC0xLCAtMSwgMCwgMSwgMSwgMSwgMCwgMSwgMSwgMSwgMCwgLTEsIC0xLCAtMV07XG5jb25zdCB2eSA9IFsxLCAxLCAwLCAtMSwgLTEsIC0xLCAwLCAxLCAtMSwgLTEsIDAsIDEsIDEsIDEsIDAsIC0xXTtcbmNvbnN0IHJvdGF0aW9uQ2F5bGV5ID0gW107XG5jb25zdCByb3RhdGlvbk1hdHJpY2VzID0gW107XG5jb25zdCBzaWdudW0gPSBNYXRoLnNpZ247XG5mdW5jdGlvbiBpbml0KCkge1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDE2OyBpKyspIHtcbiAgICBjb25zdCByb3cgPSBbXTtcbiAgICByb3RhdGlvbkNheWxleS5wdXNoKHJvdyk7XG4gICAgZm9yIChsZXQgaiA9IDA7IGogPCAxNjsgaisrKSB7XG4gICAgICBjb25zdCBfdXggPSBzaWdudW0odXhbaV0gKiB1eFtqXSArIHZ4W2ldICogdXlbal0pO1xuICAgICAgY29uc3QgX3V5ID0gc2lnbnVtKHV5W2ldICogdXhbal0gKyB2eVtpXSAqIHV5W2pdKTtcbiAgICAgIGNvbnN0IF92eCA9IHNpZ251bSh1eFtpXSAqIHZ4W2pdICsgdnhbaV0gKiB2eVtqXSk7XG4gICAgICBjb25zdCBfdnkgPSBzaWdudW0odXlbaV0gKiB2eFtqXSArIHZ5W2ldICogdnlbal0pO1xuICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCAxNjsgaysrKSB7XG4gICAgICAgIGlmICh1eFtrXSA9PT0gX3V4ICYmIHV5W2tdID09PSBfdXkgJiYgdnhba10gPT09IF92eCAmJiB2eVtrXSA9PT0gX3Z5KSB7XG4gICAgICAgICAgcm93LnB1c2goayk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxNjsgaSsrKSB7XG4gICAgY29uc3QgbWF0ID0gbmV3IE1hdHJpeCgpO1xuICAgIG1hdC5zZXQodXhbaV0sIHV5W2ldLCB2eFtpXSwgdnlbaV0sIDAsIDApO1xuICAgIHJvdGF0aW9uTWF0cmljZXMucHVzaChtYXQpO1xuICB9XG59XG5pbml0KCk7XG5jb25zdCBncm91cEQ4ID0ge1xuICAvKipcbiAgICogfCBSb3RhdGlvbiB8IERpcmVjdGlvbiB8XG4gICAqIHwtLS0tLS0tLS0tfC0tLS0tLS0tLS0tfFxuICAgKiB8IDDCsCAgICAgICB8IEVhc3QgICAgICB8XG4gICAqIEBncm91cCBncm91cEQ4XG4gICAqIEB0eXBlIHtHRDhTeW1tZXRyeX1cbiAgICovXG4gIEU6IDAsXG4gIC8qKlxuICAgKiB8IFJvdGF0aW9uIHwgRGlyZWN0aW9uIHxcbiAgICogfC0tLS0tLS0tLS18LS0tLS0tLS0tLS18XG4gICAqIHwgNDXCsOKGuyAgICAgfCBTb3V0aGVhc3QgfFxuICAgKiBAZ3JvdXAgZ3JvdXBEOFxuICAgKiBAdHlwZSB7R0Q4U3ltbWV0cnl9XG4gICAqL1xuICBTRTogMSxcbiAgLyoqXG4gICAqIHwgUm90YXRpb24gfCBEaXJlY3Rpb24gfFxuICAgKiB8LS0tLS0tLS0tLXwtLS0tLS0tLS0tLXxcbiAgICogfCA5MMKw4oa7ICAgICB8IFNvdXRoICAgICB8XG4gICAqIEBncm91cCBncm91cEQ4XG4gICAqIEB0eXBlIHtHRDhTeW1tZXRyeX1cbiAgICovXG4gIFM6IDIsXG4gIC8qKlxuICAgKiB8IFJvdGF0aW9uIHwgRGlyZWN0aW9uIHxcbiAgICogfC0tLS0tLS0tLS18LS0tLS0tLS0tLS18XG4gICAqIHwgMTM1wrDihrsgICAgfCBTb3V0aHdlc3QgfFxuICAgKiBAZ3JvdXAgZ3JvdXBEOFxuICAgKiBAdHlwZSB7R0Q4U3ltbWV0cnl9XG4gICAqL1xuICBTVzogMyxcbiAgLyoqXG4gICAqIHwgUm90YXRpb24gfCBEaXJlY3Rpb24gfFxuICAgKiB8LS0tLS0tLS0tLXwtLS0tLS0tLS0tLXxcbiAgICogfCAxODDCsCAgICAgfCBXZXN0ICAgICAgfFxuICAgKiBAZ3JvdXAgZ3JvdXBEOFxuICAgKiBAdHlwZSB7R0Q4U3ltbWV0cnl9XG4gICAqL1xuICBXOiA0LFxuICAvKipcbiAgICogfCBSb3RhdGlvbiAgICB8IERpcmVjdGlvbiAgICB8XG4gICAqIHwtLS0tLS0tLS0tLS0tfC0tLS0tLS0tLS0tLS0tfFxuICAgKiB8IC0xMzXCsC8yMjXCsOKGuyB8IE5vcnRod2VzdCAgICB8XG4gICAqIEBncm91cCBncm91cEQ4XG4gICAqIEB0eXBlIHtHRDhTeW1tZXRyeX1cbiAgICovXG4gIE5XOiA1LFxuICAvKipcbiAgICogfCBSb3RhdGlvbiAgICB8IERpcmVjdGlvbiAgICB8XG4gICAqIHwtLS0tLS0tLS0tLS0tfC0tLS0tLS0tLS0tLS0tfFxuICAgKiB8IC05MMKwLzI3MMKw4oa7ICB8IE5vcnRoICAgICAgICB8XG4gICAqIEBncm91cCBncm91cEQ4XG4gICAqIEB0eXBlIHtHRDhTeW1tZXRyeX1cbiAgICovXG4gIE46IDYsXG4gIC8qKlxuICAgKiB8IFJvdGF0aW9uICAgIHwgRGlyZWN0aW9uICAgIHxcbiAgICogfC0tLS0tLS0tLS0tLS18LS0tLS0tLS0tLS0tLS18XG4gICAqIHwgLTQ1wrAvMzE1wrDihrsgIHwgTm9ydGhlYXN0ICAgIHxcbiAgICogQGdyb3VwIGdyb3VwRDhcbiAgICogQHR5cGUge0dEOFN5bW1ldHJ5fVxuICAgKi9cbiAgTkU6IDcsXG4gIC8qKlxuICAgKiBSZWZsZWN0aW9uIGFib3V0IFktYXhpcy5cbiAgICogQGdyb3VwIGdyb3VwRDhcbiAgICogQHR5cGUge0dEOFN5bW1ldHJ5fVxuICAgKi9cbiAgTUlSUk9SX1ZFUlRJQ0FMOiA4LFxuICAvKipcbiAgICogUmVmbGVjdGlvbiBhYm91dCB0aGUgbWFpbiBkaWFnb25hbC5cbiAgICogQGdyb3VwIGdyb3VwRDhcbiAgICogQHR5cGUge0dEOFN5bW1ldHJ5fVxuICAgKi9cbiAgTUFJTl9ESUFHT05BTDogMTAsXG4gIC8qKlxuICAgKiBSZWZsZWN0aW9uIGFib3V0IFgtYXhpcy5cbiAgICogQGdyb3VwIGdyb3VwRDhcbiAgICogQHR5cGUge0dEOFN5bW1ldHJ5fVxuICAgKi9cbiAgTUlSUk9SX0hPUklaT05UQUw6IDEyLFxuICAvKipcbiAgICogUmVmbGVjdGlvbiBhYm91dCByZXZlcnNlIGRpYWdvbmFsLlxuICAgKiBAZ3JvdXAgZ3JvdXBEOFxuICAgKiBAdHlwZSB7R0Q4U3ltbWV0cnl9XG4gICAqL1xuICBSRVZFUlNFX0RJQUdPTkFMOiAxNCxcbiAgLyoqXG4gICAqIEBncm91cCBncm91cEQ4XG4gICAqIEBwYXJhbSB7R0Q4U3ltbWV0cnl9IGluZCAtIHNwcml0ZSByb3RhdGlvbiBhbmdsZS5cbiAgICogQHJldHVybnMge0dEOFN5bW1ldHJ5fSBUaGUgWC1jb21wb25lbnQgb2YgdGhlIFUtYXhpc1xuICAgKiAgICBhZnRlciByb3RhdGluZyB0aGUgYXhlcy5cbiAgICovXG4gIHVYOiAoaW5kKSA9PiB1eFtpbmRdLFxuICAvKipcbiAgICogQGdyb3VwIGdyb3VwRDhcbiAgICogQHBhcmFtIHtHRDhTeW1tZXRyeX0gaW5kIC0gc3ByaXRlIHJvdGF0aW9uIGFuZ2xlLlxuICAgKiBAcmV0dXJucyB7R0Q4U3ltbWV0cnl9IFRoZSBZLWNvbXBvbmVudCBvZiB0aGUgVS1heGlzXG4gICAqICAgIGFmdGVyIHJvdGF0aW5nIHRoZSBheGVzLlxuICAgKi9cbiAgdVk6IChpbmQpID0+IHV5W2luZF0sXG4gIC8qKlxuICAgKiBAZ3JvdXAgZ3JvdXBEOFxuICAgKiBAcGFyYW0ge0dEOFN5bW1ldHJ5fSBpbmQgLSBzcHJpdGUgcm90YXRpb24gYW5nbGUuXG4gICAqIEByZXR1cm5zIHtHRDhTeW1tZXRyeX0gVGhlIFgtY29tcG9uZW50IG9mIHRoZSBWLWF4aXNcbiAgICogICAgYWZ0ZXIgcm90YXRpbmcgdGhlIGF4ZXMuXG4gICAqL1xuICB2WDogKGluZCkgPT4gdnhbaW5kXSxcbiAgLyoqXG4gICAqIEBncm91cCBncm91cEQ4XG4gICAqIEBwYXJhbSB7R0Q4U3ltbWV0cnl9IGluZCAtIHNwcml0ZSByb3RhdGlvbiBhbmdsZS5cbiAgICogQHJldHVybnMge0dEOFN5bW1ldHJ5fSBUaGUgWS1jb21wb25lbnQgb2YgdGhlIFYtYXhpc1xuICAgKiAgICBhZnRlciByb3RhdGluZyB0aGUgYXhlcy5cbiAgICovXG4gIHZZOiAoaW5kKSA9PiB2eVtpbmRdLFxuICAvKipcbiAgICogQGdyb3VwIGdyb3VwRDhcbiAgICogQHBhcmFtIHtHRDhTeW1tZXRyeX0gcm90YXRpb24gLSBzeW1tZXRyeSB3aG9zZSBvcHBvc2l0ZVxuICAgKiAgIGlzIG5lZWRlZC4gT25seSByb3RhdGlvbnMgaGF2ZSBvcHBvc2l0ZSBzeW1tZXRyaWVzIHdoaWxlXG4gICAqICAgcmVmbGVjdGlvbnMgZG9uJ3QuXG4gICAqIEByZXR1cm5zIHtHRDhTeW1tZXRyeX0gVGhlIG9wcG9zaXRlIHN5bW1ldHJ5IG9mIGByb3RhdGlvbmBcbiAgICovXG4gIGludjogKHJvdGF0aW9uKSA9PiB7XG4gICAgaWYgKHJvdGF0aW9uICYgOCkge1xuICAgICAgcmV0dXJuIHJvdGF0aW9uICYgMTU7XG4gICAgfVxuICAgIHJldHVybiAtcm90YXRpb24gJiA3O1xuICB9LFxuICAvKipcbiAgICogQ29tcG9zZXMgdGhlIHR3byBEOCBvcGVyYXRpb25zLlxuICAgKlxuICAgKiBUYWtpbmcgYF5gIGFzIHJlZmxlY3Rpb246XG4gICAqXG4gICAqIHwgICAgICAgfCBFPTAgfCBTPTIgfCBXPTQgfCBOPTYgfCBFXj04IHwgU149MTAgfCBXXj0xMiB8IE5ePTE0IHxcbiAgICogfC0tLS0tLS18LS0tLS18LS0tLS18LS0tLS18LS0tLS18LS0tLS0tfC0tLS0tLS18LS0tLS0tLXwtLS0tLS0tfFxuICAgKiB8IEU9MCAgIHwgRSAgIHwgUyAgIHwgVyAgIHwgTiAgIHwgRV4gICB8IFNeICAgIHwgV14gICAgfCBOXiAgICB8XG4gICAqIHwgUz0yICAgfCBTICAgfCBXICAgfCBOICAgfCBFICAgfCBTXiAgIHwgV14gICAgfCBOXiAgICB8IEVeICAgIHxcbiAgICogfCBXPTQgICB8IFcgICB8IE4gICB8IEUgICB8IFMgICB8IFdeICAgfCBOXiAgICB8IEVeICAgIHwgU14gICAgfFxuICAgKiB8IE49NiAgIHwgTiAgIHwgRSAgIHwgUyAgIHwgVyAgIHwgTl4gICB8IEVeICAgIHwgU14gICAgfCBXXiAgICB8XG4gICAqIHwgRV49OCAgfCBFXiAgfCBOXiAgfCBXXiAgfCBTXiAgfCBFICAgIHwgTiAgICAgfCBXICAgICB8IFMgICAgIHxcbiAgICogfCBTXj0xMCB8IFNeICB8IEVeICB8IE5eICB8IFdeICB8IFMgICAgfCBFICAgICB8IE4gICAgIHwgVyAgICAgfFxuICAgKiB8IFdePTEyIHwgV14gIHwgU14gIHwgRV4gIHwgTl4gIHwgVyAgICB8IFMgICAgIHwgRSAgICAgfCBOICAgICB8XG4gICAqIHwgTl49MTQgfCBOXiAgfCBXXiAgfCBTXiAgfCBFXiAgfCBOICAgIHwgVyAgICAgfCBTICAgICB8IEUgICAgIHxcbiAgICpcbiAgICogW1RoaXMgaXMgYSBDYXlsZXkgdGFibGVde0BsaW5rIGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0NheWxleV90YWJsZX1cbiAgICogQGdyb3VwIGdyb3VwRDhcbiAgICogQHBhcmFtIHtHRDhTeW1tZXRyeX0gcm90YXRpb25TZWNvbmQgLSBTZWNvbmQgb3BlcmF0aW9uLCB3aGljaFxuICAgKiAgIGlzIHRoZSByb3cgaW4gdGhlIGFib3ZlIGNheWxleSB0YWJsZS5cbiAgICogQHBhcmFtIHtHRDhTeW1tZXRyeX0gcm90YXRpb25GaXJzdCAtIEZpcnN0IG9wZXJhdGlvbiwgd2hpY2hcbiAgICogICBpcyB0aGUgY29sdW1uIGluIHRoZSBhYm92ZSBjYXlsZXkgdGFibGUuXG4gICAqIEByZXR1cm5zIHtHRDhTeW1tZXRyeX0gQ29tcG9zZWQgb3BlcmF0aW9uXG4gICAqL1xuICBhZGQ6IChyb3RhdGlvblNlY29uZCwgcm90YXRpb25GaXJzdCkgPT4gcm90YXRpb25DYXlsZXlbcm90YXRpb25TZWNvbmRdW3JvdGF0aW9uRmlyc3RdLFxuICAvKipcbiAgICogUmV2ZXJzZSBvZiBgYWRkYC5cbiAgICogQGdyb3VwIGdyb3VwRDhcbiAgICogQHBhcmFtIHtHRDhTeW1tZXRyeX0gcm90YXRpb25TZWNvbmQgLSBTZWNvbmQgb3BlcmF0aW9uXG4gICAqIEBwYXJhbSB7R0Q4U3ltbWV0cnl9IHJvdGF0aW9uRmlyc3QgLSBGaXJzdCBvcGVyYXRpb25cbiAgICogQHJldHVybnMge0dEOFN5bW1ldHJ5fSBSZXN1bHRcbiAgICovXG4gIHN1YjogKHJvdGF0aW9uU2Vjb25kLCByb3RhdGlvbkZpcnN0KSA9PiByb3RhdGlvbkNheWxleVtyb3RhdGlvblNlY29uZF1bZ3JvdXBEOC5pbnYocm90YXRpb25GaXJzdCldLFxuICAvKipcbiAgICogQWRkcyAxODAgZGVncmVlcyB0byByb3RhdGlvbiwgd2hpY2ggaXMgYSBjb21tdXRhdGl2ZVxuICAgKiBvcGVyYXRpb24uXG4gICAqIEBncm91cCBncm91cEQ4XG4gICAqIEBwYXJhbSB7bnVtYmVyfSByb3RhdGlvbiAtIFRoZSBudW1iZXIgdG8gcm90YXRlLlxuICAgKiBAcmV0dXJucyB7bnVtYmVyfSBSb3RhdGVkIG51bWJlclxuICAgKi9cbiAgcm90YXRlMTgwOiAocm90YXRpb24pID0+IHJvdGF0aW9uIF4gNCxcbiAgLyoqXG4gICAqIENoZWNrcyBpZiB0aGUgcm90YXRpb24gYW5nbGUgaXMgdmVydGljYWwsIGkuZS4gc291dGhcbiAgICogb3Igbm9ydGguIEl0IGRvZXNuJ3Qgd29yayBmb3IgcmVmbGVjdGlvbnMuXG4gICAqIEBncm91cCBncm91cEQ4XG4gICAqIEBwYXJhbSB7R0Q4U3ltbWV0cnl9IHJvdGF0aW9uIC0gVGhlIG51bWJlciB0byBjaGVjay5cbiAgICogQHJldHVybnMge2Jvb2xlYW59IFdoZXRoZXIgb3Igbm90IHRoZSBkaXJlY3Rpb24gaXMgdmVydGljYWxcbiAgICovXG4gIGlzVmVydGljYWw6IChyb3RhdGlvbikgPT4gKHJvdGF0aW9uICYgMykgPT09IDIsXG4gIC8vIHJvdGF0aW9uICUgNCA9PT0gMlxuICAvKipcbiAgICogQXBwcm94aW1hdGVzIHRoZSB2ZWN0b3IgYFYoZHgsZHkpYCBpbnRvIG9uZSBvZiB0aGVcbiAgICogZWlnaHQgZGlyZWN0aW9ucyBwcm92aWRlZCBieSBgZ3JvdXBEOGAuXG4gICAqIEBncm91cCBncm91cEQ4XG4gICAqIEBwYXJhbSB7bnVtYmVyfSBkeCAtIFgtY29tcG9uZW50IG9mIHRoZSB2ZWN0b3JcbiAgICogQHBhcmFtIHtudW1iZXJ9IGR5IC0gWS1jb21wb25lbnQgb2YgdGhlIHZlY3RvclxuICAgKiBAcmV0dXJucyB7R0Q4U3ltbWV0cnl9IEFwcHJveGltYXRpb24gb2YgdGhlIHZlY3RvciBpbnRvXG4gICAqICBvbmUgb2YgdGhlIGVpZ2h0IHN5bW1ldHJpZXMuXG4gICAqL1xuICBieURpcmVjdGlvbjogKGR4LCBkeSkgPT4ge1xuICAgIGlmIChNYXRoLmFicyhkeCkgKiAyIDw9IE1hdGguYWJzKGR5KSkge1xuICAgICAgaWYgKGR5ID49IDApIHtcbiAgICAgICAgcmV0dXJuIGdyb3VwRDguUztcbiAgICAgIH1cbiAgICAgIHJldHVybiBncm91cEQ4Lk47XG4gICAgfSBlbHNlIGlmIChNYXRoLmFicyhkeSkgKiAyIDw9IE1hdGguYWJzKGR4KSkge1xuICAgICAgaWYgKGR4ID4gMCkge1xuICAgICAgICByZXR1cm4gZ3JvdXBEOC5FO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGdyb3VwRDguVztcbiAgICB9IGVsc2UgaWYgKGR5ID4gMCkge1xuICAgICAgaWYgKGR4ID4gMCkge1xuICAgICAgICByZXR1cm4gZ3JvdXBEOC5TRTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBncm91cEQ4LlNXO1xuICAgIH0gZWxzZSBpZiAoZHggPiAwKSB7XG4gICAgICByZXR1cm4gZ3JvdXBEOC5ORTtcbiAgICB9XG4gICAgcmV0dXJuIGdyb3VwRDguTlc7XG4gIH0sXG4gIC8qKlxuICAgKiBIZWxwcyBzcHJpdGUgdG8gY29tcGVuc2F0ZSB0ZXh0dXJlIHBhY2tlciByb3RhdGlvbi5cbiAgICogQGdyb3VwIGdyb3VwRDhcbiAgICogQHBhcmFtIHtNYXRyaXh9IG1hdHJpeCAtIHNwcml0ZSB3b3JsZCBtYXRyaXhcbiAgICogQHBhcmFtIHtHRDhTeW1tZXRyeX0gcm90YXRpb24gLSBUaGUgcm90YXRpb24gZmFjdG9yIHRvIHVzZS5cbiAgICogQHBhcmFtIHtudW1iZXJ9IHR4IC0gc3ByaXRlIGFuY2hvcmluZ1xuICAgKiBAcGFyYW0ge251bWJlcn0gdHkgLSBzcHJpdGUgYW5jaG9yaW5nXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBkdyAtIHNwcml0ZSB3aWR0aFxuICAgKiBAcGFyYW0ge251bWJlcn0gZGggLSBzcHJpdGUgaGVpZ2h0XG4gICAqL1xuICBtYXRyaXhBcHBlbmRSb3RhdGlvbkludjogKG1hdHJpeCwgcm90YXRpb24sIHR4ID0gMCwgdHkgPSAwLCBkdyA9IDAsIGRoID0gMCkgPT4ge1xuICAgIGNvbnN0IG1hdCA9IHJvdGF0aW9uTWF0cmljZXNbZ3JvdXBEOC5pbnYocm90YXRpb24pXTtcbiAgICBjb25zdCBhID0gbWF0LmE7XG4gICAgY29uc3QgYiA9IG1hdC5iO1xuICAgIGNvbnN0IGMgPSBtYXQuYztcbiAgICBjb25zdCBkID0gbWF0LmQ7XG4gICAgY29uc3QgZmluYWxUeCA9IHR4IC0gTWF0aC5taW4oMCwgYSAqIGR3LCBjICogZGgsIGEgKiBkdyArIGMgKiBkaCk7XG4gICAgY29uc3QgZmluYWxUeSA9IHR5IC0gTWF0aC5taW4oMCwgYiAqIGR3LCBkICogZGgsIGIgKiBkdyArIGQgKiBkaCk7XG4gICAgY29uc3QgYTEgPSBtYXRyaXguYTtcbiAgICBjb25zdCBiMSA9IG1hdHJpeC5iO1xuICAgIGNvbnN0IGMxID0gbWF0cml4LmM7XG4gICAgY29uc3QgZDEgPSBtYXRyaXguZDtcbiAgICBtYXRyaXguYSA9IGEgKiBhMSArIGIgKiBjMTtcbiAgICBtYXRyaXguYiA9IGEgKiBiMSArIGIgKiBkMTtcbiAgICBtYXRyaXguYyA9IGMgKiBhMSArIGQgKiBjMTtcbiAgICBtYXRyaXguZCA9IGMgKiBiMSArIGQgKiBkMTtcbiAgICBtYXRyaXgudHggPSBmaW5hbFR4ICogYTEgKyBmaW5hbFR5ICogYzEgKyBtYXRyaXgudHg7XG4gICAgbWF0cml4LnR5ID0gZmluYWxUeCAqIGIxICsgZmluYWxUeSAqIGQxICsgbWF0cml4LnR5O1xuICB9LFxuICAvKipcbiAgICogVHJhbnNmb3JtcyByZWN0YW5nbGUgY29vcmRpbmF0ZXMgYmFzZWQgb24gdGV4dHVyZSBwYWNrZXIgcm90YXRpb24uXG4gICAqIFVzZWQgd2hlbiB0ZXh0dXJlIGF0bGFzIHBhZ2VzIGFyZSByb3RhdGVkIGFuZCBjb29yZGluYXRlcyBuZWVkIHRvIGJlIGFkanVzdGVkLlxuICAgKiBAZ3JvdXAgZ3JvdXBEOFxuICAgKiBAcGFyYW0ge1JlY3RhbmdsZUxpa2V9IHJlY3QgLSBSZWN0YW5nbGUgd2l0aCBvcmlnaW5hbCBjb29yZGluYXRlcyB0byB0cmFuc2Zvcm1cbiAgICogQHBhcmFtIHtSZWN0YW5nbGVMaWtlfSBzb3VyY2VGcmFtZSAtIFNvdXJjZSB0ZXh0dXJlIGZyYW1lIChpbmNsdWRlcyBvZmZzZXQgYW5kIGRpbWVuc2lvbnMpXG4gICAqIEBwYXJhbSB7R0Q4U3ltbWV0cnl9IHJvdGF0aW9uIC0gVGhlIGdyb3VwRDggcm90YXRpb24gdmFsdWVcbiAgICogQHBhcmFtIHtSZWN0YW5nbGV9IG91dCAtIFJlY3RhbmdsZSB0byBzdG9yZSB0aGUgcmVzdWx0XG4gICAqIEByZXR1cm5zIHtSZWN0YW5nbGV9IFRyYW5zZm9ybWVkIGNvb3JkaW5hdGVzIChpbmNsdWRlcyBzb3VyY2UgZnJhbWUgb2Zmc2V0KVxuICAgKi9cbiAgdHJhbnNmb3JtUmVjdENvb3JkczogKHJlY3QsIHNvdXJjZUZyYW1lLCByb3RhdGlvbiwgb3V0KSA9PiB7XG4gICAgY29uc3QgeyB4LCB5LCB3aWR0aCwgaGVpZ2h0IH0gPSByZWN0O1xuICAgIGNvbnN0IHsgeDogZnJhbWVYLCB5OiBmcmFtZVksIHdpZHRoOiBmcmFtZVdpZHRoLCBoZWlnaHQ6IGZyYW1lSGVpZ2h0IH0gPSBzb3VyY2VGcmFtZTtcbiAgICBpZiAocm90YXRpb24gPT09IGdyb3VwRDguRSkge1xuICAgICAgb3V0LnNldCh4ICsgZnJhbWVYLCB5ICsgZnJhbWVZLCB3aWR0aCwgaGVpZ2h0KTtcbiAgICAgIHJldHVybiBvdXQ7XG4gICAgfSBlbHNlIGlmIChyb3RhdGlvbiA9PT0gZ3JvdXBEOC5TKSB7XG4gICAgICByZXR1cm4gb3V0LnNldChcbiAgICAgICAgZnJhbWVXaWR0aCAtIHkgLSBoZWlnaHQgKyBmcmFtZVgsXG4gICAgICAgIHggKyBmcmFtZVksXG4gICAgICAgIGhlaWdodCxcbiAgICAgICAgd2lkdGhcbiAgICAgICk7XG4gICAgfSBlbHNlIGlmIChyb3RhdGlvbiA9PT0gZ3JvdXBEOC5XKSB7XG4gICAgICByZXR1cm4gb3V0LnNldChcbiAgICAgICAgZnJhbWVXaWR0aCAtIHggLSB3aWR0aCArIGZyYW1lWCxcbiAgICAgICAgZnJhbWVIZWlnaHQgLSB5IC0gaGVpZ2h0ICsgZnJhbWVZLFxuICAgICAgICB3aWR0aCxcbiAgICAgICAgaGVpZ2h0XG4gICAgICApO1xuICAgIH0gZWxzZSBpZiAocm90YXRpb24gPT09IGdyb3VwRDguTikge1xuICAgICAgcmV0dXJuIG91dC5zZXQoXG4gICAgICAgIHkgKyBmcmFtZVgsXG4gICAgICAgIGZyYW1lSGVpZ2h0IC0geCAtIHdpZHRoICsgZnJhbWVZLFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHdpZHRoXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gb3V0LnNldCh4ICsgZnJhbWVYLCB5ICsgZnJhbWVZLCB3aWR0aCwgaGVpZ2h0KTtcbiAgfVxufTtcblxuZXhwb3J0IHsgZ3JvdXBEOCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Z3JvdXBEOC5tanMubWFwXG4iLCJpbXBvcnQgeyBQb2ludCB9IGZyb20gJy4uL3BvaW50L1BvaW50Lm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgdGVtcFBvaW50cyA9IFtuZXcgUG9pbnQoKSwgbmV3IFBvaW50KCksIG5ldyBQb2ludCgpLCBuZXcgUG9pbnQoKV07XG5jbGFzcyBSZWN0YW5nbGUge1xuICAvKipcbiAgICogQHBhcmFtIHggLSBUaGUgWCBjb29yZGluYXRlIG9mIHRoZSB1cHBlci1sZWZ0IGNvcm5lciBvZiB0aGUgcmVjdGFuZ2xlXG4gICAqIEBwYXJhbSB5IC0gVGhlIFkgY29vcmRpbmF0ZSBvZiB0aGUgdXBwZXItbGVmdCBjb3JuZXIgb2YgdGhlIHJlY3RhbmdsZVxuICAgKiBAcGFyYW0gd2lkdGggLSBUaGUgb3ZlcmFsbCB3aWR0aCBvZiB0aGUgcmVjdGFuZ2xlXG4gICAqIEBwYXJhbSBoZWlnaHQgLSBUaGUgb3ZlcmFsbCBoZWlnaHQgb2YgdGhlIHJlY3RhbmdsZVxuICAgKi9cbiAgY29uc3RydWN0b3IoeCA9IDAsIHkgPSAwLCB3aWR0aCA9IDAsIGhlaWdodCA9IDApIHtcbiAgICAvKipcbiAgICAgKiBUaGUgdHlwZSBvZiB0aGUgb2JqZWN0LCBtYWlubHkgdXNlZCB0byBhdm9pZCBgaW5zdGFuY2VvZmAgY2hlY2tzXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIC8vIENoZWNrIHNoYXBlIHR5cGVcbiAgICAgKiBjb25zdCBzaGFwZSA9IG5ldyBSZWN0YW5nbGUoMCwgMCwgMTAwLCAxMDApO1xuICAgICAqIGNvbnNvbGUubG9nKHNoYXBlLnR5cGUpOyAvLyAncmVjdGFuZ2xlJ1xuICAgICAqXG4gICAgICogLy8gVXNlIGluIHR5cGUgZ3VhcmRzXG4gICAgICogaWYgKHNoYXBlLnR5cGUgPT09ICdyZWN0YW5nbGUnKSB7XG4gICAgICogICAgIGNvbnNvbGUubG9nKHNoYXBlLndpZHRoLCBzaGFwZS5oZWlnaHQpO1xuICAgICAqIH1cbiAgICAgKiBgYGBcbiAgICAgKiBAcmVhZG9ubHlcbiAgICAgKiBAZGVmYXVsdCAncmVjdGFuZ2xlJ1xuICAgICAqIEBzZWUge0BsaW5rIFNIQVBFX1BSSU1JVElWRX0gRm9yIGFsbCBzaGFwZSB0eXBlc1xuICAgICAqL1xuICAgIHRoaXMudHlwZSA9IFwicmVjdGFuZ2xlXCI7XG4gICAgdGhpcy54ID0gTnVtYmVyKHgpO1xuICAgIHRoaXMueSA9IE51bWJlcih5KTtcbiAgICB0aGlzLndpZHRoID0gTnVtYmVyKHdpZHRoKTtcbiAgICB0aGlzLmhlaWdodCA9IE51bWJlcihoZWlnaHQpO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBsZWZ0IGVkZ2UgKHgtY29vcmRpbmF0ZSkgb2YgdGhlIHJlY3RhbmdsZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gR2V0IGxlZnQgZWRnZSBwb3NpdGlvblxuICAgKiBjb25zdCByZWN0ID0gbmV3IFJlY3RhbmdsZSgxMDAsIDEwMCwgMjAwLCAxNTApO1xuICAgKiBjb25zb2xlLmxvZyhyZWN0LmxlZnQpOyAvLyAxMDBcbiAgICpcbiAgICogLy8gVXNlIGluIGFsaWdubWVudCBjYWxjdWxhdGlvbnNcbiAgICogc3ByaXRlLnggPSByZWN0LmxlZnQgKyBwYWRkaW5nO1xuICAgKlxuICAgKiAvLyBDb21wYXJlIHBvc2l0aW9uc1xuICAgKiBpZiAocG9pbnQueCA+IHJlY3QubGVmdCkge1xuICAgKiAgICAgY29uc29sZS5sb2coJ1BvaW50IGlzIHJpZ2h0IG9mIHJlY3RhbmdsZScpO1xuICAgKiB9XG4gICAqIGBgYFxuICAgKiBAcmVhZG9ubHlcbiAgICogQHJldHVybnMgVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgbGVmdCBlZGdlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5yaWdodH0gRm9yIHJpZ2h0IGVkZ2UgcG9zaXRpb25cbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLnh9IEZvciBkaXJlY3QgeC1jb29yZGluYXRlIGFjY2Vzc1xuICAgKi9cbiAgZ2V0IGxlZnQoKSB7XG4gICAgcmV0dXJuIHRoaXMueDtcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgcmlnaHQgZWRnZSAoeCArIHdpZHRoKSBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBHZXQgcmlnaHQgZWRnZSBwb3NpdGlvblxuICAgKiBjb25zdCByZWN0ID0gbmV3IFJlY3RhbmdsZSgxMDAsIDEwMCwgMjAwLCAxNTApO1xuICAgKiBjb25zb2xlLmxvZyhyZWN0LnJpZ2h0KTsgLy8gMzAwXG4gICAqXG4gICAqIC8vIEFsaWduIHRvIHJpZ2h0IGVkZ2VcbiAgICogc3ByaXRlLnggPSByZWN0LnJpZ2h0IC0gc3ByaXRlLndpZHRoO1xuICAgKlxuICAgKiAvLyBDaGVjayBib3VuZGFyaWVzXG4gICAqIGlmIChwb2ludC54IDwgcmVjdC5yaWdodCkge1xuICAgKiAgICAgY29uc29sZS5sb2coJ1BvaW50IGlzIGluc2lkZSByaWdodCBib3VuZCcpO1xuICAgKiB9XG4gICAqIGBgYFxuICAgKiBAcmVhZG9ubHlcbiAgICogQHJldHVybnMgVGhlIHgtY29vcmRpbmF0ZSBvZiB0aGUgcmlnaHQgZWRnZVxuICAgKiBAc2VlIHtAbGluayBSZWN0YW5nbGUubGVmdH0gRm9yIGxlZnQgZWRnZSBwb3NpdGlvblxuICAgKiBAc2VlIHtAbGluayBSZWN0YW5nbGUud2lkdGh9IEZvciB3aWR0aCB2YWx1ZVxuICAgKi9cbiAgZ2V0IHJpZ2h0KCkge1xuICAgIHJldHVybiB0aGlzLnggKyB0aGlzLndpZHRoO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSB0b3AgZWRnZSAoeS1jb29yZGluYXRlKSBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBHZXQgdG9wIGVkZ2UgcG9zaXRpb25cbiAgICogY29uc3QgcmVjdCA9IG5ldyBSZWN0YW5nbGUoMTAwLCAxMDAsIDIwMCwgMTUwKTtcbiAgICogY29uc29sZS5sb2cocmVjdC50b3ApOyAvLyAxMDBcbiAgICpcbiAgICogLy8gUG9zaXRpb24gYWJvdmUgcmVjdGFuZ2xlXG4gICAqIHNwcml0ZS55ID0gcmVjdC50b3AgLSBzcHJpdGUuaGVpZ2h0O1xuICAgKlxuICAgKiAvLyBDaGVjayB2ZXJ0aWNhbCBwb3NpdGlvblxuICAgKiBpZiAocG9pbnQueSA+IHJlY3QudG9wKSB7XG4gICAqICAgICBjb25zb2xlLmxvZygnUG9pbnQgaXMgYmVsb3cgdG9wIGVkZ2UnKTtcbiAgICogfVxuICAgKiBgYGBcbiAgICogQHJlYWRvbmx5XG4gICAqIEByZXR1cm5zIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIHRvcCBlZGdlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5ib3R0b219IEZvciBib3R0b20gZWRnZSBwb3NpdGlvblxuICAgKiBAc2VlIHtAbGluayBSZWN0YW5nbGUueX0gRm9yIGRpcmVjdCB5LWNvb3JkaW5hdGUgYWNjZXNzXG4gICAqL1xuICBnZXQgdG9wKCkge1xuICAgIHJldHVybiB0aGlzLnk7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGJvdHRvbSBlZGdlICh5ICsgaGVpZ2h0KSBvZiB0aGUgcmVjdGFuZ2xlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBHZXQgYm90dG9tIGVkZ2UgcG9zaXRpb25cbiAgICogY29uc3QgcmVjdCA9IG5ldyBSZWN0YW5nbGUoMTAwLCAxMDAsIDIwMCwgMTUwKTtcbiAgICogY29uc29sZS5sb2cocmVjdC5ib3R0b20pOyAvLyAyNTBcbiAgICpcbiAgICogLy8gU3RhY2sgYmVsb3cgcmVjdGFuZ2xlXG4gICAqIHNwcml0ZS55ID0gcmVjdC5ib3R0b20gKyBtYXJnaW47XG4gICAqXG4gICAqIC8vIENoZWNrIHZlcnRpY2FsIGJvdW5kc1xuICAgKiBpZiAocG9pbnQueSA8IHJlY3QuYm90dG9tKSB7XG4gICAqICAgICBjb25zb2xlLmxvZygnUG9pbnQgaXMgYWJvdmUgYm90dG9tIGVkZ2UnKTtcbiAgICogfVxuICAgKiBgYGBcbiAgICogQHJlYWRvbmx5XG4gICAqIEByZXR1cm5zIFRoZSB5LWNvb3JkaW5hdGUgb2YgdGhlIGJvdHRvbSBlZGdlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS50b3B9IEZvciB0b3AgZWRnZSBwb3NpdGlvblxuICAgKiBAc2VlIHtAbGluayBSZWN0YW5nbGUuaGVpZ2h0fSBGb3IgaGVpZ2h0IHZhbHVlXG4gICAqL1xuICBnZXQgYm90dG9tKCkge1xuICAgIHJldHVybiB0aGlzLnkgKyB0aGlzLmhlaWdodDtcbiAgfVxuICAvKipcbiAgICogRGV0ZXJtaW5lcyB3aGV0aGVyIHRoZSBSZWN0YW5nbGUgaXMgZW1wdHkgKGhhcyBubyBhcmVhKS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQ2hlY2sgemVybyBkaW1lbnNpb25zXG4gICAqIGNvbnN0IHJlY3QgPSBuZXcgUmVjdGFuZ2xlKDEwMCwgMTAwLCAwLCA1MCk7XG4gICAqIGNvbnNvbGUubG9nKHJlY3QuaXNFbXB0eSgpKTsgLy8gdHJ1ZVxuICAgKiBgYGBcbiAgICogQHJldHVybnMgVHJ1ZSBpZiB0aGUgcmVjdGFuZ2xlIGhhcyBubyBhcmVhXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS53aWR0aH0gRm9yIHdpZHRoIHZhbHVlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5oZWlnaHR9IEZvciBoZWlnaHQgdmFsdWVcbiAgICovXG4gIGlzRW1wdHkoKSB7XG4gICAgcmV0dXJuIHRoaXMubGVmdCA9PT0gdGhpcy5yaWdodCB8fCB0aGlzLnRvcCA9PT0gdGhpcy5ib3R0b207XG4gIH1cbiAgLyoqXG4gICAqIEEgY29uc3RhbnQgZW1wdHkgcmVjdGFuZ2xlLiBUaGlzIGlzIGEgbmV3IG9iamVjdCBldmVyeSB0aW1lIHRoZSBwcm9wZXJ0eSBpcyBhY2Nlc3NlZC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gR2V0IGZyZXNoIGVtcHR5IHJlY3RhbmdsZVxuICAgKiBjb25zdCBlbXB0eSA9IFJlY3RhbmdsZS5FTVBUWTtcbiAgICogY29uc29sZS5sb2coZW1wdHkuaXNFbXB0eSgpKTsgLy8gdHJ1ZVxuICAgKiBgYGBcbiAgICogQHJldHVybnMgQSBuZXcgZW1wdHkgcmVjdGFuZ2xlIGluc3RhbmNlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5pc0VtcHR5fSBGb3IgZW1wdHkgc3RhdGUgdGVzdGluZ1xuICAgKi9cbiAgc3RhdGljIGdldCBFTVBUWSgpIHtcbiAgICByZXR1cm4gbmV3IFJlY3RhbmdsZSgwLCAwLCAwLCAwKTtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBhIGNsb25lIG9mIHRoaXMgUmVjdGFuZ2xlXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNsb25pbmdcbiAgICogY29uc3Qgb3JpZ2luYWwgPSBuZXcgUmVjdGFuZ2xlKDEwMCwgMTAwLCAyMDAsIDE1MCk7XG4gICAqIGNvbnN0IGNvcHkgPSBvcmlnaW5hbC5jbG9uZSgpO1xuICAgKlxuICAgKiAvLyBDbG9uZSBhbmQgbW9kaWZ5XG4gICAqIGNvbnN0IG1vZGlmaWVkID0gb3JpZ2luYWwuY2xvbmUoKTtcbiAgICogbW9kaWZpZWQud2lkdGggKj0gMjtcbiAgICogbW9kaWZpZWQuaGVpZ2h0ICs9IDUwO1xuICAgKlxuICAgKiAvLyBWZXJpZnkgaW5kZXBlbmRlbmNlXG4gICAqIGNvbnNvbGUubG9nKG9yaWdpbmFsLndpZHRoKTsgIC8vIDIwMFxuICAgKiBjb25zb2xlLmxvZyhtb2RpZmllZC53aWR0aCk7ICAvLyA0MDBcbiAgICogYGBgXG4gICAqIEByZXR1cm5zIEEgY29weSBvZiB0aGUgcmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5jb3B5RnJvbX0gRm9yIGNvcHlpbmcgaW50byBleGlzdGluZyByZWN0YW5nbGVcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmNvcHlUb30gRm9yIGNvcHlpbmcgdG8gYW5vdGhlciByZWN0YW5nbGVcbiAgICovXG4gIGNsb25lKCkge1xuICAgIHJldHVybiBuZXcgUmVjdGFuZ2xlKHRoaXMueCwgdGhpcy55LCB0aGlzLndpZHRoLCB0aGlzLmhlaWdodCk7XG4gIH1cbiAgLyoqXG4gICAqIENvbnZlcnRzIGEgQm91bmRzIG9iamVjdCB0byBhIFJlY3RhbmdsZSBvYmplY3QuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIENvbnZlcnQgYm91bmRzIHRvIHJlY3RhbmdsZVxuICAgKiBjb25zdCBib3VuZHMgPSBjb250YWluZXIuZ2V0Qm91bmRzKCk7XG4gICAqIGNvbnN0IHJlY3QgPSBuZXcgUmVjdGFuZ2xlKCkuY29weUZyb21Cb3VuZHMoYm91bmRzKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSBib3VuZHMgLSBUaGUgYm91bmRzIHRvIGNvcHkgYW5kIGNvbnZlcnQgdG8gYSByZWN0YW5nbGVcbiAgICogQHJldHVybnMgUmV0dXJucyBpdHNlbGZcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzfSBGb3IgYm91bmRzIG9iamVjdCBzdHJ1Y3R1cmVcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmdldEJvdW5kc30gRm9yIGdldHRpbmcgcmVjdGFuZ2xlIGJvdW5kc1xuICAgKi9cbiAgY29weUZyb21Cb3VuZHMoYm91bmRzKSB7XG4gICAgdGhpcy54ID0gYm91bmRzLm1pblg7XG4gICAgdGhpcy55ID0gYm91bmRzLm1pblk7XG4gICAgdGhpcy53aWR0aCA9IGJvdW5kcy5tYXhYIC0gYm91bmRzLm1pblg7XG4gICAgdGhpcy5oZWlnaHQgPSBib3VuZHMubWF4WSAtIGJvdW5kcy5taW5ZO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBDb3BpZXMgYW5vdGhlciByZWN0YW5nbGUgdG8gdGhpcyBvbmUuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGNvcHlpbmdcbiAgICogY29uc3Qgc291cmNlID0gbmV3IFJlY3RhbmdsZSgxMDAsIDEwMCwgMjAwLCAxNTApO1xuICAgKiBjb25zdCB0YXJnZXQgPSBuZXcgUmVjdGFuZ2xlKCk7XG4gICAqIHRhcmdldC5jb3B5RnJvbShzb3VyY2UpO1xuICAgKlxuICAgKiAvLyBDaGFpbiB3aXRoIG90aGVyIG9wZXJhdGlvbnNcbiAgICogY29uc3QgcmVjdCA9IG5ldyBSZWN0YW5nbGUoKVxuICAgKiAgICAgLmNvcHlGcm9tKHNvdXJjZSlcbiAgICogICAgIC5wYWQoMTApO1xuICAgKiBgYGBcbiAgICogQHBhcmFtIHJlY3RhbmdsZSAtIFRoZSByZWN0YW5nbGUgdG8gY29weSBmcm9tXG4gICAqIEByZXR1cm5zIFJldHVybnMgaXRzZWxmXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5jb3B5VG99IEZvciBjb3B5aW5nIHRvIGFub3RoZXIgcmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5jbG9uZX0gRm9yIGNyZWF0aW5nIG5ldyByZWN0YW5nbGUgY29weVxuICAgKi9cbiAgY29weUZyb20ocmVjdGFuZ2xlKSB7XG4gICAgdGhpcy54ID0gcmVjdGFuZ2xlLng7XG4gICAgdGhpcy55ID0gcmVjdGFuZ2xlLnk7XG4gICAgdGhpcy53aWR0aCA9IHJlY3RhbmdsZS53aWR0aDtcbiAgICB0aGlzLmhlaWdodCA9IHJlY3RhbmdsZS5oZWlnaHQ7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENvcGllcyB0aGlzIHJlY3RhbmdsZSB0byBhbm90aGVyIG9uZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY29weWluZ1xuICAgKiBjb25zdCBzb3VyY2UgPSBuZXcgUmVjdGFuZ2xlKDEwMCwgMTAwLCAyMDAsIDE1MCk7XG4gICAqIGNvbnN0IHRhcmdldCA9IG5ldyBSZWN0YW5nbGUoKTtcbiAgICogc291cmNlLmNvcHlUbyh0YXJnZXQpO1xuICAgKlxuICAgKiAvLyBDaGFpbiB3aXRoIG90aGVyIG9wZXJhdGlvbnNcbiAgICogY29uc3QgcmVzdWx0ID0gc291cmNlXG4gICAqICAgICAuY29weVRvKG5ldyBSZWN0YW5nbGUoKSlcbiAgICogICAgIC5nZXRCb3VuZHMoKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSByZWN0YW5nbGUgLSBUaGUgcmVjdGFuZ2xlIHRvIGNvcHkgdG9cbiAgICogQHJldHVybnMgUmV0dXJucyBnaXZlbiBwYXJhbWV0ZXJcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmNvcHlGcm9tfSBGb3IgY29weWluZyBmcm9tIGFub3RoZXIgcmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5jbG9uZX0gRm9yIGNyZWF0aW5nIG5ldyByZWN0YW5nbGUgY29weVxuICAgKi9cbiAgY29weVRvKHJlY3RhbmdsZSkge1xuICAgIHJlY3RhbmdsZS5jb3B5RnJvbSh0aGlzKTtcbiAgICByZXR1cm4gcmVjdGFuZ2xlO1xuICB9XG4gIC8qKlxuICAgKiBDaGVja3Mgd2hldGhlciB0aGUgeCBhbmQgeSBjb29yZGluYXRlcyBnaXZlbiBhcmUgY29udGFpbmVkIHdpdGhpbiB0aGlzIFJlY3RhbmdsZVxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBjb250YWlubWVudCBjaGVja1xuICAgKiBjb25zdCByZWN0ID0gbmV3IFJlY3RhbmdsZSgxMDAsIDEwMCwgMjAwLCAxNTApO1xuICAgKiBjb25zdCBpc0luc2lkZSA9IHJlY3QuY29udGFpbnMoMTUwLCAxMjUpOyAvLyB0cnVlXG4gICAqIC8vIENoZWNrIGVkZ2UgY2FzZXNcbiAgICogY29uc29sZS5sb2cocmVjdC5jb250YWlucygxMDAsIDEwMCkpOyAvLyB0cnVlIChvbiBlZGdlKVxuICAgKiBjb25zb2xlLmxvZyhyZWN0LmNvbnRhaW5zKDMwMCwgMjUwKSk7IC8vIGZhbHNlIChvdXRzaWRlKVxuICAgKiBgYGBcbiAgICogQHBhcmFtIHggLSBUaGUgWCBjb29yZGluYXRlIG9mIHRoZSBwb2ludCB0byB0ZXN0XG4gICAqIEBwYXJhbSB5IC0gVGhlIFkgY29vcmRpbmF0ZSBvZiB0aGUgcG9pbnQgdG8gdGVzdFxuICAgKiBAcmV0dXJucyBXaGV0aGVyIHRoZSB4L3kgY29vcmRpbmF0ZXMgYXJlIHdpdGhpbiB0aGlzIFJlY3RhbmdsZVxuICAgKiBAc2VlIHtAbGluayBSZWN0YW5nbGUuY29udGFpbnNSZWN0fSBGb3IgcmVjdGFuZ2xlIGNvbnRhaW5tZW50XG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5zdHJva2VDb250YWluc30gRm9yIGNoZWNraW5nIHN0cm9rZSBpbnRlcnNlY3Rpb25cbiAgICovXG4gIGNvbnRhaW5zKHgsIHkpIHtcbiAgICBpZiAodGhpcy53aWR0aCA8PSAwIHx8IHRoaXMuaGVpZ2h0IDw9IDApIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKHggPj0gdGhpcy54ICYmIHggPCB0aGlzLnggKyB0aGlzLndpZHRoKSB7XG4gICAgICBpZiAoeSA+PSB0aGlzLnkgJiYgeSA8IHRoaXMueSArIHRoaXMuaGVpZ2h0KSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyB3aGV0aGVyIHRoZSB4IGFuZCB5IGNvb3JkaW5hdGVzIGdpdmVuIGFyZSBjb250YWluZWQgd2l0aGluIHRoaXMgcmVjdGFuZ2xlIGluY2x1ZGluZyB0aGUgc3Ryb2tlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBzdHJva2UgY2hlY2tcbiAgICogY29uc3QgcmVjdCA9IG5ldyBSZWN0YW5nbGUoMTAwLCAxMDAsIDIwMCwgMTUwKTtcbiAgICogY29uc3QgaXNPblN0cm9rZSA9IHJlY3Quc3Ryb2tlQ29udGFpbnMoMTUwLCAxMDAsIDQpOyAvLyA0cHggbGluZSB3aWR0aFxuICAgKlxuICAgKiAvLyBDaGVjayB3aXRoIGRpZmZlcmVudCBhbGlnbm1lbnRzXG4gICAqIGNvbnN0IGlubmVyU3Ryb2tlID0gcmVjdC5zdHJva2VDb250YWlucygxNTAsIDEwMCwgNCwgMSk7ICAgLy8gSW5zaWRlXG4gICAqIGNvbnN0IGNlbnRlclN0cm9rZSA9IHJlY3Quc3Ryb2tlQ29udGFpbnMoMTUwLCAxMDAsIDQsIDAuNSk7IC8vIENlbnRlcmVkXG4gICAqIGNvbnN0IG91dGVyU3Ryb2tlID0gcmVjdC5zdHJva2VDb250YWlucygxNTAsIDEwMCwgNCwgMCk7ICAgLy8gT3V0c2lkZVxuICAgKiBgYGBcbiAgICogQHBhcmFtIHggLSBUaGUgWCBjb29yZGluYXRlIG9mIHRoZSBwb2ludCB0byB0ZXN0XG4gICAqIEBwYXJhbSB5IC0gVGhlIFkgY29vcmRpbmF0ZSBvZiB0aGUgcG9pbnQgdG8gdGVzdFxuICAgKiBAcGFyYW0gc3Ryb2tlV2lkdGggLSBUaGUgd2lkdGggb2YgdGhlIGxpbmUgdG8gY2hlY2tcbiAgICogQHBhcmFtIGFsaWdubWVudCAtIFRoZSBhbGlnbm1lbnQgb2YgdGhlIHN0cm9rZSAoMSA9IGlubmVyLCAwLjUgPSBjZW50ZXJlZCwgMCA9IG91dGVyKVxuICAgKiBAcmV0dXJucyBXaGV0aGVyIHRoZSB4L3kgY29vcmRpbmF0ZXMgYXJlIHdpdGhpbiB0aGlzIHJlY3RhbmdsZSdzIHN0cm9rZVxuICAgKiBAc2VlIHtAbGluayBSZWN0YW5nbGUuY29udGFpbnN9IEZvciBjaGVja2luZyBmaWxsIGNvbnRhaW5tZW50XG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5nZXRCb3VuZHN9IEZvciBnZXR0aW5nIHN0cm9rZSBib3VuZHNcbiAgICovXG4gIHN0cm9rZUNvbnRhaW5zKHgsIHksIHN0cm9rZVdpZHRoLCBhbGlnbm1lbnQgPSAwLjUpIHtcbiAgICBjb25zdCB7IHdpZHRoLCBoZWlnaHQgfSA9IHRoaXM7XG4gICAgaWYgKHdpZHRoIDw9IDAgfHwgaGVpZ2h0IDw9IDApIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBfeCA9IHRoaXMueDtcbiAgICBjb25zdCBfeSA9IHRoaXMueTtcbiAgICBjb25zdCBzdHJva2VXaWR0aE91dGVyID0gc3Ryb2tlV2lkdGggKiAoMSAtIGFsaWdubWVudCk7XG4gICAgY29uc3Qgc3Ryb2tlV2lkdGhJbm5lciA9IHN0cm9rZVdpZHRoIC0gc3Ryb2tlV2lkdGhPdXRlcjtcbiAgICBjb25zdCBvdXRlckxlZnQgPSBfeCAtIHN0cm9rZVdpZHRoT3V0ZXI7XG4gICAgY29uc3Qgb3V0ZXJSaWdodCA9IF94ICsgd2lkdGggKyBzdHJva2VXaWR0aE91dGVyO1xuICAgIGNvbnN0IG91dGVyVG9wID0gX3kgLSBzdHJva2VXaWR0aE91dGVyO1xuICAgIGNvbnN0IG91dGVyQm90dG9tID0gX3kgKyBoZWlnaHQgKyBzdHJva2VXaWR0aE91dGVyO1xuICAgIGNvbnN0IGlubmVyTGVmdCA9IF94ICsgc3Ryb2tlV2lkdGhJbm5lcjtcbiAgICBjb25zdCBpbm5lclJpZ2h0ID0gX3ggKyB3aWR0aCAtIHN0cm9rZVdpZHRoSW5uZXI7XG4gICAgY29uc3QgaW5uZXJUb3AgPSBfeSArIHN0cm9rZVdpZHRoSW5uZXI7XG4gICAgY29uc3QgaW5uZXJCb3R0b20gPSBfeSArIGhlaWdodCAtIHN0cm9rZVdpZHRoSW5uZXI7XG4gICAgcmV0dXJuIHggPj0gb3V0ZXJMZWZ0ICYmIHggPD0gb3V0ZXJSaWdodCAmJiB5ID49IG91dGVyVG9wICYmIHkgPD0gb3V0ZXJCb3R0b20gJiYgISh4ID4gaW5uZXJMZWZ0ICYmIHggPCBpbm5lclJpZ2h0ICYmIHkgPiBpbm5lclRvcCAmJiB5IDwgaW5uZXJCb3R0b20pO1xuICB9XG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgdGhlIGBvdGhlcmAgUmVjdGFuZ2xlIHRyYW5zZm9ybWVkIGJ5IGB0cmFuc2Zvcm1gIGludGVyc2VjdHMgd2l0aCBgdGhpc2AgUmVjdGFuZ2xlIG9iamVjdC5cbiAgICogUmV0dXJucyB0cnVlIG9ubHkgaWYgdGhlIGFyZWEgb2YgdGhlIGludGVyc2VjdGlvbiBpcyA+MCwgdGhpcyBtZWFucyB0aGF0IFJlY3RhbmdsZXNcbiAgICogc2hhcmluZyBhIHNpZGUgYXJlIG5vdCBvdmVybGFwcGluZy4gQW5vdGhlciBzaWRlIGVmZmVjdCBpcyB0aGF0IGFuIGFyZWFsZXNzIHJlY3RhbmdsZVxuICAgKiAod2lkdGggb3IgaGVpZ2h0IGVxdWFsIHRvIHplcm8pIGNhbid0IGludGVyc2VjdCBhbnkgb3RoZXIgcmVjdGFuZ2xlLlxuICAgKiBAcGFyYW0ge1JlY3RhbmdsZX0gb3RoZXIgLSBUaGUgUmVjdGFuZ2xlIHRvIGludGVyc2VjdCB3aXRoIGB0aGlzYC5cbiAgICogQHBhcmFtIHtNYXRyaXh9IHRyYW5zZm9ybSAtIFRoZSB0cmFuc2Zvcm1hdGlvbiBtYXRyaXggb2YgYG90aGVyYC5cbiAgICogQHJldHVybnMge2Jvb2xlYW59IEEgdmFsdWUgb2YgYHRydWVgIGlmIHRoZSB0cmFuc2Zvcm1lZCBgb3RoZXJgIFJlY3RhbmdsZSBpbnRlcnNlY3RzIHdpdGggYHRoaXNgOyBvdGhlcndpc2UgYGZhbHNlYC5cbiAgICovXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIHdoZXRoZXIgdGhlIGBvdGhlcmAgUmVjdGFuZ2xlIHRyYW5zZm9ybWVkIGJ5IGB0cmFuc2Zvcm1gIGludGVyc2VjdHMgd2l0aCBgdGhpc2AgUmVjdGFuZ2xlIG9iamVjdC5cbiAgICpcbiAgICogUmV0dXJucyB0cnVlIG9ubHkgaWYgdGhlIGFyZWEgb2YgdGhlIGludGVyc2VjdGlvbiBpcyBncmVhdGVyIHRoYW4gMC5cbiAgICogVGhpcyBtZWFucyB0aGF0IHJlY3RhbmdsZXMgc2hhcmluZyBvbmx5IGEgc2lkZSBhcmUgbm90IGNvbnNpZGVyZWQgaW50ZXJzZWN0aW5nLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBpbnRlcnNlY3Rpb24gY2hlY2tcbiAgICogY29uc3QgcmVjdDEgPSBuZXcgUmVjdGFuZ2xlKDAsIDAsIDEwMCwgMTAwKTtcbiAgICogY29uc3QgcmVjdDIgPSBuZXcgUmVjdGFuZ2xlKDUwLCA1MCwgMTAwLCAxMDApO1xuICAgKiBjb25zb2xlLmxvZyhyZWN0MS5pbnRlcnNlY3RzKHJlY3QyKSk7IC8vIHRydWVcbiAgICpcbiAgICogLy8gV2l0aCB0cmFuc2Zvcm1hdGlvbiBtYXRyaXhcbiAgICogY29uc3QgbWF0cml4ID0gbmV3IE1hdHJpeCgpO1xuICAgKiBtYXRyaXgucm90YXRlKE1hdGguUEkgLyA0KTsgLy8gNDUgZGVncmVlc1xuICAgKiBjb25zb2xlLmxvZyhyZWN0MS5pbnRlcnNlY3RzKHJlY3QyLCBtYXRyaXgpKTsgLy8gQ2hlY2tzIHdpdGggcm90YXRpb25cbiAgICpcbiAgICogLy8gRWRnZSBjYXNlc1xuICAgKiBjb25zdCB6ZXJvV2lkdGggPSBuZXcgUmVjdGFuZ2xlKDAsIDAsIDAsIDEwMCk7XG4gICAqIGNvbnNvbGUubG9nKHJlY3QxLmludGVyc2VjdHMoemVyb1dpZHRoKSk7IC8vIGZhbHNlIChubyBhcmVhKVxuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBSZXR1cm5zIHRydWUgb25seSBpZiBpbnRlcnNlY3Rpb24gYXJlYSBpcyA+IDBcbiAgICogLSBSZWN0YW5nbGVzIHNoYXJpbmcgb25seSBhIHNpZGUgYXJlIG5vdCBpbnRlcnNlY3RpbmdcbiAgICogLSBaZXJvLWFyZWEgcmVjdGFuZ2xlcyBjYW5ub3QgaW50ZXJzZWN0IGFueXRoaW5nXG4gICAqIC0gU3VwcG9ydHMgb3B0aW9uYWwgdHJhbnNmb3JtYXRpb24gbWF0cml4XG4gICAqIEBwYXJhbSBvdGhlciAtIFRoZSBSZWN0YW5nbGUgdG8gaW50ZXJzZWN0IHdpdGggYHRoaXNgXG4gICAqIEBwYXJhbSB0cmFuc2Zvcm0gLSBPcHRpb25hbCB0cmFuc2Zvcm1hdGlvbiBtYXRyaXggb2YgYG90aGVyYFxuICAgKiBAcmV0dXJucyBUcnVlIGlmIHRoZSB0cmFuc2Zvcm1lZCBgb3RoZXJgIFJlY3RhbmdsZSBpbnRlcnNlY3RzIHdpdGggYHRoaXNgXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5jb250YWluc1JlY3R9IEZvciBjb250YWlubWVudCB0ZXN0aW5nXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5jb250YWluc30gRm9yIHBvaW50IHRlc3RpbmdcbiAgICovXG4gIGludGVyc2VjdHMob3RoZXIsIHRyYW5zZm9ybSkge1xuICAgIGlmICghdHJhbnNmb3JtKSB7XG4gICAgICBjb25zdCB4MDIgPSB0aGlzLnggPCBvdGhlci54ID8gb3RoZXIueCA6IHRoaXMueDtcbiAgICAgIGNvbnN0IHgxMiA9IHRoaXMucmlnaHQgPiBvdGhlci5yaWdodCA/IG90aGVyLnJpZ2h0IDogdGhpcy5yaWdodDtcbiAgICAgIGlmICh4MTIgPD0geDAyKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHkwMiA9IHRoaXMueSA8IG90aGVyLnkgPyBvdGhlci55IDogdGhpcy55O1xuICAgICAgY29uc3QgeTEyID0gdGhpcy5ib3R0b20gPiBvdGhlci5ib3R0b20gPyBvdGhlci5ib3R0b20gOiB0aGlzLmJvdHRvbTtcbiAgICAgIHJldHVybiB5MTIgPiB5MDI7XG4gICAgfVxuICAgIGNvbnN0IHgwID0gdGhpcy5sZWZ0O1xuICAgIGNvbnN0IHgxID0gdGhpcy5yaWdodDtcbiAgICBjb25zdCB5MCA9IHRoaXMudG9wO1xuICAgIGNvbnN0IHkxID0gdGhpcy5ib3R0b207XG4gICAgaWYgKHgxIDw9IHgwIHx8IHkxIDw9IHkwKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IGx0ID0gdGVtcFBvaW50c1swXS5zZXQob3RoZXIubGVmdCwgb3RoZXIudG9wKTtcbiAgICBjb25zdCBsYiA9IHRlbXBQb2ludHNbMV0uc2V0KG90aGVyLmxlZnQsIG90aGVyLmJvdHRvbSk7XG4gICAgY29uc3QgcnQgPSB0ZW1wUG9pbnRzWzJdLnNldChvdGhlci5yaWdodCwgb3RoZXIudG9wKTtcbiAgICBjb25zdCByYiA9IHRlbXBQb2ludHNbM10uc2V0KG90aGVyLnJpZ2h0LCBvdGhlci5ib3R0b20pO1xuICAgIGlmIChydC54IDw9IGx0LnggfHwgbGIueSA8PSBsdC55KSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHMgPSBNYXRoLnNpZ24odHJhbnNmb3JtLmEgKiB0cmFuc2Zvcm0uZCAtIHRyYW5zZm9ybS5iICogdHJhbnNmb3JtLmMpO1xuICAgIGlmIChzID09PSAwKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHRyYW5zZm9ybS5hcHBseShsdCwgbHQpO1xuICAgIHRyYW5zZm9ybS5hcHBseShsYiwgbGIpO1xuICAgIHRyYW5zZm9ybS5hcHBseShydCwgcnQpO1xuICAgIHRyYW5zZm9ybS5hcHBseShyYiwgcmIpO1xuICAgIGlmIChNYXRoLm1heChsdC54LCBsYi54LCBydC54LCByYi54KSA8PSB4MCB8fCBNYXRoLm1pbihsdC54LCBsYi54LCBydC54LCByYi54KSA+PSB4MSB8fCBNYXRoLm1heChsdC55LCBsYi55LCBydC55LCByYi55KSA8PSB5MCB8fCBNYXRoLm1pbihsdC55LCBsYi55LCBydC55LCByYi55KSA+PSB5MSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBueCA9IHMgKiAobGIueSAtIGx0LnkpO1xuICAgIGNvbnN0IG55ID0gcyAqIChsdC54IC0gbGIueCk7XG4gICAgY29uc3QgbjAwID0gbnggKiB4MCArIG55ICogeTA7XG4gICAgY29uc3QgbjEwID0gbnggKiB4MSArIG55ICogeTA7XG4gICAgY29uc3QgbjAxID0gbnggKiB4MCArIG55ICogeTE7XG4gICAgY29uc3QgbjExID0gbnggKiB4MSArIG55ICogeTE7XG4gICAgaWYgKE1hdGgubWF4KG4wMCwgbjEwLCBuMDEsIG4xMSkgPD0gbnggKiBsdC54ICsgbnkgKiBsdC55IHx8IE1hdGgubWluKG4wMCwgbjEwLCBuMDEsIG4xMSkgPj0gbnggKiByYi54ICsgbnkgKiByYi55KSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IG14ID0gcyAqIChsdC55IC0gcnQueSk7XG4gICAgY29uc3QgbXkgPSBzICogKHJ0LnggLSBsdC54KTtcbiAgICBjb25zdCBtMDAgPSBteCAqIHgwICsgbXkgKiB5MDtcbiAgICBjb25zdCBtMTAgPSBteCAqIHgxICsgbXkgKiB5MDtcbiAgICBjb25zdCBtMDEgPSBteCAqIHgwICsgbXkgKiB5MTtcbiAgICBjb25zdCBtMTEgPSBteCAqIHgxICsgbXkgKiB5MTtcbiAgICBpZiAoTWF0aC5tYXgobTAwLCBtMTAsIG0wMSwgbTExKSA8PSBteCAqIGx0LnggKyBteSAqIGx0LnkgfHwgTWF0aC5taW4obTAwLCBtMTAsIG0wMSwgbTExKSA+PSBteCAqIHJiLnggKyBteSAqIHJiLnkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLyoqXG4gICAqIFBhZHMgdGhlIHJlY3RhbmdsZSBtYWtpbmcgaXQgZ3JvdyBpbiBhbGwgZGlyZWN0aW9ucy5cbiAgICpcbiAgICogSWYgcGFkZGluZ1kgaXMgb21pdHRlZCwgYm90aCBwYWRkaW5nWCBhbmQgcGFkZGluZ1kgd2lsbCBiZSBzZXQgdG8gcGFkZGluZ1guXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHBhZGRpbmdcbiAgICogY29uc3QgcmVjdCA9IG5ldyBSZWN0YW5nbGUoMTAwLCAxMDAsIDIwMCwgMTUwKTtcbiAgICogcmVjdC5wYWQoMTApOyAvLyBBZGRzIDEwcHggcGFkZGluZyBvbiBhbGwgc2lkZXNcbiAgICpcbiAgICogLy8gRGlmZmVyZW50IGhvcml6b250YWwgYW5kIHZlcnRpY2FsIHBhZGRpbmdcbiAgICogY29uc3QgdWlSZWN0ID0gbmV3IFJlY3RhbmdsZSgwLCAwLCAxMDAsIDUwKTtcbiAgICogdWlSZWN0LnBhZCgyMCwgMTApOyAvLyAyMHB4IGhvcml6b250YWwsIDEwcHggdmVydGljYWxcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gQWRqdXN0cyB4L3kgYnkgc3VidHJhY3RpbmcgcGFkZGluZ1xuICAgKiAtIEluY3JlYXNlcyB3aWR0aC9oZWlnaHQgYnkgcGFkZGluZyAqIDJcbiAgICogLSBDb21tb24gaW4gVUkgbGF5b3V0IGNhbGN1bGF0aW9uc1xuICAgKiAtIENoYWluYWJsZSB3aXRoIG90aGVyIG1ldGhvZHNcbiAgICogQHBhcmFtIHBhZGRpbmdYIC0gVGhlIGhvcml6b250YWwgcGFkZGluZyBhbW91bnRcbiAgICogQHBhcmFtIHBhZGRpbmdZIC0gVGhlIHZlcnRpY2FsIHBhZGRpbmcgYW1vdW50XG4gICAqIEByZXR1cm5zIFJldHVybnMgaXRzZWxmXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5lbmxhcmdlfSBGb3IgZ3Jvd2luZyB0byBpbmNsdWRlIGFub3RoZXIgcmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5maXR9IEZvciBzaHJpbmtpbmcgdG8gZml0IHdpdGhpbiBhbm90aGVyIHJlY3RhbmdsZVxuICAgKi9cbiAgcGFkKHBhZGRpbmdYID0gMCwgcGFkZGluZ1kgPSBwYWRkaW5nWCkge1xuICAgIHRoaXMueCAtPSBwYWRkaW5nWDtcbiAgICB0aGlzLnkgLT0gcGFkZGluZ1k7XG4gICAgdGhpcy53aWR0aCArPSBwYWRkaW5nWCAqIDI7XG4gICAgdGhpcy5oZWlnaHQgKz0gcGFkZGluZ1kgKiAyO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBGaXRzIHRoaXMgcmVjdGFuZ2xlIGFyb3VuZCB0aGUgcGFzc2VkIG9uZS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgZml0dGluZ1xuICAgKiBjb25zdCBjb250YWluZXIgPSBuZXcgUmVjdGFuZ2xlKDAsIDAsIDEwMCwgMTAwKTtcbiAgICogY29uc3QgY29udGVudCA9IG5ldyBSZWN0YW5nbGUoMjUsIDI1LCAyMDAsIDIwMCk7XG4gICAqIGNvbnRlbnQuZml0KGNvbnRhaW5lcik7IC8vIENsaXBzIHRvIGNvbnRhaW5lciBib3VuZHNcbiAgICogYGBgXG4gICAqIEBwYXJhbSByZWN0YW5nbGUgLSBUaGUgcmVjdGFuZ2xlIHRvIGZpdCBhcm91bmRcbiAgICogQHJldHVybnMgUmV0dXJucyBpdHNlbGZcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmVubGFyZ2V9IEZvciBncm93aW5nIHRvIGluY2x1ZGUgYW5vdGhlciByZWN0YW5nbGVcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLnBhZH0gRm9yIGFkZGluZyBwYWRkaW5nIGFyb3VuZCB0aGUgcmVjdGFuZ2xlXG4gICAqL1xuICBmaXQocmVjdGFuZ2xlKSB7XG4gICAgY29uc3QgeDEgPSBNYXRoLm1heCh0aGlzLngsIHJlY3RhbmdsZS54KTtcbiAgICBjb25zdCB4MiA9IE1hdGgubWluKHRoaXMueCArIHRoaXMud2lkdGgsIHJlY3RhbmdsZS54ICsgcmVjdGFuZ2xlLndpZHRoKTtcbiAgICBjb25zdCB5MSA9IE1hdGgubWF4KHRoaXMueSwgcmVjdGFuZ2xlLnkpO1xuICAgIGNvbnN0IHkyID0gTWF0aC5taW4odGhpcy55ICsgdGhpcy5oZWlnaHQsIHJlY3RhbmdsZS55ICsgcmVjdGFuZ2xlLmhlaWdodCk7XG4gICAgdGhpcy54ID0geDE7XG4gICAgdGhpcy53aWR0aCA9IE1hdGgubWF4KHgyIC0geDEsIDApO1xuICAgIHRoaXMueSA9IHkxO1xuICAgIHRoaXMuaGVpZ2h0ID0gTWF0aC5tYXgoeTIgLSB5MSwgMCk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIEVubGFyZ2VzIHJlY3RhbmdsZSBzbyB0aGF0IGl0cyBjb3JuZXJzIGxpZSBvbiBhIGdyaWQgZGVmaW5lZCBieSByZXNvbHV0aW9uLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBncmlkIGFsaWdubWVudFxuICAgKiBjb25zdCByZWN0ID0gbmV3IFJlY3RhbmdsZSgxMC4yLCAxMC42LCAxMDAuOCwgMTAwLjQpO1xuICAgKiByZWN0LmNlaWwoKTsgLy8gQWxpZ25zIHRvIHdob2xlIHBpeGVsc1xuICAgKlxuICAgKiAvLyBDdXN0b20gcmVzb2x1dGlvbiBncmlkXG4gICAqIGNvbnN0IHVpUmVjdCA9IG5ldyBSZWN0YW5nbGUoNS4zLCA1LjcsIDUwLjIsIDUwLjgpO1xuICAgKiB1aVJlY3QuY2VpbCgwLjUpOyAvLyBBbGlnbnMgdG8gaGFsZiBwaXhlbHNcbiAgICpcbiAgICogLy8gVXNlIHdpdGggcHJlY2lzaW9uIHZhbHVlXG4gICAqIGNvbnN0IHByZWNpc2VSZWN0ID0gbmV3IFJlY3RhbmdsZSgyMC4wMDEsIDIwLjk5OSwgMTAwLjAwMSwgMTAwLjk5OSk7XG4gICAqIHByZWNpc2VSZWN0LmNlaWwoMSwgMC4wMSk7IC8vIEhhbmRsZXMgc21hbGwgZGVjaW1hbCB2YXJpYXRpb25zXG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcmVzb2x1dGlvbiAtIFRoZSBncmlkIHNpemUgdG8gYWxpZ24gdG8gKDEgPSB3aG9sZSBwaXhlbHMpXG4gICAqIEBwYXJhbSBlcHMgLSBTbWFsbCBudW1iZXIgdG8gcHJldmVudCBmbG9hdGluZyBwb2ludCBlcnJvcnNcbiAgICogQHJldHVybnMgUmV0dXJucyBpdHNlbGZcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmZpdH0gRm9yIGNvbnN0cmFpbmluZyB0byBib3VuZHNcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmVubGFyZ2V9IEZvciBncm93aW5nIGRpbWVuc2lvbnNcbiAgICovXG4gIGNlaWwocmVzb2x1dGlvbiA9IDEsIGVwcyA9IDFlLTMpIHtcbiAgICBjb25zdCB4MiA9IE1hdGguY2VpbCgodGhpcy54ICsgdGhpcy53aWR0aCAtIGVwcykgKiByZXNvbHV0aW9uKSAvIHJlc29sdXRpb247XG4gICAgY29uc3QgeTIgPSBNYXRoLmNlaWwoKHRoaXMueSArIHRoaXMuaGVpZ2h0IC0gZXBzKSAqIHJlc29sdXRpb24pIC8gcmVzb2x1dGlvbjtcbiAgICB0aGlzLnggPSBNYXRoLmZsb29yKCh0aGlzLnggKyBlcHMpICogcmVzb2x1dGlvbikgLyByZXNvbHV0aW9uO1xuICAgIHRoaXMueSA9IE1hdGguZmxvb3IoKHRoaXMueSArIGVwcykgKiByZXNvbHV0aW9uKSAvIHJlc29sdXRpb247XG4gICAgdGhpcy53aWR0aCA9IHgyIC0gdGhpcy54O1xuICAgIHRoaXMuaGVpZ2h0ID0geTIgLSB0aGlzLnk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFNjYWxlcyB0aGUgcmVjdGFuZ2xlJ3MgZGltZW5zaW9ucyBhbmQgcG9zaXRpb24gYnkgdGhlIHNwZWNpZmllZCBmYWN0b3JzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCByZWN0ID0gbmV3IFJlY3RhbmdsZSg1MCwgNTAsIDEwMCwgMTAwKTtcbiAgICpcbiAgICogLy8gU2NhbGUgdW5pZm9ybWx5XG4gICAqIHJlY3Quc2NhbGUoMC41LCAwLjUpO1xuICAgKiAvLyByZWN0IGlzIG5vdzogeD0yNSwgeT0yNSwgd2lkdGg9NTAsIGhlaWdodD01MFxuICAgKlxuICAgKiAvLyBub24tdW5pZm9ybWx5XG4gICAqIHJlY3Quc2NhbGUoMC41LCAxKTtcbiAgICogLy8gcmVjdCBpcyBub3c6IHg9MjUsIHk9NTAsIHdpZHRoPTUwLCBoZWlnaHQ9MTAwXG4gICAqIGBgYFxuICAgKiBAcGFyYW0geCAtIFRoZSBmYWN0b3IgYnkgd2hpY2ggdG8gc2NhbGUgdGhlIGhvcml6b250YWwgcHJvcGVydGllcyAoeCwgd2lkdGgpLlxuICAgKiBAcGFyYW0geSAtIFRoZSBmYWN0b3IgYnkgd2hpY2ggdG8gc2NhbGUgdGhlIHZlcnRpY2FsIHByb3BlcnRpZXMgKHksIGhlaWdodCkuXG4gICAqIEByZXR1cm5zIFJldHVybnMgaXRzZWxmXG4gICAqL1xuICBzY2FsZSh4LCB5ID0geCkge1xuICAgIHRoaXMueCAqPSB4O1xuICAgIHRoaXMueSAqPSB5O1xuICAgIHRoaXMud2lkdGggKj0geDtcbiAgICB0aGlzLmhlaWdodCAqPSB5O1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBFbmxhcmdlcyB0aGlzIHJlY3RhbmdsZSB0byBpbmNsdWRlIHRoZSBwYXNzZWQgcmVjdGFuZ2xlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBlbmxhcmdlbWVudFxuICAgKiBjb25zdCByZWN0ID0gbmV3IFJlY3RhbmdsZSg1MCwgNTAsIDEwMCwgMTAwKTtcbiAgICogY29uc3Qgb3RoZXIgPSBuZXcgUmVjdGFuZ2xlKDAsIDAsIDIwMCwgNzUpO1xuICAgKiByZWN0LmVubGFyZ2Uob3RoZXIpO1xuICAgKiAvLyByZWN0IGlzIG5vdzogeD0wLCB5PTAsIHdpZHRoPTIwMCwgaGVpZ2h0PTE1MFxuICAgKlxuICAgKiAvLyBVc2UgZm9yIGJvdW5kaW5nIGJveCBjYWxjdWxhdGlvblxuICAgKiBjb25zdCBib3VuZHMgPSBuZXcgUmVjdGFuZ2xlKCk7XG4gICAqIG9iamVjdHMuZm9yRWFjaCgob2JqKSA9PiB7XG4gICAqICAgICBib3VuZHMuZW5sYXJnZShvYmouZ2V0Qm91bmRzKCkpO1xuICAgKiB9KTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSByZWN0YW5nbGUgLSBUaGUgcmVjdGFuZ2xlIHRvIGluY2x1ZGVcbiAgICogQHJldHVybnMgUmV0dXJucyBpdHNlbGZcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmZpdH0gRm9yIHNocmlua2luZyB0byBmaXQgd2l0aGluIGFub3RoZXIgcmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5wYWR9IEZvciBhZGRpbmcgcGFkZGluZyBhcm91bmQgdGhlIHJlY3RhbmdsZVxuICAgKi9cbiAgZW5sYXJnZShyZWN0YW5nbGUpIHtcbiAgICBjb25zdCB4MSA9IE1hdGgubWluKHRoaXMueCwgcmVjdGFuZ2xlLngpO1xuICAgIGNvbnN0IHgyID0gTWF0aC5tYXgodGhpcy54ICsgdGhpcy53aWR0aCwgcmVjdGFuZ2xlLnggKyByZWN0YW5nbGUud2lkdGgpO1xuICAgIGNvbnN0IHkxID0gTWF0aC5taW4odGhpcy55LCByZWN0YW5nbGUueSk7XG4gICAgY29uc3QgeTIgPSBNYXRoLm1heCh0aGlzLnkgKyB0aGlzLmhlaWdodCwgcmVjdGFuZ2xlLnkgKyByZWN0YW5nbGUuaGVpZ2h0KTtcbiAgICB0aGlzLnggPSB4MTtcbiAgICB0aGlzLndpZHRoID0geDIgLSB4MTtcbiAgICB0aGlzLnkgPSB5MTtcbiAgICB0aGlzLmhlaWdodCA9IHkyIC0geTE7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGZyYW1pbmcgcmVjdGFuZ2xlIG9mIHRoZSByZWN0YW5nbGUgYXMgYSBSZWN0YW5nbGUgb2JqZWN0XG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGJvdW5kcyByZXRyaWV2YWxcbiAgICogY29uc3QgcmVjdCA9IG5ldyBSZWN0YW5nbGUoMTAwLCAxMDAsIDIwMCwgMTUwKTtcbiAgICogY29uc3QgYm91bmRzID0gcmVjdC5nZXRCb3VuZHMoKTtcbiAgICpcbiAgICogLy8gUmV1c2UgZXhpc3RpbmcgcmVjdGFuZ2xlXG4gICAqIGNvbnN0IG91dCA9IG5ldyBSZWN0YW5nbGUoKTtcbiAgICogcmVjdC5nZXRCb3VuZHMob3V0KTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSBvdXQgLSBPcHRpb25hbCByZWN0YW5nbGUgdG8gc3RvcmUgdGhlIHJlc3VsdFxuICAgKiBAcmV0dXJucyBUaGUgZnJhbWluZyByZWN0YW5nbGVcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmNvcHlGcm9tfSBGb3IgZGlyZWN0IGNvcHlpbmdcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmNsb25lfSBGb3IgY3JlYXRpbmcgbmV3IGNvcHlcbiAgICovXG4gIGdldEJvdW5kcyhvdXQpIHtcbiAgICBvdXQgfHwgKG91dCA9IG5ldyBSZWN0YW5nbGUoKSk7XG4gICAgb3V0LmNvcHlGcm9tKHRoaXMpO1xuICAgIHJldHVybiBvdXQ7XG4gIH1cbiAgLyoqXG4gICAqIERldGVybWluZXMgd2hldGhlciBhbm90aGVyIFJlY3RhbmdsZSBpcyBmdWxseSBjb250YWluZWQgd2l0aGluIHRoaXMgUmVjdGFuZ2xlLlxuICAgKlxuICAgKiBSZWN0YW5nbGVzIHRoYXQgb2NjdXB5IHRoZSBzYW1lIHNwYWNlIGFyZSBjb25zaWRlcmVkIHRvIGJlIGNvbnRhaW5pbmcgZWFjaCBvdGhlci5cbiAgICpcbiAgICogUmVjdGFuZ2xlcyB3aXRob3V0IGFyZWEgKHdpZHRoIG9yIGhlaWdodCBlcXVhbCB0byB6ZXJvKSBjYW4ndCBjb250YWluIGFueXRoaW5nLFxuICAgKiBub3QgZXZlbiBvdGhlciBhcmVhbGVzcyByZWN0YW5nbGVzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBDaGVjayBpZiBvbmUgcmVjdGFuZ2xlIGNvbnRhaW5zIGFub3RoZXJcbiAgICogY29uc3QgY29udGFpbmVyID0gbmV3IFJlY3RhbmdsZSgwLCAwLCAxMDAsIDEwMCk7XG4gICAqIGNvbnN0IGlubmVyID0gbmV3IFJlY3RhbmdsZSgyNSwgMjUsIDUwLCA1MCk7XG4gICAqXG4gICAqIGNvbnNvbGUubG9nKGNvbnRhaW5lci5jb250YWluc1JlY3QoaW5uZXIpKTsgLy8gdHJ1ZVxuICAgKlxuICAgKiAvLyBDaGVjayBvdmVybGFwcGluZyByZWN0YW5nbGVzXG4gICAqIGNvbnN0IHBhcnRpYWwgPSBuZXcgUmVjdGFuZ2xlKDc1LCA3NSwgNTAsIDUwKTtcbiAgICogY29uc29sZS5sb2coY29udGFpbmVyLmNvbnRhaW5zUmVjdChwYXJ0aWFsKSk7IC8vIGZhbHNlXG4gICAqXG4gICAqIC8vIFplcm8tYXJlYSByZWN0YW5nbGVzIGNhbid0IGNvbnRhaW4gYW55dGhpbmdcbiAgICogY29uc3QgZW1wdHkgPSBuZXcgUmVjdGFuZ2xlKDAsIDAsIDAsIDEwMCk7XG4gICAqIGNvbnNvbGUubG9nKGVtcHR5LmNvbnRhaW5zUmVjdChpbm5lcikpOyAvLyBmYWxzZVxuICAgKiBgYGBcbiAgICogQHBhcmFtIG90aGVyIC0gVGhlIFJlY3RhbmdsZSB0byBjaGVjayBmb3IgY29udGFpbm1lbnRcbiAgICogQHJldHVybnMgVHJ1ZSBpZiBvdGhlciBpcyBmdWxseSBjb250YWluZWQgd2l0aGluIHRoaXMgUmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5jb250YWluc30gRm9yIHBvaW50IGNvbnRhaW5tZW50XG4gICAqIEBzZWUge0BsaW5rIFJlY3RhbmdsZS5pbnRlcnNlY3RzfSBGb3Igb3ZlcmxhcCB0ZXN0aW5nXG4gICAqL1xuICBjb250YWluc1JlY3Qob3RoZXIpIHtcbiAgICBpZiAodGhpcy53aWR0aCA8PSAwIHx8IHRoaXMuaGVpZ2h0IDw9IDApIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCB4MSA9IG90aGVyLng7XG4gICAgY29uc3QgeTEgPSBvdGhlci55O1xuICAgIGNvbnN0IHgyID0gb3RoZXIueCArIG90aGVyLndpZHRoO1xuICAgIGNvbnN0IHkyID0gb3RoZXIueSArIG90aGVyLmhlaWdodDtcbiAgICByZXR1cm4geDEgPj0gdGhpcy54ICYmIHgxIDwgdGhpcy54ICsgdGhpcy53aWR0aCAmJiB5MSA+PSB0aGlzLnkgJiYgeTEgPCB0aGlzLnkgKyB0aGlzLmhlaWdodCAmJiB4MiA+PSB0aGlzLnggJiYgeDIgPD0gdGhpcy54ICsgdGhpcy53aWR0aCAmJiB5MiA+PSB0aGlzLnkgJiYgeTIgPD0gdGhpcy55ICsgdGhpcy5oZWlnaHQ7XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgdGhlIHBvc2l0aW9uIGFuZCBkaW1lbnNpb25zIG9mIHRoZSByZWN0YW5nbGUuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHVzYWdlXG4gICAqIGNvbnN0IHJlY3QgPSBuZXcgUmVjdGFuZ2xlKCk7XG4gICAqIHJlY3Quc2V0KDEwMCwgMTAwLCAyMDAsIDE1MCk7XG4gICAqXG4gICAqIC8vIENoYWluIHdpdGggb3RoZXIgb3BlcmF0aW9uc1xuICAgKiBjb25zdCBib3VuZHMgPSBuZXcgUmVjdGFuZ2xlKClcbiAgICogICAgIC5zZXQoMCwgMCwgMTAwLCAxMDApXG4gICAqICAgICAucGFkKDEwKTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSB4IC0gVGhlIFggY29vcmRpbmF0ZSBvZiB0aGUgdXBwZXItbGVmdCBjb3JuZXIgb2YgdGhlIHJlY3RhbmdsZVxuICAgKiBAcGFyYW0geSAtIFRoZSBZIGNvb3JkaW5hdGUgb2YgdGhlIHVwcGVyLWxlZnQgY29ybmVyIG9mIHRoZSByZWN0YW5nbGVcbiAgICogQHBhcmFtIHdpZHRoIC0gVGhlIG92ZXJhbGwgd2lkdGggb2YgdGhlIHJlY3RhbmdsZVxuICAgKiBAcGFyYW0gaGVpZ2h0IC0gVGhlIG92ZXJhbGwgaGVpZ2h0IG9mIHRoZSByZWN0YW5nbGVcbiAgICogQHJldHVybnMgUmV0dXJucyBpdHNlbGYgZm9yIG1ldGhvZCBjaGFpbmluZ1xuICAgKiBAc2VlIHtAbGluayBSZWN0YW5nbGUuY29weUZyb219IEZvciBjb3B5aW5nIGZyb20gYW5vdGhlciByZWN0YW5nbGVcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlLmNsb25lfSBGb3IgY3JlYXRpbmcgYSBuZXcgY29weVxuICAgKi9cbiAgc2V0KHgsIHksIHdpZHRoLCBoZWlnaHQpIHtcbiAgICB0aGlzLnggPSB4O1xuICAgIHRoaXMueSA9IHk7XG4gICAgdGhpcy53aWR0aCA9IHdpZHRoO1xuICAgIHRoaXMuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBgW3BpeGkuanMvbWF0aDpSZWN0YW5nbGUgeD0ke3RoaXMueH0geT0ke3RoaXMueX0gd2lkdGg9JHt0aGlzLndpZHRofSBoZWlnaHQ9JHt0aGlzLmhlaWdodH1dYDtcbiAgfVxufVxuXG5leHBvcnQgeyBSZWN0YW5nbGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVJlY3RhbmdsZS5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IHVpZENhY2hlID0ge1xuICBkZWZhdWx0OiAtMVxufTtcbmZ1bmN0aW9uIHVpZChuYW1lID0gXCJkZWZhdWx0XCIpIHtcbiAgaWYgKHVpZENhY2hlW25hbWVdID09PSB2b2lkIDApIHtcbiAgICB1aWRDYWNoZVtuYW1lXSA9IC0xO1xuICB9XG4gIHJldHVybiArK3VpZENhY2hlW25hbWVdO1xufVxuZnVuY3Rpb24gcmVzZXRVaWRzKCkge1xuICBmb3IgKGNvbnN0IGtleSBpbiB1aWRDYWNoZSkge1xuICAgIGRlbGV0ZSB1aWRDYWNoZVtrZXldO1xuICB9XG59XG5cbmV4cG9ydCB7IHJlc2V0VWlkcywgdWlkIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD11aWQubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCB3YXJuaW5ncyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5jb25zdCB2OF8wXzAgPSBcIjguMC4wXCI7XG5jb25zdCB2OF8zXzQgPSBcIjguMy40XCI7XG5jb25zdCB2OF8yMV8wID0gXCI4LjIxLjBcIjtcbmNvbnN0IHY4XzIyXzAgPSBcIjguMjIuMFwiO1xuY29uc3QgZGVwcmVjYXRpb25TdGF0ZSA9IHtcbiAgcXVpZXQ6IGZhbHNlLFxuICBub0NvbG9yOiBmYWxzZVxufTtcbmNvbnN0IGRlcHJlY2F0aW9uID0gKCh2ZXJzaW9uLCBtZXNzYWdlLCBpZ25vcmVEZXB0aCA9IDMpID0+IHtcbiAgaWYgKGRlcHJlY2F0aW9uU3RhdGUucXVpZXQgfHwgd2FybmluZ3MuaGFzKG1lc3NhZ2UpKSByZXR1cm47XG4gIGxldCBzdGFjayA9IG5ldyBFcnJvcigpLnN0YWNrO1xuICBjb25zdCBkZXByZWNhdGlvbk1lc3NhZ2UgPSBgJHttZXNzYWdlfVxuRGVwcmVjYXRlZCBzaW5jZSB2JHt2ZXJzaW9ufWA7XG4gIGNvbnN0IHVzZUdyb3VwID0gdHlwZW9mIGNvbnNvbGUuZ3JvdXBDb2xsYXBzZWQgPT09IFwiZnVuY3Rpb25cIiAmJiAhZGVwcmVjYXRpb25TdGF0ZS5ub0NvbG9yO1xuICBpZiAodHlwZW9mIHN0YWNrID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgY29uc29sZS53YXJuKFwiUGl4aUpTIERlcHJlY2F0aW9uIFdhcm5pbmc6IFwiLCBkZXByZWNhdGlvbk1lc3NhZ2UpO1xuICB9IGVsc2Uge1xuICAgIHN0YWNrID0gc3RhY2suc3BsaXQoXCJcXG5cIikuc3BsaWNlKGlnbm9yZURlcHRoKS5qb2luKFwiXFxuXCIpO1xuICAgIGlmICh1c2VHcm91cCkge1xuICAgICAgY29uc29sZS5ncm91cENvbGxhcHNlZChcbiAgICAgICAgXCIlY1BpeGlKUyBEZXByZWNhdGlvbiBXYXJuaW5nOiAlYyVzXCIsXG4gICAgICAgIFwiY29sb3I6IzYxNDEwODtiYWNrZ3JvdW5kOiNmZmZiZTZcIixcbiAgICAgICAgXCJmb250LXdlaWdodDpub3JtYWw7Y29sb3I6IzYxNDEwODtiYWNrZ3JvdW5kOiNmZmZiZTZcIixcbiAgICAgICAgZGVwcmVjYXRpb25NZXNzYWdlXG4gICAgICApO1xuICAgICAgY29uc29sZS53YXJuKHN0YWNrKTtcbiAgICAgIGNvbnNvbGUuZ3JvdXBFbmQoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS53YXJuKFwiUGl4aUpTIERlcHJlY2F0aW9uIFdhcm5pbmc6IFwiLCBkZXByZWNhdGlvbk1lc3NhZ2UpO1xuICAgICAgY29uc29sZS53YXJuKHN0YWNrKTtcbiAgICB9XG4gIH1cbiAgd2FybmluZ3MuYWRkKG1lc3NhZ2UpO1xufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydGllcyhkZXByZWNhdGlvbiwge1xuICBxdWlldDoge1xuICAgIGdldDogKCkgPT4gZGVwcmVjYXRpb25TdGF0ZS5xdWlldCxcbiAgICBzZXQ6ICh2YWx1ZSkgPT4ge1xuICAgICAgZGVwcmVjYXRpb25TdGF0ZS5xdWlldCA9IHZhbHVlO1xuICAgIH0sXG4gICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICBjb25maWd1cmFibGU6IGZhbHNlXG4gIH0sXG4gIG5vQ29sb3I6IHtcbiAgICBnZXQ6ICgpID0+IGRlcHJlY2F0aW9uU3RhdGUubm9Db2xvcixcbiAgICBzZXQ6ICh2YWx1ZSkgPT4ge1xuICAgICAgZGVwcmVjYXRpb25TdGF0ZS5ub0NvbG9yID0gdmFsdWU7XG4gICAgfSxcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGNvbmZpZ3VyYWJsZTogZmFsc2VcbiAgfVxufSk7XG5cbmV4cG9ydCB7IGRlcHJlY2F0aW9uLCB2OF8wXzAsIHY4XzIxXzAsIHY4XzIyXzAsIHY4XzNfNCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZGVwcmVjYXRpb24ubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBOT09QID0gKCkgPT4ge1xufTtcblxuZXhwb3J0IHsgTk9PUCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Tk9PUC5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGlzSW50ZWdlckZvcm1hdChmb3JtYXQpIHtcbiAgcmV0dXJuIGZvcm1hdC5lbmRzV2l0aChcImludFwiKTtcbn1cblxuZXhwb3J0IHsgaXNJbnRlZ2VyRm9ybWF0IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pc0ludGVnZXJGb3JtYXQubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBuZXh0UG93Mih2KSB7XG4gIHYgKz0gdiA9PT0gMCA/IDEgOiAwO1xuICAtLXY7XG4gIHYgfD0gdiA+Pj4gMTtcbiAgdiB8PSB2ID4+PiAyO1xuICB2IHw9IHYgPj4+IDQ7XG4gIHYgfD0gdiA+Pj4gODtcbiAgdiB8PSB2ID4+PiAxNjtcbiAgcmV0dXJuIHYgKyAxO1xufVxuZnVuY3Rpb24gaXNQb3cyKHYpIHtcbiAgcmV0dXJuICEodiAmIHYgLSAxKSAmJiAhIXY7XG59XG5mdW5jdGlvbiBsb2cyKHYpIHtcbiAgbGV0IHIgPSAodiA+IDY1NTM1ID8gMSA6IDApIDw8IDQ7XG4gIHYgPj4+PSByO1xuICBsZXQgc2hpZnQgPSAodiA+IDI1NSA/IDEgOiAwKSA8PCAzO1xuICB2ID4+Pj0gc2hpZnQ7XG4gIHIgfD0gc2hpZnQ7XG4gIHNoaWZ0ID0gKHYgPiAxNSA/IDEgOiAwKSA8PCAyO1xuICB2ID4+Pj0gc2hpZnQ7XG4gIHIgfD0gc2hpZnQ7XG4gIHNoaWZ0ID0gKHYgPiAzID8gMSA6IDApIDw8IDE7XG4gIHYgPj4+PSBzaGlmdDtcbiAgciB8PSBzaGlmdDtcbiAgcmV0dXJuIHIgfCB2ID4+IDE7XG59XG5cbmV4cG9ydCB7IGlzUG93MiwgbG9nMiwgbmV4dFBvdzIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBvdzIubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBkZWZpbmVkUHJvcHMob2JqKSB7XG4gIGNvbnN0IHJlc3VsdCA9IHt9O1xuICBmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcbiAgICBpZiAob2JqW2tleV0gIT09IHZvaWQgMCkge1xuICAgICAgcmVzdWx0W2tleV0gPSBvYmpba2V5XTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZXhwb3J0IHsgZGVmaW5lZFByb3BzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1kZWZpbmVkUHJvcHMubWpzLm1hcFxuIiwiaW1wb3J0IEV2ZW50RW1pdHRlciBmcm9tICdldmVudGVtaXR0ZXIzJztcbmltcG9ydCB7IHVpZCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGEvdWlkLm1qcyc7XG5pbXBvcnQgeyBkZXByZWNhdGlvbiwgdjhfMF8wIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy9kZXByZWNhdGlvbi5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IGlkSGFzaCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuZnVuY3Rpb24gY3JlYXRlUmVzb3VyY2VJZEZyb21TdHJpbmcodmFsdWUpIHtcbiAgY29uc3QgaWQgPSBpZEhhc2hbdmFsdWVdO1xuICBpZiAoaWQgPT09IHZvaWQgMCkge1xuICAgIGlkSGFzaFt2YWx1ZV0gPSB1aWQoXCJyZXNvdXJjZVwiKTtcbiAgfVxuICByZXR1cm4gaWQ7XG59XG5jb25zdCBfVGV4dHVyZVN0eWxlID0gY2xhc3MgX1RleHR1cmVTdHlsZSBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIC8qKlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIG9wdGlvbnMgZm9yIHRoZSBzdHlsZVxuICAgKi9cbiAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgc3VwZXIoKTtcbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy5fcmVzb3VyY2VUeXBlID0gXCJ0ZXh0dXJlU2FtcGxlclwiO1xuICAgIC8qKlxuICAgICAqIFNwZWNpZmllcyB0aGUgbWF4aW11bSBhbmlzb3Ryb3B5IHZhbHVlIGNsYW1wIHVzZWQgYnkgdGhlIHNhbXBsZXIuXG4gICAgICogTm90ZTogTW9zdCBpbXBsZW1lbnRhdGlvbnMgc3VwcG9ydCB7QGxpbmsgVGV4dHVyZVN0eWxlI21heEFuaXNvdHJvcHl9IHZhbHVlcyBpbiByYW5nZVxuICAgICAqIGJldHdlZW4gMSBhbmQgMTYsIGluY2x1c2l2ZS4gVGhlIHVzZWQgdmFsdWUgb2Yge0BsaW5rIFRleHR1cmVTdHlsZSNtYXhBbmlzb3Ryb3B5fSB3aWxsXG4gICAgICogYmUgY2xhbXBlZCB0byB0aGUgbWF4aW11bSB2YWx1ZSB0aGF0IHRoZSBwbGF0Zm9ybSBzdXBwb3J0cy5cbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9tYXhBbmlzb3Ryb3B5ID0gMTtcbiAgICAvKipcbiAgICAgKiBIYXMgdGhlIHN0eWxlIGJlZW4gZGVzdHJveWVkP1xuICAgICAqIEByZWFkb25seVxuICAgICAqL1xuICAgIHRoaXMuZGVzdHJveWVkID0gZmFsc2U7XG4gICAgb3B0aW9ucyA9IHsgLi4uX1RleHR1cmVTdHlsZS5kZWZhdWx0T3B0aW9ucywgLi4ub3B0aW9ucyB9O1xuICAgIHRoaXMuYWRkcmVzc01vZGUgPSBvcHRpb25zLmFkZHJlc3NNb2RlO1xuICAgIHRoaXMuYWRkcmVzc01vZGVVID0gb3B0aW9ucy5hZGRyZXNzTW9kZVUgPz8gdGhpcy5hZGRyZXNzTW9kZVU7XG4gICAgdGhpcy5hZGRyZXNzTW9kZVYgPSBvcHRpb25zLmFkZHJlc3NNb2RlViA/PyB0aGlzLmFkZHJlc3NNb2RlVjtcbiAgICB0aGlzLmFkZHJlc3NNb2RlVyA9IG9wdGlvbnMuYWRkcmVzc01vZGVXID8/IHRoaXMuYWRkcmVzc01vZGVXO1xuICAgIHRoaXMuc2NhbGVNb2RlID0gb3B0aW9ucy5zY2FsZU1vZGU7XG4gICAgdGhpcy5tYWdGaWx0ZXIgPSBvcHRpb25zLm1hZ0ZpbHRlciA/PyB0aGlzLm1hZ0ZpbHRlcjtcbiAgICB0aGlzLm1pbkZpbHRlciA9IG9wdGlvbnMubWluRmlsdGVyID8/IHRoaXMubWluRmlsdGVyO1xuICAgIHRoaXMubWlwbWFwRmlsdGVyID0gb3B0aW9ucy5taXBtYXBGaWx0ZXIgPz8gdGhpcy5taXBtYXBGaWx0ZXI7XG4gICAgdGhpcy5sb2RNaW5DbGFtcCA9IG9wdGlvbnMubG9kTWluQ2xhbXA7XG4gICAgdGhpcy5sb2RNYXhDbGFtcCA9IG9wdGlvbnMubG9kTWF4Q2xhbXA7XG4gICAgdGhpcy5jb21wYXJlID0gb3B0aW9ucy5jb21wYXJlO1xuICAgIHRoaXMubWF4QW5pc290cm9weSA9IG9wdGlvbnMubWF4QW5pc290cm9weSA/PyAxO1xuICB9XG4gIHNldCBhZGRyZXNzTW9kZSh2YWx1ZSkge1xuICAgIHRoaXMuYWRkcmVzc01vZGVVID0gdmFsdWU7XG4gICAgdGhpcy5hZGRyZXNzTW9kZVYgPSB2YWx1ZTtcbiAgICB0aGlzLmFkZHJlc3NNb2RlVyA9IHZhbHVlO1xuICB9XG4gIC8qKiBzZXR0aW5nIHRoaXMgd2lsbCBzZXQgd3JhcE1vZGVVLHdyYXBNb2RlViBhbmQgd3JhcE1vZGVXIGFsbCBhdCBvbmNlISAqL1xuICBnZXQgYWRkcmVzc01vZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuYWRkcmVzc01vZGVVO1xuICB9XG4gIHNldCB3cmFwTW9kZSh2YWx1ZSkge1xuICAgIGRlcHJlY2F0aW9uKHY4XzBfMCwgXCJUZXh0dXJlU3R5bGUud3JhcE1vZGUgaXMgbm93IFRleHR1cmVTdHlsZS5hZGRyZXNzTW9kZVwiKTtcbiAgICB0aGlzLmFkZHJlc3NNb2RlID0gdmFsdWU7XG4gIH1cbiAgZ2V0IHdyYXBNb2RlKCkge1xuICAgIHJldHVybiB0aGlzLmFkZHJlc3NNb2RlO1xuICB9XG4gIHNldCBzY2FsZU1vZGUodmFsdWUpIHtcbiAgICB0aGlzLm1hZ0ZpbHRlciA9IHZhbHVlO1xuICAgIHRoaXMubWluRmlsdGVyID0gdmFsdWU7XG4gICAgdGhpcy5taXBtYXBGaWx0ZXIgPSB2YWx1ZTtcbiAgfVxuICAvKiogc2V0dGluZyB0aGlzIHdpbGwgc2V0IG1hZ0ZpbHRlcixtaW5GaWx0ZXIgYW5kIG1pcG1hcEZpbHRlciBhbGwgYXQgb25jZSEgICovXG4gIGdldCBzY2FsZU1vZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMubWFnRmlsdGVyO1xuICB9XG4gIC8qKiBTcGVjaWZpZXMgdGhlIG1heGltdW0gYW5pc290cm9weSB2YWx1ZSBjbGFtcCB1c2VkIGJ5IHRoZSBzYW1wbGVyLiAqL1xuICBzZXQgbWF4QW5pc290cm9weSh2YWx1ZSkge1xuICAgIHRoaXMuX21heEFuaXNvdHJvcHkgPSBNYXRoLm1pbih2YWx1ZSwgMTYpO1xuICAgIGlmICh0aGlzLl9tYXhBbmlzb3Ryb3B5ID4gMSkge1xuICAgICAgdGhpcy5zY2FsZU1vZGUgPSBcImxpbmVhclwiO1xuICAgIH1cbiAgfVxuICBnZXQgbWF4QW5pc290cm9weSgpIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4QW5pc290cm9weTtcbiAgfVxuICAvLyBUT0RPIC0gbW92ZSB0aGlzIHRvIFdlYkdMP1xuICBnZXQgX3Jlc291cmNlSWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NoYXJlZFJlc291cmNlSWQgfHwgdGhpcy5fZ2VuZXJhdGVSZXNvdXJjZUlkKCk7XG4gIH1cbiAgdXBkYXRlKCkge1xuICAgIHRoaXMuX3NoYXJlZFJlc291cmNlSWQgPSBudWxsO1xuICAgIHRoaXMuZW1pdChcImNoYW5nZVwiLCB0aGlzKTtcbiAgfVxuICBfZ2VuZXJhdGVSZXNvdXJjZUlkKCkge1xuICAgIGNvbnN0IGJpZ0tleSA9IGAke3RoaXMuYWRkcmVzc01vZGVVfS0ke3RoaXMuYWRkcmVzc01vZGVWfS0ke3RoaXMuYWRkcmVzc01vZGVXfS0ke3RoaXMubWFnRmlsdGVyfS0ke3RoaXMubWluRmlsdGVyfS0ke3RoaXMubWlwbWFwRmlsdGVyfS0ke3RoaXMubG9kTWluQ2xhbXB9LSR7dGhpcy5sb2RNYXhDbGFtcH0tJHt0aGlzLmNvbXBhcmV9LSR7dGhpcy5fbWF4QW5pc290cm9weX1gO1xuICAgIHRoaXMuX3NoYXJlZFJlc291cmNlSWQgPSBjcmVhdGVSZXNvdXJjZUlkRnJvbVN0cmluZyhiaWdLZXkpO1xuICAgIHJldHVybiB0aGlzLl9yZXNvdXJjZUlkO1xuICB9XG4gIC8qKiBEZXN0cm95cyB0aGUgc3R5bGUgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLmRlc3Ryb3llZCA9IHRydWU7XG4gICAgdGhpcy5lbWl0KFwiZGVzdHJveVwiLCB0aGlzKTtcbiAgICB0aGlzLmVtaXQoXCJjaGFuZ2VcIiwgdGhpcyk7XG4gICAgdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcbiAgfVxufTtcbi8qKiBkZWZhdWx0IG9wdGlvbnMgZm9yIHRoZSBzdHlsZSAqL1xuX1RleHR1cmVTdHlsZS5kZWZhdWx0T3B0aW9ucyA9IHtcbiAgYWRkcmVzc01vZGU6IFwiY2xhbXAtdG8tZWRnZVwiLFxuICBzY2FsZU1vZGU6IFwibGluZWFyXCJcbn07XG5sZXQgVGV4dHVyZVN0eWxlID0gX1RleHR1cmVTdHlsZTtcblxuZXhwb3J0IHsgVGV4dHVyZVN0eWxlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1UZXh0dXJlU3R5bGUubWpzLm1hcFxuIiwiaW1wb3J0IEV2ZW50RW1pdHRlciBmcm9tICdldmVudGVtaXR0ZXIzJztcbmltcG9ydCB7IGlzUG93MiB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL21hdGhzL21pc2MvcG93Mi5tanMnO1xuaW1wb3J0IHsgZGVmaW5lZFByb3BzIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vc2NlbmUvY29udGFpbmVyL3V0aWxzL2RlZmluZWRQcm9wcy5tanMnO1xuaW1wb3J0IHsgdWlkIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vdXRpbHMvZGF0YS91aWQubWpzJztcbmltcG9ydCB7IGRlcHJlY2F0aW9uLCB2OF8yMl8wIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy9kZXByZWNhdGlvbi5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVN0eWxlIH0gZnJvbSAnLi4vVGV4dHVyZVN0eWxlLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgX1RleHR1cmVTb3VyY2UgPSBjbGFzcyBfVGV4dHVyZVNvdXJjZSBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIC8qKlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIG9wdGlvbnMgZm9yIGNyZWF0aW5nIGEgbmV3IFRleHR1cmVTb3VyY2VcbiAgICovXG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy5fZ3B1RGF0YSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLl9nY0xhc3RVc2VkID0gLTE7XG4gICAgLyoqIHVuaXF1ZSBpZCBmb3IgdGhpcyBUZXh0dXJlIHNvdXJjZSAqL1xuICAgIHRoaXMudWlkID0gdWlkKFwidGV4dHVyZVNvdXJjZVwiKTtcbiAgICAvKipcbiAgICAgKiBUaGUgcmVzb3VyY2UgdHlwZSB1c2VkIGJ5IHRoaXMgVGV4dHVyZVNvdXJjZS4gVGhpcyBpcyB1c2VkIGJ5IHRoZSBiaW5kIGdyb3VwcyB0byBkZXRlcm1pbmVcbiAgICAgKiBob3cgdG8gaGFuZGxlIHRoaXMgcmVzb3VyY2UuXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fcmVzb3VyY2VUeXBlID0gXCJ0ZXh0dXJlU291cmNlXCI7XG4gICAgLyoqXG4gICAgICogaSB1bmlxdWUgcmVzb3VyY2UgaWQsIHVzZWQgYnkgdGhlIGJpbmQgZ3JvdXAgc3lzdGVtcy5cbiAgICAgKiBUaGlzIGNhbiBjaGFuZ2UgaWYgdGhlIHRleHR1cmUgaXMgcmVzaXplZCBvciBpdHMgcmVzb3VyY2UgY2hhbmdlc1xuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX3Jlc291cmNlSWQgPSB1aWQoXCJyZXNvdXJjZVwiKTtcbiAgICAvKipcbiAgICAgKiB0aGlzIGlzIGhvdyB0aGUgYmFja2VuZHMga25vdyBob3cgdG8gdXBsb2FkIHRoaXMgdGV4dHVyZSB0byB0aGUgR1BVXG4gICAgICogSXQgY2hhbmdlcyBkZXBlbmRpbmcgb24gdGhlIHJlc291cmNlIHR5cGUuIENsYXNzZXMgdGhhdCBleHRlbmQgVGV4dHVyZVNvdXJjZVxuICAgICAqIHNob3VsZCBvdmVycmlkZSB0aGlzIHByb3BlcnR5LlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMudXBsb2FkTWV0aG9kSWQgPSBcInVua25vd25cIjtcbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy5fcmVzb2x1dGlvbiA9IDE7XG4gICAgLyoqIHRoZSBwaXhlbCB3aWR0aCBvZiB0aGlzIHRleHR1cmUgc291cmNlLiBUaGlzIGlzIHRoZSBSRUFMIHB1cmUgbnVtYmVyLCBub3QgYWNjb3VudGluZyByZXNvbHV0aW9uICovXG4gICAgdGhpcy5waXhlbFdpZHRoID0gMTtcbiAgICAvKiogdGhlIHBpeGVsIGhlaWdodCBvZiB0aGlzIHRleHR1cmUgc291cmNlLiBUaGlzIGlzIHRoZSBSRUFMIHB1cmUgbnVtYmVyLCBub3QgYWNjb3VudGluZyByZXNvbHV0aW9uICovXG4gICAgdGhpcy5waXhlbEhlaWdodCA9IDE7XG4gICAgLyoqXG4gICAgICogdGhlIHdpZHRoIG9mIHRoaXMgdGV4dHVyZSBzb3VyY2UsIGFjY291bnRpbmcgZm9yIHJlc29sdXRpb25cbiAgICAgKiBlZyBwaXhlbFdpZHRoIDIwMCwgcmVzb2x1dGlvbiAyLCB0aGVuIHdpZHRoIHdpbGwgYmUgMTAwXG4gICAgICovXG4gICAgdGhpcy53aWR0aCA9IDE7XG4gICAgLyoqXG4gICAgICogdGhlIGhlaWdodCBvZiB0aGlzIHRleHR1cmUgc291cmNlLCBhY2NvdW50aW5nIGZvciByZXNvbHV0aW9uXG4gICAgICogZWcgcGl4ZWxIZWlnaHQgMjAwLCByZXNvbHV0aW9uIDIsIHRoZW4gaGVpZ2h0IHdpbGwgYmUgMTAwXG4gICAgICovXG4gICAgdGhpcy5oZWlnaHQgPSAxO1xuICAgIC8qKlxuICAgICAqIFRoZSBudW1iZXIgb2Ygc2FtcGxlcyBvZiBhIG11bHRpc2FtcGxlIHRleHR1cmUuIFRoaXMgaXMgYWx3YXlzIDEgZm9yIG5vbi1tdWx0aXNhbXBsZSB0ZXh0dXJlcy5cbiAgICAgKiBUbyBlbmFibGUgbXVsdGlzYW1wbGUgZm9yIGEgdGV4dHVyZSwgc2V0IGFudGlhbGlhcyB0byB0cnVlXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5zYW1wbGVDb3VudCA9IDE7XG4gICAgLyoqXG4gICAgICogVGhlIG51bWJlciBvZiBtaXAgbGV2ZWxzIHRvIGdlbmVyYXRlIGZvciB0aGlzIHRleHR1cmUuXG4gICAgICogdGhpcyBpcyBvdmVycmlkZGVuIGlmIGF1dG9HZW5lcmF0ZU1pcG1hcHMgaXMgdHJ1ZS4gaXQgaXMgcmVhZCBvbmx5IVxuICAgICAqL1xuICAgIHRoaXMubWlwTGV2ZWxDb3VudCA9IDE7XG4gICAgLyoqXG4gICAgICogU2hvdWxkIHdlIGF1dG8gZ2VuZXJhdGUgbWlwbWFwcyBmb3IgdGhpcyB0ZXh0dXJlPyBUaGlzIHdpbGwgYXV0b21hdGljYWxseSBnZW5lcmF0ZSBtaXBtYXBzXG4gICAgICogZm9yIHRoaXMgdGV4dHVyZSB3aGVuIHVwbG9hZGluZyB0byB0aGUgR1BVLiBNaXBtYXBwZWQgdGV4dHVyZXMgdGFrZSB1cCBtb3JlIG1lbW9yeSwgYnV0XG4gICAgICogY2FuIGxvb2sgYmV0dGVyIHdoZW4gc2NhbGVkIGRvd24uXG4gICAgICpcbiAgICAgKiBGb3IgcGVyZm9ybWFuY2UgcmVhc29ucywgaXQgaXMgcmVjb21tZW5kZWQgdG8gTk9UIHVzZSB0aGlzIHdpdGggUmVuZGVyVGV4dHVyZXMsIGFzIHRoZXkgYXJlIG9mdGVuIHVwZGF0ZWQgZXZlcnkgZnJhbWUuXG4gICAgICogSWYgeW91IGRvLCBtYWtlIHN1cmUgdG8gY2FsbCBgdXBkYXRlTWlwbWFwc2AgYWZ0ZXIgeW91IHVwZGF0ZSB0aGUgdGV4dHVyZS5cbiAgICAgKlxuICAgICAqIEEgM0QgdGV4dHVyZSBvbiBXZWJHUFUgbmVlZHMge0BsaW5rIFRleHR1cmVTb3VyY2VPcHRpb25zLnN0b3JhZ2V9IGFuZCBgcmdiYTh1bm9ybWAgb3IgYHJnYmExNmZsb2F0YCxcbiAgICAgKiBiZWNhdXNlIGEgY29tcHV0ZSBzaGFkZXIgd3JpdGVzIHRoZSBtaXBzLiBXZWJHTCBmaWxscyB0aGUgY2hhaW4gd2l0aCBgZ2wuZ2VuZXJhdGVNaXBtYXBgLlxuICAgICAqL1xuICAgIHRoaXMuYXV0b0dlbmVyYXRlTWlwbWFwcyA9IGZhbHNlO1xuICAgIC8qKiB0aGUgZm9ybWF0IHRoYXQgdGhlIHRleHR1cmUgZGF0YSBoYXMgKi9cbiAgICB0aGlzLmZvcm1hdCA9IFwicmdiYTh1bm9ybVwiO1xuICAgIC8qKiBob3cgdGhlIHRleHR1cmUgaXMgc3RvcmVkIChXZWJHUFUgdGV4dHVyZSBkaW1lbnNpb24pLCBkZXJpdmVkIGZyb20ge0BsaW5rIFRleHR1cmVTb3VyY2Ujdmlld0RpbWVuc2lvbn0gKi9cbiAgICB0aGlzLmRpbWVuc2lvbiA9IFwiMmRcIjtcbiAgICAvKiogaG93IHRoaXMgdGV4dHVyZSBpcyB2aWV3ZWQvc2FtcGxlZCBieSBzaGFkZXJzIChXZWJHUFUgdmlldyBkaW1lbnNpb24pICovXG4gICAgdGhpcy52aWV3RGltZW5zaW9uID0gXCIyZFwiO1xuICAgIC8qKiBob3cgbWFueSBhcnJheSBsYXllcnMgdGhpcyB0ZXh0dXJlIGhhczsgMSBmb3IgYSAzRCB0ZXh0dXJlICovXG4gICAgdGhpcy5hcnJheUxheWVyQ291bnQgPSAxO1xuICAgIC8qKiB0aGUgZGVwdGggb2YgYSAzRCB0ZXh0dXJlIGluIHRleGVsczsgMSBmb3IgZXZlcnkgb3RoZXIgdGV4dHVyZSAqL1xuICAgIHRoaXMuZGVwdGggPSAxO1xuICAgIHRoaXMuX293bnNTdHlsZSA9IGZhbHNlO1xuICAgIC8qKlxuICAgICAqIE9ubHkgcmVhbGx5IGFmZmVjdHMgUmVuZGVyVGV4dHVyZXMuXG4gICAgICogU2hvdWxkIHdlIHVzZSBhbnRpYWxpYXNpbmcgZm9yIHRoaXMgdGV4dHVyZS4gSXQgd2lsbCBsb29rIGJldHRlciwgYnV0IG1heSBpbXBhY3QgcGVyZm9ybWFuY2UgYXMgYVxuICAgICAqIEJsaXQgb3BlcmF0aW9uIHdpbGwgYmUgcmVxdWlyZWQgdG8gcmVzb2x2ZSB0aGUgdGV4dHVyZS5cbiAgICAgKi9cbiAgICB0aGlzLmFudGlhbGlhcyA9IGZhbHNlO1xuICAgIC8qKlxuICAgICAqIFRyZWF0IHRoZSB1bmRlcmx5aW5nIEdQVSB0ZXh0dXJlIGFzIHRyYW5zaWVudCDigJQgc2VlIHtAbGluayBUZXh0dXJlU291cmNlT3B0aW9ucy50cmFuc2llbnR9LlxuICAgICAqIEludGVybmFsIGZsYWcsIHBvcHVsYXRlZCBmcm9tIG9wdGlvbnMuXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy50cmFuc2llbnQgPSBmYWxzZTtcbiAgICAvKipcbiAgICAgKiBXaGV0aGVyIGNvbXB1dGUgc2hhZGVycyBjYW4gd3JpdGUgdG8gdGhpcyB0ZXh0dXJlIG9uIFdlYkdQVS4gU2VlIHtAbGluayBUZXh0dXJlU291cmNlT3B0aW9ucy5zdG9yYWdlfS5cbiAgICAgKiBSZWFkIHdoZW4gdGhlIEdQVSB0ZXh0dXJlIGlzIGNyZWF0ZWQuXG4gICAgICovXG4gICAgdGhpcy5zdG9yYWdlID0gZmFsc2U7XG4gICAgLyoqXG4gICAgICogVXNlZCBieSB0aGUgYmF0Y2hlciB0byBidWlsZCB0ZXh0dXJlIGJhdGNoZXMuIGZhc3RlciB0byBoYXZlIHRoZSB2YXJpYWJsZSBoZXJlIVxuICAgICAqIEBwcm90ZWN0ZWRcbiAgICAgKi9cbiAgICB0aGlzLl9iYXRjaFRpY2sgPSAtMTtcbiAgICAvKipcbiAgICAgKiBBIHRlbXBvcmFyeSBiYXRjaCBsb2NhdGlvbiBmb3IgdGhlIHRleHR1cmUgYmF0Y2hpbmcuIEhlcmUgZm9yIHBlcmZvcm1hbmNlIHJlYXNvbnMgb25seSFcbiAgICAgKiBAcHJvdGVjdGVkXG4gICAgICovXG4gICAgdGhpcy5fdGV4dHVyZUJpbmRMb2NhdGlvbiA9IC0xO1xuICAgIGNvbnN0IHBhc3NlZE9wdGlvbnMgPSBvcHRpb25zO1xuICAgIG9wdGlvbnMgPSB7IC4uLl9UZXh0dXJlU291cmNlLmRlZmF1bHRPcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgY29uc3Qgdmlld0RpbWVuc2lvbiA9IHJlc29sdmVWaWV3RGltZW5zaW9uKG9wdGlvbnMpO1xuICAgIGNvbnN0IGRpbWVuc2lvbiA9IHZpZXdEaW1lbnNpb24gPT09IFwiM2RcIiB8fCB2aWV3RGltZW5zaW9uID09PSBcIjFkXCIgPyB2aWV3RGltZW5zaW9uIDogXCIyZFwiO1xuICAgIHZhbGlkYXRlVGV4dHVyZVNoYXBlKHBhc3NlZE9wdGlvbnMsIHZpZXdEaW1lbnNpb24sIGRpbWVuc2lvbik7XG4gICAgdGhpcy5sYWJlbCA9IG9wdGlvbnMubGFiZWwgPz8gXCJcIjtcbiAgICB0aGlzLnJlc291cmNlID0gb3B0aW9ucy5yZXNvdXJjZTtcbiAgICB0aGlzLmF1dG9HYXJiYWdlQ29sbGVjdCA9IG9wdGlvbnMuYXV0b0dhcmJhZ2VDb2xsZWN0O1xuICAgIHRoaXMuX3Jlc29sdXRpb24gPSBvcHRpb25zLnJlc29sdXRpb247XG4gICAgaWYgKG9wdGlvbnMud2lkdGgpIHtcbiAgICAgIHRoaXMucGl4ZWxXaWR0aCA9IG9wdGlvbnMud2lkdGggKiB0aGlzLl9yZXNvbHV0aW9uO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnBpeGVsV2lkdGggPSB0aGlzLnJlc291cmNlID8gdGhpcy5yZXNvdXJjZVdpZHRoID8/IDEgOiAxO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5oZWlnaHQpIHtcbiAgICAgIHRoaXMucGl4ZWxIZWlnaHQgPSBvcHRpb25zLmhlaWdodCAqIHRoaXMuX3Jlc29sdXRpb247XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMucGl4ZWxIZWlnaHQgPSB0aGlzLnJlc291cmNlID8gdGhpcy5yZXNvdXJjZUhlaWdodCA/PyAxIDogMTtcbiAgICB9XG4gICAgdGhpcy53aWR0aCA9IHRoaXMucGl4ZWxXaWR0aCAvIHRoaXMuX3Jlc29sdXRpb247XG4gICAgdGhpcy5oZWlnaHQgPSB0aGlzLnBpeGVsSGVpZ2h0IC8gdGhpcy5fcmVzb2x1dGlvbjtcbiAgICB0aGlzLmZvcm1hdCA9IG9wdGlvbnMuZm9ybWF0O1xuICAgIHRoaXMuZGltZW5zaW9uID0gZGltZW5zaW9uO1xuICAgIHRoaXMudmlld0RpbWVuc2lvbiA9IHZpZXdEaW1lbnNpb247XG4gICAgdGhpcy5hcnJheUxheWVyQ291bnQgPSBvcHRpb25zLmFycmF5TGF5ZXJDb3VudDtcbiAgICB0aGlzLmRlcHRoID0gZGltZW5zaW9uID09PSBcIjNkXCIgPyBvcHRpb25zLmRlcHRoID8/IDEgOiAxO1xuICAgIHRoaXMubWlwTGV2ZWxDb3VudCA9IG9wdGlvbnMubWlwTGV2ZWxDb3VudDtcbiAgICB0aGlzLmF1dG9HZW5lcmF0ZU1pcG1hcHMgPSBvcHRpb25zLmF1dG9HZW5lcmF0ZU1pcG1hcHM7XG4gICAgdGhpcy5zYW1wbGVDb3VudCA9IG9wdGlvbnMuc2FtcGxlQ291bnQ7XG4gICAgdGhpcy5hbnRpYWxpYXMgPSBkaW1lbnNpb24gPT09IFwiM2RcIiA/IGZhbHNlIDogb3B0aW9ucy5hbnRpYWxpYXM7XG4gICAgdGhpcy50cmFuc2llbnQgPSBvcHRpb25zLnRyYW5zaWVudCA/PyBmYWxzZTtcbiAgICB0aGlzLnN0b3JhZ2UgPSBvcHRpb25zLnN0b3JhZ2UgPz8gZmFsc2U7XG4gICAgdGhpcy5hbHBoYU1vZGUgPSBvcHRpb25zLmFscGhhTW9kZTtcbiAgICB0aGlzLnN0eWxlID0gbmV3IFRleHR1cmVTdHlsZShkZWZpbmVkUHJvcHMob3B0aW9ucykpO1xuICAgIHRoaXMuX293bnNTdHlsZSA9IHRydWU7XG4gICAgdGhpcy5kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9yZWZyZXNoUE9UKCk7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBzaXplIGFsb25nIHogdGhhdCB0aGUgR1BVIGFsbG9jYXRlczoge0BsaW5rIFRleHR1cmVTb3VyY2UjZGVwdGh9IGZvciBhIDNEIHRleHR1cmUsXG4gICAqIHtAbGluayBUZXh0dXJlU291cmNlI2FycmF5TGF5ZXJDb3VudH0gb3RoZXJ3aXNlLiBXZWJHUFUncyBgZGVwdGhPckFycmF5TGF5ZXJzYC5cbiAgICovXG4gIGdldCBkZXB0aE9yQXJyYXlMYXllcnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuZGltZW5zaW9uID09PSBcIjNkXCIgPyB0aGlzLmRlcHRoIDogdGhpcy5hcnJheUxheWVyQ291bnQgfHwgMTtcbiAgfVxuICAvKiogcmV0dXJucyBpdHNlbGYgKi9cbiAgZ2V0IHNvdXJjZSgpIHtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKiogdGhlIHN0eWxlIG9mIHRoZSB0ZXh0dXJlICovXG4gIGdldCBzdHlsZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fc3R5bGU7XG4gIH1cbiAgc2V0IHN0eWxlKHZhbHVlKSB7XG4gICAgaWYgKHRoaXMuc3R5bGUgPT09IHZhbHVlKSByZXR1cm47XG4gICAgdGhpcy5fb3duc1N0eWxlID0gZmFsc2U7XG4gICAgdGhpcy5fc3R5bGU/Lm9mZihcImNoYW5nZVwiLCB0aGlzLl9vblN0eWxlQ2hhbmdlLCB0aGlzKTtcbiAgICB0aGlzLl9zdHlsZSA9IHZhbHVlO1xuICAgIHRoaXMuX3N0eWxlPy5vbihcImNoYW5nZVwiLCB0aGlzLl9vblN0eWxlQ2hhbmdlLCB0aGlzKTtcbiAgICB0aGlzLl9vblN0eWxlQ2hhbmdlKCk7XG4gIH1cbiAgLyoqIFNwZWNpZmllcyB0aGUgbWF4aW11bSBhbmlzb3Ryb3B5IHZhbHVlIGNsYW1wIHVzZWQgYnkgdGhlIHNhbXBsZXIuICovXG4gIHNldCBtYXhBbmlzb3Ryb3B5KHZhbHVlKSB7XG4gICAgdGhpcy5fc3R5bGUubWF4QW5pc290cm9weSA9IHZhbHVlO1xuICB9XG4gIGdldCBtYXhBbmlzb3Ryb3B5KCkge1xuICAgIHJldHVybiB0aGlzLl9zdHlsZS5tYXhBbmlzb3Ryb3B5O1xuICB9XG4gIC8qKiBzZXR0aW5nIHRoaXMgd2lsbCBzZXQgd3JhcE1vZGVVLCB3cmFwTW9kZVYgYW5kIHdyYXBNb2RlVyBhbGwgYXQgb25jZSEgKi9cbiAgZ2V0IGFkZHJlc3NNb2RlKCkge1xuICAgIHJldHVybiB0aGlzLl9zdHlsZS5hZGRyZXNzTW9kZTtcbiAgfVxuICBzZXQgYWRkcmVzc01vZGUodmFsdWUpIHtcbiAgICB0aGlzLl9zdHlsZS5hZGRyZXNzTW9kZSA9IHZhbHVlO1xuICB9XG4gIC8qKiBzZXR0aW5nIHRoaXMgd2lsbCBzZXQgd3JhcE1vZGVVLCB3cmFwTW9kZVYgYW5kIHdyYXBNb2RlVyBhbGwgYXQgb25jZSEgKi9cbiAgZ2V0IHJlcGVhdE1vZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3N0eWxlLmFkZHJlc3NNb2RlO1xuICB9XG4gIHNldCByZXBlYXRNb2RlKHZhbHVlKSB7XG4gICAgdGhpcy5fc3R5bGUuYWRkcmVzc01vZGUgPSB2YWx1ZTtcbiAgfVxuICAvKiogU3BlY2lmaWVzIHRoZSBzYW1wbGluZyBiZWhhdmlvciB3aGVuIHRoZSBzYW1wbGUgZm9vdHByaW50IGlzIHNtYWxsZXIgdGhhbiBvciBlcXVhbCB0byBvbmUgdGV4ZWwuICovXG4gIGdldCBtYWdGaWx0ZXIoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3N0eWxlLm1hZ0ZpbHRlcjtcbiAgfVxuICBzZXQgbWFnRmlsdGVyKHZhbHVlKSB7XG4gICAgdGhpcy5fc3R5bGUubWFnRmlsdGVyID0gdmFsdWU7XG4gIH1cbiAgLyoqIFNwZWNpZmllcyB0aGUgc2FtcGxpbmcgYmVoYXZpb3Igd2hlbiB0aGUgc2FtcGxlIGZvb3RwcmludCBpcyBsYXJnZXIgdGhhbiBvbmUgdGV4ZWwuICovXG4gIGdldCBtaW5GaWx0ZXIoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3N0eWxlLm1pbkZpbHRlcjtcbiAgfVxuICBzZXQgbWluRmlsdGVyKHZhbHVlKSB7XG4gICAgdGhpcy5fc3R5bGUubWluRmlsdGVyID0gdmFsdWU7XG4gIH1cbiAgLyoqIFNwZWNpZmllcyBiZWhhdmlvciBmb3Igc2FtcGxpbmcgYmV0d2VlbiBtaXBtYXAgbGV2ZWxzLiAqL1xuICBnZXQgbWlwbWFwRmlsdGVyKCkge1xuICAgIHJldHVybiB0aGlzLl9zdHlsZS5taXBtYXBGaWx0ZXI7XG4gIH1cbiAgc2V0IG1pcG1hcEZpbHRlcih2YWx1ZSkge1xuICAgIHRoaXMuX3N0eWxlLm1pcG1hcEZpbHRlciA9IHZhbHVlO1xuICB9XG4gIC8qKiBTcGVjaWZpZXMgdGhlIG1pbmltdW0gYW5kIG1heGltdW0gbGV2ZWxzIG9mIGRldGFpbCwgcmVzcGVjdGl2ZWx5LCB1c2VkIGludGVybmFsbHkgd2hlbiBzYW1wbGluZyBhIHRleHR1cmUuICovXG4gIGdldCBsb2RNaW5DbGFtcCgpIHtcbiAgICByZXR1cm4gdGhpcy5fc3R5bGUubG9kTWluQ2xhbXA7XG4gIH1cbiAgc2V0IGxvZE1pbkNsYW1wKHZhbHVlKSB7XG4gICAgdGhpcy5fc3R5bGUubG9kTWluQ2xhbXAgPSB2YWx1ZTtcbiAgfVxuICAvKiogU3BlY2lmaWVzIHRoZSBtaW5pbXVtIGFuZCBtYXhpbXVtIGxldmVscyBvZiBkZXRhaWwsIHJlc3BlY3RpdmVseSwgdXNlZCBpbnRlcm5hbGx5IHdoZW4gc2FtcGxpbmcgYSB0ZXh0dXJlLiAqL1xuICBnZXQgbG9kTWF4Q2xhbXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3N0eWxlLmxvZE1heENsYW1wO1xuICB9XG4gIHNldCBsb2RNYXhDbGFtcCh2YWx1ZSkge1xuICAgIHRoaXMuX3N0eWxlLmxvZE1heENsYW1wID0gdmFsdWU7XG4gIH1cbiAgX29uU3R5bGVDaGFuZ2UoKSB7XG4gICAgdGhpcy5lbWl0KFwic3R5bGVDaGFuZ2VcIiwgdGhpcyk7XG4gIH1cbiAgLyoqIGNhbGwgdGhpcyBpZiB5b3UgaGF2ZSBtb2RpZmllZCB0aGUgdGV4dHVyZSBvdXRzaWRlIG9mIHRoZSBjb25zdHJ1Y3RvciAqL1xuICB1cGRhdGUoKSB7XG4gICAgaWYgKHRoaXMucmVzb3VyY2UpIHtcbiAgICAgIGNvbnN0IHJlc29sdXRpb24gPSB0aGlzLl9yZXNvbHV0aW9uO1xuICAgICAgY29uc3QgZGlkUmVzaXplID0gdGhpcy5yZXNpemUodGhpcy5yZXNvdXJjZVdpZHRoIC8gcmVzb2x1dGlvbiwgdGhpcy5yZXNvdXJjZUhlaWdodCAvIHJlc29sdXRpb24pO1xuICAgICAgaWYgKGRpZFJlc2l6ZSkgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLmVtaXQoXCJ1cGRhdGVcIiwgdGhpcyk7XG4gIH1cbiAgLyoqIERlc3Ryb3lzIHRoaXMgdGV4dHVyZSBzb3VyY2UgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLmRlc3Ryb3llZCA9IHRydWU7XG4gICAgdGhpcy51bmxvYWQoKTtcbiAgICB0aGlzLmVtaXQoXCJkZXN0cm95XCIsIHRoaXMpO1xuICAgIGlmICh0aGlzLl9zdHlsZSkge1xuICAgICAgaWYgKHRoaXMuX293bnNTdHlsZSkgdGhpcy5fc3R5bGUuZGVzdHJveSgpO1xuICAgICAgdGhpcy5fc3R5bGUgPSBudWxsO1xuICAgIH1cbiAgICB0aGlzLnVwbG9hZE1ldGhvZElkID0gbnVsbDtcbiAgICB0aGlzLnJlc291cmNlID0gbnVsbDtcbiAgICB0aGlzLnJlbW92ZUFsbExpc3RlbmVycygpO1xuICB9XG4gIC8qKlxuICAgKiBUaGlzIHdpbGwgdW5sb2FkIHRoZSBUZXh0dXJlIHNvdXJjZSBmcm9tIHRoZSBHUFUuIFRoaXMgd2lsbCBmcmVlIHVwIHRoZSBHUFUgbWVtb3J5XG4gICAqIEFzIHNvb24gYXMgaXQgaXMgcmVxdWlyZWQgZm9yZSByZW5kZXJpbmcsIGl0IHdpbGwgYmUgcmUtdXBsb2FkZWQuXG4gICAqL1xuICB1bmxvYWQoKSB7XG4gICAgdGhpcy5fcmVzb3VyY2VJZCA9IHVpZChcInJlc291cmNlXCIpO1xuICAgIHRoaXMuZW1pdChcImNoYW5nZVwiLCB0aGlzKTtcbiAgICB0aGlzLmVtaXQoXCJ1bmxvYWRcIiwgdGhpcyk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gdGhpcy5fZ3B1RGF0YSkge1xuICAgICAgdGhpcy5fZ3B1RGF0YVtrZXldPy5kZXN0cm95Py4oKTtcbiAgICB9XG4gICAgdGhpcy5fZ3B1RGF0YSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICB9XG4gIC8qKiB0aGUgd2lkdGggb2YgdGhlIHJlc291cmNlLiBUaGlzIGlzIHRoZSBSRUFMIHB1cmUgbnVtYmVyLCBub3QgYWNjb3VudGluZyByZXNvbHV0aW9uICAgKi9cbiAgZ2V0IHJlc291cmNlV2lkdGgoKSB7XG4gICAgY29uc3QgeyByZXNvdXJjZSB9ID0gdGhpcztcbiAgICByZXR1cm4gcmVzb3VyY2UubmF0dXJhbFdpZHRoIHx8IHJlc291cmNlLnZpZGVvV2lkdGggfHwgcmVzb3VyY2UuZGlzcGxheVdpZHRoIHx8IHJlc291cmNlLndpZHRoO1xuICB9XG4gIC8qKiB0aGUgaGVpZ2h0IG9mIHRoZSByZXNvdXJjZS4gVGhpcyBpcyB0aGUgUkVBTCBwdXJlIG51bWJlciwgbm90IGFjY291bnRpbmcgcmVzb2x1dGlvbiAqL1xuICBnZXQgcmVzb3VyY2VIZWlnaHQoKSB7XG4gICAgY29uc3QgeyByZXNvdXJjZSB9ID0gdGhpcztcbiAgICByZXR1cm4gcmVzb3VyY2UubmF0dXJhbEhlaWdodCB8fCByZXNvdXJjZS52aWRlb0hlaWdodCB8fCByZXNvdXJjZS5kaXNwbGF5SGVpZ2h0IHx8IHJlc291cmNlLmhlaWdodDtcbiAgfVxuICAvKipcbiAgICogdGhlIHJlc29sdXRpb24gb2YgdGhlIHRleHR1cmUuIENoYW5naW5nIHRoaXMgbnVtYmVyLCB3aWxsIG5vdCBjaGFuZ2UgdGhlIG51bWJlciBvZiBwaXhlbHMgaW4gdGhlIGFjdHVhbCB0ZXh0dXJlXG4gICAqIGJ1dCB3aWxsIHRoZSBzaXplIG9mIHRoZSB0ZXh0dXJlIHdoZW4gcmVuZGVyZWQuXG4gICAqXG4gICAqIGNoYW5naW5nIHRoZSByZXNvbHV0aW9uIG9mIHRoaXMgdGV4dHVyZSB0byAyIGZvciBleGFtcGxlIHdpbGwgbWFrZSBpdCBhcHBlYXIgdHdpY2UgYXMgc21hbGwgd2hlbiByZW5kZXJlZCAoYXMgcGl4ZWxcbiAgICogZGVuc2l0eSB3aWxsIGhhdmUgaW5jcmVhc2VkKVxuICAgKi9cbiAgZ2V0IHJlc29sdXRpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuX3Jlc29sdXRpb247XG4gIH1cbiAgc2V0IHJlc29sdXRpb24ocmVzb2x1dGlvbikge1xuICAgIGlmICh0aGlzLl9yZXNvbHV0aW9uID09PSByZXNvbHV0aW9uKSByZXR1cm47XG4gICAgdGhpcy5fcmVzb2x1dGlvbiA9IHJlc29sdXRpb247XG4gICAgdGhpcy53aWR0aCA9IHRoaXMucGl4ZWxXaWR0aCAvIHJlc29sdXRpb247XG4gICAgdGhpcy5oZWlnaHQgPSB0aGlzLnBpeGVsSGVpZ2h0IC8gcmVzb2x1dGlvbjtcbiAgfVxuICAvKipcbiAgICogUmVzaXplIHRoZSB0ZXh0dXJlLCB0aGlzIGlzIGhhbmR5IGlmIHlvdSB3YW50IHRvIHVzZSB0aGUgdGV4dHVyZSBhcyBhIHJlbmRlciB0ZXh0dXJlXG4gICAqIEBwYXJhbSB3aWR0aCAtIHRoZSBuZXcgd2lkdGggb2YgdGhlIHRleHR1cmVcbiAgICogQHBhcmFtIGhlaWdodCAtIHRoZSBuZXcgaGVpZ2h0IG9mIHRoZSB0ZXh0dXJlXG4gICAqIEBwYXJhbSByZXNvbHV0aW9uIC0gdGhlIG5ldyByZXNvbHV0aW9uIG9mIHRoZSB0ZXh0dXJlXG4gICAqIEByZXR1cm5zIC0gaWYgdGhlIHRleHR1cmUgd2FzIHJlc2l6ZWRcbiAgICovXG4gIHJlc2l6ZSh3aWR0aCwgaGVpZ2h0LCByZXNvbHV0aW9uKSB7XG4gICAgcmVzb2x1dGlvbiB8fCAocmVzb2x1dGlvbiA9IHRoaXMuX3Jlc29sdXRpb24pO1xuICAgIHdpZHRoIHx8ICh3aWR0aCA9IHRoaXMud2lkdGgpO1xuICAgIGhlaWdodCB8fCAoaGVpZ2h0ID0gdGhpcy5oZWlnaHQpO1xuICAgIGNvbnN0IG5ld1BpeGVsV2lkdGggPSBNYXRoLnJvdW5kKHdpZHRoICogcmVzb2x1dGlvbik7XG4gICAgY29uc3QgbmV3UGl4ZWxIZWlnaHQgPSBNYXRoLnJvdW5kKGhlaWdodCAqIHJlc29sdXRpb24pO1xuICAgIHRoaXMud2lkdGggPSBuZXdQaXhlbFdpZHRoIC8gcmVzb2x1dGlvbjtcbiAgICB0aGlzLmhlaWdodCA9IG5ld1BpeGVsSGVpZ2h0IC8gcmVzb2x1dGlvbjtcbiAgICB0aGlzLl9yZXNvbHV0aW9uID0gcmVzb2x1dGlvbjtcbiAgICBpZiAodGhpcy5waXhlbFdpZHRoID09PSBuZXdQaXhlbFdpZHRoICYmIHRoaXMucGl4ZWxIZWlnaHQgPT09IG5ld1BpeGVsSGVpZ2h0KSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHRoaXMuX3JlZnJlc2hQT1QoKTtcbiAgICB0aGlzLnBpeGVsV2lkdGggPSBuZXdQaXhlbFdpZHRoO1xuICAgIHRoaXMucGl4ZWxIZWlnaHQgPSBuZXdQaXhlbEhlaWdodDtcbiAgICB0aGlzLmVtaXQoXCJyZXNpemVcIiwgdGhpcyk7XG4gICAgdGhpcy5fcmVzb3VyY2VJZCA9IHVpZChcInJlc291cmNlXCIpO1xuICAgIHRoaXMuZW1pdChcImNoYW5nZVwiLCB0aGlzKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICAvKipcbiAgICogTGV0cyB0aGUgcmVuZGVyZXIga25vdyB0aGF0IHRoaXMgdGV4dHVyZSBoYXMgYmVlbiB1cGRhdGVkIGFuZCBpdHMgbWlwbWFwcyBzaG91bGQgYmUgcmUtZ2VuZXJhdGVkLlxuICAgKiBUaGlzIGlzIG9ubHkgaW1wb3J0YW50IGZvciBSZW5kZXJUZXh0dXJlIGluc3RhbmNlcywgYXMgc3RhbmRhcmQgVGV4dHVyZSBpbnN0YW5jZXMgd2lsbCBoYXZlIHRoZWlyXG4gICAqIG1pcG1hcHMgZ2VuZXJhdGVkIG9uIHVwbG9hZC4gWW91IHNob3VsZCBjYWxsIHRoaXMgbWV0aG9kIGFmdGVyIHlvdSBtYWtlIGFueSBjaGFuZ2UgdG8gdGhlIHRleHR1cmVcbiAgICpcbiAgICogVGhlIHJlYXNvbiBmb3IgdGhpcyBpcyBpcyBjYW4gYmUgcXVpdGUgZXhwZW5zaXZlIHRvIHVwZGF0ZSBtaXBtYXBzIGZvciBhIHRleHR1cmUuIFNvIGJ5IGRlZmF1bHQsXG4gICAqIFdlIHdhbnQgeW91LCB0aGUgZGV2ZWxvcGVyIHRvIHNwZWNpZnkgd2hlbiB0aGlzIGFjdGlvbiBzaG91bGQgaGFwcGVuLlxuICAgKlxuICAgKiBHZW5lcmFsbHkgeW91IGRvbid0IHdhbnQgdG8gaGF2ZSBtaXBtYXBzIGdlbmVyYXRlZCBvbiBSZW5kZXIgdGFyZ2V0cyB0aGF0IGFyZSBjaGFuZ2VkIGV2ZXJ5IGZyYW1lLFxuICAgKi9cbiAgdXBkYXRlTWlwbWFwcygpIHtcbiAgICBpZiAodGhpcy5hdXRvR2VuZXJhdGVNaXBtYXBzICYmIHRoaXMubWlwTGV2ZWxDb3VudCA+IDEpIHtcbiAgICAgIHRoaXMuZW1pdChcInVwZGF0ZU1pcG1hcHNcIiwgdGhpcyk7XG4gICAgfVxuICB9XG4gIHNldCB3cmFwTW9kZSh2YWx1ZSkge1xuICAgIHRoaXMuX3N0eWxlLndyYXBNb2RlID0gdmFsdWU7XG4gIH1cbiAgZ2V0IHdyYXBNb2RlKCkge1xuICAgIHJldHVybiB0aGlzLl9zdHlsZS53cmFwTW9kZTtcbiAgfVxuICBzZXQgc2NhbGVNb2RlKHZhbHVlKSB7XG4gICAgdGhpcy5fc3R5bGUuc2NhbGVNb2RlID0gdmFsdWU7XG4gIH1cbiAgLyoqIHNldHRpbmcgdGhpcyB3aWxsIHNldCBtYWdGaWx0ZXIsbWluRmlsdGVyIGFuZCBtaXBtYXBGaWx0ZXIgYWxsIGF0IG9uY2UhICAqL1xuICBnZXQgc2NhbGVNb2RlKCkge1xuICAgIHJldHVybiB0aGlzLl9zdHlsZS5zY2FsZU1vZGU7XG4gIH1cbiAgLyoqXG4gICAqIFJlZnJlc2ggY2hlY2sgZm9yIGlzUG93ZXJPZlR3byB0ZXh0dXJlIGJhc2VkIG9uIHNpemVcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9yZWZyZXNoUE9UKCkge1xuICAgIHRoaXMuaXNQb3dlck9mVHdvID0gaXNQb3cyKHRoaXMucGl4ZWxXaWR0aCkgJiYgaXNQb3cyKHRoaXMucGl4ZWxIZWlnaHQpO1xuICB9XG4gIHN0YXRpYyB0ZXN0KF9yZXNvdXJjZSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIlVuaW1wbGVtZW50ZWRcIik7XG4gIH1cbn07XG4vKiogVGhlIGRlZmF1bHQgb3B0aW9ucyB1c2VkIHdoZW4gY3JlYXRpbmcgYSBuZXcgVGV4dHVyZVNvdXJjZS4gb3ZlcnJpZGUgdGhlc2UgdG8gYWRkIHlvdXIgb3duIGRlZmF1bHRzICovXG5fVGV4dHVyZVNvdXJjZS5kZWZhdWx0T3B0aW9ucyA9IHtcbiAgcmVzb2x1dGlvbjogMSxcbiAgZm9ybWF0OiBcImJncmE4dW5vcm1cIixcbiAgYWxwaGFNb2RlOiBcInByZW11bHRpcGx5LWFscGhhLW9uLXVwbG9hZFwiLFxuICBhcnJheUxheWVyQ291bnQ6IDEsXG4gIG1pcExldmVsQ291bnQ6IDEsXG4gIGF1dG9HZW5lcmF0ZU1pcG1hcHM6IGZhbHNlLFxuICBzYW1wbGVDb3VudDogMSxcbiAgYW50aWFsaWFzOiBmYWxzZSxcbiAgYXV0b0dhcmJhZ2VDb2xsZWN0OiBmYWxzZVxufTtcbmxldCBUZXh0dXJlU291cmNlID0gX1RleHR1cmVTb3VyY2U7XG5mdW5jdGlvbiByZXNvbHZlVmlld0RpbWVuc2lvbihvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zLnZpZXdEaW1lbnNpb24pIHJldHVybiBvcHRpb25zLnZpZXdEaW1lbnNpb247XG4gIGlmIChvcHRpb25zLmRlcHRoKSByZXR1cm4gXCIzZFwiO1xuICByZXR1cm4gb3B0aW9ucy5hcnJheUxheWVyQ291bnQgPiAxID8gXCIyZC1hcnJheVwiIDogXCIyZFwiO1xufVxuZnVuY3Rpb24gdmFsaWRhdGVUZXh0dXJlU2hhcGUob3B0aW9ucywgdmlld0RpbWVuc2lvbiwgZGltZW5zaW9uKSB7XG4gIGlmIChvcHRpb25zLmRlcHRoICE9PSB2b2lkIDAgJiYgdHlwZW9mIG9wdGlvbnMuZGVwdGggIT09IFwibnVtYmVyXCIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYFtUZXh0dXJlU291cmNlXSBkZXB0aCBpcyBhIDNEIHRleHR1cmUncyBkZXB0aCBpbiB0ZXhlbHMsIGJ1dCBnb3QgJHtvcHRpb25zLmRlcHRofS4gRm9yIGEgZGVwdGggYnVmZmVyLCB1c2UgdGhlIGRlcHRoIG9wdGlvbiBvZiBhIFJlbmRlclRhcmdldCBvciB0aGUgcmVuZGVyZXIuYCk7XG4gIH1cbiAgaWYgKG9wdGlvbnMuZGVwdGggJiYgb3B0aW9ucy5hcnJheUxheWVyQ291bnQgPiAxKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiW1RleHR1cmVTb3VyY2VdIGRlcHRoIGFuZCBhcnJheUxheWVyQ291bnQgY2FuJ3QgYmUgY29tYmluZWQ6IHVzZSBkZXB0aCBmb3IgYSAzRCB0ZXh0dXJlIG9yIGFycmF5TGF5ZXJDb3VudCBmb3IgYSAyRCBhcnJheS5cIik7XG4gIH1cbiAgaWYgKG9wdGlvbnMuZGVwdGggJiYgdmlld0RpbWVuc2lvbiAhPT0gXCIzZFwiKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBbVGV4dHVyZVNvdXJjZV0gZGVwdGggbWFrZXMgYSAzRCB0ZXh0dXJlLCBidXQgdmlld0RpbWVuc2lvbiBpcyAnJHt2aWV3RGltZW5zaW9ufScuIFVzZSBhcnJheUxheWVyQ291bnQgZm9yIGxheWVyZWQgdGV4dHVyZXMuYCk7XG4gIH1cbiAgaWYgKHZpZXdEaW1lbnNpb24gPT09IFwiM2RcIiAmJiBvcHRpb25zLmFycmF5TGF5ZXJDb3VudCA+IDEpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJbVGV4dHVyZVNvdXJjZV0gYSAzRCB0ZXh0dXJlIHRha2VzIGRlcHRoLCBub3QgYXJyYXlMYXllckNvdW50LlwiKTtcbiAgfVxuICBpZiAob3B0aW9ucy5kaW1lbnNpb25zICYmIG9wdGlvbnMuZGltZW5zaW9ucyAhPT0gZGltZW5zaW9uKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBbVGV4dHVyZVNvdXJjZV0gZGltZW5zaW9ucyAnJHtvcHRpb25zLmRpbWVuc2lvbnN9JyBkb2Vzbid0IG1hdGNoIHZpZXdEaW1lbnNpb24gJyR7dmlld0RpbWVuc2lvbn0nLiBMZWF2ZSBkaW1lbnNpb25zIG91dDsgaXQgaXMgZGVyaXZlZCBmcm9tIHRoZSB2aWV3LmApO1xuICB9IGVsc2UgaWYgKG9wdGlvbnMuZGltZW5zaW9ucykge1xuICAgIGRlcHJlY2F0aW9uKHY4XzIyXzAsIFwiVGV4dHVyZVNvdXJjZSBkaW1lbnNpb25zIGlzIGRlcml2ZWQgZnJvbSB2aWV3RGltZW5zaW9uIGFuZCBkZXB0aDsgbGVhdmUgaXQgb3V0LlwiKTtcbiAgfVxuICBpZiAoZGltZW5zaW9uID09PSBcIjNkXCIgJiYgb3B0aW9ucy5hbnRpYWxpYXMpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJbVGV4dHVyZVNvdXJjZV0gYSAzRCB0ZXh0dXJlIGNhbid0IGJlIGFudGlhbGlhc2VkOiBXZWJHUFUgaGFzIG5vIG11bHRpc2FtcGxlZCAzRCB0ZXh0dXJlcy5cIik7XG4gIH1cbn1cblxuZXhwb3J0IHsgVGV4dHVyZVNvdXJjZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9VGV4dHVyZVNvdXJjZS5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBpc0ludGVnZXJGb3JtYXQgfSBmcm9tICcuLi91dGlscy9pc0ludGVnZXJGb3JtYXQubWpzJztcbmltcG9ydCB7IFRleHR1cmVTb3VyY2UgfSBmcm9tICcuL1RleHR1cmVTb3VyY2UubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBCdWZmZXJJbWFnZVNvdXJjZSBleHRlbmRzIFRleHR1cmVTb3VyY2Uge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgY29uc3QgZGVwdGhPckFycmF5TGF5ZXJzID0gb3B0aW9ucy5kZXB0aCA/PyBvcHRpb25zLmFycmF5TGF5ZXJDb3VudCA/PyAxO1xuICAgIGNvbnN0IGJ1ZmZlciA9IG9wdGlvbnMucmVzb3VyY2UgfHwgbmV3IEZsb2F0MzJBcnJheShvcHRpb25zLndpZHRoICogb3B0aW9ucy5oZWlnaHQgKiBkZXB0aE9yQXJyYXlMYXllcnMgKiA0KTtcbiAgICBsZXQgZm9ybWF0ID0gb3B0aW9ucy5mb3JtYXQ7XG4gICAgaWYgKCFmb3JtYXQpIHtcbiAgICAgIGlmIChidWZmZXIgaW5zdGFuY2VvZiBGbG9hdDMyQXJyYXkpIHtcbiAgICAgICAgZm9ybWF0ID0gXCJyZ2JhMzJmbG9hdFwiO1xuICAgICAgfSBlbHNlIGlmIChidWZmZXIgaW5zdGFuY2VvZiBJbnQzMkFycmF5KSB7XG4gICAgICAgIGZvcm1hdCA9IFwicmdiYTMydWludFwiO1xuICAgICAgfSBlbHNlIGlmIChidWZmZXIgaW5zdGFuY2VvZiBVaW50MzJBcnJheSkge1xuICAgICAgICBmb3JtYXQgPSBcInJnYmEzMnVpbnRcIjtcbiAgICAgIH0gZWxzZSBpZiAoYnVmZmVyIGluc3RhbmNlb2YgSW50MTZBcnJheSkge1xuICAgICAgICBmb3JtYXQgPSBcInJnYmExNnVpbnRcIjtcbiAgICAgIH0gZWxzZSBpZiAoYnVmZmVyIGluc3RhbmNlb2YgVWludDE2QXJyYXkpIHtcbiAgICAgICAgZm9ybWF0ID0gXCJyZ2JhMTZ1aW50XCI7XG4gICAgICB9IGVsc2UgaWYgKGJ1ZmZlciBpbnN0YW5jZW9mIEludDhBcnJheSkge1xuICAgICAgICBmb3JtYXQgPSBcImJncmE4dW5vcm1cIjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZvcm1hdCA9IFwiYmdyYTh1bm9ybVwiO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBub1ByZW11bHRpcGx5ID0gaXNJbnRlZ2VyRm9ybWF0KGZvcm1hdCkgfHwgZGVwdGhPckFycmF5TGF5ZXJzID4gMTtcbiAgICBzdXBlcih7XG4gICAgICAuLi5ub1ByZW11bHRpcGx5ICYmIHsgYWxwaGFNb2RlOiBcIm5vLXByZW11bHRpcGx5LWFscGhhXCIgfSxcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICByZXNvdXJjZTogYnVmZmVyLFxuICAgICAgZm9ybWF0XG4gICAgfSk7XG4gICAgdGhpcy51cGxvYWRNZXRob2RJZCA9IFwiYnVmZmVyXCI7XG4gICAgLyoqXG4gICAgICogRmlyc3QgdGV4ZWwgb2YgdGhlIHJhbmdlIGJlaW5nIHVwbG9hZGVkIGJ5IHRoZSBjdXJyZW50IHtAbGluayBCdWZmZXJJbWFnZVNvdXJjZSN1cGRhdGV9IGNhbGwuXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fdXBkYXRlU3RhcnQgPSAwO1xuICAgIC8qKlxuICAgICAqIE9uZSBwYXN0IHRoZSBsYXN0IHRleGVsIG9mIHRoZSByYW5nZSBiZWluZyB1cGxvYWRlZCBieSB0aGUgY3VycmVudFxuICAgICAqIHtAbGluayBCdWZmZXJJbWFnZVNvdXJjZSN1cGRhdGV9IGNhbGwuIGBJbmZpbml0eWAgbWVhbnMgdGhlIHdob2xlIHRleHR1cmUuXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fdXBkYXRlRW5kID0gSW5maW5pdHk7XG4gIH1cbiAgLyoqXG4gICAqIFVwbG9hZHMgdGhlIGJ1ZmZlciB0byB0aGUgR1BVLiBDYWxsIHRoaXMgYWZ0ZXIgY2hhbmdpbmcgdGhlIGRhdGEgaW4ge0BsaW5rIFRleHR1cmVTb3VyY2UjcmVzb3VyY2V9LlxuICAgKlxuICAgKiBUaGUgYnVmZmVyIGlzIGEgZmxhdCBsaXN0IG9mIHRleGVscyBpbiByb3ctbWFqb3Igb3JkZXIsIHNvIHRleGVsIGBpYCBzaXRzIGF0XG4gICAqIGB4ID0gaSAlIHdpZHRoYCwgYHkgPSBmbG9vcihpIC8gd2lkdGgpYC4gUGFzcyBhIHRleGVsIHJhbmdlIHRvIHVwbG9hZCBvbmx5IHRoYXQgcGFydCBvZlxuICAgKiB0aGUgdGV4dHVyZTsgbGVhdmUgaXQgb3V0IHRvIHVwbG9hZCBldmVyeXRoaW5nLlxuICAgKlxuICAgKiBUaGUgdXBsb2FkIGhhcHBlbnMgaW1tZWRpYXRlbHkgZm9yIGV2ZXJ5IHJlbmRlcmVyIHRoYXQgYWxyZWFkeSBob2xkcyB0aGUgdGV4dHVyZSwgYW5kIHRoZVxuICAgKiByYW5nZSBhcHBsaWVzIHRvIHRoaXMgY2FsbCBvbmx5LiBJZiB5b3UgY2hhbmdlIHNldmVyYWwgcGFydHMgb2YgdGhlIGJ1ZmZlciwgdHJhY2sgdGhlIGRpcnR5XG4gICAqIHNwYW4geW91cnNlbGYgYW5kIGNhbGwgYHVwZGF0ZWAgb25jZSB3aXRoIHRoZSBjb21iaW5lZCByYW5nZS4gRWFjaCBjYWxsIGhhcyBhIGZpeGVkIGNvc3Qgb25cbiAgICogdG9wIG9mIHRoZSBieXRlcyBpdCBtb3Zlcywgd2hpY2ggcmVhY2hlcyB0ZW5zIG9mIG1pY3Jvc2Vjb25kcyBvbiBzb21lIG1vYmlsZSBHUFVzLiBPbmUgc3BhblxuICAgKiB1c3VhbGx5IGJlYXRzIG1hbnkgc21hbGwgY2FsbHMuXG4gICAqXG4gICAqIFBhcnRpYWwgdXBsb2FkcyBhc3N1bWUgdGhlIGJ1ZmZlciBob2xkcyBleGFjdGx5IGB3aWR0aCAqIGhlaWdodGAgdGV4ZWxzLiBBIDNEIHRleHR1cmUgb3IgMkQgYXJyYXlcbiAgICogYWx3YXlzIHVwbG9hZHMgd2hvbGUsIHNvIGl0IHRha2VzIG5vIHJhbmdlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBkYXRhID0gbmV3IEZsb2F0MzJBcnJheSg0MDk2ICogNjQgKiA0KTtcbiAgICogY29uc3Qgc291cmNlID0gbmV3IEJ1ZmZlckltYWdlU291cmNlKHsgcmVzb3VyY2U6IGRhdGEsIHdpZHRoOiA0MDk2LCBoZWlnaHQ6IDY0IH0pO1xuICAgKlxuICAgKiAvLyBjaGFuZ2UgdGV4ZWxzIDEwMCB0byAxMTUgKDQgZmxvYXRzIHBlciByZ2JhMzJmbG9hdCB0ZXhlbClcbiAgICogZGF0YS5maWxsKDEsIDEwMCAqIDQsIDExNiAqIDQpO1xuICAgKlxuICAgKiAvLyB1cGxvYWQgb25seSB0aG9zZSAxNiB0ZXhlbHNcbiAgICogc291cmNlLnVwZGF0ZSgxMDAsIDExNik7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gc3RhcnQgLSBpbmRleCBvZiB0aGUgZmlyc3QgdGV4ZWwgdG8gdXBsb2FkXG4gICAqIEBwYXJhbSBlbmQgLSBpbmRleCBvbmUgcGFzdCB0aGUgbGFzdCB0ZXhlbCB0byB1cGxvYWQgKGV4Y2x1c2l2ZSwgbGlrZSBgVHlwZWRBcnJheS5zdWJhcnJheWApXG4gICAqL1xuICB1cGRhdGUoc3RhcnQgPSAwLCBlbmQgPSBJbmZpbml0eSkge1xuICAgIGlmICgoc3RhcnQgPiAwIHx8IGVuZCA8IEluZmluaXR5KSAmJiB0aGlzLmRlcHRoT3JBcnJheUxheWVycyA+IDEpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIltCdWZmZXJJbWFnZVNvdXJjZV0gYSAzRCB0ZXh0dXJlIG9yIDJEIGFycmF5IHVwbG9hZHMgd2hvbGU6IGNhbGwgdXBkYXRlKCkgd2l0aCBubyByYW5nZS5cIik7XG4gICAgfVxuICAgIHRoaXMuX3VwZGF0ZVN0YXJ0ID0gc3RhcnQ7XG4gICAgdGhpcy5fdXBkYXRlRW5kID0gZW5kO1xuICAgIHN1cGVyLnVwZGF0ZSgpO1xuICAgIHRoaXMuX3VwZGF0ZVN0YXJ0ID0gMDtcbiAgICB0aGlzLl91cGRhdGVFbmQgPSBJbmZpbml0eTtcbiAgfVxuICBzdGF0aWMgdGVzdChyZXNvdXJjZSkge1xuICAgIHJldHVybiByZXNvdXJjZSBpbnN0YW5jZW9mIEludDhBcnJheSB8fCByZXNvdXJjZSBpbnN0YW5jZW9mIFVpbnQ4QXJyYXkgfHwgcmVzb3VyY2UgaW5zdGFuY2VvZiBVaW50OENsYW1wZWRBcnJheSB8fCByZXNvdXJjZSBpbnN0YW5jZW9mIEludDE2QXJyYXkgfHwgcmVzb3VyY2UgaW5zdGFuY2VvZiBVaW50MTZBcnJheSB8fCByZXNvdXJjZSBpbnN0YW5jZW9mIEludDMyQXJyYXkgfHwgcmVzb3VyY2UgaW5zdGFuY2VvZiBVaW50MzJBcnJheSB8fCByZXNvdXJjZSBpbnN0YW5jZW9mIEZsb2F0MzJBcnJheTtcbiAgfVxufVxuQnVmZmVySW1hZ2VTb3VyY2UuZXh0ZW5zaW9uID0gRXh0ZW5zaW9uVHlwZS5UZXh0dXJlU291cmNlO1xuXG5leHBvcnQgeyBCdWZmZXJJbWFnZVNvdXJjZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QnVmZmVySW1hZ2VTb3VyY2UubWpzLm1hcFxuIiwiaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IHRlbXBNYXQgPSBuZXcgTWF0cml4KCk7XG5jbGFzcyBUZXh0dXJlTWF0cml4IHtcbiAgLyoqXG4gICAqIEBwYXJhbSB0ZXh0dXJlIC0gb2JzZXJ2ZWQgdGV4dHVyZVxuICAgKiBAcGFyYW0gY2xhbXBNYXJnaW4gLSBDaGFuZ2VzIGZyYW1lIGNsYW1waW5nLCAwLjUgYnkgZGVmYXVsdC4gVXNlIC0wLjUgZm9yIGV4dHJhIGJvcmRlci5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHRleHR1cmUsIGNsYW1wTWFyZ2luKSB7XG4gICAgdGhpcy5tYXBDb29yZCA9IG5ldyBNYXRyaXgoKTtcbiAgICB0aGlzLnVDbGFtcEZyYW1lID0gbmV3IEZsb2F0MzJBcnJheSg0KTtcbiAgICB0aGlzLnVDbGFtcE9mZnNldCA9IG5ldyBGbG9hdDMyQXJyYXkoMik7XG4gICAgdGhpcy5fdXBkYXRlSUQgPSAwO1xuICAgIHRoaXMuY2xhbXBPZmZzZXQgPSAwO1xuICAgIGlmICh0eXBlb2YgY2xhbXBNYXJnaW4gPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHRoaXMuY2xhbXBNYXJnaW4gPSB0ZXh0dXJlLndpZHRoIDwgMTAgPyAwIDogMC41O1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmNsYW1wTWFyZ2luID0gY2xhbXBNYXJnaW47XG4gICAgfVxuICAgIHRoaXMuaXNTaW1wbGUgPSBmYWxzZTtcbiAgICB0aGlzLnRleHR1cmUgPSB0ZXh0dXJlO1xuICB9XG4gIC8qKiBUZXh0dXJlIHByb3BlcnR5LiAqL1xuICBnZXQgdGV4dHVyZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fdGV4dHVyZTtcbiAgfVxuICBzZXQgdGV4dHVyZSh2YWx1ZSkge1xuICAgIGlmICh0aGlzLl90ZXh0dXJlICE9PSB2YWx1ZSkge1xuICAgICAgdGhpcy5fdGV4dHVyZT8ucmVtb3ZlTGlzdGVuZXIoXCJ1cGRhdGVcIiwgdGhpcy51cGRhdGUsIHRoaXMpO1xuICAgICAgdGhpcy5fdGV4dHVyZSA9IHZhbHVlO1xuICAgICAgdGhpcy5fdGV4dHVyZS5hZGRMaXN0ZW5lcihcInVwZGF0ZVwiLCB0aGlzLnVwZGF0ZSwgdGhpcyk7XG4gICAgfVxuICAgIHRoaXMudXBkYXRlKCk7XG4gIH1cbiAgLyoqIFJlbGVhc2VzIHRoZSBvYnNlcnZlZCB0ZXh0dXJlLCByZW1vdmluZyB0aGUgYHVwZGF0ZWAgbGlzdGVuZXIgZnJvbSBpdC4gKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLl90ZXh0dXJlPy5yZW1vdmVMaXN0ZW5lcihcInVwZGF0ZVwiLCB0aGlzLnVwZGF0ZSwgdGhpcyk7XG4gICAgdGhpcy5fdGV4dHVyZSA9IG51bGw7XG4gIH1cbiAgLyoqXG4gICAqIE11bHRpcGxpZXMgdXZzIGFycmF5IHRvIHRyYW5zZm9ybVxuICAgKiBAcGFyYW0gdXZzIC0gbWVzaCB1dnNcbiAgICogQHBhcmFtIFtvdXQ9dXZzXSAtIG91dHB1dFxuICAgKiBAcmV0dXJucyAtIG91dHB1dFxuICAgKi9cbiAgbXVsdGlwbHlVdnModXZzLCBvdXQpIHtcbiAgICBpZiAob3V0ID09PSB2b2lkIDApIHtcbiAgICAgIG91dCA9IHV2cztcbiAgICB9XG4gICAgY29uc3QgbWF0ID0gdGhpcy5tYXBDb29yZDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHV2cy5sZW5ndGg7IGkgKz0gMikge1xuICAgICAgY29uc3QgeCA9IHV2c1tpXTtcbiAgICAgIGNvbnN0IHkgPSB1dnNbaSArIDFdO1xuICAgICAgb3V0W2ldID0geCAqIG1hdC5hICsgeSAqIG1hdC5jICsgbWF0LnR4O1xuICAgICAgb3V0W2kgKyAxXSA9IHggKiBtYXQuYiArIHkgKiBtYXQuZCArIG1hdC50eTtcbiAgICB9XG4gICAgcmV0dXJuIG91dDtcbiAgfVxuICAvKipcbiAgICogVXBkYXRlcyBtYXRyaWNlcyBpZiB0ZXh0dXJlIHdhcyBjaGFuZ2VkXG4gICAqIEByZXR1cm5zIC0gd2hldGhlciBvciBub3QgaXQgd2FzIHVwZGF0ZWRcbiAgICovXG4gIHVwZGF0ZSgpIHtcbiAgICBjb25zdCB0ZXggPSB0aGlzLl90ZXh0dXJlO1xuICAgIHRoaXMuX3VwZGF0ZUlEKys7XG4gICAgY29uc3QgdXZzID0gdGV4LnV2cztcbiAgICB0aGlzLm1hcENvb3JkLnNldCh1dnMueDEgLSB1dnMueDAsIHV2cy55MSAtIHV2cy55MCwgdXZzLngzIC0gdXZzLngwLCB1dnMueTMgLSB1dnMueTAsIHV2cy54MCwgdXZzLnkwKTtcbiAgICBjb25zdCBvcmlnID0gdGV4Lm9yaWc7XG4gICAgY29uc3QgdHJpbSA9IHRleC50cmltO1xuICAgIGlmICh0cmltKSB7XG4gICAgICB0ZW1wTWF0LnNldChcbiAgICAgICAgb3JpZy53aWR0aCAvIHRyaW0ud2lkdGgsXG4gICAgICAgIDAsXG4gICAgICAgIDAsXG4gICAgICAgIG9yaWcuaGVpZ2h0IC8gdHJpbS5oZWlnaHQsXG4gICAgICAgIC10cmltLnggLyB0cmltLndpZHRoLFxuICAgICAgICAtdHJpbS55IC8gdHJpbS5oZWlnaHRcbiAgICAgICk7XG4gICAgICB0aGlzLm1hcENvb3JkLmFwcGVuZCh0ZW1wTWF0KTtcbiAgICB9XG4gICAgY29uc3QgdGV4QmFzZSA9IHRleC5zb3VyY2U7XG4gICAgY29uc3QgZnJhbWUgPSB0aGlzLnVDbGFtcEZyYW1lO1xuICAgIGNvbnN0IG1hcmdpbiA9IHRoaXMuY2xhbXBNYXJnaW4gLyB0ZXhCYXNlLl9yZXNvbHV0aW9uO1xuICAgIGNvbnN0IG9mZnNldCA9IHRoaXMuY2xhbXBPZmZzZXQgLyB0ZXhCYXNlLl9yZXNvbHV0aW9uO1xuICAgIGZyYW1lWzBdID0gKHRleC5mcmFtZS54ICsgbWFyZ2luICsgb2Zmc2V0KSAvIHRleEJhc2Uud2lkdGg7XG4gICAgZnJhbWVbMV0gPSAodGV4LmZyYW1lLnkgKyBtYXJnaW4gKyBvZmZzZXQpIC8gdGV4QmFzZS5oZWlnaHQ7XG4gICAgZnJhbWVbMl0gPSAodGV4LmZyYW1lLnggKyB0ZXguZnJhbWUud2lkdGggLSBtYXJnaW4gKyBvZmZzZXQpIC8gdGV4QmFzZS53aWR0aDtcbiAgICBmcmFtZVszXSA9ICh0ZXguZnJhbWUueSArIHRleC5mcmFtZS5oZWlnaHQgLSBtYXJnaW4gKyBvZmZzZXQpIC8gdGV4QmFzZS5oZWlnaHQ7XG4gICAgdGhpcy51Q2xhbXBPZmZzZXRbMF0gPSB0aGlzLmNsYW1wT2Zmc2V0IC8gdGV4QmFzZS5waXhlbFdpZHRoO1xuICAgIHRoaXMudUNsYW1wT2Zmc2V0WzFdID0gdGhpcy5jbGFtcE9mZnNldCAvIHRleEJhc2UucGl4ZWxIZWlnaHQ7XG4gICAgdGhpcy5pc1NpbXBsZSA9IHRleC5mcmFtZS53aWR0aCA9PT0gdGV4QmFzZS53aWR0aCAmJiB0ZXguZnJhbWUuaGVpZ2h0ID09PSB0ZXhCYXNlLmhlaWdodCAmJiB0ZXgucm90YXRlID09PSAwO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59XG5cbmV4cG9ydCB7IFRleHR1cmVNYXRyaXggfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVRleHR1cmVNYXRyaXgubWpzLm1hcFxuIiwiaW1wb3J0IEV2ZW50RW1pdHRlciBmcm9tICdldmVudGVtaXR0ZXIzJztcbmltcG9ydCB7IGdyb3VwRDggfSBmcm9tICcuLi8uLi8uLi8uLi9tYXRocy9tYXRyaXgvZ3JvdXBEOC5tanMnO1xuaW1wb3J0IHsgUmVjdGFuZ2xlIH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvc2hhcGVzL1JlY3RhbmdsZS5tanMnO1xuaW1wb3J0IHsgdWlkIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvZGF0YS91aWQubWpzJztcbmltcG9ydCB7IGRlcHJlY2F0aW9uLCB2OF8wXzAgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9sb2dnaW5nL2RlcHJlY2F0aW9uLm1qcyc7XG5pbXBvcnQgeyBOT09QIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvbWlzYy9OT09QLm1qcyc7XG5pbXBvcnQgeyBCdWZmZXJJbWFnZVNvdXJjZSB9IGZyb20gJy4vc291cmNlcy9CdWZmZXJJbWFnZVNvdXJjZS5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVNvdXJjZSB9IGZyb20gJy4vc291cmNlcy9UZXh0dXJlU291cmNlLm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlTWF0cml4IH0gZnJvbSAnLi9UZXh0dXJlTWF0cml4Lm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgVGV4dHVyZSBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIC8qKlxuICAgKiBAcGFyYW0ge1RleHR1cmVPcHRpb25zfSBvcHRpb25zIC0gT3B0aW9ucyBmb3IgdGhlIHRleHR1cmVcbiAgICovXG4gIGNvbnN0cnVjdG9yKHtcbiAgICBzb3VyY2UsXG4gICAgbGFiZWwsXG4gICAgZnJhbWUsXG4gICAgb3JpZyxcbiAgICB0cmltLFxuICAgIGRlZmF1bHRBbmNob3IsXG4gICAgZGVmYXVsdEJvcmRlcnMsXG4gICAgcm90YXRlLFxuICAgIGR5bmFtaWNcbiAgfSA9IHt9KSB7XG4gICAgc3VwZXIoKTtcbiAgICAvKiogdW5pcXVlIGlkIGZvciB0aGlzIHRleHR1cmUgKi9cbiAgICB0aGlzLnVpZCA9IHVpZChcInRleHR1cmVcIik7XG4gICAgLyoqIEEgdXZzIG9iamVjdCBiYXNlZCBvbiB0aGUgZ2l2ZW4gZnJhbWUgYW5kIHRoZSB0ZXh0dXJlIHNvdXJjZSAqL1xuICAgIHRoaXMudXZzID0geyB4MDogMCwgeTA6IDAsIHgxOiAwLCB5MTogMCwgeDI6IDAsIHkyOiAwLCB4MzogMCwgeTM6IDAgfTtcbiAgICAvKipcbiAgICAgKiBUaGlzIGlzIHRoZSBhcmVhIG9mIHRoZSBCYXNlVGV4dHVyZSBpbWFnZSB0byBhY3R1YWxseSBjb3B5IHRvIHRoZSBDYW52YXMgLyBXZWJHTCB3aGVuIHJlbmRlcmluZyxcbiAgICAgKiBpcnJlc3BlY3RpdmUgb2YgdGhlIGFjdHVhbCBmcmFtZSBzaXplIG9yIHBsYWNlbWVudCAod2hpY2ggY2FuIGJlIGluZmx1ZW5jZWQgYnkgdHJpbW1lZCB0ZXh0dXJlIGF0bGFzZXMpXG4gICAgICovXG4gICAgdGhpcy5mcmFtZSA9IG5ldyBSZWN0YW5nbGUoKTtcbiAgICAvKipcbiAgICAgKiBEb2VzIHRoaXMgVGV4dHVyZSBoYXZlIGFueSBmcmFtZSBkYXRhIGFzc2lnbmVkIHRvIGl0P1xuICAgICAqXG4gICAgICogVGhpcyBtb2RlIGlzIGVuYWJsZWQgYXV0b21hdGljYWxseSBpZiBubyBmcmFtZSB3YXMgcGFzc2VkIGluc2lkZSBjb25zdHJ1Y3Rvci5cbiAgICAgKlxuICAgICAqIEluIHRoaXMgbW9kZSB0ZXh0dXJlIGlzIHN1YnNjcmliZWQgdG8gYmFzZVRleHR1cmUgZXZlbnRzLCBhbmQgZmlyZXMgYHVwZGF0ZWAgb24gYW55IGNoYW5nZS5cbiAgICAgKlxuICAgICAqIEJld2FyZSwgYWZ0ZXIgbG9hZGluZyBvciByZXNpemUgb2YgYmFzZVRleHR1cmUgZXZlbnQgY2FuIGZpcmVkIHR3byB0aW1lcyFcbiAgICAgKiBJZiB5b3Ugd2FudCBtb3JlIGNvbnRyb2wsIHN1YnNjcmliZSBvbiBiYXNlVGV4dHVyZSBpdHNlbGYuXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiB0ZXh0dXJlLm9uKCd1cGRhdGUnLCAoKSA9PiB7fSk7XG4gICAgICovXG4gICAgdGhpcy5ub0ZyYW1lID0gZmFsc2U7XG4gICAgLyoqXG4gICAgICogU2V0IHRvIHRydWUgaWYgeW91IHBsYW4gb24gbW9kaWZ5aW5nIHRoZSB1dnMgb2YgdGhpcyB0ZXh0dXJlLlxuICAgICAqIFdoZW4gdGhpcyBpcyB0aGUgY2FzZSwgc3ByaXRlcyBhbmQgb3RoZXIgb2JqZWN0cyB1c2luZyB0aGUgdGV4dHVyZSB3aWxsXG4gICAgICogbWFrZSBzdXJlIHRvIGxpc3RlbiBmb3IgY2hhbmdlcyB0byB0aGUgdXZzIGFuZCB1cGRhdGUgdGhlaXIgdmVydGljZXMgYWNjb3JkaW5nbHkuXG4gICAgICovXG4gICAgdGhpcy5keW5hbWljID0gZmFsc2U7XG4gICAgLyoqIGlzIGl0IGEgdGV4dHVyZT8geWVzISB1c2VkIGZvciB0eXBlIGNoZWNraW5nICovXG4gICAgdGhpcy5pc1RleHR1cmUgPSB0cnVlO1xuICAgIHRoaXMubGFiZWwgPSBsYWJlbDtcbiAgICB0aGlzLnNvdXJjZSA9IHNvdXJjZT8uc291cmNlID8/IG5ldyBUZXh0dXJlU291cmNlKCk7XG4gICAgdGhpcy5ub0ZyYW1lID0gIWZyYW1lO1xuICAgIGlmIChmcmFtZSkge1xuICAgICAgdGhpcy5mcmFtZS5jb3B5RnJvbShmcmFtZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHsgd2lkdGgsIGhlaWdodCB9ID0gdGhpcy5fc291cmNlO1xuICAgICAgdGhpcy5mcmFtZS53aWR0aCA9IHdpZHRoO1xuICAgICAgdGhpcy5mcmFtZS5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgfVxuICAgIHRoaXMub3JpZyA9IG9yaWcgfHwgdGhpcy5mcmFtZTtcbiAgICB0aGlzLnRyaW0gPSB0cmltO1xuICAgIHRoaXMucm90YXRlID0gcm90YXRlID8/IDA7XG4gICAgdGhpcy5kZWZhdWx0QW5jaG9yID0gZGVmYXVsdEFuY2hvcjtcbiAgICB0aGlzLmRlZmF1bHRCb3JkZXJzID0gZGVmYXVsdEJvcmRlcnM7XG4gICAgdGhpcy5kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICB0aGlzLmR5bmFtaWMgPSBkeW5hbWljIHx8IGZhbHNlO1xuICAgIHRoaXMudXBkYXRlVXZzKCk7XG4gIH1cbiAgc2V0IHNvdXJjZSh2YWx1ZSkge1xuICAgIGlmICh0aGlzLl9zb3VyY2UpIHtcbiAgICAgIHRoaXMuX3NvdXJjZS5vZmYoXCJyZXNpemVcIiwgdGhpcy51cGRhdGUsIHRoaXMpO1xuICAgIH1cbiAgICB0aGlzLl9zb3VyY2UgPSB2YWx1ZTtcbiAgICB2YWx1ZS5vbihcInJlc2l6ZVwiLCB0aGlzLnVwZGF0ZSwgdGhpcyk7XG4gICAgdGhpcy5lbWl0KFwidXBkYXRlXCIsIHRoaXMpO1xuICB9XG4gIC8qKiB0aGUgdW5kZXJseWluZyBzb3VyY2Ugb2YgdGhlIHRleHR1cmUgKGVxdWl2YWxlbnQgb2YgYmFzZVRleHR1cmUgaW4gdjcpICovXG4gIGdldCBzb3VyY2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NvdXJjZTtcbiAgfVxuICAvKiogcmV0dXJucyBhIFRleHR1cmVNYXRyaXggaW5zdGFuY2UgZm9yIHRoaXMgdGV4dHVyZS4gQnkgZGVmYXVsdCwgdGhhdCBvYmplY3QgaXMgbm90IGNyZWF0ZWQgYmVjYXVzZSBpdHMgaGVhdnkuICovXG4gIGdldCB0ZXh0dXJlTWF0cml4KCkge1xuICAgIGlmICghdGhpcy5fdGV4dHVyZU1hdHJpeCkge1xuICAgICAgdGhpcy5fdGV4dHVyZU1hdHJpeCA9IG5ldyBUZXh0dXJlTWF0cml4KHRoaXMpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fdGV4dHVyZU1hdHJpeDtcbiAgfVxuICAvKiogVGhlIHdpZHRoIG9mIHRoZSBUZXh0dXJlIGluIHBpeGVscy4gKi9cbiAgZ2V0IHdpZHRoKCkge1xuICAgIHJldHVybiB0aGlzLm9yaWcud2lkdGg7XG4gIH1cbiAgLyoqIFRoZSBoZWlnaHQgb2YgdGhlIFRleHR1cmUgaW4gcGl4ZWxzLiAqL1xuICBnZXQgaGVpZ2h0KCkge1xuICAgIHJldHVybiB0aGlzLm9yaWcuaGVpZ2h0O1xuICB9XG4gIC8qKiBDYWxsIHRoaXMgZnVuY3Rpb24gd2hlbiB5b3UgaGF2ZSBtb2RpZmllZCB0aGUgZnJhbWUgb2YgdGhpcyB0ZXh0dXJlLiAqL1xuICB1cGRhdGVVdnMoKSB7XG4gICAgY29uc3QgeyB1dnMsIGZyYW1lIH0gPSB0aGlzO1xuICAgIGNvbnN0IHsgd2lkdGgsIGhlaWdodCB9ID0gdGhpcy5fc291cmNlO1xuICAgIGNvbnN0IG5YID0gZnJhbWUueCAvIHdpZHRoO1xuICAgIGNvbnN0IG5ZID0gZnJhbWUueSAvIGhlaWdodDtcbiAgICBjb25zdCBuVyA9IGZyYW1lLndpZHRoIC8gd2lkdGg7XG4gICAgY29uc3QgbkggPSBmcmFtZS5oZWlnaHQgLyBoZWlnaHQ7XG4gICAgbGV0IHJvdGF0ZSA9IHRoaXMucm90YXRlO1xuICAgIGlmIChyb3RhdGUpIHtcbiAgICAgIGNvbnN0IHcyID0gblcgLyAyO1xuICAgICAgY29uc3QgaDIgPSBuSCAvIDI7XG4gICAgICBjb25zdCBjWCA9IG5YICsgdzI7XG4gICAgICBjb25zdCBjWSA9IG5ZICsgaDI7XG4gICAgICByb3RhdGUgPSBncm91cEQ4LmFkZChyb3RhdGUsIGdyb3VwRDguTlcpO1xuICAgICAgdXZzLngwID0gY1ggKyB3MiAqIGdyb3VwRDgudVgocm90YXRlKTtcbiAgICAgIHV2cy55MCA9IGNZICsgaDIgKiBncm91cEQ4LnVZKHJvdGF0ZSk7XG4gICAgICByb3RhdGUgPSBncm91cEQ4LmFkZChyb3RhdGUsIDIpO1xuICAgICAgdXZzLngxID0gY1ggKyB3MiAqIGdyb3VwRDgudVgocm90YXRlKTtcbiAgICAgIHV2cy55MSA9IGNZICsgaDIgKiBncm91cEQ4LnVZKHJvdGF0ZSk7XG4gICAgICByb3RhdGUgPSBncm91cEQ4LmFkZChyb3RhdGUsIDIpO1xuICAgICAgdXZzLngyID0gY1ggKyB3MiAqIGdyb3VwRDgudVgocm90YXRlKTtcbiAgICAgIHV2cy55MiA9IGNZICsgaDIgKiBncm91cEQ4LnVZKHJvdGF0ZSk7XG4gICAgICByb3RhdGUgPSBncm91cEQ4LmFkZChyb3RhdGUsIDIpO1xuICAgICAgdXZzLngzID0gY1ggKyB3MiAqIGdyb3VwRDgudVgocm90YXRlKTtcbiAgICAgIHV2cy55MyA9IGNZICsgaDIgKiBncm91cEQ4LnVZKHJvdGF0ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHV2cy54MCA9IG5YO1xuICAgICAgdXZzLnkwID0gblk7XG4gICAgICB1dnMueDEgPSBuWCArIG5XO1xuICAgICAgdXZzLnkxID0gblk7XG4gICAgICB1dnMueDIgPSBuWCArIG5XO1xuICAgICAgdXZzLnkyID0gblkgKyBuSDtcbiAgICAgIHV2cy54MyA9IG5YO1xuICAgICAgdXZzLnkzID0gblkgKyBuSDtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoaXMgdGV4dHVyZVxuICAgKiBAcGFyYW0gZGVzdHJveVNvdXJjZSAtIERlc3Ryb3kgdGhlIHNvdXJjZSB3aGVuIHRoZSB0ZXh0dXJlIGlzIGRlc3Ryb3llZC5cbiAgICovXG4gIGRlc3Ryb3koZGVzdHJveVNvdXJjZSA9IGZhbHNlKSB7XG4gICAgaWYgKHRoaXMuX3NvdXJjZSkge1xuICAgICAgdGhpcy5fc291cmNlLm9mZihcInJlc2l6ZVwiLCB0aGlzLnVwZGF0ZSwgdGhpcyk7XG4gICAgICBpZiAoZGVzdHJveVNvdXJjZSkge1xuICAgICAgICB0aGlzLl9zb3VyY2UuZGVzdHJveSgpO1xuICAgICAgICB0aGlzLl9zb3VyY2UgPSBudWxsO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLl90ZXh0dXJlTWF0cml4ID0gbnVsbDtcbiAgICB0aGlzLmRlc3Ryb3llZCA9IHRydWU7XG4gICAgdGhpcy5lbWl0KFwiZGVzdHJveVwiLCB0aGlzKTtcbiAgICB0aGlzLnJlbW92ZUFsbExpc3RlbmVycygpO1xuICB9XG4gIC8qKlxuICAgKiBDYWxsIHRoaXMgaWYgeW91IGhhdmUgbW9kaWZpZWQgdGhlIGB0ZXh0dXJlIG91dHNpZGVgIG9mIHRoZSBjb25zdHJ1Y3Rvci5cbiAgICpcbiAgICogSWYgeW91IGhhdmUgbW9kaWZpZWQgdGhpcyB0ZXh0dXJlJ3Mgc291cmNlLCB5b3UgbXVzdCBzZXBhcmF0ZWx5IGNhbGwgYHRleHR1cmUuc291cmNlLnVwZGF0ZSgpYCB0byBzZWUgdGhvc2UgY2hhbmdlcy5cbiAgICovXG4gIHVwZGF0ZSgpIHtcbiAgICBpZiAodGhpcy5ub0ZyYW1lKSB7XG4gICAgICB0aGlzLmZyYW1lLndpZHRoID0gdGhpcy5fc291cmNlLndpZHRoO1xuICAgICAgdGhpcy5mcmFtZS5oZWlnaHQgPSB0aGlzLl9zb3VyY2UuaGVpZ2h0O1xuICAgIH1cbiAgICB0aGlzLnVwZGF0ZVV2cygpO1xuICAgIHRoaXMuZW1pdChcInVwZGF0ZVwiLCB0aGlzKTtcbiAgfVxuICAvKiogQGRlcHJlY2F0ZWQgc2luY2UgOC4wLjAgKi9cbiAgZ2V0IGJhc2VUZXh0dXJlKCkge1xuICAgIGRlcHJlY2F0aW9uKHY4XzBfMCwgXCJUZXh0dXJlLmJhc2VUZXh0dXJlIGlzIG5vdyBUZXh0dXJlLnNvdXJjZVwiKTtcbiAgICByZXR1cm4gdGhpcy5fc291cmNlO1xuICB9XG59XG5UZXh0dXJlLkVNUFRZID0gbmV3IFRleHR1cmUoe1xuICBsYWJlbDogXCJFTVBUWVwiLFxuICBzb3VyY2U6IG5ldyBUZXh0dXJlU291cmNlKHtcbiAgICBsYWJlbDogXCJFTVBUWVwiXG4gIH0pXG59KTtcblRleHR1cmUuRU1QVFkuZGVzdHJveSA9IE5PT1A7XG5UZXh0dXJlLldISVRFID0gbmV3IFRleHR1cmUoe1xuICBzb3VyY2U6IG5ldyBCdWZmZXJJbWFnZVNvdXJjZSh7XG4gICAgcmVzb3VyY2U6IG5ldyBVaW50OEFycmF5KFsyNTUsIDI1NSwgMjU1LCAyNTVdKSxcbiAgICB3aWR0aDogMSxcbiAgICBoZWlnaHQ6IDEsXG4gICAgYWxwaGFNb2RlOiBcInByZW11bHRpcGx5LWFscGhhLW9uLXVwbG9hZFwiLFxuICAgIGxhYmVsOiBcIldISVRFXCJcbiAgfSksXG4gIGxhYmVsOiBcIldISVRFXCJcbn0pO1xuVGV4dHVyZS5XSElURS5kZXN0cm95ID0gTk9PUDtcblxuZXhwb3J0IHsgVGV4dHVyZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9VGV4dHVyZS5tanMubWFwXG4iLCJpbXBvcnQgeyBNYXRyaXggfSBmcm9tICcuLi8uLi8uLi9tYXRocy9tYXRyaXgvTWF0cml4Lm1qcyc7XG5pbXBvcnQgeyBSZWN0YW5nbGUgfSBmcm9tICcuLi8uLi8uLi9tYXRocy9zaGFwZXMvUmVjdGFuZ2xlLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgZGVmYXVsdE1hdHJpeCA9IG5ldyBNYXRyaXgoKTtcbmNsYXNzIEJvdW5kcyB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IEJvdW5kcyBvYmplY3QuXG4gICAqIEBwYXJhbSBtaW5YIC0gVGhlIG1pbmltdW0gWCBjb29yZGluYXRlIG9mIHRoZSBib3VuZHMuXG4gICAqIEBwYXJhbSBtaW5ZIC0gVGhlIG1pbmltdW0gWSBjb29yZGluYXRlIG9mIHRoZSBib3VuZHMuXG4gICAqIEBwYXJhbSBtYXhYIC0gVGhlIG1heGltdW0gWCBjb29yZGluYXRlIG9mIHRoZSBib3VuZHMuXG4gICAqIEBwYXJhbSBtYXhZIC0gVGhlIG1heGltdW0gWSBjb29yZGluYXRlIG9mIHRoZSBib3VuZHMuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihtaW5YID0gSW5maW5pdHksIG1pblkgPSBJbmZpbml0eSwgbWF4WCA9IC1JbmZpbml0eSwgbWF4WSA9IC1JbmZpbml0eSkge1xuICAgIC8qKlxuICAgICAqIFRoZSBtaW5pbXVtIFggY29vcmRpbmF0ZSBvZiB0aGUgYm91bmRzLlxuICAgICAqIFJlcHJlc2VudHMgdGhlIGxlZnRtb3N0IGVkZ2Ugb2YgdGhlIGJvdW5kaW5nIGJveC5cbiAgICAgKiBAZXhhbXBsZVxuICAgICAqIGBgYHRzXG4gICAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygpO1xuICAgICAqIC8vIFNldCBsZWZ0IGVkZ2VcbiAgICAgKiBib3VuZHMubWluWCA9IDEwMDtcbiAgICAgKiBgYGBcbiAgICAgKiBAZGVmYXVsdCBJbmZpbml0eVxuICAgICAqL1xuICAgIHRoaXMubWluWCA9IEluZmluaXR5O1xuICAgIC8qKlxuICAgICAqIFRoZSBtaW5pbXVtIFkgY29vcmRpbmF0ZSBvZiB0aGUgYm91bmRzLlxuICAgICAqIFJlcHJlc2VudHMgdGhlIHRvcG1vc3QgZWRnZSBvZiB0aGUgYm91bmRpbmcgYm94LlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKCk7XG4gICAgICogLy8gU2V0IHRvcCBlZGdlXG4gICAgICogYm91bmRzLm1pblkgPSAxMDA7XG4gICAgICogYGBgXG4gICAgICogQGRlZmF1bHQgSW5maW5pdHlcbiAgICAgKi9cbiAgICB0aGlzLm1pblkgPSBJbmZpbml0eTtcbiAgICAvKipcbiAgICAgKiBUaGUgbWF4aW11bSBYIGNvb3JkaW5hdGUgb2YgdGhlIGJvdW5kcy5cbiAgICAgKiBSZXByZXNlbnRzIHRoZSByaWdodG1vc3QgZWRnZSBvZiB0aGUgYm91bmRpbmcgYm94LlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKCk7XG4gICAgICogLy8gU2V0IHJpZ2h0IGVkZ2VcbiAgICAgKiBib3VuZHMubWF4WCA9IDIwMDtcbiAgICAgKiAvLyBHZXQgd2lkdGhcbiAgICAgKiBjb25zdCB3aWR0aCA9IGJvdW5kcy5tYXhYIC0gYm91bmRzLm1pblg7XG4gICAgICogYGBgXG4gICAgICogQGRlZmF1bHQgLUluZmluaXR5XG4gICAgICovXG4gICAgdGhpcy5tYXhYID0gLUluZmluaXR5O1xuICAgIC8qKlxuICAgICAqIFRoZSBtYXhpbXVtIFkgY29vcmRpbmF0ZSBvZiB0aGUgYm91bmRzLlxuICAgICAqIFJlcHJlc2VudHMgdGhlIGJvdHRvbW1vc3QgZWRnZSBvZiB0aGUgYm91bmRpbmcgYm94LlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKCk7XG4gICAgICogLy8gU2V0IGJvdHRvbSBlZGdlXG4gICAgICogYm91bmRzLm1heFkgPSAyMDA7XG4gICAgICogLy8gR2V0IGhlaWdodFxuICAgICAqIGNvbnN0IGhlaWdodCA9IGJvdW5kcy5tYXhZIC0gYm91bmRzLm1pblk7XG4gICAgICogYGBgXG4gICAgICogQGRlZmF1bHQgLUluZmluaXR5XG4gICAgICovXG4gICAgdGhpcy5tYXhZID0gLUluZmluaXR5O1xuICAgIC8qKlxuICAgICAqIFRoZSB0cmFuc2Zvcm1hdGlvbiBtYXRyaXggYXBwbGllZCB0byB0aGlzIGJvdW5kcyBvYmplY3QuXG4gICAgICogVXNlZCB3aGVuIGNhbGN1bGF0aW5nIGJvdW5kcyB3aXRoIHRyYW5zZm9ybXMuXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoKTtcbiAgICAgKlxuICAgICAqIC8vIEFwcGx5IHRyYW5zbGF0aW9uIG1hdHJpeFxuICAgICAqIGJvdW5kcy5tYXRyaXggPSBuZXcgTWF0cml4KClcbiAgICAgKiAgICAgLnRyYW5zbGF0ZSgxMDAsIDEwMCk7XG4gICAgICpcbiAgICAgKiAvLyBDb21iaW5lIHRyYW5zZm9ybWF0aW9uc1xuICAgICAqIGJvdW5kcy5tYXRyaXggPSBuZXcgTWF0cml4KClcbiAgICAgKiAgICAgLnRyYW5zbGF0ZSg1MCwgNTApXG4gICAgICogICAgIC5yb3RhdGUoTWF0aC5QSSAvIDQpXG4gICAgICogICAgIC5zY2FsZSgyLCAyKTtcbiAgICAgKlxuICAgICAqIC8vIFVzZSBpbiBib3VuZHMgY2FsY3VsYXRpb25zXG4gICAgICogYm91bmRzLmFkZEZyYW1lKDAsIDAsIDEwMCwgMTAwKTsgLy8gVXNlcyBjdXJyZW50IG1hdHJpeFxuICAgICAqIGJvdW5kcy5hZGRGcmFtZSgwLCAwLCAxMDAsIDEwMCwgY3VzdG9tTWF0cml4KTsgLy8gT3ZlcnJpZGUgbWF0cml4XG4gICAgICogYGBgXG4gICAgICogQGFkdmFuY2VkXG4gICAgICovXG4gICAgdGhpcy5tYXRyaXggPSBkZWZhdWx0TWF0cml4O1xuICAgIHRoaXMubWluWCA9IG1pblg7XG4gICAgdGhpcy5taW5ZID0gbWluWTtcbiAgICB0aGlzLm1heFggPSBtYXhYO1xuICAgIHRoaXMubWF4WSA9IG1heFk7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyBpZiBib3VuZHMgYXJlIGVtcHR5LCBtZWFuaW5nIGVpdGhlciB3aWR0aCBvciBoZWlnaHQgaXMgemVybyBvciBuZWdhdGl2ZS5cbiAgICogRW1wdHkgYm91bmRzIG9jY3VyIHdoZW4gbWluIHZhbHVlcyBleGNlZWQgbWF4IHZhbHVlcyBvbiBlaXRoZXIgYXhpcy5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygpO1xuICAgKlxuICAgKiAvLyBDaGVjayBpZiBuZXdseSBjcmVhdGVkIGJvdW5kcyBhcmUgZW1wdHlcbiAgICogY29uc29sZS5sb2coYm91bmRzLmlzRW1wdHkoKSk7IC8vIHRydWUsIGRlZmF1bHQgYm91bmRzIGFyZSBlbXB0eVxuICAgKlxuICAgKiAvLyBBZGQgZnJhbWUgYW5kIGNoZWNrIGFnYWluXG4gICAqIGJvdW5kcy5hZGRGcmFtZSgwLCAwLCAxMDAsIDEwMCk7XG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5pc0VtcHR5KCkpOyAvLyBmYWxzZSwgYm91bmRzIG5vdyBoYXZlIGFyZWFcbiAgICpcbiAgICogLy8gQ2xlYXIgYm91bmRzXG4gICAqIGJvdW5kcy5jbGVhcigpO1xuICAgKiBjb25zb2xlLmxvZyhib3VuZHMuaXNFbXB0eSgpKTsgLy8gdHJ1ZSwgYm91bmRzIGFyZSBlbXB0eSBhZ2FpblxuICAgKiBgYGBcbiAgICogQHJldHVybnMgVHJ1ZSBpZiBib3VuZHMgYXJlIGVtcHR5IChoYXZlIG5vIGFyZWEpXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNjbGVhcn0gRm9yIHJlc2V0dGluZyBib3VuZHNcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2lzVmFsaWR9IEZvciBjaGVja2luZyB2YWxpZGl0eVxuICAgKi9cbiAgaXNFbXB0eSgpIHtcbiAgICByZXR1cm4gdGhpcy5taW5YID4gdGhpcy5tYXhYIHx8IHRoaXMubWluWSA+IHRoaXMubWF4WTtcbiAgfVxuICAvKipcbiAgICogVGhlIGJvdW5kaW5nIHJlY3RhbmdsZSByZXByZXNlbnRhdGlvbiBvZiB0aGVzZSBib3VuZHMuXG4gICAqIExhemlseSBjcmVhdGVzIGFuZCB1cGRhdGVzIGEgUmVjdGFuZ2xlIGluc3RhbmNlIGJhc2VkIG9uIHRoZSBjdXJyZW50IGJvdW5kcy5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygwLCAwLCAxMDAsIDEwMCk7XG4gICAqXG4gICAqIC8vIEdldCByZWN0YW5nbGUgcmVwcmVzZW50YXRpb25cbiAgICogY29uc3QgcmVjdCA9IGJvdW5kcy5yZWN0YW5nbGU7XG4gICAqIGNvbnNvbGUubG9nKHJlY3QueCwgcmVjdC55LCByZWN0LndpZHRoLCByZWN0LmhlaWdodCk7XG4gICAqXG4gICAqIC8vIFVzZSBmb3IgaGl0IHRlc3RpbmdcbiAgICogaWYgKGJvdW5kcy5yZWN0YW5nbGUuY29udGFpbnMobW91c2VYLCBtb3VzZVkpKSB7XG4gICAqICAgICBjb25zb2xlLmxvZygnTW91c2UgaXMgaW5zaWRlIGJvdW5kcyEnKTtcbiAgICogfVxuICAgKiBgYGBcbiAgICogQHNlZSB7QGxpbmsgUmVjdGFuZ2xlfSBGb3IgcmVjdGFuZ2xlIG1ldGhvZHNcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzLmlzRW1wdHl9IEZvciBib3VuZHMgdmFsaWRhdGlvblxuICAgKi9cbiAgZ2V0IHJlY3RhbmdsZSgpIHtcbiAgICBpZiAoIXRoaXMuX3JlY3RhbmdsZSkge1xuICAgICAgdGhpcy5fcmVjdGFuZ2xlID0gbmV3IFJlY3RhbmdsZSgpO1xuICAgIH1cbiAgICBjb25zdCByZWN0YW5nbGUgPSB0aGlzLl9yZWN0YW5nbGU7XG4gICAgaWYgKHRoaXMubWluWCA+IHRoaXMubWF4WCB8fCB0aGlzLm1pblkgPiB0aGlzLm1heFkpIHtcbiAgICAgIHJlY3RhbmdsZS54ID0gMDtcbiAgICAgIHJlY3RhbmdsZS55ID0gMDtcbiAgICAgIHJlY3RhbmdsZS53aWR0aCA9IDA7XG4gICAgICByZWN0YW5nbGUuaGVpZ2h0ID0gMDtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVjdGFuZ2xlLmNvcHlGcm9tQm91bmRzKHRoaXMpO1xuICAgIH1cbiAgICByZXR1cm4gcmVjdGFuZ2xlO1xuICB9XG4gIC8qKlxuICAgKiBDbGVhcnMgdGhlIGJvdW5kcyBhbmQgcmVzZXRzIGFsbCBjb29yZGluYXRlcyB0byB0aGVpciBkZWZhdWx0IHZhbHVlcy5cbiAgICogUmVzZXRzIHRoZSB0cmFuc2Zvcm1hdGlvbiBtYXRyaXggYmFjayB0byBpZGVudGl0eS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygwLCAwLCAxMDAsIDEwMCk7XG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5pc0VtcHR5KCkpOyAvLyBmYWxzZVxuICAgKiAvLyBDbGVhciB0aGUgYm91bmRzXG4gICAqIGJvdW5kcy5jbGVhcigpO1xuICAgKiBjb25zb2xlLmxvZyhib3VuZHMuaXNFbXB0eSgpKTsgLy8gdHJ1ZVxuICAgKiBgYGBcbiAgICogQHJldHVybnMgVGhpcyBib3VuZHMgb2JqZWN0IGZvciBjaGFpbmluZ1xuICAgKi9cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy5taW5YID0gSW5maW5pdHk7XG4gICAgdGhpcy5taW5ZID0gSW5maW5pdHk7XG4gICAgdGhpcy5tYXhYID0gLUluZmluaXR5O1xuICAgIHRoaXMubWF4WSA9IC1JbmZpbml0eTtcbiAgICB0aGlzLm1hdHJpeCA9IGRlZmF1bHRNYXRyaXg7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgdGhlIGJvdW5kcyBkaXJlY3RseSB1c2luZyBjb29yZGluYXRlIHZhbHVlcy5cbiAgICogUHJvdmlkZXMgYSB3YXkgdG8gc2V0IGFsbCBib3VuZHMgdmFsdWVzIGF0IG9uY2UuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoKTtcbiAgICogYm91bmRzLnNldCgwLCAwLCAxMDAsIDEwMCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0geDAgLSBMZWZ0IFggY29vcmRpbmF0ZSBvZiBmcmFtZVxuICAgKiBAcGFyYW0geTAgLSBUb3AgWSBjb29yZGluYXRlIG9mIGZyYW1lXG4gICAqIEBwYXJhbSB4MSAtIFJpZ2h0IFggY29vcmRpbmF0ZSBvZiBmcmFtZVxuICAgKiBAcGFyYW0geTEgLSBCb3R0b20gWSBjb29yZGluYXRlIG9mIGZyYW1lXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNhZGRGcmFtZX0gRm9yIG1hdHJpeC1hd2FyZSBib3VuZHMgc2V0dGluZ1xuICAgKiBAc2VlIHtAbGluayBCb3VuZHMjY2xlYXJ9IEZvciByZXNldHRpbmcgYm91bmRzXG4gICAqL1xuICBzZXQoeDAsIHkwLCB4MSwgeTEpIHtcbiAgICB0aGlzLm1pblggPSB4MDtcbiAgICB0aGlzLm1pblkgPSB5MDtcbiAgICB0aGlzLm1heFggPSB4MTtcbiAgICB0aGlzLm1heFkgPSB5MTtcbiAgfVxuICAvKipcbiAgICogQWRkcyBhIHJlY3Rhbmd1bGFyIGZyYW1lIHRvIHRoZSBib3VuZHMsIG9wdGlvbmFsbHkgdHJhbnNmb3JtZWQgYnkgYSBtYXRyaXguXG4gICAqIFVwZGF0ZXMgdGhlIGJvdW5kcyB0byBlbmNvbXBhc3MgdGhlIG5ldyBmcmFtZSBjb29yZGluYXRlcy5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygpO1xuICAgKiBib3VuZHMuYWRkRnJhbWUoMCwgMCwgMTAwLCAxMDApO1xuICAgKlxuICAgKiAvLyBBZGQgdHJhbnNmb3JtZWQgZnJhbWVcbiAgICogY29uc3QgbWF0cml4ID0gbmV3IE1hdHJpeCgpXG4gICAqICAgICAudHJhbnNsYXRlKDUwLCA1MClcbiAgICogICAgIC5yb3RhdGUoTWF0aC5QSSAvIDQpO1xuICAgKiBib3VuZHMuYWRkRnJhbWUoMCwgMCwgMTAwLCAxMDAsIG1hdHJpeCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0geDAgLSBMZWZ0IFggY29vcmRpbmF0ZSBvZiBmcmFtZVxuICAgKiBAcGFyYW0geTAgLSBUb3AgWSBjb29yZGluYXRlIG9mIGZyYW1lXG4gICAqIEBwYXJhbSB4MSAtIFJpZ2h0IFggY29vcmRpbmF0ZSBvZiBmcmFtZVxuICAgKiBAcGFyYW0geTEgLSBCb3R0b20gWSBjb29yZGluYXRlIG9mIGZyYW1lXG4gICAqIEBwYXJhbSBtYXRyaXggLSBPcHRpb25hbCB0cmFuc2Zvcm1hdGlvbiBtYXRyaXhcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2FkZFJlY3R9IEZvciBhZGRpbmcgUmVjdGFuZ2xlIG9iamVjdHNcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2FkZEJvdW5kc30gRm9yIGFkZGluZyBvdGhlciBCb3VuZHNcbiAgICovXG4gIGFkZEZyYW1lKHgwLCB5MCwgeDEsIHkxLCBtYXRyaXgpIHtcbiAgICBtYXRyaXggfHwgKG1hdHJpeCA9IHRoaXMubWF0cml4KTtcbiAgICBjb25zdCBhID0gbWF0cml4LmE7XG4gICAgY29uc3QgYiA9IG1hdHJpeC5iO1xuICAgIGNvbnN0IGMgPSBtYXRyaXguYztcbiAgICBjb25zdCBkID0gbWF0cml4LmQ7XG4gICAgY29uc3QgdHggPSBtYXRyaXgudHg7XG4gICAgY29uc3QgdHkgPSBtYXRyaXgudHk7XG4gICAgbGV0IG1pblggPSB0aGlzLm1pblg7XG4gICAgbGV0IG1pblkgPSB0aGlzLm1pblk7XG4gICAgbGV0IG1heFggPSB0aGlzLm1heFg7XG4gICAgbGV0IG1heFkgPSB0aGlzLm1heFk7XG4gICAgbGV0IHggPSBhICogeDAgKyBjICogeTAgKyB0eDtcbiAgICBsZXQgeSA9IGIgKiB4MCArIGQgKiB5MCArIHR5O1xuICAgIGlmICh4IDwgbWluWCkgbWluWCA9IHg7XG4gICAgaWYgKHkgPCBtaW5ZKSBtaW5ZID0geTtcbiAgICBpZiAoeCA+IG1heFgpIG1heFggPSB4O1xuICAgIGlmICh5ID4gbWF4WSkgbWF4WSA9IHk7XG4gICAgeCA9IGEgKiB4MSArIGMgKiB5MCArIHR4O1xuICAgIHkgPSBiICogeDEgKyBkICogeTAgKyB0eTtcbiAgICBpZiAoeCA8IG1pblgpIG1pblggPSB4O1xuICAgIGlmICh5IDwgbWluWSkgbWluWSA9IHk7XG4gICAgaWYgKHggPiBtYXhYKSBtYXhYID0geDtcbiAgICBpZiAoeSA+IG1heFkpIG1heFkgPSB5O1xuICAgIHggPSBhICogeDAgKyBjICogeTEgKyB0eDtcbiAgICB5ID0gYiAqIHgwICsgZCAqIHkxICsgdHk7XG4gICAgaWYgKHggPCBtaW5YKSBtaW5YID0geDtcbiAgICBpZiAoeSA8IG1pblkpIG1pblkgPSB5O1xuICAgIGlmICh4ID4gbWF4WCkgbWF4WCA9IHg7XG4gICAgaWYgKHkgPiBtYXhZKSBtYXhZID0geTtcbiAgICB4ID0gYSAqIHgxICsgYyAqIHkxICsgdHg7XG4gICAgeSA9IGIgKiB4MSArIGQgKiB5MSArIHR5O1xuICAgIGlmICh4IDwgbWluWCkgbWluWCA9IHg7XG4gICAgaWYgKHkgPCBtaW5ZKSBtaW5ZID0geTtcbiAgICBpZiAoeCA+IG1heFgpIG1heFggPSB4O1xuICAgIGlmICh5ID4gbWF4WSkgbWF4WSA9IHk7XG4gICAgdGhpcy5taW5YID0gbWluWDtcbiAgICB0aGlzLm1pblkgPSBtaW5ZO1xuICAgIHRoaXMubWF4WCA9IG1heFg7XG4gICAgdGhpcy5tYXhZID0gbWF4WTtcbiAgfVxuICAvKipcbiAgICogQWRkcyBhIHJlY3RhbmdsZSB0byB0aGUgYm91bmRzLCBvcHRpb25hbGx5IHRyYW5zZm9ybWVkIGJ5IGEgbWF0cml4LlxuICAgKiBVcGRhdGVzIHRoZSBib3VuZHMgdG8gZW5jb21wYXNzIHRoZSBnaXZlbiByZWN0YW5nbGUuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoKTtcbiAgICogLy8gQWRkIHNpbXBsZSByZWN0YW5nbGVcbiAgICogY29uc3QgcmVjdCA9IG5ldyBSZWN0YW5nbGUoMCwgMCwgMTAwLCAxMDApO1xuICAgKiBib3VuZHMuYWRkUmVjdChyZWN0KTtcbiAgICpcbiAgICogLy8gQWRkIHRyYW5zZm9ybWVkIHJlY3RhbmdsZVxuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KClcbiAgICogICAgIC50cmFuc2xhdGUoNTAsIDUwKVxuICAgKiAgICAgLnJvdGF0ZShNYXRoLlBJIC8gNCk7XG4gICAqIGJvdW5kcy5hZGRSZWN0KHJlY3QsIG1hdHJpeCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gcmVjdCAtIFRoZSByZWN0YW5nbGUgdG8gYmUgYWRkZWRcbiAgICogQHBhcmFtIG1hdHJpeCAtIE9wdGlvbmFsIHRyYW5zZm9ybWF0aW9uIG1hdHJpeFxuICAgKiBAc2VlIHtAbGluayBCb3VuZHMjYWRkRnJhbWV9IEZvciBhZGRpbmcgcmF3IGNvb3JkaW5hdGVzXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNhZGRCb3VuZHN9IEZvciBhZGRpbmcgb3RoZXIgYm91bmRzXG4gICAqL1xuICBhZGRSZWN0KHJlY3QsIG1hdHJpeCkge1xuICAgIHRoaXMuYWRkRnJhbWUocmVjdC54LCByZWN0LnksIHJlY3QueCArIHJlY3Qud2lkdGgsIHJlY3QueSArIHJlY3QuaGVpZ2h0LCBtYXRyaXgpO1xuICB9XG4gIC8qKlxuICAgKiBBZGRzIGFub3RoZXIgYm91bmRzIG9iamVjdCB0byB0aGlzIG9uZSwgb3B0aW9uYWxseSB0cmFuc2Zvcm1lZCBieSBhIG1hdHJpeC5cbiAgICogRXhwYW5kcyB0aGUgYm91bmRzIHRvIGluY2x1ZGUgdGhlIGdpdmVuIGJvdW5kcycgYXJlYS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygpO1xuICAgKlxuICAgKiAvLyBBZGQgY2hpbGQgYm91bmRzXG4gICAqIGNvbnN0IGNoaWxkQm91bmRzID0gc3ByaXRlLmdldEJvdW5kcygpO1xuICAgKiBib3VuZHMuYWRkQm91bmRzKGNoaWxkQm91bmRzKTtcbiAgICpcbiAgICogLy8gQWRkIHRyYW5zZm9ybWVkIGJvdW5kc1xuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KClcbiAgICogICAgIC5zY2FsZSgyLCAyKTtcbiAgICogYm91bmRzLmFkZEJvdW5kcyhjaGlsZEJvdW5kcywgbWF0cml4KTtcbiAgICogYGBgXG4gICAqIEBwYXJhbSBib3VuZHMgLSBUaGUgYm91bmRzIHRvIGJlIGFkZGVkXG4gICAqIEBwYXJhbSBtYXRyaXggLSBPcHRpb25hbCB0cmFuc2Zvcm1hdGlvbiBtYXRyaXhcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2FkZEZyYW1lfSBGb3IgYWRkaW5nIHJhdyBjb29yZGluYXRlc1xuICAgKiBAc2VlIHtAbGluayBCb3VuZHMjYWRkUmVjdH0gRm9yIGFkZGluZyByZWN0YW5nbGVzXG4gICAqL1xuICBhZGRCb3VuZHMoYm91bmRzLCBtYXRyaXgpIHtcbiAgICB0aGlzLmFkZEZyYW1lKGJvdW5kcy5taW5YLCBib3VuZHMubWluWSwgYm91bmRzLm1heFgsIGJvdW5kcy5tYXhZLCBtYXRyaXgpO1xuICB9XG4gIC8qKlxuICAgKiBBZGRzIG90aGVyIEJvdW5kcyBhcyBhIG1hc2ssIGNyZWF0aW5nIGFuIGludGVyc2VjdGlvbiBvZiB0aGUgdHdvIGJvdW5kcy5cbiAgICogT25seSBrZWVwcyB0aGUgb3ZlcmxhcHBpbmcgcmVnaW9uIGJldHdlZW4gY3VycmVudCBib3VuZHMgYW5kIG1hc2sgYm91bmRzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKDAsIDAsIDEwMCwgMTAwKTtcbiAgICogLy8gQ3JlYXRlIG1hc2sgYm91bmRzXG4gICAqIGNvbnN0IG1hc2sgPSBuZXcgQm91bmRzKCk7XG4gICAqIG1hc2suYWRkRnJhbWUoNTAsIDUwLCAxNTAsIDE1MCk7XG4gICAqIC8vIEFwcGx5IG1hc2sgLSByZXN1bHRzIGluIGJvdW5kcyBvZiAoNTAsNTAsMTAwLDEwMClcbiAgICogYm91bmRzLmFkZEJvdW5kc01hc2sobWFzayk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gbWFzayAtIFRoZSBCb3VuZHMgdG8gdXNlIGFzIGEgbWFza1xuICAgKiBAc2VlIHtAbGluayBCb3VuZHMjYWRkQm91bmRzfSBGb3IgdW5pb24gb3BlcmF0aW9uXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNmaXR9IEZvciBmaXR0aW5nIHRvIHJlY3RhbmdsZVxuICAgKi9cbiAgYWRkQm91bmRzTWFzayhtYXNrKSB7XG4gICAgdGhpcy5taW5YID0gdGhpcy5taW5YID4gbWFzay5taW5YID8gdGhpcy5taW5YIDogbWFzay5taW5YO1xuICAgIHRoaXMubWluWSA9IHRoaXMubWluWSA+IG1hc2subWluWSA/IHRoaXMubWluWSA6IG1hc2subWluWTtcbiAgICB0aGlzLm1heFggPSB0aGlzLm1heFggPCBtYXNrLm1heFggPyB0aGlzLm1heFggOiBtYXNrLm1heFg7XG4gICAgdGhpcy5tYXhZID0gdGhpcy5tYXhZIDwgbWFzay5tYXhZID8gdGhpcy5tYXhZIDogbWFzay5tYXhZO1xuICB9XG4gIC8qKlxuICAgKiBBcHBsaWVzIGEgdHJhbnNmb3JtYXRpb24gbWF0cml4IHRvIHRoZSBib3VuZHMsIHVwZGF0aW5nIGl0cyBjb29yZGluYXRlcy5cbiAgICogVHJhbnNmb3JtcyBhbGwgY29ybmVycyBvZiB0aGUgYm91bmRzIHVzaW5nIHRoZSBnaXZlbiBtYXRyaXguXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoMCwgMCwgMTAwLCAxMDApO1xuICAgKiAvLyBBcHBseSB0cmFuc2xhdGlvblxuICAgKiBjb25zdCB0cmFuc2xhdGVNYXRyaXggPSBuZXcgTWF0cml4KClcbiAgICogICAgIC50cmFuc2xhdGUoNTAsIDUwKTtcbiAgICogYm91bmRzLmFwcGx5TWF0cml4KHRyYW5zbGF0ZU1hdHJpeCk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gbWF0cml4IC0gVGhlIG1hdHJpeCB0byBhcHBseSB0byB0aGUgYm91bmRzXG4gICAqIEBzZWUge0BsaW5rIE1hdHJpeH0gRm9yIG1hdHJpeCBvcGVyYXRpb25zXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNhZGRGcmFtZX0gRm9yIGFkZGluZyB0cmFuc2Zvcm1lZCBmcmFtZXNcbiAgICovXG4gIGFwcGx5TWF0cml4KG1hdHJpeCkge1xuICAgIGNvbnN0IG1pblggPSB0aGlzLm1pblg7XG4gICAgY29uc3QgbWluWSA9IHRoaXMubWluWTtcbiAgICBjb25zdCBtYXhYID0gdGhpcy5tYXhYO1xuICAgIGNvbnN0IG1heFkgPSB0aGlzLm1heFk7XG4gICAgY29uc3QgeyBhLCBiLCBjLCBkLCB0eCwgdHkgfSA9IG1hdHJpeDtcbiAgICBsZXQgeCA9IGEgKiBtaW5YICsgYyAqIG1pblkgKyB0eDtcbiAgICBsZXQgeSA9IGIgKiBtaW5YICsgZCAqIG1pblkgKyB0eTtcbiAgICB0aGlzLm1pblggPSB4O1xuICAgIHRoaXMubWluWSA9IHk7XG4gICAgdGhpcy5tYXhYID0geDtcbiAgICB0aGlzLm1heFkgPSB5O1xuICAgIHggPSBhICogbWF4WCArIGMgKiBtaW5ZICsgdHg7XG4gICAgeSA9IGIgKiBtYXhYICsgZCAqIG1pblkgKyB0eTtcbiAgICB0aGlzLm1pblggPSB4IDwgdGhpcy5taW5YID8geCA6IHRoaXMubWluWDtcbiAgICB0aGlzLm1pblkgPSB5IDwgdGhpcy5taW5ZID8geSA6IHRoaXMubWluWTtcbiAgICB0aGlzLm1heFggPSB4ID4gdGhpcy5tYXhYID8geCA6IHRoaXMubWF4WDtcbiAgICB0aGlzLm1heFkgPSB5ID4gdGhpcy5tYXhZID8geSA6IHRoaXMubWF4WTtcbiAgICB4ID0gYSAqIG1pblggKyBjICogbWF4WSArIHR4O1xuICAgIHkgPSBiICogbWluWCArIGQgKiBtYXhZICsgdHk7XG4gICAgdGhpcy5taW5YID0geCA8IHRoaXMubWluWCA/IHggOiB0aGlzLm1pblg7XG4gICAgdGhpcy5taW5ZID0geSA8IHRoaXMubWluWSA/IHkgOiB0aGlzLm1pblk7XG4gICAgdGhpcy5tYXhYID0geCA+IHRoaXMubWF4WCA/IHggOiB0aGlzLm1heFg7XG4gICAgdGhpcy5tYXhZID0geSA+IHRoaXMubWF4WSA/IHkgOiB0aGlzLm1heFk7XG4gICAgeCA9IGEgKiBtYXhYICsgYyAqIG1heFkgKyB0eDtcbiAgICB5ID0gYiAqIG1heFggKyBkICogbWF4WSArIHR5O1xuICAgIHRoaXMubWluWCA9IHggPCB0aGlzLm1pblggPyB4IDogdGhpcy5taW5YO1xuICAgIHRoaXMubWluWSA9IHkgPCB0aGlzLm1pblkgPyB5IDogdGhpcy5taW5ZO1xuICAgIHRoaXMubWF4WCA9IHggPiB0aGlzLm1heFggPyB4IDogdGhpcy5tYXhYO1xuICAgIHRoaXMubWF4WSA9IHkgPiB0aGlzLm1heFkgPyB5IDogdGhpcy5tYXhZO1xuICB9XG4gIC8qKlxuICAgKiBSZXNpemVzIHRoZSBib3VuZHMgb2JqZWN0IHRvIGZpdCB3aXRoaW4gdGhlIGdpdmVuIHJlY3RhbmdsZS5cbiAgICogQ2xpcHMgdGhlIGJvdW5kcyBpZiB0aGV5IGV4dGVuZCBiZXlvbmQgdGhlIHJlY3RhbmdsZSdzIGVkZ2VzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKDAsIDAsIDIwMCwgMjAwKTtcbiAgICogLy8gRml0IHdpdGhpbiB2aWV3cG9ydFxuICAgKiBjb25zdCB2aWV3cG9ydCA9IG5ldyBSZWN0YW5nbGUoNTAsIDUwLCAxMDAsIDEwMCk7XG4gICAqIGJvdW5kcy5maXQodmlld3BvcnQpO1xuICAgKiAvLyBib3VuZHMgYXJlIG5vdyAoNTAsIDUwLCAxNTAsIDE1MClcbiAgICogYGBgXG4gICAqIEBwYXJhbSByZWN0IC0gVGhlIHJlY3RhbmdsZSB0byBmaXQgd2l0aGluXG4gICAqIEByZXR1cm5zIFRoaXMgYm91bmRzIG9iamVjdCBmb3IgY2hhaW5pbmdcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2FkZEJvdW5kc01hc2t9IEZvciBpbnRlcnNlY3Rpb25cbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI3BhZH0gRm9yIGV4cGFuZGluZyBib3VuZHNcbiAgICovXG4gIGZpdChyZWN0KSB7XG4gICAgaWYgKHRoaXMubWluWCA8IHJlY3QubGVmdCkgdGhpcy5taW5YID0gcmVjdC5sZWZ0O1xuICAgIGlmICh0aGlzLm1heFggPiByZWN0LnJpZ2h0KSB0aGlzLm1heFggPSByZWN0LnJpZ2h0O1xuICAgIGlmICh0aGlzLm1pblkgPCByZWN0LnRvcCkgdGhpcy5taW5ZID0gcmVjdC50b3A7XG4gICAgaWYgKHRoaXMubWF4WSA+IHJlY3QuYm90dG9tKSB0aGlzLm1heFkgPSByZWN0LmJvdHRvbTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogUmVzaXplcyB0aGUgYm91bmRzIG9iamVjdCB0byBpbmNsdWRlIHRoZSBnaXZlbiBib3VuZHMuXG4gICAqIFNpbWlsYXIgdG8gZml0KCkgYnV0IHdvcmtzIHdpdGggcmF3IGNvb3JkaW5hdGUgdmFsdWVzIGluc3RlYWQgb2YgYSBSZWN0YW5nbGUuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoMCwgMCwgMjAwLCAyMDApO1xuICAgKiAvLyBGaXQgdG8gc3BlY2lmaWMgY29vcmRpbmF0ZXNcbiAgICogYm91bmRzLmZpdEJvdW5kcyg1MCwgMTUwLCA1MCwgMTUwKTtcbiAgICogLy8gYm91bmRzIGFyZSBub3cgKDUwLCA1MCwgMTUwLCAxNTApXG4gICAqIGBgYFxuICAgKiBAcGFyYW0gbGVmdCAtIFRoZSBsZWZ0IHZhbHVlIG9mIHRoZSBib3VuZHNcbiAgICogQHBhcmFtIHJpZ2h0IC0gVGhlIHJpZ2h0IHZhbHVlIG9mIHRoZSBib3VuZHNcbiAgICogQHBhcmFtIHRvcCAtIFRoZSB0b3AgdmFsdWUgb2YgdGhlIGJvdW5kc1xuICAgKiBAcGFyYW0gYm90dG9tIC0gVGhlIGJvdHRvbSB2YWx1ZSBvZiB0aGUgYm91bmRzXG4gICAqIEByZXR1cm5zIFRoaXMgYm91bmRzIG9iamVjdCBmb3IgY2hhaW5pbmdcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2ZpdH0gRm9yIGZpdHRpbmcgdG8gUmVjdGFuZ2xlXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNhZGRCb3VuZHNNYXNrfSBGb3IgaW50ZXJzZWN0aW9uXG4gICAqL1xuICBmaXRCb3VuZHMobGVmdCwgcmlnaHQsIHRvcCwgYm90dG9tKSB7XG4gICAgaWYgKHRoaXMubWluWCA8IGxlZnQpIHRoaXMubWluWCA9IGxlZnQ7XG4gICAgaWYgKHRoaXMubWF4WCA+IHJpZ2h0KSB0aGlzLm1heFggPSByaWdodDtcbiAgICBpZiAodGhpcy5taW5ZIDwgdG9wKSB0aGlzLm1pblkgPSB0b3A7XG4gICAgaWYgKHRoaXMubWF4WSA+IGJvdHRvbSkgdGhpcy5tYXhZID0gYm90dG9tO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBQYWRzIGJvdW5kcyBvYmplY3QsIG1ha2luZyBpdCBncm93IGluIGFsbCBkaXJlY3Rpb25zLlxuICAgKiBJZiBwYWRkaW5nWSBpcyBvbWl0dGVkLCBib3RoIHBhZGRpbmdYIGFuZCBwYWRkaW5nWSB3aWxsIGJlIHNldCB0byBwYWRkaW5nWC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygwLCAwLCAxMDAsIDEwMCk7XG4gICAqXG4gICAqIC8vIEFkZCBlcXVhbCBwYWRkaW5nXG4gICAqIGJvdW5kcy5wYWQoMTApO1xuICAgKiAvLyBib3VuZHMgYXJlIG5vdyAoLTEwLCAtMTAsIDExMCwgMTEwKVxuICAgKlxuICAgKiAvLyBBZGQgZGlmZmVyZW50IHBhZGRpbmcgZm9yIHggYW5kIHlcbiAgICogYm91bmRzLnBhZCgyMCwgMTApO1xuICAgKiAvLyBib3VuZHMgYXJlIG5vdyAoLTMwLCAtMjAsIDEzMCwgMTIwKVxuICAgKiBgYGBcbiAgICogQHBhcmFtIHBhZGRpbmdYIC0gVGhlIGhvcml6b250YWwgcGFkZGluZyBhbW91bnRcbiAgICogQHBhcmFtIHBhZGRpbmdZIC0gVGhlIHZlcnRpY2FsIHBhZGRpbmcgYW1vdW50XG4gICAqIEByZXR1cm5zIFRoaXMgYm91bmRzIG9iamVjdCBmb3IgY2hhaW5pbmdcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2ZpdH0gRm9yIGNvbnN0cmFpbmluZyBib3VuZHNcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI3NjYWxlfSBGb3IgdW5pZm9ybSBzY2FsaW5nXG4gICAqL1xuICBwYWQocGFkZGluZ1gsIHBhZGRpbmdZID0gcGFkZGluZ1gpIHtcbiAgICB0aGlzLm1pblggLT0gcGFkZGluZ1g7XG4gICAgdGhpcy5tYXhYICs9IHBhZGRpbmdYO1xuICAgIHRoaXMubWluWSAtPSBwYWRkaW5nWTtcbiAgICB0aGlzLm1heFkgKz0gcGFkZGluZ1k7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENlaWxzIHRoZSBib3VuZHMgYnkgcm91bmRpbmcgdXAgbWF4IHZhbHVlcyBhbmQgcm91bmRpbmcgZG93biBtaW4gdmFsdWVzLlxuICAgKiBVc2VmdWwgZm9yIHBpeGVsLXBlcmZlY3QgY2FsY3VsYXRpb25zIGFuZCBhdm9pZGluZyBmcmFjdGlvbmFsIHBpeGVscy5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygpO1xuICAgKiBib3VuZHMuc2V0KDEwLjIsIDEwLjksIDUwLjEsIDUwLjgpO1xuICAgKlxuICAgKiAvLyBSb3VuZCB0byB3aG9sZSBwaXhlbHNcbiAgICogYm91bmRzLmNlaWwoKTtcbiAgICogLy8gYm91bmRzIGFyZSBub3cgKDEwLCAxMCwgNTEsIDUxKVxuICAgKiBgYGBcbiAgICogQHJldHVybnMgVGhpcyBib3VuZHMgb2JqZWN0IGZvciBjaGFpbmluZ1xuICAgKiBAc2VlIHtAbGluayBCb3VuZHMjc2NhbGV9IEZvciBzaXplIGFkanVzdG1lbnRzXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNmaXR9IEZvciBjb25zdHJhaW5pbmcgYm91bmRzXG4gICAqL1xuICBjZWlsKCkge1xuICAgIHRoaXMubWluWCA9IE1hdGguZmxvb3IodGhpcy5taW5YKTtcbiAgICB0aGlzLm1pblkgPSBNYXRoLmZsb29yKHRoaXMubWluWSk7XG4gICAgdGhpcy5tYXhYID0gTWF0aC5jZWlsKHRoaXMubWF4WCk7XG4gICAgdGhpcy5tYXhZID0gTWF0aC5jZWlsKHRoaXMubWF4WSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgQm91bmRzIGluc3RhbmNlIHdpdGggdGhlIHNhbWUgdmFsdWVzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKDAsIDAsIDEwMCwgMTAwKTtcbiAgICpcbiAgICogLy8gQ3JlYXRlIGEgY29weVxuICAgKiBjb25zdCBjb3B5ID0gYm91bmRzLmNsb25lKCk7XG4gICAqXG4gICAqIC8vIE9yaWdpbmFsIGFuZCBjb3B5IGFyZSBpbmRlcGVuZGVudFxuICAgKiBib3VuZHMucGFkKDEwKTtcbiAgICogY29uc29sZS5sb2coY29weS53aWR0aCA9PT0gYm91bmRzLndpZHRoKTsgLy8gZmFsc2VcbiAgICogYGBgXG4gICAqIEByZXR1cm5zIEEgbmV3IEJvdW5kcyBpbnN0YW5jZSB3aXRoIHRoZSBzYW1lIHZhbHVlc1xuICAgKiBAc2VlIHtAbGluayBCb3VuZHMjY29weUZyb219IEZvciByZXVzaW5nIGV4aXN0aW5nIGJvdW5kc1xuICAgKi9cbiAgY2xvbmUoKSB7XG4gICAgcmV0dXJuIG5ldyBCb3VuZHModGhpcy5taW5YLCB0aGlzLm1pblksIHRoaXMubWF4WCwgdGhpcy5tYXhZKTtcbiAgfVxuICAvKipcbiAgICogU2NhbGVzIHRoZSBib3VuZHMgYnkgdGhlIGdpdmVuIHZhbHVlcywgYWRqdXN0aW5nIGFsbCBlZGdlcyBwcm9wb3J0aW9uYWxseS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygwLCAwLCAxMDAsIDEwMCk7XG4gICAqXG4gICAqIC8vIFNjYWxlIHVuaWZvcm1seVxuICAgKiBib3VuZHMuc2NhbGUoMik7XG4gICAqIC8vIGJvdW5kcyBhcmUgbm93ICgwLCAwLCAyMDAsIDIwMClcbiAgICpcbiAgICogLy8gU2NhbGUgbm9uLXVuaWZvcm1seVxuICAgKiBib3VuZHMuc2NhbGUoMC41LCAyKTtcbiAgICogLy8gYm91bmRzIGFyZSBub3cgKDAsIDAsIDEwMCwgNDAwKVxuICAgKiBgYGBcbiAgICogQHBhcmFtIHggLSBUaGUgWCB2YWx1ZSB0byBzY2FsZSBieVxuICAgKiBAcGFyYW0geSAtIFRoZSBZIHZhbHVlIHRvIHNjYWxlIGJ5IChkZWZhdWx0cyB0byB4KVxuICAgKiBAcmV0dXJucyBUaGlzIGJvdW5kcyBvYmplY3QgZm9yIGNoYWluaW5nXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNwYWR9IEZvciBhZGRpbmcgcGFkZGluZ1xuICAgKiBAc2VlIHtAbGluayBCb3VuZHMjZml0fSBGb3IgY29uc3RyYWluaW5nIHNpemVcbiAgICovXG4gIHNjYWxlKHgsIHkgPSB4KSB7XG4gICAgdGhpcy5taW5YICo9IHg7XG4gICAgdGhpcy5taW5ZICo9IHk7XG4gICAgdGhpcy5tYXhYICo9IHg7XG4gICAgdGhpcy5tYXhZICo9IHk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSB4IHBvc2l0aW9uIG9mIHRoZSBib3VuZHMgaW4gbG9jYWwgc3BhY2UuXG4gICAqIFNldHRpbmcgdGhpcyB2YWx1ZSB3aWxsIG1vdmUgdGhlIGJvdW5kcyB3aGlsZSBtYWludGFpbmluZyBpdHMgd2lkdGguXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoMCwgMCwgMTAwLCAxMDApO1xuICAgKiAvLyBHZXQgeCBwb3NpdGlvblxuICAgKiBjb25zb2xlLmxvZyhib3VuZHMueCk7IC8vIDBcbiAgICpcbiAgICogLy8gTW92ZSBib3VuZHMgaG9yaXpvbnRhbGx5XG4gICAqIGJvdW5kcy54ID0gNTA7XG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5taW5YLCBib3VuZHMubWF4WCk7IC8vIDUwLCAxNTBcbiAgICpcbiAgICogLy8gV2lkdGggc3RheXMgdGhlIHNhbWVcbiAgICogY29uc29sZS5sb2coYm91bmRzLndpZHRoKTsgLy8gU3RpbGwgMTAwXG4gICAqIGBgYFxuICAgKi9cbiAgZ2V0IHgoKSB7XG4gICAgcmV0dXJuIHRoaXMubWluWDtcbiAgfVxuICBzZXQgeCh2YWx1ZSkge1xuICAgIGNvbnN0IHdpZHRoID0gdGhpcy5tYXhYIC0gdGhpcy5taW5YO1xuICAgIHRoaXMubWluWCA9IHZhbHVlO1xuICAgIHRoaXMubWF4WCA9IHZhbHVlICsgd2lkdGg7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSB5IHBvc2l0aW9uIG9mIHRoZSBib3VuZHMgaW4gbG9jYWwgc3BhY2UuXG4gICAqIFNldHRpbmcgdGhpcyB2YWx1ZSB3aWxsIG1vdmUgdGhlIGJvdW5kcyB3aGlsZSBtYWludGFpbmluZyBpdHMgaGVpZ2h0LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKDAsIDAsIDEwMCwgMTAwKTtcbiAgICogLy8gR2V0IHkgcG9zaXRpb25cbiAgICogY29uc29sZS5sb2coYm91bmRzLnkpOyAvLyAwXG4gICAqXG4gICAqIC8vIE1vdmUgYm91bmRzIHZlcnRpY2FsbHlcbiAgICogYm91bmRzLnkgPSA1MDtcbiAgICogY29uc29sZS5sb2coYm91bmRzLm1pblksIGJvdW5kcy5tYXhZKTsgLy8gNTAsIDE1MFxuICAgKlxuICAgKiAvLyBIZWlnaHQgc3RheXMgdGhlIHNhbWVcbiAgICogY29uc29sZS5sb2coYm91bmRzLmhlaWdodCk7IC8vIFN0aWxsIDEwMFxuICAgKiBgYGBcbiAgICovXG4gIGdldCB5KCkge1xuICAgIHJldHVybiB0aGlzLm1pblk7XG4gIH1cbiAgc2V0IHkodmFsdWUpIHtcbiAgICBjb25zdCBoZWlnaHQgPSB0aGlzLm1heFkgLSB0aGlzLm1pblk7XG4gICAgdGhpcy5taW5ZID0gdmFsdWU7XG4gICAgdGhpcy5tYXhZID0gdmFsdWUgKyBoZWlnaHQ7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSB3aWR0aCB2YWx1ZSBvZiB0aGUgYm91bmRzLlxuICAgKiBSZXByZXNlbnRzIHRoZSBkaXN0YW5jZSBiZXR3ZWVuIG1pblggYW5kIG1heFggY29vcmRpbmF0ZXMuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoMCwgMCwgMTAwLCAxMDApO1xuICAgKiAvLyBHZXQgd2lkdGhcbiAgICogY29uc29sZS5sb2coYm91bmRzLndpZHRoKTsgLy8gMTAwXG4gICAqIC8vIFJlc2l6ZSB3aWR0aFxuICAgKiBib3VuZHMud2lkdGggPSAyMDA7XG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5tYXhYIC0gYm91bmRzLm1pblgpOyAvLyAyMDBcbiAgICogYGBgXG4gICAqL1xuICBnZXQgd2lkdGgoKSB7XG4gICAgcmV0dXJuIHRoaXMubWF4WCAtIHRoaXMubWluWDtcbiAgfVxuICBzZXQgd2lkdGgodmFsdWUpIHtcbiAgICB0aGlzLm1heFggPSB0aGlzLm1pblggKyB2YWx1ZTtcbiAgfVxuICAvKipcbiAgICogVGhlIGhlaWdodCB2YWx1ZSBvZiB0aGUgYm91bmRzLlxuICAgKiBSZXByZXNlbnRzIHRoZSBkaXN0YW5jZSBiZXR3ZWVuIG1pblkgYW5kIG1heFkgY29vcmRpbmF0ZXMuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoMCwgMCwgMTAwLCAxMDApO1xuICAgKiAvLyBHZXQgaGVpZ2h0XG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5oZWlnaHQpOyAvLyAxMDBcbiAgICogLy8gUmVzaXplIGhlaWdodFxuICAgKiBib3VuZHMuaGVpZ2h0ID0gMTUwO1xuICAgKiBjb25zb2xlLmxvZyhib3VuZHMubWF4WSAtIGJvdW5kcy5taW5ZKTsgLy8gMTUwXG4gICAqIGBgYFxuICAgKi9cbiAgZ2V0IGhlaWdodCgpIHtcbiAgICByZXR1cm4gdGhpcy5tYXhZIC0gdGhpcy5taW5ZO1xuICB9XG4gIHNldCBoZWlnaHQodmFsdWUpIHtcbiAgICB0aGlzLm1heFkgPSB0aGlzLm1pblkgKyB2YWx1ZTtcbiAgfVxuICAvKipcbiAgICogVGhlIGxlZnQgZWRnZSBjb29yZGluYXRlIG9mIHRoZSBib3VuZHMuXG4gICAqIEFsaWFzIGZvciBtaW5YLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKDUwLCAwLCAxNTAsIDEwMCk7XG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5sZWZ0KTsgLy8gNTBcbiAgICogY29uc29sZS5sb2coYm91bmRzLmxlZnQgPT09IGJvdW5kcy5taW5YKTsgLy8gdHJ1ZVxuICAgKiBgYGBcbiAgICogQHJlYWRvbmx5XG4gICAqL1xuICBnZXQgbGVmdCgpIHtcbiAgICByZXR1cm4gdGhpcy5taW5YO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgcmlnaHQgZWRnZSBjb29yZGluYXRlIG9mIHRoZSBib3VuZHMuXG4gICAqIEFsaWFzIGZvciBtYXhYLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKDAsIDAsIDEwMCwgMTAwKTtcbiAgICogY29uc29sZS5sb2coYm91bmRzLnJpZ2h0KTsgLy8gMTAwXG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5yaWdodCA9PT0gYm91bmRzLm1heFgpOyAvLyB0cnVlXG4gICAqIGBgYFxuICAgKiBAcmVhZG9ubHlcbiAgICovXG4gIGdldCByaWdodCgpIHtcbiAgICByZXR1cm4gdGhpcy5tYXhYO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgdG9wIGVkZ2UgY29vcmRpbmF0ZSBvZiB0aGUgYm91bmRzLlxuICAgKiBBbGlhcyBmb3IgbWluWS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygwLCAyNSwgMTAwLCAxMjUpO1xuICAgKiBjb25zb2xlLmxvZyhib3VuZHMudG9wKTsgLy8gMjVcbiAgICogY29uc29sZS5sb2coYm91bmRzLnRvcCA9PT0gYm91bmRzLm1pblkpOyAvLyB0cnVlXG4gICAqIGBgYFxuICAgKiBAcmVhZG9ubHlcbiAgICovXG4gIGdldCB0b3AoKSB7XG4gICAgcmV0dXJuIHRoaXMubWluWTtcbiAgfVxuICAvKipcbiAgICogVGhlIGJvdHRvbSBlZGdlIGNvb3JkaW5hdGUgb2YgdGhlIGJvdW5kcy5cbiAgICogQWxpYXMgZm9yIG1heFkuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoMCwgMCwgMTAwLCAyMDApO1xuICAgKiBjb25zb2xlLmxvZyhib3VuZHMuYm90dG9tKTsgLy8gMjAwXG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5ib3R0b20gPT09IGJvdW5kcy5tYXhZKTsgLy8gdHJ1ZVxuICAgKiBgYGBcbiAgICogQHJlYWRvbmx5XG4gICAqL1xuICBnZXQgYm90dG9tKCkge1xuICAgIHJldHVybiB0aGlzLm1heFk7XG4gIH1cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIGJvdW5kcyBoYXMgcG9zaXRpdmUgd2lkdGggYW5kIGhlaWdodC5cbiAgICogQ2hlY2tzIGlmIGJvdGggZGltZW5zaW9ucyBhcmUgZ3JlYXRlciB0aGFuIHplcm8uXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGJvdW5kcyA9IG5ldyBCb3VuZHMoMCwgMCwgMTAwLCAxMDApO1xuICAgKiAvLyBDaGVjayBpZiBib3VuZHMgYXJlIHBvc2l0aXZlXG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5pc1Bvc2l0aXZlKTsgLy8gdHJ1ZVxuICAgKlxuICAgKiAvLyBOZWdhdGl2ZSBib3VuZHNcbiAgICogYm91bmRzLm1heFggPSBib3VuZHMubWluWDtcbiAgICogY29uc29sZS5sb2coYm91bmRzLmlzUG9zaXRpdmUpOyAvLyBmYWxzZSwgd2lkdGggaXMgMFxuICAgKiBgYGBcbiAgICogQHJlYWRvbmx5XG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNpc0VtcHR5fSBGb3IgY2hlY2tpbmcgZW1wdHkgc3RhdGVcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2lzVmFsaWR9IEZvciBjaGVja2luZyB2YWxpZGl0eVxuICAgKi9cbiAgZ2V0IGlzUG9zaXRpdmUoKSB7XG4gICAgcmV0dXJuIHRoaXMubWF4WCAtIHRoaXMubWluWCA+IDAgJiYgdGhpcy5tYXhZIC0gdGhpcy5taW5ZID4gMDtcbiAgfVxuICAvKipcbiAgICogV2hldGhlciB0aGUgYm91bmRzIGhhcyB2YWxpZCBjb29yZGluYXRlcy5cbiAgICogQ2hlY2tzIGlmIHRoZSBib3VuZHMgaGFzIGJlZW4gaW5pdGlhbGl6ZWQgd2l0aCByZWFsIHZhbHVlcy5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygpO1xuICAgKiBjb25zb2xlLmxvZyhib3VuZHMuaXNWYWxpZCk7IC8vIGZhbHNlLCBkZWZhdWx0IHN0YXRlXG4gICAqXG4gICAqIC8vIFNldCB2YWxpZCBib3VuZHNcbiAgICogYm91bmRzLmFkZEZyYW1lKDAsIDAsIDEwMCwgMTAwKTtcbiAgICogY29uc29sZS5sb2coYm91bmRzLmlzVmFsaWQpOyAvLyB0cnVlXG4gICAqIGBgYFxuICAgKiBAcmVhZG9ubHlcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2lzRW1wdHl9IEZvciBjaGVja2luZyBlbXB0eSBzdGF0ZVxuICAgKiBAc2VlIHtAbGluayBCb3VuZHMjaXNQb3NpdGl2ZX0gRm9yIGNoZWNraW5nIGRpbWVuc2lvbnNcbiAgICovXG4gIGdldCBpc1ZhbGlkKCkge1xuICAgIHJldHVybiB0aGlzLm1pblggKyB0aGlzLm1pblkgIT09IEluZmluaXR5O1xuICB9XG4gIC8qKlxuICAgKiBBZGRzIHZlcnRpY2VzIGZyb20gYSBGbG9hdDMyQXJyYXkgdG8gdGhlIGJvdW5kcywgb3B0aW9uYWxseSB0cmFuc2Zvcm1lZCBieSBhIG1hdHJpeC5cbiAgICogVXNlZCBmb3IgZWZmaWNpZW50bHkgdXBkYXRpbmcgYm91bmRzIGZyb20gcmF3IHZlcnRleCBkYXRhLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBib3VuZHMgPSBuZXcgQm91bmRzKCk7XG4gICAqXG4gICAqIC8vIEFkZCB2ZXJ0aWNlcyBmcm9tIGdlb21ldHJ5XG4gICAqIGNvbnN0IHZlcnRpY2VzID0gbmV3IEZsb2F0MzJBcnJheShbXG4gICAqICAgICAwLCAwLCAgICAvLyBWZXJ0ZXggMVxuICAgKiAgICAgMTAwLCAwLCAgLy8gVmVydGV4IDJcbiAgICogICAgIDEwMCwgMTAwIC8vIFZlcnRleCAzXG4gICAqIF0pO1xuICAgKiBib3VuZHMuYWRkVmVydGV4RGF0YSh2ZXJ0aWNlcywgMCwgNik7XG4gICAqXG4gICAqIC8vIEFkZCB0cmFuc2Zvcm1lZCB2ZXJ0aWNlc1xuICAgKiBjb25zdCBtYXRyaXggPSBuZXcgTWF0cml4KClcbiAgICogICAgIC50cmFuc2xhdGUoNTAsIDUwKVxuICAgKiAgICAgLnJvdGF0ZShNYXRoLlBJIC8gNCk7XG4gICAqIGJvdW5kcy5hZGRWZXJ0ZXhEYXRhKHZlcnRpY2VzLCAwLCA2LCBtYXRyaXgpO1xuICAgKlxuICAgKiAvLyBBZGQgc3Vic2V0IG9mIHZlcnRpY2VzXG4gICAqIGJvdW5kcy5hZGRWZXJ0ZXhEYXRhKHZlcnRpY2VzLCAyLCA0KTsgLy8gT25seSBzZWNvbmQgdmVydGV4XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gdmVydGV4RGF0YSAtIFRoZSBhcnJheSBvZiB2ZXJ0aWNlcyB0byBhZGRcbiAgICogQHBhcmFtIGJlZ2luT2Zmc2V0IC0gU3RhcnRpbmcgaW5kZXggaW4gdGhlIHZlcnRleCBhcnJheVxuICAgKiBAcGFyYW0gZW5kT2Zmc2V0IC0gRW5kaW5nIGluZGV4IGluIHRoZSB2ZXJ0ZXggYXJyYXkgKGV4Y2x1ZGVkKVxuICAgKiBAcGFyYW0gbWF0cml4IC0gT3B0aW9uYWwgdHJhbnNmb3JtYXRpb24gbWF0cml4XG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNhZGRGcmFtZX0gRm9yIGFkZGluZyByZWN0YW5ndWxhciBmcmFtZXNcbiAgICogQHNlZSB7QGxpbmsgTWF0cml4fSBGb3IgdHJhbnNmb3JtYXRpb24gZGV0YWlsc1xuICAgKi9cbiAgYWRkVmVydGV4RGF0YSh2ZXJ0ZXhEYXRhLCBiZWdpbk9mZnNldCwgZW5kT2Zmc2V0LCBtYXRyaXgpIHtcbiAgICBsZXQgbWluWCA9IHRoaXMubWluWDtcbiAgICBsZXQgbWluWSA9IHRoaXMubWluWTtcbiAgICBsZXQgbWF4WCA9IHRoaXMubWF4WDtcbiAgICBsZXQgbWF4WSA9IHRoaXMubWF4WTtcbiAgICBtYXRyaXggfHwgKG1hdHJpeCA9IHRoaXMubWF0cml4KTtcbiAgICBjb25zdCBhID0gbWF0cml4LmE7XG4gICAgY29uc3QgYiA9IG1hdHJpeC5iO1xuICAgIGNvbnN0IGMgPSBtYXRyaXguYztcbiAgICBjb25zdCBkID0gbWF0cml4LmQ7XG4gICAgY29uc3QgdHggPSBtYXRyaXgudHg7XG4gICAgY29uc3QgdHkgPSBtYXRyaXgudHk7XG4gICAgZm9yIChsZXQgaSA9IGJlZ2luT2Zmc2V0OyBpIDwgZW5kT2Zmc2V0OyBpICs9IDIpIHtcbiAgICAgIGNvbnN0IGxvY2FsWCA9IHZlcnRleERhdGFbaV07XG4gICAgICBjb25zdCBsb2NhbFkgPSB2ZXJ0ZXhEYXRhW2kgKyAxXTtcbiAgICAgIGNvbnN0IHggPSBhICogbG9jYWxYICsgYyAqIGxvY2FsWSArIHR4O1xuICAgICAgY29uc3QgeSA9IGIgKiBsb2NhbFggKyBkICogbG9jYWxZICsgdHk7XG4gICAgICBtaW5YID0geCA8IG1pblggPyB4IDogbWluWDtcbiAgICAgIG1pblkgPSB5IDwgbWluWSA/IHkgOiBtaW5ZO1xuICAgICAgbWF4WCA9IHggPiBtYXhYID8geCA6IG1heFg7XG4gICAgICBtYXhZID0geSA+IG1heFkgPyB5IDogbWF4WTtcbiAgICB9XG4gICAgdGhpcy5taW5YID0gbWluWDtcbiAgICB0aGlzLm1pblkgPSBtaW5ZO1xuICAgIHRoaXMubWF4WCA9IG1heFg7XG4gICAgdGhpcy5tYXhZID0gbWF4WTtcbiAgfVxuICAvKipcbiAgICogQ2hlY2tzIGlmIGEgcG9pbnQgaXMgY29udGFpbmVkIHdpdGhpbiB0aGUgYm91bmRzLlxuICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIHBvaW50J3MgY29vcmRpbmF0ZXMgZmFsbCB3aXRoaW4gdGhlIGJvdW5kcycgYXJlYS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygwLCAwLCAxMDAsIDEwMCk7XG4gICAqIC8vIEJhc2ljIHBvaW50IGNoZWNrXG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5jb250YWluc1BvaW50KDUwLCA1MCkpOyAvLyB0cnVlXG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5jb250YWluc1BvaW50KDE1MCwgMTUwKSk7IC8vIGZhbHNlXG4gICAqXG4gICAqIC8vIENoZWNrIGVkZ2VzXG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy5jb250YWluc1BvaW50KDAsIDApKTsgICAvLyB0cnVlLCBpbmNsdWRlcyBlZGdlc1xuICAgKiBjb25zb2xlLmxvZyhib3VuZHMuY29udGFpbnNQb2ludCgxMDAsIDEwMCkpOyAvLyB0cnVlLCBpbmNsdWRlcyBlZGdlc1xuICAgKiBgYGBcbiAgICogQHBhcmFtIHggLSB4IGNvb3JkaW5hdGUgdG8gY2hlY2tcbiAgICogQHBhcmFtIHkgLSB5IGNvb3JkaW5hdGUgdG8gY2hlY2tcbiAgICogQHJldHVybnMgVHJ1ZSBpZiB0aGUgcG9pbnQgaXMgaW5zaWRlIHRoZSBib3VuZHNcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI2lzUG9zaXRpdmV9IEZvciB2YWxpZCBib3VuZHMgY2hlY2tcbiAgICogQHNlZSB7QGxpbmsgQm91bmRzI3JlY3RhbmdsZX0gRm9yIFJlY3RhbmdsZSByZXByZXNlbnRhdGlvblxuICAgKi9cbiAgY29udGFpbnNQb2ludCh4LCB5KSB7XG4gICAgaWYgKHRoaXMubWluWCA8PSB4ICYmIHRoaXMubWluWSA8PSB5ICYmIHRoaXMubWF4WCA+PSB4ICYmIHRoaXMubWF4WSA+PSB5KSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBib3VuZHMuXG4gICAqIFVzZWZ1bCBmb3IgZGVidWdnaW5nIGFuZCBsb2dnaW5nIGJvdW5kcyBpbmZvcm1hdGlvbi5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3QgYm91bmRzID0gbmV3IEJvdW5kcygwLCAwLCAxMDAsIDEwMCk7XG4gICAqIGNvbnNvbGUubG9nKGJvdW5kcy50b1N0cmluZygpKTsgLy8gXCJbcGl4aS5qczpCb3VuZHMgbWluWD0wIG1pblk9MCBtYXhYPTEwMCBtYXhZPTEwMCB3aWR0aD0xMDAgaGVpZ2h0PTEwMF1cIlxuICAgKiBgYGBcbiAgICogQHJldHVybnMgQSBzdHJpbmcgZGVzY3JpYmluZyB0aGUgYm91bmRzXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNjb3B5RnJvbX0gRm9yIGNvcHlpbmcgYm91bmRzXG4gICAqIEBzZWUge0BsaW5rIEJvdW5kcyNjbG9uZX0gRm9yIGNyZWF0aW5nIGEgbmV3IGluc3RhbmNlXG4gICAqL1xuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYFtwaXhpLmpzOkJvdW5kcyBtaW5YPSR7dGhpcy5taW5YfSBtaW5ZPSR7dGhpcy5taW5ZfSBtYXhYPSR7dGhpcy5tYXhYfSBtYXhZPSR7dGhpcy5tYXhZfSB3aWR0aD0ke3RoaXMud2lkdGh9IGhlaWdodD0ke3RoaXMuaGVpZ2h0fV1gO1xuICB9XG4gIC8qKlxuICAgKiBDb3BpZXMgdGhlIGJvdW5kcyBmcm9tIGFub3RoZXIgYm91bmRzIG9iamVjdC5cbiAgICogVXNlZnVsIGZvciByZXVzaW5nIGJvdW5kcyBvYmplY3RzIGFuZCBhdm9pZGluZyBhbGxvY2F0aW9ucy5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29uc3Qgc291cmNlQm91bmRzID0gbmV3IEJvdW5kcygwLCAwLCAxMDAsIDEwMCk7XG4gICAqIC8vIENvcHkgYm91bmRzXG4gICAqIGNvbnN0IHRhcmdldEJvdW5kcyA9IG5ldyBCb3VuZHMoKTtcbiAgICogdGFyZ2V0Qm91bmRzLmNvcHlGcm9tKHNvdXJjZUJvdW5kcyk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gYm91bmRzIC0gVGhlIGJvdW5kcyB0byBjb3B5IGZyb21cbiAgICogQHJldHVybnMgVGhpcyBib3VuZHMgb2JqZWN0IGZvciBjaGFpbmluZ1xuICAgKiBAc2VlIHtAbGluayBCb3VuZHMjY2xvbmV9IEZvciBjcmVhdGluZyBuZXcgaW5zdGFuY2VzXG4gICAqL1xuICBjb3B5RnJvbShib3VuZHMpIHtcbiAgICB0aGlzLm1pblggPSBib3VuZHMubWluWDtcbiAgICB0aGlzLm1pblkgPSBib3VuZHMubWluWTtcbiAgICB0aGlzLm1heFggPSBib3VuZHMubWF4WDtcbiAgICB0aGlzLm1heFkgPSBib3VuZHMubWF4WTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxufVxuXG5leHBvcnQgeyBCb3VuZHMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUJvdW5kcy5tanMubWFwXG4iLCJ2YXIgcj17Z3JhZDouOSx0dXJuOjM2MCxyYWQ6MzYwLygyKk1hdGguUEkpfSx0PWZ1bmN0aW9uKHIpe3JldHVyblwic3RyaW5nXCI9PXR5cGVvZiByP3IubGVuZ3RoPjA6XCJudW1iZXJcIj09dHlwZW9mIHJ9LG49ZnVuY3Rpb24ocix0LG4pe3JldHVybiB2b2lkIDA9PT10JiYodD0wKSx2b2lkIDA9PT1uJiYobj1NYXRoLnBvdygxMCx0KSksTWF0aC5yb3VuZChuKnIpL24rMH0sZT1mdW5jdGlvbihyLHQsbil7cmV0dXJuIHZvaWQgMD09PXQmJih0PTApLHZvaWQgMD09PW4mJihuPTEpLHI+bj9uOnI+dD9yOnR9LHU9ZnVuY3Rpb24ocil7cmV0dXJuKHI9aXNGaW5pdGUocik/ciUzNjA6MCk+MD9yOnIrMzYwfSxhPWZ1bmN0aW9uKHIpe3JldHVybntyOmUoci5yLDAsMjU1KSxnOmUoci5nLDAsMjU1KSxiOmUoci5iLDAsMjU1KSxhOmUoci5hKX19LG89ZnVuY3Rpb24ocil7cmV0dXJue3I6bihyLnIpLGc6bihyLmcpLGI6bihyLmIpLGE6bihyLmEsMyl9fSxpPS9eIyhbMC05YS1mXXszLDh9KSQvaSxzPWZ1bmN0aW9uKHIpe3ZhciB0PXIudG9TdHJpbmcoMTYpO3JldHVybiB0Lmxlbmd0aDwyP1wiMFwiK3Q6dH0saD1mdW5jdGlvbihyKXt2YXIgdD1yLnIsbj1yLmcsZT1yLmIsdT1yLmEsYT1NYXRoLm1heCh0LG4sZSksbz1hLU1hdGgubWluKHQsbixlKSxpPW8/YT09PXQ/KG4tZSkvbzphPT09bj8yKyhlLXQpL286NCsodC1uKS9vOjA7cmV0dXJue2g6NjAqKGk8MD9pKzY6aSksczphP28vYSoxMDA6MCx2OmEvMjU1KjEwMCxhOnV9fSxiPWZ1bmN0aW9uKHIpe3ZhciB0PXIuaCxuPXIucyxlPXIudix1PXIuYTt0PXQvMzYwKjYsbi89MTAwLGUvPTEwMDt2YXIgYT1NYXRoLmZsb29yKHQpLG89ZSooMS1uKSxpPWUqKDEtKHQtYSkqbikscz1lKigxLSgxLXQrYSkqbiksaD1hJTY7cmV0dXJue3I6MjU1KltlLGksbyxvLHMsZV1baF0sZzoyNTUqW3MsZSxlLGksbyxvXVtoXSxiOjI1NSpbbyxvLHMsZSxlLGldW2hdLGE6dX19LGc9ZnVuY3Rpb24ocil7cmV0dXJue2g6dShyLmgpLHM6ZShyLnMsMCwxMDApLGw6ZShyLmwsMCwxMDApLGE6ZShyLmEpfX0sZD1mdW5jdGlvbihyKXtyZXR1cm57aDpuKHIuaCksczpuKHIucyksbDpuKHIubCksYTpuKHIuYSwzKX19LGY9ZnVuY3Rpb24ocil7cmV0dXJuIGIoKG49KHQ9cikucyx7aDp0Lmgsczoobio9KChlPXQubCk8NTA/ZToxMDAtZSkvMTAwKT4wPzIqbi8oZStuKSoxMDA6MCx2OmUrbixhOnQuYX0pKTt2YXIgdCxuLGV9LGM9ZnVuY3Rpb24ocil7cmV0dXJue2g6KHQ9aChyKSkuaCxzOih1PSgyMDAtKG49dC5zKSkqKGU9dC52KS8xMDApPjAmJnU8MjAwP24qZS8xMDAvKHU8PTEwMD91OjIwMC11KSoxMDA6MCxsOnUvMixhOnQuYX07dmFyIHQsbixlLHV9LGw9L15oc2xhP1xcKFxccyooWystXT9cXGQqXFwuP1xcZCspKGRlZ3xyYWR8Z3JhZHx0dXJuKT9cXHMqLFxccyooWystXT9cXGQqXFwuP1xcZCspJVxccyosXFxzKihbKy1dP1xcZCpcXC4/XFxkKyklXFxzKig/OixcXHMqKFsrLV0/XFxkKlxcLj9cXGQrKSglKT9cXHMqKT9cXCkkL2kscD0vXmhzbGE/XFwoXFxzKihbKy1dP1xcZCpcXC4/XFxkKykoZGVnfHJhZHxncmFkfHR1cm4pP1xccysoWystXT9cXGQqXFwuP1xcZCspJVxccysoWystXT9cXGQqXFwuP1xcZCspJVxccyooPzpcXC9cXHMqKFsrLV0/XFxkKlxcLj9cXGQrKSglKT9cXHMqKT9cXCkkL2ksdj0vXnJnYmE/XFwoXFxzKihbKy1dP1xcZCpcXC4/XFxkKykoJSk/XFxzKixcXHMqKFsrLV0/XFxkKlxcLj9cXGQrKSglKT9cXHMqLFxccyooWystXT9cXGQqXFwuP1xcZCspKCUpP1xccyooPzosXFxzKihbKy1dP1xcZCpcXC4/XFxkKykoJSk/XFxzKik/XFwpJC9pLG09L15yZ2JhP1xcKFxccyooWystXT9cXGQqXFwuP1xcZCspKCUpP1xccysoWystXT9cXGQqXFwuP1xcZCspKCUpP1xccysoWystXT9cXGQqXFwuP1xcZCspKCUpP1xccyooPzpcXC9cXHMqKFsrLV0/XFxkKlxcLj9cXGQrKSglKT9cXHMqKT9cXCkkL2kseT17c3RyaW5nOltbZnVuY3Rpb24ocil7dmFyIHQ9aS5leGVjKHIpO3JldHVybiB0PyhyPXRbMV0pLmxlbmd0aDw9ND97cjpwYXJzZUludChyWzBdK3JbMF0sMTYpLGc6cGFyc2VJbnQoclsxXStyWzFdLDE2KSxiOnBhcnNlSW50KHJbMl0rclsyXSwxNiksYTo0PT09ci5sZW5ndGg/bihwYXJzZUludChyWzNdK3JbM10sMTYpLzI1NSwyKToxfTo2PT09ci5sZW5ndGh8fDg9PT1yLmxlbmd0aD97cjpwYXJzZUludChyLnN1YnN0cigwLDIpLDE2KSxnOnBhcnNlSW50KHIuc3Vic3RyKDIsMiksMTYpLGI6cGFyc2VJbnQoci5zdWJzdHIoNCwyKSwxNiksYTo4PT09ci5sZW5ndGg/bihwYXJzZUludChyLnN1YnN0cig2LDIpLDE2KS8yNTUsMik6MX06bnVsbDpudWxsfSxcImhleFwiXSxbZnVuY3Rpb24ocil7dmFyIHQ9di5leGVjKHIpfHxtLmV4ZWMocik7cmV0dXJuIHQ/dFsyXSE9PXRbNF18fHRbNF0hPT10WzZdP251bGw6YSh7cjpOdW1iZXIodFsxXSkvKHRbMl0/MTAwLzI1NToxKSxnOk51bWJlcih0WzNdKS8odFs0XT8xMDAvMjU1OjEpLGI6TnVtYmVyKHRbNV0pLyh0WzZdPzEwMC8yNTU6MSksYTp2b2lkIDA9PT10WzddPzE6TnVtYmVyKHRbN10pLyh0WzhdPzEwMDoxKX0pOm51bGx9LFwicmdiXCJdLFtmdW5jdGlvbih0KXt2YXIgbj1sLmV4ZWModCl8fHAuZXhlYyh0KTtpZighbilyZXR1cm4gbnVsbDt2YXIgZSx1LGE9Zyh7aDooZT1uWzFdLHU9blsyXSx2b2lkIDA9PT11JiYodT1cImRlZ1wiKSxOdW1iZXIoZSkqKHJbdV18fDEpKSxzOk51bWJlcihuWzNdKSxsOk51bWJlcihuWzRdKSxhOnZvaWQgMD09PW5bNV0/MTpOdW1iZXIobls1XSkvKG5bNl0/MTAwOjEpfSk7cmV0dXJuIGYoYSl9LFwiaHNsXCJdXSxvYmplY3Q6W1tmdW5jdGlvbihyKXt2YXIgbj1yLnIsZT1yLmcsdT1yLmIsbz1yLmEsaT12b2lkIDA9PT1vPzE6bztyZXR1cm4gdChuKSYmdChlKSYmdCh1KT9hKHtyOk51bWJlcihuKSxnOk51bWJlcihlKSxiOk51bWJlcih1KSxhOk51bWJlcihpKX0pOm51bGx9LFwicmdiXCJdLFtmdW5jdGlvbihyKXt2YXIgbj1yLmgsZT1yLnMsdT1yLmwsYT1yLmEsbz12b2lkIDA9PT1hPzE6YTtpZighdChuKXx8IXQoZSl8fCF0KHUpKXJldHVybiBudWxsO3ZhciBpPWcoe2g6TnVtYmVyKG4pLHM6TnVtYmVyKGUpLGw6TnVtYmVyKHUpLGE6TnVtYmVyKG8pfSk7cmV0dXJuIGYoaSl9LFwiaHNsXCJdLFtmdW5jdGlvbihyKXt2YXIgbj1yLmgsYT1yLnMsbz1yLnYsaT1yLmEscz12b2lkIDA9PT1pPzE6aTtpZighdChuKXx8IXQoYSl8fCF0KG8pKXJldHVybiBudWxsO3ZhciBoPWZ1bmN0aW9uKHIpe3JldHVybntoOnUoci5oKSxzOmUoci5zLDAsMTAwKSx2OmUoci52LDAsMTAwKSxhOmUoci5hKX19KHtoOk51bWJlcihuKSxzOk51bWJlcihhKSx2Ok51bWJlcihvKSxhOk51bWJlcihzKX0pO3JldHVybiBiKGgpfSxcImhzdlwiXV19LE49ZnVuY3Rpb24ocix0KXtmb3IodmFyIG49MDtuPHQubGVuZ3RoO24rKyl7dmFyIGU9dFtuXVswXShyKTtpZihlKXJldHVybltlLHRbbl1bMV1dfXJldHVybltudWxsLHZvaWQgMF19LHg9ZnVuY3Rpb24ocil7cmV0dXJuXCJzdHJpbmdcIj09dHlwZW9mIHI/TihyLnRyaW0oKSx5LnN0cmluZyk6XCJvYmplY3RcIj09dHlwZW9mIHImJm51bGwhPT1yP04ocix5Lm9iamVjdCk6W251bGwsdm9pZCAwXX0sST1mdW5jdGlvbihyKXtyZXR1cm4geChyKVsxXX0sTT1mdW5jdGlvbihyLHQpe3ZhciBuPWMocik7cmV0dXJue2g6bi5oLHM6ZShuLnMrMTAwKnQsMCwxMDApLGw6bi5sLGE6bi5hfX0sSD1mdW5jdGlvbihyKXtyZXR1cm4oMjk5KnIucis1ODcqci5nKzExNCpyLmIpLzFlMy8yNTV9LCQ9ZnVuY3Rpb24ocix0KXt2YXIgbj1jKHIpO3JldHVybntoOm4uaCxzOm4ucyxsOmUobi5sKzEwMCp0LDAsMTAwKSxhOm4uYX19LGo9ZnVuY3Rpb24oKXtmdW5jdGlvbiByKHIpe3RoaXMucGFyc2VkPXgocilbMF0sdGhpcy5yZ2JhPXRoaXMucGFyc2VkfHx7cjowLGc6MCxiOjAsYToxfX1yZXR1cm4gci5wcm90b3R5cGUuaXNWYWxpZD1mdW5jdGlvbigpe3JldHVybiBudWxsIT09dGhpcy5wYXJzZWR9LHIucHJvdG90eXBlLmJyaWdodG5lc3M9ZnVuY3Rpb24oKXtyZXR1cm4gbihIKHRoaXMucmdiYSksMil9LHIucHJvdG90eXBlLmlzRGFyaz1mdW5jdGlvbigpe3JldHVybiBIKHRoaXMucmdiYSk8LjV9LHIucHJvdG90eXBlLmlzTGlnaHQ9ZnVuY3Rpb24oKXtyZXR1cm4gSCh0aGlzLnJnYmEpPj0uNX0sci5wcm90b3R5cGUudG9IZXg9ZnVuY3Rpb24oKXtyZXR1cm4gcj1vKHRoaXMucmdiYSksdD1yLnIsZT1yLmcsdT1yLmIsaT0oYT1yLmEpPDE/cyhuKDI1NSphKSk6XCJcIixcIiNcIitzKHQpK3MoZSkrcyh1KStpO3ZhciByLHQsZSx1LGEsaX0sci5wcm90b3R5cGUudG9SZ2I9ZnVuY3Rpb24oKXtyZXR1cm4gbyh0aGlzLnJnYmEpfSxyLnByb3RvdHlwZS50b1JnYlN0cmluZz1mdW5jdGlvbigpe3JldHVybiByPW8odGhpcy5yZ2JhKSx0PXIucixuPXIuZyxlPXIuYiwodT1yLmEpPDE/XCJyZ2JhKFwiK3QrXCIsIFwiK24rXCIsIFwiK2UrXCIsIFwiK3UrXCIpXCI6XCJyZ2IoXCIrdCtcIiwgXCIrbitcIiwgXCIrZStcIilcIjt2YXIgcix0LG4sZSx1fSxyLnByb3RvdHlwZS50b0hzbD1mdW5jdGlvbigpe3JldHVybiBkKGModGhpcy5yZ2JhKSl9LHIucHJvdG90eXBlLnRvSHNsU3RyaW5nPWZ1bmN0aW9uKCl7cmV0dXJuIHI9ZChjKHRoaXMucmdiYSkpLHQ9ci5oLG49ci5zLGU9ci5sLCh1PXIuYSk8MT9cImhzbGEoXCIrdCtcIiwgXCIrbitcIiUsIFwiK2UrXCIlLCBcIit1K1wiKVwiOlwiaHNsKFwiK3QrXCIsIFwiK24rXCIlLCBcIitlK1wiJSlcIjt2YXIgcix0LG4sZSx1fSxyLnByb3RvdHlwZS50b0hzdj1mdW5jdGlvbigpe3JldHVybiByPWgodGhpcy5yZ2JhKSx7aDpuKHIuaCksczpuKHIucyksdjpuKHIudiksYTpuKHIuYSwzKX07dmFyIHJ9LHIucHJvdG90eXBlLmludmVydD1mdW5jdGlvbigpe3JldHVybiB3KHtyOjI1NS0ocj10aGlzLnJnYmEpLnIsZzoyNTUtci5nLGI6MjU1LXIuYixhOnIuYX0pO3ZhciByfSxyLnByb3RvdHlwZS5zYXR1cmF0ZT1mdW5jdGlvbihyKXtyZXR1cm4gdm9pZCAwPT09ciYmKHI9LjEpLHcoTSh0aGlzLnJnYmEscikpfSxyLnByb3RvdHlwZS5kZXNhdHVyYXRlPWZ1bmN0aW9uKHIpe3JldHVybiB2b2lkIDA9PT1yJiYocj0uMSksdyhNKHRoaXMucmdiYSwtcikpfSxyLnByb3RvdHlwZS5ncmF5c2NhbGU9ZnVuY3Rpb24oKXtyZXR1cm4gdyhNKHRoaXMucmdiYSwtMSkpfSxyLnByb3RvdHlwZS5saWdodGVuPWZ1bmN0aW9uKHIpe3JldHVybiB2b2lkIDA9PT1yJiYocj0uMSksdygkKHRoaXMucmdiYSxyKSl9LHIucHJvdG90eXBlLmRhcmtlbj1mdW5jdGlvbihyKXtyZXR1cm4gdm9pZCAwPT09ciYmKHI9LjEpLHcoJCh0aGlzLnJnYmEsLXIpKX0sci5wcm90b3R5cGUucm90YXRlPWZ1bmN0aW9uKHIpe3JldHVybiB2b2lkIDA9PT1yJiYocj0xNSksdGhpcy5odWUodGhpcy5odWUoKStyKX0sci5wcm90b3R5cGUuYWxwaGE9ZnVuY3Rpb24ocil7cmV0dXJuXCJudW1iZXJcIj09dHlwZW9mIHI/dyh7cjoodD10aGlzLnJnYmEpLnIsZzp0LmcsYjp0LmIsYTpyfSk6bih0aGlzLnJnYmEuYSwzKTt2YXIgdH0sci5wcm90b3R5cGUuaHVlPWZ1bmN0aW9uKHIpe3ZhciB0PWModGhpcy5yZ2JhKTtyZXR1cm5cIm51bWJlclwiPT10eXBlb2Ygcj93KHtoOnIsczp0LnMsbDp0LmwsYTp0LmF9KTpuKHQuaCl9LHIucHJvdG90eXBlLmlzRXF1YWw9ZnVuY3Rpb24ocil7cmV0dXJuIHRoaXMudG9IZXgoKT09PXcocikudG9IZXgoKX0scn0oKSx3PWZ1bmN0aW9uKHIpe3JldHVybiByIGluc3RhbmNlb2Ygaj9yOm5ldyBqKHIpfSxTPVtdLGs9ZnVuY3Rpb24ocil7ci5mb3JFYWNoKGZ1bmN0aW9uKHIpe1MuaW5kZXhPZihyKTwwJiYocihqLHkpLFMucHVzaChyKSl9KX0sRT1mdW5jdGlvbigpe3JldHVybiBuZXcgaih7cjoyNTUqTWF0aC5yYW5kb20oKSxnOjI1NSpNYXRoLnJhbmRvbSgpLGI6MjU1Kk1hdGgucmFuZG9tKCl9KX07ZXhwb3J0e2ogYXMgQ29sb3JkLHcgYXMgY29sb3JkLGsgYXMgZXh0ZW5kLEkgYXMgZ2V0Rm9ybWF0LEUgYXMgcmFuZG9tfTtcbiIsImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uKGUsZil7dmFyIGE9e3doaXRlOlwiI2ZmZmZmZlwiLGJpc3F1ZTpcIiNmZmU0YzRcIixibHVlOlwiIzAwMDBmZlwiLGNhZGV0Ymx1ZTpcIiM1ZjllYTBcIixjaGFydHJldXNlOlwiIzdmZmYwMFwiLGNob2NvbGF0ZTpcIiNkMjY5MWVcIixjb3JhbDpcIiNmZjdmNTBcIixhbnRpcXVld2hpdGU6XCIjZmFlYmQ3XCIsYXF1YTpcIiMwMGZmZmZcIixhenVyZTpcIiNmMGZmZmZcIix3aGl0ZXNtb2tlOlwiI2Y1ZjVmNVwiLHBhcGF5YXdoaXA6XCIjZmZlZmQ1XCIscGx1bTpcIiNkZGEwZGRcIixibGFuY2hlZGFsbW9uZDpcIiNmZmViY2RcIixibGFjazpcIiMwMDAwMDBcIixnb2xkOlwiI2ZmZDcwMFwiLGdvbGRlbnJvZDpcIiNkYWE1MjBcIixnYWluc2Jvcm86XCIjZGNkY2RjXCIsY29ybnNpbGs6XCIjZmZmOGRjXCIsY29ybmZsb3dlcmJsdWU6XCIjNjQ5NWVkXCIsYnVybHl3b29kOlwiI2RlYjg4N1wiLGFxdWFtYXJpbmU6XCIjN2ZmZmQ0XCIsYmVpZ2U6XCIjZjVmNWRjXCIsY3JpbXNvbjpcIiNkYzE0M2NcIixjeWFuOlwiIzAwZmZmZlwiLGRhcmtibHVlOlwiIzAwMDA4YlwiLGRhcmtjeWFuOlwiIzAwOGI4YlwiLGRhcmtnb2xkZW5yb2Q6XCIjYjg4NjBiXCIsZGFya2toYWtpOlwiI2JkYjc2YlwiLGRhcmtncmF5OlwiI2E5YTlhOVwiLGRhcmtncmVlbjpcIiMwMDY0MDBcIixkYXJrZ3JleTpcIiNhOWE5YTlcIixwZWFjaHB1ZmY6XCIjZmZkYWI5XCIsZGFya21hZ2VudGE6XCIjOGIwMDhiXCIsZGFya3JlZDpcIiM4YjAwMDBcIixkYXJrb3JjaGlkOlwiIzk5MzJjY1wiLGRhcmtvcmFuZ2U6XCIjZmY4YzAwXCIsZGFya3NsYXRlYmx1ZTpcIiM0ODNkOGJcIixncmF5OlwiIzgwODA4MFwiLGRhcmtzbGF0ZWdyYXk6XCIjMmY0ZjRmXCIsZGFya3NsYXRlZ3JleTpcIiMyZjRmNGZcIixkZWVwcGluazpcIiNmZjE0OTNcIixkZWVwc2t5Ymx1ZTpcIiMwMGJmZmZcIix3aGVhdDpcIiNmNWRlYjNcIixmaXJlYnJpY2s6XCIjYjIyMjIyXCIsZmxvcmFsd2hpdGU6XCIjZmZmYWYwXCIsZ2hvc3R3aGl0ZTpcIiNmOGY4ZmZcIixkYXJrdmlvbGV0OlwiIzk0MDBkM1wiLG1hZ2VudGE6XCIjZmYwMGZmXCIsZ3JlZW46XCIjMDA4MDAwXCIsZG9kZ2VyYmx1ZTpcIiMxZTkwZmZcIixncmV5OlwiIzgwODA4MFwiLGhvbmV5ZGV3OlwiI2YwZmZmMFwiLGhvdHBpbms6XCIjZmY2OWI0XCIsYmx1ZXZpb2xldDpcIiM4YTJiZTJcIixmb3Jlc3RncmVlbjpcIiMyMjhiMjJcIixsYXduZ3JlZW46XCIjN2NmYzAwXCIsaW5kaWFucmVkOlwiI2NkNWM1Y1wiLGluZGlnbzpcIiM0YjAwODJcIixmdWNoc2lhOlwiI2ZmMDBmZlwiLGJyb3duOlwiI2E1MmEyYVwiLG1hcm9vbjpcIiM4MDAwMDBcIixtZWRpdW1ibHVlOlwiIzAwMDBjZFwiLGxpZ2h0Y29yYWw6XCIjZjA4MDgwXCIsZGFya3R1cnF1b2lzZTpcIiMwMGNlZDFcIixsaWdodGN5YW46XCIjZTBmZmZmXCIsaXZvcnk6XCIjZmZmZmYwXCIsbGlnaHR5ZWxsb3c6XCIjZmZmZmUwXCIsbGlnaHRzYWxtb246XCIjZmZhMDdhXCIsbGlnaHRzZWFncmVlbjpcIiMyMGIyYWFcIixsaW5lbjpcIiNmYWYwZTZcIixtZWRpdW1hcXVhbWFyaW5lOlwiIzY2Y2RhYVwiLGxlbW9uY2hpZmZvbjpcIiNmZmZhY2RcIixsaW1lOlwiIzAwZmYwMFwiLGtoYWtpOlwiI2YwZTY4Y1wiLG1lZGl1bXNlYWdyZWVuOlwiIzNjYjM3MVwiLGxpbWVncmVlbjpcIiMzMmNkMzJcIixtZWRpdW1zcHJpbmdncmVlbjpcIiMwMGZhOWFcIixsaWdodHNreWJsdWU6XCIjODdjZWZhXCIsbGlnaHRibHVlOlwiI2FkZDhlNlwiLG1pZG5pZ2h0Ymx1ZTpcIiMxOTE5NzBcIixsaWdodHBpbms6XCIjZmZiNmMxXCIsbWlzdHlyb3NlOlwiI2ZmZTRlMVwiLG1vY2Nhc2luOlwiI2ZmZTRiNVwiLG1pbnRjcmVhbTpcIiNmNWZmZmFcIixsaWdodHNsYXRlZ3JheTpcIiM3Nzg4OTlcIixsaWdodHNsYXRlZ3JleTpcIiM3Nzg4OTlcIixuYXZham93aGl0ZTpcIiNmZmRlYWRcIixuYXZ5OlwiIzAwMDA4MFwiLG1lZGl1bXZpb2xldHJlZDpcIiNjNzE1ODVcIixwb3dkZXJibHVlOlwiI2IwZTBlNlwiLHBhbGVnb2xkZW5yb2Q6XCIjZWVlOGFhXCIsb2xkbGFjZTpcIiNmZGY1ZTZcIixwYWxldHVycXVvaXNlOlwiI2FmZWVlZVwiLG1lZGl1bXR1cnF1b2lzZTpcIiM0OGQxY2NcIixtZWRpdW1vcmNoaWQ6XCIjYmE1NWQzXCIscmViZWNjYXB1cnBsZTpcIiM2NjMzOTlcIixsaWdodHN0ZWVsYmx1ZTpcIiNiMGM0ZGVcIixtZWRpdW1zbGF0ZWJsdWU6XCIjN2I2OGVlXCIsdGhpc3RsZTpcIiNkOGJmZDhcIix0YW46XCIjZDJiNDhjXCIsb3JjaGlkOlwiI2RhNzBkNlwiLG1lZGl1bXB1cnBsZTpcIiM5MzcwZGJcIixwdXJwbGU6XCIjODAwMDgwXCIscGluazpcIiNmZmMwY2JcIixza3libHVlOlwiIzg3Y2VlYlwiLHNwcmluZ2dyZWVuOlwiIzAwZmY3ZlwiLHBhbGVncmVlbjpcIiM5OGZiOThcIixyZWQ6XCIjZmYwMDAwXCIseWVsbG93OlwiI2ZmZmYwMFwiLHNsYXRlYmx1ZTpcIiM2YTVhY2RcIixsYXZlbmRlcmJsdXNoOlwiI2ZmZjBmNVwiLHBlcnU6XCIjY2Q4NTNmXCIscGFsZXZpb2xldHJlZDpcIiNkYjcwOTNcIix2aW9sZXQ6XCIjZWU4MmVlXCIsdGVhbDpcIiMwMDgwODBcIixzbGF0ZWdyYXk6XCIjNzA4MDkwXCIsc2xhdGVncmV5OlwiIzcwODA5MFwiLGFsaWNlYmx1ZTpcIiNmMGY4ZmZcIixkYXJrc2VhZ3JlZW46XCIjOGZiYzhmXCIsZGFya29saXZlZ3JlZW46XCIjNTU2YjJmXCIsZ3JlZW55ZWxsb3c6XCIjYWRmZjJmXCIsc2VhZ3JlZW46XCIjMmU4YjU3XCIsc2Vhc2hlbGw6XCIjZmZmNWVlXCIsdG9tYXRvOlwiI2ZmNjM0N1wiLHNpbHZlcjpcIiNjMGMwYzBcIixzaWVubmE6XCIjYTA1MjJkXCIsbGF2ZW5kZXI6XCIjZTZlNmZhXCIsbGlnaHRncmVlbjpcIiM5MGVlOTBcIixvcmFuZ2U6XCIjZmZhNTAwXCIsb3JhbmdlcmVkOlwiI2ZmNDUwMFwiLHN0ZWVsYmx1ZTpcIiM0NjgyYjRcIixyb3lhbGJsdWU6XCIjNDE2OWUxXCIsdHVycXVvaXNlOlwiIzQwZTBkMFwiLHllbGxvd2dyZWVuOlwiIzlhY2QzMlwiLHNhbG1vbjpcIiNmYTgwNzJcIixzYWRkbGVicm93bjpcIiM4YjQ1MTNcIixzYW5keWJyb3duOlwiI2Y0YTQ2MFwiLHJvc3licm93bjpcIiNiYzhmOGZcIixkYXJrc2FsbW9uOlwiI2U5OTY3YVwiLGxpZ2h0Z29sZGVucm9keWVsbG93OlwiI2ZhZmFkMlwiLHNub3c6XCIjZmZmYWZhXCIsbGlnaHRncmV5OlwiI2QzZDNkM1wiLGxpZ2h0Z3JheTpcIiNkM2QzZDNcIixkaW1ncmF5OlwiIzY5Njk2OVwiLGRpbWdyZXk6XCIjNjk2OTY5XCIsb2xpdmVkcmFiOlwiIzZiOGUyM1wiLG9saXZlOlwiIzgwODAwMFwifSxyPXt9O2Zvcih2YXIgZCBpbiBhKXJbYVtkXV09ZDt2YXIgbD17fTtlLnByb3RvdHlwZS50b05hbWU9ZnVuY3Rpb24oZil7aWYoISh0aGlzLnJnYmEuYXx8dGhpcy5yZ2JhLnJ8fHRoaXMucmdiYS5nfHx0aGlzLnJnYmEuYikpcmV0dXJuXCJ0cmFuc3BhcmVudFwiO3ZhciBkLGksbj1yW3RoaXMudG9IZXgoKV07aWYobilyZXR1cm4gbjtpZihudWxsPT1mP3ZvaWQgMDpmLmNsb3Nlc3Qpe3ZhciBvPXRoaXMudG9SZ2IoKSx0PTEvMCxiPVwiYmxhY2tcIjtpZighbC5sZW5ndGgpZm9yKHZhciBjIGluIGEpbFtjXT1uZXcgZShhW2NdKS50b1JnYigpO2Zvcih2YXIgZyBpbiBhKXt2YXIgdT0oZD1vLGk9bFtnXSxNYXRoLnBvdyhkLnItaS5yLDIpK01hdGgucG93KGQuZy1pLmcsMikrTWF0aC5wb3coZC5iLWkuYiwyKSk7dTx0JiYodD11LGI9Zyl9cmV0dXJuIGJ9fTtmLnN0cmluZy5wdXNoKFtmdW5jdGlvbihmKXt2YXIgcj1mLnRvTG93ZXJDYXNlKCksZD1cInRyYW5zcGFyZW50XCI9PT1yP1wiIzAwMDBcIjphW3JdO3JldHVybiBkP25ldyBlKGQpLnRvUmdiKCk6bnVsbH0sXCJuYW1lXCJdKX1cbiIsImltcG9ydCB7IGV4dGVuZCwgY29sb3JkIH0gZnJvbSAnQHBpeGkvY29sb3JkJztcbmltcG9ydCBuYW1lc1BsdWdpbiBmcm9tICdAcGl4aS9jb2xvcmQvcGx1Z2lucy9uYW1lcyc7XG5cblwidXNlIHN0cmljdFwiO1xuZXh0ZW5kKFtuYW1lc1BsdWdpbl0pO1xuY29uc3QgX0NvbG9yID0gY2xhc3MgX0NvbG9yIHtcbiAgLyoqXG4gICAqIEBwYXJhbSB7Q29sb3JTb3VyY2V9IHZhbHVlIC0gT3B0aW9uYWwgdmFsdWUgdG8gdXNlLCBpZiBub3QgcHJvdmlkZWQsIHdoaXRlIGlzIHVzZWQuXG4gICAqL1xuICBjb25zdHJ1Y3Rvcih2YWx1ZSA9IDE2Nzc3MjE1KSB7XG4gICAgdGhpcy5fdmFsdWUgPSBudWxsO1xuICAgIHRoaXMuX2NvbXBvbmVudHMgPSBuZXcgRmxvYXQzMkFycmF5KDQpO1xuICAgIHRoaXMuX2NvbXBvbmVudHMuZmlsbCgxKTtcbiAgICB0aGlzLl9pbnQgPSAxNjc3NzIxNTtcbiAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gIH1cbiAgLyoqXG4gICAqIEdldCB0aGUgcmVkIGNvbXBvbmVudCBvZiB0aGUgY29sb3IsIG5vcm1hbGl6ZWQgYmV0d2VlbiAwIGFuZCAxLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBjb2xvciA9IG5ldyBDb2xvcigncmVkJyk7XG4gICAqIGNvbnNvbGUubG9nKGNvbG9yLnJlZCk7IC8vIDFcbiAgICpcbiAgICogY29uc3QgZ3JlZW4gPSBuZXcgQ29sb3IoJyMwMGZmMDAnKTtcbiAgICogY29uc29sZS5sb2coZ3JlZW4ucmVkKTsgLy8gMFxuICAgKiBgYGBcbiAgICovXG4gIGdldCByZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbXBvbmVudHNbMF07XG4gIH1cbiAgLyoqXG4gICAqIEdldCB0aGUgZ3JlZW4gY29tcG9uZW50IG9mIHRoZSBjb2xvciwgbm9ybWFsaXplZCBiZXR3ZWVuIDAgYW5kIDEuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGNvbG9yID0gbmV3IENvbG9yKCdsaW1lJyk7XG4gICAqIGNvbnNvbGUubG9nKGNvbG9yLmdyZWVuKTsgLy8gMVxuICAgKlxuICAgKiBjb25zdCByZWQgPSBuZXcgQ29sb3IoJyNmZjAwMDAnKTtcbiAgICogY29uc29sZS5sb2cocmVkLmdyZWVuKTsgLy8gMFxuICAgKiBgYGBcbiAgICovXG4gIGdldCBncmVlbigpIHtcbiAgICByZXR1cm4gdGhpcy5fY29tcG9uZW50c1sxXTtcbiAgfVxuICAvKipcbiAgICogR2V0IHRoZSBibHVlIGNvbXBvbmVudCBvZiB0aGUgY29sb3IsIG5vcm1hbGl6ZWQgYmV0d2VlbiAwIGFuZCAxLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBjb2xvciA9IG5ldyBDb2xvcignYmx1ZScpO1xuICAgKiBjb25zb2xlLmxvZyhjb2xvci5ibHVlKTsgLy8gMVxuICAgKlxuICAgKiBjb25zdCB5ZWxsb3cgPSBuZXcgQ29sb3IoJyNmZmZmMDAnKTtcbiAgICogY29uc29sZS5sb2coeWVsbG93LmJsdWUpOyAvLyAwXG4gICAqIGBgYFxuICAgKi9cbiAgZ2V0IGJsdWUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbXBvbmVudHNbMl07XG4gIH1cbiAgLyoqXG4gICAqIEdldCB0aGUgYWxwaGEgY29tcG9uZW50IG9mIHRoZSBjb2xvciwgbm9ybWFsaXplZCBiZXR3ZWVuIDAgYW5kIDEuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNvbnN0IGNvbG9yID0gbmV3IENvbG9yKCdyZWQnKTtcbiAgICogY29uc29sZS5sb2coY29sb3IuYWxwaGEpOyAvLyAxIChmdWxseSBvcGFxdWUpXG4gICAqXG4gICAqIGNvbnN0IHRyYW5zcGFyZW50ID0gbmV3IENvbG9yKCdyZ2JhKDI1NSwgMCwgMCwgMC41KScpO1xuICAgKiBjb25zb2xlLmxvZyh0cmFuc3BhcmVudC5hbHBoYSk7IC8vIDAuNSAoc2VtaS10cmFuc3BhcmVudClcbiAgICogYGBgXG4gICAqL1xuICBnZXQgYWxwaGEoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbXBvbmVudHNbM107XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgdGhlIGNvbG9yIHZhbHVlIGFuZCByZXR1cm5zIHRoZSBpbnN0YW5jZSBmb3IgY2hhaW5pbmcuXG4gICAqXG4gICAqIFRoaXMgaXMgYSBjaGFpbmFibGUgdmVyc2lvbiBvZiBzZXR0aW5nIHRoZSBgdmFsdWVgIHByb3BlcnR5LlxuICAgKiBAcGFyYW0gdmFsdWUgLSBUaGUgY29sb3IgdG8gc2V0LiBBY2NlcHRzIHZhcmlvdXMgZm9ybWF0czpcbiAgICogLSBIZXggc3RyaW5ncy9udW1iZXJzIChlLmcuLCAnI2ZmMDAwMCcsIDB4ZmYwMDAwKVxuICAgKiAtIFJHQi9SR0JBIHZhbHVlcyAoYXJyYXlzLCBvYmplY3RzKVxuICAgKiAtIENTUyBjb2xvciBuYW1lc1xuICAgKiAtIEhTTC9IU0xBIHZhbHVlc1xuICAgKiAtIEhTVi9IU1ZBIHZhbHVlc1xuICAgKiBAcmV0dXJucyBUaGUgQ29sb3IgaW5zdGFuY2UgZm9yIGNoYWluaW5nXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHVzYWdlXG4gICAqIGNvbnN0IGNvbG9yID0gbmV3IENvbG9yKCk7XG4gICAqIGNvbG9yLnNldFZhbHVlKCcjZmYwMDAwJylcbiAgICogICAgIC5zZXRBbHBoYSgwLjUpXG4gICAqICAgICAucHJlbXVsdGlwbHkoMC44KTtcbiAgICpcbiAgICogLy8gRGlmZmVyZW50IGZvcm1hdHNcbiAgICogY29sb3Iuc2V0VmFsdWUoMHhmZjAwMDApOyAgICAgICAgICAvLyBIZXggbnVtYmVyXG4gICAqIGNvbG9yLnNldFZhbHVlKCcjZmYwMDAwJyk7ICAgICAgICAgLy8gSGV4IHN0cmluZ1xuICAgKiBjb2xvci5zZXRWYWx1ZShbMSwgMCwgMF0pOyAgICAgICAgIC8vIFJHQiBhcnJheVxuICAgKiBjb2xvci5zZXRWYWx1ZShbMSwgMCwgMCwgMC41XSk7ICAgIC8vIFJHQkEgYXJyYXlcbiAgICogY29sb3Iuc2V0VmFsdWUoeyByOiAxLCBnOiAwLCBiOiAwIH0pOyAvLyBSR0Igb2JqZWN0XG4gICAqXG4gICAqIC8vIENvcHkgZnJvbSBhbm90aGVyIGNvbG9yXG4gICAqIGNvbnN0IHJlZCA9IG5ldyBDb2xvcigncmVkJyk7XG4gICAqIGNvbG9yLnNldFZhbHVlKHJlZCk7XG4gICAqIGBgYFxuICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIGNvbG9yIHZhbHVlIGlzIGludmFsaWQgb3IgbnVsbFxuICAgKiBAc2VlIHtAbGluayBDb2xvci52YWx1ZX0gRm9yIHRoZSB1bmRlcmx5aW5nIHZhbHVlIHByb3BlcnR5XG4gICAqL1xuICBzZXRWYWx1ZSh2YWx1ZSkge1xuICAgIHRoaXMudmFsdWUgPSB2YWx1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogVGhlIGN1cnJlbnQgY29sb3Igc291cmNlLiBUaGlzIHByb3BlcnR5IGFsbG93cyBnZXR0aW5nIGFuZCBzZXR0aW5nIHRoZSBjb2xvciB2YWx1ZVxuICAgKiB3aGlsZSBwcmVzZXJ2aW5nIHRoZSBvcmlnaW5hbCBmb3JtYXQgd2hlcmUgcG9zc2libGUuXG4gICAqIEByZW1hcmtzXG4gICAqIFdoZW4gc2V0dGluZzpcbiAgICogLSBTZXR0aW5nIHRvIGEgYENvbG9yYCBpbnN0YW5jZSBjb3BpZXMgaXRzIHNvdXJjZSBhbmQgY29tcG9uZW50c1xuICAgKiAtIFNldHRpbmcgdG8gb3RoZXIgdmFsaWQgc291cmNlcyBub3JtYWxpemVzIGFuZCBzdG9yZXMgdGhlIHZhbHVlXG4gICAqIC0gU2V0dGluZyB0byBgbnVsbGAgdGhyb3dzIGFuIEVycm9yXG4gICAqIC0gVGhlIGNvbG9yIHJlbWFpbnMgdW5jaGFuZ2VkIGlmIG5vcm1hbGl6YXRpb24gZmFpbHNcbiAgICpcbiAgICogV2hlbiBnZXR0aW5nOlxuICAgKiAtIFJldHVybnMgYG51bGxgIGlmIGNvbG9yIHdhcyBtb2RpZmllZCBieSB7QGxpbmsgQ29sb3IubXVsdGlwbHl9IG9yIHtAbGluayBDb2xvci5wcmVtdWx0aXBseX1cbiAgICogLSBPdGhlcndpc2UgcmV0dXJucyB0aGUgb3JpZ2luYWwgY29sb3Igc291cmNlXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIFNldHRpbmcgZGlmZmVyZW50IGNvbG9yIGZvcm1hdHNcbiAgICogY29uc3QgY29sb3IgPSBuZXcgQ29sb3IoKTtcbiAgICpcbiAgICogY29sb3IudmFsdWUgPSAweGZmMDAwMDsgICAgICAgICAvLyBIZXggbnVtYmVyXG4gICAqIGNvbG9yLnZhbHVlID0gJyNmZjAwMDAnOyAgICAgICAgLy8gSGV4IHN0cmluZ1xuICAgKiBjb2xvci52YWx1ZSA9IFsxLCAwLCAwXTsgICAgICAgIC8vIFJHQiBhcnJheVxuICAgKiBjb2xvci52YWx1ZSA9IFsxLCAwLCAwLCAwLjVdOyAgIC8vIFJHQkEgYXJyYXlcbiAgICogY29sb3IudmFsdWUgPSB7IHI6IDEsIGc6IDAsIGI6IDAgfTsgLy8gUkdCIG9iamVjdFxuICAgKlxuICAgKiAvLyBDb3B5aW5nIGZyb20gYW5vdGhlciBjb2xvclxuICAgKiBjb25zdCByZWQgPSBuZXcgQ29sb3IoJ3JlZCcpO1xuICAgKiBjb2xvci52YWx1ZSA9IHJlZDsgIC8vIENvcGllcyByZWQncyBjb21wb25lbnRzXG4gICAqXG4gICAqIC8vIEdldHRpbmcgdGhlIHZhbHVlXG4gICAqIGNvbnNvbGUubG9nKGNvbG9yLnZhbHVlKTsgIC8vIFJldHVybnMgb3JpZ2luYWwgZm9ybWF0XG4gICAqXG4gICAqIC8vIEFmdGVyIG1vZGlmaWNhdGlvbnNcbiAgICogY29sb3IubXVsdGlwbHkoWzAuNSwgMC41LCAwLjVdKTtcbiAgICogY29uc29sZS5sb2coY29sb3IudmFsdWUpOyAgLy8gUmV0dXJucyBudWxsXG4gICAqIGBgYFxuICAgKiBAdGhyb3dzIHtFcnJvcn0gV2hlbiBhdHRlbXB0aW5nIHRvIHNldCBgbnVsbGBcbiAgICovXG4gIHNldCB2YWx1ZSh2YWx1ZSkge1xuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIF9Db2xvcikge1xuICAgICAgdGhpcy5fdmFsdWUgPSB0aGlzLl9jbG9uZVNvdXJjZSh2YWx1ZS5fdmFsdWUpO1xuICAgICAgdGhpcy5faW50ID0gdmFsdWUuX2ludDtcbiAgICAgIHRoaXMuX2NvbXBvbmVudHMuc2V0KHZhbHVlLl9jb21wb25lbnRzKTtcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBudWxsKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3Qgc2V0IENvbG9yI3ZhbHVlIHRvIG51bGxcIik7XG4gICAgfSBlbHNlIGlmICh0aGlzLl92YWx1ZSA9PT0gbnVsbCB8fCAhdGhpcy5faXNTb3VyY2VFcXVhbCh0aGlzLl92YWx1ZSwgdmFsdWUpKSB7XG4gICAgICB0aGlzLl92YWx1ZSA9IHRoaXMuX2Nsb25lU291cmNlKHZhbHVlKTtcbiAgICAgIHRoaXMuX25vcm1hbGl6ZSh0aGlzLl92YWx1ZSk7XG4gICAgfVxuICB9XG4gIGdldCB2YWx1ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gIH1cbiAgLyoqXG4gICAqIENvcHkgYSBjb2xvciBzb3VyY2UgaW50ZXJuYWxseS5cbiAgICogQHBhcmFtIHZhbHVlIC0gQ29sb3Igc291cmNlXG4gICAqL1xuICBfY2xvbmVTb3VyY2UodmFsdWUpIHtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIiB8fCB2YWx1ZSBpbnN0YW5jZW9mIE51bWJlciB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgQXJyYXlCdWZmZXIuaXNWaWV3KHZhbHVlKSkge1xuICAgICAgcmV0dXJuIHZhbHVlLnNsaWNlKDApO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsKSB7XG4gICAgICByZXR1cm4geyAuLi52YWx1ZSB9O1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgLyoqXG4gICAqIEVxdWFsaXR5IGNoZWNrIGZvciBjb2xvciBzb3VyY2VzLlxuICAgKiBAcGFyYW0gdmFsdWUxIC0gRmlyc3QgY29sb3Igc291cmNlXG4gICAqIEBwYXJhbSB2YWx1ZTIgLSBTZWNvbmQgY29sb3Igc291cmNlXG4gICAqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgY29sb3Igc291cmNlcyBhcmUgZXF1YWwsIGBmYWxzZWAgb3RoZXJ3aXNlLlxuICAgKi9cbiAgX2lzU291cmNlRXF1YWwodmFsdWUxLCB2YWx1ZTIpIHtcbiAgICBjb25zdCB0eXBlMSA9IHR5cGVvZiB2YWx1ZTE7XG4gICAgY29uc3QgdHlwZTIgPSB0eXBlb2YgdmFsdWUyO1xuICAgIGlmICh0eXBlMSAhPT0gdHlwZTIpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9IGVsc2UgaWYgKHR5cGUxID09PSBcIm51bWJlclwiIHx8IHR5cGUxID09PSBcInN0cmluZ1wiIHx8IHZhbHVlMSBpbnN0YW5jZW9mIE51bWJlcikge1xuICAgICAgcmV0dXJuIHZhbHVlMSA9PT0gdmFsdWUyO1xuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZTEpICYmIEFycmF5LmlzQXJyYXkodmFsdWUyKSB8fCBBcnJheUJ1ZmZlci5pc1ZpZXcodmFsdWUxKSAmJiBBcnJheUJ1ZmZlci5pc1ZpZXcodmFsdWUyKSkge1xuICAgICAgaWYgKHZhbHVlMS5sZW5ndGggIT09IHZhbHVlMi5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHZhbHVlMS5ldmVyeSgodiwgaSkgPT4gdiA9PT0gdmFsdWUyW2ldKTtcbiAgICB9IGVsc2UgaWYgKHZhbHVlMSAhPT0gbnVsbCAmJiB2YWx1ZTIgIT09IG51bGwpIHtcbiAgICAgIGNvbnN0IGtleXMxID0gT2JqZWN0LmtleXModmFsdWUxKTtcbiAgICAgIGNvbnN0IGtleXMyID0gT2JqZWN0LmtleXModmFsdWUyKTtcbiAgICAgIGlmIChrZXlzMS5sZW5ndGggIT09IGtleXMyLmxlbmd0aCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICByZXR1cm4ga2V5czEuZXZlcnkoKGtleSkgPT4gdmFsdWUxW2tleV0gPT09IHZhbHVlMltrZXldKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlMSA9PT0gdmFsdWUyO1xuICB9XG4gIC8qKlxuICAgKiBDb252ZXJ0IHRvIGEgUkdCQSBjb2xvciBvYmplY3Qgd2l0aCBub3JtYWxpemVkIGNvbXBvbmVudHMgKDAtMSkuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IENvbG9yIH0gZnJvbSAncGl4aS5qcyc7XG4gICAqXG4gICAqIC8vIENvbnZlcnQgY29sb3JzIHRvIFJHQkEgb2JqZWN0c1xuICAgKiBuZXcgQ29sb3IoJ3doaXRlJykudG9SZ2JhKCk7ICAgICAvLyByZXR1cm5zIHsgcjogMSwgZzogMSwgYjogMSwgYTogMSB9XG4gICAqIG5ldyBDb2xvcignI2ZmMDAwMCcpLnRvUmdiYSgpOyAgIC8vIHJldHVybnMgeyByOiAxLCBnOiAwLCBiOiAwLCBhOiAxIH1cbiAgICpcbiAgICogLy8gV2l0aCB0cmFuc3BhcmVuY3lcbiAgICogbmV3IENvbG9yKCdyZ2JhKDI1NSwwLDAsMC41KScpLnRvUmdiYSgpOyAvLyByZXR1cm5zIHsgcjogMSwgZzogMCwgYjogMCwgYTogMC41IH1cbiAgICogYGBgXG4gICAqIEByZXR1cm5zIEFuIFJHQkEgb2JqZWN0IHdpdGggbm9ybWFsaXplZCBjb21wb25lbnRzXG4gICAqL1xuICB0b1JnYmEoKSB7XG4gICAgY29uc3QgW3IsIGcsIGIsIGFdID0gdGhpcy5fY29tcG9uZW50cztcbiAgICByZXR1cm4geyByLCBnLCBiLCBhIH07XG4gIH1cbiAgLyoqXG4gICAqIENvbnZlcnQgdG8gYSBSR0IgY29sb3Igb2JqZWN0IHdpdGggbm9ybWFsaXplZCBjb21wb25lbnRzICgwLTEpLlxuICAgKlxuICAgKiBBbHBoYSBjb21wb25lbnQgaXMgb21pdHRlZCBpbiB0aGUgb3V0cHV0LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgeyBDb2xvciB9IGZyb20gJ3BpeGkuanMnO1xuICAgKlxuICAgKiAvLyBDb252ZXJ0IGNvbG9ycyB0byBSR0Igb2JqZWN0c1xuICAgKiBuZXcgQ29sb3IoJ3doaXRlJykudG9SZ2IoKTsgICAgIC8vIHJldHVybnMgeyByOiAxLCBnOiAxLCBiOiAxIH1cbiAgICogbmV3IENvbG9yKCcjZmYwMDAwJykudG9SZ2IoKTsgICAvLyByZXR1cm5zIHsgcjogMSwgZzogMCwgYjogMCB9XG4gICAqXG4gICAqIC8vIEFscGhhIGlzIGlnbm9yZWRcbiAgICogbmV3IENvbG9yKCdyZ2JhKDI1NSwwLDAsMC41KScpLnRvUmdiKCk7IC8vIHJldHVybnMgeyByOiAxLCBnOiAwLCBiOiAwIH1cbiAgICogYGBgXG4gICAqIEByZXR1cm5zIEFuIFJHQiBvYmplY3Qgd2l0aCBub3JtYWxpemVkIGNvbXBvbmVudHNcbiAgICovXG4gIHRvUmdiKCkge1xuICAgIGNvbnN0IFtyLCBnLCBiXSA9IHRoaXMuX2NvbXBvbmVudHM7XG4gICAgcmV0dXJuIHsgciwgZywgYiB9O1xuICB9XG4gIC8qKlxuICAgKiBDb252ZXJ0IHRvIGEgQ1NTLXN0eWxlIHJnYmEgc3RyaW5nIHJlcHJlc2VudGF0aW9uLlxuICAgKlxuICAgKiBSR0IgY29tcG9uZW50cyBhcmUgc2NhbGVkIHRvIDAtMjU1IHJhbmdlLCBhbHBoYSByZW1haW5zIDAtMS5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IHsgQ29sb3IgfSBmcm9tICdwaXhpLmpzJztcbiAgICpcbiAgICogLy8gQ29udmVydCBjb2xvcnMgdG8gUkdCQSBzdHJpbmdzXG4gICAqIG5ldyBDb2xvcignd2hpdGUnKS50b1JnYmFTdHJpbmcoKTsgICAgIC8vIHJldHVybnMgXCJyZ2JhKDI1NSwyNTUsMjU1LDEpXCJcbiAgICogbmV3IENvbG9yKCcjZmYwMDAwJykudG9SZ2JhU3RyaW5nKCk7ICAgLy8gcmV0dXJucyBcInJnYmEoMjU1LDAsMCwxKVwiXG4gICAqXG4gICAqIC8vIFdpdGggdHJhbnNwYXJlbmN5XG4gICAqIG5ldyBDb2xvcihbMSwgMCwgMCwgMC41XSkudG9SZ2JhU3RyaW5nKCk7IC8vIHJldHVybnMgXCJyZ2JhKDI1NSwwLDAsMC41KVwiXG4gICAqIGBgYFxuICAgKiBAcmV0dXJucyBBIENTUy1jb21wYXRpYmxlIHJnYmEgc3RyaW5nXG4gICAqL1xuICB0b1JnYmFTdHJpbmcoKSB7XG4gICAgY29uc3QgW3IsIGcsIGJdID0gdGhpcy50b1VpbnQ4UmdiQXJyYXkoKTtcbiAgICByZXR1cm4gYHJnYmEoJHtyfSwke2d9LCR7Yn0sJHt0aGlzLmFscGhhfSlgO1xuICB9XG4gIC8qKlxuICAgKiBDb252ZXJ0IHRvIGFuIFtSLCBHLCBCXSBhcnJheSBvZiBjbGFtcGVkIHVpbnQ4IHZhbHVlcyAoMCB0byAyNTUpLlxuICAgKiBAcGFyYW0ge251bWJlcltdfFVpbnQ4QXJyYXl8VWludDhDbGFtcGVkQXJyYXl9IFtvdXRdIC0gT3B0aW9uYWwgb3V0cHV0IGFycmF5LiBJZiBub3QgcHJvdmlkZWQsXG4gICAqIGEgY2FjaGVkIGFycmF5IHdpbGwgYmUgdXNlZCBhbmQgcmV0dXJuZWQuXG4gICAqIEByZXR1cm5zIEFycmF5IGNvbnRhaW5pbmcgUkdCIGNvbXBvbmVudHMgYXMgaW50ZWdlcnMgYmV0d2VlbiAwLTI1NVxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyB1c2FnZVxuICAgKiBuZXcgQ29sb3IoJ3doaXRlJykudG9VaW50OFJnYkFycmF5KCk7IC8vIHJldHVybnMgWzI1NSwgMjU1LCAyNTVdXG4gICAqIG5ldyBDb2xvcignI2ZmMDAwMCcpLnRvVWludDhSZ2JBcnJheSgpOyAvLyByZXR1cm5zIFsyNTUsIDAsIDBdXG4gICAqXG4gICAqIC8vIFVzaW5nIGN1c3RvbSBvdXRwdXQgYXJyYXlcbiAgICogY29uc3QgcmdiID0gbmV3IFVpbnQ4QXJyYXkoMyk7XG4gICAqIG5ldyBDb2xvcignYmx1ZScpLnRvVWludDhSZ2JBcnJheShyZ2IpOyAvLyByZ2IgaXMgbm93IFswLCAwLCAyNTVdXG4gICAqXG4gICAqIC8vIFVzaW5nIGRpZmZlcmVudCBhcnJheSB0eXBlc1xuICAgKiBuZXcgQ29sb3IoJ3JlZCcpLnRvVWludDhSZ2JBcnJheShuZXcgVWludDhDbGFtcGVkQXJyYXkoMykpOyAvLyBbMjU1LCAwLCAwXVxuICAgKiBuZXcgQ29sb3IoJ3JlZCcpLnRvVWludDhSZ2JBcnJheShbXSk7IC8vIFsyNTUsIDAsIDBdXG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIE91dHB1dCB2YWx1ZXMgYXJlIGFsd2F5cyBjbGFtcGVkIGJldHdlZW4gMC0yNTVcbiAgICogLSBBbHBoYSBjb21wb25lbnQgaXMgbm90IGluY2x1ZGVkIGluIG91dHB1dFxuICAgKiAtIFJldXNlcyBpbnRlcm5hbCBjYWNoZSBhcnJheSBpZiBubyBvdXRwdXQgYXJyYXkgcHJvdmlkZWRcbiAgICovXG4gIHRvVWludDhSZ2JBcnJheShvdXQpIHtcbiAgICBjb25zdCBbciwgZywgYl0gPSB0aGlzLl9jb21wb25lbnRzO1xuICAgIGlmICghdGhpcy5fYXJyYXlSZ2IpIHtcbiAgICAgIHRoaXMuX2FycmF5UmdiID0gW107XG4gICAgfVxuICAgIG91dCB8fCAob3V0ID0gdGhpcy5fYXJyYXlSZ2IpO1xuICAgIG91dFswXSA9IE1hdGgucm91bmQociAqIDI1NSk7XG4gICAgb3V0WzFdID0gTWF0aC5yb3VuZChnICogMjU1KTtcbiAgICBvdXRbMl0gPSBNYXRoLnJvdW5kKGIgKiAyNTUpO1xuICAgIHJldHVybiBvdXQ7XG4gIH1cbiAgLyoqXG4gICAqIENvbnZlcnQgdG8gYW4gW1IsIEcsIEIsIEFdIGFycmF5IG9mIG5vcm1hbGl6ZWQgZmxvYXRzIChudW1iZXJzIGZyb20gMC4wIHRvIDEuMCkuXG4gICAqIEBwYXJhbSB7bnVtYmVyW118RmxvYXQzMkFycmF5fSBbb3V0XSAtIE9wdGlvbmFsIG91dHB1dCBhcnJheS4gSWYgbm90IHByb3ZpZGVkLFxuICAgKiBhIGNhY2hlZCBhcnJheSB3aWxsIGJlIHVzZWQgYW5kIHJldHVybmVkLlxuICAgKiBAcmV0dXJucyBBcnJheSBjb250YWluaW5nIFJHQkEgY29tcG9uZW50cyBhcyBmbG9hdHMgYmV0d2VlbiAwLTFcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgdXNhZ2VcbiAgICogbmV3IENvbG9yKCd3aGl0ZScpLnRvQXJyYXkoKTsgIC8vIHJldHVybnMgWzEsIDEsIDEsIDFdXG4gICAqIG5ldyBDb2xvcigncmVkJykudG9BcnJheSgpOyAgICAvLyByZXR1cm5zIFsxLCAwLCAwLCAxXVxuICAgKlxuICAgKiAvLyBXaXRoIGFscGhhXG4gICAqIG5ldyBDb2xvcigncmdiYSgyNTUsMCwwLDAuNSknKS50b0FycmF5KCk7IC8vIHJldHVybnMgWzEsIDAsIDAsIDAuNV1cbiAgICpcbiAgICogLy8gVXNpbmcgY3VzdG9tIG91dHB1dCBhcnJheVxuICAgKiBjb25zdCByZ2JhID0gbmV3IEZsb2F0MzJBcnJheSg0KTtcbiAgICogbmV3IENvbG9yKCdibHVlJykudG9BcnJheShyZ2JhKTsgLy8gcmdiYSBpcyBub3cgWzAsIDAsIDEsIDFdXG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIE91dHB1dCB2YWx1ZXMgYXJlIG5vcm1hbGl6ZWQgYmV0d2VlbiAwLTFcbiAgICogLSBJbmNsdWRlcyBhbHBoYSBjb21wb25lbnQgYXMgdGhlIGZvdXJ0aCB2YWx1ZVxuICAgKiAtIFJldXNlcyBpbnRlcm5hbCBjYWNoZSBhcnJheSBpZiBubyBvdXRwdXQgYXJyYXkgcHJvdmlkZWRcbiAgICovXG4gIHRvQXJyYXkob3V0KSB7XG4gICAgaWYgKCF0aGlzLl9hcnJheVJnYmEpIHtcbiAgICAgIHRoaXMuX2FycmF5UmdiYSA9IFtdO1xuICAgIH1cbiAgICBvdXQgfHwgKG91dCA9IHRoaXMuX2FycmF5UmdiYSk7XG4gICAgY29uc3QgW3IsIGcsIGIsIGFdID0gdGhpcy5fY29tcG9uZW50cztcbiAgICBvdXRbMF0gPSByO1xuICAgIG91dFsxXSA9IGc7XG4gICAgb3V0WzJdID0gYjtcbiAgICBvdXRbM10gPSBhO1xuICAgIHJldHVybiBvdXQ7XG4gIH1cbiAgLyoqXG4gICAqIENvbnZlcnQgdG8gYW4gW1IsIEcsIEJdIGFycmF5IG9mIG5vcm1hbGl6ZWQgZmxvYXRzIChudW1iZXJzIGZyb20gMC4wIHRvIDEuMCkuXG4gICAqIEBwYXJhbSB7bnVtYmVyW118RmxvYXQzMkFycmF5fSBbb3V0XSAtIE9wdGlvbmFsIG91dHB1dCBhcnJheS4gSWYgbm90IHByb3ZpZGVkLFxuICAgKiBhIGNhY2hlZCBhcnJheSB3aWxsIGJlIHVzZWQgYW5kIHJldHVybmVkLlxuICAgKiBAcmV0dXJucyBBcnJheSBjb250YWluaW5nIFJHQiBjb21wb25lbnRzIGFzIGZsb2F0cyBiZXR3ZWVuIDAtMVxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyB1c2FnZVxuICAgKiBuZXcgQ29sb3IoJ3doaXRlJykudG9SZ2JBcnJheSgpOyAvLyByZXR1cm5zIFsxLCAxLCAxXVxuICAgKiBuZXcgQ29sb3IoJ3JlZCcpLnRvUmdiQXJyYXkoKTsgICAvLyByZXR1cm5zIFsxLCAwLCAwXVxuICAgKlxuICAgKiAvLyBVc2luZyBjdXN0b20gb3V0cHV0IGFycmF5XG4gICAqIGNvbnN0IHJnYiA9IG5ldyBGbG9hdDMyQXJyYXkoMyk7XG4gICAqIG5ldyBDb2xvcignYmx1ZScpLnRvUmdiQXJyYXkocmdiKTsgLy8gcmdiIGlzIG5vdyBbMCwgMCwgMV1cbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gT3V0cHV0IHZhbHVlcyBhcmUgbm9ybWFsaXplZCBiZXR3ZWVuIDAtMVxuICAgKiAtIEFscGhhIGNvbXBvbmVudCBpcyBvbWl0dGVkIGZyb20gb3V0cHV0XG4gICAqIC0gUmV1c2VzIGludGVybmFsIGNhY2hlIGFycmF5IGlmIG5vIG91dHB1dCBhcnJheSBwcm92aWRlZFxuICAgKi9cbiAgdG9SZ2JBcnJheShvdXQpIHtcbiAgICBpZiAoIXRoaXMuX2FycmF5UmdiKSB7XG4gICAgICB0aGlzLl9hcnJheVJnYiA9IFtdO1xuICAgIH1cbiAgICBvdXQgfHwgKG91dCA9IHRoaXMuX2FycmF5UmdiKTtcbiAgICBjb25zdCBbciwgZywgYl0gPSB0aGlzLl9jb21wb25lbnRzO1xuICAgIG91dFswXSA9IHI7XG4gICAgb3V0WzFdID0gZztcbiAgICBvdXRbMl0gPSBiO1xuICAgIHJldHVybiBvdXQ7XG4gIH1cbiAgLyoqXG4gICAqIENvbnZlcnQgdG8gYSBoZXhhZGVjaW1hbCBudW1iZXIuXG4gICAqIEByZXR1cm5zIFRoZSBjb2xvciBhcyBhIDI0LWJpdCBSR0IgaW50ZWdlclxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyB1c2FnZVxuICAgKiBuZXcgQ29sb3IoJ3doaXRlJykudG9OdW1iZXIoKTsgLy8gcmV0dXJucyAweGZmZmZmZlxuICAgKiBuZXcgQ29sb3IoJ3JlZCcpLnRvTnVtYmVyKCk7ICAgLy8gcmV0dXJucyAweGZmMDAwMFxuICAgKlxuICAgKiAvLyBTdG9yZSBhcyBoZXhcbiAgICogY29uc3QgY29sb3IgPSBuZXcgQ29sb3IoJ2JsdWUnKTtcbiAgICogY29uc3QgaGV4ID0gY29sb3IudG9OdW1iZXIoKTsgLy8gMHgwMDAwZmZcbiAgICogYGBgXG4gICAqL1xuICB0b051bWJlcigpIHtcbiAgICByZXR1cm4gdGhpcy5faW50O1xuICB9XG4gIC8qKlxuICAgKiBDb252ZXJ0IHRvIGEgQkdSIG51bWJlci5cbiAgICpcbiAgICogVXNlZnVsIGZvciBwbGF0Zm9ybXMgdGhhdCBleHBlY3QgY29sb3JzIGluIEJHUiBmb3JtYXQuXG4gICAqIEByZXR1cm5zIFRoZSBjb2xvciBhcyBhIDI0LWJpdCBCR1IgaW50ZWdlclxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBDb252ZXJ0IFJHQiB0byBCR1JcbiAgICogbmV3IENvbG9yKDB4ZmZjYzk5KS50b0Jnck51bWJlcigpOyAvLyByZXR1cm5zIDB4OTljY2ZmXG4gICAqXG4gICAqIC8vIENvbW1vbiB1c2UgY2FzZTogcGxhdGZvcm0tc3BlY2lmaWMgY29sb3IgZm9ybWF0XG4gICAqIGNvbnN0IGNvbG9yID0gbmV3IENvbG9yKCdvcmFuZ2UnKTtcbiAgICogY29uc3QgYmdyQ29sb3IgPSBjb2xvci50b0Jnck51bWJlcigpOyAvLyBDb2xvciB3aXRoIHN3YXBwZWQgUi9CIGNoYW5uZWxzXG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiBUaGlzIHN3YXBzIHRoZSByZWQgYW5kIGJsdWUgY2hhbm5lbHMgY29tcGFyZWQgdG8gdGhlIG5vcm1hbCBSR0IgZm9ybWF0OlxuICAgKiAtIFJHQiAweFJSR0dCQiBiZWNvbWVzIEJHUiAweEJCR0dSUlxuICAgKi9cbiAgdG9CZ3JOdW1iZXIoKSB7XG4gICAgY29uc3QgW3IsIGcsIGJdID0gdGhpcy50b1VpbnQ4UmdiQXJyYXkoKTtcbiAgICByZXR1cm4gKGIgPDwgMTYpICsgKGcgPDwgOCkgKyByO1xuICB9XG4gIC8qKlxuICAgKiBDb252ZXJ0IHRvIGEgaGV4YWRlY2ltYWwgbnVtYmVyIGluIGxpdHRsZSBlbmRpYW4gZm9ybWF0IChlLmcuLCBCQkdHUlIpLlxuICAgKlxuICAgKiBVc2VmdWwgZm9yIHBsYXRmb3JtcyB0aGF0IGV4cGVjdCBjb2xvcnMgaW4gbGl0dGxlIGVuZGlhbiBieXRlIG9yZGVyLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgeyBDb2xvciB9IGZyb20gJ3BpeGkuanMnO1xuICAgKlxuICAgKiAvLyBDb252ZXJ0IFJHQiBjb2xvciB0byBsaXR0bGUgZW5kaWFuIGZvcm1hdFxuICAgKiBuZXcgQ29sb3IoMHhmZmNjOTkpLnRvTGl0dGxlRW5kaWFuTnVtYmVyKCk7IC8vIHJldHVybnMgMHg5OWNjZmZcbiAgICpcbiAgICogLy8gQ29tbW9uIHVzZSBjYXNlczpcbiAgICogY29uc3QgY29sb3IgPSBuZXcgQ29sb3IoJ29yYW5nZScpO1xuICAgKiBjb25zdCBsZUNvbG9yID0gY29sb3IudG9MaXR0bGVFbmRpYW5OdW1iZXIoKTsgLy8gU3dhcHMgYnl0ZSBvcmRlciBmb3IgTEUgc3lzdGVtc1xuICAgKlxuICAgKiAvLyBNdWx0aXBsZSBjb252ZXJzaW9uc1xuICAgKiBjb25zdCBjb2xvcnMgPSB7XG4gICAqICAgICBub3JtYWw6IDB4ZmZjYzk5LFxuICAgKiAgICAgbGl0dGxlRW5kaWFuOiBuZXcgQ29sb3IoMHhmZmNjOTkpLnRvTGl0dGxlRW5kaWFuTnVtYmVyKCksIC8vIDB4OTljY2ZmXG4gICAqICAgICBiYWNrVG9Ob3JtYWw6IG5ldyBDb2xvcigweDk5Y2NmZikudG9MaXR0bGVFbmRpYW5OdW1iZXIoKSAgLy8gMHhmZmNjOTlcbiAgICogfTtcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gU3dhcHMgUiBhbmQgQiBjaGFubmVscyBpbiB0aGUgY29sb3IgdmFsdWVcbiAgICogLSBSR0IgMHhSUkdHQkIgYmVjb21lcyAweEJCR0dSUlxuICAgKiAtIFVzZWZ1bCBmb3Igc3lzdGVtcyB0aGF0IHVzZSBsaXR0bGUgZW5kaWFuIGJ5dGUgb3JkZXJcbiAgICogLSBDYW4gYmUgdXNlZCB0byBjb252ZXJ0IGJhY2sgYW5kIGZvcnRoIGJldHdlZW4gZm9ybWF0c1xuICAgKiBAcmV0dXJucyBUaGUgY29sb3IgYXMgYSBudW1iZXIgaW4gbGl0dGxlIGVuZGlhbiBmb3JtYXQgKEJCR0dSUilcbiAgICogQHNlZSB7QGxpbmsgQ29sb3IudG9CZ3JOdW1iZXJ9IEZvciBCR1IgZm9ybWF0IHdpdGhvdXQgYnl0ZSBzd2FwcGluZ1xuICAgKi9cbiAgdG9MaXR0bGVFbmRpYW5OdW1iZXIoKSB7XG4gICAgY29uc3QgdmFsdWUgPSB0aGlzLl9pbnQ7XG4gICAgcmV0dXJuICh2YWx1ZSA+PiAxNikgKyAodmFsdWUgJiA2NTI4MCkgKyAoKHZhbHVlICYgMjU1KSA8PCAxNik7XG4gIH1cbiAgLyoqXG4gICAqIE11bHRpcGx5IHdpdGggYW5vdGhlciBjb2xvci5cbiAgICpcbiAgICogVGhpcyBhY3Rpb24gaXMgZGVzdHJ1Y3RpdmUgYW5kIG1vZGlmaWVzIHRoZSBvcmlnaW5hbCBjb2xvci5cbiAgICogQHBhcmFtIHtDb2xvclNvdXJjZX0gdmFsdWUgLSBUaGUgY29sb3IgdG8gbXVsdGlwbHkgYnkuIEFjY2VwdHMgYW55IHZhbGlkIGNvbG9yIGZvcm1hdDpcbiAgICogLSBIZXggc3RyaW5ncy9udW1iZXJzIChlLmcuLCAnI2ZmMDAwMCcsIDB4ZmYwMDAwKVxuICAgKiAtIFJHQi9SR0JBIGFycmF5cyAoWzEsIDAsIDBdLCBbMSwgMCwgMCwgMV0pXG4gICAqIC0gQ29sb3Igb2JqZWN0cyAoeyByOiAxLCBnOiAwLCBiOiAwIH0pXG4gICAqIC0gQ1NTIGNvbG9yIG5hbWVzICgncmVkJywgJ2JsdWUnKVxuICAgKiBAcmV0dXJucyB0aGlzIC0gVGhlIENvbG9yIGluc3RhbmNlIGZvciBjaGFpbmluZ1xuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBtdWx0aXBsaWNhdGlvblxuICAgKiBjb25zdCBjb2xvciA9IG5ldyBDb2xvcignI2ZmMDAwMCcpO1xuICAgKiBjb2xvci5tdWx0aXBseSgweDgwODA4MCk7IC8vIDUwJSBkYXJrZXIgcmVkXG4gICAqXG4gICAqIC8vIFdpdGggdHJhbnNwYXJlbmN5XG4gICAqIGNvbG9yLm11bHRpcGx5KFsxLCAxLCAxLCAwLjVdKTsgLy8gNTAlIHRyYW5zcGFyZW50XG4gICAqXG4gICAqIC8vIENoYWluIG9wZXJhdGlvbnNcbiAgICogY29sb3JcbiAgICogICAgIC5tdWx0aXBseSgnIzgwODA4MCcpXG4gICAqICAgICAubXVsdGlwbHkoeyByOiAxLCBnOiAxLCBiOiAxLCBhOiAwLjUgfSk7XG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIE11bHRpcGxpZXMgZWFjaCBSR0IgY29tcG9uZW50IGFuZCBhbHBoYSBzZXBhcmF0ZWx5XG4gICAqIC0gVmFsdWVzIGFyZSBjbGFtcGVkIGJldHdlZW4gMC0xXG4gICAqIC0gT3JpZ2luYWwgY29sb3IgZm9ybWF0IGlzIGxvc3QgKHZhbHVlIGJlY29tZXMgbnVsbClcbiAgICogLSBPcGVyYXRpb24gY2Fubm90IGJlIHVuZG9uZVxuICAgKi9cbiAgbXVsdGlwbHkodmFsdWUpIHtcbiAgICBjb25zdCBbciwgZywgYiwgYV0gPSBfQ29sb3IuX3RlbXAuc2V0VmFsdWUodmFsdWUpLl9jb21wb25lbnRzO1xuICAgIHRoaXMuX2NvbXBvbmVudHNbMF0gKj0gcjtcbiAgICB0aGlzLl9jb21wb25lbnRzWzFdICo9IGc7XG4gICAgdGhpcy5fY29tcG9uZW50c1syXSAqPSBiO1xuICAgIHRoaXMuX2NvbXBvbmVudHNbM10gKj0gYTtcbiAgICB0aGlzLl9yZWZyZXNoSW50KCk7XG4gICAgdGhpcy5fdmFsdWUgPSBudWxsO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBDb252ZXJ0cyBjb2xvciB0byBhIHByZW11bHRpcGxpZWQgYWxwaGEgZm9ybWF0LlxuICAgKlxuICAgKiBUaGlzIGFjdGlvbiBpcyBkZXN0cnVjdGl2ZSBhbmQgbW9kaWZpZXMgdGhlIG9yaWdpbmFsIGNvbG9yLlxuICAgKiBAcGFyYW0gYWxwaGEgLSBUaGUgYWxwaGEgdmFsdWUgdG8gbXVsdGlwbHkgYnkgKDAtMSlcbiAgICogQHBhcmFtIHtib29sZWFufSBbYXBwbHlUb1JHQj10cnVlXSAtIFdoZXRoZXIgdG8gcHJlbXVsdGlwbHkgUkdCIGNoYW5uZWxzXG4gICAqIEByZXR1cm5zIHtDb2xvcn0gVGhlIENvbG9yIGluc3RhbmNlIGZvciBjaGFpbmluZ1xuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBwcmVtdWx0aXBsaWNhdGlvblxuICAgKiBjb25zdCBjb2xvciA9IG5ldyBDb2xvcigncmVkJyk7XG4gICAqIGNvbG9yLnByZW11bHRpcGx5KDAuNSk7IC8vIDUwJSB0cmFuc3BhcmVudCByZWQgd2l0aCBwcmVtdWx0aXBsaWVkIFJHQlxuICAgKlxuICAgKiAvLyBBbHBoYSBvbmx5IChSR0IgdW5jaGFuZ2VkKVxuICAgKiBjb2xvci5wcmVtdWx0aXBseSgwLjUsIGZhbHNlKTsgLy8gNTAlIHRyYW5zcGFyZW50LCBvcmlnaW5hbCBSR0JcbiAgICpcbiAgICogLy8gQ2hhaW4gd2l0aCBvdGhlciBvcGVyYXRpb25zXG4gICAqIGNvbG9yXG4gICAqICAgICAubXVsdGlwbHkoMHg4MDgwODApXG4gICAqICAgICAucHJlbXVsdGlwbHkoMC41KVxuICAgKiAgICAgLnRvTnVtYmVyKCk7XG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIFJHQiBjaGFubmVscyBhcmUgbXVsdGlwbGllZCBieSBhbHBoYSB3aGVuIGFwcGx5VG9SR0IgaXMgdHJ1ZVxuICAgKiAtIEFscGhhIGlzIGFsd2F5cyBzZXQgdG8gdGhlIHByb3ZpZGVkIHZhbHVlXG4gICAqIC0gVmFsdWVzIGFyZSBjbGFtcGVkIGJldHdlZW4gMC0xXG4gICAqIC0gT3JpZ2luYWwgY29sb3IgZm9ybWF0IGlzIGxvc3QgKHZhbHVlIGJlY29tZXMgbnVsbClcbiAgICogLSBPcGVyYXRpb24gY2Fubm90IGJlIHVuZG9uZVxuICAgKi9cbiAgcHJlbXVsdGlwbHkoYWxwaGEsIGFwcGx5VG9SR0IgPSB0cnVlKSB7XG4gICAgaWYgKGFwcGx5VG9SR0IpIHtcbiAgICAgIHRoaXMuX2NvbXBvbmVudHNbMF0gKj0gYWxwaGE7XG4gICAgICB0aGlzLl9jb21wb25lbnRzWzFdICo9IGFscGhhO1xuICAgICAgdGhpcy5fY29tcG9uZW50c1syXSAqPSBhbHBoYTtcbiAgICB9XG4gICAgdGhpcy5fY29tcG9uZW50c1szXSA9IGFscGhhO1xuICAgIHRoaXMuX3JlZnJlc2hJbnQoKTtcbiAgICB0aGlzLl92YWx1ZSA9IG51bGw7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGNvbG9yIGFzIGEgMzItYml0IHByZW11bHRpcGxpZWQgYWxwaGEgaW50ZWdlci5cbiAgICpcbiAgICogRm9ybWF0OiAweEFBUlJHR0JCXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBhbHBoYSAtIFRoZSBhbHBoYSB2YWx1ZSB0byBtdWx0aXBseSBieSAoMC0xKVxuICAgKiBAcGFyYW0ge2Jvb2xlYW59IFthcHBseVRvUkdCPXRydWVdIC0gV2hldGhlciB0byBwcmVtdWx0aXBseSBSR0IgY2hhbm5lbHNcbiAgICogQHJldHVybnMge251bWJlcn0gVGhlIHByZW11bHRpcGxpZWQgY29sb3IgYXMgYSAzMi1iaXQgaW50ZWdlclxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBDb252ZXJ0IHRvIHByZW11bHRpcGxpZWQgZm9ybWF0XG4gICAqIGNvbnN0IGNvbG9yID0gbmV3IENvbG9yKCdyZWQnKTtcbiAgICpcbiAgICogLy8gRnVsbCBvcGFjaXR5ICgweEZGUlJHR0JCKVxuICAgKiBjb2xvci50b1ByZW11bHRpcGxpZWQoMS4wKTsgLy8gMHhGRkZGMDAwMFxuICAgKlxuICAgKiAvLyA1MCUgdHJhbnNwYXJlbmN5IHdpdGggcHJlbXVsdGlwbGllZCBSR0JcbiAgICogY29sb3IudG9QcmVtdWx0aXBsaWVkKDAuNSk7IC8vIDB4N0Y3RjAwMDBcbiAgICpcbiAgICogLy8gNTAlIHRyYW5zcGFyZW5jeSB3aXRob3V0IFJHQiBwcmVtdWx0aXBsaWNhdGlvblxuICAgKiBjb2xvci50b1ByZW11bHRpcGxpZWQoMC41LCBmYWxzZSk7IC8vIDB4N0ZGRjAwMDBcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gUmV0dXJucyBmdWxsIG9wYWNpdHkgKDB4RkYwMDAwMDApIHdoZW4gYWxwaGEgaXMgMS4wXG4gICAqIC0gUmV0dXJucyAwIHdoZW4gYWxwaGEgaXMgMC4wIGFuZCBhcHBseVRvUkdCIGlzIHRydWVcbiAgICogLSBSR0IgdmFsdWVzIGFyZSByb3VuZGVkIGR1cmluZyBwcmVtdWx0aXBsaWNhdGlvblxuICAgKi9cbiAgdG9QcmVtdWx0aXBsaWVkKGFscGhhLCBhcHBseVRvUkdCID0gdHJ1ZSkge1xuICAgIGlmIChhbHBoYSA9PT0gMSkge1xuICAgICAgcmV0dXJuICgyNTUgPDwgMjQpICsgdGhpcy5faW50O1xuICAgIH1cbiAgICBpZiAoYWxwaGEgPT09IDApIHtcbiAgICAgIHJldHVybiBhcHBseVRvUkdCID8gMCA6IHRoaXMuX2ludDtcbiAgICB9XG4gICAgbGV0IHIgPSB0aGlzLl9pbnQgPj4gMTYgJiAyNTU7XG4gICAgbGV0IGcgPSB0aGlzLl9pbnQgPj4gOCAmIDI1NTtcbiAgICBsZXQgYiA9IHRoaXMuX2ludCAmIDI1NTtcbiAgICBpZiAoYXBwbHlUb1JHQikge1xuICAgICAgciA9IHIgKiBhbHBoYSArIDAuNSB8IDA7XG4gICAgICBnID0gZyAqIGFscGhhICsgMC41IHwgMDtcbiAgICAgIGIgPSBiICogYWxwaGEgKyAwLjUgfCAwO1xuICAgIH1cbiAgICByZXR1cm4gKGFscGhhICogMjU1IDw8IDI0KSArIChyIDw8IDE2KSArIChnIDw8IDgpICsgYjtcbiAgfVxuICAvKipcbiAgICogQ29udmVydCB0byBhIGhleGFkZWNpbWFsIHN0cmluZyAoNiBjaGFyYWN0ZXJzKS5cbiAgICogQHJldHVybnMgQSBDU1MtY29tcGF0aWJsZSBoZXggY29sb3Igc3RyaW5nIChlLmcuLCBcIiNmZjAwMDBcIilcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IHsgQ29sb3IgfSBmcm9tICdwaXhpLmpzJztcbiAgICpcbiAgICogLy8gQmFzaWMgY29sb3JzXG4gICAqIG5ldyBDb2xvcigncmVkJykudG9IZXgoKTsgICAgLy8gcmV0dXJucyBcIiNmZjAwMDBcIlxuICAgKiBuZXcgQ29sb3IoJ3doaXRlJykudG9IZXgoKTsgIC8vIHJldHVybnMgXCIjZmZmZmZmXCJcbiAgICogbmV3IENvbG9yKCdibGFjaycpLnRvSGV4KCk7ICAvLyByZXR1cm5zIFwiIzAwMDAwMFwiXG4gICAqXG4gICAqIC8vIEZyb20gZGlmZmVyZW50IGZvcm1hdHNcbiAgICogbmV3IENvbG9yKDB4ZmYwMDAwKS50b0hleCgpOyAvLyByZXR1cm5zIFwiI2ZmMDAwMFwiXG4gICAqIG5ldyBDb2xvcihbMSwgMCwgMF0pLnRvSGV4KCk7IC8vIHJldHVybnMgXCIjZmYwMDAwXCJcbiAgICogbmV3IENvbG9yKHsgcjogMSwgZzogMCwgYjogMCB9KS50b0hleCgpOyAvLyByZXR1cm5zIFwiI2ZmMDAwMFwiXG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIEFsd2F5cyByZXR1cm5zIGEgNi1jaGFyYWN0ZXIgaGV4IHN0cmluZ1xuICAgKiAtIEluY2x1ZGVzIGxlYWRpbmcgXCIjXCIgY2hhcmFjdGVyXG4gICAqIC0gQWxwaGEgY2hhbm5lbCBpcyBpZ25vcmVkXG4gICAqIC0gVmFsdWVzIGFyZSByb3VuZGVkIHRvIG5lYXJlc3QgaGV4IHZhbHVlXG4gICAqL1xuICB0b0hleCgpIHtcbiAgICBjb25zdCBoZXhTdHJpbmcgPSB0aGlzLl9pbnQudG9TdHJpbmcoMTYpO1xuICAgIHJldHVybiBgIyR7XCIwMDAwMDBcIi5zdWJzdHJpbmcoMCwgNiAtIGhleFN0cmluZy5sZW5ndGgpICsgaGV4U3RyaW5nfWA7XG4gIH1cbiAgLyoqXG4gICAqIENvbnZlcnQgdG8gYSBoZXhhZGVjaW1hbCBzdHJpbmcgd2l0aCBhbHBoYSAoOCBjaGFyYWN0ZXJzKS5cbiAgICogQHJldHVybnMgQSBDU1MtY29tcGF0aWJsZSBoZXggY29sb3Igc3RyaW5nIHdpdGggYWxwaGEgKGUuZy4sIFwiI2ZmMDAwMGZmXCIpXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGltcG9ydCB7IENvbG9yIH0gZnJvbSAncGl4aS5qcyc7XG4gICAqXG4gICAqIC8vIEZ1bGx5IG9wYXF1ZSBjb2xvcnNcbiAgICogbmV3IENvbG9yKCdyZWQnKS50b0hleGEoKTsgICAvLyByZXR1cm5zIFwiI2ZmMDAwMGZmXCJcbiAgICogbmV3IENvbG9yKCd3aGl0ZScpLnRvSGV4YSgpOyAvLyByZXR1cm5zIFwiI2ZmZmZmZmZmXCJcbiAgICpcbiAgICogLy8gV2l0aCB0cmFuc3BhcmVuY3lcbiAgICogbmV3IENvbG9yKCdyZ2JhKDI1NSwgMCwgMCwgMC41KScpLnRvSGV4YSgpOyAvLyByZXR1cm5zIFwiI2ZmMDAwMDdmXCJcbiAgICogbmV3IENvbG9yKFsxLCAwLCAwLCAwXSkudG9IZXhhKCk7IC8vIHJldHVybnMgXCIjZmYwMDAwMDBcIlxuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBSZXR1cm5zIGFuIDgtY2hhcmFjdGVyIGhleCBzdHJpbmdcbiAgICogLSBJbmNsdWRlcyBsZWFkaW5nIFwiI1wiIGNoYXJhY3RlclxuICAgKiAtIEFscGhhIGlzIGVuY29kZWQgaW4gbGFzdCB0d28gY2hhcmFjdGVyc1xuICAgKiAtIFZhbHVlcyBhcmUgcm91bmRlZCB0byBuZWFyZXN0IGhleCB2YWx1ZVxuICAgKi9cbiAgdG9IZXhhKCkge1xuICAgIGNvbnN0IGFscGhhVmFsdWUgPSBNYXRoLnJvdW5kKHRoaXMuX2NvbXBvbmVudHNbM10gKiAyNTUpO1xuICAgIGNvbnN0IGFscGhhU3RyaW5nID0gYWxwaGFWYWx1ZS50b1N0cmluZygxNik7XG4gICAgcmV0dXJuIHRoaXMudG9IZXgoKSArIFwiMDBcIi5zdWJzdHJpbmcoMCwgMiAtIGFscGhhU3RyaW5nLmxlbmd0aCkgKyBhbHBoYVN0cmluZztcbiAgfVxuICAvKipcbiAgICogU2V0IGFscGhhICh0cmFuc3BhcmVuY3kpIHZhbHVlIHdoaWxlIHByZXNlcnZpbmcgY29sb3IgY29tcG9uZW50cy5cbiAgICpcbiAgICogUHJvdmlkZXMgYSBjaGFpbmFibGUgaW50ZXJmYWNlIGZvciBzZXR0aW5nIGFscGhhLlxuICAgKiBAcGFyYW0gYWxwaGEgLSBBbHBoYSB2YWx1ZSBiZXR3ZWVuIDAgKGZ1bGx5IHRyYW5zcGFyZW50KSBhbmQgMSAoZnVsbHkgb3BhcXVlKVxuICAgKiBAcmV0dXJucyBUaGUgQ29sb3IgaW5zdGFuY2UgZm9yIGNoYWluaW5nXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIGFscGhhIHNldHRpbmdcbiAgICogY29uc3QgY29sb3IgPSBuZXcgQ29sb3IoJ3JlZCcpO1xuICAgKiBjb2xvci5zZXRBbHBoYSgwLjUpOyAgLy8gNTAlIHRyYW5zcGFyZW50IHJlZFxuICAgKlxuICAgKiAvLyBDaGFpbiB3aXRoIG90aGVyIG9wZXJhdGlvbnNcbiAgICogY29sb3JcbiAgICogICAgIC5zZXRWYWx1ZSgnI2ZmMDAwMCcpXG4gICAqICAgICAuc2V0QWxwaGEoMC44KSAgICAvLyA4MCUgb3BhcXVlXG4gICAqICAgICAucHJlbXVsdGlwbHkoMC41KTsgLy8gRnVydGhlciBtb2RpZnkgYWxwaGFcbiAgICpcbiAgICogLy8gUmVzZXQgdG8gZnVsbHkgb3BhcXVlXG4gICAqIGNvbG9yLnNldEFscGhhKDEpO1xuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBBbHBoYSB2YWx1ZSBpcyBjbGFtcGVkIGJldHdlZW4gMC0xXG4gICAqIC0gQ2FuIGJlIGNoYWluZWQgd2l0aCBvdGhlciBjb2xvciBvcGVyYXRpb25zXG4gICAqL1xuICBzZXRBbHBoYShhbHBoYSkge1xuICAgIHRoaXMuX2NvbXBvbmVudHNbM10gPSB0aGlzLl9jbGFtcChhbHBoYSk7XG4gICAgdGhpcy5fdmFsdWUgPSBudWxsO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBOb3JtYWxpemUgdGhlIGlucHV0IHZhbHVlIGludG8gcmdiYVxuICAgKiBAcGFyYW0gdmFsdWUgLSBJbnB1dCB2YWx1ZVxuICAgKi9cbiAgX25vcm1hbGl6ZSh2YWx1ZSkge1xuICAgIGxldCByO1xuICAgIGxldCBnO1xuICAgIGxldCBiO1xuICAgIGxldCBhO1xuICAgIGlmICgodHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiIHx8IHZhbHVlIGluc3RhbmNlb2YgTnVtYmVyKSAmJiB2YWx1ZSA+PSAwICYmIHZhbHVlIDw9IDE2Nzc3MjE1KSB7XG4gICAgICBjb25zdCBpbnQgPSB2YWx1ZTtcbiAgICAgIHIgPSAoaW50ID4+IDE2ICYgMjU1KSAvIDI1NTtcbiAgICAgIGcgPSAoaW50ID4+IDggJiAyNTUpIC8gMjU1O1xuICAgICAgYiA9IChpbnQgJiAyNTUpIC8gMjU1O1xuICAgICAgYSA9IDE7XG4gICAgfSBlbHNlIGlmICgoQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgdmFsdWUgaW5zdGFuY2VvZiBGbG9hdDMyQXJyYXkpICYmIHZhbHVlLmxlbmd0aCA+PSAzICYmIHZhbHVlLmxlbmd0aCA8PSA0KSB7XG4gICAgICB2YWx1ZSA9IHRoaXMuX2NsYW1wKHZhbHVlKTtcbiAgICAgIFtyLCBnLCBiLCBhID0gMV0gPSB2YWx1ZTtcbiAgICB9IGVsc2UgaWYgKCh2YWx1ZSBpbnN0YW5jZW9mIFVpbnQ4QXJyYXkgfHwgdmFsdWUgaW5zdGFuY2VvZiBVaW50OENsYW1wZWRBcnJheSkgJiYgdmFsdWUubGVuZ3RoID49IDMgJiYgdmFsdWUubGVuZ3RoIDw9IDQpIHtcbiAgICAgIHZhbHVlID0gdGhpcy5fY2xhbXAodmFsdWUsIDAsIDI1NSk7XG4gICAgICBbciwgZywgYiwgYSA9IDI1NV0gPSB2YWx1ZTtcbiAgICAgIHIgLz0gMjU1O1xuICAgICAgZyAvPSAyNTU7XG4gICAgICBiIC89IDI1NTtcbiAgICAgIGEgLz0gMjU1O1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIikge1xuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBjb25zdCBtYXRjaCA9IF9Db2xvci5IRVhfUEFUVEVSTi5leGVjKHZhbHVlKTtcbiAgICAgICAgaWYgKG1hdGNoKSB7XG4gICAgICAgICAgdmFsdWUgPSBgIyR7bWF0Y2hbMl19YDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY29uc3QgY29sb3IgPSBjb2xvcmQodmFsdWUpO1xuICAgICAgaWYgKGNvbG9yLmlzVmFsaWQoKSkge1xuICAgICAgICAoeyByLCBnLCBiLCBhIH0gPSBjb2xvci5yZ2JhKTtcbiAgICAgICAgciAvPSAyNTU7XG4gICAgICAgIGcgLz0gMjU1O1xuICAgICAgICBiIC89IDI1NTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHIgIT09IHZvaWQgMCkge1xuICAgICAgdGhpcy5fY29tcG9uZW50c1swXSA9IHI7XG4gICAgICB0aGlzLl9jb21wb25lbnRzWzFdID0gZztcbiAgICAgIHRoaXMuX2NvbXBvbmVudHNbMl0gPSBiO1xuICAgICAgdGhpcy5fY29tcG9uZW50c1szXSA9IGE7XG4gICAgICB0aGlzLl9yZWZyZXNoSW50KCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgVW5hYmxlIHRvIGNvbnZlcnQgY29sb3IgJHt2YWx1ZX1gKTtcbiAgICB9XG4gIH1cbiAgLyoqIFJlZnJlc2ggdGhlIGludGVybmFsIGNvbG9yIHJnYiBudW1iZXIgKi9cbiAgX3JlZnJlc2hJbnQoKSB7XG4gICAgdGhpcy5fY2xhbXAodGhpcy5fY29tcG9uZW50cyk7XG4gICAgY29uc3QgW3IsIGcsIGJdID0gdGhpcy5fY29tcG9uZW50cztcbiAgICB0aGlzLl9pbnQgPSAociAqIDI1NSA8PCAxNikgKyAoZyAqIDI1NSA8PCA4KSArIChiICogMjU1IHwgMCk7XG4gIH1cbiAgLyoqXG4gICAqIENsYW1wcyB2YWx1ZXMgdG8gYSByYW5nZS4gV2lsbCBvdmVycmlkZSBvcmlnaW5hbCB2YWx1ZXNcbiAgICogQHBhcmFtIHZhbHVlIC0gVmFsdWUocykgdG8gY2xhbXBcbiAgICogQHBhcmFtIG1pbiAtIE1pbmltdW0gdmFsdWVcbiAgICogQHBhcmFtIG1heCAtIE1heGltdW0gdmFsdWVcbiAgICovXG4gIF9jbGFtcCh2YWx1ZSwgbWluID0gMCwgbWF4ID0gMSkge1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgIHJldHVybiBNYXRoLm1pbihNYXRoLm1heCh2YWx1ZSwgbWluKSwgbWF4KTtcbiAgICB9XG4gICAgdmFsdWUuZm9yRWFjaCgodiwgaSkgPT4ge1xuICAgICAgdmFsdWVbaV0gPSBNYXRoLm1pbihNYXRoLm1heCh2LCBtaW4pLCBtYXgpO1xuICAgIH0pO1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICAvKipcbiAgICogQ2hlY2sgaWYgYSB2YWx1ZSBjYW4gYmUgaW50ZXJwcmV0ZWQgYXMgYSB2YWxpZCBjb2xvciBmb3JtYXQuXG4gICAqIFN1cHBvcnRzIGFsbCBjb2xvciBmb3JtYXRzIHRoYXQgY2FuIGJlIHVzZWQgd2l0aCB0aGUgQ29sb3IgY2xhc3MuXG4gICAqIEBwYXJhbSB2YWx1ZSAtIFZhbHVlIHRvIGNoZWNrXG4gICAqIEByZXR1cm5zIFRydWUgaWYgdGhlIHZhbHVlIGNhbiBiZSB1c2VkIGFzIGEgY29sb3JcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IHsgQ29sb3IgfSBmcm9tICdwaXhpLmpzJztcbiAgICpcbiAgICogLy8gQ1NTIGNvbG9ycyBhbmQgaGV4IHZhbHVlc1xuICAgKiBDb2xvci5pc0NvbG9yTGlrZSgncmVkJyk7ICAgICAgICAgIC8vIHRydWVcbiAgICogQ29sb3IuaXNDb2xvckxpa2UoJyNmZjAwMDAnKTsgICAgICAvLyB0cnVlXG4gICAqIENvbG9yLmlzQ29sb3JMaWtlKDB4ZmYwMDAwKTsgICAgICAgLy8gdHJ1ZVxuICAgKlxuICAgKiAvLyBBcnJheXMgKFJHQi9SR0JBKVxuICAgKiBDb2xvci5pc0NvbG9yTGlrZShbMSwgMCwgMF0pOyAgICAgIC8vIHRydWVcbiAgICogQ29sb3IuaXNDb2xvckxpa2UoWzEsIDAsIDAsIDAuNV0pOyAvLyB0cnVlXG4gICAqXG4gICAqIC8vIFR5cGVkQXJyYXlzXG4gICAqIENvbG9yLmlzQ29sb3JMaWtlKG5ldyBGbG9hdDMyQXJyYXkoWzEsIDAsIDBdKSk7ICAgICAgICAgIC8vIHRydWVcbiAgICogQ29sb3IuaXNDb2xvckxpa2UobmV3IFVpbnQ4QXJyYXkoWzI1NSwgMCwgMF0pKTsgICAgICAgICAgLy8gdHJ1ZVxuICAgKiBDb2xvci5pc0NvbG9yTGlrZShuZXcgVWludDhDbGFtcGVkQXJyYXkoWzI1NSwgMCwgMF0pKTsgICAvLyB0cnVlXG4gICAqXG4gICAqIC8vIE9iamVjdCBmb3JtYXRzXG4gICAqIENvbG9yLmlzQ29sb3JMaWtlKHsgcjogMSwgZzogMCwgYjogMCB9KTsgICAgICAgICAgICAvLyB0cnVlIChSR0IpXG4gICAqIENvbG9yLmlzQ29sb3JMaWtlKHsgcjogMSwgZzogMCwgYjogMCwgYTogMC41IH0pOyAgICAvLyB0cnVlIChSR0JBKVxuICAgKiBDb2xvci5pc0NvbG9yTGlrZSh7IGg6IDAsIHM6IDEwMCwgbDogNTAgfSk7ICAgICAgICAgLy8gdHJ1ZSAoSFNMKVxuICAgKiBDb2xvci5pc0NvbG9yTGlrZSh7IGg6IDAsIHM6IDEwMCwgbDogNTAsIGE6IDAuNSB9KTsgLy8gdHJ1ZSAoSFNMQSlcbiAgICogQ29sb3IuaXNDb2xvckxpa2UoeyBoOiAwLCBzOiAxMDAsIHY6IDEwMCB9KTsgICAgICAgIC8vIHRydWUgKEhTVilcbiAgICogQ29sb3IuaXNDb2xvckxpa2UoeyBoOiAwLCBzOiAxMDAsIHY6IDEwMCwgYTogMC41IH0pOy8vIHRydWUgKEhTVkEpXG4gICAqXG4gICAqIC8vIENvbG9yIGluc3RhbmNlc1xuICAgKiBDb2xvci5pc0NvbG9yTGlrZShuZXcgQ29sb3IoJ3JlZCcpKTsgLy8gdHJ1ZVxuICAgKlxuICAgKiAvLyBJbnZhbGlkIHZhbHVlc1xuICAgKiBDb2xvci5pc0NvbG9yTGlrZShudWxsKTsgICAgICAgICAgIC8vIGZhbHNlXG4gICAqIENvbG9yLmlzQ29sb3JMaWtlKHVuZGVmaW5lZCk7ICAgICAgLy8gZmFsc2VcbiAgICogQ29sb3IuaXNDb2xvckxpa2Uoe30pOyAgICAgICAgICAgICAvLyBmYWxzZVxuICAgKiBDb2xvci5pc0NvbG9yTGlrZShbXSk7ICAgICAgICAgICAgIC8vIGZhbHNlXG4gICAqIENvbG9yLmlzQ29sb3JMaWtlKCdub3QtYS1jb2xvcicpOyAgLy8gZmFsc2VcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIENoZWNrcyBmb3IgdGhlIGZvbGxvd2luZyBmb3JtYXRzOlxuICAgKiAtIE51bWJlcnMgKDB4MDAwMDAwIHRvIDB4ZmZmZmZmKVxuICAgKiAtIENTUyBjb2xvciBzdHJpbmdzXG4gICAqIC0gUkdCL1JHQkEgYXJyYXlzIGFuZCBvYmplY3RzXG4gICAqIC0gSFNML0hTTEEgb2JqZWN0c1xuICAgKiAtIEhTVi9IU1ZBIG9iamVjdHNcbiAgICogLSBUeXBlZEFycmF5cyAoRmxvYXQzMkFycmF5LCBVaW50OEFycmF5LCBVaW50OENsYW1wZWRBcnJheSlcbiAgICogLSBDb2xvciBpbnN0YW5jZXNcbiAgICogQHNlZSB7QGxpbmsgQ29sb3JTb3VyY2V9IEZvciBzdXBwb3J0ZWQgY29sb3IgZm9ybWF0IHR5cGVzXG4gICAqIEBzZWUge0BsaW5rIENvbG9yLnNldFZhbHVlfSBGb3Igc2V0dGluZyBjb2xvciB2YWx1ZXNcbiAgICogQGNhdGVnb3J5IHV0aWxpdHlcbiAgICovXG4gIHN0YXRpYyBpc0NvbG9yTGlrZSh2YWx1ZSkge1xuICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIgfHwgdHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiIHx8IHZhbHVlIGluc3RhbmNlb2YgTnVtYmVyIHx8IHZhbHVlIGluc3RhbmNlb2YgX0NvbG9yIHx8IEFycmF5LmlzQXJyYXkodmFsdWUpIHx8IHZhbHVlIGluc3RhbmNlb2YgVWludDhBcnJheSB8fCB2YWx1ZSBpbnN0YW5jZW9mIFVpbnQ4Q2xhbXBlZEFycmF5IHx8IHZhbHVlIGluc3RhbmNlb2YgRmxvYXQzMkFycmF5IHx8IHZhbHVlLnIgIT09IHZvaWQgMCAmJiB2YWx1ZS5nICE9PSB2b2lkIDAgJiYgdmFsdWUuYiAhPT0gdm9pZCAwIHx8IHZhbHVlLnIgIT09IHZvaWQgMCAmJiB2YWx1ZS5nICE9PSB2b2lkIDAgJiYgdmFsdWUuYiAhPT0gdm9pZCAwICYmIHZhbHVlLmEgIT09IHZvaWQgMCB8fCB2YWx1ZS5oICE9PSB2b2lkIDAgJiYgdmFsdWUucyAhPT0gdm9pZCAwICYmIHZhbHVlLmwgIT09IHZvaWQgMCB8fCB2YWx1ZS5oICE9PSB2b2lkIDAgJiYgdmFsdWUucyAhPT0gdm9pZCAwICYmIHZhbHVlLmwgIT09IHZvaWQgMCAmJiB2YWx1ZS5hICE9PSB2b2lkIDAgfHwgdmFsdWUuaCAhPT0gdm9pZCAwICYmIHZhbHVlLnMgIT09IHZvaWQgMCAmJiB2YWx1ZS52ICE9PSB2b2lkIDAgfHwgdmFsdWUuaCAhPT0gdm9pZCAwICYmIHZhbHVlLnMgIT09IHZvaWQgMCAmJiB2YWx1ZS52ICE9PSB2b2lkIDAgJiYgdmFsdWUuYSAhPT0gdm9pZCAwO1xuICB9XG59O1xuLyoqXG4gKiBTdGF0aWMgc2hhcmVkIENvbG9yIGluc3RhbmNlIHVzZWQgZm9yIHV0aWxpdHkgb3BlcmF0aW9ucy4gVGhpcyBpcyBhIHNpbmdsZXRvbiBjb2xvciBvYmplY3RcbiAqIHRoYXQgY2FuIGJlIHJldXNlZCB0byBhdm9pZCBjcmVhdGluZyB1bm5lY2Vzc2FyeSBDb2xvciBpbnN0YW5jZXMuXG4gKiA+IFshSU1QT1JUQU5UXSBZb3Ugc2hvdWxkIGJlIGNhcmVmdWwgd2hlbiB1c2luZyB0aGlzIHNoYXJlZCBpbnN0YW5jZSwgYXMgaXQgaXMgbXV0YWJsZSBhbmQgY2FuIGJlXG4gKiA+IGNoYW5nZWQgYnkgYW55IGNvZGUgdGhhdCB1c2VzIGl0LlxuICogPlxuICogPiBJdCBpcyBiZXN0IHVzZWQgZm9yIG9uZS1vZmYgY29sb3Igb3BlcmF0aW9ucyBvciB0ZW1wb3JhcnkgdHJhbnNmb3JtYXRpb25zLlxuICogPiBGb3IgcGVyc2lzdGVudCBjb2xvcnMsIGNyZWF0ZSB5b3VyIG93biBDb2xvciBpbnN0YW5jZSBpbnN0ZWFkLlxuICogQGV4YW1wbGVcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBDb2xvciB9IGZyb20gJ3BpeGkuanMnO1xuICpcbiAqIC8vIFVzZSBzaGFyZWQgaW5zdGFuY2UgZm9yIG9uZS1vZmYgY29sb3Igb3BlcmF0aW9uc1xuICogQ29sb3Iuc2hhcmVkLnNldFZhbHVlKDB4ZmYwMDAwKTtcbiAqIGNvbnN0IHJlZEhleCA9IENvbG9yLnNoYXJlZC50b0hleCgpOyAgICAgLy8gXCIjZmYwMDAwXCJcbiAqIGNvbnN0IHJlZFJnYiA9IENvbG9yLnNoYXJlZC50b1JnYkFycmF5KCk7IC8vIFsxLCAwLCAwXVxuICpcbiAqIC8vIFRlbXBvcmFyeSBjb2xvciB0cmFuc2Zvcm1hdGlvbnNcbiAqIGNvbnN0IGNvbG9yTnVtYmVyID0gQ29sb3Iuc2hhcmVkXG4gKiAgICAgLnNldFZhbHVlKCcjZmYwMDAwJykgICAgIC8vIFNldCB0byByZWRcbiAqICAgICAuc2V0QWxwaGEoMC41KSAgICAgICAgICAvLyBNYWtlIHNlbWktdHJhbnNwYXJlbnRcbiAqICAgICAucHJlbXVsdGlwbHkoMC44KSAgICAgICAvLyBBcHBseSBwcmVtdWx0aXBsaWNhdGlvblxuICogICAgIC50b051bWJlcigpOyAgICAgICAgICAgIC8vIENvbnZlcnQgdG8gbnVtYmVyXG4gKlxuICogLy8gQ2hhaW4gbXVsdGlwbGUgb3BlcmF0aW9uc1xuICogY29uc3QgcmVzdWx0ID0gQ29sb3Iuc2hhcmVkXG4gKiAgICAgLnNldFZhbHVlKHNvbWVDb2xvcilcbiAqICAgICAubXVsdGlwbHkodGludENvbG9yKVxuICogICAgIC50b1ByZW11bHRpcGxpZWQoYWxwaGEpO1xuICogYGBgXG4gKiBAcmVtYXJrc1xuICogLSBUaGlzIGlzIGEgc2hhcmVkIGluc3RhbmNlIC0gYmUgY2FyZWZ1bCBhYm91dCBtdWx0aXBsZSBjb2RlIHBhdGhzIHVzaW5nIGl0IHNpbXVsdGFuZW91c2x5XG4gKiAtIFVzZSBmb3IgdGVtcG9yYXJ5IGNvbG9yIG9wZXJhdGlvbnMgdG8gYXZvaWQgYWxsb2NhdGluZyBuZXcgQ29sb3IgaW5zdGFuY2VzXG4gKiAtIFRoZSB2YWx1ZSBpcyBwcmVzZXJ2ZWQgYmV0d2VlbiBvcGVyYXRpb25zLCBzbyByZXNldCBpZiBuZWVkZWRcbiAqIC0gRm9yIHBlcnNpc3RlbnQgY29sb3JzLCBjcmVhdGUgeW91ciBvd24gQ29sb3IgaW5zdGFuY2UgaW5zdGVhZFxuICovXG5fQ29sb3Iuc2hhcmVkID0gbmV3IF9Db2xvcigpO1xuLyoqXG4gKiBUZW1wb3JhcnkgQ29sb3Igb2JqZWN0IGZvciBzdGF0aWMgdXNlcyBpbnRlcm5hbGx5LlxuICogQXMgdG8gbm90IGNvbmZsaWN0IHdpdGggQ29sb3Iuc2hhcmVkLlxuICogQGlnbm9yZVxuICovXG5fQ29sb3IuX3RlbXAgPSBuZXcgX0NvbG9yKCk7XG4vKiogUGF0dGVybiBmb3IgaGV4IHN0cmluZ3MgKi9cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbmFtaW5nLWNvbnZlbnRpb25cbl9Db2xvci5IRVhfUEFUVEVSTiA9IC9eKCN8MHgpPygoW2EtZjAtOV17M30pezEsMn0oW2EtZjAtOV17Mn0pPykkL2k7XG5sZXQgQ29sb3IgPSBfQ29sb3I7XG5cbmV4cG9ydCB7IENvbG9yIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1Db2xvci5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmxldCB3YXJuQ291bnQgPSAwO1xuY29uc3QgbWF4V2FybmluZ3MgPSA1MDA7XG5mdW5jdGlvbiB3YXJuKC4uLmFyZ3MpIHtcbiAgaWYgKHdhcm5Db3VudCA9PT0gbWF4V2FybmluZ3MpIHJldHVybjtcbiAgd2FybkNvdW50Kys7XG4gIGlmICh3YXJuQ291bnQgPT09IG1heFdhcm5pbmdzKSB7XG4gICAgY29uc29sZS53YXJuKFwiUGl4aUpTIFdhcm5pbmc6IHRvbyBtYW55IHdhcm5pbmdzLCBubyBtb3JlIHdhcm5pbmdzIHdpbGwgYmUgcmVwb3J0ZWQgdG8gdGhlIGNvbnNvbGUgYnkgUGl4aUpTLlwiKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zb2xlLndhcm4oXCJQaXhpSlMgV2FybmluZzogXCIsIC4uLmFyZ3MpO1xuICB9XG59XG5cbmV4cG9ydCB7IHdhcm4gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXdhcm4ubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBHbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5ID0ge1xuICAvKipcbiAgICogU2V0IG9mIHJlZ2lzdGVyZWQgcG9vbHMgYW5kIGNsZWFuYWJsZSBvYmplY3RzLlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3JlZ2lzdGVyZWRSZXNvdXJjZXM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYSBwb29sIG9yIGNsZWFuYWJsZSBvYmplY3QgZm9yIGNsZWFudXAuXG4gICAqIEBwYXJhbSB7Q2xlYW5hYmxlfSBwb29sIC0gVGhlIHBvb2wgb3Igb2JqZWN0IHRvIHJlZ2lzdGVyLlxuICAgKi9cbiAgcmVnaXN0ZXIocG9vbCkge1xuICAgIHRoaXMuX3JlZ2lzdGVyZWRSZXNvdXJjZXMuYWRkKHBvb2wpO1xuICB9LFxuICAvKipcbiAgICogVW5yZWdpc3RlcnMgYSBwb29sIG9yIGNsZWFuYWJsZSBvYmplY3QgZnJvbSBjbGVhbnVwLlxuICAgKiBAcGFyYW0ge0NsZWFuYWJsZX0gcG9vbCAtIFRoZSBwb29sIG9yIG9iamVjdCB0byB1bnJlZ2lzdGVyLlxuICAgKi9cbiAgdW5yZWdpc3Rlcihwb29sKSB7XG4gICAgdGhpcy5fcmVnaXN0ZXJlZFJlc291cmNlcy5kZWxldGUocG9vbCk7XG4gIH0sXG4gIC8qKiBDbGVhcnMgYWxsIHJlZ2lzdGVyZWQgcG9vbHMgYW5kIGNsZWFuYWJsZSBvYmplY3RzLiBUaGlzIHdpbGwgY2FsbCBjbGVhcigpIG9uIGVhY2ggcmVnaXN0ZXJlZCBpdGVtLiAqL1xuICByZWxlYXNlKCkge1xuICAgIHRoaXMuX3JlZ2lzdGVyZWRSZXNvdXJjZXMuZm9yRWFjaCgocG9vbCkgPT4gcG9vbC5jbGVhcigpKTtcbiAgfSxcbiAgLyoqXG4gICAqIEdldHMgdGhlIG51bWJlciBvZiByZWdpc3RlcmVkIHBvb2xzIGFuZCBjbGVhbmFibGUgb2JqZWN0cy5cbiAgICogQHJldHVybnMge251bWJlcn0gVGhlIGNvdW50IG9mIHJlZ2lzdGVyZWQgaXRlbXMuXG4gICAqL1xuICBnZXQgcmVnaXN0ZXJlZENvdW50KCkge1xuICAgIHJldHVybiB0aGlzLl9yZWdpc3RlcmVkUmVzb3VyY2VzLnNpemU7XG4gIH0sXG4gIC8qKlxuICAgKiBDaGVja3MgaWYgYSBzcGVjaWZpYyBwb29sIG9yIGNsZWFuYWJsZSBvYmplY3QgaXMgcmVnaXN0ZXJlZC5cbiAgICogQHBhcmFtIHtDbGVhbmFibGV9IHBvb2wgLSBUaGUgcG9vbCBvciBvYmplY3QgdG8gY2hlY2suXG4gICAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHRoZSBpdGVtIGlzIHJlZ2lzdGVyZWQsIGZhbHNlIG90aGVyd2lzZS5cbiAgICovXG4gIGlzUmVnaXN0ZXJlZChwb29sKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JlZ2lzdGVyZWRSZXNvdXJjZXMuaGFzKHBvb2wpO1xuICB9LFxuICAvKipcbiAgICogUmVtb3ZlcyBhbGwgcmVnaXN0cmF0aW9ucyB3aXRob3V0IGNsZWFyaW5nIHRoZSBwb29scy5cbiAgICogVXNlZnVsIGlmIHlvdSB3YW50IHRvIHJlc2V0IHRoZSBjb2xsZWN0b3Igd2l0aG91dCBhZmZlY3RpbmcgdGhlIHBvb2xzLlxuICAgKi9cbiAgcmVzZXQoKSB7XG4gICAgdGhpcy5fcmVnaXN0ZXJlZFJlc291cmNlcy5jbGVhcigpO1xuICB9XG59O1xuXG5leHBvcnQgeyBHbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1HbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5Lm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY2xhc3MgUG9vbCB7XG4gIC8qKlxuICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFBvb2wuXG4gICAqIEBwYXJhbSBDbGFzc1R5cGUgLSBUaGUgY29uc3RydWN0b3Igb2YgdGhlIGl0ZW1zIGluIHRoZSBwb29sLlxuICAgKiBAcGFyYW0ge251bWJlcn0gW2luaXRpYWxTaXplXSAtIFRoZSBpbml0aWFsIHNpemUgb2YgdGhlIHBvb2wuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihDbGFzc1R5cGUsIGluaXRpYWxTaXplKSB7XG4gICAgdGhpcy5fcG9vbCA9IFtdO1xuICAgIHRoaXMuX2NvdW50ID0gMDtcbiAgICB0aGlzLl9pbmRleCA9IDA7XG4gICAgdGhpcy5fY2xhc3NUeXBlID0gQ2xhc3NUeXBlO1xuICAgIGlmIChpbml0aWFsU2l6ZSkge1xuICAgICAgdGhpcy5wcmVwb3B1bGF0ZShpbml0aWFsU2l6ZSk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBQcmVwb3B1bGF0ZXMgdGhlIHBvb2wgd2l0aCBhIGdpdmVuIG51bWJlciBvZiBpdGVtcy5cbiAgICogQHBhcmFtIHRvdGFsIC0gVGhlIG51bWJlciBvZiBpdGVtcyB0byBhZGQgdG8gdGhlIHBvb2wuXG4gICAqL1xuICBwcmVwb3B1bGF0ZSh0b3RhbCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdG90YWw7IGkrKykge1xuICAgICAgdGhpcy5fcG9vbFt0aGlzLl9pbmRleCsrXSA9IG5ldyB0aGlzLl9jbGFzc1R5cGUoKTtcbiAgICB9XG4gICAgdGhpcy5fY291bnQgKz0gdG90YWw7XG4gIH1cbiAgLyoqXG4gICAqIEdldHMgYW4gaXRlbSBmcm9tIHRoZSBwb29sLiBDYWxscyB0aGUgaXRlbSdzIGBpbml0YCBtZXRob2QgaWYgaXQgZXhpc3RzLlxuICAgKiBJZiB0aGVyZSBhcmUgbm8gaXRlbXMgbGVmdCBpbiB0aGUgcG9vbCwgYSBuZXcgb25lIHdpbGwgYmUgY3JlYXRlZC5cbiAgICogQHBhcmFtIHtJfSBbZGF0YV0gLSBPcHRpb25hbCBkYXRhIHRvIHBhc3MgdG8gdGhlIGl0ZW0ncyBjb25zdHJ1Y3Rvci5cbiAgICogQHJldHVybnMge1R9IFRoZSBpdGVtIGZyb20gdGhlIHBvb2wuXG4gICAqL1xuICBnZXQoZGF0YSkge1xuICAgIGxldCBpdGVtO1xuICAgIGlmICh0aGlzLl9pbmRleCA+IDApIHtcbiAgICAgIGl0ZW0gPSB0aGlzLl9wb29sWy0tdGhpcy5faW5kZXhdO1xuICAgIH0gZWxzZSB7XG4gICAgICBpdGVtID0gbmV3IHRoaXMuX2NsYXNzVHlwZSgpO1xuICAgICAgdGhpcy5fY291bnQrKztcbiAgICB9XG4gICAgaXRlbS5pbml0Py4oZGF0YSk7XG4gICAgcmV0dXJuIGl0ZW07XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gaXRlbSB0byB0aGUgcG9vbC4gQ2FsbHMgdGhlIGl0ZW0ncyBgcmVzZXRgIG1ldGhvZCBpZiBpdCBleGlzdHMuXG4gICAqIEBwYXJhbSB7VH0gaXRlbSAtIFRoZSBpdGVtIHRvIHJldHVybiB0byB0aGUgcG9vbC5cbiAgICovXG4gIHJldHVybihpdGVtKSB7XG4gICAgaXRlbS5yZXNldD8uKCk7XG4gICAgdGhpcy5fcG9vbFt0aGlzLl9pbmRleCsrXSA9IGl0ZW07XG4gIH1cbiAgLyoqXG4gICAqIEdldHMgdGhlIG51bWJlciBvZiBpdGVtcyBpbiB0aGUgcG9vbC5cbiAgICogQHJlYWRvbmx5XG4gICAqL1xuICBnZXQgdG90YWxTaXplKCkge1xuICAgIHJldHVybiB0aGlzLl9jb3VudDtcbiAgfVxuICAvKipcbiAgICogR2V0cyB0aGUgbnVtYmVyIG9mIGl0ZW1zIGluIHRoZSBwb29sIHRoYXQgYXJlIGZyZWUgdG8gdXNlIHdpdGhvdXQgbmVlZGluZyB0byBjcmVhdGUgbW9yZS5cbiAgICogQHJlYWRvbmx5XG4gICAqL1xuICBnZXQgdG90YWxGcmVlKCkge1xuICAgIHJldHVybiB0aGlzLl9pbmRleDtcbiAgfVxuICAvKipcbiAgICogR2V0cyB0aGUgbnVtYmVyIG9mIGl0ZW1zIGluIHRoZSBwb29sIHRoYXQgYXJlIGN1cnJlbnRseSBpbiB1c2UuXG4gICAqIEByZWFkb25seVxuICAgKi9cbiAgZ2V0IHRvdGFsVXNlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY291bnQgLSB0aGlzLl9pbmRleDtcbiAgfVxuICAvKiogY2xlYXJzIHRoZSBwb29sICovXG4gIGNsZWFyKCkge1xuICAgIGlmICh0aGlzLl9wb29sLmxlbmd0aCA+IDAgJiYgdGhpcy5fcG9vbFswXS5kZXN0cm95KSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuX2luZGV4OyBpKyspIHtcbiAgICAgICAgdGhpcy5fcG9vbFtpXS5kZXN0cm95KCk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuX3Bvb2wubGVuZ3RoID0gMDtcbiAgICB0aGlzLl9jb3VudCA9IDA7XG4gICAgdGhpcy5faW5kZXggPSAwO1xuICB9XG59XG5cbmV4cG9ydCB7IFBvb2wgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVBvb2wubWpzLm1hcFxuIiwiaW1wb3J0IHsgR2xvYmFsUmVzb3VyY2VSZWdpc3RyeSB9IGZyb20gJy4vR2xvYmFsUmVzb3VyY2VSZWdpc3RyeS5tanMnO1xuaW1wb3J0IHsgUG9vbCB9IGZyb20gJy4vUG9vbC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIFBvb2xHcm91cENsYXNzIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLyoqXG4gICAgICogQSBtYXAgdG8gc3RvcmUgdGhlIHBvb2xzIGJ5IHRoZWlyIGNsYXNzIHR5cGUuXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICB0aGlzLl9wb29sc0J5Q2xhc3MgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICB9XG4gIC8qKlxuICAgKiBQcmVwb3B1bGF0ZXMgYSBzcGVjaWZpYyBwb29sIHdpdGggYSBnaXZlbiBudW1iZXIgb2YgaXRlbXMuXG4gICAqIEB0ZW1wbGF0ZSBUIFRoZSB0eXBlIG9mIGl0ZW1zIGluIHRoZSBwb29sLiBNdXN0IGV4dGVuZCBQb29sSXRlbS5cbiAgICogQHBhcmFtIHtQb29sSXRlbUNvbnN0cnVjdG9yPFQ+fSBDbGFzcyAtIFRoZSBjb25zdHJ1Y3RvciBvZiB0aGUgaXRlbXMgaW4gdGhlIHBvb2wuXG4gICAqIEBwYXJhbSB7bnVtYmVyfSB0b3RhbCAtIFRoZSBudW1iZXIgb2YgaXRlbXMgdG8gYWRkIHRvIHRoZSBwb29sLlxuICAgKi9cbiAgcHJlcG9wdWxhdGUoQ2xhc3MsIHRvdGFsKSB7XG4gICAgY29uc3QgY2xhc3NQb29sID0gdGhpcy5nZXRQb29sKENsYXNzKTtcbiAgICBjbGFzc1Bvb2wucHJlcG9wdWxhdGUodG90YWwpO1xuICB9XG4gIC8qKlxuICAgKiBHZXRzIGFuIGl0ZW0gZnJvbSBhIHNwZWNpZmljIHBvb2wuXG4gICAqIEB0ZW1wbGF0ZSBUIFRoZSB0eXBlIG9mIGl0ZW1zIGluIHRoZSBwb29sLiBNdXN0IGV4dGVuZCBQb29sSXRlbS5cbiAgICogQHBhcmFtIHtQb29sSXRlbUNvbnN0cnVjdG9yPFQ+fSBDbGFzcyAtIFRoZSBjb25zdHJ1Y3RvciBvZiB0aGUgaXRlbXMgaW4gdGhlIHBvb2wuXG4gICAqIEBwYXJhbSB7dW5rbm93bn0gW2RhdGFdIC0gT3B0aW9uYWwgZGF0YSB0byBwYXNzIHRvIHRoZSBpdGVtJ3MgY29uc3RydWN0b3IuXG4gICAqIEByZXR1cm5zIHtUfSBUaGUgaXRlbSBmcm9tIHRoZSBwb29sLlxuICAgKi9cbiAgZ2V0KENsYXNzLCBkYXRhKSB7XG4gICAgY29uc3QgcG9vbCA9IHRoaXMuZ2V0UG9vbChDbGFzcyk7XG4gICAgcmV0dXJuIHBvb2wuZ2V0KGRhdGEpO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIGFuIGl0ZW0gdG8gaXRzIHJlc3BlY3RpdmUgcG9vbC5cbiAgICogQHBhcmFtIHtQb29sSXRlbX0gaXRlbSAtIFRoZSBpdGVtIHRvIHJldHVybiB0byB0aGUgcG9vbC5cbiAgICovXG4gIHJldHVybihpdGVtKSB7XG4gICAgY29uc3QgcG9vbCA9IHRoaXMuZ2V0UG9vbChpdGVtLmNvbnN0cnVjdG9yKTtcbiAgICBwb29sLnJldHVybihpdGVtKTtcbiAgfVxuICAvKipcbiAgICogR2V0cyBhIHNwZWNpZmljIHBvb2wgYmFzZWQgb24gdGhlIGNsYXNzIHR5cGUuXG4gICAqIEB0ZW1wbGF0ZSBUIFRoZSB0eXBlIG9mIGl0ZW1zIGluIHRoZSBwb29sLiBNdXN0IGV4dGVuZCBQb29sSXRlbS5cbiAgICogQHBhcmFtIHtQb29sSXRlbUNvbnN0cnVjdG9yPFQ+fSBDbGFzc1R5cGUgLSBUaGUgY29uc3RydWN0b3Igb2YgdGhlIGl0ZW1zIGluIHRoZSBwb29sLlxuICAgKiBAcmV0dXJucyB7UG9vbDxUPn0gVGhlIHBvb2wgb2YgdGhlIGdpdmVuIGNsYXNzIHR5cGUuXG4gICAqL1xuICBnZXRQb29sKENsYXNzVHlwZSkge1xuICAgIGlmICghdGhpcy5fcG9vbHNCeUNsYXNzLmhhcyhDbGFzc1R5cGUpKSB7XG4gICAgICB0aGlzLl9wb29sc0J5Q2xhc3Muc2V0KENsYXNzVHlwZSwgbmV3IFBvb2woQ2xhc3NUeXBlKSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9wb29sc0J5Q2xhc3MuZ2V0KENsYXNzVHlwZSk7XG4gIH1cbiAgLyoqIGdldHMgdGhlIHVzYWdlIHN0YXRzIG9mIGVhY2ggcG9vbCBpbiB0aGUgc3lzdGVtICovXG4gIHN0YXRzKCkge1xuICAgIGNvbnN0IHN0YXRzID0ge307XG4gICAgdGhpcy5fcG9vbHNCeUNsYXNzLmZvckVhY2goKHBvb2wpID0+IHtcbiAgICAgIGNvbnN0IG5hbWUgPSBzdGF0c1twb29sLl9jbGFzc1R5cGUubmFtZV0gPyBwb29sLl9jbGFzc1R5cGUubmFtZSArIHBvb2wuX2NsYXNzVHlwZS5JRCA6IHBvb2wuX2NsYXNzVHlwZS5uYW1lO1xuICAgICAgc3RhdHNbbmFtZV0gPSB7XG4gICAgICAgIGZyZWU6IHBvb2wudG90YWxGcmVlLFxuICAgICAgICB1c2VkOiBwb29sLnRvdGFsVXNlZCxcbiAgICAgICAgc2l6ZTogcG9vbC50b3RhbFNpemVcbiAgICAgIH07XG4gICAgfSk7XG4gICAgcmV0dXJuIHN0YXRzO1xuICB9XG4gIC8qKiBDbGVhcnMgYWxsIHBvb2xzIGluIHRoZSBncm91cC4gVGhpcyB3aWxsIHJlc2V0IGFsbCBwb29scyBhbmQgZnJlZSB0aGVpciByZXNvdXJjZXMuICovXG4gIGNsZWFyKCkge1xuICAgIHRoaXMuX3Bvb2xzQnlDbGFzcy5mb3JFYWNoKChwb29sKSA9PiBwb29sLmNsZWFyKCkpO1xuICAgIHRoaXMuX3Bvb2xzQnlDbGFzcy5jbGVhcigpO1xuICB9XG59XG5jb25zdCBCaWdQb29sID0gbmV3IFBvb2xHcm91cENsYXNzKCk7XG5HbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5LnJlZ2lzdGVyKEJpZ1Bvb2wpO1xuXG5leHBvcnQgeyBCaWdQb29sLCBQb29sR3JvdXBDbGFzcyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UG9vbEdyb3VwLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gbXVsdGlwbHlIZXhDb2xvcnMoY29sb3IxLCBjb2xvcjIpIHtcbiAgaWYgKGNvbG9yMSA9PT0gMTY3NzcyMTUgfHwgIWNvbG9yMikgcmV0dXJuIGNvbG9yMjtcbiAgaWYgKGNvbG9yMiA9PT0gMTY3NzcyMTUgfHwgIWNvbG9yMSkgcmV0dXJuIGNvbG9yMTtcbiAgY29uc3QgcjEgPSBjb2xvcjEgPj4gMTYgJiAyNTU7XG4gIGNvbnN0IGcxID0gY29sb3IxID4+IDggJiAyNTU7XG4gIGNvbnN0IGIxID0gY29sb3IxICYgMjU1O1xuICBjb25zdCByMiA9IGNvbG9yMiA+PiAxNiAmIDI1NTtcbiAgY29uc3QgZzIgPSBjb2xvcjIgPj4gOCAmIDI1NTtcbiAgY29uc3QgYjIgPSBjb2xvcjIgJiAyNTU7XG4gIGNvbnN0IHIgPSByMSAqIHIyIC8gMjU1IHwgMDtcbiAgY29uc3QgZyA9IGcxICogZzIgLyAyNTUgfCAwO1xuICBjb25zdCBiID0gYjEgKiBiMiAvIDI1NSB8IDA7XG4gIHJldHVybiAociA8PCAxNikgKyAoZyA8PCA4KSArIGI7XG59XG5cbmV4cG9ydCB7IG11bHRpcGx5SGV4Q29sb3JzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdWx0aXBseUhleENvbG9ycy5tanMubWFwXG4iLCJpbXBvcnQgeyB1aWQgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9kYXRhL3VpZC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIEluc3RydWN0aW9uU2V0IHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLyoqIGEgdW5pcXVlIGlkIGZvciB0aGlzIGluc3RydWN0aW9uIHNldCB1c2VkIHRocm91Z2ggdGhlIHJlbmRlcmVyICovXG4gICAgdGhpcy51aWQgPSB1aWQoXCJpbnN0cnVjdGlvblNldFwiKTtcbiAgICAvKiogdGhlIGFycmF5IG9mIGluc3RydWN0aW9ucyAqL1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zID0gW107XG4gICAgLyoqIHRoZSBhY3R1YWwgc2l6ZSBvZiB0aGUgYXJyYXkgKGFueSBpbnN0cnVjdGlvbnMgcGFzc2VkIHRoaXMgc2hvdWxkIGJlIGlnbm9yZWQpICovXG4gICAgdGhpcy5pbnN0cnVjdGlvblNpemUgPSAwO1xuICAgIHRoaXMucmVuZGVyYWJsZXMgPSBbXTtcbiAgICAvKiogdXNlZCBieSB0aGUgZ2FyYmFnZSBjb2xsZWN0b3IgdG8gdHJhY2sgd2hlbiB0aGUgaW5zdHJ1Y3Rpb24gc2V0IHdhcyBsYXN0IHVzZWQgKi9cbiAgICB0aGlzLmdjVGljayA9IDA7XG4gIH1cbiAgLyoqIHJlc2V0IHRoZSBpbnN0cnVjdGlvbiBzZXQgc28gaXQgY2FuIGJlIHJldXNlZCBzZXQgc2l6ZSBiYWNrIHRvIDAgKi9cbiAgcmVzZXQoKSB7XG4gICAgdGhpcy5pbnN0cnVjdGlvblNpemUgPSAwO1xuICB9XG4gIC8qKlxuICAgKiBEZXN0cm95IHRoZSBpbnN0cnVjdGlvbiBzZXQsIGNsZWFyaW5nIHRoZSBpbnN0cnVjdGlvbnMgYW5kIHJlbmRlcmFibGVzIGFuZCBub3RpZnlpbmdcbiAgICogZWFjaCByZW5kZXIgcGlwZSBzbyBpdCBjYW4gcmVsZWFzZSBhbnkgcGVyLUluc3RydWN0aW9uU2V0IGNhY2hlZCByZXNvdXJjZXMuXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICBpZiAodGhpcy5yZW5kZXJQaXBlcykge1xuICAgICAgZm9yIChjb25zdCBpIGluIHRoaXMucmVuZGVyUGlwZXMpIHtcbiAgICAgICAgdGhpcy5yZW5kZXJQaXBlc1tpXS5kZXN0cm95SW5zdHJ1Y3Rpb25TZXQ/Lih0aGlzKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5pbnN0cnVjdGlvbnMubGVuZ3RoID0gMDtcbiAgICB0aGlzLnJlbmRlcmFibGVzLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5yZW5kZXJQaXBlcyA9IG51bGw7XG4gICAgdGhpcy5nY1RpY2sgPSAwO1xuICB9XG4gIC8qKlxuICAgKiBBZGQgYW4gaW5zdHJ1Y3Rpb24gdG8gdGhlIHNldFxuICAgKiBAcGFyYW0gaW5zdHJ1Y3Rpb24gLSBhZGQgYW4gaW5zdHJ1Y3Rpb24gdG8gdGhlIHNldFxuICAgKi9cbiAgYWRkKGluc3RydWN0aW9uKSB7XG4gICAgdGhpcy5pbnN0cnVjdGlvbnNbdGhpcy5pbnN0cnVjdGlvblNpemUrK10gPSBpbnN0cnVjdGlvbjtcbiAgfVxuICAvKipcbiAgICogTG9nIHRoZSBpbnN0cnVjdGlvbnMgdG8gdGhlIGNvbnNvbGUgKGZvciBkZWJ1Z2dpbmcpXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgbG9nKCkge1xuICAgIHRoaXMuaW5zdHJ1Y3Rpb25zLmxlbmd0aCA9IHRoaXMuaW5zdHJ1Y3Rpb25TaXplO1xuICAgIGNvbnNvbGUudGFibGUodGhpcy5pbnN0cnVjdGlvbnMsIFtcInR5cGVcIiwgXCJhY3Rpb25cIl0pO1xuICB9XG59XG5cbmV4cG9ydCB7IEluc3RydWN0aW9uU2V0IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1JbnN0cnVjdGlvblNldC5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmNsYXNzIFNjcmVlblNpemVSZWdpc3RyeSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIC8qKiB0aGUgbGl2ZSBzY3JlZW4gc2l6ZXMgaW4gcGh5c2ljYWwgcGl4ZWxzLCBrZXllZCBieSByZW5kZXJlciB1aWQgKi9cbiAgICB0aGlzLl9zY3JlZW5TaXplcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgLyoqIHRoZSB1bmlxdWUgcmVnaXN0ZXJlZCBzY3JlZW4gd2lkdGhzIGluIHBoeXNpY2FsIHBpeGVscywgc29ydGVkIGFzY2VuZGluZyAqL1xuICAgIHRoaXMuX3dpZHRocyA9IFtdO1xuICAgIC8qKiB0aGUgdW5pcXVlIHJlZ2lzdGVyZWQgc2NyZWVuIGhlaWdodHMgaW4gcGh5c2ljYWwgcGl4ZWxzLCBzb3J0ZWQgYXNjZW5kaW5nICovXG4gICAgdGhpcy5faGVpZ2h0cyA9IFtdO1xuICB9XG4gIC8qKiBUaGUgbnVtYmVyIG9mIHJlbmRlcmVycyB3aXRoIGEgcmVnaXN0ZXJlZCBzY3JlZW4uICovXG4gIGdldCBzaXplKCkge1xuICAgIHJldHVybiB0aGlzLl9zY3JlZW5TaXplcy5zaXplO1xuICB9XG4gIC8qKlxuICAgKiBSZWdpc3RlcnMsIG9yIHVwZGF0ZXMsIHRoZSBzY3JlZW4gc2l6ZSBvZiBhIHJlbmRlcmVyLlxuICAgKiBAcGFyYW0gcmVuZGVyZXJVaWQgLSBUaGUgdWlkIG9mIHRoZSByZW5kZXJlciwgdXNlZCB0byB1cGRhdGUgb3IgcmVtb3ZlIHRoaXMgc2NyZWVuIGxhdGVyLlxuICAgKiBAcGFyYW0gcGl4ZWxXaWR0aCAtIFRoZSB3aWR0aCBvZiB0aGUgc2NyZWVuIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICogQHBhcmFtIHBpeGVsSGVpZ2h0IC0gVGhlIGhlaWdodCBvZiB0aGUgc2NyZWVuIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICogQHJldHVybnMgYHRydWVgIGlmIHRoaXMgY2hhbmdlZCB0aGUgcmVnaXN0ZXJlZCBzY3JlZW5zLCBgZmFsc2VgIGlmIHRoZSBzaXplIHdhcyBhbHJlYWR5IHJlZ2lzdGVyZWQuXG4gICAqL1xuICBzZXQocmVuZGVyZXJVaWQsIHBpeGVsV2lkdGgsIHBpeGVsSGVpZ2h0KSB7XG4gICAgY29uc3QgY3VycmVudCA9IHRoaXMuX3NjcmVlblNpemVzLmdldChyZW5kZXJlclVpZCk7XG4gICAgaWYgKGN1cnJlbnQgJiYgY3VycmVudC5waXhlbFdpZHRoID09PSBwaXhlbFdpZHRoICYmIGN1cnJlbnQucGl4ZWxIZWlnaHQgPT09IHBpeGVsSGVpZ2h0KSByZXR1cm4gZmFsc2U7XG4gICAgdGhpcy5fc2NyZWVuU2l6ZXMuc2V0KHJlbmRlcmVyVWlkLCB7IHBpeGVsV2lkdGgsIHBpeGVsSGVpZ2h0IH0pO1xuICAgIHRoaXMuX3VwZGF0ZSgpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIC8qKlxuICAgKiBSZW1vdmVzIHRoZSBzY3JlZW4gb2YgYSByZW5kZXJlci5cbiAgICogQHBhcmFtIHJlbmRlcmVyVWlkIC0gVGhlIHVpZCB0aGUgc2NyZWVuIHdhcyByZWdpc3RlcmVkIHdpdGguXG4gICAqIEByZXR1cm5zIGB0cnVlYCBpZiBhIHNjcmVlbiB3YXMgcmVtb3ZlZCwgYGZhbHNlYCBpZiB0aGUgcmVuZGVyZXIgaGFkIG5vbmUgcmVnaXN0ZXJlZC5cbiAgICovXG4gIHJlbW92ZShyZW5kZXJlclVpZCkge1xuICAgIGlmICghdGhpcy5fc2NyZWVuU2l6ZXMuZGVsZXRlKHJlbmRlcmVyVWlkKSkgcmV0dXJuIGZhbHNlO1xuICAgIHRoaXMuX3VwZGF0ZSgpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgc21hbGxlc3QgcmVnaXN0ZXJlZCBzY3JlZW4gd2lkdGggdGhlIHJlcXVlc3QgZml0cyBpbi5cbiAgICogQHBhcmFtIHBpeGVsV2lkdGggLSBUaGUgcmVxdWVzdGVkIHdpZHRoIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICogQHJldHVybnMgVGhlIHNtYWxsZXN0IGxpdmUgc2NyZWVuIHdpZHRoIHRoYXQgaXMgYXQgbGVhc3QgYHBpeGVsV2lkdGhgLCBvciBgdW5kZWZpbmVkYCBpZiBub25lLlxuICAgKi9cbiAgZ2V0Rml0dGluZ1dpZHRoKHBpeGVsV2lkdGgpIHtcbiAgICByZXR1cm4gdGhpcy5fZ2V0Rml0dGluZ0F4aXMocGl4ZWxXaWR0aCwgdGhpcy5fd2lkdGhzKTtcbiAgfVxuICAvKipcbiAgICogVGhlIHNtYWxsZXN0IHJlZ2lzdGVyZWQgc2NyZWVuIGhlaWdodCB0aGUgcmVxdWVzdCBmaXRzIGluLlxuICAgKiBAcGFyYW0gcGl4ZWxIZWlnaHQgLSBUaGUgcmVxdWVzdGVkIGhlaWdodCBpbiBwaHlzaWNhbCBwaXhlbHMuXG4gICAqIEByZXR1cm5zIFRoZSBzbWFsbGVzdCBsaXZlIHNjcmVlbiBoZWlnaHQgdGhhdCBpcyBhdCBsZWFzdCBgcGl4ZWxIZWlnaHRgLCBvciBgdW5kZWZpbmVkYCBpZiBub25lLlxuICAgKi9cbiAgZ2V0Rml0dGluZ0hlaWdodChwaXhlbEhlaWdodCkge1xuICAgIHJldHVybiB0aGlzLl9nZXRGaXR0aW5nQXhpcyhwaXhlbEhlaWdodCwgdGhpcy5faGVpZ2h0cyk7XG4gIH1cbiAgLyoqXG4gICAqIFdoZXRoZXIgYSBsaXZlIHNjcmVlbiB1c2VzIHRoaXMgd2lkdGguXG4gICAqIEBwYXJhbSB3aWR0aCAtIFRoZSB3aWR0aCBpbiBwaHlzaWNhbCBwaXhlbHMuXG4gICAqL1xuICBoYXNXaWR0aCh3aWR0aCkge1xuICAgIHJldHVybiB0aGlzLl93aWR0aHMuaW5jbHVkZXMod2lkdGgpO1xuICB9XG4gIC8qKlxuICAgKiBXaGV0aGVyIGEgbGl2ZSBzY3JlZW4gdXNlcyB0aGlzIGhlaWdodC5cbiAgICogQHBhcmFtIGhlaWdodCAtIFRoZSBoZWlnaHQgaW4gcGh5c2ljYWwgcGl4ZWxzLlxuICAgKi9cbiAgaGFzSGVpZ2h0KGhlaWdodCkge1xuICAgIHJldHVybiB0aGlzLl9oZWlnaHRzLmluY2x1ZGVzKGhlaWdodCk7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBzbWFsbGVzdCByZWdpc3RlcmVkIHNjcmVlbiBvbiB0aGlzIGF4aXMgdGhhdCB0aGUgcmVxdWVzdCBzdGlsbCBmaXRzIGluLlxuICAgKiBAcGFyYW0gcGl4ZWxTaXplIC0gVGhlIHJlcXVlc3RlZCBzaXplIG9uIHRoaXMgYXhpcyBpbiBwaHlzaWNhbCBwaXhlbHMuXG4gICAqIEBwYXJhbSBzY3JlZW5TaXplcyAtIFRoZSBsaXZlIHNjcmVlbiBzaXplcyBvbiB0aGlzIGF4aXMsIHNvcnRlZCBhc2NlbmRpbmcuXG4gICAqIEByZXR1cm5zIFRoZSBzbWFsbGVzdCBzY3JlZW4gc2l6ZSB0aGF0IGlzIGF0IGxlYXN0IGBwaXhlbFNpemVgLCBvciBgdW5kZWZpbmVkYCBpZiBub25lLlxuICAgKi9cbiAgX2dldEZpdHRpbmdBeGlzKHBpeGVsU2l6ZSwgc2NyZWVuU2l6ZXMpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNjcmVlblNpemVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBzY3JlZW5TaXplID0gc2NyZWVuU2l6ZXNbaV07XG4gICAgICBpZiAoc2NyZWVuU2l6ZSA+PSBwaXhlbFNpemUpIHJldHVybiBzY3JlZW5TaXplO1xuICAgIH1cbiAgICByZXR1cm4gdm9pZCAwO1xuICB9XG4gIC8qKiBSZWJ1aWxkcyB0aGUgc29ydGVkIHVuaXF1ZSBzaXplcyBmb3IgZWFjaCBheGlzLiAqL1xuICBfdXBkYXRlKCkge1xuICAgIHRoaXMuX3dpZHRocyA9IFsuLi50aGlzLl9zY3JlZW5TaXplcy52YWx1ZXMoKV0ubWFwKChzY3JlZW5TaXplKSA9PiBzY3JlZW5TaXplLnBpeGVsV2lkdGgpLmZpbHRlcigod2lkdGgsIGksIHdpZHRocykgPT4gd2lkdGhzLmluZGV4T2Yod2lkdGgpID09PSBpKS5zb3J0KChhLCBiKSA9PiBhIC0gYik7XG4gICAgdGhpcy5faGVpZ2h0cyA9IFsuLi50aGlzLl9zY3JlZW5TaXplcy52YWx1ZXMoKV0ubWFwKChzY3JlZW5TaXplKSA9PiBzY3JlZW5TaXplLnBpeGVsSGVpZ2h0KS5maWx0ZXIoKGhlaWdodCwgaSwgaGVpZ2h0cykgPT4gaGVpZ2h0cy5pbmRleE9mKGhlaWdodCkgPT09IGkpLnNvcnQoKGEsIGIpID0+IGEgLSBiKTtcbiAgfVxufVxuXG5leHBvcnQgeyBTY3JlZW5TaXplUmVnaXN0cnkgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVNjcmVlblNpemVSZWdpc3RyeS5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IEJyb3dzZXJBZGFwdGVyID0ge1xuICBjcmVhdGVDYW52YXM6ICh3aWR0aCwgaGVpZ2h0KSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcbiAgICBjYW52YXMud2lkdGggPSB3aWR0aDtcbiAgICBjYW52YXMuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgIHJldHVybiBjYW52YXM7XG4gIH0sXG4gIGNyZWF0ZUltYWdlOiAoKSA9PiBuZXcgSW1hZ2UoKSxcbiAgZ2V0Q2FudmFzUmVuZGVyaW5nQ29udGV4dDJEOiAoKSA9PiBDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQsXG4gIGdldFdlYkdMUmVuZGVyaW5nQ29udGV4dDogKCkgPT4gV2ViR0xSZW5kZXJpbmdDb250ZXh0LFxuICBnZXROYXZpZ2F0b3I6ICgpID0+IG5hdmlnYXRvcixcbiAgZ2V0QmFzZVVybDogKCkgPT4gZG9jdW1lbnQuYmFzZVVSSSA/PyB3aW5kb3cubG9jYXRpb24uaHJlZixcbiAgZ2V0Rm9udEZhY2VTZXQ6ICgpID0+IGRvY3VtZW50LmZvbnRzLFxuICBmZXRjaDogKHVybCwgb3B0aW9ucykgPT4gZmV0Y2godXJsLCBvcHRpb25zKSxcbiAgcGFyc2VYTUw6ICh4bWwpID0+IHtcbiAgICBjb25zdCBwYXJzZXIgPSBuZXcgRE9NUGFyc2VyKCk7XG4gICAgcmV0dXJuIHBhcnNlci5wYXJzZUZyb21TdHJpbmcoeG1sLCBcInRleHQveG1sXCIpO1xuICB9XG59O1xuXG5leHBvcnQgeyBCcm93c2VyQWRhcHRlciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QnJvd3NlckFkYXB0ZXIubWpzLm1hcFxuIiwiaW1wb3J0IHsgQnJvd3NlckFkYXB0ZXIgfSBmcm9tICcuLi9lbnZpcm9ubWVudC1icm93c2VyL0Jyb3dzZXJBZGFwdGVyLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xubGV0IGN1cnJlbnRBZGFwdGVyID0gQnJvd3NlckFkYXB0ZXI7XG5jb25zdCBET01BZGFwdGVyID0ge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgY3VycmVudCBhZGFwdGVyLlxuICAgKiBAcmV0dXJucyB7ZW52aXJvbm1lbnQuQWRhcHRlcn0gVGhlIGN1cnJlbnQgYWRhcHRlci5cbiAgICovXG4gIGdldCgpIHtcbiAgICByZXR1cm4gY3VycmVudEFkYXB0ZXI7XG4gIH0sXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBjdXJyZW50IGFkYXB0ZXIuXG4gICAqIEBwYXJhbSBhZGFwdGVyIC0gVGhlIG5ldyBhZGFwdGVyLlxuICAgKi9cbiAgc2V0KGFkYXB0ZXIpIHtcbiAgICBjdXJyZW50QWRhcHRlciA9IGFkYXB0ZXI7XG4gIH1cbn07XG5cbmV4cG9ydCB7IERPTUFkYXB0ZXIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFkYXB0ZXIubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBpZENvdW50cyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuY29uc3QgaWRIYXNoID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG5mdW5jdGlvbiBjcmVhdGVJZEZyb21TdHJpbmcodmFsdWUsIGdyb3VwSWQpIHtcbiAgbGV0IGlkID0gaWRIYXNoW3ZhbHVlXTtcbiAgaWYgKGlkID09PSB2b2lkIDApIHtcbiAgICBpZiAoaWRDb3VudHNbZ3JvdXBJZF0gPT09IHZvaWQgMCkge1xuICAgICAgaWRDb3VudHNbZ3JvdXBJZF0gPSAxO1xuICAgIH1cbiAgICBpZEhhc2hbdmFsdWVdID0gaWQgPSBpZENvdW50c1tncm91cElkXSsrO1xuICB9XG4gIHJldHVybiBpZDtcbn1cblxuZXhwb3J0IHsgY3JlYXRlSWRGcm9tU3RyaW5nIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jcmVhdGVJZEZyb21TdHJpbmcubWpzLm1hcFxuIiwiaW1wb3J0IHsgRE9NQWRhcHRlciB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2Vudmlyb25tZW50L2FkYXB0ZXIubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5sZXQgY29udGV4dDtcbmZ1bmN0aW9uIGdldFRlc3RDb250ZXh0KCkge1xuICBpZiAoIWNvbnRleHQgfHwgY29udGV4dD8uaXNDb250ZXh0TG9zdCgpKSB7XG4gICAgY29uc3QgY2FudmFzID0gRE9NQWRhcHRlci5nZXQoKS5jcmVhdGVDYW52YXMoKTtcbiAgICBjb250ZXh0ID0gY2FudmFzLmdldENvbnRleHQoXCJ3ZWJnbFwiLCB7fSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRleHQ7XG59XG5cbmV4cG9ydCB7IGdldFRlc3RDb250ZXh0IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1nZXRUZXN0Q29udGV4dC5tanMubWFwXG4iLCJpbXBvcnQgeyBnZXRUZXN0Q29udGV4dCB9IGZyb20gJy4vZ2V0VGVzdENvbnRleHQubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5sZXQgbWF4RnJhZ21lbnRQcmVjaXNpb247XG5mdW5jdGlvbiBnZXRNYXhGcmFnbWVudFByZWNpc2lvbigpIHtcbiAgaWYgKCFtYXhGcmFnbWVudFByZWNpc2lvbikge1xuICAgIG1heEZyYWdtZW50UHJlY2lzaW9uID0gXCJtZWRpdW1wXCI7XG4gICAgY29uc3QgZ2wgPSBnZXRUZXN0Q29udGV4dCgpO1xuICAgIGlmIChnbCkge1xuICAgICAgaWYgKGdsLmdldFNoYWRlclByZWNpc2lvbkZvcm1hdCkge1xuICAgICAgICBjb25zdCBzaGFkZXJGcmFnbWVudCA9IGdsLmdldFNoYWRlclByZWNpc2lvbkZvcm1hdChnbC5GUkFHTUVOVF9TSEFERVIsIGdsLkhJR0hfRkxPQVQpO1xuICAgICAgICBtYXhGcmFnbWVudFByZWNpc2lvbiA9IHNoYWRlckZyYWdtZW50LnByZWNpc2lvbiA/IFwiaGlnaHBcIiA6IFwibWVkaXVtcFwiO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gbWF4RnJhZ21lbnRQcmVjaXNpb247XG59XG5cbmV4cG9ydCB7IGdldE1heEZyYWdtZW50UHJlY2lzaW9uIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1nZXRNYXhGcmFnbWVudFByZWNpc2lvbi5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGFkZFByb2dyYW1EZWZpbmVzKHNyYywgaXNFUzMwMCwgaXNGcmFnbWVudCkge1xuICBpZiAoaXNFUzMwMCkgcmV0dXJuIHNyYztcbiAgaWYgKGlzRnJhZ21lbnQpIHtcbiAgICBzcmMgPSBzcmMucmVwbGFjZShcIm91dCB2ZWM0IGZpbmFsQ29sb3I7XCIsIFwiXCIpO1xuICAgIHJldHVybiBgXG5cbiAgICAgICAgI2lmZGVmIEdMX0VTIC8vIFRoaXMgY2hlY2tzIGlmIGl0IGlzIFdlYkdMMVxuICAgICAgICAjZGVmaW5lIGluIHZhcnlpbmdcbiAgICAgICAgI2RlZmluZSBmaW5hbENvbG9yIGdsX0ZyYWdDb2xvclxuICAgICAgICAjZGVmaW5lIHRleHR1cmUgdGV4dHVyZTJEXG4gICAgICAgICNlbmRpZlxuICAgICAgICAke3NyY31cbiAgICAgICAgYDtcbiAgfVxuICByZXR1cm4gYFxuXG4gICAgICAgICNpZmRlZiBHTF9FUyAvLyBUaGlzIGNoZWNrcyBpZiBpdCBpcyBXZWJHTDFcbiAgICAgICAgI2RlZmluZSBpbiBhdHRyaWJ1dGVcbiAgICAgICAgI2RlZmluZSBvdXQgdmFyeWluZ1xuICAgICAgICAjZW5kaWZcbiAgICAgICAgJHtzcmN9XG4gICAgICAgIGA7XG59XG5cbmV4cG9ydCB7IGFkZFByb2dyYW1EZWZpbmVzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1hZGRQcm9ncmFtRGVmaW5lcy5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IHVucXVhbGlmaWVkU2FtcGxlclBhdHRlcm4gPSAvXFxidW5pZm9ybVxccysoW2l1XT9zYW1wbGVyXFx3KykvZztcbmNvbnN0IGRlY2xhcmVkU2FtcGxlclBhdHRlcm4gPSAvXFxicHJlY2lzaW9uXFxzK1xcdytcXHMrKFtpdV0/c2FtcGxlclxcdyspXFxzKjsvZztcbmNvbnN0IGRlZmF1bHRTYW1wbGVyUHJlY2lzaW9ucyA9IHtcbiAgc2FtcGxlcjJEOiBcImxvd3BcIixcbiAgc2FtcGxlckN1YmU6IFwibG93cFwiXG59O1xuZnVuY3Rpb24gZW5zdXJlUHJlY2lzaW9uKHNyYywgb3B0aW9ucywgaXNGcmFnbWVudCkge1xuICBjb25zdCBtYXhTdXBwb3J0ZWRQcmVjaXNpb24gPSBpc0ZyYWdtZW50ID8gb3B0aW9ucy5tYXhTdXBwb3J0ZWRGcmFnbWVudFByZWNpc2lvbiA6IG9wdGlvbnMubWF4U3VwcG9ydGVkVmVydGV4UHJlY2lzaW9uO1xuICBpZiAoc3JjLnN1YnN0cmluZygwLCA5KSAhPT0gXCJwcmVjaXNpb25cIikge1xuICAgIGxldCBwcmVjaXNpb24gPSBpc0ZyYWdtZW50ID8gb3B0aW9ucy5yZXF1ZXN0ZWRGcmFnbWVudFByZWNpc2lvbiA6IG9wdGlvbnMucmVxdWVzdGVkVmVydGV4UHJlY2lzaW9uO1xuICAgIGlmIChwcmVjaXNpb24gPT09IFwiaGlnaHBcIiAmJiBtYXhTdXBwb3J0ZWRQcmVjaXNpb24gIT09IFwiaGlnaHBcIikge1xuICAgICAgcHJlY2lzaW9uID0gXCJtZWRpdW1wXCI7XG4gICAgfVxuICAgIHNyYyA9IGBwcmVjaXNpb24gJHtwcmVjaXNpb259IGZsb2F0O1xuJHtzcmN9YDtcbiAgfSBlbHNlIGlmIChtYXhTdXBwb3J0ZWRQcmVjaXNpb24gIT09IFwiaGlnaHBcIiAmJiBzcmMuc3Vic3RyaW5nKDAsIDE1KSA9PT0gXCJwcmVjaXNpb24gaGlnaHBcIikge1xuICAgIHNyYyA9IHNyYy5yZXBsYWNlKFwicHJlY2lzaW9uIGhpZ2hwXCIsIFwicHJlY2lzaW9uIG1lZGl1bXBcIik7XG4gIH1cbiAgY29uc3Qgc2FtcGxlclByZWNpc2lvbiA9IG9wdGlvbnMubWF4U3VwcG9ydGVkRnJhZ21lbnRQcmVjaXNpb24gPT09IFwiaGlnaHBcIiA/IFwiaGlnaHBcIiA6IFwibWVkaXVtcFwiO1xuICByZXR1cm4gZW5zdXJlU2FtcGxlclByZWNpc2lvbihzcmMsIHNhbXBsZXJQcmVjaXNpb24pO1xufVxuZnVuY3Rpb24gZW5zdXJlU2FtcGxlclByZWNpc2lvbihzcmMsIGRhdGFQcmVjaXNpb24pIHtcbiAgY29uc3QgZG9uZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gIGxldCBoZWFkZXIgPSBcIlwiO1xuICBmb3IgKGNvbnN0IFssIHR5cGVdIG9mIHNyYy5tYXRjaEFsbChkZWNsYXJlZFNhbXBsZXJQYXR0ZXJuKSkgZG9uZS5hZGQodHlwZSk7XG4gIGZvciAoY29uc3QgWywgdHlwZV0gb2Ygc3JjLm1hdGNoQWxsKHVucXVhbGlmaWVkU2FtcGxlclBhdHRlcm4pKSB7XG4gICAgaWYgKGRvbmUuaGFzKHR5cGUpKSBjb250aW51ZTtcbiAgICBkb25lLmFkZCh0eXBlKTtcbiAgICBoZWFkZXIgKz0gYHByZWNpc2lvbiAke2RlZmF1bHRTYW1wbGVyUHJlY2lzaW9uc1t0eXBlXSA/PyBkYXRhUHJlY2lzaW9ufSAke3R5cGV9O1xuYDtcbiAgfVxuICByZXR1cm4gaGVhZGVyICsgc3JjO1xufVxuXG5leHBvcnQgeyBlbnN1cmVQcmVjaXNpb24gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVuc3VyZVByZWNpc2lvbi5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGluc2VydFZlcnNpb24oc3JjLCBpc0VTMzAwKSB7XG4gIGlmICghaXNFUzMwMCkgcmV0dXJuIHNyYztcbiAgcmV0dXJuIGAjdmVyc2lvbiAzMDAgZXNcbiR7c3JjfWA7XG59XG5cbmV4cG9ydCB7IGluc2VydFZlcnNpb24gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluc2VydFZlcnNpb24ubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBmcmFnbWVudE5hbWVDYWNoZSA9IHt9O1xuY29uc3QgVmVydGV4TmFtZUNhY2hlID0ge307XG5mdW5jdGlvbiBzZXRQcm9ncmFtTmFtZShzcmMsIHsgbmFtZSA9IGBwaXhpLXByb2dyYW1gIH0sIGlzRnJhZ21lbnQgPSB0cnVlKSB7XG4gIG5hbWUgPSBuYW1lLnJlcGxhY2UoL1xccysvZywgXCItXCIpO1xuICBuYW1lICs9IGlzRnJhZ21lbnQgPyBcIi1mcmFnbWVudFwiIDogXCItdmVydGV4XCI7XG4gIGNvbnN0IG5hbWVDYWNoZSA9IGlzRnJhZ21lbnQgPyBmcmFnbWVudE5hbWVDYWNoZSA6IFZlcnRleE5hbWVDYWNoZTtcbiAgaWYgKG5hbWVDYWNoZVtuYW1lXSkge1xuICAgIG5hbWVDYWNoZVtuYW1lXSsrO1xuICAgIG5hbWUgKz0gYC0ke25hbWVDYWNoZVtuYW1lXX1gO1xuICB9IGVsc2Uge1xuICAgIG5hbWVDYWNoZVtuYW1lXSA9IDE7XG4gIH1cbiAgaWYgKHNyYy5pbmRleE9mKFwiI2RlZmluZSBTSEFERVJfTkFNRVwiKSAhPT0gLTEpIHJldHVybiBzcmM7XG4gIGNvbnN0IHNoYWRlck5hbWUgPSBgI2RlZmluZSBTSEFERVJfTkFNRSAke25hbWV9YDtcbiAgcmV0dXJuIGAke3NoYWRlck5hbWV9XG4ke3NyY31gO1xufVxuXG5leHBvcnQgeyBzZXRQcm9ncmFtTmFtZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2V0UHJvZ3JhbU5hbWUubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBzdHJpcFZlcnNpb24oc3JjLCBpc0VTMzAwKSB7XG4gIGlmICghaXNFUzMwMCkgcmV0dXJuIHNyYztcbiAgcmV0dXJuIHNyYy5yZXBsYWNlKFwiI3ZlcnNpb24gMzAwIGVzXCIsIFwiXCIpO1xufVxuXG5leHBvcnQgeyBzdHJpcFZlcnNpb24gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN0cmlwVmVyc2lvbi5tanMubWFwXG4iLCJpbXBvcnQgeyBjcmVhdGVJZEZyb21TdHJpbmcgfSBmcm9tICcuLi8uLi9zaGFyZWQvdXRpbHMvY3JlYXRlSWRGcm9tU3RyaW5nLm1qcyc7XG5pbXBvcnQgeyBnZXRNYXhGcmFnbWVudFByZWNpc2lvbiB9IGZyb20gJy4vcHJvZ3JhbS9nZXRNYXhGcmFnbWVudFByZWNpc2lvbi5tanMnO1xuaW1wb3J0IHsgYWRkUHJvZ3JhbURlZmluZXMgfSBmcm9tICcuL3Byb2dyYW0vcHJlcHJvY2Vzc29ycy9hZGRQcm9ncmFtRGVmaW5lcy5tanMnO1xuaW1wb3J0IHsgZW5zdXJlUHJlY2lzaW9uIH0gZnJvbSAnLi9wcm9ncmFtL3ByZXByb2Nlc3NvcnMvZW5zdXJlUHJlY2lzaW9uLm1qcyc7XG5pbXBvcnQgeyBpbnNlcnRWZXJzaW9uIH0gZnJvbSAnLi9wcm9ncmFtL3ByZXByb2Nlc3NvcnMvaW5zZXJ0VmVyc2lvbi5tanMnO1xuaW1wb3J0IHsgc2V0UHJvZ3JhbU5hbWUgfSBmcm9tICcuL3Byb2dyYW0vcHJlcHJvY2Vzc29ycy9zZXRQcm9ncmFtTmFtZS5tanMnO1xuaW1wb3J0IHsgc3RyaXBWZXJzaW9uIH0gZnJvbSAnLi9wcm9ncmFtL3ByZXByb2Nlc3NvcnMvc3RyaXBWZXJzaW9uLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgcHJvY2Vzc2VzID0ge1xuICAvLyBzdHJpcHMgYW55IHZlcnNpb24gaGVhZGVycy4uXG4gIHN0cmlwVmVyc2lvbixcbiAgLy8gYWRkcyBwcmVjaXNpb24gc3RyaW5nIGlmIG5vdCBhbHJlYWR5IHByZXNlbnRcbiAgZW5zdXJlUHJlY2lzaW9uLFxuICAvLyBhZGQgc29tZSBkZWZpbmVzIGlmIFdlYkdMMSB0byBtYWtlIGl0IG1vcmUgY29tcGF0aWJsZSB3aXRoIFdlYkdMMiBzaGFkZXJzXG4gIGFkZFByb2dyYW1EZWZpbmVzLFxuICAvLyBhZGQgdGhlIHByb2dyYW0gbmFtZSB0byB0aGUgc2hhZGVyXG4gIHNldFByb2dyYW1OYW1lLFxuICAvLyBhZGQgdGhlIHZlcnNpb24gc3RyaW5nIHRvIHRoZSBzaGFkZXIgaGVhZGVyXG4gIGluc2VydFZlcnNpb25cbn07XG5jb25zdCBwcm9ncmFtQ2FjaGUgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbmNvbnN0IF9HbFByb2dyYW0gPSBjbGFzcyBfR2xQcm9ncmFtIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBzaGlueSBuZXcgR2xQcm9ncmFtLiBVc2VkIGJ5IFdlYkdMIHJlbmRlcmVyLlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvcHRpb25zIGZvciB0aGUgcHJvZ3JhbS5cbiAgICovXG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0geyAuLi5fR2xQcm9ncmFtLmRlZmF1bHRPcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgY29uc3QgaXNFUzMwMCA9IG9wdGlvbnMuZnJhZ21lbnQuaW5kZXhPZihcIiN2ZXJzaW9uIDMwMCBlc1wiKSAhPT0gLTE7XG4gICAgY29uc3QgcHJlcHJvY2Vzc29yT3B0aW9ucyA9IHtcbiAgICAgIHN0cmlwVmVyc2lvbjogaXNFUzMwMCxcbiAgICAgIGVuc3VyZVByZWNpc2lvbjoge1xuICAgICAgICByZXF1ZXN0ZWRGcmFnbWVudFByZWNpc2lvbjogb3B0aW9ucy5wcmVmZXJyZWRGcmFnbWVudFByZWNpc2lvbixcbiAgICAgICAgcmVxdWVzdGVkVmVydGV4UHJlY2lzaW9uOiBvcHRpb25zLnByZWZlcnJlZFZlcnRleFByZWNpc2lvbixcbiAgICAgICAgbWF4U3VwcG9ydGVkVmVydGV4UHJlY2lzaW9uOiBcImhpZ2hwXCIsXG4gICAgICAgIG1heFN1cHBvcnRlZEZyYWdtZW50UHJlY2lzaW9uOiBnZXRNYXhGcmFnbWVudFByZWNpc2lvbigpXG4gICAgICB9LFxuICAgICAgc2V0UHJvZ3JhbU5hbWU6IHtcbiAgICAgICAgbmFtZTogb3B0aW9ucy5uYW1lXG4gICAgICB9LFxuICAgICAgYWRkUHJvZ3JhbURlZmluZXM6IGlzRVMzMDAsXG4gICAgICBpbnNlcnRWZXJzaW9uOiBpc0VTMzAwXG4gICAgfTtcbiAgICBsZXQgZnJhZ21lbnQgPSBvcHRpb25zLmZyYWdtZW50O1xuICAgIGxldCB2ZXJ0ZXggPSBvcHRpb25zLnZlcnRleDtcbiAgICBPYmplY3Qua2V5cyhwcm9jZXNzZXMpLmZvckVhY2goKHByb2Nlc3NLZXkpID0+IHtcbiAgICAgIGNvbnN0IHByb2Nlc3NPcHRpb25zID0gcHJlcHJvY2Vzc29yT3B0aW9uc1twcm9jZXNzS2V5XTtcbiAgICAgIGZyYWdtZW50ID0gcHJvY2Vzc2VzW3Byb2Nlc3NLZXldKGZyYWdtZW50LCBwcm9jZXNzT3B0aW9ucywgdHJ1ZSk7XG4gICAgICB2ZXJ0ZXggPSBwcm9jZXNzZXNbcHJvY2Vzc0tleV0odmVydGV4LCBwcm9jZXNzT3B0aW9ucywgZmFsc2UpO1xuICAgIH0pO1xuICAgIHRoaXMuZnJhZ21lbnQgPSBmcmFnbWVudDtcbiAgICB0aGlzLnZlcnRleCA9IHZlcnRleDtcbiAgICB0aGlzLnRyYW5zZm9ybUZlZWRiYWNrVmFyeWluZ3MgPSBvcHRpb25zLnRyYW5zZm9ybUZlZWRiYWNrVmFyeWluZ3M7XG4gICAgdGhpcy5fa2V5ID0gY3JlYXRlSWRGcm9tU3RyaW5nKGAke3RoaXMudmVydGV4fToke3RoaXMuZnJhZ21lbnR9YCwgXCJnbC1wcm9ncmFtXCIpO1xuICB9XG4gIC8qKiBkZXN0cm95cyB0aGUgcHJvZ3JhbSAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMuZnJhZ21lbnQgPSBudWxsO1xuICAgIHRoaXMudmVydGV4ID0gbnVsbDtcbiAgICB0aGlzLl9hdHRyaWJ1dGVEYXRhID0gbnVsbDtcbiAgICB0aGlzLl91bmlmb3JtRGF0YSA9IG51bGw7XG4gICAgdGhpcy5fdW5pZm9ybUJsb2NrRGF0YSA9IG51bGw7XG4gICAgdGhpcy50cmFuc2Zvcm1GZWVkYmFja1ZhcnlpbmdzID0gbnVsbDtcbiAgICBwcm9ncmFtQ2FjaGVbdGhpcy5fY2FjaGVLZXldID0gbnVsbDtcbiAgfVxuICAvKipcbiAgICogSGVscGVyIGZ1bmN0aW9uIHRoYXQgY3JlYXRlcyBhIHByb2dyYW0gZm9yIGEgZ2l2ZW4gc291cmNlLlxuICAgKiBJdCB3aWxsIGNoZWNrIHRoZSBwcm9ncmFtIGNhY2hlIGlmIHRoZSBwcm9ncmFtIGhhcyBhbHJlYWR5IGJlZW4gY3JlYXRlZC5cbiAgICogSWYgaXQgaGFzIHRoYXQgb25lIHdpbGwgYmUgcmV0dXJuZWQsIGlmIG5vdCBhIG5ldyBvbmUgd2lsbCBiZSBjcmVhdGVkIGFuZCBjYWNoZWQuXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgZm9yIHRoZSBwcm9ncmFtLlxuICAgKiBAcmV0dXJucyBBIHByb2dyYW0gdXNpbmcgdGhlIHNhbWUgc291cmNlXG4gICAqL1xuICBzdGF0aWMgZnJvbShvcHRpb25zKSB7XG4gICAgY29uc3Qga2V5ID0gYCR7b3B0aW9ucy52ZXJ0ZXh9OiR7b3B0aW9ucy5mcmFnbWVudH1gO1xuICAgIGlmICghcHJvZ3JhbUNhY2hlW2tleV0pIHtcbiAgICAgIHByb2dyYW1DYWNoZVtrZXldID0gbmV3IF9HbFByb2dyYW0ob3B0aW9ucyk7XG4gICAgICBwcm9ncmFtQ2FjaGVba2V5XS5fY2FjaGVLZXkgPSBrZXk7XG4gICAgfVxuICAgIHJldHVybiBwcm9ncmFtQ2FjaGVba2V5XTtcbiAgfVxufTtcbi8qKiBUaGUgZGVmYXVsdCBvcHRpb25zIHVzZWQgYnkgdGhlIHByb2dyYW0uICovXG5fR2xQcm9ncmFtLmRlZmF1bHRPcHRpb25zID0ge1xuICBwcmVmZXJyZWRWZXJ0ZXhQcmVjaXNpb246IFwiaGlnaHBcIixcbiAgcHJlZmVycmVkRnJhZ21lbnRQcmVjaXNpb246IFwibWVkaXVtcFwiXG59O1xubGV0IEdsUHJvZ3JhbSA9IF9HbFByb2dyYW07XG5cbmV4cG9ydCB7IEdsUHJvZ3JhbSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9R2xQcm9ncmFtLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY29uc3QgYXR0cmlidXRlRm9ybWF0RGF0YSA9IHtcbiAgdWludDh4MjogeyBzaXplOiAyLCBzdHJpZGU6IDIsIG5vcm1hbGlzZWQ6IGZhbHNlIH0sXG4gIHVpbnQ4eDQ6IHsgc2l6ZTogNCwgc3RyaWRlOiA0LCBub3JtYWxpc2VkOiBmYWxzZSB9LFxuICBzaW50OHgyOiB7IHNpemU6IDIsIHN0cmlkZTogMiwgbm9ybWFsaXNlZDogZmFsc2UgfSxcbiAgc2ludDh4NDogeyBzaXplOiA0LCBzdHJpZGU6IDQsIG5vcm1hbGlzZWQ6IGZhbHNlIH0sXG4gIHVub3JtOHgyOiB7IHNpemU6IDIsIHN0cmlkZTogMiwgbm9ybWFsaXNlZDogdHJ1ZSB9LFxuICB1bm9ybTh4NDogeyBzaXplOiA0LCBzdHJpZGU6IDQsIG5vcm1hbGlzZWQ6IHRydWUgfSxcbiAgc25vcm04eDI6IHsgc2l6ZTogMiwgc3RyaWRlOiAyLCBub3JtYWxpc2VkOiB0cnVlIH0sXG4gIHNub3JtOHg0OiB7IHNpemU6IDQsIHN0cmlkZTogNCwgbm9ybWFsaXNlZDogdHJ1ZSB9LFxuICB1aW50MTZ4MjogeyBzaXplOiAyLCBzdHJpZGU6IDQsIG5vcm1hbGlzZWQ6IGZhbHNlIH0sXG4gIHVpbnQxNng0OiB7IHNpemU6IDQsIHN0cmlkZTogOCwgbm9ybWFsaXNlZDogZmFsc2UgfSxcbiAgc2ludDE2eDI6IHsgc2l6ZTogMiwgc3RyaWRlOiA0LCBub3JtYWxpc2VkOiBmYWxzZSB9LFxuICBzaW50MTZ4NDogeyBzaXplOiA0LCBzdHJpZGU6IDgsIG5vcm1hbGlzZWQ6IGZhbHNlIH0sXG4gIHVub3JtMTZ4MjogeyBzaXplOiAyLCBzdHJpZGU6IDQsIG5vcm1hbGlzZWQ6IHRydWUgfSxcbiAgdW5vcm0xNng0OiB7IHNpemU6IDQsIHN0cmlkZTogOCwgbm9ybWFsaXNlZDogdHJ1ZSB9LFxuICBzbm9ybTE2eDI6IHsgc2l6ZTogMiwgc3RyaWRlOiA0LCBub3JtYWxpc2VkOiB0cnVlIH0sXG4gIHNub3JtMTZ4NDogeyBzaXplOiA0LCBzdHJpZGU6IDgsIG5vcm1hbGlzZWQ6IHRydWUgfSxcbiAgZmxvYXQxNngyOiB7IHNpemU6IDIsIHN0cmlkZTogNCwgbm9ybWFsaXNlZDogZmFsc2UgfSxcbiAgZmxvYXQxNng0OiB7IHNpemU6IDQsIHN0cmlkZTogOCwgbm9ybWFsaXNlZDogZmFsc2UgfSxcbiAgZmxvYXQzMjogeyBzaXplOiAxLCBzdHJpZGU6IDQsIG5vcm1hbGlzZWQ6IGZhbHNlIH0sXG4gIGZsb2F0MzJ4MjogeyBzaXplOiAyLCBzdHJpZGU6IDgsIG5vcm1hbGlzZWQ6IGZhbHNlIH0sXG4gIGZsb2F0MzJ4MzogeyBzaXplOiAzLCBzdHJpZGU6IDEyLCBub3JtYWxpc2VkOiBmYWxzZSB9LFxuICBmbG9hdDMyeDQ6IHsgc2l6ZTogNCwgc3RyaWRlOiAxNiwgbm9ybWFsaXNlZDogZmFsc2UgfSxcbiAgdWludDMyOiB7IHNpemU6IDEsIHN0cmlkZTogNCwgbm9ybWFsaXNlZDogZmFsc2UgfSxcbiAgdWludDMyeDI6IHsgc2l6ZTogMiwgc3RyaWRlOiA4LCBub3JtYWxpc2VkOiBmYWxzZSB9LFxuICB1aW50MzJ4MzogeyBzaXplOiAzLCBzdHJpZGU6IDEyLCBub3JtYWxpc2VkOiBmYWxzZSB9LFxuICB1aW50MzJ4NDogeyBzaXplOiA0LCBzdHJpZGU6IDE2LCBub3JtYWxpc2VkOiBmYWxzZSB9LFxuICBzaW50MzI6IHsgc2l6ZTogMSwgc3RyaWRlOiA0LCBub3JtYWxpc2VkOiBmYWxzZSB9LFxuICBzaW50MzJ4MjogeyBzaXplOiAyLCBzdHJpZGU6IDgsIG5vcm1hbGlzZWQ6IGZhbHNlIH0sXG4gIHNpbnQzMngzOiB7IHNpemU6IDMsIHN0cmlkZTogMTIsIG5vcm1hbGlzZWQ6IGZhbHNlIH0sXG4gIHNpbnQzMng0OiB7IHNpemU6IDQsIHN0cmlkZTogMTYsIG5vcm1hbGlzZWQ6IGZhbHNlIH1cbn07XG5mdW5jdGlvbiBnZXRBdHRyaWJ1dGVJbmZvRnJvbUZvcm1hdChmb3JtYXQpIHtcbiAgcmV0dXJuIGF0dHJpYnV0ZUZvcm1hdERhdGFbZm9ybWF0XSA/PyBhdHRyaWJ1dGVGb3JtYXREYXRhLmZsb2F0MzI7XG59XG5cbmV4cG9ydCB7IGdldEF0dHJpYnV0ZUluZm9Gcm9tRm9ybWF0IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1nZXRBdHRyaWJ1dGVJbmZvRnJvbUZvcm1hdC5tanMubWFwXG4iLCJpbXBvcnQgeyBnZXRBdHRyaWJ1dGVJbmZvRnJvbUZvcm1hdCB9IGZyb20gJy4uLy4uLy4uL3NoYXJlZC9nZW9tZXRyeS91dGlscy9nZXRBdHRyaWJ1dGVJbmZvRnJvbUZvcm1hdC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IFdHU0xfVE9fVkVSVEVYX1RZUEVTID0ge1xuICBmMzI6IFwiZmxvYXQzMlwiLFxuICBcInZlYzI8ZjMyPlwiOiBcImZsb2F0MzJ4MlwiLFxuICBcInZlYzM8ZjMyPlwiOiBcImZsb2F0MzJ4M1wiLFxuICBcInZlYzQ8ZjMyPlwiOiBcImZsb2F0MzJ4NFwiLFxuICB2ZWMyZjogXCJmbG9hdDMyeDJcIixcbiAgdmVjM2Y6IFwiZmxvYXQzMngzXCIsXG4gIHZlYzRmOiBcImZsb2F0MzJ4NFwiLFxuICBpMzI6IFwic2ludDMyXCIsXG4gIFwidmVjMjxpMzI+XCI6IFwic2ludDMyeDJcIixcbiAgXCJ2ZWMzPGkzMj5cIjogXCJzaW50MzJ4M1wiLFxuICBcInZlYzQ8aTMyPlwiOiBcInNpbnQzMng0XCIsXG4gIHZlYzJpOiBcInNpbnQzMngyXCIsXG4gIHZlYzNpOiBcInNpbnQzMngzXCIsXG4gIHZlYzRpOiBcInNpbnQzMng0XCIsXG4gIHUzMjogXCJ1aW50MzJcIixcbiAgXCJ2ZWMyPHUzMj5cIjogXCJ1aW50MzJ4MlwiLFxuICBcInZlYzM8dTMyPlwiOiBcInVpbnQzMngzXCIsXG4gIFwidmVjNDx1MzI+XCI6IFwidWludDMyeDRcIixcbiAgdmVjMnU6IFwidWludDMyeDJcIixcbiAgdmVjM3U6IFwidWludDMyeDNcIixcbiAgdmVjNHU6IFwidWludDMyeDRcIixcbiAgYm9vbDogXCJ1aW50MzJcIixcbiAgXCJ2ZWMyPGJvb2w+XCI6IFwidWludDMyeDJcIixcbiAgXCJ2ZWMzPGJvb2w+XCI6IFwidWludDMyeDNcIixcbiAgXCJ2ZWM0PGJvb2w+XCI6IFwidWludDMyeDRcIlxufTtcbmNvbnN0IExPQ0FUSU9OX1JFR0VYID0gL0Bsb2NhdGlvblxcKChcXGQrKVxcKVxccysoW2EtekEtWjAtOV9dKylcXHMqOlxccyooW2EtekEtWjAtOV88Pl0rKSg/Oix8XFxzfFxcKXwkKS9nO1xuZnVuY3Rpb24gcGFyc2VMb2NhdGlvbnMoc3RyLCByZXN1bHRzKSB7XG4gIGxldCBtYXRjaDtcbiAgd2hpbGUgKChtYXRjaCA9IExPQ0FUSU9OX1JFR0VYLmV4ZWMoc3RyKSkgIT09IG51bGwpIHtcbiAgICBjb25zdCBmb3JtYXQgPSBXR1NMX1RPX1ZFUlRFWF9UWVBFU1ttYXRjaFszXV0gPz8gXCJmbG9hdDMyXCI7XG4gICAgcmVzdWx0c1ttYXRjaFsyXV0gPSB7XG4gICAgICBsb2NhdGlvbjogcGFyc2VJbnQobWF0Y2hbMV0sIDEwKSxcbiAgICAgIGZvcm1hdCxcbiAgICAgIHN0cmlkZTogZ2V0QXR0cmlidXRlSW5mb0Zyb21Gb3JtYXQoZm9ybWF0KS5zdHJpZGUsXG4gICAgICBvZmZzZXQ6IDAsXG4gICAgICBpbnN0YW5jZTogZmFsc2UsXG4gICAgICBzdGFydDogMFxuICAgIH07XG4gIH1cbiAgTE9DQVRJT05fUkVHRVgubGFzdEluZGV4ID0gMDtcbn1cbmZ1bmN0aW9uIHN0cmlwQ29tbWVudHMoc291cmNlKSB7XG4gIHJldHVybiBzb3VyY2UucmVwbGFjZSgvXFwvXFwvLiokL2dtLCBcIlwiKS5yZXBsYWNlKC9cXC9cXCpbXFxzXFxTXSo/XFwqXFwvL2csIFwiXCIpO1xufVxuZnVuY3Rpb24gZXh0cmFjdEF0dHJpYnV0ZXNGcm9tR3B1UHJvZ3JhbSh7IHNvdXJjZSwgZW50cnlQb2ludCB9KSB7XG4gIGNvbnN0IHJlc3VsdHMgPSB7fTtcbiAgY29uc3QgY2xlYW5Tb3VyY2UgPSBzdHJpcENvbW1lbnRzKHNvdXJjZSk7XG4gIGNvbnN0IG1haW5WZXJ0U3RhcnQgPSBjbGVhblNvdXJjZS5pbmRleE9mKGBmbiAke2VudHJ5UG9pbnR9KGApO1xuICBpZiAobWFpblZlcnRTdGFydCA9PT0gLTEpIHtcbiAgICByZXR1cm4gcmVzdWx0cztcbiAgfVxuICBjb25zdCBhcnJvd0Z1bmN0aW9uU3RhcnQgPSBjbGVhblNvdXJjZS5pbmRleE9mKFwiLT5cIiwgbWFpblZlcnRTdGFydCk7XG4gIGlmIChhcnJvd0Z1bmN0aW9uU3RhcnQgPT09IC0xKSB7XG4gICAgcmV0dXJuIHJlc3VsdHM7XG4gIH1cbiAgY29uc3QgZnVuY3Rpb25BcmdzU3Vic3RyaW5nID0gY2xlYW5Tb3VyY2Uuc3Vic3RyaW5nKG1haW5WZXJ0U3RhcnQsIGFycm93RnVuY3Rpb25TdGFydCk7XG4gIHBhcnNlTG9jYXRpb25zKGZ1bmN0aW9uQXJnc1N1YnN0cmluZywgcmVzdWx0cyk7XG4gIGlmIChPYmplY3Qua2V5cyhyZXN1bHRzKS5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBzdHJ1Y3RNYXRjaCA9IGZ1bmN0aW9uQXJnc1N1YnN0cmluZy5tYXRjaCgvXFwoXFxzKlxcdytcXHMqOlxccyooXFx3KykvKTtcbiAgICBpZiAoc3RydWN0TWF0Y2gpIHtcbiAgICAgIGNvbnN0IHN0cnVjdE5hbWUgPSBzdHJ1Y3RNYXRjaFsxXTtcbiAgICAgIGNvbnN0IHN0cnVjdFJlZ2V4ID0gbmV3IFJlZ0V4cChgc3RydWN0XFxcXHMrJHtzdHJ1Y3ROYW1lfVxcXFxzKlxcXFx7KFtefV0rKVxcXFx9YCwgXCJzXCIpO1xuICAgICAgY29uc3Qgc3RydWN0Qm9keSA9IGNsZWFuU291cmNlLm1hdGNoKHN0cnVjdFJlZ2V4KTtcbiAgICAgIGlmIChzdHJ1Y3RCb2R5KSB7XG4gICAgICAgIHBhcnNlTG9jYXRpb25zKHN0cnVjdEJvZHlbMV0sIHJlc3VsdHMpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gcmVzdWx0cztcbn1cblxuZXhwb3J0IHsgZXh0cmFjdEF0dHJpYnV0ZXNGcm9tR3B1UHJvZ3JhbSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXh0cmFjdEF0dHJpYnV0ZXNGcm9tR3B1UHJvZ3JhbS5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGV4dHJhY3RTdHJ1Y3RBbmRHcm91cHMod2dzbCkge1xuICBjb25zdCBsaW5lUGF0dGVybiA9IC8oXnxbXi9dKUAoZ3JvdXB8YmluZGluZylcXChcXGQrXFwpW147XSs7L2c7XG4gIGNvbnN0IGdyb3VwUGF0dGVybiA9IC9AZ3JvdXBcXCgoXFxkKylcXCkvO1xuICBjb25zdCBiaW5kaW5nUGF0dGVybiA9IC9AYmluZGluZ1xcKChcXGQrKVxcKS87XG4gIGNvbnN0IG5hbWVQYXR0ZXJuID0gL3Zhcig8W14+XSs+KT8gKFxcdyspLztcbiAgY29uc3QgdHlwZVBhdHRlcm4gPSAvOlxccyooW1xcdzw+XSspLztcbiAgY29uc3Qgc3RydWN0UGF0dGVybiA9IC9zdHJ1Y3RcXHMrKFxcdyspXFxzKnsoW159XSspfS9nO1xuICBjb25zdCBzdHJ1Y3RNZW1iZXJQYXR0ZXJuID0gLyhcXHcrKVxccyo6XFxzKihbXFx3XFw8XFw+XSspL2c7XG4gIGNvbnN0IHN0cnVjdE5hbWUgPSAvc3RydWN0XFxzKyhcXHcrKS87XG4gIGNvbnN0IGdyb3VwcyA9IHdnc2wubWF0Y2gobGluZVBhdHRlcm4pPy5tYXAoKGl0ZW0pID0+IHtcbiAgICBjb25zdCB2YXJNYXRjaCA9IGl0ZW0ubWF0Y2gobmFtZVBhdHRlcm4pO1xuICAgIGNvbnN0IHZhclF1YWxpZmllciA9IHZhck1hdGNoPy5bMV0gPz8gXCJcIjtcbiAgICBsZXQgYWNjZXNzTW9kZTtcbiAgICBpZiAodmFyUXVhbGlmaWVyID09PSBcIjx1bmlmb3JtPlwiKSB7XG4gICAgICBhY2Nlc3NNb2RlID0gXCJ1bmlmb3JtXCI7XG4gICAgfSBlbHNlIGlmICh2YXJRdWFsaWZpZXIuc3RhcnRzV2l0aChcIjxzdG9yYWdlXCIpKSB7XG4gICAgICBhY2Nlc3NNb2RlID0gXCJzdG9yYWdlXCI7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICBncm91cDogcGFyc2VJbnQoaXRlbS5tYXRjaChncm91cFBhdHRlcm4pWzFdLCAxMCksXG4gICAgICBiaW5kaW5nOiBwYXJzZUludChpdGVtLm1hdGNoKGJpbmRpbmdQYXR0ZXJuKVsxXSwgMTApLFxuICAgICAgbmFtZTogdmFyTWF0Y2hbMl0sXG4gICAgICBhY2Nlc3NNb2RlLFxuICAgICAgdHlwZTogaXRlbS5tYXRjaCh0eXBlUGF0dGVybilbMV1cbiAgICB9O1xuICB9KTtcbiAgaWYgKCFncm91cHMpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZ3JvdXBzOiBbXSxcbiAgICAgIHN0cnVjdHM6IFtdXG4gICAgfTtcbiAgfVxuICBjb25zdCBzdHJ1Y3RzID0gd2dzbC5tYXRjaChzdHJ1Y3RQYXR0ZXJuKT8ubWFwKChzdHJ1Y3QpID0+IHtcbiAgICBjb25zdCBuYW1lID0gc3RydWN0Lm1hdGNoKHN0cnVjdE5hbWUpWzFdO1xuICAgIGNvbnN0IG1lbWJlcnMgPSBzdHJ1Y3QubWF0Y2goc3RydWN0TWVtYmVyUGF0dGVybikucmVkdWNlKChhY2MsIG1lbWJlcikgPT4ge1xuICAgICAgY29uc3QgW25hbWUyLCB0eXBlXSA9IG1lbWJlci5zcGxpdChcIjpcIik7XG4gICAgICBhY2NbbmFtZTIudHJpbSgpXSA9IHR5cGUudHJpbSgpO1xuICAgICAgcmV0dXJuIGFjYztcbiAgICB9LCB7fSk7XG4gICAgaWYgKCFtZW1iZXJzKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIHsgbmFtZSwgbWVtYmVycyB9O1xuICB9KS5maWx0ZXIoKHsgbmFtZSB9KSA9PiBncm91cHMuc29tZShcbiAgICAoZ3JvdXApID0+IChcbiAgICAgIC8vIEhhbmRsZSBib3RoIGRpcmVjdCB0eXBlIG1hdGNoZXMgYW5kIGdlbmVyaWMgdHlwZXMgbGlrZSBhcnJheTxTdHJ1Y3ROYW1lPlxuICAgICAgZ3JvdXAudHlwZSA9PT0gbmFtZSB8fCBncm91cC50eXBlLmluY2x1ZGVzKGA8JHtuYW1lfT5gKVxuICAgIClcbiAgKSkgPz8gW107XG4gIHJldHVybiB7XG4gICAgZ3JvdXBzLFxuICAgIHN0cnVjdHNcbiAgfTtcbn1cblxuZXhwb3J0IHsgZXh0cmFjdFN0cnVjdEFuZEdyb3VwcyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXh0cmFjdFN0cnVjdEFuZEdyb3Vwcy5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbnZhciBTaGFkZXJTdGFnZSA9IC8qIEBfX1BVUkVfXyAqLyAoKFNoYWRlclN0YWdlMikgPT4ge1xuICBTaGFkZXJTdGFnZTJbU2hhZGVyU3RhZ2UyW1wiVkVSVEVYXCJdID0gMV0gPSBcIlZFUlRFWFwiO1xuICBTaGFkZXJTdGFnZTJbU2hhZGVyU3RhZ2UyW1wiRlJBR01FTlRcIl0gPSAyXSA9IFwiRlJBR01FTlRcIjtcbiAgU2hhZGVyU3RhZ2UyW1NoYWRlclN0YWdlMltcIkNPTVBVVEVcIl0gPSA0XSA9IFwiQ09NUFVURVwiO1xuICByZXR1cm4gU2hhZGVyU3RhZ2UyO1xufSkoU2hhZGVyU3RhZ2UgfHwge30pO1xuXG5leHBvcnQgeyBTaGFkZXJTdGFnZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29uc3QubWpzLm1hcFxuIiwiaW1wb3J0IHsgU2hhZGVyU3RhZ2UgfSBmcm9tICcuLi8uLi8uLi9zaGFyZWQvc2hhZGVyL2NvbnN0Lm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gZ2V0VGV4dHVyZVNhbXBsZVR5cGUodHlwZSkge1xuICBpZiAodHlwZS5lbmRzV2l0aChcIjx1MzI+XCIpKSB7XG4gICAgcmV0dXJuIFwidWludFwiO1xuICB9XG4gIGlmICh0eXBlLmVuZHNXaXRoKFwiPGkzMj5cIikpIHtcbiAgICByZXR1cm4gXCJzaW50XCI7XG4gIH1cbiAgcmV0dXJuIFwiZmxvYXRcIjtcbn1cbmZ1bmN0aW9uIGdlbmVyYXRlR3B1TGF5b3V0R3JvdXBzKHsgZ3JvdXBzIH0pIHtcbiAgY29uc3QgbGF5b3V0ID0gW107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZ3JvdXBzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgZ3JvdXAgPSBncm91cHNbaV07XG4gICAgaWYgKCFsYXlvdXRbZ3JvdXAuZ3JvdXBdKSB7XG4gICAgICBsYXlvdXRbZ3JvdXAuZ3JvdXBdID0gW107XG4gICAgfVxuICAgIGlmIChncm91cC5hY2Nlc3NNb2RlID09PSBcInVuaWZvcm1cIikge1xuICAgICAgbGF5b3V0W2dyb3VwLmdyb3VwXS5wdXNoKHtcbiAgICAgICAgYmluZGluZzogZ3JvdXAuYmluZGluZyxcbiAgICAgICAgdmlzaWJpbGl0eTogU2hhZGVyU3RhZ2UuVkVSVEVYIHwgU2hhZGVyU3RhZ2UuRlJBR01FTlQsXG4gICAgICAgIGJ1ZmZlcjoge1xuICAgICAgICAgIHR5cGU6IFwidW5pZm9ybVwiXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoZ3JvdXAuYWNjZXNzTW9kZSA9PT0gXCJzdG9yYWdlXCIpIHtcbiAgICAgIGxheW91dFtncm91cC5ncm91cF0ucHVzaCh7XG4gICAgICAgIGJpbmRpbmc6IGdyb3VwLmJpbmRpbmcsXG4gICAgICAgIHZpc2liaWxpdHk6IFNoYWRlclN0YWdlLlZFUlRFWCB8IFNoYWRlclN0YWdlLkZSQUdNRU5ULFxuICAgICAgICBidWZmZXI6IHtcbiAgICAgICAgICB0eXBlOiBcInJlYWQtb25seS1zdG9yYWdlXCJcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChncm91cC50eXBlID09PSBcInNhbXBsZXJcIikge1xuICAgICAgbGF5b3V0W2dyb3VwLmdyb3VwXS5wdXNoKHtcbiAgICAgICAgYmluZGluZzogZ3JvdXAuYmluZGluZyxcbiAgICAgICAgdmlzaWJpbGl0eTogU2hhZGVyU3RhZ2UuVkVSVEVYIHwgU2hhZGVyU3RhZ2UuRlJBR01FTlQsXG4gICAgICAgIHNhbXBsZXI6IHtcbiAgICAgICAgICB0eXBlOiBcImZpbHRlcmluZ1wiXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoZ3JvdXAudHlwZSA9PT0gXCJzYW1wbGVyX2NvbXBhcmlzb25cIikge1xuICAgICAgbGF5b3V0W2dyb3VwLmdyb3VwXS5wdXNoKHtcbiAgICAgICAgYmluZGluZzogZ3JvdXAuYmluZGluZyxcbiAgICAgICAgdmlzaWJpbGl0eTogU2hhZGVyU3RhZ2UuVkVSVEVYIHwgU2hhZGVyU3RhZ2UuRlJBR01FTlQsXG4gICAgICAgIHNhbXBsZXI6IHtcbiAgICAgICAgICB0eXBlOiBcImNvbXBhcmlzb25cIlxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKGdyb3VwLnR5cGUgPT09IFwidGV4dHVyZV8yZFwiIHx8IGdyb3VwLnR5cGUuc3RhcnRzV2l0aChcInRleHR1cmVfMmQ8XCIpKSB7XG4gICAgICBsYXlvdXRbZ3JvdXAuZ3JvdXBdLnB1c2goe1xuICAgICAgICBiaW5kaW5nOiBncm91cC5iaW5kaW5nLFxuICAgICAgICB2aXNpYmlsaXR5OiBTaGFkZXJTdGFnZS5WRVJURVggfCBTaGFkZXJTdGFnZS5GUkFHTUVOVCxcbiAgICAgICAgdGV4dHVyZToge1xuICAgICAgICAgIHNhbXBsZVR5cGU6IGdldFRleHR1cmVTYW1wbGVUeXBlKGdyb3VwLnR5cGUpLFxuICAgICAgICAgIHZpZXdEaW1lbnNpb246IFwiMmRcIixcbiAgICAgICAgICBtdWx0aXNhbXBsZWQ6IGZhbHNlXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoZ3JvdXAudHlwZSA9PT0gXCJ0ZXh0dXJlX2RlcHRoXzJkXCIpIHtcbiAgICAgIGxheW91dFtncm91cC5ncm91cF0ucHVzaCh7XG4gICAgICAgIGJpbmRpbmc6IGdyb3VwLmJpbmRpbmcsXG4gICAgICAgIHZpc2liaWxpdHk6IFNoYWRlclN0YWdlLlZFUlRFWCB8IFNoYWRlclN0YWdlLkZSQUdNRU5ULFxuICAgICAgICB0ZXh0dXJlOiB7XG4gICAgICAgICAgc2FtcGxlVHlwZTogXCJkZXB0aFwiLFxuICAgICAgICAgIHZpZXdEaW1lbnNpb246IFwiMmRcIixcbiAgICAgICAgICBtdWx0aXNhbXBsZWQ6IGZhbHNlXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoZ3JvdXAudHlwZSA9PT0gXCJ0ZXh0dXJlX2RlcHRoXzJkX2FycmF5XCIpIHtcbiAgICAgIGxheW91dFtncm91cC5ncm91cF0ucHVzaCh7XG4gICAgICAgIGJpbmRpbmc6IGdyb3VwLmJpbmRpbmcsXG4gICAgICAgIHZpc2liaWxpdHk6IFNoYWRlclN0YWdlLlZFUlRFWCB8IFNoYWRlclN0YWdlLkZSQUdNRU5ULFxuICAgICAgICB0ZXh0dXJlOiB7XG4gICAgICAgICAgc2FtcGxlVHlwZTogXCJkZXB0aFwiLFxuICAgICAgICAgIHZpZXdEaW1lbnNpb246IFwiMmQtYXJyYXlcIixcbiAgICAgICAgICBtdWx0aXNhbXBsZWQ6IGZhbHNlXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoZ3JvdXAudHlwZSA9PT0gXCJ0ZXh0dXJlXzJkX2FycmF5XCIgfHwgZ3JvdXAudHlwZS5zdGFydHNXaXRoKFwidGV4dHVyZV8yZF9hcnJheTxcIikpIHtcbiAgICAgIGxheW91dFtncm91cC5ncm91cF0ucHVzaCh7XG4gICAgICAgIGJpbmRpbmc6IGdyb3VwLmJpbmRpbmcsXG4gICAgICAgIHZpc2liaWxpdHk6IFNoYWRlclN0YWdlLlZFUlRFWCB8IFNoYWRlclN0YWdlLkZSQUdNRU5ULFxuICAgICAgICB0ZXh0dXJlOiB7XG4gICAgICAgICAgc2FtcGxlVHlwZTogZ2V0VGV4dHVyZVNhbXBsZVR5cGUoZ3JvdXAudHlwZSksXG4gICAgICAgICAgdmlld0RpbWVuc2lvbjogXCIyZC1hcnJheVwiLFxuICAgICAgICAgIG11bHRpc2FtcGxlZDogZmFsc2VcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChncm91cC50eXBlID09PSBcInRleHR1cmVfM2RcIiB8fCBncm91cC50eXBlLnN0YXJ0c1dpdGgoXCJ0ZXh0dXJlXzNkPFwiKSkge1xuICAgICAgbGF5b3V0W2dyb3VwLmdyb3VwXS5wdXNoKHtcbiAgICAgICAgYmluZGluZzogZ3JvdXAuYmluZGluZyxcbiAgICAgICAgdmlzaWJpbGl0eTogU2hhZGVyU3RhZ2UuVkVSVEVYIHwgU2hhZGVyU3RhZ2UuRlJBR01FTlQsXG4gICAgICAgIHRleHR1cmU6IHtcbiAgICAgICAgICBzYW1wbGVUeXBlOiBnZXRUZXh0dXJlU2FtcGxlVHlwZShncm91cC50eXBlKSxcbiAgICAgICAgICB2aWV3RGltZW5zaW9uOiBcIjNkXCIsXG4gICAgICAgICAgbXVsdGlzYW1wbGVkOiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKGdyb3VwLnR5cGUgPT09IFwidGV4dHVyZV9jdWJlXCIgfHwgZ3JvdXAudHlwZS5zdGFydHNXaXRoKFwidGV4dHVyZV9jdWJlPFwiKSkge1xuICAgICAgbGF5b3V0W2dyb3VwLmdyb3VwXS5wdXNoKHtcbiAgICAgICAgYmluZGluZzogZ3JvdXAuYmluZGluZyxcbiAgICAgICAgdmlzaWJpbGl0eTogU2hhZGVyU3RhZ2UuVkVSVEVYIHwgU2hhZGVyU3RhZ2UuRlJBR01FTlQsXG4gICAgICAgIHRleHR1cmU6IHtcbiAgICAgICAgICBzYW1wbGVUeXBlOiBnZXRUZXh0dXJlU2FtcGxlVHlwZShncm91cC50eXBlKSxcbiAgICAgICAgICB2aWV3RGltZW5zaW9uOiBcImN1YmVcIixcbiAgICAgICAgICBtdWx0aXNhbXBsZWQ6IGZhbHNlXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBmb3IgKGxldCBpID0gMDsgaSA8IGxheW91dC5sZW5ndGg7IGkrKykge1xuICAgIGxheW91dFtpXSB8fCAobGF5b3V0W2ldID0gW10pO1xuICB9XG4gIHJldHVybiBsYXlvdXQ7XG59XG5cbmV4cG9ydCB7IGdlbmVyYXRlR3B1TGF5b3V0R3JvdXBzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1nZW5lcmF0ZUdwdUxheW91dEdyb3Vwcy5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGdlbmVyYXRlTGF5b3V0SGFzaCh7IGdyb3VwcyB9KSB7XG4gIGNvbnN0IGxheW91dCA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGdyb3Vwcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGdyb3VwID0gZ3JvdXBzW2ldO1xuICAgIGlmICghbGF5b3V0W2dyb3VwLmdyb3VwXSkge1xuICAgICAgbGF5b3V0W2dyb3VwLmdyb3VwXSA9IHt9O1xuICAgIH1cbiAgICBsYXlvdXRbZ3JvdXAuZ3JvdXBdW2dyb3VwLm5hbWVdID0gZ3JvdXAuYmluZGluZztcbiAgfVxuICByZXR1cm4gbGF5b3V0O1xufVxuXG5leHBvcnQgeyBnZW5lcmF0ZUxheW91dEhhc2ggfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdlbmVyYXRlTGF5b3V0SGFzaC5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIHJlbW92ZVN0cnVjdEFuZEdyb3VwRHVwbGljYXRlcyh2ZXJ0ZXhTdHJ1Y3RzQW5kR3JvdXBzLCBmcmFnbWVudFN0cnVjdHNBbmRHcm91cHMpIHtcbiAgY29uc3Qgc3RydWN0TmFtZVNldCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gIGNvbnN0IGR1cGVHcm91cEtleVNldCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gIGNvbnN0IHN0cnVjdHMgPSBbLi4udmVydGV4U3RydWN0c0FuZEdyb3Vwcy5zdHJ1Y3RzLCAuLi5mcmFnbWVudFN0cnVjdHNBbmRHcm91cHMuc3RydWN0c10uZmlsdGVyKChzdHJ1Y3QpID0+IHtcbiAgICBpZiAoc3RydWN0TmFtZVNldC5oYXMoc3RydWN0Lm5hbWUpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHN0cnVjdE5hbWVTZXQuYWRkKHN0cnVjdC5uYW1lKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG4gIGNvbnN0IGdyb3VwcyA9IFsuLi52ZXJ0ZXhTdHJ1Y3RzQW5kR3JvdXBzLmdyb3VwcywgLi4uZnJhZ21lbnRTdHJ1Y3RzQW5kR3JvdXBzLmdyb3Vwc10uZmlsdGVyKChncm91cCkgPT4ge1xuICAgIGNvbnN0IGtleSA9IGAke2dyb3VwLm5hbWV9LSR7Z3JvdXAuYmluZGluZ31gO1xuICAgIGlmIChkdXBlR3JvdXBLZXlTZXQuaGFzKGtleSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZHVwZUdyb3VwS2V5U2V0LmFkZChrZXkpO1xuICAgIHJldHVybiB0cnVlO1xuICB9KTtcbiAgcmV0dXJuIHsgc3RydWN0cywgZ3JvdXBzIH07XG59XG5cbmV4cG9ydCB7IHJlbW92ZVN0cnVjdEFuZEdyb3VwRHVwbGljYXRlcyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVtb3ZlU3RydWN0QW5kR3JvdXBEdXBsaWNhdGVzLm1qcy5tYXBcbiIsImltcG9ydCB7IGNyZWF0ZUlkRnJvbVN0cmluZyB9IGZyb20gJy4uLy4uL3NoYXJlZC91dGlscy9jcmVhdGVJZEZyb21TdHJpbmcubWpzJztcbmltcG9ydCB7IGV4dHJhY3RBdHRyaWJ1dGVzRnJvbUdwdVByb2dyYW0gfSBmcm9tICcuL3V0aWxzL2V4dHJhY3RBdHRyaWJ1dGVzRnJvbUdwdVByb2dyYW0ubWpzJztcbmltcG9ydCB7IGV4dHJhY3RTdHJ1Y3RBbmRHcm91cHMgfSBmcm9tICcuL3V0aWxzL2V4dHJhY3RTdHJ1Y3RBbmRHcm91cHMubWpzJztcbmltcG9ydCB7IGdlbmVyYXRlR3B1TGF5b3V0R3JvdXBzIH0gZnJvbSAnLi91dGlscy9nZW5lcmF0ZUdwdUxheW91dEdyb3Vwcy5tanMnO1xuaW1wb3J0IHsgZ2VuZXJhdGVMYXlvdXRIYXNoIH0gZnJvbSAnLi91dGlscy9nZW5lcmF0ZUxheW91dEhhc2gubWpzJztcbmltcG9ydCB7IHJlbW92ZVN0cnVjdEFuZEdyb3VwRHVwbGljYXRlcyB9IGZyb20gJy4vdXRpbHMvcmVtb3ZlU3RydWN0QW5kR3JvdXBEdXBsaWNhdGVzLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgcHJvZ3JhbUNhY2hlID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG5jbGFzcyBHcHVQcm9ncmFtIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBHcHVQcm9ncmFtXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgZm9yIHRoZSBncHUgcHJvZ3JhbVxuICAgKi9cbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLl9sYXlvdXRLZXkgPSAwO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLl9hdHRyaWJ1dGVMb2NhdGlvbnNLZXkgPSAwO1xuICAgIGNvbnN0IHsgZnJhZ21lbnQsIHZlcnRleCwgbGF5b3V0LCBncHVMYXlvdXQsIG5hbWUgfSA9IG9wdGlvbnM7XG4gICAgdGhpcy5uYW1lID0gbmFtZTtcbiAgICB0aGlzLmZyYWdtZW50ID0gZnJhZ21lbnQ7XG4gICAgdGhpcy52ZXJ0ZXggPSB2ZXJ0ZXg7XG4gICAgaWYgKGZyYWdtZW50LnNvdXJjZSA9PT0gdmVydGV4LnNvdXJjZSkge1xuICAgICAgY29uc3Qgc3RydWN0c0FuZEdyb3VwcyA9IGV4dHJhY3RTdHJ1Y3RBbmRHcm91cHMoZnJhZ21lbnQuc291cmNlKTtcbiAgICAgIHRoaXMuc3RydWN0c0FuZEdyb3VwcyA9IHN0cnVjdHNBbmRHcm91cHM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHZlcnRleFN0cnVjdHNBbmRHcm91cHMgPSBleHRyYWN0U3RydWN0QW5kR3JvdXBzKHZlcnRleC5zb3VyY2UpO1xuICAgICAgY29uc3QgZnJhZ21lbnRTdHJ1Y3RzQW5kR3JvdXBzID0gZXh0cmFjdFN0cnVjdEFuZEdyb3VwcyhmcmFnbWVudC5zb3VyY2UpO1xuICAgICAgdGhpcy5zdHJ1Y3RzQW5kR3JvdXBzID0gcmVtb3ZlU3RydWN0QW5kR3JvdXBEdXBsaWNhdGVzKHZlcnRleFN0cnVjdHNBbmRHcm91cHMsIGZyYWdtZW50U3RydWN0c0FuZEdyb3Vwcyk7XG4gICAgfVxuICAgIHRoaXMubGF5b3V0ID0gbGF5b3V0ID8/IGdlbmVyYXRlTGF5b3V0SGFzaCh0aGlzLnN0cnVjdHNBbmRHcm91cHMpO1xuICAgIHRoaXMuZ3B1TGF5b3V0ID0gZ3B1TGF5b3V0ID8/IGdlbmVyYXRlR3B1TGF5b3V0R3JvdXBzKHRoaXMuc3RydWN0c0FuZEdyb3Vwcyk7XG4gICAgdGhpcy5hdXRvQXNzaWduR2xvYmFsVW5pZm9ybXMgPSAhISh0aGlzLmxheW91dFswXT8uZ2xvYmFsVW5pZm9ybXMgIT09IHZvaWQgMCk7XG4gICAgdGhpcy5hdXRvQXNzaWduTG9jYWxVbmlmb3JtcyA9ICEhKHRoaXMubGF5b3V0WzFdPy5sb2NhbFVuaWZvcm1zICE9PSB2b2lkIDApO1xuICAgIHRoaXMuX2dlbmVyYXRlUHJvZ3JhbUtleSgpO1xuICB9XG4gIC8vIFRPRE8gbWFrZXIgdGhpcyBwdXJlXG4gIF9nZW5lcmF0ZVByb2dyYW1LZXkoKSB7XG4gICAgY29uc3QgeyB2ZXJ0ZXgsIGZyYWdtZW50IH0gPSB0aGlzO1xuICAgIGNvbnN0IGJpZ0tleSA9IHZlcnRleC5zb3VyY2UgKyBmcmFnbWVudC5zb3VyY2UgKyB2ZXJ0ZXguZW50cnlQb2ludCArIGZyYWdtZW50LmVudHJ5UG9pbnQ7XG4gICAgdGhpcy5fbGF5b3V0S2V5ID0gY3JlYXRlSWRGcm9tU3RyaW5nKGJpZ0tleSwgXCJwcm9ncmFtXCIpO1xuICB9XG4gIGdldCBhdHRyaWJ1dGVEYXRhKCkge1xuICAgIHRoaXMuX2F0dHJpYnV0ZURhdGEgPz8gKHRoaXMuX2F0dHJpYnV0ZURhdGEgPSBleHRyYWN0QXR0cmlidXRlc0Zyb21HcHVQcm9ncmFtKHRoaXMudmVydGV4KSk7XG4gICAgcmV0dXJuIHRoaXMuX2F0dHJpYnV0ZURhdGE7XG4gIH1cbiAgLyoqIGRlc3Ryb3lzIHRoZSBwcm9ncmFtICovXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5ncHVMYXlvdXQgPSBudWxsO1xuICAgIHRoaXMubGF5b3V0ID0gbnVsbDtcbiAgICB0aGlzLnN0cnVjdHNBbmRHcm91cHMgPSBudWxsO1xuICAgIHRoaXMuZnJhZ21lbnQgPSBudWxsO1xuICAgIHRoaXMudmVydGV4ID0gbnVsbDtcbiAgICBwcm9ncmFtQ2FjaGVbdGhpcy5fY2FjaGVLZXldID0gbnVsbDtcbiAgfVxuICAvKipcbiAgICogSGVscGVyIGZ1bmN0aW9uIHRoYXQgY3JlYXRlcyBhIHByb2dyYW0gZm9yIGEgZ2l2ZW4gc291cmNlLlxuICAgKiBJdCB3aWxsIGNoZWNrIHRoZSBwcm9ncmFtIGNhY2hlIGlmIHRoZSBwcm9ncmFtIGhhcyBhbHJlYWR5IGJlZW4gY3JlYXRlZC5cbiAgICogSWYgaXQgaGFzIHRoYXQgb25lIHdpbGwgYmUgcmV0dXJuZWQsIGlmIG5vdCBhIG5ldyBvbmUgd2lsbCBiZSBjcmVhdGVkIGFuZCBjYWNoZWQuXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgZm9yIHRoZSBwcm9ncmFtLlxuICAgKiBAcmV0dXJucyBBIHByb2dyYW0gdXNpbmcgdGhlIHNhbWUgc291cmNlXG4gICAqL1xuICBzdGF0aWMgZnJvbShvcHRpb25zKSB7XG4gICAgY29uc3Qga2V5ID0gYCR7b3B0aW9ucy52ZXJ0ZXguc291cmNlfToke29wdGlvbnMuZnJhZ21lbnQuc291cmNlfToke29wdGlvbnMuZnJhZ21lbnQuZW50cnlQb2ludH06JHtvcHRpb25zLnZlcnRleC5lbnRyeVBvaW50fWA7XG4gICAgaWYgKCFwcm9ncmFtQ2FjaGVba2V5XSkge1xuICAgICAgcHJvZ3JhbUNhY2hlW2tleV0gPSBuZXcgR3B1UHJvZ3JhbShvcHRpb25zKTtcbiAgICAgIHByb2dyYW1DYWNoZVtrZXldLl9jYWNoZUtleSA9IGtleTtcbiAgICB9XG4gICAgcmV0dXJuIHByb2dyYW1DYWNoZVtrZXldO1xuICB9XG59XG5cbmV4cG9ydCB7IEdwdVByb2dyYW0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUdwdVByb2dyYW0ubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBVTklGT1JNX1RZUEVTX1ZBTFVFUyA9IFtcbiAgXCJmMzJcIixcbiAgXCJpMzJcIixcbiAgXCJ1MzJcIixcbiAgXCJ2ZWMyPGYzMj5cIixcbiAgXCJ2ZWMzPGYzMj5cIixcbiAgXCJ2ZWM0PGYzMj5cIixcbiAgXCJtYXQyeDI8ZjMyPlwiLFxuICBcIm1hdDN4MzxmMzI+XCIsXG4gIFwibWF0NHg0PGYzMj5cIixcbiAgXCJtYXQzeDI8ZjMyPlwiLFxuICBcIm1hdDR4MjxmMzI+XCIsXG4gIFwibWF0MngzPGYzMj5cIixcbiAgXCJtYXQ0eDM8ZjMyPlwiLFxuICBcIm1hdDJ4NDxmMzI+XCIsXG4gIFwibWF0M3g0PGYzMj5cIixcbiAgXCJ2ZWMyPGkzMj5cIixcbiAgXCJ2ZWMzPGkzMj5cIixcbiAgXCJ2ZWM0PGkzMj5cIixcbiAgXCJ2ZWMyPHUzMj5cIixcbiAgXCJ2ZWMzPHUzMj5cIixcbiAgXCJ2ZWM0PHUzMj5cIlxuXTtcbmNvbnN0IFVOSUZPUk1fVFlQRVNfTUFQID0gVU5JRk9STV9UWVBFU19WQUxVRVMucmVkdWNlKChhY2MsIHR5cGUpID0+IHtcbiAgYWNjW3R5cGVdID0gdHJ1ZTtcbiAgcmV0dXJuIGFjYztcbn0sIHt9KTtcblxuZXhwb3J0IHsgVU5JRk9STV9UWVBFU19NQVAsIFVOSUZPUk1fVFlQRVNfVkFMVUVTIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD10eXBlcy5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGdldERlZmF1bHRVbmlmb3JtVmFsdWUodHlwZSwgc2l6ZSkge1xuICBzd2l0Y2ggKHR5cGUpIHtcbiAgICBjYXNlIFwiZjMyXCI6XG4gICAgICByZXR1cm4gMDtcbiAgICBjYXNlIFwidmVjMjxmMzI+XCI6XG4gICAgICByZXR1cm4gbmV3IEZsb2F0MzJBcnJheSgyICogc2l6ZSk7XG4gICAgY2FzZSBcInZlYzM8ZjMyPlwiOlxuICAgICAgcmV0dXJuIG5ldyBGbG9hdDMyQXJyYXkoMyAqIHNpemUpO1xuICAgIGNhc2UgXCJ2ZWM0PGYzMj5cIjpcbiAgICAgIHJldHVybiBuZXcgRmxvYXQzMkFycmF5KDQgKiBzaXplKTtcbiAgICBjYXNlIFwibWF0MngyPGYzMj5cIjpcbiAgICAgIHJldHVybiBuZXcgRmxvYXQzMkFycmF5KFtcbiAgICAgICAgMSxcbiAgICAgICAgMCxcbiAgICAgICAgMCxcbiAgICAgICAgMVxuICAgICAgXSk7XG4gICAgY2FzZSBcIm1hdDN4MzxmMzI+XCI6XG4gICAgICByZXR1cm4gbmV3IEZsb2F0MzJBcnJheShbXG4gICAgICAgIDEsXG4gICAgICAgIDAsXG4gICAgICAgIDAsXG4gICAgICAgIDAsXG4gICAgICAgIDEsXG4gICAgICAgIDAsXG4gICAgICAgIDAsXG4gICAgICAgIDAsXG4gICAgICAgIDFcbiAgICAgIF0pO1xuICAgIGNhc2UgXCJtYXQ0eDQ8ZjMyPlwiOlxuICAgICAgcmV0dXJuIG5ldyBGbG9hdDMyQXJyYXkoW1xuICAgICAgICAxLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICAxLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICAxLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICAxXG4gICAgICBdKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZXhwb3J0IHsgZ2V0RGVmYXVsdFVuaWZvcm1WYWx1ZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Z2V0RGVmYXVsdFVuaWZvcm1WYWx1ZS5tanMubWFwXG4iLCJpbXBvcnQgRXZlbnRFbWl0dGVyIGZyb20gJ2V2ZW50ZW1pdHRlcjMnO1xuaW1wb3J0IHsgdWlkIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvZGF0YS91aWQubWpzJztcbmltcG9ydCB7IGNyZWF0ZUlkRnJvbVN0cmluZyB9IGZyb20gJy4uL3V0aWxzL2NyZWF0ZUlkRnJvbVN0cmluZy5tanMnO1xuaW1wb3J0IHsgVU5JRk9STV9UWVBFU19NQVAsIFVOSUZPUk1fVFlQRVNfVkFMVUVTIH0gZnJvbSAnLi90eXBlcy5tanMnO1xuaW1wb3J0IHsgZ2V0RGVmYXVsdFVuaWZvcm1WYWx1ZSB9IGZyb20gJy4vdXRpbHMvZ2V0RGVmYXVsdFVuaWZvcm1WYWx1ZS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IF9Vbmlmb3JtR3JvdXAgPSBjbGFzcyBfVW5pZm9ybUdyb3VwIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBVbmlmb3JtIGdyb3VwXG4gICAqIEBwYXJhbSB1bmlmb3JtU3RydWN0dXJlcyAtIFRoZSBzdHJ1Y3R1cmVzIG9mIHRoZSB1bmlmb3JtIGdyb3VwXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9wdGlvbmFsIHBhcmFtZXRlcnMgb2YgdGhpcyB1bmlmb3JtIGdyb3VwXG4gICAqL1xuICBjb25zdHJ1Y3Rvcih1bmlmb3JtU3RydWN0dXJlcywgb3B0aW9ucykge1xuICAgIHN1cGVyKCk7XG4gICAgLyoqIGEgdW5pcXVlIGlkIGZvciB0aGlzIHVuaWZvcm0gZ3JvdXAgdXNlZCB0aHJvdWdoIHRoZSByZW5kZXJlciAqL1xuICAgIHRoaXMudWlkID0gdWlkKFwidW5pZm9ybVwiKTtcbiAgICAvKipcbiAgICAgKiBhIHJlc291cmNlIHR5cGUsIHVzZWQgdG8gaWRlbnRpZnkgaG93IHRvIGhhbmRsZSBpdCB3aGVuIGl0cyBpbiBhIGJpbmQgZ3JvdXAgLyBzaGFkZXIgcmVzb3VyY2VcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9yZXNvdXJjZVR5cGUgPSBcInVuaWZvcm1Hcm91cFwiO1xuICAgIC8qKlxuICAgICAqIHRoZSByZXNvdXJjZSBpZCB1c2VkIGludGVybmFsbHkgYnkgdGhlIHJlbmRlcmVyIHRvIGJ1aWxkIGJpbmQgZ3JvdXAga2V5c1xuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX3Jlc291cmNlSWQgPSB1aWQoXCJyZXNvdXJjZVwiKTtcbiAgICAvKiogdXNlZCBpdG8gaWRlbnRpZnkgaWYgdGhpcyBpcyBhIHVuaWZvcm0gZ3JvdXAgKi9cbiAgICB0aGlzLmlzVW5pZm9ybUdyb3VwID0gdHJ1ZTtcbiAgICAvKipcbiAgICAgKiB1c2VkIHRvIGZsYWcgaWYgdGhpcyBVbmlmb3JtIGdyb3VwcyBkYXRhIGlzIGRpZmZlcmVudCBmcm9tIHdoYXQgaXQgaGFzIHN0b3JlZCBpbiBpdHMgYnVmZmVyIC8gb24gdGhlIEdQVVxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX2RpcnR5SWQgPSAwO1xuICAgIC8vIGltcGxlbWVudGluZyB0aGUgaW50ZXJmYWNlIC0gVW5pZm9ybUdyb3VwIGFyZSBub3QgZGVzdHJveWVkXG4gICAgdGhpcy5kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICBvcHRpb25zID0geyAuLi5fVW5pZm9ybUdyb3VwLmRlZmF1bHRPcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgdGhpcy51bmlmb3JtU3RydWN0dXJlcyA9IHVuaWZvcm1TdHJ1Y3R1cmVzO1xuICAgIGNvbnN0IHVuaWZvcm1zID0ge307XG4gICAgZm9yIChjb25zdCBpIGluIHVuaWZvcm1TdHJ1Y3R1cmVzKSB7XG4gICAgICBjb25zdCB1bmlmb3JtRGF0YSA9IHVuaWZvcm1TdHJ1Y3R1cmVzW2ldO1xuICAgICAgdW5pZm9ybURhdGEubmFtZSA9IGk7XG4gICAgICB1bmlmb3JtRGF0YS5zaXplID0gdW5pZm9ybURhdGEuc2l6ZSA/PyAxO1xuICAgICAgaWYgKCFVTklGT1JNX1RZUEVTX01BUFt1bmlmb3JtRGF0YS50eXBlXSkge1xuICAgICAgICBjb25zdCBhcnJheU1hdGNoID0gdW5pZm9ybURhdGEudHlwZS5tYXRjaCgvXmFycmF5PChcXHcrKD86PFxcdys+KT8pLFxccyooXFxkKyk+JC8pO1xuICAgICAgICBpZiAoYXJyYXlNYXRjaCkge1xuICAgICAgICAgIGNvbnN0IFssIGlubmVyVHlwZSwgc2l6ZV0gPSBhcnJheU1hdGNoO1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIGBVbmlmb3JtIHR5cGUgJHt1bmlmb3JtRGF0YS50eXBlfSBpcyBub3Qgc3VwcG9ydGVkLiBVc2UgdHlwZTogJyR7aW5uZXJUeXBlfScsIHNpemU6ICR7c2l6ZX0gaW5zdGVhZC5gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuaWZvcm0gdHlwZSAke3VuaWZvcm1EYXRhLnR5cGV9IGlzIG5vdCBzdXBwb3J0ZWQuIFN1cHBvcnRlZCB1bmlmb3JtIHR5cGVzIGFyZTogJHtVTklGT1JNX1RZUEVTX1ZBTFVFUy5qb2luKFwiLCBcIil9YCk7XG4gICAgICB9XG4gICAgICB1bmlmb3JtRGF0YS52YWx1ZSA/PyAodW5pZm9ybURhdGEudmFsdWUgPSBnZXREZWZhdWx0VW5pZm9ybVZhbHVlKHVuaWZvcm1EYXRhLnR5cGUsIHVuaWZvcm1EYXRhLnNpemUpKTtcbiAgICAgIHVuaWZvcm1zW2ldID0gdW5pZm9ybURhdGEudmFsdWU7XG4gICAgfVxuICAgIHRoaXMudW5pZm9ybXMgPSB1bmlmb3JtcztcbiAgICB0aGlzLl9kaXJ0eUlkID0gMTtcbiAgICB0aGlzLnVibyA9IG9wdGlvbnMudWJvO1xuICAgIHRoaXMuaXNTdGF0aWMgPSBvcHRpb25zLmlzU3RhdGljO1xuICAgIHRoaXMuX3NpZ25hdHVyZSA9IGNyZWF0ZUlkRnJvbVN0cmluZyhPYmplY3Qua2V5cyh1bmlmb3JtcykubWFwKFxuICAgICAgKGkpID0+IGAke2l9LSR7dW5pZm9ybVN0cnVjdHVyZXNbaV0udHlwZX1gXG4gICAgKS5qb2luKFwiLVwiKSwgXCJ1bmlmb3JtLWdyb3VwXCIpO1xuICB9XG4gIC8qKlxuICAgKiBhbiB1bmRlcmx5aW5nIGJ1ZmZlciB0aGF0IHdpbGwgYmUgdXBsb2FkZWQgdG8gdGhlIEdQVSB3aGVuIHVzaW5nIHRoaXMgVW5pZm9ybUdyb3VwLlxuICAgKiBJdCBpcyBjcmVhdGVkIGxhemlseSBieSB0aGUgcmVuZGVyZXIncyB1Ym8gc3lzdGVtIG9uIGZpcnN0IHVzZS5cbiAgICovXG4gIGdldCBidWZmZXIoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2J1ZmZlcjtcbiAgfVxuICBzZXQgYnVmZmVyKHZhbHVlKSB7XG4gICAgaWYgKHRoaXMuX2J1ZmZlciA9PT0gdmFsdWUpIHJldHVybjtcbiAgICB0aGlzLl9idWZmZXI/Lm9mZihcImNoYW5nZVwiLCB0aGlzLm9uQnVmZmVyQ2hhbmdlLCB0aGlzKTtcbiAgICB0aGlzLl9idWZmZXIgPSB2YWx1ZTtcbiAgICB2YWx1ZT8ub24oXCJjaGFuZ2VcIiwgdGhpcy5vbkJ1ZmZlckNoYW5nZSwgdGhpcyk7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBHQyB0cmFja3MgdGhpcyBncm91cCdzIHVuZGVybHlpbmcgYnVmZmVyLCBub3QgdGhlIGdyb3VwIGl0c2VsZiDigJQgYSBHQyBzdGFtcCBvbiB0aGVcbiAgICogZ3JvdXAgKHNlZSBCaW5kR3JvdXAuX3RvdWNoKSBtdXN0IGxhbmQgb24gdGhlIGJ1ZmZlciwgb3IgdGhlIEdDIGNvbGxlY3RzIGl0IHdoaWxlXG4gICAqIGNhY2hlZCBiaW5kIGdyb3VwcyBzdGlsbCByZWZlcmVuY2UgaXQuXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgZ2V0IF9nY0xhc3RVc2VkKCkge1xuICAgIHJldHVybiB0aGlzLl9idWZmZXI/Ll9nY0xhc3RVc2VkID8/IC0xO1xuICB9XG4gIHNldCBfZ2NMYXN0VXNlZCh2YWx1ZSkge1xuICAgIGlmICh0aGlzLl9idWZmZXIpIHRoaXMuX2J1ZmZlci5fZ2NMYXN0VXNlZCA9IHZhbHVlO1xuICB9XG4gIC8qKlxuICAgKiBCaW5kIGdyb3VwIGtleXMgYXJlIGJ1aWx0IGZyb20gdGhpcyBncm91cCdzIF9yZXNvdXJjZUlkLCBub3QgdGhlIGJ1ZmZlcidzIOKAlCBzbyB3aGVuIHRoZVxuICAgKiBidWZmZXIgcmUta2V5cyAoaXQgcmVzaXplZCwgb3IgdGhlIEdDIHVubG9hZGVkIGl0cyBHUFUgY29weSksIHRoaXMgZ3JvdXAgbXVzdCByZS1rZXkgdG9vLFxuICAgKiBvciBjYWNoZWQgR1BVQmluZEdyb3VwcyBrZWVwIHJlZmVyZW5jaW5nIHRoZSBkZXN0cm95ZWQgR1BVIGJ1ZmZlci5cbiAgICovXG4gIG9uQnVmZmVyQ2hhbmdlKCkge1xuICAgIHRoaXMuX3Jlc291cmNlSWQgPSB1aWQoXCJyZXNvdXJjZVwiKTtcbiAgICB0aGlzLmVtaXQoXCJjaGFuZ2VcIiwgdGhpcyk7XG4gIH1cbiAgLyoqIENhbGwgdGhpcyBpZiB5b3Ugd2FudCB0aGUgdW5pZm9ybSBncm91cHMgZGF0YSB0byBiZSB1cGxvYWRlZCB0byB0aGUgR1BVIG9ubHkgdXNlZnVsIGlmIGBpc1N0YXRpY2AgaXMgdHJ1ZS4gKi9cbiAgdXBkYXRlKCkge1xuICAgIHRoaXMuX2RpcnR5SWQrKztcbiAgfVxufTtcbi8qKlxuICogZW1pdHMgd2hlbiB0aGUgdW5kZXJseWluZyBidWZmZXIgbmVlZHMgdG8gYmUgcmUtYm91bmQgKGl0IHJlc2l6ZWQgb3Igd2FzIHVubG9hZGVkKSxcbiAqIGxldHRpbmcgY2FjaGVkIGJpbmQgZ3JvdXBzIGtub3cgdGhleSBtdXN0IHJlYnVpbGRcbiAqIEBldmVudCBjaGFuZ2VcbiAqL1xuLyoqIFRoZSBkZWZhdWx0IG9wdGlvbnMgdXNlZCBieSB0aGUgdW5pZm9ybSBncm91cC4gKi9cbl9Vbmlmb3JtR3JvdXAuZGVmYXVsdE9wdGlvbnMgPSB7XG4gIC8qKiBpZiB0cnVlIHRoZSBVbmlmb3JtR3JvdXAgaXMgaGFuZGxlZCBhcyBhbiBVbmlmb3JtIGJ1ZmZlciBvYmplY3QuICovXG4gIHVibzogZmFsc2UsXG4gIC8qKiBpZiB0cnVlLCB0aGVuIHlvdSBhcmUgcmVzcG9uc2libGUgZm9yIHdoZW4gdGhlIGRhdGEgaXMgdXBsb2FkZWQgdG8gdGhlIEdQVSBieSBjYWxsaW5nIGB1cGRhdGUoKWAgKi9cbiAgaXNTdGF0aWM6IGZhbHNlXG59O1xubGV0IFVuaWZvcm1Hcm91cCA9IF9Vbmlmb3JtR3JvdXA7XG5cbmV4cG9ydCB7IFVuaWZvcm1Hcm91cCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9VW5pZm9ybUdyb3VwLm1qcy5tYXBcbiIsImltcG9ydCB7IHdhcm4gfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9sb2dnaW5nL3dhcm4ubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBCaW5kR3JvdXAge1xuICAvKipcbiAgICogQ3JlYXRlIGEgbmV3IGluc3RhbmNlIG9mIHRoZSBCaW5kIEdyb3VwLlxuICAgKiBAcGFyYW0gcmVzb3VyY2VzIC0gVGhlIHJlc291cmNlcyB0aGF0IGFyZSBib3VuZCB0b2dldGhlciBmb3IgdXNlIGJ5IGEgc2hhZGVyLlxuICAgKi9cbiAgY29uc3RydWN0b3IocmVzb3VyY2VzKSB7XG4gICAgLyoqXG4gICAgICogVGhlIHJlc291cmNlcyB0aGF0IGFyZSBib3VuZCB0b2dldGhlciBmb3IgdXNlIGJ5IGEgc2hhZGVyLCBrZXllZCBieSBiaW5kaW5nIG51bWJlci5cbiAgICAgKlxuICAgICAqIFRyZWF0IHRoaXMgYXMgcmVhZC1vbmx5IGFuZCB1c2Uge0BsaW5rIEJpbmRHcm91cCNzZXRSZXNvdXJjZX0gdG8gYWRkIG9yIHJlcGxhY2UgYSByZXNvdXJjZS5cbiAgICAgKiBBIGRpcmVjdCB3cml0ZSBza2lwcyB0aGUgYmluZCBncm91cCdzIGNoYW5nZSB0cmFja2luZzogdGhlIEdQVSBiaW5kIGdyb3VwIGlzIG5vdCByZWJ1aWx0LFxuICAgICAqIGFuZCB0aGUgcmVuZGVyZXIgbmV2ZXIgc3luY3MgdGhlIG5ldyByZXNvdXJjZSdzIHVuaWZvcm1zIG9yIG1hcmtzIGl0IGFzIGluIHVzZS5cbiAgICAgKiBAcmVhZG9ubHlcbiAgICAgKi9cbiAgICB0aGlzLnJlc291cmNlcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIHRoaXMuX3Jlc291cmNlS2V5c1ZhbHVlID0gbnVsbDtcbiAgICB0aGlzLl9kaXJ0eSA9IHRydWU7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBmb3IgKGNvbnN0IGkgaW4gcmVzb3VyY2VzKSB7XG4gICAgICBjb25zdCByZXNvdXJjZSA9IHJlc291cmNlc1tpXTtcbiAgICAgIHRoaXMuc2V0UmVzb3VyY2UocmVzb3VyY2UsIGluZGV4KyspO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogVGhlIGJpbmRpbmcgbnVtYmVycyBpbiB1c2UgaW4ge0BsaW5rIEJpbmRHcm91cCNyZXNvdXJjZXN9LCBhc2NlbmRpbmcuIEJpbmRpbmcgbnVtYmVycyBjYW5cbiAgICogaGF2ZSBnYXBzLCBzbyBwZXItZHJhdyBsb29wcyBpbmRleCB0aGlzIGxpc3QgaW5zdGVhZCBvZiBydW5uaW5nIGBmb3IuLi5pbmAgb3ZlclxuICAgKiBgcmVzb3VyY2VzYCwgd2hpY2ggYnVpbGRzIGEgZnJlc2gga2V5IGxpc3Qgb24gZXZlcnkgY2FsbCBmb3IgaW50ZWdlciBrZXlzLlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGdldCBfcmVzb3VyY2VLZXlzKCkge1xuICAgIHRoaXMuX3Jlc291cmNlS2V5c1ZhbHVlID8/ICh0aGlzLl9yZXNvdXJjZUtleXNWYWx1ZSA9IE9iamVjdC5rZXlzKHRoaXMucmVzb3VyY2VzKS5tYXAoTnVtYmVyKSk7XG4gICAgcmV0dXJuIHRoaXMuX3Jlc291cmNlS2V5c1ZhbHVlO1xuICB9XG4gIC8qKlxuICAgKiBBIGtleSB1c2VkIGludGVybmFsbHkgdG8gbWF0Y2ggaXQgdXAgdG8gYSBXZWJHUFUgQmluZEdyb3VwLlxuICAgKiBMYXppbHkgcmVidWlsdCBmcm9tIHJlc291cmNlIElEcyB3aGVuIGRpcnR5LlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGdldCBfa2V5KCkge1xuICAgIGlmICh0aGlzLl9kaXJ0eSkge1xuICAgICAgdGhpcy5fZGlydHkgPSBmYWxzZTtcbiAgICAgIGNvbnN0IGtleVBhcnRzID0gW107XG4gICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgZm9yIChjb25zdCBpIGluIHRoaXMucmVzb3VyY2VzKSB7XG4gICAgICAgIGtleVBhcnRzW2luZGV4KytdID0gdGhpcy5yZXNvdXJjZXNbaV0gPyB0aGlzLnJlc291cmNlc1tpXS5fcmVzb3VyY2VJZCA6IC0xO1xuICAgICAgfVxuICAgICAgdGhpcy5fa2V5VmFsdWUgPSBrZXlQYXJ0cy5qb2luKFwifFwiKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2tleVZhbHVlO1xuICB9XG4gIC8qKlxuICAgKiBTZXQgYSByZXNvdXJjZSBhdCBhIGdpdmVuIGluZGV4LiBUaGlzIGZ1bmN0aW9uIHdpbGxcbiAgICogZW5zdXJlIHRoYXQgbGlzdGVuZXJzIHdpbGwgYmUgcmVtb3ZlZCBmcm9tIHRoZSBjdXJyZW50IHJlc291cmNlXG4gICAqIGFuZCBhZGRlZCB0byB0aGUgbmV3IHJlc291cmNlLlxuICAgKiBAcGFyYW0gcmVzb3VyY2UgLSBUaGUgcmVzb3VyY2UgdG8gc2V0LlxuICAgKiBAcGFyYW0gaW5kZXggLSBUaGUgaW5kZXggdG8gc2V0IHRoZSByZXNvdXJjZSBhdC5cbiAgICovXG4gIHNldFJlc291cmNlKHJlc291cmNlLCBpbmRleCkge1xuICAgIGNvbnN0IGN1cnJlbnRSZXNvdXJjZSA9IHRoaXMucmVzb3VyY2VzW2luZGV4XTtcbiAgICBpZiAocmVzb3VyY2UgPT09IGN1cnJlbnRSZXNvdXJjZSkgcmV0dXJuO1xuICAgIGlmIChjdXJyZW50UmVzb3VyY2UpIHtcbiAgICAgIGN1cnJlbnRSZXNvdXJjZS5vZmY/LihcImNoYW5nZVwiLCB0aGlzLm9uUmVzb3VyY2VDaGFuZ2UsIHRoaXMpO1xuICAgIH1cbiAgICByZXNvdXJjZS5vbj8uKFwiY2hhbmdlXCIsIHRoaXMub25SZXNvdXJjZUNoYW5nZSwgdGhpcyk7XG4gICAgaWYgKGN1cnJlbnRSZXNvdXJjZSA9PT0gdm9pZCAwKSB7XG4gICAgICB0aGlzLl9yZXNvdXJjZUtleXNWYWx1ZSA9IG51bGw7XG4gICAgfVxuICAgIHRoaXMucmVzb3VyY2VzW2luZGV4XSA9IHJlc291cmNlO1xuICAgIHRoaXMuX2RpcnR5ID0gdHJ1ZTtcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgcmVzb3VyY2UgYXQgdGhlIGN1cnJlbnQgc3BlY2lmaWVkIGluZGV4LlxuICAgKiBAcGFyYW0gaW5kZXggLSBUaGUgaW5kZXggb2YgdGhlIHJlc291cmNlIHRvIGdldC5cbiAgICogQHJldHVybnMgLSBUaGUgcmVzb3VyY2UgYXQgdGhlIHNwZWNpZmllZCBpbmRleC5cbiAgICovXG4gIGdldFJlc291cmNlKGluZGV4KSB7XG4gICAgcmV0dXJuIHRoaXMucmVzb3VyY2VzW2luZGV4XTtcbiAgfVxuICAvKipcbiAgICogVXNlZCBpbnRlcm5hbGx5IHRvICd0b3VjaCcgZWFjaCByZXNvdXJjZSwgdG8gZW5zdXJlIHRoYXQgdGhlIEdDXG4gICAqIGtub3dzIHRoYXQgYWxsIHJlc291cmNlcyBpbiB0aGlzIGJpbmQgZ3JvdXAgYXJlIHN0aWxsIGJlaW5nIHVzZWQuXG4gICAqIEBwYXJhbSBub3cgLSBUaGUgY3VycmVudCB0aW1lIGluIG1pbGxpc2Vjb25kcy5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBfdG91Y2gobm93KSB7XG4gICAgY29uc3QgcmVzb3VyY2VzID0gdGhpcy5yZXNvdXJjZXM7XG4gICAgY29uc3Qga2V5cyA9IHRoaXMuX3Jlc291cmNlS2V5cztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IHJlc291cmNlID0gcmVzb3VyY2VzW2tleXNbaV1dO1xuICAgICAgaWYgKCFyZXNvdXJjZSkgY29udGludWU7XG4gICAgICByZXNvdXJjZS5fZ2NMYXN0VXNlZCA9IG5vdztcbiAgICB9XG4gIH1cbiAgLyoqIERlc3Ryb3lzIHRoaXMgYmluZCBncm91cCBhbmQgcmVtb3ZlcyBhbGwgbGlzdGVuZXJzLiAqL1xuICBkZXN0cm95KCkge1xuICAgIGNvbnN0IHJlc291cmNlcyA9IHRoaXMucmVzb3VyY2VzO1xuICAgIGZvciAoY29uc3QgaSBpbiByZXNvdXJjZXMpIHtcbiAgICAgIGNvbnN0IHJlc291cmNlID0gcmVzb3VyY2VzW2ldO1xuICAgICAgcmVzb3VyY2U/Lm9mZj8uKFwiY2hhbmdlXCIsIHRoaXMub25SZXNvdXJjZUNoYW5nZSwgdGhpcyk7XG4gICAgfVxuICAgIHRoaXMucmVzb3VyY2VzID0gbnVsbDtcbiAgICB0aGlzLl9yZXNvdXJjZUtleXNWYWx1ZSA9IG51bGw7XG4gIH1cbiAgb25SZXNvdXJjZUNoYW5nZShyZXNvdXJjZSkge1xuICAgIHRoaXMuX2RpcnR5ID0gdHJ1ZTtcbiAgICBpZiAocmVzb3VyY2UuZGVzdHJveWVkKSB7XG4gICAgICBjb25zdCByZXNvdXJjZXMgPSB0aGlzLnJlc291cmNlcztcbiAgICAgIGZvciAoY29uc3QgaSBpbiByZXNvdXJjZXMpIHtcbiAgICAgICAgaWYgKHJlc291cmNlc1tpXSA9PT0gcmVzb3VyY2UpIHtcbiAgICAgICAgICByZXNvdXJjZXNbaV0gPSBudWxsO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB3YXJuKGBbQmluZEdyb3VwXSBhICcke3Jlc291cmNlLl9yZXNvdXJjZVR5cGV9JyB3YXMgZGVzdHJveWVkIHdoaWxlIHN0aWxsIGJvdW5kIHRvIGEgc2hhZGVyLiBSZW1vdmUgaXQgZnJvbSB0aGUgc2hhZGVyIGJlZm9yZSBkZXN0cm95aW5nIGl0LmApO1xuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgeyBCaW5kR3JvdXAgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUJpbmRHcm91cC5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbnZhciBSZW5kZXJlclR5cGUgPSAvKiBAX19QVVJFX18gKi8gKChSZW5kZXJlclR5cGUyKSA9PiB7XG4gIFJlbmRlcmVyVHlwZTJbUmVuZGVyZXJUeXBlMltcIldFQkdMXCJdID0gMV0gPSBcIldFQkdMXCI7XG4gIFJlbmRlcmVyVHlwZTJbUmVuZGVyZXJUeXBlMltcIldFQkdQVVwiXSA9IDJdID0gXCJXRUJHUFVcIjtcbiAgUmVuZGVyZXJUeXBlMltSZW5kZXJlclR5cGUyW1wiQ0FOVkFTXCJdID0gNF0gPSBcIkNBTlZBU1wiO1xuICBSZW5kZXJlclR5cGUyW1JlbmRlcmVyVHlwZTJbXCJCT1RIXCJdID0gM10gPSBcIkJPVEhcIjtcbiAgcmV0dXJuIFJlbmRlcmVyVHlwZTI7XG59KShSZW5kZXJlclR5cGUgfHwge30pO1xuXG5leHBvcnQgeyBSZW5kZXJlclR5cGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXR5cGVzLm1qcy5tYXBcbiIsImltcG9ydCB7IGNyZWF0ZUlkRnJvbVN0cmluZyB9IGZyb20gJy4uL3V0aWxzL2NyZWF0ZUlkRnJvbVN0cmluZy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIFNoYWRlck92ZXJyaWRlcyB7XG4gIC8qKlxuICAgKiBAcGFyYW0gZGF0YSAtIEEgZGljdGlvbmFyeSBvZiBjb25zdGFudHMgdG8gc2V0IG9uIHRoZSBzaGFkZXIuXG4gICAqIEtleXMgc2hvdWxkIG1hdGNoIHRoZSBjb25zdGFudCBuYW1lcyBpbiB0aGUgV0dTTCBzaGFkZXIuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihkYXRhKSB7XG4gICAgdGhpcy5kYXRhID0geyAuLi5kYXRhIH07XG4gICAgY29uc3Qga2V5ID0gT2JqZWN0LmtleXMoZGF0YSkuc29ydCgpLm1hcCgoaykgPT4gYCR7a306JHtkYXRhW2tdfWApLmpvaW4oXCJ8XCIpO1xuICAgIHRoaXMuaWQgPSBjcmVhdGVJZEZyb21TdHJpbmcoa2V5LCBcInNoYWRlci1vdmVycmlkZXNcIik7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBTaGFkZXJPdmVycmlkZXMgaW5zdGFuY2UgZnJvbSBhIHBsYWluIG9iamVjdCBvciBleGlzdGluZyBpbnN0YW5jZS5cbiAgICogQHBhcmFtIG92ZXJyaWRlcyAtIFRoZSBvdmVycmlkZXMgdG8gY29udmVydC5cbiAgICogQHJldHVybnMgQSBTaGFkZXJPdmVycmlkZXMgaW5zdGFuY2UuXG4gICAqL1xuICBzdGF0aWMgZnJvbShvdmVycmlkZXMpIHtcbiAgICBpZiAob3ZlcnJpZGVzIGluc3RhbmNlb2YgU2hhZGVyT3ZlcnJpZGVzKSB7XG4gICAgICByZXR1cm4gb3ZlcnJpZGVzO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IFNoYWRlck92ZXJyaWRlcyhvdmVycmlkZXMpO1xuICB9XG59XG5cbmV4cG9ydCB7IFNoYWRlck92ZXJyaWRlcyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9U2hhZGVyT3ZlcnJpZGVzLm1qcy5tYXBcbiIsImltcG9ydCBFdmVudEVtaXR0ZXIgZnJvbSAnZXZlbnRlbWl0dGVyMyc7XG5pbXBvcnQgeyB1aWQgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9kYXRhL3VpZC5tanMnO1xuaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2xvZ2dpbmcvd2Fybi5tanMnO1xuaW1wb3J0IHsgR2xQcm9ncmFtIH0gZnJvbSAnLi4vLi4vZ2wvc2hhZGVyL0dsUHJvZ3JhbS5tanMnO1xuaW1wb3J0IHsgQmluZEdyb3VwIH0gZnJvbSAnLi4vLi4vZ3B1L3NoYWRlci9CaW5kR3JvdXAubWpzJztcbmltcG9ydCB7IEdwdVByb2dyYW0gfSBmcm9tICcuLi8uLi9ncHUvc2hhZGVyL0dwdVByb2dyYW0ubWpzJztcbmltcG9ydCB7IFJlbmRlcmVyVHlwZSB9IGZyb20gJy4uLy4uL3R5cGVzLm1qcyc7XG5pbXBvcnQgeyBTaGFkZXJPdmVycmlkZXMgfSBmcm9tICcuL1NoYWRlck92ZXJyaWRlcy5tanMnO1xuaW1wb3J0IHsgVW5pZm9ybUdyb3VwIH0gZnJvbSAnLi9Vbmlmb3JtR3JvdXAubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBTaGFkZXIgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgc3VwZXIoKTtcbiAgICAvKiogQSB1bmlxdWUgaWRlbnRpZmllciBmb3IgdGhlIHNoYWRlciAqL1xuICAgIHRoaXMudWlkID0gdWlkKFwic2hhZGVyXCIpO1xuICAgIC8qKlxuICAgICAqIEEgcmVjb3JkIG9mIHRoZSB1bmlmb3JtIGdyb3VwcyBhbmQgcmVzb3VyY2VzIHVzZWQgYnkgdGhlIHNoYWRlci5cbiAgICAgKiBUaGlzIGlzIHVzZWQgYnkgV2ViR0wgcmVuZGVyZXIgdG8gc3luYyB1bmlmb3JtIGRhdGEuXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fdW5pZm9ybUJpbmRNYXAgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB0aGlzLl9vd25lZEJpbmRHcm91cHMgPSBbXTtcbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy5fZGVzdHJveWVkID0gZmFsc2U7XG4gICAgbGV0IHtcbiAgICAgIGdwdVByb2dyYW0sXG4gICAgICBnbFByb2dyYW0sXG4gICAgICBncm91cHMsXG4gICAgICByZXNvdXJjZXMsXG4gICAgICBjb21wYXRpYmxlUmVuZGVyZXJzLFxuICAgICAgZ3JvdXBNYXAsXG4gICAgICBvdmVycmlkZXNcbiAgICB9ID0gb3B0aW9ucztcbiAgICB0aGlzLl9vdmVycmlkZXMgPSBvdmVycmlkZXMgPyBTaGFkZXJPdmVycmlkZXMuZnJvbShvdmVycmlkZXMpIDogbnVsbDtcbiAgICB0aGlzLmdwdVByb2dyYW0gPSBncHVQcm9ncmFtO1xuICAgIHRoaXMuZ2xQcm9ncmFtID0gZ2xQcm9ncmFtO1xuICAgIGlmIChjb21wYXRpYmxlUmVuZGVyZXJzID09PSB2b2lkIDApIHtcbiAgICAgIGNvbXBhdGlibGVSZW5kZXJlcnMgPSAwO1xuICAgICAgaWYgKGdwdVByb2dyYW0pIGNvbXBhdGlibGVSZW5kZXJlcnMgfD0gUmVuZGVyZXJUeXBlLldFQkdQVTtcbiAgICAgIGlmIChnbFByb2dyYW0pIGNvbXBhdGlibGVSZW5kZXJlcnMgfD0gUmVuZGVyZXJUeXBlLldFQkdMO1xuICAgIH1cbiAgICB0aGlzLmNvbXBhdGlibGVSZW5kZXJlcnMgPSBjb21wYXRpYmxlUmVuZGVyZXJzO1xuICAgIGNvbnN0IG5hbWVIYXNoID0ge307XG4gICAgaWYgKGdyb3VwTWFwKSB7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZ3JvdXBNYXApIHtcbiAgICAgICAgZm9yIChjb25zdCBqIGluIGdyb3VwTWFwW2ldKSB7XG4gICAgICAgICAgY29uc3QgdW5pZm9ybU5hbWUgPSBncm91cE1hcFtpXVtqXTtcbiAgICAgICAgICBuYW1lSGFzaFt1bmlmb3JtTmFtZV0gPSB7XG4gICAgICAgICAgICBncm91cDogaSxcbiAgICAgICAgICAgIGJpbmRpbmc6IGosXG4gICAgICAgICAgICBuYW1lOiB1bmlmb3JtTmFtZVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFyZXNvdXJjZXMgJiYgIWdyb3Vwcykge1xuICAgICAgcmVzb3VyY2VzID0ge307XG4gICAgfVxuICAgIGlmIChyZXNvdXJjZXMgJiYgZ3JvdXBzKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJbU2hhZGVyXSBDYW5ub3QgaGF2ZSBib3RoIHJlc291cmNlcyBhbmQgZ3JvdXBzXCIpO1xuICAgIH0gZWxzZSBpZiAoIWdwdVByb2dyYW0gJiYgZ3JvdXBzICYmICFncm91cE1hcCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiW1NoYWRlcl0gTm8gZ3JvdXAgbWFwIG9yIFdlYkdQVSBzaGFkZXIgcHJvdmlkZWQgLSBjb25zaWRlciB1c2luZyByZXNvdXJjZXMgaW5zdGVhZC5cIik7XG4gICAgfSBlbHNlIGlmIChncHVQcm9ncmFtICYmIGdyb3VwcyAmJiAhZ3JvdXBNYXApIHtcbiAgICAgIGNvbnN0IGdyb3VwRGF0YSA9IGdwdVByb2dyYW0uc3RydWN0c0FuZEdyb3Vwcy5ncm91cHM7XG4gICAgICBncm91cE1hcCA9IHt9O1xuICAgICAgZ3JvdXBEYXRhLmZvckVhY2goKGRhdGEpID0+IHtcbiAgICAgICAgZ3JvdXBNYXBbZGF0YS5ncm91cF0gPSBncm91cE1hcFtkYXRhLmdyb3VwXSB8fCB7fTtcbiAgICAgICAgZ3JvdXBNYXBbZGF0YS5ncm91cF1bZGF0YS5iaW5kaW5nXSA9IGRhdGEubmFtZTtcbiAgICAgICAgbmFtZUhhc2hbZGF0YS5uYW1lXSA9IGRhdGE7XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHJlc291cmNlcykge1xuICAgICAgZ3JvdXBzID0ge307XG4gICAgICBncm91cE1hcCB8fCAoZ3JvdXBNYXAgPSB7fSk7XG4gICAgICBpZiAoZ3B1UHJvZ3JhbSkge1xuICAgICAgICBjb25zdCBncm91cERhdGEgPSBncHVQcm9ncmFtLnN0cnVjdHNBbmRHcm91cHMuZ3JvdXBzO1xuICAgICAgICBncm91cERhdGEuZm9yRWFjaCgoZGF0YSkgPT4ge1xuICAgICAgICAgIGdyb3VwTWFwW2RhdGEuZ3JvdXBdID0gZ3JvdXBNYXBbZGF0YS5ncm91cF0gfHwge307XG4gICAgICAgICAgZ3JvdXBNYXBbZGF0YS5ncm91cF1bZGF0YS5iaW5kaW5nXSA9IGRhdGEubmFtZTtcbiAgICAgICAgICBuYW1lSGFzaFtkYXRhLm5hbWVdID0gZGF0YTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBsZXQgYmluZFRpY2sgPSAwO1xuICAgICAgZm9yIChjb25zdCBpIGluIHJlc291cmNlcykge1xuICAgICAgICBpZiAobmFtZUhhc2hbaV0pIGNvbnRpbnVlO1xuICAgICAgICBpZiAoZ3B1UHJvZ3JhbSAmJiAhZ2xQcm9ncmFtKSB7XG4gICAgICAgICAgd2FybihgW1NoYWRlcl0gdGhlIHJlc291cmNlICcke2l9JyBtYXRjaGVzIG5vIGJpbmRpbmcgaW4gdGhlIFdHU0wgc291cmNlIFxcdTIwMTQgaXMgdGhlIG5hbWUgY29ycmVjdD9gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWdyb3Vwc1s5OV0pIHtcbiAgICAgICAgICBncm91cHNbOTldID0gbmV3IEJpbmRHcm91cCgpO1xuICAgICAgICAgIHRoaXMuX293bmVkQmluZEdyb3Vwcy5wdXNoKGdyb3Vwc1s5OV0pO1xuICAgICAgICB9XG4gICAgICAgIG5hbWVIYXNoW2ldID0geyBncm91cDogOTksIGJpbmRpbmc6IGJpbmRUaWNrLCBuYW1lOiBpIH07XG4gICAgICAgIGdyb3VwTWFwWzk5XSA9IGdyb3VwTWFwWzk5XSB8fCB7fTtcbiAgICAgICAgZ3JvdXBNYXBbOTldW2JpbmRUaWNrXSA9IGk7XG4gICAgICAgIGJpbmRUaWNrKys7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gcmVzb3VyY2VzKSB7XG4gICAgICAgIGNvbnN0IG5hbWUgPSBpO1xuICAgICAgICBsZXQgdmFsdWUgPSByZXNvdXJjZXNbaV07XG4gICAgICAgIGlmICghdmFsdWUuc291cmNlICYmICF2YWx1ZS5fcmVzb3VyY2VUeXBlKSB7XG4gICAgICAgICAgdmFsdWUgPSBuZXcgVW5pZm9ybUdyb3VwKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkYXRhID0gbmFtZUhhc2hbbmFtZV07XG4gICAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgICAgaWYgKCFncm91cHNbZGF0YS5ncm91cF0pIHtcbiAgICAgICAgICAgIGdyb3Vwc1tkYXRhLmdyb3VwXSA9IG5ldyBCaW5kR3JvdXAoKTtcbiAgICAgICAgICAgIHRoaXMuX293bmVkQmluZEdyb3Vwcy5wdXNoKGdyb3Vwc1tkYXRhLmdyb3VwXSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGdyb3Vwc1tkYXRhLmdyb3VwXS5zZXRSZXNvdXJjZSh2YWx1ZSwgZGF0YS5iaW5kaW5nKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLmdyb3VwcyA9IGdyb3VwcztcbiAgICB0aGlzLl91bmlmb3JtQmluZE1hcCA9IGdyb3VwTWFwO1xuICAgIHRoaXMucmVzb3VyY2VzID0gdGhpcy5fYnVpbGRSZXNvdXJjZUFjY2Vzc29yKGdyb3VwcywgbmFtZUhhc2gpO1xuICB9XG4gIC8qKlxuICAgKiBTb21ldGltZXMgYSByZXNvdXJjZSBncm91cCB3aWxsIGJlIHByb3ZpZGVkIGxhdGVyIChmb3IgZXhhbXBsZSBnbG9iYWwgdW5pZm9ybXMpXG4gICAqIEluIHN1Y2ggY2FzZXMsIHRoaXMgbWV0aG9kIGNhbiBiZSB1c2VkIHRvIGxldCB0aGUgc2hhZGVyIGtub3cgYWJvdXQgdGhlIGdyb3VwLlxuICAgKiBAcGFyYW0gbmFtZSAtIHRoZSBuYW1lIG9mIHRoZSByZXNvdXJjZSBncm91cFxuICAgKiBAcGFyYW0gZ3JvdXBJbmRleCAtIHRoZSBpbmRleCBvZiB0aGUgZ3JvdXAgKHNob3VsZCBtYXRjaCB0aGUgd2ViR1BVIHNoYWRlciBncm91cCBsb2NhdGlvbilcbiAgICogQHBhcmFtIGJpbmRJbmRleCAtIHRoZSBpbmRleCBvZiB0aGUgYmluZCBwb2ludCAoc2hvdWxkIG1hdGNoIHRoZSB3ZWJHUFUgc2hhZGVyIGJpbmQgcG9pbnQpXG4gICAqL1xuICBhZGRSZXNvdXJjZShuYW1lLCBncm91cEluZGV4LCBiaW5kSW5kZXgpIHtcbiAgICB2YXIgX2EsIF9iO1xuICAgIChfYSA9IHRoaXMuX3VuaWZvcm1CaW5kTWFwKVtncm91cEluZGV4XSB8fCAoX2FbZ3JvdXBJbmRleF0gPSB7fSk7XG4gICAgKF9iID0gdGhpcy5fdW5pZm9ybUJpbmRNYXBbZ3JvdXBJbmRleF0pW2JpbmRJbmRleF0gfHwgKF9iW2JpbmRJbmRleF0gPSBuYW1lKTtcbiAgICBpZiAoIXRoaXMuZ3JvdXBzW2dyb3VwSW5kZXhdKSB7XG4gICAgICB0aGlzLmdyb3Vwc1tncm91cEluZGV4XSA9IG5ldyBCaW5kR3JvdXAoKTtcbiAgICAgIHRoaXMuX293bmVkQmluZEdyb3Vwcy5wdXNoKHRoaXMuZ3JvdXBzW2dyb3VwSW5kZXhdKTtcbiAgICB9XG4gIH1cbiAgX2J1aWxkUmVzb3VyY2VBY2Nlc3Nvcihncm91cHMsIG5hbWVIYXNoKSB7XG4gICAgY29uc3QgdW5pZm9ybXNPdXQgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGkgaW4gbmFtZUhhc2gpIHtcbiAgICAgIGNvbnN0IGRhdGEgPSBuYW1lSGFzaFtpXTtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh1bmlmb3Jtc091dCwgZGF0YS5uYW1lLCB7XG4gICAgICAgIGdldCgpIHtcbiAgICAgICAgICByZXR1cm4gZ3JvdXBzW2RhdGEuZ3JvdXBdLmdldFJlc291cmNlKGRhdGEuYmluZGluZyk7XG4gICAgICAgIH0sXG4gICAgICAgIHNldCh2YWx1ZSkge1xuICAgICAgICAgIGdyb3Vwc1tkYXRhLmdyb3VwXS5zZXRSZXNvdXJjZSh2YWx1ZSwgZGF0YS5iaW5kaW5nKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiB1bmlmb3Jtc091dDtcbiAgfVxuICAvKipcbiAgICogVXNlIHRvIGRlc3Ryb3kgdGhlIHNoYWRlciB3aGVuIGl0cyBub3QgbG9uZ2VyIG5lZWRlZC5cbiAgICogSXQgd2lsbCBkZXN0cm95IHRoZSByZXNvdXJjZXMgYW5kIHJlbW92ZSBsaXN0ZW5lcnMuXG4gICAqIEBwYXJhbSBkZXN0cm95UHJvZ3JhbXMgLSBpZiB0aGUgcHJvZ3JhbXMgc2hvdWxkIGJlIGRlc3Ryb3llZCBhcyB3ZWxsLlxuICAgKiBNYWtlIHN1cmUgaXRzIG5vdCBiZWluZyB1c2VkIGJ5IG90aGVyIHNoYWRlcnMhXG4gICAqL1xuICBkZXN0cm95KGRlc3Ryb3lQcm9ncmFtcyA9IGZhbHNlKSB7XG4gICAgaWYgKHRoaXMuX2Rlc3Ryb3llZCkgcmV0dXJuO1xuICAgIHRoaXMuX2Rlc3Ryb3llZCA9IHRydWU7XG4gICAgdGhpcy5lbWl0KFwiZGVzdHJveVwiLCB0aGlzKTtcbiAgICBpZiAoZGVzdHJveVByb2dyYW1zKSB7XG4gICAgICB0aGlzLmdwdVByb2dyYW0/LmRlc3Ryb3koKTtcbiAgICAgIHRoaXMuZ2xQcm9ncmFtPy5kZXN0cm95KCk7XG4gICAgfVxuICAgIHRoaXMuZ3B1UHJvZ3JhbSA9IG51bGw7XG4gICAgdGhpcy5nbFByb2dyYW0gPSBudWxsO1xuICAgIHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCk7XG4gICAgdGhpcy5fdW5pZm9ybUJpbmRNYXAgPSBudWxsO1xuICAgIHRoaXMuX293bmVkQmluZEdyb3Vwcy5mb3JFYWNoKChiaW5kR3JvdXApID0+IHtcbiAgICAgIGJpbmRHcm91cC5kZXN0cm95KCk7XG4gICAgfSk7XG4gICAgdGhpcy5fb3duZWRCaW5kR3JvdXBzID0gbnVsbDtcbiAgICB0aGlzLnJlc291cmNlcyA9IG51bGw7XG4gICAgdGhpcy5ncm91cHMgPSBudWxsO1xuICAgIHRoaXMuX292ZXJyaWRlcyA9IG51bGw7XG4gIH1cbiAgc3RhdGljIGZyb20ob3B0aW9ucykge1xuICAgIGNvbnN0IHsgZ3B1LCBnbCwgLi4ucmVzdCB9ID0gb3B0aW9ucztcbiAgICBsZXQgZ3B1UHJvZ3JhbTtcbiAgICBsZXQgZ2xQcm9ncmFtO1xuICAgIGlmIChncHUpIHtcbiAgICAgIGdwdVByb2dyYW0gPSBHcHVQcm9ncmFtLmZyb20oZ3B1KTtcbiAgICB9XG4gICAgaWYgKGdsKSB7XG4gICAgICBnbFByb2dyYW0gPSBHbFByb2dyYW0uZnJvbShnbCk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgU2hhZGVyKHtcbiAgICAgIGdwdVByb2dyYW0sXG4gICAgICBnbFByb2dyYW0sXG4gICAgICAuLi5yZXN0XG4gICAgfSk7XG4gIH1cbn1cblxuZXhwb3J0IHsgU2hhZGVyIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1TaGFkZXIubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgQnVmZmVyVXNhZ2UgPSAvKiBAX19QVVJFX18gKi8gKChCdWZmZXJVc2FnZTIpID0+IHtcbiAgQnVmZmVyVXNhZ2UyW0J1ZmZlclVzYWdlMltcIk1BUF9SRUFEXCJdID0gMV0gPSBcIk1BUF9SRUFEXCI7XG4gIEJ1ZmZlclVzYWdlMltCdWZmZXJVc2FnZTJbXCJNQVBfV1JJVEVcIl0gPSAyXSA9IFwiTUFQX1dSSVRFXCI7XG4gIEJ1ZmZlclVzYWdlMltCdWZmZXJVc2FnZTJbXCJDT1BZX1NSQ1wiXSA9IDRdID0gXCJDT1BZX1NSQ1wiO1xuICBCdWZmZXJVc2FnZTJbQnVmZmVyVXNhZ2UyW1wiQ09QWV9EU1RcIl0gPSA4XSA9IFwiQ09QWV9EU1RcIjtcbiAgQnVmZmVyVXNhZ2UyW0J1ZmZlclVzYWdlMltcIklOREVYXCJdID0gMTZdID0gXCJJTkRFWFwiO1xuICBCdWZmZXJVc2FnZTJbQnVmZmVyVXNhZ2UyW1wiVkVSVEVYXCJdID0gMzJdID0gXCJWRVJURVhcIjtcbiAgQnVmZmVyVXNhZ2UyW0J1ZmZlclVzYWdlMltcIlVOSUZPUk1cIl0gPSA2NF0gPSBcIlVOSUZPUk1cIjtcbiAgQnVmZmVyVXNhZ2UyW0J1ZmZlclVzYWdlMltcIlNUT1JBR0VcIl0gPSAxMjhdID0gXCJTVE9SQUdFXCI7XG4gIEJ1ZmZlclVzYWdlMltCdWZmZXJVc2FnZTJbXCJJTkRJUkVDVFwiXSA9IDI1Nl0gPSBcIklORElSRUNUXCI7XG4gIEJ1ZmZlclVzYWdlMltCdWZmZXJVc2FnZTJbXCJRVUVSWV9SRVNPTFZFXCJdID0gNTEyXSA9IFwiUVVFUllfUkVTT0xWRVwiO1xuICBCdWZmZXJVc2FnZTJbQnVmZmVyVXNhZ2UyW1wiU1RBVElDXCJdID0gMTAyNF0gPSBcIlNUQVRJQ1wiO1xuICByZXR1cm4gQnVmZmVyVXNhZ2UyO1xufSkoQnVmZmVyVXNhZ2UgfHwge30pO1xuXG5leHBvcnQgeyBCdWZmZXJVc2FnZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29uc3QubWpzLm1hcFxuIiwiaW1wb3J0IEV2ZW50RW1pdHRlciBmcm9tICdldmVudGVtaXR0ZXIzJztcbmltcG9ydCB7IHVpZCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGEvdWlkLm1qcyc7XG5pbXBvcnQgeyBCdWZmZXJVc2FnZSB9IGZyb20gJy4vY29uc3QubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBCdWZmZXIgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBCdWZmZXIgd2l0aCB0aGUgZ2l2ZW4gb3B0aW9uc1xuICAgKiBAcGFyYW0gb3B0aW9ucyAtIHRoZSBvcHRpb25zIGZvciB0aGUgYnVmZmVyXG4gICAqL1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgbGV0IHsgZGF0YSwgc2l6ZSB9ID0gb3B0aW9ucztcbiAgICBjb25zdCB7IHVzYWdlLCBsYWJlbCwgc2hyaW5rVG9GaXQgfSA9IG9wdGlvbnM7XG4gICAgc3VwZXIoKTtcbiAgICAvKipcbiAgICAgKiBlbWl0cyB3aGVuIHRoZSB1bmRlcmx5aW5nIGJ1ZmZlciBoYXMgY2hhbmdlZCBzaGFwZSAoaS5lLiByZXNpemVkKSBvciBiZWVuIHVubG9hZGVkLFxuICAgICAqIGxldHRpbmcgdGhlIHJlbmRlcmVyIGtub3cgdGhhdCBpdCBuZWVkcyB0byBkaXNjYXJkIHRoZSBvbGQgYnVmZmVyIG9uIHRoZSBHUFUgYW5kIGNyZWF0ZSBhIG5ldyBvbmVcbiAgICAgKiBAZXZlbnQgY2hhbmdlXG4gICAgICovXG4gICAgLyoqXG4gICAgICogZW1pdHMgd2hlbiB0aGUgdW5kZXJseWluZyBidWZmZXIgZGF0YSBoYXMgYmVlbiB1cGRhdGVkLiBsZXR0aW5nIHRoZSByZW5kZXJlciBrbm93XG4gICAgICogdGhhdCBpdCBuZWVkcyB0byB1cGRhdGUgdGhlIGJ1ZmZlciBvbiB0aGUgR1BVXG4gICAgICogQGV2ZW50IHVwZGF0ZVxuICAgICAqL1xuICAgIC8qKlxuICAgICAqIGVtaXRzIHdoZW4gdGhlIGJ1ZmZlciBpcyBkZXN0cm95ZWQuIGxldHRpbmcgdGhlIHJlbmRlcmVyIGtub3cgdGhhdCBpdCBuZWVkcyB0byBkZXN0cm95IHRoZSBidWZmZXIgb24gdGhlIEdQVVxuICAgICAqIEBldmVudCBkZXN0cm95XG4gICAgICovXG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuX2dwdURhdGEgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy5fZ2NMYXN0VXNlZCA9IC0xO1xuICAgIC8qKiBJZiBzZXQgdG8gdHJ1ZSwgdGhlIGJ1ZmZlciB3aWxsIGJlIGdhcmJhZ2UgY29sbGVjdGVkIGF1dG9tYXRpY2FsbHkgd2hlbiBpdCBpcyBub3QgdXNlZC4gKi9cbiAgICB0aGlzLmF1dG9HYXJiYWdlQ29sbGVjdCA9IHRydWU7XG4gICAgLyoqIGEgdW5pcXVlIGlkIGZvciB0aGlzIHVuaWZvcm0gZ3JvdXAgdXNlZCB0aHJvdWdoIHRoZSByZW5kZXJlciAqL1xuICAgIHRoaXMudWlkID0gdWlkKFwiYnVmZmVyXCIpO1xuICAgIC8qKlxuICAgICAqIGEgcmVzb3VyY2UgdHlwZSwgdXNlZCB0byBpZGVudGlmeSBob3cgdG8gaGFuZGxlIGl0IHdoZW4gaXRzIGluIGEgYmluZCBncm91cCAvIHNoYWRlciByZXNvdXJjZVxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX3Jlc291cmNlVHlwZSA9IFwiYnVmZmVyXCI7XG4gICAgLyoqXG4gICAgICogdGhlIHJlc291cmNlIGlkIHVzZWQgaW50ZXJuYWxseSBieSB0aGUgcmVuZGVyZXIgdG8gYnVpbGQgYmluZCBncm91cCBrZXlzXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fcmVzb3VyY2VJZCA9IHVpZChcInJlc291cmNlXCIpO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLl91cGRhdGVJRCA9IDE7XG4gICAgLyoqIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuX3VwZGF0ZU9mZnNldCA9IDA7XG4gICAgdGhpcy5fZGF0YUludDMyID0gbnVsbDtcbiAgICAvKipcbiAgICAgKiBzaG91bGQgdGhlIEdQVSBidWZmZXIgYmUgc2hydW5rIHdoZW4gdGhlIGRhdGEgYmVjb21lcyBzbWFsbGVyP1xuICAgICAqIGNoYW5naW5nIHRoaXMgd2lsbCBjYXVzZSB0aGUgYnVmZmVyIHRvIGJlIGRlc3Ryb3llZCBhbmQgYSBuZXcgb25lIGNyZWF0ZWQgb24gdGhlIEdQVVxuICAgICAqIHRoaXMgY2FuIGJlIGV4cGVuc2l2ZSwgZXNwZWNpYWxseSBpZiB0aGUgYnVmZmVyIGlzIGFscmVhZHkgYmlnIGVub3VnaCFcbiAgICAgKiBzZXR0aW5nIHRoaXMgdG8gZmFsc2Ugd2lsbCBwcmV2ZW50IHRoZSBidWZmZXIgZnJvbSBiZWluZyBzaHJ1bmsuIFRoaXMgd2lsbCB5aWVsZCBiZXR0ZXIgcGVyZm9ybWFuY2VcbiAgICAgKiBpZiB5b3UgYXJlIGNvbnN0YW50bHkgc2V0dGluZyBkYXRhIHRoYXQgaXMgY2hhbmdpbmcgc2l6ZSBvZnRlbi5cbiAgICAgKiBAZGVmYXVsdCB0cnVlXG4gICAgICovXG4gICAgdGhpcy5zaHJpbmtUb0ZpdCA9IHRydWU7XG4gICAgLyoqXG4gICAgICogSGFzIHRoZSBidWZmZXIgYmVlbiBkZXN0cm95ZWQ/XG4gICAgICogQHJlYWRvbmx5XG4gICAgICovXG4gICAgdGhpcy5kZXN0cm95ZWQgPSBmYWxzZTtcbiAgICBpZiAoZGF0YSBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICBkYXRhID0gbmV3IEZsb2F0MzJBcnJheShkYXRhKTtcbiAgICB9XG4gICAgdGhpcy5fZGF0YSA9IGRhdGE7XG4gICAgc2l6ZSA/PyAoc2l6ZSA9IGRhdGE/LmJ5dGVMZW5ndGgpO1xuICAgIGNvbnN0IG1hcHBlZEF0Q3JlYXRpb24gPSAhIWRhdGE7XG4gICAgdGhpcy5kZXNjcmlwdG9yID0ge1xuICAgICAgc2l6ZSxcbiAgICAgIHVzYWdlLFxuICAgICAgbWFwcGVkQXRDcmVhdGlvbixcbiAgICAgIGxhYmVsXG4gICAgfTtcbiAgICB0aGlzLnNocmlua1RvRml0ID0gc2hyaW5rVG9GaXQgPz8gdHJ1ZTtcbiAgfVxuICAvKiogdGhlIGRhdGEgaW4gdGhlIGJ1ZmZlciAqL1xuICBnZXQgZGF0YSgpIHtcbiAgICByZXR1cm4gdGhpcy5fZGF0YTtcbiAgfVxuICBzZXQgZGF0YSh2YWx1ZSkge1xuICAgIHRoaXMuc2V0RGF0YVdpdGhTaXplKHZhbHVlLCB2YWx1ZS5sZW5ndGgsIHRydWUpO1xuICB9XG4gIGdldCBkYXRhSW50MzIoKSB7XG4gICAgaWYgKCF0aGlzLl9kYXRhSW50MzIpIHtcbiAgICAgIHRoaXMuX2RhdGFJbnQzMiA9IG5ldyBJbnQzMkFycmF5KHRoaXMuZGF0YS5idWZmZXIpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fZGF0YUludDMyO1xuICB9XG4gIC8qKiB3aGV0aGVyIHRoZSBidWZmZXIgaXMgc3RhdGljIG9yIG5vdCAqL1xuICBnZXQgc3RhdGljKCkge1xuICAgIHJldHVybiAhISh0aGlzLmRlc2NyaXB0b3IudXNhZ2UgJiBCdWZmZXJVc2FnZS5TVEFUSUMpO1xuICB9XG4gIHNldCBzdGF0aWModmFsdWUpIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHRoaXMuZGVzY3JpcHRvci51c2FnZSB8PSBCdWZmZXJVc2FnZS5TVEFUSUM7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuZGVzY3JpcHRvci51c2FnZSAmPSB+QnVmZmVyVXNhZ2UuU1RBVElDO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogU2V0cyB0aGUgZGF0YSBpbiB0aGUgYnVmZmVyIHRvIHRoZSBnaXZlbiB2YWx1ZS4gVGhpcyB3aWxsIGltbWVkaWF0ZWx5IHVwZGF0ZSB0aGUgYnVmZmVyIG9uIHRoZSBHUFUuXG4gICAqIElmIHlvdSBvbmx5IHdhbnQgdG8gdXBkYXRlIGEgc3Vic2V0IG9mIHRoZSBidWZmZXIsIHlvdSBjYW4gcGFzcyBpbiB0aGUgc2l6ZSBvZiB0aGUgZGF0YS5cbiAgICogQHBhcmFtIHZhbHVlIC0gdGhlIGRhdGEgdG8gc2V0XG4gICAqIEBwYXJhbSBzaXplIC0gdGhlIHNpemUgb2YgdGhlIGRhdGEgaW4gYnl0ZXNcbiAgICogQHBhcmFtIHN5bmNHUFUgLSBzaG91bGQgdGhlIGJ1ZmZlciBiZSB1cGRhdGVkIG9uIHRoZSBHUFUgaW1tZWRpYXRlbHk/XG4gICAqL1xuICBzZXREYXRhV2l0aFNpemUodmFsdWUsIHNpemUsIHN5bmNHUFUpIHtcbiAgICB0aGlzLl91cGRhdGVJRCsrO1xuICAgIHRoaXMuX3VwZGF0ZVNpemUgPSBzaXplICogdmFsdWUuQllURVNfUEVSX0VMRU1FTlQ7XG4gICAgdGhpcy5fdXBkYXRlT2Zmc2V0ID0gMDtcbiAgICBpZiAodGhpcy5fZGF0YSA9PT0gdmFsdWUpIHtcbiAgICAgIGlmIChzeW5jR1BVKSB0aGlzLmVtaXQoXCJ1cGRhdGVcIiwgdGhpcyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG9sZERhdGEgPSB0aGlzLl9kYXRhO1xuICAgIHRoaXMuX2RhdGEgPSB2YWx1ZTtcbiAgICB0aGlzLl9kYXRhSW50MzIgPSBudWxsO1xuICAgIGlmICghb2xkRGF0YSB8fCBvbGREYXRhLmxlbmd0aCAhPT0gdmFsdWUubGVuZ3RoKSB7XG4gICAgICBpZiAoIXRoaXMuc2hyaW5rVG9GaXQgJiYgb2xkRGF0YSAmJiB2YWx1ZS5ieXRlTGVuZ3RoIDwgb2xkRGF0YS5ieXRlTGVuZ3RoKSB7XG4gICAgICAgIGlmIChzeW5jR1BVKSB0aGlzLmVtaXQoXCJ1cGRhdGVcIiwgdGhpcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmRlc2NyaXB0b3Iuc2l6ZSA9IHZhbHVlLmJ5dGVMZW5ndGg7XG4gICAgICAgIHRoaXMuX3Jlc291cmNlSWQgPSB1aWQoXCJyZXNvdXJjZVwiKTtcbiAgICAgICAgdGhpcy5lbWl0KFwiY2hhbmdlXCIsIHRoaXMpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoc3luY0dQVSkgdGhpcy5lbWl0KFwidXBkYXRlXCIsIHRoaXMpO1xuICB9XG4gIC8qKlxuICAgKiB1cGRhdGVzIHRoZSBidWZmZXIgb24gdGhlIEdQVSB0byByZWZsZWN0IHRoZSBkYXRhIGluIHRoZSBidWZmZXIuXG4gICAqIEJ5IGRlZmF1bHQgaXQgd2lsbCB1cGRhdGUgdGhlIGVudGlyZSBidWZmZXIuIElmIHlvdSBvbmx5IHdhbnQgdG8gdXBkYXRlIGEgc3Vic2V0IG9mIHRoZSBidWZmZXIsXG4gICAqIHlvdSBjYW4gcGFzcyBpbiB0aGUgc2l6ZSBvZiB0aGUgYnVmZmVyIHRvIHVwZGF0ZS5cbiAgICogQHBhcmFtIHNpemVJbkJ5dGVzIC0gdGhlIG5ldyBzaXplIG9mIHRoZSBidWZmZXIgaW4gYnl0ZXNcbiAgICogQHBhcmFtIG9mZnNldEluQnl0ZXMgLSB0aGUgb2Zmc2V0IHRvIHN0YXJ0IHVwZGF0aW5nIGZyb21cbiAgICovXG4gIHVwZGF0ZShzaXplSW5CeXRlcywgb2Zmc2V0SW5CeXRlcykge1xuICAgIHRoaXMuX3VwZGF0ZVNpemUgPSBzaXplSW5CeXRlcyA/PyB0aGlzLl91cGRhdGVTaXplO1xuICAgIHRoaXMuX3VwZGF0ZU9mZnNldCA9IG9mZnNldEluQnl0ZXMgfHwgMDtcbiAgICB0aGlzLl91cGRhdGVJRCsrO1xuICAgIHRoaXMuZW1pdChcInVwZGF0ZVwiLCB0aGlzKTtcbiAgfVxuICAvKiogVW5sb2FkcyB0aGUgYnVmZmVyIGZyb20gdGhlIEdQVSAqL1xuICB1bmxvYWQoKSB7XG4gICAgdGhpcy5lbWl0KFwidW5sb2FkXCIsIHRoaXMpO1xuICAgIGZvciAoY29uc3Qga2V5IGluIHRoaXMuX2dwdURhdGEpIHtcbiAgICAgIHRoaXMuX2dwdURhdGFba2V5XT8uZGVzdHJveSgpO1xuICAgIH1cbiAgICB0aGlzLl9ncHVEYXRhID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgaWYgKCF0aGlzLmRlc3Ryb3llZCkge1xuICAgICAgdGhpcy5fcmVzb3VyY2VJZCA9IHVpZChcInJlc291cmNlXCIpO1xuICAgICAgdGhpcy5lbWl0KFwiY2hhbmdlXCIsIHRoaXMpO1xuICAgIH1cbiAgfVxuICAvKiogRGVzdHJveXMgdGhlIGJ1ZmZlciAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMuZGVzdHJveWVkID0gdHJ1ZTtcbiAgICB0aGlzLnVubG9hZCgpO1xuICAgIHRoaXMuZW1pdChcImRlc3Ryb3lcIiwgdGhpcyk7XG4gICAgdGhpcy5lbWl0KFwiY2hhbmdlXCIsIHRoaXMpO1xuICAgIHRoaXMuX2RhdGEgPSBudWxsO1xuICAgIHRoaXMuZGVzY3JpcHRvciA9IG51bGw7XG4gICAgdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcbiAgfVxufVxuXG5leHBvcnQgeyBCdWZmZXIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUJ1ZmZlci5tanMubWFwXG4iLCJpbXBvcnQgeyBCdWZmZXIgfSBmcm9tICcuLi8uLi9idWZmZXIvQnVmZmVyLm1qcyc7XG5pbXBvcnQgeyBCdWZmZXJVc2FnZSB9IGZyb20gJy4uLy4uL2J1ZmZlci9jb25zdC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGVuc3VyZUlzQnVmZmVyKGJ1ZmZlciwgaW5kZXgpIHtcbiAgaWYgKCEoYnVmZmVyIGluc3RhbmNlb2YgQnVmZmVyKSkge1xuICAgIGxldCB1c2FnZSA9IGluZGV4ID8gQnVmZmVyVXNhZ2UuSU5ERVggOiBCdWZmZXJVc2FnZS5WRVJURVg7XG4gICAgaWYgKGJ1ZmZlciBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICBpZiAoaW5kZXgpIHtcbiAgICAgICAgYnVmZmVyID0gbmV3IFVpbnQzMkFycmF5KGJ1ZmZlcik7XG4gICAgICAgIHVzYWdlID0gQnVmZmVyVXNhZ2UuSU5ERVggfCBCdWZmZXJVc2FnZS5DT1BZX0RTVDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGJ1ZmZlciA9IG5ldyBGbG9hdDMyQXJyYXkoYnVmZmVyKTtcbiAgICAgICAgdXNhZ2UgPSBCdWZmZXJVc2FnZS5WRVJURVggfCBCdWZmZXJVc2FnZS5DT1BZX0RTVDtcbiAgICAgIH1cbiAgICB9XG4gICAgYnVmZmVyID0gbmV3IEJ1ZmZlcih7XG4gICAgICBkYXRhOiBidWZmZXIsXG4gICAgICBsYWJlbDogaW5kZXggPyBcImluZGV4LW1lc2gtYnVmZmVyXCIgOiBcInZlcnRleC1tZXNoLWJ1ZmZlclwiLFxuICAgICAgdXNhZ2VcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gYnVmZmVyO1xufVxuXG5leHBvcnQgeyBlbnN1cmVJc0J1ZmZlciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZW5zdXJlSXNCdWZmZXIubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBnZXRHZW9tZXRyeUJvdW5kcyhnZW9tZXRyeSwgYXR0cmlidXRlSWQsIGJvdW5kcykge1xuICBjb25zdCBhdHRyaWJ1dGUgPSBnZW9tZXRyeS5nZXRBdHRyaWJ1dGUoYXR0cmlidXRlSWQpO1xuICBpZiAoIWF0dHJpYnV0ZSkge1xuICAgIGJvdW5kcy5taW5YID0gMDtcbiAgICBib3VuZHMubWluWSA9IDA7XG4gICAgYm91bmRzLm1heFggPSAwO1xuICAgIGJvdW5kcy5tYXhZID0gMDtcbiAgICByZXR1cm4gYm91bmRzO1xuICB9XG4gIGNvbnN0IGRhdGEgPSBhdHRyaWJ1dGUuYnVmZmVyLmRhdGE7XG4gIGxldCBtaW5YID0gSW5maW5pdHk7XG4gIGxldCBtaW5ZID0gSW5maW5pdHk7XG4gIGxldCBtYXhYID0gLUluZmluaXR5O1xuICBsZXQgbWF4WSA9IC1JbmZpbml0eTtcbiAgY29uc3QgYnl0ZVNpemUgPSBkYXRhLkJZVEVTX1BFUl9FTEVNRU5UO1xuICBjb25zdCBvZmZzZXQgPSAoYXR0cmlidXRlLm9mZnNldCB8fCAwKSAvIGJ5dGVTaXplO1xuICBjb25zdCBzdHJpZGUgPSAoYXR0cmlidXRlLnN0cmlkZSB8fCAyICogNCkgLyBieXRlU2l6ZTtcbiAgZm9yIChsZXQgaSA9IG9mZnNldDsgaSA8IGRhdGEubGVuZ3RoOyBpICs9IHN0cmlkZSkge1xuICAgIGNvbnN0IHggPSBkYXRhW2ldO1xuICAgIGNvbnN0IHkgPSBkYXRhW2kgKyAxXTtcbiAgICBpZiAoeCA+IG1heFgpIG1heFggPSB4O1xuICAgIGlmICh5ID4gbWF4WSkgbWF4WSA9IHk7XG4gICAgaWYgKHggPCBtaW5YKSBtaW5YID0geDtcbiAgICBpZiAoeSA8IG1pblkpIG1pblkgPSB5O1xuICB9XG4gIGJvdW5kcy5taW5YID0gbWluWDtcbiAgYm91bmRzLm1pblkgPSBtaW5ZO1xuICBib3VuZHMubWF4WCA9IG1heFg7XG4gIGJvdW5kcy5tYXhZID0gbWF4WTtcbiAgcmV0dXJuIGJvdW5kcztcbn1cblxuZXhwb3J0IHsgZ2V0R2VvbWV0cnlCb3VuZHMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdldEdlb21ldHJ5Qm91bmRzLm1qcy5tYXBcbiIsImltcG9ydCBFdmVudEVtaXR0ZXIgZnJvbSAnZXZlbnRlbWl0dGVyMyc7XG5pbXBvcnQgeyBCb3VuZHMgfSBmcm9tICcuLi8uLi8uLi8uLi9zY2VuZS9jb250YWluZXIvYm91bmRzL0JvdW5kcy5tanMnO1xuaW1wb3J0IHsgdWlkIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvZGF0YS91aWQubWpzJztcbmltcG9ydCB7IGRlcHJlY2F0aW9uIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy9kZXByZWNhdGlvbi5tanMnO1xuaW1wb3J0IHsgQnVmZmVyIH0gZnJvbSAnLi4vYnVmZmVyL0J1ZmZlci5tanMnO1xuaW1wb3J0IHsgZW5zdXJlSXNCdWZmZXIgfSBmcm9tICcuL3V0aWxzL2Vuc3VyZUlzQnVmZmVyLm1qcyc7XG5pbXBvcnQgeyBnZXRHZW9tZXRyeUJvdW5kcyB9IGZyb20gJy4vdXRpbHMvZ2V0R2VvbWV0cnlCb3VuZHMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBlbnN1cmVJc0F0dHJpYnV0ZShhdHRyaWJ1dGUpIHtcbiAgaWYgKGF0dHJpYnV0ZSBpbnN0YW5jZW9mIEJ1ZmZlciB8fCBBcnJheS5pc0FycmF5KGF0dHJpYnV0ZSkgfHwgYXR0cmlidXRlLkJZVEVTX1BFUl9FTEVNRU5UKSB7XG4gICAgYXR0cmlidXRlID0ge1xuICAgICAgYnVmZmVyOiBhdHRyaWJ1dGVcbiAgICB9O1xuICB9XG4gIGF0dHJpYnV0ZS5idWZmZXIgPSBlbnN1cmVJc0J1ZmZlcihhdHRyaWJ1dGUuYnVmZmVyLCBmYWxzZSk7XG4gIHJldHVybiBhdHRyaWJ1dGU7XG59XG5jbGFzcyBHZW9tZXRyeSBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBuZXcgaW5zdGFuY2Ugb2YgYSBnZW9tZXRyeVxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvcHRpb25zIGZvciB0aGUgZ2VvbWV0cnkuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30pIHtcbiAgICBzdXBlcigpO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLl9ncHVEYXRhID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgLyoqIElmIHNldCB0byB0cnVlLCB0aGUgcmVzb3VyY2Ugd2lsbCBiZSBnYXJiYWdlIGNvbGxlY3RlZCBhdXRvbWF0aWNhbGx5IHdoZW4gaXQgaXMgbm90IHVzZWQuICovXG4gICAgdGhpcy5hdXRvR2FyYmFnZUNvbGxlY3QgPSB0cnVlO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLl9nY0xhc3RVc2VkID0gLTE7XG4gICAgLyoqIFRoZSB1bmlxdWUgaWQgb2YgdGhlIGdlb21ldHJ5LiAqL1xuICAgIHRoaXMudWlkID0gdWlkKFwiZ2VvbWV0cnlcIik7XG4gICAgLyoqXG4gICAgICogdGhlIGxheW91dCBrZXkgd2lsbCBiZSBnZW5lcmF0ZWQgYnkgV2ViR1BVIGFsbCBnZW9tZXRyaWVzIHRoYXQgaGF2ZSB0aGUgc2FtZSBzdHJ1Y3R1cmVcbiAgICAgKiB3aWxsIGhhdmUgdGhlIHNhbWUgbGF5b3V0IGtleS4gVGhpcyBpcyB1c2VkIHRvIGNhY2hlIHRoZSBwaXBlbGluZSBsYXlvdXRcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9sYXlvdXRLZXkgPSAwO1xuICAgIC8qKiB0aGUgaW5zdGFuY2UgY291bnQgb2YgdGhlIGdlb21ldHJ5IHRvIGRyYXcgKi9cbiAgICB0aGlzLmluc3RhbmNlQ291bnQgPSAxO1xuICAgIC8qKlxuICAgICAqIFRoZSBudW1iZXIgb2YgaW5kaWNlcyB0byBkcmF3LCBvciBgMGAgdG8gZHJhdyB0aGUgd2hvbGUgaW5kZXggYnVmZmVyLlxuICAgICAqXG4gICAgICogU2V0IHRoaXMgd2hlbiBhIGdlb21ldHJ5IG9ubHkgY292ZXJzIGEgcHJlZml4IG9mIGFuIGluZGV4IGJ1ZmZlciBpdCBzaGFyZXMgd2l0aCBvdGhlcnMgLSBhXG4gICAgICogcG9vbCBvZiBpZGVudGljYWwgcXVhZHMsIHNheSwgd2hlcmUgb25lIGJ1ZmZlciBob2xkcyB0aGUgc2l4IGluZGljZXMgcGVyIHF1YWQgZm9yIHRoZSBsYXJnZXN0XG4gICAgICogYmF0Y2ggYW5kIGVhY2ggZ2VvbWV0cnkgZHJhd3MgYXMgbWFueSBxdWFkcyBhcyBpdCBjdXJyZW50bHkgaG9sZHMuIEEgYHNpemVgIHBhc3NlZCB0byB0aGVcbiAgICAgKiBkcmF3IGNhbGwgc3RpbGwgd2lucywgYW5kIGEgZ2VvbWV0cnkgd2l0aCBubyBpbmRleCBidWZmZXIgaWdub3JlcyB0aGlzIGVudGlyZWx5XG4gICAgICogKHtAbGluayBHZW9tZXRyeS52ZXJ0ZXhDb3VudH0gZHJpdmVzIHRob3NlKS4gUmVhZCBhdCBkcmF3IHRpbWUgb25seSwgc28gY2hhbmdpbmcgaXQgbmV2ZXJcbiAgICAgKiByZS11cGxvYWRzIG9yIHJlLWxheXMtb3V0IGFueXRoaW5nLlxuICAgICAqIEBkZWZhdWx0IDBcbiAgICAgKi9cbiAgICB0aGlzLmluZGV4Q291bnQgPSAwO1xuICAgIHRoaXMuX2JvdW5kcyA9IG5ldyBCb3VuZHMoKTtcbiAgICB0aGlzLl9ib3VuZHNEaXJ0eSA9IHRydWU7XG4gICAgdGhpcy5fdmVydGV4Q291bnQgPSAwO1xuICAgIHRoaXMuX3ZlcnRleENvdW50RGlydHkgPSB0cnVlO1xuICAgIGNvbnN0IHsgYXR0cmlidXRlcywgaW5kZXhCdWZmZXIsIHRvcG9sb2d5IH0gPSBvcHRpb25zO1xuICAgIHRoaXMuYnVmZmVycyA9IFtdO1xuICAgIHRoaXMuYXR0cmlidXRlcyA9IHt9O1xuICAgIGlmIChhdHRyaWJ1dGVzKSB7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gYXR0cmlidXRlcykge1xuICAgICAgICB0aGlzLmFkZEF0dHJpYnV0ZShpLCBhdHRyaWJ1dGVzW2ldKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5pbnN0YW5jZUNvdW50ID0gb3B0aW9ucy5pbnN0YW5jZUNvdW50ID8/IDE7XG4gICAgdGhpcy5pbmRleENvdW50ID0gb3B0aW9ucy5pbmRleENvdW50ID8/IDA7XG4gICAgaWYgKGluZGV4QnVmZmVyKSB7XG4gICAgICB0aGlzLmFkZEluZGV4KGluZGV4QnVmZmVyKTtcbiAgICB9XG4gICAgdGhpcy50b3BvbG9neSA9IHRvcG9sb2d5IHx8IFwidHJpYW5nbGUtbGlzdFwiO1xuICB9XG4gIG9uQnVmZmVyVXBkYXRlKCkge1xuICAgIHRoaXMuX2JvdW5kc0RpcnR5ID0gdHJ1ZTtcbiAgICB0aGlzLl92ZXJ0ZXhDb3VudERpcnR5ID0gdHJ1ZTtcbiAgICB0aGlzLmVtaXQoXCJ1cGRhdGVcIiwgdGhpcyk7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHJlcXVlc3RlZCBhdHRyaWJ1dGUuXG4gICAqIEBwYXJhbSBpZCAtIFRoZSBuYW1lIG9mIHRoZSBhdHRyaWJ1dGUgcmVxdWlyZWRcbiAgICogQHJldHVybnMgLSBUaGUgYXR0cmlidXRlIHJlcXVlc3RlZC5cbiAgICovXG4gIGdldEF0dHJpYnV0ZShpZCkge1xuICAgIHJldHVybiB0aGlzLmF0dHJpYnV0ZXNbaWRdO1xuICB9XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBpbmRleCBidWZmZXJcbiAgICogQHJldHVybnMgLSBUaGUgaW5kZXggYnVmZmVyLlxuICAgKi9cbiAgZ2V0SW5kZXgoKSB7XG4gICAgcmV0dXJuIHRoaXMuaW5kZXhCdWZmZXI7XG4gIH1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHJlcXVlc3RlZCBidWZmZXIuXG4gICAqIEBwYXJhbSBpZCAtIFRoZSBuYW1lIG9mIHRoZSBidWZmZXIgcmVxdWlyZWQuXG4gICAqIEByZXR1cm5zIC0gVGhlIGJ1ZmZlciByZXF1ZXN0ZWQuXG4gICAqL1xuICBnZXRCdWZmZXIoaWQpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRBdHRyaWJ1dGUoaWQpLmJ1ZmZlcjtcbiAgfVxuICAvKipcbiAgICogVGhlIG51bWJlciBvZiB2ZXJ0aWNlcyBpbiB0aGlzIGdlb21ldHJ5LCBkZXJpdmVkIGZyb20gdGhlIGZpcnN0IG5vbi1pbnN0YW5jZWQgYXR0cmlidXRlLlxuICAgKiBUaGUgdmFsdWUgaXMgY2FjaGVkIGFuZCBvbmx5IHJlY2FsY3VsYXRlZCB3aGVuIHRoZSBnZW9tZXRyeSdzIGJ1ZmZlcnMgb3IgYXR0cmlidXRlcyBjaGFuZ2UuXG4gICAqL1xuICBnZXQgdmVydGV4Q291bnQoKSB7XG4gICAgaWYgKCF0aGlzLl92ZXJ0ZXhDb3VudERpcnR5KSByZXR1cm4gdGhpcy5fdmVydGV4Q291bnQ7XG4gICAgdGhpcy5fdmVydGV4Q291bnREaXJ0eSA9IGZhbHNlO1xuICAgIGNvbnN0IGF0dHJpYnV0ZXMgPSB0aGlzLmF0dHJpYnV0ZXM7XG4gICAgZm9yIChjb25zdCBpIGluIGF0dHJpYnV0ZXMpIHtcbiAgICAgIGNvbnN0IGF0dHJpYnV0ZSA9IGF0dHJpYnV0ZXNbaV07XG4gICAgICBpZiAoYXR0cmlidXRlLmluc3RhbmNlKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IGJ1ZmZlciA9IGF0dHJpYnV0ZS5idWZmZXI7XG4gICAgICB0aGlzLl92ZXJ0ZXhDb3VudCA9IGJ1ZmZlci5kYXRhLmxlbmd0aCAvIChhdHRyaWJ1dGUuc3RyaWRlIC8gNCB8fCBhdHRyaWJ1dGUuc2l6ZSk7XG4gICAgICByZXR1cm4gdGhpcy5fdmVydGV4Q291bnQ7XG4gICAgfVxuICAgIHRoaXMuX3ZlcnRleENvdW50ID0gMDtcbiAgICByZXR1cm4gMDtcbiAgfVxuICAvKipcbiAgICogVXNlZCB0byBmaWd1cmUgb3V0IGhvdyBtYW55IHZlcnRpY2VzIHRoZXJlIGFyZSBpbiB0aGlzIGdlb21ldHJ5XG4gICAqIEByZXR1cm5zIHRoZSBudW1iZXIgb2YgdmVydGljZXMgaW4gdGhlIGdlb21ldHJ5XG4gICAqIEBkZXByZWNhdGVkIHNpbmNlIDguMjAuMCwgdXNlIHtAbGluayBHZW9tZXRyeS52ZXJ0ZXhDb3VudH0gaW5zdGVhZFxuICAgKi9cbiAgZ2V0U2l6ZSgpIHtcbiAgICBkZXByZWNhdGlvbihcIjguMjAuMFwiLCBcIkdlb21ldHJ5LmdldFNpemUgaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSBHZW9tZXRyeS52ZXJ0ZXhDb3VudCBpbnN0ZWFkLlwiKTtcbiAgICByZXR1cm4gdGhpcy52ZXJ0ZXhDb3VudDtcbiAgfVxuICAvKipcbiAgICogQWRkcyBhbiBhdHRyaWJ1dGUgdG8gdGhlIGdlb21ldHJ5LlxuICAgKiBAcGFyYW0gbmFtZSAtIFRoZSBuYW1lIG9mIHRoZSBhdHRyaWJ1dGUgdG8gYWRkLlxuICAgKiBAcGFyYW0gYXR0cmlidXRlT3B0aW9uIC0gVGhlIGF0dHJpYnV0ZSBvcHRpb24gdG8gYWRkLlxuICAgKi9cbiAgYWRkQXR0cmlidXRlKG5hbWUsIGF0dHJpYnV0ZU9wdGlvbikge1xuICAgIGNvbnN0IGF0dHJpYnV0ZSA9IGVuc3VyZUlzQXR0cmlidXRlKGF0dHJpYnV0ZU9wdGlvbik7XG4gICAgY29uc3QgYnVmZmVySW5kZXggPSB0aGlzLmJ1ZmZlcnMuaW5kZXhPZihhdHRyaWJ1dGUuYnVmZmVyKTtcbiAgICBpZiAoYnVmZmVySW5kZXggPT09IC0xKSB7XG4gICAgICB0aGlzLmJ1ZmZlcnMucHVzaChhdHRyaWJ1dGUuYnVmZmVyKTtcbiAgICAgIGF0dHJpYnV0ZS5idWZmZXIub24oXCJ1cGRhdGVcIiwgdGhpcy5vbkJ1ZmZlclVwZGF0ZSwgdGhpcyk7XG4gICAgICBhdHRyaWJ1dGUuYnVmZmVyLm9uKFwiY2hhbmdlXCIsIHRoaXMub25CdWZmZXJVcGRhdGUsIHRoaXMpO1xuICAgIH1cbiAgICB0aGlzLmF0dHJpYnV0ZXNbbmFtZV0gPSBhdHRyaWJ1dGU7XG4gICAgdGhpcy5fdmVydGV4Q291bnREaXJ0eSA9IHRydWU7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYW4gaW5kZXggYnVmZmVyIHRvIHRoZSBnZW9tZXRyeS5cbiAgICogQHBhcmFtIGluZGV4QnVmZmVyIC0gVGhlIGluZGV4IGJ1ZmZlciB0byBhZGQuIENhbiBiZSBhIEJ1ZmZlciwgVHlwZWRBcnJheSwgb3IgYW4gYXJyYXkgb2YgbnVtYmVycy5cbiAgICovXG4gIGFkZEluZGV4KGluZGV4QnVmZmVyKSB7XG4gICAgdGhpcy5pbmRleEJ1ZmZlciA9IGVuc3VyZUlzQnVmZmVyKGluZGV4QnVmZmVyLCB0cnVlKTtcbiAgICB0aGlzLmJ1ZmZlcnMucHVzaCh0aGlzLmluZGV4QnVmZmVyKTtcbiAgfVxuICAvKiogUmV0dXJucyB0aGUgYm91bmRzIG9mIHRoZSBnZW9tZXRyeS4gKi9cbiAgZ2V0IGJvdW5kcygpIHtcbiAgICBpZiAoIXRoaXMuX2JvdW5kc0RpcnR5KSByZXR1cm4gdGhpcy5fYm91bmRzO1xuICAgIHRoaXMuX2JvdW5kc0RpcnR5ID0gZmFsc2U7XG4gICAgcmV0dXJuIGdldEdlb21ldHJ5Qm91bmRzKHRoaXMsIFwiYVBvc2l0aW9uXCIsIHRoaXMuX2JvdW5kcyk7XG4gIH1cbiAgLyoqIFVubG9hZHMgdGhlIGdlb21ldHJ5IGZyb20gdGhlIEdQVS4gKi9cbiAgdW5sb2FkKCkge1xuICAgIHRoaXMuZW1pdChcInVubG9hZFwiLCB0aGlzKTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiB0aGlzLl9ncHVEYXRhKSB7XG4gICAgICB0aGlzLl9ncHVEYXRhW2tleV0/LmRlc3Ryb3koKTtcbiAgICB9XG4gICAgdGhpcy5fZ3B1RGF0YSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICB9XG4gIC8qKlxuICAgKiBkZXN0cm95cyB0aGUgZ2VvbWV0cnkuXG4gICAqIEBwYXJhbSBkZXN0cm95QnVmZmVycyAtIGRlc3Ryb3kgdGhlIGJ1ZmZlcnMgYXNzb2NpYXRlZCB3aXRoIHRoaXMgZ2VvbWV0cnlcbiAgICovXG4gIGRlc3Ryb3koZGVzdHJveUJ1ZmZlcnMgPSBmYWxzZSkge1xuICAgIHRoaXMuZW1pdChcImRlc3Ryb3lcIiwgdGhpcyk7XG4gICAgZm9yIChjb25zdCBidWZmZXIgb2YgdGhpcy5idWZmZXJzKSB7XG4gICAgICBidWZmZXIub2ZmKFwidXBkYXRlXCIsIHRoaXMub25CdWZmZXJVcGRhdGUsIHRoaXMpO1xuICAgICAgYnVmZmVyLm9mZihcImNoYW5nZVwiLCB0aGlzLm9uQnVmZmVyVXBkYXRlLCB0aGlzKTtcbiAgICAgIGlmIChkZXN0cm95QnVmZmVycykgYnVmZmVyLmRlc3Ryb3koKTtcbiAgICB9XG4gICAgdGhpcy51bmxvYWQoKTtcbiAgICB0aGlzLnJlbW92ZUFsbExpc3RlbmVycygpO1xuICAgIHRoaXMuYXR0cmlidXRlcyA9IG51bGw7XG4gICAgdGhpcy5idWZmZXJzID0gbnVsbDtcbiAgICB0aGlzLmluZGV4QnVmZmVyID0gbnVsbDtcbiAgICB0aGlzLl9ib3VuZHMgPSBudWxsO1xuICB9XG59XG5cbmV4cG9ydCB7IEdlb21ldHJ5IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1HZW9tZXRyeS5tanMubWFwXG4iLCJpbXBvcnQgeyBET01BZGFwdGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vZW52aXJvbm1lbnQvYWRhcHRlci5tanMnO1xuaW1wb3J0IHsgbmV4dFBvdzIsIGlzUG93MiB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL21pc2MvcG93Mi5tanMnO1xuaW1wb3J0IHsgZGVwcmVjYXRpb24sIHY4XzIxXzAgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9sb2dnaW5nL2RlcHJlY2F0aW9uLm1qcyc7XG5pbXBvcnQgeyB3YXJuIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy93YXJuLm1qcyc7XG5pbXBvcnQgeyBHbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5IH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvcG9vbC9HbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5Lm1qcyc7XG5pbXBvcnQgeyBTY3JlZW5TaXplUmVnaXN0cnkgfSBmcm9tICcuL3V0aWxzL1NjcmVlblNpemVSZWdpc3RyeS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IG1heEtleURpbWVuc2lvbiA9IDMyNzY3O1xuZnVuY3Rpb24gYnVja2V0S2V5KHdpZHRoLCBoZWlnaHQpIHtcbiAgcmV0dXJuICh3aWR0aCA8PCAxNykgKyAoaGVpZ2h0IDw8IDIpO1xufVxuY2xhc3MgQ2FudmFzUG9vbENsYXNzIHtcbiAgY29uc3RydWN0b3IoY2FudmFzT3B0aW9ucykge1xuICAgIC8qKiBpZGxlIGNhbnZhc2VzLCBrZXllZCBieSBzaXplICovXG4gICAgdGhpcy5fYnVja2V0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgLyoqIHRoZSBzY3JlZW5zIHRoaXMgcG9vbCBpcyBzaXppbmcgaXRzIGNhbnZhc2VzIGZvciAqL1xuICAgIHRoaXMuX3NjcmVlbnMgPSBuZXcgU2NyZWVuU2l6ZVJlZ2lzdHJ5KCk7XG4gICAgdGhpcy5fZW5hYmxlRnVsbFNjcmVlbiA9IGZhbHNlO1xuICAgIHRoaXMuY2FudmFzT3B0aW9ucyA9IGNhbnZhc09wdGlvbnMgfHwge307XG4gIH1cbiAgLyoqXG4gICAqIEhhcyBubyBlZmZlY3QuIFRoZSBwb29sIHNpemVzIGNhbnZhc2VzIHRvIHRoZSBzY3JlZW5zIHJlZ2lzdGVyZWQgd2l0aFxuICAgKiB7QGxpbmsgQ2FudmFzUG9vbENsYXNzI3NldFNjcmVlblNpemV8c2V0U2NyZWVuU2l6ZX0uXG4gICAqIEBkZXByZWNhdGVkIHNpbmNlIDguMjEuMFxuICAgKi9cbiAgZ2V0IGVuYWJsZUZ1bGxTY3JlZW4oKSB7XG4gICAgZGVwcmVjYXRpb24odjhfMjFfMCwgXCJDYW52YXNQb29sLmVuYWJsZUZ1bGxTY3JlZW4gaXMgbm8gbG9uZ2VyIHVzZWQsIHRoZSBwb29sIHNpemVzIGNhbnZhc2VzIHRvIHRoZSBzY3JlZW5zIHJlZ2lzdGVyZWQgd2l0aCBzZXRTY3JlZW5TaXplLlwiKTtcbiAgICByZXR1cm4gdGhpcy5fZW5hYmxlRnVsbFNjcmVlbjtcbiAgfVxuICBzZXQgZW5hYmxlRnVsbFNjcmVlbih2YWx1ZSkge1xuICAgIGRlcHJlY2F0aW9uKHY4XzIxXzAsIFwiQ2FudmFzUG9vbC5lbmFibGVGdWxsU2NyZWVuIGlzIG5vIGxvbmdlciB1c2VkLCB0aGUgcG9vbCBzaXplcyBjYW52YXNlcyB0byB0aGUgc2NyZWVucyByZWdpc3RlcmVkIHdpdGggc2V0U2NyZWVuU2l6ZS5cIik7XG4gICAgdGhpcy5fZW5hYmxlRnVsbFNjcmVlbiA9IHZhbHVlO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGVzIHRleHR1cmUgd2l0aCBwYXJhbXMgdGhhdCB3ZXJlIHNwZWNpZmllZCBpbiBwb29sIGNvbnN0cnVjdG9yLlxuICAgKiBAcGFyYW0gcGl4ZWxXaWR0aCAtIFdpZHRoIG9mIHRleHR1cmUgaW4gcGl4ZWxzLlxuICAgKiBAcGFyYW0gcGl4ZWxIZWlnaHQgLSBIZWlnaHQgb2YgdGV4dHVyZSBpbiBwaXhlbHMuXG4gICAqL1xuICBfY3JlYXRlQ2FudmFzQW5kQ29udGV4dChwaXhlbFdpZHRoLCBwaXhlbEhlaWdodCkge1xuICAgIGNvbnN0IGNhbnZhcyA9IERPTUFkYXB0ZXIuZ2V0KCkuY3JlYXRlQ2FudmFzKCk7XG4gICAgY2FudmFzLndpZHRoID0gcGl4ZWxXaWR0aDtcbiAgICBjYW52YXMuaGVpZ2h0ID0gcGl4ZWxIZWlnaHQ7XG4gICAgY29uc3QgY29udGV4dCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XG4gICAgcmV0dXJuIHsgY2FudmFzLCBjb250ZXh0IH07XG4gIH1cbiAgLyoqXG4gICAqIEdldHMgYSBQb3dlci1vZi1Ud28gY2FudmFzIG9yIHNjcmVlbiBzaXplZCBjYW52YXNcbiAgICogQHBhcmFtIG1pbldpZHRoIC0gVGhlIG1pbmltdW0gd2lkdGggb2YgdGhlIGNhbnZhcy5cbiAgICogQHBhcmFtIG1pbkhlaWdodCAtIFRoZSBtaW5pbXVtIGhlaWdodCBvZiB0aGUgY2FudmFzLlxuICAgKiBAcGFyYW0gcmVzb2x1dGlvbiAtIFRoZSByZXNvbHV0aW9uIG9mIHRoZSBjYW52YXMuXG4gICAqIEByZXR1cm5zIFRoZSBuZXcgY2FudmFzIGFuZCBpdHMgY29udGV4dC5cbiAgICovXG4gIGdldE9wdGltYWxDYW52YXNBbmRDb250ZXh0KG1pbldpZHRoLCBtaW5IZWlnaHQsIHJlc29sdXRpb24gPSAxKSB7XG4gICAgY29uc3QgeyB3aWR0aDogY2FudmFzV2lkdGgsIGhlaWdodDogY2FudmFzSGVpZ2h0IH0gPSB0aGlzLmdldE9wdGltYWxTaXplKG1pbldpZHRoLCBtaW5IZWlnaHQsIHJlc29sdXRpb24pO1xuICAgIGlmIChjYW52YXNXaWR0aCA+IG1heEtleURpbWVuc2lvbiB8fCBjYW52YXNIZWlnaHQgPiBtYXhLZXlEaW1lbnNpb24pIHtcbiAgICAgIHdhcm4oYENhbnZhc1Bvb2w6ICR7Y2FudmFzV2lkdGh9eCR7Y2FudmFzSGVpZ2h0fSBpcyBsYXJnZXIgdGhhbiB0aGUgJHttYXhLZXlEaW1lbnNpb259cHggcG9vbCBrZXkgbGltaXQsIGNhbnZhc2VzIG9mIHRoaXMgc2l6ZSBtYXkgYmUgcG9vbGVkIHRvZ2V0aGVyYCk7XG4gICAgfVxuICAgIGNvbnN0IGtleSA9IGJ1Y2tldEtleShjYW52YXNXaWR0aCwgY2FudmFzSGVpZ2h0KTtcbiAgICBsZXQgYnVja2V0ID0gdGhpcy5fYnVja2V0cy5nZXQoa2V5KTtcbiAgICBpZiAoIWJ1Y2tldCkge1xuICAgICAgYnVja2V0ID0gW107XG4gICAgICB0aGlzLl9idWNrZXRzLnNldChrZXksIGJ1Y2tldCk7XG4gICAgfVxuICAgIGxldCBjYW52YXNBbmRDb250ZXh0ID0gYnVja2V0LnBvcCgpO1xuICAgIGlmICghY2FudmFzQW5kQ29udGV4dCkge1xuICAgICAgY2FudmFzQW5kQ29udGV4dCA9IHRoaXMuX2NyZWF0ZUNhbnZhc0FuZENvbnRleHQoY2FudmFzV2lkdGgsIGNhbnZhc0hlaWdodCk7XG4gICAgfVxuICAgIHJldHVybiBjYW52YXNBbmRDb250ZXh0O1xuICB9XG4gIC8qKlxuICAgKiBUaGUgYmFja2luZyBzaXplLCBpbiBwaHlzaWNhbCBwaXhlbHMsIHRoYXRcbiAgICoge0BsaW5rIENhbnZhc1Bvb2xDbGFzcyNnZXRPcHRpbWFsQ2FudmFzQW5kQ29udGV4dHxnZXRPcHRpbWFsQ2FudmFzQW5kQ29udGV4dH0gd291bGQgYWxsb2NhdGUgZm9yIGEgcmVxdWVzdCxcbiAgICogd2l0aG91dCB0YWtpbmcgYSBjYW52YXMgZnJvbSB0aGUgcG9vbC5cbiAgICpcbiAgICogRWFjaCBheGlzIGlzIHRoZSBuZXh0IHBvd2VyIG9mIHR3bywgb3IgdGhlIHNtYWxsZXN0IHJlZ2lzdGVyZWQgc2NyZWVuIHRoZSByZXF1ZXN0IGZpdHMgaW5zaWRlXG4gICAqIChzZWUge0BsaW5rIENhbnZhc1Bvb2xDbGFzcyNzZXRTY3JlZW5TaXplfHNldFNjcmVlblNpemV9KS5cbiAgICogQHBhcmFtIG1pbldpZHRoIC0gVGhlIG1pbmltdW0gd2lkdGggb2YgdGhlIGNhbnZhcy5cbiAgICogQHBhcmFtIG1pbkhlaWdodCAtIFRoZSBtaW5pbXVtIGhlaWdodCBvZiB0aGUgY2FudmFzLlxuICAgKiBAcGFyYW0gcmVzb2x1dGlvbiAtIFRoZSByZXNvbHV0aW9uIG9mIHRoZSBjYW52YXMuXG4gICAqIEByZXR1cm5zIFRoZSB3aWR0aCBhbmQgaGVpZ2h0IHRoZSBwb29sZWQgY2FudmFzIHdvdWxkIGhhdmUsIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICovXG4gIGdldE9wdGltYWxTaXplKG1pbldpZHRoLCBtaW5IZWlnaHQsIHJlc29sdXRpb24gPSAxKSB7XG4gICAgY29uc3QgcGl4ZWxXaWR0aCA9IE1hdGguY2VpbChtaW5XaWR0aCAqIHJlc29sdXRpb24gLSAxZS02KTtcbiAgICBjb25zdCBwaXhlbEhlaWdodCA9IE1hdGguY2VpbChtaW5IZWlnaHQgKiByZXNvbHV0aW9uIC0gMWUtNik7XG4gICAgY29uc3QgcG8yV2lkdGggPSBuZXh0UG93MihwaXhlbFdpZHRoKTtcbiAgICBjb25zdCBzY3JlZW5XaWR0aCA9IHRoaXMuX3NjcmVlbnMuZ2V0Rml0dGluZ1dpZHRoKHBpeGVsV2lkdGgpO1xuICAgIGNvbnN0IHBvMkhlaWdodCA9IG5leHRQb3cyKHBpeGVsSGVpZ2h0KTtcbiAgICBjb25zdCBzY3JlZW5IZWlnaHQgPSB0aGlzLl9zY3JlZW5zLmdldEZpdHRpbmdIZWlnaHQocGl4ZWxIZWlnaHQpO1xuICAgIHJldHVybiB7XG4gICAgICB3aWR0aDogc2NyZWVuV2lkdGggIT09IHZvaWQgMCA/IE1hdGgubWluKHNjcmVlbldpZHRoLCBwbzJXaWR0aCkgOiBwbzJXaWR0aCxcbiAgICAgIGhlaWdodDogc2NyZWVuSGVpZ2h0ICE9PSB2b2lkIDAgPyBNYXRoLm1pbihzY3JlZW5IZWlnaHQsIHBvMkhlaWdodCkgOiBwbzJIZWlnaHRcbiAgICB9O1xuICB9XG4gIC8qKlxuICAgKiBQbGFjZSBhIGNhbnZhcyBiYWNrIGludG8gdGhlIHBvb2wuXG4gICAqIEBwYXJhbSBjYW52YXNBbmRDb250ZXh0XG4gICAqL1xuICByZXR1cm5DYW52YXNBbmRDb250ZXh0KGNhbnZhc0FuZENvbnRleHQpIHtcbiAgICBjb25zdCBjYW52YXMgPSBjYW52YXNBbmRDb250ZXh0LmNhbnZhcztcbiAgICBjb25zdCB7IHdpZHRoLCBoZWlnaHQgfSA9IGNhbnZhcztcbiAgICBjb25zdCBjYW52YXNlcyA9IHRoaXMuX2J1Y2tldHMuZ2V0KGJ1Y2tldEtleSh3aWR0aCwgaGVpZ2h0KSk7XG4gICAgaWYgKCFjYW52YXNlcykgcmV0dXJuO1xuICAgIGNhbnZhc0FuZENvbnRleHQuY29udGV4dC5yZXNldFRyYW5zZm9ybSgpO1xuICAgIGNhbnZhc0FuZENvbnRleHQuY29udGV4dC5jbGVhclJlY3QoMCwgMCwgd2lkdGgsIGhlaWdodCk7XG4gICAgY2FudmFzZXMucHVzaChjYW52YXNBbmRDb250ZXh0KTtcbiAgfVxuICAvKipcbiAgICogUmVnaXN0ZXJzIHRoZSBzY3JlZW4gc2l6ZSBvZiBhIHJlbmRlcmVyIHdpdGggdGhlIHBvb2wsIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICpcbiAgICogV2hpbGUgYSBzY3JlZW4gaXMgcmVnaXN0ZXJlZCwgYSByZXF1ZXN0IHRoYXQgZml0cyBpbnNpZGUgaXQgb24gYW4gYXhpcyBpcyBnaXZlbiB0aGF0IHNjcmVlbidzIHNpemUgb25cbiAgICogdGhhdCBheGlzIGluc3RlYWQgb2YgdGhlIG5leHQgcG93ZXIgb2YgdHdvLCB3aGljaCBzdG9wcyBhIGZ1bGwgc2NyZWVuIGNhbnZhcyBmcm9tIGJlaW5nIGFsbG9jYXRlZCBmYXJcbiAgICogbGFyZ2VyIHRoYW4gdGhlIHNjcmVlbi4gUmVxdWVzdHMgbGFyZ2VyIHRoYW4gZXZlcnkgcmVnaXN0ZXJlZCBzY3JlZW4gb24gYW4gYXhpcyBrZWVwIHRoZSBwb3dlciBvZiB0d29cbiAgICogc2l6ZSAtIHRoZSBwb29sIG5ldmVyIHJvdW5kcyBhIHJlcXVlc3QgdXAgdG8gYSBzY3JlZW4gaXQgZG9lcyBub3QgZml0IGluLlxuICAgKiBAcGFyYW0gcmVuZGVyZXJVaWQgLSBUaGUgdWlkIG9mIHRoZSByZW5kZXJlciwgdXNlZCB0byB1cGRhdGUgb3IgcmVtb3ZlIHRoaXMgc2NyZWVuIGxhdGVyLlxuICAgKiBAcGFyYW0gcGl4ZWxXaWR0aCAtIFRoZSB3aWR0aCBvZiB0aGUgc2NyZWVuIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICogQHBhcmFtIHBpeGVsSGVpZ2h0IC0gVGhlIGhlaWdodCBvZiB0aGUgc2NyZWVuIGluIHBoeXNpY2FsIHBpeGVscy5cbiAgICovXG4gIHNldFNjcmVlblNpemUocmVuZGVyZXJVaWQsIHBpeGVsV2lkdGgsIHBpeGVsSGVpZ2h0KSB7XG4gICAgaWYgKCF0aGlzLl9zY3JlZW5zLnNldChyZW5kZXJlclVpZCwgcGl4ZWxXaWR0aCwgcGl4ZWxIZWlnaHQpKSByZXR1cm47XG4gICAgdGhpcy5fcHJ1bmVTY3JlZW5DYW52YXNlcygpO1xuICB9XG4gIC8qKlxuICAgKiBSZW1vdmVzIGEgc2NyZWVuIHByZXZpb3VzbHkgcmVnaXN0ZXJlZCB3aXRoXG4gICAqIHtAbGluayBDYW52YXNQb29sQ2xhc3Mjc2V0U2NyZWVuU2l6ZXxzZXRTY3JlZW5TaXplfSwgZHJvcHBpbmcgYW55IGlkbGUgY2FudmFzZXMgdGhhdCB3ZXJlXG4gICAqIG9ubHkgYmVpbmcga2VwdCBmb3IgaXQuXG4gICAqIEBwYXJhbSByZW5kZXJlclVpZCAtIFRoZSB1aWQgdGhlIHNjcmVlbiB3YXMgcmVnaXN0ZXJlZCB3aXRoLlxuICAgKi9cbiAgcmVtb3ZlU2NyZWVuKHJlbmRlcmVyVWlkKSB7XG4gICAgaWYgKCF0aGlzLl9zY3JlZW5zLnJlbW92ZShyZW5kZXJlclVpZCkpIHJldHVybjtcbiAgICB0aGlzLl9wcnVuZVNjcmVlbkNhbnZhc2VzKCk7XG4gIH1cbiAgLyoqIENsZWFycyB0aGUgcG9vbC4gKi9cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy5fYnVja2V0cy5jbGVhcigpO1xuICB9XG4gIC8qKlxuICAgKiBEcm9wcyB0aGUgaWRsZSBjYW52YXNlcyBpbiBldmVyeSBidWNrZXQgdGhhdCBoYXMgYSBub24gcG93ZXIgb2YgdHdvIGRpbWVuc2lvbiBtYXRjaGluZyBubyBsaXZlXG4gICAqIHNjcmVlbi4gUG93ZXIgb2YgdHdvIGJ1Y2tldHMgYXJlIGFsd2F5cyBrZXB0LCBhcyBhbnkgcmVxdWVzdCBjYW4gZmFsbCBiYWNrIHRvIHRoZW0uXG4gICAqL1xuICBfcHJ1bmVTY3JlZW5DYW52YXNlcygpIHtcbiAgICBmb3IgKGNvbnN0IFtrZXldIG9mIHRoaXMuX2J1Y2tldHMpIHtcbiAgICAgIGNvbnN0IHdpZHRoID0ga2V5ID4+PiAxNztcbiAgICAgIGNvbnN0IGhlaWdodCA9IGtleSA+Pj4gMiAmIDMyNzY3O1xuICAgICAgaWYgKChpc1BvdzIod2lkdGgpIHx8IHRoaXMuX3NjcmVlbnMuaGFzV2lkdGgod2lkdGgpKSAmJiAoaXNQb3cyKGhlaWdodCkgfHwgdGhpcy5fc2NyZWVucy5oYXNIZWlnaHQoaGVpZ2h0KSkpIGNvbnRpbnVlO1xuICAgICAgdGhpcy5fYnVja2V0cy5kZWxldGUoa2V5KTtcbiAgICB9XG4gIH1cbn1cbmNvbnN0IENhbnZhc1Bvb2wgPSBuZXcgQ2FudmFzUG9vbENsYXNzKCk7XG5HbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5LnJlZ2lzdGVyKENhbnZhc1Bvb2wpO1xuXG5leHBvcnQgeyBDYW52YXNQb29sLCBDYW52YXNQb29sQ2xhc3MgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUNhbnZhc1Bvb2wubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOztBQUNBLElBQUksZ0JBQWdDLGtCQUFFLG1CQUFtQjtDQUN2RCxlQUFlLGlCQUFpQjtDQUNoQyxlQUFlLGdCQUFnQjtDQUMvQixlQUFlLHVCQUF1QjtDQUN0QyxlQUFlLGlCQUFpQjtDQUNoQyxlQUFlLGlCQUFpQjtDQUNoQyxlQUFlLGlCQUFpQjtDQUNoQyxlQUFlLHdCQUF3QjtDQUN2QyxlQUFlLGtCQUFrQjtDQUNqQyxlQUFlLGtCQUFrQjtDQUNqQyxlQUFlLGtCQUFrQjtDQUNqQyxlQUFlLHdCQUF3QjtDQUN2QyxlQUFlLGlCQUFpQjtDQUNoQyxlQUFlLGtCQUFrQjtDQUNqQyxlQUFlLFdBQVc7Q0FDMUIsZUFBZSxnQkFBZ0I7Q0FDL0IsZUFBZSxtQkFBbUI7Q0FDbEMsZUFBZSxpQkFBaUI7Q0FDaEMsZUFBZSxxQkFBcUI7Q0FDcEMsZUFBZSxnQkFBZ0I7Q0FDL0IsZUFBZSxlQUFlO0NBQzlCLGVBQWUsbUJBQW1CO0NBQ2xDLGVBQWUsMEJBQTBCO0NBQ3pDLGVBQWUsMkJBQTJCO0NBQzFDLGVBQWUsaUJBQWlCO0NBQ2hDLGVBQWUsa0JBQWtCO0NBQ2pDLGVBQWUsYUFBYTtDQUM1QixPQUFPO0FBQ1QsRUFBQSxDQUFHLGlCQUFpQixDQUFDLENBQUM7QUFDdEIsSUFBTSxzQkFBc0IsUUFBUTtDQUNsQyxJQUFJLE9BQU8sUUFBUSxjQUFjLE9BQU8sUUFBUSxZQUFZLElBQUksV0FBVztFQUN6RSxJQUFJLENBQUMsSUFBSSxXQUNQLE1BQU0sSUFBSSxNQUFNLCtDQUErQztFQUdqRSxNQUFNO0dBQUUsR0FEUyxPQUFPLElBQUksY0FBYyxXQUFXLEVBQUUsTUFBTSxJQUFJLFVBQVUsSUFBSSxJQUFJO0dBQzlELEtBQUs7RUFBSTtDQUNoQztDQUNBLElBQUksT0FBTyxRQUFRLFVBQ2pCLE1BQU0sRUFBRSxHQUFHLElBQUk7TUFFZixNQUFNLElBQUksTUFBTSx3QkFBd0I7Q0FFMUMsSUFBSSxPQUFPLElBQUksU0FBUyxVQUN0QixJQUFJLE9BQU8sQ0FBQyxJQUFJLElBQUk7Q0FFdEIsT0FBTztBQUNUO0FBQ0EsSUFBTSw4QkFBOEIsS0FBSyxvQkFBb0IsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLFlBQVk7QUFDakcsSUFBTSxhQUFhOztDQUVqQixjQUFjLENBQUM7O0NBRWYsaUJBQWlCLENBQUM7O0NBRWxCLFFBQVEsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCVCxPQUFPLEdBQUcsYUFBYTtFQUNyQixZQUFZLElBQUksa0JBQWtCLENBQUMsQ0FBQyxTQUFTLFFBQVE7R0FDbkQsSUFBSSxLQUFLLFNBQVMsU0FBUyxLQUFLLGdCQUFnQixLQUFLLEdBQUcsR0FBRyxDQUFDO0VBQzlELENBQUM7RUFDRCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJBLElBQUksR0FBRyxhQUFhO0VBQ2xCLFlBQVksSUFBSSxrQkFBa0IsQ0FBQyxDQUFDLFNBQVMsUUFBUTtHQUNuRCxJQUFJLEtBQUssU0FBUyxTQUFTO0lBQ3pCLE1BQU0sV0FBVyxLQUFLO0lBQ3RCLE1BQU0sUUFBUSxLQUFLO0lBQ25CLElBQUksQ0FBQyxTQUFTLE9BQU87S0FDbkIsTUFBTSxRQUFRLE1BQU0sU0FBUyxDQUFDO0tBQzlCLE1BQU0sS0FBSyxFQUFFLEtBQUssR0FBRztJQUN2QixPQUNFLFNBQVMsS0FBSyxHQUFHLEdBQUc7R0FFeEIsQ0FBQztFQUNILENBQUM7RUFDRCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Q0FVQSxPQUFPLE1BQU0sT0FBTyxVQUFVO0VBQzVCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0saUJBQWlCLEtBQUs7RUFDNUIsSUFBSSxZQUFZLFNBQVMsZUFBZSxPQUN0QyxNQUFNLElBQUksTUFBTSxrQkFBa0IsS0FBSyx1QkFBdUI7RUFFaEUsWUFBWSxRQUFRO0VBQ3BCLGVBQWUsUUFBUTtFQUN2QixNQUFNLFFBQVEsS0FBSztFQUNuQixJQUFJLE1BQU0sT0FBTztHQUNmLE1BQU0sS0FBSyxFQUFFLFNBQVMsUUFBUSxNQUFNLEdBQUcsQ0FBQztHQUN4QyxPQUFPLE1BQU07RUFDZjtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FRQSxZQUFZLE1BQU0sS0FBSztFQUNyQixPQUFPLEtBQUssT0FDVixPQUNDLGNBQWM7R0FDYixJQUFJLFVBQVUsTUFDWixJQUFJLFVBQVUsUUFBUSxVQUFVO0VBRXBDLElBQ0MsY0FBYztHQUNiLElBQUksVUFBVSxNQUNaLE9BQU8sSUFBSSxVQUFVO0VBRXpCLENBQ0Y7Q0FDRjs7Ozs7Ozs7O0NBU0Esa0JBQWtCLE1BQU0sS0FBSyxrQkFBa0IsSUFBSTtFQUNqRCxPQUFPLEtBQUssT0FDVixPQUNDLGNBQWM7R0FFYixJQURjLElBQUksV0FBVyxTQUFTLEtBQUssU0FBUyxVQUFVLElBQ3RELEtBQUssR0FBRztHQUNoQixJQUFJLEtBQUs7SUFBRSxNQUFNLFVBQVU7SUFBTSxPQUFPLFVBQVU7R0FBSSxDQUFDO0dBQ3ZELElBQUksTUFBTSxHQUFHLE1BQU0sMkJBQTJCLEVBQUUsT0FBTyxlQUFlLElBQUksMkJBQTJCLEVBQUUsT0FBTyxlQUFlLENBQUM7RUFDaEksSUFDQyxjQUFjO0dBQ2IsTUFBTSxRQUFRLElBQUksV0FBVyxTQUFTLEtBQUssU0FBUyxVQUFVLElBQUk7R0FDbEUsSUFBSSxVQUFVLElBQ1osSUFBSSxPQUFPLE9BQU8sQ0FBQztFQUV2QixDQUNGO0NBQ0Y7Ozs7Ozs7OztDQVNBLGFBQWEsTUFBTSxNQUFNLGtCQUFrQixJQUFJO0VBQzdDLE9BQU8sS0FBSyxPQUNWLE9BQ0MsY0FBYztHQUNiLElBQUksS0FBSyxTQUFTLFVBQVUsR0FBRyxHQUM3QjtHQUVGLEtBQUssS0FBSyxVQUFVLEdBQUc7R0FDdkIsS0FBSyxNQUFNLEdBQUcsTUFBTSwyQkFBMkIsR0FBRyxlQUFlLElBQUksMkJBQTJCLEdBQUcsZUFBZSxDQUFDO0VBQ3JILElBQ0MsY0FBYztHQUNiLE1BQU0sUUFBUSxLQUFLLFFBQVEsVUFBVSxHQUFHO0dBQ3hDLElBQUksVUFBVSxJQUNaLEtBQUssT0FBTyxPQUFPLENBQUM7RUFFeEIsQ0FDRjtDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlDQSxNQUFNLFFBQVEsR0FBRyxTQUFTO0VBQ3hCLEtBQUssTUFBTSxVQUFVLFNBQ25CLE9BQU8saUJBQWlCLE9BQU8sV0FBVyxPQUFPLDBCQUEwQixNQUFNLENBQUM7Q0FFdEY7QUFDRjtBRXRRQSxJQUFBLHlCQUFlQTtDRERmLElBQUksTUFBTSxPQUFPLFVBQVU7Q0FDdkIsSUFBQSxTQUFTOzs7Ozs7OztDQVNiLFNBQVMsU0FBUyxDQUFDO0NBU25CLElBQUksT0FBTyxRQUFRO0VBQ2pCLE9BQU8sWUFBWSxPQUFPLE9BQU8sSUFBSTtFQU1yQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxXQUFXLFNBQVM7Q0FDeEM7Ozs7Ozs7Ozs7Q0FXQSxTQUFTLEdBQUcsSUFBSSxTQUFTLE1BQU07RUFDN0IsS0FBSyxLQUFLO0VBQ1YsS0FBSyxVQUFVO0VBQ2YsS0FBSyxPQUFPLFFBQVE7Q0FDdEI7Ozs7Ozs7Ozs7OztDQWFBLFNBQVMsWUFBWSxTQUFTLE9BQU8sSUFBSSxTQUFTLE1BQU07RUFDdEQsSUFBSSxPQUFPLE9BQU8sWUFDaEIsTUFBTSxJQUFJLFVBQVUsaUNBQWlDO0VBR3ZELElBQUksV0FBVyxJQUFJLEdBQUcsSUFBSSxXQUFXLFNBQVMsSUFBSSxHQUM5QyxNQUFNLFNBQVMsU0FBUyxRQUFRO0VBRXBDLElBQUksQ0FBQyxRQUFRLFFBQVEsTUFBTSxRQUFRLFFBQVEsT0FBTyxVQUFVLFFBQVE7T0FDL0QsSUFBSSxDQUFDLFFBQVEsUUFBUSxJQUFJLENBQUMsSUFBSSxRQUFRLFFBQVEsSUFBSSxDQUFDLEtBQUssUUFBUTtPQUNoRSxRQUFRLFFBQVEsT0FBTyxDQUFDLFFBQVEsUUFBUSxNQUFNLFFBQVE7RUFFM0QsT0FBTztDQUNUOzs7Ozs7OztDQVNBLFNBQVMsV0FBVyxTQUFTLEtBQUs7RUFDaEMsSUFBSSxFQUFFLFFBQVEsaUJBQWlCLEdBQUcsUUFBUSxVQUFVLElBQUksT0FBTztPQUMxRCxPQUFPLFFBQVEsUUFBUTtDQUM5Qjs7Ozs7Ozs7Q0FTQSxTQUFTLGVBQWU7RUFDdEIsS0FBSyxVQUFVLElBQUksT0FBTztFQUMxQixLQUFLLGVBQWU7Q0FDdEI7Ozs7Ozs7O0NBU0EsYUFBYSxVQUFVLGFBQWEsU0FBUyxhQUFhO0VBQ3hELElBQUksUUFBUSxDQUFDLEdBQ1QsUUFDQTtFQUVKLElBQUksS0FBSyxpQkFBaUIsR0FBRyxPQUFPO0VBRXBDLEtBQUssUUFBUyxTQUFTLEtBQUssU0FDMUIsSUFBSSxJQUFJLEtBQUssUUFBUSxJQUFJLEdBQUcsTUFBTSxLQUFLLFNBQVMsS0FBSyxNQUFNLENBQUMsSUFBSSxJQUFJO0VBR3RFLElBQUksT0FBTyx1QkFDVCxPQUFPLE1BQU0sT0FBTyxPQUFPLHNCQUFzQixNQUFNLENBQUM7RUFHMUQsT0FBTztDQUNUOzs7Ozs7OztDQVNBLGFBQWEsVUFBVSxZQUFZLFNBQVMsVUFBVSxPQUFPO0VBQzNELElBQUksTUFBTSxTQUFTLFNBQVMsUUFBUSxPQUNoQyxXQUFXLEtBQUssUUFBUTtFQUU1QixJQUFJLENBQUMsVUFBVSxPQUFPLENBQUM7RUFDdkIsSUFBSSxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVMsRUFBRTtFQUVwQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUssSUFBSSxNQUFNLENBQUMsR0FBRyxJQUFJLEdBQUcsS0FDN0QsR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO0VBR3RCLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FTQSxhQUFhLFVBQVUsZ0JBQWdCLFNBQVMsY0FBYyxPQUFPO0VBQ25FLElBQUksTUFBTSxTQUFTLFNBQVMsUUFBUSxPQUNoQyxZQUFZLEtBQUssUUFBUTtFQUU3QixJQUFJLENBQUMsV0FBVyxPQUFPO0VBQ3ZCLElBQUksVUFBVSxJQUFJLE9BQU87RUFDekIsT0FBTyxVQUFVO0NBQ25COzs7Ozs7OztDQVNBLGFBQWEsVUFBVSxPQUFPLFNBQVMsS0FBSyxPQUFPLElBQUksSUFBSSxJQUFJLElBQUksSUFBSTtFQUNyRSxJQUFJLE1BQU0sU0FBUyxTQUFTLFFBQVE7RUFFcEMsSUFBSSxDQUFDLEtBQUssUUFBUSxNQUFNLE9BQU87RUFFL0IsSUFBSSxZQUFZLEtBQUssUUFBUSxNQUN6QixNQUFNLFVBQVUsUUFDaEIsTUFDQTtFQUVKLElBQUksVUFBVSxJQUFJO0dBQ2hCLElBQUksVUFBVSxNQUFNLEtBQUssZUFBZSxPQUFPLFVBQVUsSUFBSSxLQUFBLEdBQVcsSUFBSTtHQUU1RSxRQUFRLEtBQVI7SUFDRSxLQUFLLEdBQUcsT0FBTyxVQUFVLEdBQUcsS0FBSyxVQUFVLE9BQU8sR0FBRztJQUNyRCxLQUFLLEdBQUcsT0FBTyxVQUFVLEdBQUcsS0FBSyxVQUFVLFNBQVMsRUFBRSxHQUFHO0lBQ3pELEtBQUssR0FBRyxPQUFPLFVBQVUsR0FBRyxLQUFLLFVBQVUsU0FBUyxJQUFJLEVBQUUsR0FBRztJQUM3RCxLQUFLLEdBQUcsT0FBTyxVQUFVLEdBQUcsS0FBSyxVQUFVLFNBQVMsSUFBSSxJQUFJLEVBQUUsR0FBRztJQUNqRSxLQUFLLEdBQUcsT0FBTyxVQUFVLEdBQUcsS0FBSyxVQUFVLFNBQVMsSUFBSSxJQUFJLElBQUksRUFBRSxHQUFHO0lBQ3JFLEtBQUssR0FBRyxPQUFPLFVBQVUsR0FBRyxLQUFLLFVBQVUsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUUsR0FBRztHQUMzRTtHQUVBLEtBQUssSUFBSSxHQUFHLE9BQU8sSUFBSSxNQUFNLE1BQUssQ0FBQyxHQUFHLElBQUksS0FBSyxLQUM3QyxLQUFLLElBQUksS0FBSyxVQUFVO0dBRzFCLFVBQVUsR0FBRyxNQUFNLFVBQVUsU0FBUyxJQUFJO0VBQzVDLE9BQU87R0FDTCxJQUFJLFNBQVMsVUFBVSxRQUNuQjtHQUVKLEtBQUssSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO0lBQzNCLElBQUksVUFBVSxFQUFFLENBQUMsTUFBTSxLQUFLLGVBQWUsT0FBTyxVQUFVLEVBQUUsQ0FBQyxJQUFJLEtBQUEsR0FBVyxJQUFJO0lBRWxGLFFBQVEsS0FBUjtLQUNFLEtBQUs7TUFBRyxVQUFVLEVBQUUsQ0FBQyxHQUFHLEtBQUssVUFBVSxFQUFFLENBQUMsT0FBTztNQUFHO0tBQ3BELEtBQUs7TUFBRyxVQUFVLEVBQUUsQ0FBQyxHQUFHLEtBQUssVUFBVSxFQUFFLENBQUMsU0FBUyxFQUFFO01BQUc7S0FDeEQsS0FBSztNQUFHLFVBQVUsRUFBRSxDQUFDLEdBQUcsS0FBSyxVQUFVLEVBQUUsQ0FBQyxTQUFTLElBQUksRUFBRTtNQUFHO0tBQzVELEtBQUs7TUFBRyxVQUFVLEVBQUUsQ0FBQyxHQUFHLEtBQUssVUFBVSxFQUFFLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRTtNQUFHO0tBQ2hFO01BQ0UsSUFBSSxDQUFDLE1BQU0sS0FBSyxJQUFJLEdBQUcsT0FBTyxJQUFJLE1BQU0sTUFBSyxDQUFDLEdBQUcsSUFBSSxLQUFLLEtBQ3hELEtBQUssSUFBSSxLQUFLLFVBQVU7TUFHMUIsVUFBVSxFQUFFLENBQUMsR0FBRyxNQUFNLFVBQVUsRUFBRSxDQUFDLFNBQVMsSUFBSTtJQUNwRDtHQUNGO0VBQ0Y7RUFFQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Q0FXQSxhQUFhLFVBQVUsS0FBSyxTQUFTLEdBQUcsT0FBTyxJQUFJLFNBQVM7RUFDMUQsT0FBTyxZQUFZLE1BQU0sT0FBTyxJQUFJLFNBQVMsS0FBSztDQUNwRDs7Ozs7Ozs7OztDQVdBLGFBQWEsVUFBVSxPQUFPLFNBQVMsS0FBSyxPQUFPLElBQUksU0FBUztFQUM5RCxPQUFPLFlBQVksTUFBTSxPQUFPLElBQUksU0FBUyxJQUFJO0NBQ25EOzs7Ozs7Ozs7OztDQVlBLGFBQWEsVUFBVSxpQkFBaUIsU0FBUyxlQUFlLE9BQU8sSUFBSSxTQUFTLE1BQU07RUFDeEYsSUFBSSxNQUFNLFNBQVMsU0FBUyxRQUFRO0VBRXBDLElBQUksQ0FBQyxLQUFLLFFBQVEsTUFBTSxPQUFPO0VBQy9CLElBQUksQ0FBQyxJQUFJO0dBQ1AsV0FBVyxNQUFNLEdBQUc7R0FDcEIsT0FBTztFQUNUO0VBRUEsSUFBSSxZQUFZLEtBQUssUUFBUTtFQUU3QixJQUFJLFVBQVUsSUFFVjtPQUFBLFVBQVUsT0FBTyxPQUNoQixDQUFDLFFBQVEsVUFBVSxVQUNuQixDQUFDLFdBQVcsVUFBVSxZQUFZLFVBRW5DLFdBQVcsTUFBTSxHQUFHO0VBQUEsT0FFakI7R0FDTCxLQUFLLElBQUksSUFBSSxHQUFHLFNBQVMsQ0FBQyxHQUFHLFNBQVMsVUFBVSxRQUFRLElBQUksUUFBUSxLQUNsRSxJQUNFLFVBQVUsRUFBRSxDQUFDLE9BQU8sTUFDbkIsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQ3RCLFdBQVcsVUFBVSxFQUFFLENBQUMsWUFBWSxTQUVyQyxPQUFPLEtBQUssVUFBVSxFQUFFO0dBTzVCLElBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxPQUFPLE9BQU8sV0FBVyxJQUFJLE9BQU8sS0FBSztRQUNwRSxXQUFXLE1BQU0sR0FBRztFQUMzQjtFQUVBLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FTQSxhQUFhLFVBQVUscUJBQXFCLFNBQVMsbUJBQW1CLE9BQU87RUFDN0UsSUFBSTtFQUVKLElBQUksT0FBTztHQUNULE1BQU0sU0FBUyxTQUFTLFFBQVE7R0FDaEMsSUFBSSxLQUFLLFFBQVEsTUFBTSxXQUFXLE1BQU0sR0FBRztFQUM3QyxPQUFPO0dBQ0wsS0FBSyxVQUFVLElBQUksT0FBTztHQUMxQixLQUFLLGVBQWU7RUFDdEI7RUFFQSxPQUFPO0NBQ1Q7Q0FLQSxhQUFhLFVBQVUsTUFBTSxhQUFhLFVBQVU7Q0FDcEQsYUFBYSxVQUFVLGNBQWMsYUFBYSxVQUFVO0NBSzVELGFBQWEsV0FBVztDQUt4QixhQUFhLGVBQWU7Q0FLNUIsSUFBSSxnQkFBZ0IsT0FBTyxRQUN6QixPQUFPLFVBQVU7U0MzVUpBLEVBQUFBLENBQUFBOzs7QUNGZixJQUFNLE9BQU8sS0FBSyxLQUFLO0FBQ3ZCLElBQU0sYUFBYSxNQUFNLEtBQUs7QUFDOUIsSUFBTSxhQUFhLEtBQUssS0FBSzs7O0FDRjdCLElBQU0sUUFBTixNQUFNLE1BQU07Ozs7OztDQU1WLFlBQVksSUFBSSxHQUFHLElBQUksR0FBRzs7Ozs7Ozs7Ozs7OztFQWF4QixLQUFLLElBQUk7Ozs7Ozs7Ozs7Ozs7RUFhVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7Q0FDWDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQkEsUUFBUTtFQUNOLE9BQU8sSUFBSSxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUM7Q0FDakM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXdCQSxTQUFTLEdBQUc7RUFDVixLQUFLLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztFQUNqQixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7OztDQWVBLE9BQU8sR0FBRztFQUNSLEVBQUUsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlCQSxPQUFPLEdBQUc7RUFDUixPQUFPLEVBQUUsTUFBTSxLQUFLLEtBQUssRUFBRSxNQUFNLEtBQUs7Q0FDeEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F5QkEsSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHO0VBQ2hCLEtBQUssSUFBSTtFQUNULEtBQUssSUFBSTtFQUNULE9BQU87Q0FDVDtDQUNBLFdBQVc7RUFDVCxPQUFPLHlCQUF5QixLQUFLLEVBQUUsS0FBSyxLQUFLLEVBQUU7Q0FDckQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsV0FBVyxTQUFTO0VBQ2xCLFVBQVUsSUFBSTtFQUNkLFVBQVUsSUFBSTtFQUNkLE9BQU87Q0FDVDtBQUNGO0FBQ0EsSUFBTSxZQUFZLElBQUksTUFBTTs7O0FDaE01QixJQUFNLFNBQU4sTUFBTSxPQUFPOzs7Ozs7Ozs7Q0FTWCxZQUFZLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHOzs7Ozs7O0VBT3RELEtBQUssUUFBUTtFQUNiLEtBQUssSUFBSTtFQUNULEtBQUssSUFBSTtFQUNULEtBQUssSUFBSTtFQUNULEtBQUssSUFBSTtFQUNULEtBQUssS0FBSztFQUNWLEtBQUssS0FBSztDQUNaOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0NBLFVBQVUsT0FBTztFQUNmLEtBQUssSUFBSSxNQUFNO0VBQ2YsS0FBSyxJQUFJLE1BQU07RUFDZixLQUFLLElBQUksTUFBTTtFQUNmLEtBQUssSUFBSSxNQUFNO0VBQ2YsS0FBSyxLQUFLLE1BQU07RUFDaEIsS0FBSyxLQUFLLE1BQU07Q0FDbEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F5QkEsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksSUFBSTtFQUN0QixLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLEtBQUs7RUFDVixLQUFLLEtBQUs7RUFDVixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUNBLFFBQVEsV0FBVyxLQUFLO0VBQ3RCLElBQUksQ0FBQyxLQUFLLE9BQ1IsS0FBSyx3QkFBUSxJQUFJLGFBQWEsQ0FBQztFQUVqQyxNQUFNLFFBQVEsT0FBTyxLQUFLO0VBQzFCLElBQUksV0FBVztHQUNiLE1BQU0sS0FBSyxLQUFLO0dBQ2hCLE1BQU0sS0FBSyxLQUFLO0dBQ2hCLE1BQU0sS0FBSztHQUNYLE1BQU0sS0FBSyxLQUFLO0dBQ2hCLE1BQU0sS0FBSyxLQUFLO0dBQ2hCLE1BQU0sS0FBSztHQUNYLE1BQU0sS0FBSyxLQUFLO0dBQ2hCLE1BQU0sS0FBSyxLQUFLO0dBQ2hCLE1BQU0sS0FBSztFQUNiLE9BQU87R0FDTCxNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUs7R0FDWCxNQUFNLEtBQUs7R0FDWCxNQUFNLEtBQUs7RUFDYjtFQUNBLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxNQUFNLEtBQUssUUFBUTtFQUNqQixTQUFTLFVBQVUsSUFBSSxNQUFNO0VBQzdCLE1BQU0sSUFBSSxJQUFJO0VBQ2QsTUFBTSxJQUFJLElBQUk7RUFDZCxPQUFPLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksS0FBSztFQUMxQyxPQUFPLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksS0FBSztFQUMxQyxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJBLGFBQWEsS0FBSyxRQUFRO0VBQ3hCLFNBQVMsVUFBVSxJQUFJLE1BQU07RUFDN0IsTUFBTSxJQUFJLEtBQUs7RUFDZixNQUFNLElBQUksS0FBSztFQUNmLE1BQU0sSUFBSSxLQUFLO0VBQ2YsTUFBTSxJQUFJLEtBQUs7RUFDZixNQUFNLEtBQUssS0FBSztFQUNoQixNQUFNLEtBQUssS0FBSztFQUNoQixNQUFNLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDO0VBQzdCLE1BQU0sSUFBSSxJQUFJO0VBQ2QsTUFBTSxJQUFJLElBQUk7RUFDZCxPQUFPLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLO0VBQzFELE9BQU8sSUFBSSxJQUFJLEtBQUssSUFBSSxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsS0FBSyxJQUFJLEtBQUssS0FBSztFQUMzRCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsVUFBVSxHQUFHLEdBQUc7RUFDZCxLQUFLLE1BQU07RUFDWCxLQUFLLE1BQU07RUFDWCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsTUFBTSxHQUFHLEdBQUc7RUFDVixLQUFLLEtBQUs7RUFDVixLQUFLLEtBQUs7RUFDVixLQUFLLEtBQUs7RUFDVixLQUFLLEtBQUs7RUFDVixLQUFLLE1BQU07RUFDWCxLQUFLLE1BQU07RUFDWCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBZ0NBLE9BQU8sT0FBTztFQUNaLE1BQU0sTUFBTSxLQUFLLElBQUksS0FBSztFQUMxQixNQUFNLE1BQU0sS0FBSyxJQUFJLEtBQUs7RUFDMUIsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxNQUFNLEtBQUs7RUFDakIsS0FBSyxJQUFJLEtBQUssTUFBTSxLQUFLLElBQUk7RUFDN0IsS0FBSyxJQUFJLEtBQUssTUFBTSxLQUFLLElBQUk7RUFDN0IsS0FBSyxJQUFJLEtBQUssTUFBTSxLQUFLLElBQUk7RUFDN0IsS0FBSyxJQUFJLEtBQUssTUFBTSxLQUFLLElBQUk7RUFDN0IsS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEtBQUs7RUFDaEMsS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEtBQUs7RUFDaEMsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsT0FBTyxRQUFRO0VBQ2IsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxLQUFLLEtBQUs7RUFDaEIsTUFBTSxLQUFLLEtBQUs7RUFDaEIsS0FBSyxJQUFJLE9BQU8sSUFBSSxLQUFLLE9BQU8sSUFBSTtFQUNwQyxLQUFLLElBQUksT0FBTyxJQUFJLEtBQUssT0FBTyxJQUFJO0VBQ3BDLEtBQUssSUFBSSxPQUFPLElBQUksS0FBSyxPQUFPLElBQUk7RUFDcEMsS0FBSyxJQUFJLE9BQU8sSUFBSSxLQUFLLE9BQU8sSUFBSTtFQUNwQyxLQUFLLEtBQUssT0FBTyxLQUFLLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSztFQUNqRCxLQUFLLEtBQUssT0FBTyxLQUFLLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSztFQUNqRCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLFdBQVcsR0FBRyxHQUFHO0VBQ2YsTUFBTSxLQUFLLEVBQUU7RUFDYixNQUFNLEtBQUssRUFBRTtFQUNiLE1BQU0sS0FBSyxFQUFFO0VBQ2IsTUFBTSxLQUFLLEVBQUU7RUFDYixNQUFNLEtBQUssRUFBRTtFQUNiLE1BQU0sS0FBSyxFQUFFO0VBQ2IsTUFBTSxLQUFLLEVBQUU7RUFDYixNQUFNLEtBQUssRUFBRTtFQUNiLE1BQU0sS0FBSyxFQUFFO0VBQ2IsTUFBTSxLQUFLLEVBQUU7RUFDYixLQUFLLElBQUksS0FBSyxLQUFLLEtBQUs7RUFDeEIsS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLO0VBQ3hCLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSztFQUN4QixLQUFLLElBQUksS0FBSyxLQUFLLEtBQUs7RUFDeEIsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssRUFBRTtFQUNoQyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxFQUFFO0VBQ2hDLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtDQSxhQUFhLEdBQUcsR0FBRyxRQUFRLFFBQVEsUUFBUSxRQUFRLFVBQVUsT0FBTyxPQUFPO0VBQ3pFLEtBQUssSUFBSSxLQUFLLElBQUksV0FBVyxLQUFLLElBQUk7RUFDdEMsS0FBSyxJQUFJLEtBQUssSUFBSSxXQUFXLEtBQUssSUFBSTtFQUN0QyxLQUFLLElBQUksQ0FBQyxLQUFLLElBQUksV0FBVyxLQUFLLElBQUk7RUFDdkMsS0FBSyxJQUFJLEtBQUssSUFBSSxXQUFXLEtBQUssSUFBSTtFQUN0QyxLQUFLLEtBQUssS0FBSyxTQUFTLEtBQUssSUFBSSxTQUFTLEtBQUs7RUFDL0MsS0FBSyxLQUFLLEtBQUssU0FBUyxLQUFLLElBQUksU0FBUyxLQUFLO0VBQy9DLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvQkEsUUFBUSxRQUFRO0VBQ2QsTUFBTSxNQUFNLEtBQUs7RUFDakIsSUFBSSxPQUFPLE1BQU0sS0FBSyxPQUFPLE1BQU0sS0FBSyxPQUFPLE1BQU0sS0FBSyxPQUFPLE1BQU0sR0FBRztHQUN4RSxNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUssS0FBSztHQUNoQixLQUFLLElBQUksS0FBSyxPQUFPLElBQUksS0FBSyxJQUFJLE9BQU87R0FDekMsS0FBSyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUssSUFBSSxPQUFPO0dBQ3pDLEtBQUssSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLLElBQUksT0FBTztHQUN6QyxLQUFLLElBQUksS0FBSyxPQUFPLElBQUksS0FBSyxJQUFJLE9BQU87RUFDM0M7RUFDQSxLQUFLLEtBQUssTUFBTSxPQUFPLElBQUksS0FBSyxLQUFLLE9BQU8sSUFBSSxPQUFPO0VBQ3ZELEtBQUssS0FBSyxNQUFNLE9BQU8sSUFBSSxLQUFLLEtBQUssT0FBTyxJQUFJLE9BQU87RUFDdkQsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1DQSxVQUFVLFdBQVc7RUFDbkIsTUFBTSxJQUFJLEtBQUs7RUFDZixNQUFNLElBQUksS0FBSztFQUNmLE1BQU0sSUFBSSxLQUFLO0VBQ2YsTUFBTSxJQUFJLEtBQUs7RUFDZixNQUFNLFFBQVEsVUFBVTtFQUN4QixNQUFNLFFBQVEsQ0FBQyxLQUFLLE1BQU0sQ0FBQyxHQUFHLENBQUM7RUFDL0IsTUFBTSxRQUFRLEtBQUssTUFBTSxHQUFHLENBQUM7RUFDN0IsTUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRLEtBQUs7RUFDcEMsSUFBSSxTQUFTLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDO0VBQ3BDLElBQUksUUFBUSxRQUFRLEtBQUssSUFBSSxPQUFPLEtBQUssSUFBSSxNQUFNO0dBQ2pELFVBQVUsV0FBVztHQUNyQixVQUFVLEtBQUssSUFBSSxVQUFVLEtBQUssSUFBSTtFQUN4QyxPQUFPLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLElBQUksTUFBTTtHQUMzQyxVQUFVLFdBQVcsUUFBUSxLQUFLO0dBQ2xDLFVBQVUsS0FBSyxJQUFJLFVBQVUsS0FBSyxJQUFJO0dBQ3RDLFNBQVMsQ0FBQztFQUNaLE9BQU87R0FDTCxVQUFVLFdBQVc7R0FDckIsVUFBVSxLQUFLLElBQUk7R0FDbkIsVUFBVSxLQUFLLElBQUk7RUFDckI7RUFDQSxVQUFVLE1BQU0sSUFBSTtFQUNwQixVQUFVLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQztFQUMzQyxVQUFVLFNBQVMsSUFBSSxLQUFLLE1BQU0sTUFBTSxJQUFJLElBQUksTUFBTSxJQUFJO0VBQzFELFVBQVUsU0FBUyxJQUFJLEtBQUssTUFBTSxNQUFNLElBQUksSUFBSSxNQUFNLElBQUk7RUFDMUQsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EyQkEsU0FBUztFQUNQLE1BQU0sS0FBSyxLQUFLO0VBQ2hCLE1BQU0sS0FBSyxLQUFLO0VBQ2hCLE1BQU0sS0FBSyxLQUFLO0VBQ2hCLE1BQU0sS0FBSyxLQUFLO0VBQ2hCLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLE1BQU0sSUFBSSxLQUFLLEtBQUssS0FBSztFQUN6QixLQUFLLElBQUksS0FBSztFQUNkLEtBQUssSUFBSSxDQUFDLEtBQUs7RUFDZixLQUFLLElBQUksQ0FBQyxLQUFLO0VBQ2YsS0FBSyxJQUFJLEtBQUs7RUFDZCxLQUFLLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSyxPQUFPO0VBQ3RDLEtBQUssS0FBSyxFQUFFLEtBQUssS0FBSyxLQUFLLEtBQUssT0FBTztFQUN2QyxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJCQSxhQUFhO0VBQ1gsT0FBTyxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLE9BQU8sS0FBSyxLQUFLLE9BQU87Q0FDdEc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNkJBLFdBQVc7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxLQUFLLEtBQUs7RUFDVixLQUFLLEtBQUs7RUFDVixPQUFPO0NBQ1Q7Ozs7O0NBS0EsUUFBUTtFQUNOLE1BQU0sU0FBUyxJQUFJLE9BQU87RUFDMUIsT0FBTyxJQUFJLEtBQUs7RUFDaEIsT0FBTyxJQUFJLEtBQUs7RUFDaEIsT0FBTyxJQUFJLEtBQUs7RUFDaEIsT0FBTyxJQUFJLEtBQUs7RUFDaEIsT0FBTyxLQUFLLEtBQUs7RUFDakIsT0FBTyxLQUFLLEtBQUs7RUFDakIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3QkEsT0FBTyxRQUFRO0VBQ2IsT0FBTyxJQUFJLEtBQUs7RUFDaEIsT0FBTyxJQUFJLEtBQUs7RUFDaEIsT0FBTyxJQUFJLEtBQUs7RUFDaEIsT0FBTyxJQUFJLEtBQUs7RUFDaEIsT0FBTyxLQUFLLEtBQUs7RUFDakIsT0FBTyxLQUFLLEtBQUs7RUFDakIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxTQUFTLFFBQVE7RUFDZixLQUFLLElBQUksT0FBTztFQUNoQixLQUFLLElBQUksT0FBTztFQUNoQixLQUFLLElBQUksT0FBTztFQUNoQixLQUFLLElBQUksT0FBTztFQUNoQixLQUFLLEtBQUssT0FBTztFQUNqQixLQUFLLEtBQUssT0FBTztFQUNqQixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLE9BQU8sUUFBUTtFQUNiLE9BQU8sT0FBTyxNQUFNLEtBQUssS0FBSyxPQUFPLE1BQU0sS0FBSyxLQUFLLE9BQU8sTUFBTSxLQUFLLEtBQUssT0FBTyxNQUFNLEtBQUssS0FBSyxPQUFPLE9BQU8sS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLO0NBQ2pKO0NBQ0EsV0FBVztFQUNULE9BQU8scUJBQXFCLEtBQUssRUFBRSxLQUFLLEtBQUssRUFBRSxLQUFLLEtBQUssRUFBRSxLQUFLLEtBQUssRUFBRSxNQUFNLEtBQUssR0FBRyxNQUFNLEtBQUssR0FBRztDQUNyRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlCQSxXQUFXLFdBQVc7RUFDcEIsT0FBTyxlQUFlLFNBQVM7Q0FDakM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJBLFdBQVcsU0FBUztFQUNsQixPQUFPLFdBQVcsU0FBUztDQUM3QjtBQUNGO0FBQ0EsSUFBTSxhQUFhLElBQUksT0FBTztBQUM5QixJQUFNLGlCQUFpQixJQUFJLE9BQU87OztBQ3J5QmxDLElBQU0sS0FBSztDQUFDO0NBQUc7Q0FBRztDQUFHO0NBQUk7Q0FBSTtDQUFJO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFJO0NBQUk7Q0FBSTtDQUFHO0FBQUM7QUFDaEUsSUFBTSxLQUFLO0NBQUM7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUk7Q0FBSTtDQUFJO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFJO0NBQUk7QUFBRTtBQUNoRSxJQUFNLEtBQUs7Q0FBQztDQUFHO0NBQUk7Q0FBSTtDQUFJO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUk7Q0FBSTtBQUFFO0FBQ2hFLElBQU0sS0FBSztDQUFDO0NBQUc7Q0FBRztDQUFHO0NBQUk7Q0FBSTtDQUFJO0NBQUc7Q0FBRztDQUFJO0NBQUk7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0FBQUU7QUFDaEUsSUFBTSxpQkFBaUIsQ0FBQztBQUN4QixJQUFNLG1CQUFtQixDQUFDO0FBQzFCLElBQU0sU0FBUyxLQUFLO0FBQ3BCLFNBQVMsT0FBTztDQUNkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7RUFDM0IsTUFBTSxNQUFNLENBQUM7RUFDYixlQUFlLEtBQUssR0FBRztFQUN2QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0dBQzNCLE1BQU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsRUFBRTtHQUNoRCxNQUFNLE1BQU0sT0FBTyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEVBQUU7R0FDaEQsTUFBTSxNQUFNLE9BQU8sR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxFQUFFO0dBQ2hELE1BQU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsRUFBRTtHQUNoRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUN0QixJQUFJLEdBQUcsT0FBTyxPQUFPLEdBQUcsT0FBTyxPQUFPLEdBQUcsT0FBTyxPQUFPLEdBQUcsT0FBTyxLQUFLO0lBQ3BFLElBQUksS0FBSyxDQUFDO0lBQ1Y7R0FDRjtFQUVKO0NBQ0Y7Q0FDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0VBQzNCLE1BQU0sTUFBTSxJQUFJLE9BQU87RUFDdkIsSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLENBQUM7RUFDeEMsaUJBQWlCLEtBQUssR0FBRztDQUMzQjtBQUNGO0FBQ0EsS0FBSztBQUNMLElBQU0sVUFBVTs7Ozs7Ozs7Q0FRZCxHQUFHOzs7Ozs7OztDQVFILElBQUk7Ozs7Ozs7O0NBUUosR0FBRzs7Ozs7Ozs7Q0FRSCxJQUFJOzs7Ozs7OztDQVFKLEdBQUc7Ozs7Ozs7O0NBUUgsSUFBSTs7Ozs7Ozs7Q0FRSixHQUFHOzs7Ozs7OztDQVFILElBQUk7Ozs7OztDQU1KLGlCQUFpQjs7Ozs7O0NBTWpCLGVBQWU7Ozs7OztDQU1mLG1CQUFtQjs7Ozs7O0NBTW5CLGtCQUFrQjs7Ozs7OztDQU9sQixLQUFLLFFBQVEsR0FBRzs7Ozs7OztDQU9oQixLQUFLLFFBQVEsR0FBRzs7Ozs7OztDQU9oQixLQUFLLFFBQVEsR0FBRzs7Ozs7OztDQU9oQixLQUFLLFFBQVEsR0FBRzs7Ozs7Ozs7Q0FRaEIsTUFBTSxhQUFhO0VBQ2pCLElBQUksV0FBVyxHQUNiLE9BQU8sV0FBVztFQUVwQixPQUFPLENBQUMsV0FBVztDQUNyQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlCQSxNQUFNLGdCQUFnQixrQkFBa0IsZUFBZSxlQUFlLENBQUM7Ozs7Ozs7O0NBUXZFLE1BQU0sZ0JBQWdCLGtCQUFrQixlQUFlLGVBQWUsQ0FBQyxRQUFRLElBQUksYUFBYTs7Ozs7Ozs7Q0FRaEcsWUFBWSxhQUFhLFdBQVc7Ozs7Ozs7O0NBUXBDLGFBQWEsY0FBYyxXQUFXLE9BQU87Ozs7Ozs7Ozs7Q0FXN0MsY0FBYyxJQUFJLE9BQU87RUFDdkIsSUFBSSxLQUFLLElBQUksRUFBRSxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUUsR0FBRztHQUNwQyxJQUFJLE1BQU0sR0FDUixPQUFPLFFBQVE7R0FFakIsT0FBTyxRQUFRO0VBQ2pCLE9BQU8sSUFBSSxLQUFLLElBQUksRUFBRSxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUUsR0FBRztHQUMzQyxJQUFJLEtBQUssR0FDUCxPQUFPLFFBQVE7R0FFakIsT0FBTyxRQUFRO0VBQ2pCLE9BQU8sSUFBSSxLQUFLLEdBQUc7R0FDakIsSUFBSSxLQUFLLEdBQ1AsT0FBTyxRQUFRO0dBRWpCLE9BQU8sUUFBUTtFQUNqQixPQUFPLElBQUksS0FBSyxHQUNkLE9BQU8sUUFBUTtFQUVqQixPQUFPLFFBQVE7Q0FDakI7Ozs7Ozs7Ozs7O0NBV0EsMEJBQTBCLFFBQVEsVUFBVSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLE1BQU07RUFDN0UsTUFBTSxNQUFNLGlCQUFpQixRQUFRLElBQUksUUFBUTtFQUNqRCxNQUFNLElBQUksSUFBSTtFQUNkLE1BQU0sSUFBSSxJQUFJO0VBQ2QsTUFBTSxJQUFJLElBQUk7RUFDZCxNQUFNLElBQUksSUFBSTtFQUNkLE1BQU0sVUFBVSxLQUFLLEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksRUFBRTtFQUNoRSxNQUFNLFVBQVUsS0FBSyxLQUFLLElBQUksR0FBRyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLEVBQUU7RUFDaEUsTUFBTSxLQUFLLE9BQU87RUFDbEIsTUFBTSxLQUFLLE9BQU87RUFDbEIsTUFBTSxLQUFLLE9BQU87RUFDbEIsTUFBTSxLQUFLLE9BQU87RUFDbEIsT0FBTyxJQUFJLElBQUksS0FBSyxJQUFJO0VBQ3hCLE9BQU8sSUFBSSxJQUFJLEtBQUssSUFBSTtFQUN4QixPQUFPLElBQUksSUFBSSxLQUFLLElBQUk7RUFDeEIsT0FBTyxJQUFJLElBQUksS0FBSyxJQUFJO0VBQ3hCLE9BQU8sS0FBSyxVQUFVLEtBQUssVUFBVSxLQUFLLE9BQU87RUFDakQsT0FBTyxLQUFLLFVBQVUsS0FBSyxVQUFVLEtBQUssT0FBTztDQUNuRDs7Ozs7Ozs7Ozs7Q0FXQSxzQkFBc0IsTUFBTSxhQUFhLFVBQVUsUUFBUTtFQUN6RCxNQUFNLEVBQUUsR0FBRyxHQUFHLE9BQU8sV0FBVztFQUNoQyxNQUFNLEVBQUUsR0FBRyxRQUFRLEdBQUcsUUFBUSxPQUFPLFlBQVksUUFBUSxnQkFBZ0I7RUFDekUsSUFBSSxhQUFhLFFBQVEsR0FBRztHQUMxQixJQUFJLElBQUksSUFBSSxRQUFRLElBQUksUUFBUSxPQUFPLE1BQU07R0FDN0MsT0FBTztFQUNULE9BQU8sSUFBSSxhQUFhLFFBQVEsR0FDOUIsT0FBTyxJQUFJLElBQ1QsYUFBYSxJQUFJLFNBQVMsUUFDMUIsSUFBSSxRQUNKLFFBQ0EsS0FDRjtPQUNLLElBQUksYUFBYSxRQUFRLEdBQzlCLE9BQU8sSUFBSSxJQUNULGFBQWEsSUFBSSxRQUFRLFFBQ3pCLGNBQWMsSUFBSSxTQUFTLFFBQzNCLE9BQ0EsTUFDRjtPQUNLLElBQUksYUFBYSxRQUFRLEdBQzlCLE9BQU8sSUFBSSxJQUNULElBQUksUUFDSixjQUFjLElBQUksUUFBUSxRQUMxQixRQUNBLEtBQ0Y7RUFFRixPQUFPLElBQUksSUFBSSxJQUFJLFFBQVEsSUFBSSxRQUFRLE9BQU8sTUFBTTtDQUN0RDtBQUNGOzs7QUN0VEEsSUFBTSxhQUFhO0NBQUMsSUFBSSxNQUFNO0NBQUcsSUFBSSxNQUFNO0NBQUcsSUFBSSxNQUFNO0NBQUcsSUFBSSxNQUFNO0FBQUM7QUFDdEUsSUFBTSxZQUFOLE1BQU0sVUFBVTs7Ozs7OztDQU9kLFlBQVksSUFBSSxHQUFHLElBQUksR0FBRyxRQUFRLEdBQUcsU0FBUyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFrQi9DLEtBQUssT0FBTztFQUNaLEtBQUssSUFBSSxPQUFPLENBQUM7RUFDakIsS0FBSyxJQUFJLE9BQU8sQ0FBQztFQUNqQixLQUFLLFFBQVEsT0FBTyxLQUFLO0VBQ3pCLEtBQUssU0FBUyxPQUFPLE1BQU07Q0FDN0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsSUFBSSxPQUFPO0VBQ1QsT0FBTyxLQUFLO0NBQ2Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLElBQUksS0FBSztDQUN2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxJQUFJLE1BQU07RUFDUixPQUFPLEtBQUs7Q0FDZDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUssSUFBSSxLQUFLO0NBQ3ZCOzs7Ozs7Ozs7Ozs7O0NBYUEsVUFBVTtFQUNSLE9BQU8sS0FBSyxTQUFTLEtBQUssU0FBUyxLQUFLLFFBQVEsS0FBSztDQUN2RDs7Ozs7Ozs7Ozs7O0NBWUEsV0FBVyxRQUFRO0VBQ2pCLE9BQU8sSUFBSSxVQUFVLEdBQUcsR0FBRyxHQUFHLENBQUM7Q0FDakM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsUUFBUTtFQUNOLE9BQU8sSUFBSSxVQUFVLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxPQUFPLEtBQUssTUFBTTtDQUM5RDs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxlQUFlLFFBQVE7RUFDckIsS0FBSyxJQUFJLE9BQU87RUFDaEIsS0FBSyxJQUFJLE9BQU87RUFDaEIsS0FBSyxRQUFRLE9BQU8sT0FBTyxPQUFPO0VBQ2xDLEtBQUssU0FBUyxPQUFPLE9BQU8sT0FBTztFQUNuQyxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0JBLFNBQVMsV0FBVztFQUNsQixLQUFLLElBQUksVUFBVTtFQUNuQixLQUFLLElBQUksVUFBVTtFQUNuQixLQUFLLFFBQVEsVUFBVTtFQUN2QixLQUFLLFNBQVMsVUFBVTtFQUN4QixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0JBLE9BQU8sV0FBVztFQUNoQixVQUFVLFNBQVMsSUFBSTtFQUN2QixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxTQUFTLEdBQUcsR0FBRztFQUNiLElBQUksS0FBSyxTQUFTLEtBQUssS0FBSyxVQUFVLEdBQ3BDLE9BQU87RUFFVCxJQUFJLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssT0FDL0I7T0FBQSxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLFFBQ25DLE9BQU87RUFBQTtFQUdYLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxlQUFlLEdBQUcsR0FBRyxhQUFhLFlBQVksSUFBSztFQUNqRCxNQUFNLEVBQUUsT0FBTyxXQUFXO0VBQzFCLElBQUksU0FBUyxLQUFLLFVBQVUsR0FBRyxPQUFPO0VBQ3RDLE1BQU0sS0FBSyxLQUFLO0VBQ2hCLE1BQU0sS0FBSyxLQUFLO0VBQ2hCLE1BQU0sbUJBQW1CLGVBQWUsSUFBSTtFQUM1QyxNQUFNLG1CQUFtQixjQUFjO0VBQ3ZDLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLE1BQU0sYUFBYSxLQUFLLFFBQVE7RUFDaEMsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxjQUFjLEtBQUssU0FBUztFQUNsQyxNQUFNLFlBQVksS0FBSztFQUN2QixNQUFNLGFBQWEsS0FBSyxRQUFRO0VBQ2hDLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLE1BQU0sY0FBYyxLQUFLLFNBQVM7RUFDbEMsT0FBTyxLQUFLLGFBQWEsS0FBSyxjQUFjLEtBQUssWUFBWSxLQUFLLGVBQWUsRUFBRSxJQUFJLGFBQWEsSUFBSSxjQUFjLElBQUksWUFBWSxJQUFJO0NBQzVJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQ0EsV0FBVyxPQUFPLFdBQVc7RUFDM0IsSUFBSSxDQUFDLFdBQVc7R0FDZCxNQUFNLE1BQU0sS0FBSyxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUksS0FBSztHQUU5QyxLQURZLEtBQUssUUFBUSxNQUFNLFFBQVEsTUFBTSxRQUFRLEtBQUssVUFDL0MsS0FDVCxPQUFPO0dBRVQsTUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLEtBQUs7R0FFOUMsUUFEWSxLQUFLLFNBQVMsTUFBTSxTQUFTLE1BQU0sU0FBUyxLQUFLLFVBQ2hEO0VBQ2Y7RUFDQSxNQUFNLEtBQUssS0FBSztFQUNoQixNQUFNLEtBQUssS0FBSztFQUNoQixNQUFNLEtBQUssS0FBSztFQUNoQixNQUFNLEtBQUssS0FBSztFQUNoQixJQUFJLE1BQU0sTUFBTSxNQUFNLElBQ3BCLE9BQU87RUFFVCxNQUFNLEtBQUssV0FBVyxFQUFFLENBQUMsSUFBSSxNQUFNLE1BQU0sTUFBTSxHQUFHO0VBQ2xELE1BQU0sS0FBSyxXQUFXLEVBQUUsQ0FBQyxJQUFJLE1BQU0sTUFBTSxNQUFNLE1BQU07RUFDckQsTUFBTSxLQUFLLFdBQVcsRUFBRSxDQUFDLElBQUksTUFBTSxPQUFPLE1BQU0sR0FBRztFQUNuRCxNQUFNLEtBQUssV0FBVyxFQUFFLENBQUMsSUFBSSxNQUFNLE9BQU8sTUFBTSxNQUFNO0VBQ3RELElBQUksR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxHQUM3QixPQUFPO0VBRVQsTUFBTSxJQUFJLEtBQUssS0FBSyxVQUFVLElBQUksVUFBVSxJQUFJLFVBQVUsSUFBSSxVQUFVLENBQUM7RUFDekUsSUFBSSxNQUFNLEdBQ1IsT0FBTztFQUVULFVBQVUsTUFBTSxJQUFJLEVBQUU7RUFDdEIsVUFBVSxNQUFNLElBQUksRUFBRTtFQUN0QixVQUFVLE1BQU0sSUFBSSxFQUFFO0VBQ3RCLFVBQVUsTUFBTSxJQUFJLEVBQUU7RUFDdEIsSUFBSSxLQUFLLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQUssTUFBTSxLQUFLLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQUssTUFBTSxLQUFLLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQUssTUFBTSxLQUFLLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQUssSUFDcEssT0FBTztFQUVULE1BQU0sS0FBSyxLQUFLLEdBQUcsSUFBSSxHQUFHO0VBQzFCLE1BQU0sS0FBSyxLQUFLLEdBQUcsSUFBSSxHQUFHO0VBQzFCLE1BQU0sTUFBTSxLQUFLLEtBQUssS0FBSztFQUMzQixNQUFNLE1BQU0sS0FBSyxLQUFLLEtBQUs7RUFDM0IsTUFBTSxNQUFNLEtBQUssS0FBSyxLQUFLO0VBQzNCLE1BQU0sTUFBTSxLQUFLLEtBQUssS0FBSztFQUMzQixJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLElBQUksS0FBSyxHQUFHLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUcsR0FDL0csT0FBTztFQUVULE1BQU0sS0FBSyxLQUFLLEdBQUcsSUFBSSxHQUFHO0VBQzFCLE1BQU0sS0FBSyxLQUFLLEdBQUcsSUFBSSxHQUFHO0VBQzFCLE1BQU0sTUFBTSxLQUFLLEtBQUssS0FBSztFQUMzQixNQUFNLE1BQU0sS0FBSyxLQUFLLEtBQUs7RUFDM0IsTUFBTSxNQUFNLEtBQUssS0FBSyxLQUFLO0VBQzNCLE1BQU0sTUFBTSxLQUFLLEtBQUssS0FBSztFQUMzQixJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLElBQUksS0FBSyxHQUFHLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUcsR0FDL0csT0FBTztFQUVULE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQkEsSUFBSSxXQUFXLEdBQUcsV0FBVyxVQUFVO0VBQ3JDLEtBQUssS0FBSztFQUNWLEtBQUssS0FBSztFQUNWLEtBQUssU0FBUyxXQUFXO0VBQ3pCLEtBQUssVUFBVSxXQUFXO0VBQzFCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsSUFBSSxXQUFXO0VBQ2IsTUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLEdBQUcsVUFBVSxDQUFDO0VBQ3ZDLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssT0FBTyxVQUFVLElBQUksVUFBVSxLQUFLO0VBQ3RFLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxHQUFHLFVBQVUsQ0FBQztFQUN2QyxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLFFBQVEsVUFBVSxJQUFJLFVBQVUsTUFBTTtFQUN4RSxLQUFLLElBQUk7RUFDVCxLQUFLLFFBQVEsS0FBSyxJQUFJLEtBQUssSUFBSSxDQUFDO0VBQ2hDLEtBQUssSUFBSTtFQUNULEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxJQUFJLENBQUM7RUFDakMsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXVCQSxLQUFLLGFBQWEsR0FBRyxNQUFNLE1BQU07RUFDL0IsTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSyxRQUFRLE9BQU8sVUFBVSxJQUFJO0VBQ2pFLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssU0FBUyxPQUFPLFVBQVUsSUFBSTtFQUNsRSxLQUFLLElBQUksS0FBSyxPQUFPLEtBQUssSUFBSSxPQUFPLFVBQVUsSUFBSTtFQUNuRCxLQUFLLElBQUksS0FBSyxPQUFPLEtBQUssSUFBSSxPQUFPLFVBQVUsSUFBSTtFQUNuRCxLQUFLLFFBQVEsS0FBSyxLQUFLO0VBQ3ZCLEtBQUssU0FBUyxLQUFLLEtBQUs7RUFDeEIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLE1BQU0sR0FBRyxJQUFJLEdBQUc7RUFDZCxLQUFLLEtBQUs7RUFDVixLQUFLLEtBQUs7RUFDVixLQUFLLFNBQVM7RUFDZCxLQUFLLFVBQVU7RUFDZixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsUUFBUSxXQUFXO0VBQ2pCLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxHQUFHLFVBQVUsQ0FBQztFQUN2QyxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLE9BQU8sVUFBVSxJQUFJLFVBQVUsS0FBSztFQUN0RSxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssR0FBRyxVQUFVLENBQUM7RUFDdkMsTUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxRQUFRLFVBQVUsSUFBSSxVQUFVLE1BQU07RUFDeEUsS0FBSyxJQUFJO0VBQ1QsS0FBSyxRQUFRLEtBQUs7RUFDbEIsS0FBSyxJQUFJO0VBQ1QsS0FBSyxTQUFTLEtBQUs7RUFDbkIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsVUFBVSxLQUFLO0VBQ2IsUUFBUSxNQUFNLElBQUksVUFBVTtFQUM1QixJQUFJLFNBQVMsSUFBSTtFQUNqQixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNkJBLGFBQWEsT0FBTztFQUNsQixJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssVUFBVSxHQUFHLE9BQU87RUFDaEQsTUFBTSxLQUFLLE1BQU07RUFDakIsTUFBTSxLQUFLLE1BQU07RUFDakIsTUFBTSxLQUFLLE1BQU0sSUFBSSxNQUFNO0VBQzNCLE1BQU0sS0FBSyxNQUFNLElBQUksTUFBTTtFQUMzQixPQUFPLE1BQU0sS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssU0FBUyxNQUFNLEtBQUssS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLFVBQVUsTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSyxTQUFTLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUs7Q0FDbkw7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsSUFBSSxHQUFHLEdBQUcsT0FBTyxRQUFRO0VBQ3ZCLEtBQUssSUFBSTtFQUNULEtBQUssSUFBSTtFQUNULEtBQUssUUFBUTtFQUNiLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDVDtDQUNBLFdBQVc7RUFDVCxPQUFPLDZCQUE2QixLQUFLLEVBQUUsS0FBSyxLQUFLLEVBQUUsU0FBUyxLQUFLLE1BQU0sVUFBVSxLQUFLLE9BQU87Q0FDbkc7QUFDRjs7O0FDem9CQSxJQUFNLFdBQVcsRUFDZixTQUFTLEdBQ1g7QUFDQSxTQUFTLElBQUksT0FBTyxXQUFXO0NBQzdCLElBQUksU0FBUyxVQUFVLEtBQUssR0FDMUIsU0FBUyxRQUFRO0NBRW5CLE9BQU8sRUFBRSxTQUFTO0FBQ3BCO0FBQ0EsU0FBUyxZQUFZO0NBQ25CLEtBQUssTUFBTSxPQUFPLFVBQ2hCLE9BQU8sU0FBUztBQUVwQjs7O0FDYkEsSUFBTSwyQkFBMkIsSUFBSSxJQUFJO0FBQ3pDLElBQU0sU0FBUztBQUNmLElBQU0sU0FBUztBQUNmLElBQU0sVUFBVTtBQUNoQixJQUFNLFVBQVU7QUFDaEIsSUFBTSxtQkFBbUI7Q0FDdkIsT0FBTztDQUNQLFNBQVM7QUFDWDtBQUNBLElBQU0sZ0JBQWdCLFNBQVMsU0FBUyxjQUFjLE1BQU07Q0FDMUQsSUFBSSxpQkFBaUIsU0FBUyxTQUFTLElBQUksT0FBTyxHQUFHO0NBQ3JELElBQUkseUJBQVEsSUFBSSxNQUFNLEVBQUEsQ0FBRTtDQUN4QixNQUFNLHFCQUFxQixHQUFHLFFBQVE7b0JBQ3BCO0NBQ2xCLE1BQU0sV0FBVyxPQUFPLFFBQVEsbUJBQW1CLGNBQWMsQ0FBQyxpQkFBaUI7Q0FDbkYsSUFBSSxPQUFPLFVBQVUsYUFDbkIsUUFBUSxLQUFLLGdDQUFnQyxrQkFBa0I7TUFDMUQ7RUFDTCxRQUFRLE1BQU0sTUFBTSxJQUFJLENBQUMsQ0FBQyxPQUFPLFdBQVcsQ0FBQyxDQUFDLEtBQUssSUFBSTtFQUN2RCxJQUFJLFVBQVU7R0FDWixRQUFRLGVBQ04sc0NBQ0Esb0NBQ0EsdURBQ0Esa0JBQ0Y7R0FDQSxRQUFRLEtBQUssS0FBSztHQUNsQixRQUFRLFNBQVM7RUFDbkIsT0FBTztHQUNMLFFBQVEsS0FBSyxnQ0FBZ0Msa0JBQWtCO0dBQy9ELFFBQVEsS0FBSyxLQUFLO0VBQ3BCO0NBQ0Y7Q0FDQSxTQUFTLElBQUksT0FBTztBQUN0QjtBQUNBLE9BQU8saUJBQWlCLGFBQWE7Q0FDbkMsT0FBTztFQUNMLFdBQVcsaUJBQWlCO0VBQzVCLE1BQU0sVUFBVTtHQUNkLGlCQUFpQixRQUFRO0VBQzNCO0VBQ0EsWUFBWTtFQUNaLGNBQWM7Q0FDaEI7Q0FDQSxTQUFTO0VBQ1AsV0FBVyxpQkFBaUI7RUFDNUIsTUFBTSxVQUFVO0dBQ2QsaUJBQWlCLFVBQVU7RUFDN0I7RUFDQSxZQUFZO0VBQ1osY0FBYztDQUNoQjtBQUNGLENBQUM7OztBQ3BERCxJQUFNLGFBQWEsQ0FDbkI7OztBQ0RBLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDL0IsT0FBTyxPQUFPLFNBQVMsS0FBSztBQUM5Qjs7O0FDRkEsU0FBUyxTQUFTLEdBQUc7Q0FDbkIsS0FBSyxNQUFNLElBQUksSUFBSTtDQUNuQixFQUFFO0NBQ0YsS0FBSyxNQUFNO0NBQ1gsS0FBSyxNQUFNO0NBQ1gsS0FBSyxNQUFNO0NBQ1gsS0FBSyxNQUFNO0NBQ1gsS0FBSyxNQUFNO0NBQ1gsT0FBTyxJQUFJO0FBQ2I7QUFDQSxTQUFTLE9BQU8sR0FBRztDQUNqQixPQUFPLEVBQUUsSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDO0FBQzNCO0FBQ0EsU0FBUyxLQUFLLEdBQUc7Q0FDZixJQUFJLEtBQUssSUFBSSxRQUFRLElBQUksTUFBTTtDQUMvQixPQUFPO0NBQ1AsSUFBSSxTQUFTLElBQUksTUFBTSxJQUFJLE1BQU07Q0FDakMsT0FBTztDQUNQLEtBQUs7Q0FDTCxTQUFTLElBQUksS0FBSyxJQUFJLE1BQU07Q0FDNUIsT0FBTztDQUNQLEtBQUs7Q0FDTCxTQUFTLElBQUksSUFBSSxJQUFJLE1BQU07Q0FDM0IsT0FBTztDQUNQLEtBQUs7Q0FDTCxPQUFPLElBQUksS0FBSztBQUNsQjs7O0FDMUJBLFNBQVMsYUFBYSxLQUFLO0NBQ3pCLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLEtBQUssTUFBTSxPQUFPLEtBQ2hCLElBQUksSUFBSSxTQUFTLEtBQUssR0FDcEIsT0FBTyxPQUFPLElBQUk7Q0FHdEIsT0FBTztBQUNUOzs7QUNKQSxJQUFNQyxXQUF5Qix1QkFBTyxPQUFPLElBQUk7QUFDakQsU0FBUywyQkFBMkIsT0FBTztDQUN6QyxNQUFNLEtBQUtBLFNBQU87Q0FDbEIsSUFBSSxPQUFPLEtBQUssR0FDZCxTQUFPLFNBQVMsSUFBSSxVQUFVO0NBRWhDLE9BQU87QUFDVDtBQUNBLElBQU0sZ0JBQWdCLE1BQU0sc0JBQXNCQyxzQkFBYTs7OztDQUk3RCxZQUFZLFVBQVUsQ0FBQyxHQUFHO0VBQ3hCLE1BQU07O0VBRU4sS0FBSyxnQkFBZ0I7Ozs7Ozs7O0VBUXJCLEtBQUssaUJBQWlCOzs7OztFQUt0QixLQUFLLFlBQVk7RUFDakIsVUFBVTtHQUFFLEdBQUcsY0FBYztHQUFnQixHQUFHO0VBQVE7RUFDeEQsS0FBSyxjQUFjLFFBQVE7RUFDM0IsS0FBSyxlQUFlLFFBQVEsZ0JBQWdCLEtBQUs7RUFDakQsS0FBSyxlQUFlLFFBQVEsZ0JBQWdCLEtBQUs7RUFDakQsS0FBSyxlQUFlLFFBQVEsZ0JBQWdCLEtBQUs7RUFDakQsS0FBSyxZQUFZLFFBQVE7RUFDekIsS0FBSyxZQUFZLFFBQVEsYUFBYSxLQUFLO0VBQzNDLEtBQUssWUFBWSxRQUFRLGFBQWEsS0FBSztFQUMzQyxLQUFLLGVBQWUsUUFBUSxnQkFBZ0IsS0FBSztFQUNqRCxLQUFLLGNBQWMsUUFBUTtFQUMzQixLQUFLLGNBQWMsUUFBUTtFQUMzQixLQUFLLFVBQVUsUUFBUTtFQUN2QixLQUFLLGdCQUFnQixRQUFRLGlCQUFpQjtDQUNoRDtDQUNBLElBQUksWUFBWSxPQUFPO0VBQ3JCLEtBQUssZUFBZTtFQUNwQixLQUFLLGVBQWU7RUFDcEIsS0FBSyxlQUFlO0NBQ3RCOztDQUVBLElBQUksY0FBYztFQUNoQixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksU0FBUyxPQUFPO0VBQ2xCLFlBQVksUUFBUSx1REFBdUQ7RUFDM0UsS0FBSyxjQUFjO0NBQ3JCO0NBQ0EsSUFBSSxXQUFXO0VBQ2IsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFVBQVUsT0FBTztFQUNuQixLQUFLLFlBQVk7RUFDakIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssZUFBZTtDQUN0Qjs7Q0FFQSxJQUFJLFlBQVk7RUFDZCxPQUFPLEtBQUs7Q0FDZDs7Q0FFQSxJQUFJLGNBQWMsT0FBTztFQUN2QixLQUFLLGlCQUFpQixLQUFLLElBQUksT0FBTyxFQUFFO0VBQ3hDLElBQUksS0FBSyxpQkFBaUIsR0FDeEIsS0FBSyxZQUFZO0NBRXJCO0NBQ0EsSUFBSSxnQkFBZ0I7RUFDbEIsT0FBTyxLQUFLO0NBQ2Q7Q0FFQSxJQUFJLGNBQWM7RUFDaEIsT0FBTyxLQUFLLHFCQUFxQixLQUFLLG9CQUFvQjtDQUM1RDtDQUNBLFNBQVM7RUFDUCxLQUFLLG9CQUFvQjtFQUN6QixLQUFLLEtBQUssVUFBVSxJQUFJO0NBQzFCO0NBQ0Esc0JBQXNCO0VBQ3BCLE1BQU0sU0FBUyxHQUFHLEtBQUssYUFBYSxHQUFHLEtBQUssYUFBYSxHQUFHLEtBQUssYUFBYSxHQUFHLEtBQUssVUFBVSxHQUFHLEtBQUssVUFBVSxHQUFHLEtBQUssYUFBYSxHQUFHLEtBQUssWUFBWSxHQUFHLEtBQUssWUFBWSxHQUFHLEtBQUssUUFBUSxHQUFHLEtBQUs7RUFDdk0sS0FBSyxvQkFBb0IsMkJBQTJCLE1BQU07RUFDMUQsT0FBTyxLQUFLO0NBQ2Q7O0NBRUEsVUFBVTtFQUNSLEtBQUssWUFBWTtFQUNqQixLQUFLLEtBQUssV0FBVyxJQUFJO0VBQ3pCLEtBQUssS0FBSyxVQUFVLElBQUk7RUFDeEIsS0FBSyxtQkFBbUI7Q0FDMUI7QUFDRjs7QUFFQSxjQUFjLGlCQUFpQjtDQUM3QixhQUFhO0NBQ2IsV0FBVztBQUNiO0FBQ0EsSUFBSSxlQUFlOzs7QUNyR25CLElBQU0saUJBQWlCLE1BQU0sdUJBQXVCQyxzQkFBYTs7OztDQUkvRCxZQUFZLFVBQVUsQ0FBQyxHQUFHO0VBQ3hCLE1BQU07RUFDTixLQUFLLFVBQVU7O0VBRWYsS0FBSyxXQUEyQix1QkFBTyxPQUFPLElBQUk7O0VBRWxELEtBQUssY0FBYzs7RUFFbkIsS0FBSyxNQUFNLElBQUksZUFBZTs7Ozs7O0VBTTlCLEtBQUssZ0JBQWdCOzs7Ozs7RUFNckIsS0FBSyxjQUFjLElBQUksVUFBVTs7Ozs7OztFQU9qQyxLQUFLLGlCQUFpQjs7RUFFdEIsS0FBSyxjQUFjOztFQUVuQixLQUFLLGFBQWE7O0VBRWxCLEtBQUssY0FBYzs7Ozs7RUFLbkIsS0FBSyxRQUFROzs7OztFQUtiLEtBQUssU0FBUzs7Ozs7O0VBTWQsS0FBSyxjQUFjOzs7OztFQUtuQixLQUFLLGdCQUFnQjs7Ozs7Ozs7Ozs7O0VBWXJCLEtBQUssc0JBQXNCOztFQUUzQixLQUFLLFNBQVM7O0VBRWQsS0FBSyxZQUFZOztFQUVqQixLQUFLLGdCQUFnQjs7RUFFckIsS0FBSyxrQkFBa0I7O0VBRXZCLEtBQUssUUFBUTtFQUNiLEtBQUssYUFBYTs7Ozs7O0VBTWxCLEtBQUssWUFBWTs7Ozs7O0VBTWpCLEtBQUssWUFBWTs7Ozs7RUFLakIsS0FBSyxVQUFVOzs7OztFQUtmLEtBQUssYUFBYTs7Ozs7RUFLbEIsS0FBSyx1QkFBdUI7RUFDNUIsTUFBTSxnQkFBZ0I7RUFDdEIsVUFBVTtHQUFFLEdBQUcsZUFBZTtHQUFnQixHQUFHO0VBQVE7RUFDekQsTUFBTSxnQkFBZ0IscUJBQXFCLE9BQU87RUFDbEQsTUFBTSxZQUFZLGtCQUFrQixRQUFRLGtCQUFrQixPQUFPLGdCQUFnQjtFQUNyRixxQkFBcUIsZUFBZSxlQUFlLFNBQVM7RUFDNUQsS0FBSyxRQUFRLFFBQVEsU0FBUztFQUM5QixLQUFLLFdBQVcsUUFBUTtFQUN4QixLQUFLLHFCQUFxQixRQUFRO0VBQ2xDLEtBQUssY0FBYyxRQUFRO0VBQzNCLElBQUksUUFBUSxPQUNWLEtBQUssYUFBYSxRQUFRLFFBQVEsS0FBSztPQUV2QyxLQUFLLGFBQWEsS0FBSyxXQUFXLEtBQUssaUJBQWlCLElBQUk7RUFFOUQsSUFBSSxRQUFRLFFBQ1YsS0FBSyxjQUFjLFFBQVEsU0FBUyxLQUFLO09BRXpDLEtBQUssY0FBYyxLQUFLLFdBQVcsS0FBSyxrQkFBa0IsSUFBSTtFQUVoRSxLQUFLLFFBQVEsS0FBSyxhQUFhLEtBQUs7RUFDcEMsS0FBSyxTQUFTLEtBQUssY0FBYyxLQUFLO0VBQ3RDLEtBQUssU0FBUyxRQUFRO0VBQ3RCLEtBQUssWUFBWTtFQUNqQixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLGtCQUFrQixRQUFRO0VBQy9CLEtBQUssUUFBUSxjQUFjLE9BQU8sUUFBUSxTQUFTLElBQUk7RUFDdkQsS0FBSyxnQkFBZ0IsUUFBUTtFQUM3QixLQUFLLHNCQUFzQixRQUFRO0VBQ25DLEtBQUssY0FBYyxRQUFRO0VBQzNCLEtBQUssWUFBWSxjQUFjLE9BQU8sUUFBUSxRQUFRO0VBQ3RELEtBQUssWUFBWSxRQUFRLGFBQWE7RUFDdEMsS0FBSyxVQUFVLFFBQVEsV0FBVztFQUNsQyxLQUFLLFlBQVksUUFBUTtFQUN6QixLQUFLLFFBQVEsSUFBSSxhQUFhLGFBQWEsT0FBTyxDQUFDO0VBQ25ELEtBQUssYUFBYTtFQUNsQixLQUFLLFlBQVk7RUFDakIsS0FBSyxZQUFZO0NBQ25COzs7OztDQUtBLElBQUkscUJBQXFCO0VBQ3ZCLE9BQU8sS0FBSyxjQUFjLE9BQU8sS0FBSyxRQUFRLEtBQUssbUJBQW1CO0NBQ3hFOztDQUVBLElBQUksU0FBUztFQUNYLE9BQU87Q0FDVDs7Q0FFQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksTUFBTSxPQUFPO0VBQ2YsSUFBSSxLQUFLLFVBQVUsT0FBTztFQUMxQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxRQUFRLElBQUksVUFBVSxLQUFLLGdCQUFnQixJQUFJO0VBQ3BELEtBQUssU0FBUztFQUNkLEtBQUssUUFBUSxHQUFHLFVBQVUsS0FBSyxnQkFBZ0IsSUFBSTtFQUNuRCxLQUFLLGVBQWU7Q0FDdEI7O0NBRUEsSUFBSSxjQUFjLE9BQU87RUFDdkIsS0FBSyxPQUFPLGdCQUFnQjtDQUM5QjtDQUNBLElBQUksZ0JBQWdCO0VBQ2xCLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOztDQUVBLElBQUksY0FBYztFQUNoQixPQUFPLEtBQUssT0FBTztDQUNyQjtDQUNBLElBQUksWUFBWSxPQUFPO0VBQ3JCLEtBQUssT0FBTyxjQUFjO0NBQzVCOztDQUVBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBSyxPQUFPO0NBQ3JCO0NBQ0EsSUFBSSxXQUFXLE9BQU87RUFDcEIsS0FBSyxPQUFPLGNBQWM7Q0FDNUI7O0NBRUEsSUFBSSxZQUFZO0VBQ2QsT0FBTyxLQUFLLE9BQU87Q0FDckI7Q0FDQSxJQUFJLFVBQVUsT0FBTztFQUNuQixLQUFLLE9BQU8sWUFBWTtDQUMxQjs7Q0FFQSxJQUFJLFlBQVk7RUFDZCxPQUFPLEtBQUssT0FBTztDQUNyQjtDQUNBLElBQUksVUFBVSxPQUFPO0VBQ25CLEtBQUssT0FBTyxZQUFZO0NBQzFCOztDQUVBLElBQUksZUFBZTtFQUNqQixPQUFPLEtBQUssT0FBTztDQUNyQjtDQUNBLElBQUksYUFBYSxPQUFPO0VBQ3RCLEtBQUssT0FBTyxlQUFlO0NBQzdCOztDQUVBLElBQUksY0FBYztFQUNoQixPQUFPLEtBQUssT0FBTztDQUNyQjtDQUNBLElBQUksWUFBWSxPQUFPO0VBQ3JCLEtBQUssT0FBTyxjQUFjO0NBQzVCOztDQUVBLElBQUksY0FBYztFQUNoQixPQUFPLEtBQUssT0FBTztDQUNyQjtDQUNBLElBQUksWUFBWSxPQUFPO0VBQ3JCLEtBQUssT0FBTyxjQUFjO0NBQzVCO0NBQ0EsaUJBQWlCO0VBQ2YsS0FBSyxLQUFLLGVBQWUsSUFBSTtDQUMvQjs7Q0FFQSxTQUFTO0VBQ1AsSUFBSSxLQUFLLFVBQVU7R0FDakIsTUFBTSxhQUFhLEtBQUs7R0FFeEIsSUFEa0IsS0FBSyxPQUFPLEtBQUssZ0JBQWdCLFlBQVksS0FBSyxpQkFBaUIsVUFDekUsR0FBRztFQUNqQjtFQUNBLEtBQUssS0FBSyxVQUFVLElBQUk7Q0FDMUI7O0NBRUEsVUFBVTtFQUNSLEtBQUssWUFBWTtFQUNqQixLQUFLLE9BQU87RUFDWixLQUFLLEtBQUssV0FBVyxJQUFJO0VBQ3pCLElBQUksS0FBSyxRQUFRO0dBQ2YsSUFBSSxLQUFLLFlBQVksS0FBSyxPQUFPLFFBQVE7R0FDekMsS0FBSyxTQUFTO0VBQ2hCO0VBQ0EsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssbUJBQW1CO0NBQzFCOzs7OztDQUtBLFNBQVM7RUFDUCxLQUFLLGNBQWMsSUFBSSxVQUFVO0VBQ2pDLEtBQUssS0FBSyxVQUFVLElBQUk7RUFDeEIsS0FBSyxLQUFLLFVBQVUsSUFBSTtFQUN4QixLQUFLLE1BQU0sT0FBTyxLQUFLLFVBQ3JCLEtBQUssU0FBUyxJQUFJLEVBQUUsVUFBVTtFQUVoQyxLQUFLLFdBQTJCLHVCQUFPLE9BQU8sSUFBSTtDQUNwRDs7Q0FFQSxJQUFJLGdCQUFnQjtFQUNsQixNQUFNLEVBQUUsYUFBYTtFQUNyQixPQUFPLFNBQVMsZ0JBQWdCLFNBQVMsY0FBYyxTQUFTLGdCQUFnQixTQUFTO0NBQzNGOztDQUVBLElBQUksaUJBQWlCO0VBQ25CLE1BQU0sRUFBRSxhQUFhO0VBQ3JCLE9BQU8sU0FBUyxpQkFBaUIsU0FBUyxlQUFlLFNBQVMsaUJBQWlCLFNBQVM7Q0FDOUY7Ozs7Ozs7O0NBUUEsSUFBSSxhQUFhO0VBQ2YsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFdBQVcsWUFBWTtFQUN6QixJQUFJLEtBQUssZ0JBQWdCLFlBQVk7RUFDckMsS0FBSyxjQUFjO0VBQ25CLEtBQUssUUFBUSxLQUFLLGFBQWE7RUFDL0IsS0FBSyxTQUFTLEtBQUssY0FBYztDQUNuQzs7Ozs7Ozs7Q0FRQSxPQUFPLE9BQU8sUUFBUSxZQUFZO0VBQ2hDLGVBQWUsYUFBYSxLQUFLO0VBQ2pDLFVBQVUsUUFBUSxLQUFLO0VBQ3ZCLFdBQVcsU0FBUyxLQUFLO0VBQ3pCLE1BQU0sZ0JBQWdCLEtBQUssTUFBTSxRQUFRLFVBQVU7RUFDbkQsTUFBTSxpQkFBaUIsS0FBSyxNQUFNLFNBQVMsVUFBVTtFQUNyRCxLQUFLLFFBQVEsZ0JBQWdCO0VBQzdCLEtBQUssU0FBUyxpQkFBaUI7RUFDL0IsS0FBSyxjQUFjO0VBQ25CLElBQUksS0FBSyxlQUFlLGlCQUFpQixLQUFLLGdCQUFnQixnQkFDNUQsT0FBTztFQUVULEtBQUssWUFBWTtFQUNqQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxjQUFjO0VBQ25CLEtBQUssS0FBSyxVQUFVLElBQUk7RUFDeEIsS0FBSyxjQUFjLElBQUksVUFBVTtFQUNqQyxLQUFLLEtBQUssVUFBVSxJQUFJO0VBQ3hCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Q0FXQSxnQkFBZ0I7RUFDZCxJQUFJLEtBQUssdUJBQXVCLEtBQUssZ0JBQWdCLEdBQ25ELEtBQUssS0FBSyxpQkFBaUIsSUFBSTtDQUVuQztDQUNBLElBQUksU0FBUyxPQUFPO0VBQ2xCLEtBQUssT0FBTyxXQUFXO0NBQ3pCO0NBQ0EsSUFBSSxXQUFXO0VBQ2IsT0FBTyxLQUFLLE9BQU87Q0FDckI7Q0FDQSxJQUFJLFVBQVUsT0FBTztFQUNuQixLQUFLLE9BQU8sWUFBWTtDQUMxQjs7Q0FFQSxJQUFJLFlBQVk7RUFDZCxPQUFPLEtBQUssT0FBTztDQUNyQjs7Ozs7Q0FLQSxjQUFjO0VBQ1osS0FBSyxlQUFlLE9BQU8sS0FBSyxVQUFVLEtBQUssT0FBTyxLQUFLLFdBQVc7Q0FDeEU7Q0FDQSxPQUFPLEtBQUssV0FBVztFQUNyQixNQUFNLElBQUksTUFBTSxlQUFlO0NBQ2pDO0FBQ0Y7O0FBRUEsZUFBZSxpQkFBaUI7Q0FDOUIsWUFBWTtDQUNaLFFBQVE7Q0FDUixXQUFXO0NBQ1gsaUJBQWlCO0NBQ2pCLGVBQWU7Q0FDZixxQkFBcUI7Q0FDckIsYUFBYTtDQUNiLFdBQVc7Q0FDWCxvQkFBb0I7QUFDdEI7QUFDQSxJQUFJLGdCQUFnQjtBQUNwQixTQUFTLHFCQUFxQixTQUFTO0NBQ3JDLElBQUksUUFBUSxlQUFlLE9BQU8sUUFBUTtDQUMxQyxJQUFJLFFBQVEsT0FBTyxPQUFPO0NBQzFCLE9BQU8sUUFBUSxrQkFBa0IsSUFBSSxhQUFhO0FBQ3BEO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUyxlQUFlLFdBQVc7Q0FDL0QsSUFBSSxRQUFRLFVBQVUsS0FBSyxLQUFLLE9BQU8sUUFBUSxVQUFVLFVBQ3ZELE1BQU0sSUFBSSxNQUFNLG9FQUFvRSxRQUFRLE1BQU0sOEVBQThFO0NBRWxMLElBQUksUUFBUSxTQUFTLFFBQVEsa0JBQWtCLEdBQzdDLE1BQU0sSUFBSSxNQUFNLDRIQUE0SDtDQUU5SSxJQUFJLFFBQVEsU0FBUyxrQkFBa0IsTUFDckMsTUFBTSxJQUFJLE1BQU0sbUVBQW1FLGNBQWMsNkNBQTZDO0NBRWhKLElBQUksa0JBQWtCLFFBQVEsUUFBUSxrQkFBa0IsR0FDdEQsTUFBTSxJQUFJLE1BQU0sZ0VBQWdFO0NBRWxGLElBQUksUUFBUSxjQUFjLFFBQVEsZUFBZSxXQUMvQyxNQUFNLElBQUksTUFBTSwrQkFBK0IsUUFBUSxXQUFXLGlDQUFpQyxjQUFjLHNEQUFzRDtNQUNsSyxJQUFJLFFBQVEsWUFDakIsWUFBWSxTQUFTLGlGQUFpRjtDQUV4RyxJQUFJLGNBQWMsUUFBUSxRQUFRLFdBQ2hDLE1BQU0sSUFBSSxNQUFNLDRGQUE0RjtBQUVoSDs7O0FDOVlBLElBQU0sb0JBQU4sY0FBZ0MsY0FBYztDQUM1QyxZQUFZLFNBQVM7RUFDbkIsTUFBTSxxQkFBcUIsUUFBUSxTQUFTLFFBQVEsbUJBQW1CO0VBQ3ZFLE1BQU0sU0FBUyxRQUFRLFlBQVksSUFBSSxhQUFhLFFBQVEsUUFBUSxRQUFRLFNBQVMscUJBQXFCLENBQUM7RUFDM0csSUFBSSxTQUFTLFFBQVE7RUFDckIsSUFBSSxDQUFDLFFBQVE7R0FDWCxJQUFJLGtCQUFrQixjQUNwQixTQUFTO1FBQ0osSUFBSSxrQkFBa0IsWUFDM0IsU0FBUztRQUNKLElBQUksa0JBQWtCLGFBQzNCLFNBQVM7UUFDSixJQUFJLGtCQUFrQixZQUMzQixTQUFTO1FBQ0osSUFBSSxrQkFBa0IsYUFDM0IsU0FBUztRQUNKLElBQUksa0JBQWtCLFdBQzNCLFNBQVM7UUFFVCxTQUFTO0VBRWI7RUFDQSxNQUFNLGdCQUFnQixnQkFBZ0IsTUFBTSxLQUFLLHFCQUFxQjtFQUN0RSxNQUFNO0dBQ0osR0FBRyxpQkFBaUIsRUFBRSxXQUFXLHVCQUF1QjtHQUN4RCxHQUFHO0dBQ0gsVUFBVTtHQUNWO0VBQ0YsQ0FBQztFQUNELEtBQUssaUJBQWlCOzs7OztFQUt0QixLQUFLLGVBQWU7Ozs7OztFQU1wQixLQUFLLGFBQWE7Q0FDcEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQThCQSxPQUFPLFFBQVEsR0FBRyxNQUFNLFVBQVU7RUFDaEMsS0FBSyxRQUFRLEtBQUssTUFBTSxhQUFhLEtBQUsscUJBQXFCLEdBQzdELE1BQU0sSUFBSSxNQUFNLDBGQUEwRjtFQUU1RyxLQUFLLGVBQWU7RUFDcEIsS0FBSyxhQUFhO0VBQ2xCLE1BQU0sT0FBTztFQUNiLEtBQUssZUFBZTtFQUNwQixLQUFLLGFBQWE7Q0FDcEI7Q0FDQSxPQUFPLEtBQUssVUFBVTtFQUNwQixPQUFPLG9CQUFvQixhQUFhLG9CQUFvQixjQUFjLG9CQUFvQixxQkFBcUIsb0JBQW9CLGNBQWMsb0JBQW9CLGVBQWUsb0JBQW9CLGNBQWMsb0JBQW9CLGVBQWUsb0JBQW9CO0NBQ25SO0FBQ0Y7QUFDQSxrQkFBa0IsWUFBWSxjQUFjOzs7QUN2RjVDLElBQU0sVUFBVSxJQUFJLE9BQU87QUFDM0IsSUFBTSxnQkFBTixNQUFvQjs7Ozs7Q0FLbEIsWUFBWSxTQUFTLGFBQWE7RUFDaEMsS0FBSyxXQUFXLElBQUksT0FBTztFQUMzQixLQUFLLDhCQUFjLElBQUksYUFBYSxDQUFDO0VBQ3JDLEtBQUssK0JBQWUsSUFBSSxhQUFhLENBQUM7RUFDdEMsS0FBSyxZQUFZO0VBQ2pCLEtBQUssY0FBYztFQUNuQixJQUFJLE9BQU8sZ0JBQWdCLGFBQ3pCLEtBQUssY0FBYyxRQUFRLFFBQVEsS0FBSyxJQUFJO09BRTVDLEtBQUssY0FBYztFQUVyQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxVQUFVO0NBQ2pCOztDQUVBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxRQUFRLE9BQU87RUFDakIsSUFBSSxLQUFLLGFBQWEsT0FBTztHQUMzQixLQUFLLFVBQVUsZUFBZSxVQUFVLEtBQUssUUFBUSxJQUFJO0dBQ3pELEtBQUssV0FBVztHQUNoQixLQUFLLFNBQVMsWUFBWSxVQUFVLEtBQUssUUFBUSxJQUFJO0VBQ3ZEO0VBQ0EsS0FBSyxPQUFPO0NBQ2Q7O0NBRUEsVUFBVTtFQUNSLEtBQUssVUFBVSxlQUFlLFVBQVUsS0FBSyxRQUFRLElBQUk7RUFDekQsS0FBSyxXQUFXO0NBQ2xCOzs7Ozs7O0NBT0EsWUFBWSxLQUFLLEtBQUs7RUFDcEIsSUFBSSxRQUFRLEtBQUssR0FDZixNQUFNO0VBRVIsTUFBTSxNQUFNLEtBQUs7RUFDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLLEdBQUc7R0FDdEMsTUFBTSxJQUFJLElBQUk7R0FDZCxNQUFNLElBQUksSUFBSSxJQUFJO0dBQ2xCLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0dBQ3JDLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7RUFDM0M7RUFDQSxPQUFPO0NBQ1Q7Ozs7O0NBS0EsU0FBUztFQUNQLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLEtBQUs7RUFDTCxNQUFNLE1BQU0sSUFBSTtFQUNoQixLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUU7RUFDcEcsTUFBTSxPQUFPLElBQUk7RUFDakIsTUFBTSxPQUFPLElBQUk7RUFDakIsSUFBSSxNQUFNO0dBQ1IsUUFBUSxJQUNOLEtBQUssUUFBUSxLQUFLLE9BQ2xCLEdBQ0EsR0FDQSxLQUFLLFNBQVMsS0FBSyxRQUNuQixDQUFDLEtBQUssSUFBSSxLQUFLLE9BQ2YsQ0FBQyxLQUFLLElBQUksS0FBSyxNQUNqQjtHQUNBLEtBQUssU0FBUyxPQUFPLE9BQU87RUFDOUI7RUFDQSxNQUFNLFVBQVUsSUFBSTtFQUNwQixNQUFNLFFBQVEsS0FBSztFQUNuQixNQUFNLFNBQVMsS0FBSyxjQUFjLFFBQVE7RUFDMUMsTUFBTSxTQUFTLEtBQUssY0FBYyxRQUFRO0VBQzFDLE1BQU0sTUFBTSxJQUFJLE1BQU0sSUFBSSxTQUFTLFVBQVUsUUFBUTtFQUNyRCxNQUFNLE1BQU0sSUFBSSxNQUFNLElBQUksU0FBUyxVQUFVLFFBQVE7RUFDckQsTUFBTSxNQUFNLElBQUksTUFBTSxJQUFJLElBQUksTUFBTSxRQUFRLFNBQVMsVUFBVSxRQUFRO0VBQ3ZFLE1BQU0sTUFBTSxJQUFJLE1BQU0sSUFBSSxJQUFJLE1BQU0sU0FBUyxTQUFTLFVBQVUsUUFBUTtFQUN4RSxLQUFLLGFBQWEsS0FBSyxLQUFLLGNBQWMsUUFBUTtFQUNsRCxLQUFLLGFBQWEsS0FBSyxLQUFLLGNBQWMsUUFBUTtFQUNsRCxLQUFLLFdBQVcsSUFBSSxNQUFNLFVBQVUsUUFBUSxTQUFTLElBQUksTUFBTSxXQUFXLFFBQVEsVUFBVSxJQUFJLFdBQVc7RUFDM0csT0FBTztDQUNUO0FBQ0Y7OztBQ25GQSxJQUFNLFVBQU4sY0FBc0JDLHNCQUFhOzs7O0NBSWpDLFlBQVksRUFDVixRQUNBLE9BQ0EsT0FDQSxNQUNBLE1BQ0EsZUFDQSxnQkFDQSxRQUNBLFlBQ0UsQ0FBQyxHQUFHO0VBQ04sTUFBTTs7RUFFTixLQUFLLE1BQU0sSUFBSSxTQUFTOztFQUV4QixLQUFLLE1BQU07R0FBRSxJQUFJO0dBQUcsSUFBSTtHQUFHLElBQUk7R0FBRyxJQUFJO0dBQUcsSUFBSTtHQUFHLElBQUk7R0FBRyxJQUFJO0dBQUcsSUFBSTtFQUFFOzs7OztFQUtwRSxLQUFLLFFBQVEsSUFBSSxVQUFVOzs7Ozs7Ozs7Ozs7O0VBYTNCLEtBQUssVUFBVTs7Ozs7O0VBTWYsS0FBSyxVQUFVOztFQUVmLEtBQUssWUFBWTtFQUNqQixLQUFLLFFBQVE7RUFDYixLQUFLLFNBQVMsUUFBUSxVQUFVLElBQUksY0FBYztFQUNsRCxLQUFLLFVBQVUsQ0FBQztFQUNoQixJQUFJLE9BQ0YsS0FBSyxNQUFNLFNBQVMsS0FBSztPQUNwQjtHQUNMLE1BQU0sRUFBRSxPQUFPLFdBQVcsS0FBSztHQUMvQixLQUFLLE1BQU0sUUFBUTtHQUNuQixLQUFLLE1BQU0sU0FBUztFQUN0QjtFQUNBLEtBQUssT0FBTyxRQUFRLEtBQUs7RUFDekIsS0FBSyxPQUFPO0VBQ1osS0FBSyxTQUFTLFVBQVU7RUFDeEIsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssVUFBVSxXQUFXO0VBQzFCLEtBQUssVUFBVTtDQUNqQjtDQUNBLElBQUksT0FBTyxPQUFPO0VBQ2hCLElBQUksS0FBSyxTQUNQLEtBQUssUUFBUSxJQUFJLFVBQVUsS0FBSyxRQUFRLElBQUk7RUFFOUMsS0FBSyxVQUFVO0VBQ2YsTUFBTSxHQUFHLFVBQVUsS0FBSyxRQUFRLElBQUk7RUFDcEMsS0FBSyxLQUFLLFVBQVUsSUFBSTtDQUMxQjs7Q0FFQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUs7Q0FDZDs7Q0FFQSxJQUFJLGdCQUFnQjtFQUNsQixJQUFJLENBQUMsS0FBSyxnQkFDUixLQUFLLGlCQUFpQixJQUFJLGNBQWMsSUFBSTtFQUU5QyxPQUFPLEtBQUs7Q0FDZDs7Q0FFQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUssS0FBSztDQUNuQjs7Q0FFQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUssS0FBSztDQUNuQjs7Q0FFQSxZQUFZO0VBQ1YsTUFBTSxFQUFFLEtBQUssVUFBVTtFQUN2QixNQUFNLEVBQUUsT0FBTyxXQUFXLEtBQUs7RUFDL0IsTUFBTSxLQUFLLE1BQU0sSUFBSTtFQUNyQixNQUFNLEtBQUssTUFBTSxJQUFJO0VBQ3JCLE1BQU0sS0FBSyxNQUFNLFFBQVE7RUFDekIsTUFBTSxLQUFLLE1BQU0sU0FBUztFQUMxQixJQUFJLFNBQVMsS0FBSztFQUNsQixJQUFJLFFBQVE7R0FDVixNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUssS0FBSztHQUNoQixNQUFNLEtBQUssS0FBSztHQUNoQixTQUFTLFFBQVEsSUFBSSxRQUFRLFFBQVEsRUFBRTtHQUN2QyxJQUFJLEtBQUssS0FBSyxLQUFLLFFBQVEsR0FBRyxNQUFNO0dBQ3BDLElBQUksS0FBSyxLQUFLLEtBQUssUUFBUSxHQUFHLE1BQU07R0FDcEMsU0FBUyxRQUFRLElBQUksUUFBUSxDQUFDO0dBQzlCLElBQUksS0FBSyxLQUFLLEtBQUssUUFBUSxHQUFHLE1BQU07R0FDcEMsSUFBSSxLQUFLLEtBQUssS0FBSyxRQUFRLEdBQUcsTUFBTTtHQUNwQyxTQUFTLFFBQVEsSUFBSSxRQUFRLENBQUM7R0FDOUIsSUFBSSxLQUFLLEtBQUssS0FBSyxRQUFRLEdBQUcsTUFBTTtHQUNwQyxJQUFJLEtBQUssS0FBSyxLQUFLLFFBQVEsR0FBRyxNQUFNO0dBQ3BDLFNBQVMsUUFBUSxJQUFJLFFBQVEsQ0FBQztHQUM5QixJQUFJLEtBQUssS0FBSyxLQUFLLFFBQVEsR0FBRyxNQUFNO0dBQ3BDLElBQUksS0FBSyxLQUFLLEtBQUssUUFBUSxHQUFHLE1BQU07RUFDdEMsT0FBTztHQUNMLElBQUksS0FBSztHQUNULElBQUksS0FBSztHQUNULElBQUksS0FBSyxLQUFLO0dBQ2QsSUFBSSxLQUFLO0dBQ1QsSUFBSSxLQUFLLEtBQUs7R0FDZCxJQUFJLEtBQUssS0FBSztHQUNkLElBQUksS0FBSztHQUNULElBQUksS0FBSyxLQUFLO0VBQ2hCO0NBQ0Y7Ozs7O0NBS0EsUUFBUSxnQkFBZ0IsT0FBTztFQUM3QixJQUFJLEtBQUssU0FBUztHQUNoQixLQUFLLFFBQVEsSUFBSSxVQUFVLEtBQUssUUFBUSxJQUFJO0dBQzVDLElBQUksZUFBZTtJQUNqQixLQUFLLFFBQVEsUUFBUTtJQUNyQixLQUFLLFVBQVU7R0FDakI7RUFDRjtFQUNBLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssWUFBWTtFQUNqQixLQUFLLEtBQUssV0FBVyxJQUFJO0VBQ3pCLEtBQUssbUJBQW1CO0NBQzFCOzs7Ozs7Q0FNQSxTQUFTO0VBQ1AsSUFBSSxLQUFLLFNBQVM7R0FDaEIsS0FBSyxNQUFNLFFBQVEsS0FBSyxRQUFRO0dBQ2hDLEtBQUssTUFBTSxTQUFTLEtBQUssUUFBUTtFQUNuQztFQUNBLEtBQUssVUFBVTtFQUNmLEtBQUssS0FBSyxVQUFVLElBQUk7Q0FDMUI7O0NBRUEsSUFBSSxjQUFjO0VBQ2hCLFlBQVksUUFBUSwyQ0FBMkM7RUFDL0QsT0FBTyxLQUFLO0NBQ2Q7QUFDRjtBQUNBLFFBQVEsUUFBUSxJQUFJLFFBQVE7Q0FDMUIsT0FBTztDQUNQLFFBQVEsSUFBSSxjQUFjLEVBQ3hCLE9BQU8sUUFDVCxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsTUFBTSxVQUFVO0FBQ3hCLFFBQVEsUUFBUSxJQUFJLFFBQVE7Q0FDMUIsUUFBUSxJQUFJLGtCQUFrQjtFQUM1QixVQUFVLElBQUksV0FBVztHQUFDO0dBQUs7R0FBSztHQUFLO0VBQUcsQ0FBQztFQUM3QyxPQUFPO0VBQ1AsUUFBUTtFQUNSLFdBQVc7RUFDWCxPQUFPO0NBQ1QsQ0FBQztDQUNELE9BQU87QUFDVCxDQUFDO0FBQ0QsUUFBUSxNQUFNLFVBQVU7OztBQzdMeEIsSUFBTSxnQkFBZ0IsSUFBSSxPQUFPO0FBQ2pDLElBQU0sU0FBTixNQUFNLE9BQU87Ozs7Ozs7O0NBUVgsWUFBWSxPQUFPLFVBQVUsT0FBTyxVQUFVLE9BQU8sV0FBVyxPQUFPLFdBQVc7Ozs7Ozs7Ozs7OztFQVloRixLQUFLLE9BQU87Ozs7Ozs7Ozs7OztFQVlaLEtBQUssT0FBTzs7Ozs7Ozs7Ozs7Ozs7RUFjWixLQUFLLE9BQU87Ozs7Ozs7Ozs7Ozs7O0VBY1osS0FBSyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF3QlosS0FBSyxTQUFTO0VBQ2QsS0FBSyxPQUFPO0VBQ1osS0FBSyxPQUFPO0VBQ1osS0FBSyxPQUFPO0VBQ1osS0FBSyxPQUFPO0NBQ2Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLFVBQVU7RUFDUixPQUFPLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPLEtBQUs7Q0FDbkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0JBLElBQUksWUFBWTtFQUNkLElBQUksQ0FBQyxLQUFLLFlBQ1IsS0FBSyxhQUFhLElBQUksVUFBVTtFQUVsQyxNQUFNLFlBQVksS0FBSztFQUN2QixJQUFJLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPLEtBQUssTUFBTTtHQUNsRCxVQUFVLElBQUk7R0FDZCxVQUFVLElBQUk7R0FDZCxVQUFVLFFBQVE7R0FDbEIsVUFBVSxTQUFTO0VBQ3JCLE9BQ0UsVUFBVSxlQUFlLElBQUk7RUFFL0IsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7OztDQWNBLFFBQVE7RUFDTixLQUFLLE9BQU87RUFDWixLQUFLLE9BQU87RUFDWixLQUFLLE9BQU87RUFDWixLQUFLLE9BQU87RUFDWixLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0VBQ2xCLEtBQUssT0FBTztFQUNaLEtBQUssT0FBTztFQUNaLEtBQUssT0FBTztFQUNaLEtBQUssT0FBTztDQUNkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXVCQSxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksUUFBUTtFQUMvQixXQUFXLFNBQVMsS0FBSztFQUN6QixNQUFNLElBQUksT0FBTztFQUNqQixNQUFNLElBQUksT0FBTztFQUNqQixNQUFNLElBQUksT0FBTztFQUNqQixNQUFNLElBQUksT0FBTztFQUNqQixNQUFNLEtBQUssT0FBTztFQUNsQixNQUFNLEtBQUssT0FBTztFQUNsQixJQUFJLE9BQU8sS0FBSztFQUNoQixJQUFJLE9BQU8sS0FBSztFQUNoQixJQUFJLE9BQU8sS0FBSztFQUNoQixJQUFJLE9BQU8sS0FBSztFQUNoQixJQUFJLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztFQUMxQixJQUFJLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztFQUMxQixJQUFJLElBQUksTUFBTSxPQUFPO0VBQ3JCLElBQUksSUFBSSxNQUFNLE9BQU87RUFDckIsSUFBSSxJQUFJLE1BQU0sT0FBTztFQUNyQixJQUFJLElBQUksTUFBTSxPQUFPO0VBQ3JCLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztFQUN0QixJQUFJLElBQUksS0FBSyxJQUFJLEtBQUs7RUFDdEIsSUFBSSxJQUFJLE1BQU0sT0FBTztFQUNyQixJQUFJLElBQUksTUFBTSxPQUFPO0VBQ3JCLElBQUksSUFBSSxNQUFNLE9BQU87RUFDckIsSUFBSSxJQUFJLE1BQU0sT0FBTztFQUNyQixJQUFJLElBQUksS0FBSyxJQUFJLEtBQUs7RUFDdEIsSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLO0VBQ3RCLElBQUksSUFBSSxNQUFNLE9BQU87RUFDckIsSUFBSSxJQUFJLE1BQU0sT0FBTztFQUNyQixJQUFJLElBQUksTUFBTSxPQUFPO0VBQ3JCLElBQUksSUFBSSxNQUFNLE9BQU87RUFDckIsSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLO0VBQ3RCLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztFQUN0QixJQUFJLElBQUksTUFBTSxPQUFPO0VBQ3JCLElBQUksSUFBSSxNQUFNLE9BQU87RUFDckIsSUFBSSxJQUFJLE1BQU0sT0FBTztFQUNyQixJQUFJLElBQUksTUFBTSxPQUFPO0VBQ3JCLEtBQUssT0FBTztFQUNaLEtBQUssT0FBTztFQUNaLEtBQUssT0FBTztFQUNaLEtBQUssT0FBTztDQUNkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0JBLFFBQVEsTUFBTSxRQUFRO0VBQ3BCLEtBQUssU0FBUyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssSUFBSSxLQUFLLE9BQU8sS0FBSyxJQUFJLEtBQUssUUFBUSxNQUFNO0NBQ2pGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0JBLFVBQVUsUUFBUSxRQUFRO0VBQ3hCLEtBQUssU0FBUyxPQUFPLE1BQU0sT0FBTyxNQUFNLE9BQU8sTUFBTSxPQUFPLE1BQU0sTUFBTTtDQUMxRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsY0FBYyxNQUFNO0VBQ2xCLEtBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLO0VBQ3JELEtBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLO0VBQ3JELEtBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLO0VBQ3JELEtBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLO0NBQ3ZEOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLFlBQVksUUFBUTtFQUNsQixNQUFNLE9BQU8sS0FBSztFQUNsQixNQUFNLE9BQU8sS0FBSztFQUNsQixNQUFNLE9BQU8sS0FBSztFQUNsQixNQUFNLE9BQU8sS0FBSztFQUNsQixNQUFNLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLE9BQU87RUFDL0IsSUFBSSxJQUFJLElBQUksT0FBTyxJQUFJLE9BQU87RUFDOUIsSUFBSSxJQUFJLElBQUksT0FBTyxJQUFJLE9BQU87RUFDOUIsS0FBSyxPQUFPO0VBQ1osS0FBSyxPQUFPO0VBQ1osS0FBSyxPQUFPO0VBQ1osS0FBSyxPQUFPO0VBQ1osSUFBSSxJQUFJLE9BQU8sSUFBSSxPQUFPO0VBQzFCLElBQUksSUFBSSxPQUFPLElBQUksT0FBTztFQUMxQixLQUFLLE9BQU8sSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLO0VBQ3JDLEtBQUssT0FBTyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUs7RUFDckMsS0FBSyxPQUFPLElBQUksS0FBSyxPQUFPLElBQUksS0FBSztFQUNyQyxLQUFLLE9BQU8sSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLO0VBQ3JDLElBQUksSUFBSSxPQUFPLElBQUksT0FBTztFQUMxQixJQUFJLElBQUksT0FBTyxJQUFJLE9BQU87RUFDMUIsS0FBSyxPQUFPLElBQUksS0FBSyxPQUFPLElBQUksS0FBSztFQUNyQyxLQUFLLE9BQU8sSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLO0VBQ3JDLEtBQUssT0FBTyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUs7RUFDckMsS0FBSyxPQUFPLElBQUksS0FBSyxPQUFPLElBQUksS0FBSztFQUNyQyxJQUFJLElBQUksT0FBTyxJQUFJLE9BQU87RUFDMUIsSUFBSSxJQUFJLE9BQU8sSUFBSSxPQUFPO0VBQzFCLEtBQUssT0FBTyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUs7RUFDckMsS0FBSyxPQUFPLElBQUksS0FBSyxPQUFPLElBQUksS0FBSztFQUNyQyxLQUFLLE9BQU8sSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLO0VBQ3JDLEtBQUssT0FBTyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUs7Q0FDdkM7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLElBQUksTUFBTTtFQUNSLElBQUksS0FBSyxPQUFPLEtBQUssTUFBTSxLQUFLLE9BQU8sS0FBSztFQUM1QyxJQUFJLEtBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxPQUFPLEtBQUs7RUFDN0MsSUFBSSxLQUFLLE9BQU8sS0FBSyxLQUFLLEtBQUssT0FBTyxLQUFLO0VBQzNDLElBQUksS0FBSyxPQUFPLEtBQUssUUFBUSxLQUFLLE9BQU8sS0FBSztFQUM5QyxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsVUFBVSxNQUFNLE9BQU8sS0FBSyxRQUFRO0VBQ2xDLElBQUksS0FBSyxPQUFPLE1BQU0sS0FBSyxPQUFPO0VBQ2xDLElBQUksS0FBSyxPQUFPLE9BQU8sS0FBSyxPQUFPO0VBQ25DLElBQUksS0FBSyxPQUFPLEtBQUssS0FBSyxPQUFPO0VBQ2pDLElBQUksS0FBSyxPQUFPLFFBQVEsS0FBSyxPQUFPO0VBQ3BDLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxJQUFJLFVBQVUsV0FBVyxVQUFVO0VBQ2pDLEtBQUssUUFBUTtFQUNiLEtBQUssUUFBUTtFQUNiLEtBQUssUUFBUTtFQUNiLEtBQUssUUFBUTtFQUNiLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsT0FBTztFQUNMLEtBQUssT0FBTyxLQUFLLE1BQU0sS0FBSyxJQUFJO0VBQ2hDLEtBQUssT0FBTyxLQUFLLE1BQU0sS0FBSyxJQUFJO0VBQ2hDLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSyxJQUFJO0VBQy9CLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSyxJQUFJO0VBQy9CLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsUUFBUTtFQUNOLE9BQU8sSUFBSSxPQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssSUFBSTtDQUM5RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLE1BQU0sR0FBRyxJQUFJLEdBQUc7RUFDZCxLQUFLLFFBQVE7RUFDYixLQUFLLFFBQVE7RUFDYixLQUFLLFFBQVE7RUFDYixLQUFLLFFBQVE7RUFDYixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxJQUFJLElBQUk7RUFDTixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksRUFBRSxPQUFPO0VBQ1gsTUFBTSxRQUFRLEtBQUssT0FBTyxLQUFLO0VBQy9CLEtBQUssT0FBTztFQUNaLEtBQUssT0FBTyxRQUFRO0NBQ3RCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsSUFBSSxJQUFJO0VBQ04sT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLEVBQUUsT0FBTztFQUNYLE1BQU0sU0FBUyxLQUFLLE9BQU8sS0FBSztFQUNoQyxLQUFLLE9BQU87RUFDWixLQUFLLE9BQU8sUUFBUTtDQUN0Qjs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUssT0FBTyxLQUFLO0NBQzFCO0NBQ0EsSUFBSSxNQUFNLE9BQU87RUFDZixLQUFLLE9BQU8sS0FBSyxPQUFPO0NBQzFCOzs7Ozs7Ozs7Ozs7OztDQWNBLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSyxPQUFPLEtBQUs7Q0FDMUI7Q0FDQSxJQUFJLE9BQU8sT0FBTztFQUNoQixLQUFLLE9BQU8sS0FBSyxPQUFPO0NBQzFCOzs7Ozs7Ozs7Ozs7Q0FZQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUs7Q0FDZDs7Ozs7Ozs7Ozs7O0NBWUEsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLO0NBQ2Q7Ozs7Ozs7Ozs7OztDQVlBLElBQUksTUFBTTtFQUNSLE9BQU8sS0FBSztDQUNkOzs7Ozs7Ozs7Ozs7Q0FZQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUs7Q0FDZDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLLEtBQUssT0FBTyxLQUFLLE9BQU87Q0FDOUQ7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxPQUFPLEtBQUssU0FBUztDQUNuQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQ0EsY0FBYyxZQUFZLGFBQWEsV0FBVyxRQUFRO0VBQ3hELElBQUksT0FBTyxLQUFLO0VBQ2hCLElBQUksT0FBTyxLQUFLO0VBQ2hCLElBQUksT0FBTyxLQUFLO0VBQ2hCLElBQUksT0FBTyxLQUFLO0VBQ2hCLFdBQVcsU0FBUyxLQUFLO0VBQ3pCLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sS0FBSyxPQUFPO0VBQ2xCLE1BQU0sS0FBSyxPQUFPO0VBQ2xCLEtBQUssSUFBSSxJQUFJLGFBQWEsSUFBSSxXQUFXLEtBQUssR0FBRztHQUMvQyxNQUFNLFNBQVMsV0FBVztHQUMxQixNQUFNLFNBQVMsV0FBVyxJQUFJO0dBQzlCLE1BQU0sSUFBSSxJQUFJLFNBQVMsSUFBSSxTQUFTO0dBQ3BDLE1BQU0sSUFBSSxJQUFJLFNBQVMsSUFBSSxTQUFTO0dBQ3BDLE9BQU8sSUFBSSxPQUFPLElBQUk7R0FDdEIsT0FBTyxJQUFJLE9BQU8sSUFBSTtHQUN0QixPQUFPLElBQUksT0FBTyxJQUFJO0dBQ3RCLE9BQU8sSUFBSSxPQUFPLElBQUk7RUFDeEI7RUFDQSxLQUFLLE9BQU87RUFDWixLQUFLLE9BQU87RUFDWixLQUFLLE9BQU87RUFDWixLQUFLLE9BQU87Q0FDZDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLGNBQWMsR0FBRyxHQUFHO0VBQ2xCLElBQUksS0FBSyxRQUFRLEtBQUssS0FBSyxRQUFRLEtBQUssS0FBSyxRQUFRLEtBQUssS0FBSyxRQUFRLEdBQ3JFLE9BQU87RUFFVCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Q0FhQSxXQUFXO0VBQ1QsT0FBTyx3QkFBd0IsS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLLFNBQVMsS0FBSyxNQUFNLFVBQVUsS0FBSyxPQUFPO0NBQzNJOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxTQUFTLFFBQVE7RUFDZixLQUFLLE9BQU8sT0FBTztFQUNuQixLQUFLLE9BQU8sT0FBTztFQUNuQixLQUFLLE9BQU8sT0FBTztFQUNuQixLQUFLLE9BQU8sT0FBTztFQUNuQixPQUFPO0NBQ1Q7QUFDRjs7O0FDdnpCQSxJQUFJLElBQUU7Q0FBQyxNQUFLO0NBQUcsTUFBSztDQUFJLEtBQUksT0FBSyxJQUFFLEtBQUs7QUFBRztBQUFFLElBQUEsSUFBRSxTQUFTLEdBQUU7Q0FBQyxPQUFNLFlBQVUsT0FBTyxJQUFFLEVBQUUsU0FBTyxJQUFFLFlBQVUsT0FBTztBQUFDO0FBQUUsSUFBQSxJQUFFLFNBQVMsR0FBRSxHQUFFLEdBQUU7Q0FBQyxPQUFPLEtBQUssTUFBSSxNQUFJLElBQUUsSUFBRyxLQUFLLE1BQUksTUFBSSxJQUFFLEtBQUssSUFBSSxJQUFHLENBQUMsSUFBRyxLQUFLLE1BQU0sSUFBRSxDQUFDLElBQUUsSUFBRTtBQUFDO0FBQUUsSUFBQSxJQUFFLFNBQVMsR0FBRSxHQUFFLEdBQUU7Q0FBQyxPQUFPLEtBQUssTUFBSSxNQUFJLElBQUUsSUFBRyxLQUFLLE1BQUksTUFBSSxJQUFFLElBQUcsSUFBRSxJQUFFLElBQUUsSUFBRSxJQUFFLElBQUU7QUFBQztBQUFFLElBQUEsSUFBRSxTQUFTLEdBQUU7Q0FBQyxRQUFPLElBQUUsU0FBUyxDQUFDLElBQUUsSUFBRSxNQUFJLEtBQUcsSUFBRSxJQUFFLElBQUU7QUFBRztBQUFFLElBQUEsSUFBRSxTQUFTLEdBQUU7Q0FBQyxPQUFNO0VBQUMsR0FBRSxFQUFFLEVBQUUsR0FBRSxHQUFFLEdBQUc7RUFBRSxHQUFFLEVBQUUsRUFBRSxHQUFFLEdBQUUsR0FBRztFQUFFLEdBQUUsRUFBRSxFQUFFLEdBQUUsR0FBRSxHQUFHO0VBQUUsR0FBRSxFQUFFLEVBQUUsQ0FBQztDQUFDO0FBQUM7QUFBRSxJQUFBLElBQUUsU0FBUyxHQUFFO0NBQUMsT0FBTTtFQUFDLEdBQUUsRUFBRSxFQUFFLENBQUM7RUFBRSxHQUFFLEVBQUUsRUFBRSxDQUFDO0VBQUUsR0FBRSxFQUFFLEVBQUUsQ0FBQztFQUFFLEdBQUUsRUFBRSxFQUFFLEdBQUUsQ0FBQztDQUFDO0FBQUM7QUFBRSxJQUFBLElBQUU7QUFBc0IsSUFBQSxJQUFFLFNBQVMsR0FBRTtDQUFDLElBQUksSUFBRSxFQUFFLFNBQVMsRUFBRTtDQUFFLE9BQU8sRUFBRSxTQUFPLElBQUUsTUFBSSxJQUFFO0FBQUM7QUFBRSxJQUFBLElBQUUsU0FBUyxHQUFFO0NBQUMsSUFBSSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEtBQUssSUFBSSxHQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUUsSUFBRSxLQUFLLElBQUksR0FBRSxHQUFFLENBQUMsR0FBRSxJQUFFLElBQUUsTUFBSSxLQUFHLElBQUUsS0FBRyxJQUFFLE1BQUksSUFBRSxLQUFHLElBQUUsS0FBRyxJQUFFLEtBQUcsSUFBRSxLQUFHLElBQUU7Q0FBRSxPQUFNO0VBQUMsR0FBRSxNQUFJLElBQUUsSUFBRSxJQUFFLElBQUU7RUFBRyxHQUFFLElBQUUsSUFBRSxJQUFFLE1BQUk7RUFBRSxHQUFFLElBQUUsTUFBSTtFQUFJLEdBQUU7Q0FBQztBQUFDO0FBQUUsSUFBQSxJQUFFLFNBQVMsR0FBRTtDQUFDLElBQUksSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFO0NBQUUsSUFBRSxJQUFFLE1BQUksR0FBRSxLQUFHLEtBQUksS0FBRztDQUFJLElBQUksSUFBRSxLQUFLLE1BQU0sQ0FBQyxHQUFFLElBQUUsS0FBRyxJQUFFLElBQUcsSUFBRSxLQUFHLEtBQUcsSUFBRSxLQUFHLElBQUcsSUFBRSxLQUFHLEtBQUcsSUFBRSxJQUFFLEtBQUcsSUFBRyxJQUFFLElBQUU7Q0FBRSxPQUFNO0VBQUMsR0FBRSxNQUFJO0dBQUM7R0FBRTtHQUFFO0dBQUU7R0FBRTtHQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQUcsR0FBRSxNQUFJO0dBQUM7R0FBRTtHQUFFO0dBQUU7R0FBRTtHQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQUcsR0FBRSxNQUFJO0dBQUM7R0FBRTtHQUFFO0dBQUU7R0FBRTtHQUFFO0VBQUMsQ0FBQyxDQUFDO0VBQUcsR0FBRTtDQUFDO0FBQUM7QUFBRSxJQUFBLElBQUUsU0FBUyxHQUFFO0NBQUMsT0FBTTtFQUFDLEdBQUUsRUFBRSxFQUFFLENBQUM7RUFBRSxHQUFFLEVBQUUsRUFBRSxHQUFFLEdBQUUsR0FBRztFQUFFLEdBQUUsRUFBRSxFQUFFLEdBQUUsR0FBRSxHQUFHO0VBQUUsR0FBRSxFQUFFLEVBQUUsQ0FBQztDQUFDO0FBQUM7QUFBRSxJQUFBLElBQUUsU0FBUyxHQUFFO0NBQUMsT0FBTTtFQUFDLEdBQUUsRUFBRSxFQUFFLENBQUM7RUFBRSxHQUFFLEVBQUUsRUFBRSxDQUFDO0VBQUUsR0FBRSxFQUFFLEVBQUUsQ0FBQztFQUFFLEdBQUUsRUFBRSxFQUFFLEdBQUUsQ0FBQztDQUFDO0FBQUM7QUFBRSxJQUFBLElBQUUsU0FBUyxHQUFFO0NBQUMsT0FBTyxHQUFHLEtBQUcsSUFBRSxFQUFBLENBQUcsR0FBRTtFQUFDLEdBQUUsRUFBRTtFQUFFLElBQUcsT0FBSyxJQUFFLEVBQUUsS0FBRyxLQUFHLElBQUUsTUFBSSxLQUFHLE9BQUssSUFBRSxJQUFFLEtBQUcsSUFBRSxLQUFHLE1BQUk7RUFBRSxHQUFFLElBQUU7RUFBRSxHQUFFLEVBQUU7Q0FBQyxFQUFFO0tBQU0sR0FBRSxHQUFFO0FBQUM7QUFBRSxJQUFBLElBQUUsU0FBUyxHQUFFO0NBQUMsT0FBTTtFQUFDLElBQUcsSUFBRSxFQUFFLENBQUMsRUFBQSxDQUFHO0VBQUUsSUFBRyxLQUFHLE9BQUssSUFBRSxFQUFFLE9BQUssSUFBRSxFQUFFLEtBQUcsT0FBSyxLQUFHLElBQUUsTUFBSSxJQUFFLElBQUUsT0FBSyxLQUFHLE1BQUksSUFBRSxNQUFJLEtBQUcsTUFBSTtFQUFFLEdBQUUsSUFBRTtFQUFFLEdBQUUsRUFBRTtDQUFDO0tBQU0sR0FBRSxHQUFFLEdBQUU7QUFBQztBQUFFLElBQUEsSUFBRTtBQUF5SSxJQUFBLElBQUU7QUFBa0ksSUFBQSxJQUFFO0FBQStILElBQUEsSUFBRTtBQUF3SCxJQUFBLElBQUU7Q0FBQyxRQUFPO0VBQUMsQ0FBQyxTQUFTLEdBQUU7R0FBQyxJQUFJLElBQUUsRUFBRSxLQUFLLENBQUM7R0FBRSxPQUFPLEtBQUcsSUFBRSxFQUFFLEdBQUEsQ0FBSSxVQUFRLElBQUU7SUFBQyxHQUFFLFNBQVMsRUFBRSxLQUFHLEVBQUUsSUFBRyxFQUFFO0lBQUUsR0FBRSxTQUFTLEVBQUUsS0FBRyxFQUFFLElBQUcsRUFBRTtJQUFFLEdBQUUsU0FBUyxFQUFFLEtBQUcsRUFBRSxJQUFHLEVBQUU7SUFBRSxHQUFFLE1BQUksRUFBRSxTQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUcsRUFBRSxJQUFHLEVBQUUsSUFBRSxLQUFJLENBQUMsSUFBRTtHQUFDLElBQUUsTUFBSSxFQUFFLFVBQVEsTUFBSSxFQUFFLFNBQU87SUFBQyxHQUFFLFNBQVMsRUFBRSxPQUFPLEdBQUUsQ0FBQyxHQUFFLEVBQUU7SUFBRSxHQUFFLFNBQVMsRUFBRSxPQUFPLEdBQUUsQ0FBQyxHQUFFLEVBQUU7SUFBRSxHQUFFLFNBQVMsRUFBRSxPQUFPLEdBQUUsQ0FBQyxHQUFFLEVBQUU7SUFBRSxHQUFFLE1BQUksRUFBRSxTQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sR0FBRSxDQUFDLEdBQUUsRUFBRSxJQUFFLEtBQUksQ0FBQyxJQUFFO0dBQUMsSUFBRSxPQUFLO0VBQUksR0FBRSxLQUFLO0VBQUUsQ0FBQyxTQUFTLEdBQUU7R0FBQyxJQUFJLElBQUUsRUFBRSxLQUFLLENBQUMsS0FBRyxFQUFFLEtBQUssQ0FBQztHQUFFLE9BQU8sSUFBRSxFQUFFLE9BQUssRUFBRSxNQUFJLEVBQUUsT0FBSyxFQUFFLEtBQUcsT0FBSyxFQUFFO0lBQUMsR0FBRSxPQUFPLEVBQUUsRUFBRSxLQUFHLEVBQUUsS0FBRyxNQUFJLE1BQUk7SUFBRyxHQUFFLE9BQU8sRUFBRSxFQUFFLEtBQUcsRUFBRSxLQUFHLE1BQUksTUFBSTtJQUFHLEdBQUUsT0FBTyxFQUFFLEVBQUUsS0FBRyxFQUFFLEtBQUcsTUFBSSxNQUFJO0lBQUcsR0FBRSxLQUFLLE1BQUksRUFBRSxLQUFHLElBQUUsT0FBTyxFQUFFLEVBQUUsS0FBRyxFQUFFLEtBQUcsTUFBSTtHQUFFLENBQUMsSUFBRTtFQUFJLEdBQUUsS0FBSztFQUFFLENBQUMsU0FBUyxHQUFFO0dBQUMsSUFBSSxJQUFFLEVBQUUsS0FBSyxDQUFDLEtBQUcsRUFBRSxLQUFLLENBQUM7R0FBRSxJQUFHLENBQUMsR0FBRSxPQUFPO0dBQUssSUFBSSxHQUFFO0dBQStJLE9BQU8sRUFBbEosRUFBRTtJQUFDLElBQUcsSUFBRSxFQUFFLElBQUcsSUFBRSxFQUFFLElBQUcsS0FBSyxNQUFJLE1BQUksSUFBRSxRQUFPLE9BQU8sQ0FBQyxLQUFHLEVBQUUsTUFBSTtJQUFJLEdBQUUsT0FBTyxFQUFFLEVBQUU7SUFBRSxHQUFFLE9BQU8sRUFBRSxFQUFFO0lBQUUsR0FBRSxLQUFLLE1BQUksRUFBRSxLQUFHLElBQUUsT0FBTyxFQUFFLEVBQUUsS0FBRyxFQUFFLEtBQUcsTUFBSTtHQUFFLENBQVksQ0FBQztFQUFDLEdBQUUsS0FBSztDQUFDO0NBQUUsUUFBTztFQUFDLENBQUMsU0FBUyxHQUFFO0dBQUMsSUFBSSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEtBQUssTUFBSSxJQUFFLElBQUU7R0FBRSxPQUFPLEVBQUUsQ0FBQyxLQUFHLEVBQUUsQ0FBQyxLQUFHLEVBQUUsQ0FBQyxJQUFFLEVBQUU7SUFBQyxHQUFFLE9BQU8sQ0FBQztJQUFFLEdBQUUsT0FBTyxDQUFDO0lBQUUsR0FBRSxPQUFPLENBQUM7SUFBRSxHQUFFLE9BQU8sQ0FBQztHQUFDLENBQUMsSUFBRTtFQUFJLEdBQUUsS0FBSztFQUFFLENBQUMsU0FBUyxHQUFFO0dBQUMsSUFBSSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEtBQUssTUFBSSxJQUFFLElBQUU7R0FBRSxJQUFHLENBQUMsRUFBRSxDQUFDLEtBQUcsQ0FBQyxFQUFFLENBQUMsS0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFFLE9BQU87R0FBZ0UsT0FBTyxFQUE1RCxFQUFFO0lBQUMsR0FBRSxPQUFPLENBQUM7SUFBRSxHQUFFLE9BQU8sQ0FBQztJQUFFLEdBQUUsT0FBTyxDQUFDO0lBQUUsR0FBRSxPQUFPLENBQUM7R0FBQyxDQUFZLENBQUM7RUFBQyxHQUFFLEtBQUs7RUFBRSxDQUFDLFNBQVMsR0FBRTtHQUFDLElBQUksSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFLEdBQUUsSUFBRSxLQUFLLE1BQUksSUFBRSxJQUFFO0dBQUUsSUFBRyxDQUFDLEVBQUUsQ0FBQyxLQUFHLENBQUMsRUFBRSxDQUFDLEtBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRSxPQUFPO0dBQW1JLE9BQU8sRUFBL0gsU0FBUyxHQUFFO0lBQUMsT0FBTTtLQUFDLEdBQUUsRUFBRSxFQUFFLENBQUM7S0FBRSxHQUFFLEVBQUUsRUFBRSxHQUFFLEdBQUUsR0FBRztLQUFFLEdBQUUsRUFBRSxFQUFFLEdBQUUsR0FBRSxHQUFHO0tBQUUsR0FBRSxFQUFFLEVBQUUsQ0FBQztJQUFDO0dBQUMsRUFBRTtJQUFDLEdBQUUsT0FBTyxDQUFDO0lBQUUsR0FBRSxPQUFPLENBQUM7SUFBRSxHQUFFLE9BQU8sQ0FBQztJQUFFLEdBQUUsT0FBTyxDQUFDO0dBQUMsQ0FBWSxDQUFDO0VBQUMsR0FBRSxLQUFLO0NBQUM7QUFBQztBQUFFLElBQUEsSUFBRSxTQUFTLEdBQUUsR0FBRTtDQUFDLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBSTtFQUFDLElBQUksSUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUFFLElBQUcsR0FBRSxPQUFNLENBQUMsR0FBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFO0NBQUM7Q0FBQyxPQUFNLENBQUMsTUFBSyxLQUFLLENBQUM7QUFBQztBQUFFLElBQUEsSUFBRSxTQUFTLEdBQUU7Q0FBQyxPQUFNLFlBQVUsT0FBTyxJQUFFLEVBQUUsRUFBRSxLQUFLLEdBQUUsRUFBRSxNQUFNLElBQUUsWUFBVSxPQUFPLEtBQUcsU0FBTyxJQUFFLEVBQUUsR0FBRSxFQUFFLE1BQU0sSUFBRSxDQUFDLE1BQUssS0FBSyxDQUFDO0FBQUM7QUFBZ0MsSUFBQSxJQUFFLFNBQVMsR0FBRSxHQUFFO0NBQUMsSUFBSSxJQUFFLEVBQUUsQ0FBQztDQUFFLE9BQU07RUFBQyxHQUFFLEVBQUU7RUFBRSxHQUFFLEVBQUUsRUFBRSxJQUFFLE1BQUksR0FBRSxHQUFFLEdBQUc7RUFBRSxHQUFFLEVBQUU7RUFBRSxHQUFFLEVBQUU7Q0FBQztBQUFDO0FBQUUsSUFBQSxJQUFFLFNBQVMsR0FBRTtDQUFDLFFBQU8sTUFBSSxFQUFFLElBQUUsTUFBSSxFQUFFLElBQUUsTUFBSSxFQUFFLEtBQUcsTUFBSTtBQUFHO0FBQUUsSUFBQSxJQUFFLFNBQVMsR0FBRSxHQUFFO0NBQUMsSUFBSSxJQUFFLEVBQUUsQ0FBQztDQUFFLE9BQU07RUFBQyxHQUFFLEVBQUU7RUFBRSxHQUFFLEVBQUU7RUFBRSxHQUFFLEVBQUUsRUFBRSxJQUFFLE1BQUksR0FBRSxHQUFFLEdBQUc7RUFBRSxHQUFFLEVBQUU7Q0FBQztBQUFDO0FBQUUsSUFBQSxJQUFFLFdBQVU7Q0FBQyxTQUFTLEVBQUUsR0FBRTtFQUFDLEtBQUssU0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUcsS0FBSyxPQUFLLEtBQUssVUFBUTtHQUFDLEdBQUU7R0FBRSxHQUFFO0dBQUUsR0FBRTtHQUFFLEdBQUU7RUFBQztDQUFDO0NBQUMsT0FBTyxFQUFFLFVBQVUsVUFBUSxXQUFVO0VBQUMsT0FBTyxTQUFPLEtBQUs7Q0FBTSxHQUFFLEVBQUUsVUFBVSxhQUFXLFdBQVU7RUFBQyxPQUFPLEVBQUUsRUFBRSxLQUFLLElBQUksR0FBRSxDQUFDO0NBQUMsR0FBRSxFQUFFLFVBQVUsU0FBTyxXQUFVO0VBQUMsT0FBTyxFQUFFLEtBQUssSUFBSSxJQUFFO0NBQUUsR0FBRSxFQUFFLFVBQVUsVUFBUSxXQUFVO0VBQUMsT0FBTyxFQUFFLEtBQUssSUFBSSxLQUFHO0NBQUUsR0FBRSxFQUFFLFVBQVUsUUFBTSxXQUFVO0VBQUMsT0FBTyxJQUFFLEVBQUUsS0FBSyxJQUFJLEdBQUUsSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFLEdBQUUsSUFBRSxFQUFFLEdBQUUsS0FBRyxJQUFFLEVBQUUsS0FBRyxJQUFFLEVBQUUsRUFBRSxNQUFJLENBQUMsQ0FBQyxJQUFFLElBQUcsTUFBSSxFQUFFLENBQUMsSUFBRSxFQUFFLENBQUMsSUFBRSxFQUFFLENBQUMsSUFBRTtNQUFNLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRTtDQUFDLEdBQUUsRUFBRSxVQUFVLFFBQU0sV0FBVTtFQUFDLE9BQU8sRUFBRSxLQUFLLElBQUk7Q0FBQyxHQUFFLEVBQUUsVUFBVSxjQUFZLFdBQVU7RUFBQyxPQUFPLElBQUUsRUFBRSxLQUFLLElBQUksR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsSUFBRyxJQUFFLEVBQUUsS0FBRyxJQUFFLFVBQVEsSUFBRSxPQUFLLElBQUUsT0FBSyxJQUFFLE9BQUssSUFBRSxNQUFJLFNBQU8sSUFBRSxPQUFLLElBQUUsT0FBSyxJQUFFO01BQVEsR0FBRSxHQUFFLEdBQUUsR0FBRTtDQUFDLEdBQUUsRUFBRSxVQUFVLFFBQU0sV0FBVTtFQUFDLE9BQU8sRUFBRSxFQUFFLEtBQUssSUFBSSxDQUFDO0NBQUMsR0FBRSxFQUFFLFVBQVUsY0FBWSxXQUFVO0VBQUMsT0FBTyxJQUFFLEVBQUUsRUFBRSxLQUFLLElBQUksQ0FBQyxHQUFFLElBQUUsRUFBRSxHQUFFLElBQUUsRUFBRSxHQUFFLElBQUUsRUFBRSxJQUFHLElBQUUsRUFBRSxLQUFHLElBQUUsVUFBUSxJQUFFLE9BQUssSUFBRSxRQUFNLElBQUUsUUFBTSxJQUFFLE1BQUksU0FBTyxJQUFFLE9BQUssSUFBRSxRQUFNLElBQUU7TUFBUyxHQUFFLEdBQUUsR0FBRSxHQUFFO0NBQUMsR0FBRSxFQUFFLFVBQVUsUUFBTSxXQUFVO0VBQUMsT0FBTyxJQUFFLEVBQUUsS0FBSyxJQUFJLEdBQUU7R0FBQyxHQUFFLEVBQUUsRUFBRSxDQUFDO0dBQUUsR0FBRSxFQUFFLEVBQUUsQ0FBQztHQUFFLEdBQUUsRUFBRSxFQUFFLENBQUM7R0FBRSxHQUFFLEVBQUUsRUFBRSxHQUFFLENBQUM7RUFBQztNQUFNO0NBQUMsR0FBRSxFQUFFLFVBQVUsU0FBTyxXQUFVO0VBQUMsT0FBTyxFQUFFO0dBQUMsR0FBRSxPQUFLLElBQUUsS0FBSyxLQUFBLENBQU07R0FBRSxHQUFFLE1BQUksRUFBRTtHQUFFLEdBQUUsTUFBSSxFQUFFO0dBQUUsR0FBRSxFQUFFO0VBQUMsQ0FBQztNQUFNO0NBQUMsR0FBRSxFQUFFLFVBQVUsV0FBUyxTQUFTLEdBQUU7RUFBQyxPQUFPLEtBQUssTUFBSSxNQUFJLElBQUUsS0FBSSxFQUFFLEVBQUUsS0FBSyxNQUFLLENBQUMsQ0FBQztDQUFDLEdBQUUsRUFBRSxVQUFVLGFBQVcsU0FBUyxHQUFFO0VBQUMsT0FBTyxLQUFLLE1BQUksTUFBSSxJQUFFLEtBQUksRUFBRSxFQUFFLEtBQUssTUFBSyxDQUFDLENBQUMsQ0FBQztDQUFDLEdBQUUsRUFBRSxVQUFVLFlBQVUsV0FBVTtFQUFDLE9BQU8sRUFBRSxFQUFFLEtBQUssTUFBSyxFQUFFLENBQUM7Q0FBQyxHQUFFLEVBQUUsVUFBVSxVQUFRLFNBQVMsR0FBRTtFQUFDLE9BQU8sS0FBSyxNQUFJLE1BQUksSUFBRSxLQUFJLEVBQUUsRUFBRSxLQUFLLE1BQUssQ0FBQyxDQUFDO0NBQUMsR0FBRSxFQUFFLFVBQVUsU0FBTyxTQUFTLEdBQUU7RUFBQyxPQUFPLEtBQUssTUFBSSxNQUFJLElBQUUsS0FBSSxFQUFFLEVBQUUsS0FBSyxNQUFLLENBQUMsQ0FBQyxDQUFDO0NBQUMsR0FBRSxFQUFFLFVBQVUsU0FBTyxTQUFTLEdBQUU7RUFBQyxPQUFPLEtBQUssTUFBSSxNQUFJLElBQUUsS0FBSSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUUsQ0FBQztDQUFDLEdBQUUsRUFBRSxVQUFVLFFBQU0sU0FBUyxHQUFFO0VBQUMsT0FBTSxZQUFVLE9BQU8sSUFBRSxFQUFFO0dBQUMsSUFBRyxJQUFFLEtBQUssS0FBQSxDQUFNO0dBQUUsR0FBRSxFQUFFO0dBQUUsR0FBRSxFQUFFO0dBQUUsR0FBRTtFQUFDLENBQUMsSUFBRSxFQUFFLEtBQUssS0FBSyxHQUFFLENBQUM7TUFBTTtDQUFDLEdBQUUsRUFBRSxVQUFVLE1BQUksU0FBUyxHQUFFO0VBQUMsSUFBSSxJQUFFLEVBQUUsS0FBSyxJQUFJO0VBQUUsT0FBTSxZQUFVLE9BQU8sSUFBRSxFQUFFO0dBQUMsR0FBRTtHQUFFLEdBQUUsRUFBRTtHQUFFLEdBQUUsRUFBRTtHQUFFLEdBQUUsRUFBRTtFQUFDLENBQUMsSUFBRSxFQUFFLEVBQUUsQ0FBQztDQUFDLEdBQUUsRUFBRSxVQUFVLFVBQVEsU0FBUyxHQUFFO0VBQUMsT0FBTyxLQUFLLE1BQU0sTUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU07Q0FBQyxHQUFFO0FBQUMsRUFBRTtBQUFFLElBQUEsSUFBRSxTQUFTLEdBQUU7Q0FBQyxPQUFPLGFBQWEsSUFBRSxJQUFFLElBQUksRUFBRSxDQUFDO0FBQUM7QUFBRSxJQUFBLElBQUUsQ0FBQztBQUFFLElBQUEsSUFBRSxTQUFTLEdBQUU7Q0FBQyxFQUFFLFFBQVEsU0FBUyxHQUFFO0VBQUMsRUFBRSxRQUFRLENBQUMsSUFBRSxNQUFJLEVBQUUsR0FBRSxDQUFDLEdBQUUsRUFBRSxLQUFLLENBQUM7Q0FBRSxDQUFDO0FBQUM7OztBQ0F4a0wsU0FBQSxjQUF3QixHQUFFLEdBQUU7Q0FBQyxJQUFJLElBQUU7RUFBQyxPQUFNO0VBQVUsUUFBTztFQUFVLE1BQUs7RUFBVSxXQUFVO0VBQVUsWUFBVztFQUFVLFdBQVU7RUFBVSxPQUFNO0VBQVUsY0FBYTtFQUFVLE1BQUs7RUFBVSxPQUFNO0VBQVUsWUFBVztFQUFVLFlBQVc7RUFBVSxNQUFLO0VBQVUsZ0JBQWU7RUFBVSxPQUFNO0VBQVUsTUFBSztFQUFVLFdBQVU7RUFBVSxXQUFVO0VBQVUsVUFBUztFQUFVLGdCQUFlO0VBQVUsV0FBVTtFQUFVLFlBQVc7RUFBVSxPQUFNO0VBQVUsU0FBUTtFQUFVLE1BQUs7RUFBVSxVQUFTO0VBQVUsVUFBUztFQUFVLGVBQWM7RUFBVSxXQUFVO0VBQVUsVUFBUztFQUFVLFdBQVU7RUFBVSxVQUFTO0VBQVUsV0FBVTtFQUFVLGFBQVk7RUFBVSxTQUFRO0VBQVUsWUFBVztFQUFVLFlBQVc7RUFBVSxlQUFjO0VBQVUsTUFBSztFQUFVLGVBQWM7RUFBVSxlQUFjO0VBQVUsVUFBUztFQUFVLGFBQVk7RUFBVSxPQUFNO0VBQVUsV0FBVTtFQUFVLGFBQVk7RUFBVSxZQUFXO0VBQVUsWUFBVztFQUFVLFNBQVE7RUFBVSxPQUFNO0VBQVUsWUFBVztFQUFVLE1BQUs7RUFBVSxVQUFTO0VBQVUsU0FBUTtFQUFVLFlBQVc7RUFBVSxhQUFZO0VBQVUsV0FBVTtFQUFVLFdBQVU7RUFBVSxRQUFPO0VBQVUsU0FBUTtFQUFVLE9BQU07RUFBVSxRQUFPO0VBQVUsWUFBVztFQUFVLFlBQVc7RUFBVSxlQUFjO0VBQVUsV0FBVTtFQUFVLE9BQU07RUFBVSxhQUFZO0VBQVUsYUFBWTtFQUFVLGVBQWM7RUFBVSxPQUFNO0VBQVUsa0JBQWlCO0VBQVUsY0FBYTtFQUFVLE1BQUs7RUFBVSxPQUFNO0VBQVUsZ0JBQWU7RUFBVSxXQUFVO0VBQVUsbUJBQWtCO0VBQVUsY0FBYTtFQUFVLFdBQVU7RUFBVSxjQUFhO0VBQVUsV0FBVTtFQUFVLFdBQVU7RUFBVSxVQUFTO0VBQVUsV0FBVTtFQUFVLGdCQUFlO0VBQVUsZ0JBQWU7RUFBVSxhQUFZO0VBQVUsTUFBSztFQUFVLGlCQUFnQjtFQUFVLFlBQVc7RUFBVSxlQUFjO0VBQVUsU0FBUTtFQUFVLGVBQWM7RUFBVSxpQkFBZ0I7RUFBVSxjQUFhO0VBQVUsZUFBYztFQUFVLGdCQUFlO0VBQVUsaUJBQWdCO0VBQVUsU0FBUTtFQUFVLEtBQUk7RUFBVSxRQUFPO0VBQVUsY0FBYTtFQUFVLFFBQU87RUFBVSxNQUFLO0VBQVUsU0FBUTtFQUFVLGFBQVk7RUFBVSxXQUFVO0VBQVUsS0FBSTtFQUFVLFFBQU87RUFBVSxXQUFVO0VBQVUsZUFBYztFQUFVLE1BQUs7RUFBVSxlQUFjO0VBQVUsUUFBTztFQUFVLE1BQUs7RUFBVSxXQUFVO0VBQVUsV0FBVTtFQUFVLFdBQVU7RUFBVSxjQUFhO0VBQVUsZ0JBQWU7RUFBVSxhQUFZO0VBQVUsVUFBUztFQUFVLFVBQVM7RUFBVSxRQUFPO0VBQVUsUUFBTztFQUFVLFFBQU87RUFBVSxVQUFTO0VBQVUsWUFBVztFQUFVLFFBQU87RUFBVSxXQUFVO0VBQVUsV0FBVTtFQUFVLFdBQVU7RUFBVSxXQUFVO0VBQVUsYUFBWTtFQUFVLFFBQU87RUFBVSxhQUFZO0VBQVUsWUFBVztFQUFVLFdBQVU7RUFBVSxZQUFXO0VBQVUsc0JBQXFCO0VBQVUsTUFBSztFQUFVLFdBQVU7RUFBVSxXQUFVO0VBQVUsU0FBUTtFQUFVLFNBQVE7RUFBVSxXQUFVO0VBQVUsT0FBTTtDQUFTLEdBQUUsSUFBRSxDQUFDO0NBQUUsS0FBSSxJQUFJLEtBQUssR0FBRSxFQUFFLEVBQUUsTUFBSTtDQUFFLElBQUksSUFBRSxDQUFDO0NBQUUsRUFBRSxVQUFVLFNBQU8sU0FBUyxHQUFFO0VBQUMsSUFBRyxFQUFFLEtBQUssS0FBSyxLQUFHLEtBQUssS0FBSyxLQUFHLEtBQUssS0FBSyxLQUFHLEtBQUssS0FBSyxJQUFHLE9BQU07RUFBYyxJQUFJLEdBQUUsR0FBRSxJQUFFLEVBQUUsS0FBSyxNQUFNO0VBQUcsSUFBRyxHQUFFLE9BQU87RUFBRSxJQUFHLFFBQU0sSUFBRSxLQUFLLElBQUUsRUFBRSxTQUFRO0dBQUMsSUFBSSxJQUFFLEtBQUssTUFBTSxHQUFFLElBQUUsSUFBRSxHQUFFLElBQUU7R0FBUSxJQUFHLENBQUMsRUFBRSxRQUFPLEtBQUksSUFBSSxLQUFLLEdBQUUsRUFBRSxLQUFHLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLE1BQU07R0FBRSxLQUFJLElBQUksS0FBSyxHQUFFO0lBQUMsSUFBSSxLQUFHLElBQUUsR0FBRSxJQUFFLEVBQUUsSUFBRyxLQUFLLElBQUksRUFBRSxJQUFFLEVBQUUsR0FBRSxDQUFDLElBQUUsS0FBSyxJQUFJLEVBQUUsSUFBRSxFQUFFLEdBQUUsQ0FBQyxJQUFFLEtBQUssSUFBSSxFQUFFLElBQUUsRUFBRSxHQUFFLENBQUM7SUFBRyxJQUFFLE1BQUksSUFBRSxHQUFFLElBQUU7R0FBRTtHQUFDLE9BQU87RUFBQztDQUFDO0NBQUUsRUFBRSxPQUFPLEtBQUssQ0FBQyxTQUFTLEdBQUU7RUFBQyxJQUFJLElBQUUsRUFBRSxZQUFZLEdBQUUsSUFBRSxrQkFBZ0IsSUFBRSxVQUFRLEVBQUU7RUFBRyxPQUFPLElBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBRTtDQUFJLEdBQUUsTUFBTSxDQUFDO0FBQUM7OztBQ0k5OEdDLEVBQU8sQ0FBQ0MsYUFBVyxDQUFDO0FBQ3BCLElBQU0sU0FBUyxNQUFNLE9BQU87Ozs7Q0FJMUIsWUFBWSxRQUFRLFVBQVU7RUFDNUIsS0FBSyxTQUFTO0VBQ2QsS0FBSyw4QkFBYyxJQUFJLGFBQWEsQ0FBQztFQUNyQyxLQUFLLFlBQVksS0FBSyxDQUFDO0VBQ3ZCLEtBQUssT0FBTztFQUNaLEtBQUssUUFBUTtDQUNmOzs7Ozs7Ozs7Ozs7Q0FZQSxJQUFJLE1BQU07RUFDUixPQUFPLEtBQUssWUFBWTtDQUMxQjs7Ozs7Ozs7Ozs7O0NBWUEsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLFlBQVk7Q0FDMUI7Ozs7Ozs7Ozs7OztDQVlBLElBQUksT0FBTztFQUNULE9BQU8sS0FBSyxZQUFZO0NBQzFCOzs7Ozs7Ozs7Ozs7Q0FZQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUssWUFBWTtDQUMxQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtDQSxTQUFTLE9BQU87RUFDZCxLQUFLLFFBQVE7RUFDYixPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0NBLElBQUksTUFBTSxPQUFPO0VBQ2YsSUFBSSxpQkFBaUIsUUFBUTtHQUMzQixLQUFLLFNBQVMsS0FBSyxhQUFhLE1BQU0sTUFBTTtHQUM1QyxLQUFLLE9BQU8sTUFBTTtHQUNsQixLQUFLLFlBQVksSUFBSSxNQUFNLFdBQVc7RUFDeEMsT0FBTyxJQUFJLFVBQVUsTUFDbkIsTUFBTSxJQUFJLE1BQU0sZ0NBQWdDO09BQzNDLElBQUksS0FBSyxXQUFXLFFBQVEsQ0FBQyxLQUFLLGVBQWUsS0FBSyxRQUFRLEtBQUssR0FBRztHQUMzRSxLQUFLLFNBQVMsS0FBSyxhQUFhLEtBQUs7R0FDckMsS0FBSyxXQUFXLEtBQUssTUFBTTtFQUM3QjtDQUNGO0NBQ0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLO0NBQ2Q7Ozs7O0NBS0EsYUFBYSxPQUFPO0VBQ2xCLElBQUksT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFlBQVksaUJBQWlCLFVBQVUsVUFBVSxNQUNqRyxPQUFPO09BQ0YsSUFBSSxNQUFNLFFBQVEsS0FBSyxLQUFLLFlBQVksT0FBTyxLQUFLLEdBQ3pELE9BQU8sTUFBTSxNQUFNLENBQUM7T0FDZixJQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsTUFDaEQsT0FBTyxFQUFFLEdBQUcsTUFBTTtFQUVwQixPQUFPO0NBQ1Q7Ozs7Ozs7Q0FPQSxlQUFlLFFBQVEsUUFBUTtFQUM3QixNQUFNLFFBQVEsT0FBTztFQUVyQixJQUFJLFVBQVUsT0FETyxRQUVuQixPQUFPO09BQ0YsSUFBSSxVQUFVLFlBQVksVUFBVSxZQUFZLGtCQUFrQixRQUN2RSxPQUFPLFdBQVc7T0FDYixJQUFJLE1BQU0sUUFBUSxNQUFNLEtBQUssTUFBTSxRQUFRLE1BQU0sS0FBSyxZQUFZLE9BQU8sTUFBTSxLQUFLLFlBQVksT0FBTyxNQUFNLEdBQUc7R0FDckgsSUFBSSxPQUFPLFdBQVcsT0FBTyxRQUMzQixPQUFPO0dBRVQsT0FBTyxPQUFPLE9BQU8sR0FBRyxNQUFNLE1BQU0sT0FBTyxFQUFFO0VBQy9DLE9BQU8sSUFBSSxXQUFXLFFBQVEsV0FBVyxNQUFNO0dBQzdDLE1BQU0sUUFBUSxPQUFPLEtBQUssTUFBTTtHQUNoQyxNQUFNLFFBQVEsT0FBTyxLQUFLLE1BQU07R0FDaEMsSUFBSSxNQUFNLFdBQVcsTUFBTSxRQUN6QixPQUFPO0dBRVQsT0FBTyxNQUFNLE9BQU8sUUFBUSxPQUFPLFNBQVMsT0FBTyxJQUFJO0VBQ3pEO0VBQ0EsT0FBTyxXQUFXO0NBQ3BCOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLFNBQVM7RUFDUCxNQUFNLENBQUMsR0FBRyxHQUFHLEdBQUcsS0FBSyxLQUFLO0VBQzFCLE9BQU87R0FBRTtHQUFHO0dBQUc7R0FBRztFQUFFO0NBQ3RCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsUUFBUTtFQUNOLE1BQU0sQ0FBQyxHQUFHLEdBQUcsS0FBSyxLQUFLO0VBQ3ZCLE9BQU87R0FBRTtHQUFHO0dBQUc7RUFBRTtDQUNuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLGVBQWU7RUFDYixNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUssS0FBSyxnQkFBZ0I7RUFDdkMsT0FBTyxRQUFRLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEtBQUssTUFBTTtDQUMzQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlCQSxnQkFBZ0IsS0FBSztFQUNuQixNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUssS0FBSztFQUN2QixJQUFJLENBQUMsS0FBSyxXQUNSLEtBQUssWUFBWSxDQUFDO0VBRXBCLFFBQVEsTUFBTSxLQUFLO0VBQ25CLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSSxHQUFHO0VBQzNCLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSSxHQUFHO0VBQzNCLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSSxHQUFHO0VBQzNCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBd0JBLFFBQVEsS0FBSztFQUNYLElBQUksQ0FBQyxLQUFLLFlBQ1IsS0FBSyxhQUFhLENBQUM7RUFFckIsUUFBUSxNQUFNLEtBQUs7RUFDbkIsTUFBTSxDQUFDLEdBQUcsR0FBRyxHQUFHLEtBQUssS0FBSztFQUMxQixJQUFJLEtBQUs7RUFDVCxJQUFJLEtBQUs7RUFDVCxJQUFJLEtBQUs7RUFDVCxJQUFJLEtBQUs7RUFDVCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCQSxXQUFXLEtBQUs7RUFDZCxJQUFJLENBQUMsS0FBSyxXQUNSLEtBQUssWUFBWSxDQUFDO0VBRXBCLFFBQVEsTUFBTSxLQUFLO0VBQ25CLE1BQU0sQ0FBQyxHQUFHLEdBQUcsS0FBSyxLQUFLO0VBQ3ZCLElBQUksS0FBSztFQUNULElBQUksS0FBSztFQUNULElBQUksS0FBSztFQUNULE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsV0FBVztFQUNULE9BQU8sS0FBSztDQUNkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLGNBQWM7RUFDWixNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUssS0FBSyxnQkFBZ0I7RUFDdkMsUUFBUSxLQUFLLE9BQU8sS0FBSyxLQUFLO0NBQ2hDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBK0JBLHVCQUF1QjtFQUNyQixNQUFNLFFBQVEsS0FBSztFQUNuQixRQUFRLFNBQVMsT0FBTyxRQUFRLFdBQVcsUUFBUSxRQUFRO0NBQzdEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBK0JBLFNBQVMsT0FBTztFQUNkLE1BQU0sQ0FBQyxHQUFHLEdBQUcsR0FBRyxLQUFLLE9BQU8sTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDO0VBQ2xELEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssWUFBWTtFQUNqQixLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQThCQSxZQUFZLE9BQU8sYUFBYSxNQUFNO0VBQ3BDLElBQUksWUFBWTtHQUNkLEtBQUssWUFBWSxNQUFNO0dBQ3ZCLEtBQUssWUFBWSxNQUFNO0dBQ3ZCLEtBQUssWUFBWSxNQUFNO0VBQ3pCO0VBQ0EsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssU0FBUztFQUNkLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkJBLGdCQUFnQixPQUFPLGFBQWEsTUFBTTtFQUN4QyxJQUFJLFVBQVUsR0FDWixRQUFRLE9BQU8sTUFBTSxLQUFLO0VBRTVCLElBQUksVUFBVSxHQUNaLE9BQU8sYUFBYSxJQUFJLEtBQUs7RUFFL0IsSUFBSSxJQUFJLEtBQUssUUFBUSxLQUFLO0VBQzFCLElBQUksSUFBSSxLQUFLLFFBQVEsSUFBSTtFQUN6QixJQUFJLElBQUksS0FBSyxPQUFPO0VBQ3BCLElBQUksWUFBWTtHQUNkLElBQUksSUFBSSxRQUFRLEtBQU07R0FDdEIsSUFBSSxJQUFJLFFBQVEsS0FBTTtHQUN0QixJQUFJLElBQUksUUFBUSxLQUFNO0VBQ3hCO0VBQ0EsUUFBUSxRQUFRLE9BQU8sT0FBTyxLQUFLLE9BQU8sS0FBSyxLQUFLO0NBQ3REOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3QkEsUUFBUTtFQUNOLE1BQU0sWUFBWSxLQUFLLEtBQUssU0FBUyxFQUFFO0VBQ3ZDLE9BQU8sSUFBSSxTQUFTLFVBQVUsR0FBRyxJQUFJLFVBQVUsTUFBTSxJQUFJO0NBQzNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0JBLFNBQVM7RUFFUCxNQUFNLGNBRGEsS0FBSyxNQUFNLEtBQUssWUFBWSxLQUFLLEdBQ3ZCLENBQUMsQ0FBQyxTQUFTLEVBQUU7RUFDMUMsT0FBTyxLQUFLLE1BQU0sSUFBSSxLQUFLLFVBQVUsR0FBRyxJQUFJLFlBQVksTUFBTSxJQUFJO0NBQ3BFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTBCQSxTQUFTLE9BQU87RUFDZCxLQUFLLFlBQVksS0FBSyxLQUFLLE9BQU8sS0FBSztFQUN2QyxLQUFLLFNBQVM7RUFDZCxPQUFPO0NBQ1Q7Ozs7O0NBS0EsV0FBVyxPQUFPO0VBQ2hCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixLQUFLLE9BQU8sVUFBVSxZQUFZLGlCQUFpQixXQUFXLFNBQVMsS0FBSyxTQUFTLFVBQVU7R0FDN0YsTUFBTSxNQUFNO0dBQ1osS0FBSyxPQUFPLEtBQUssT0FBTztHQUN4QixLQUFLLE9BQU8sSUFBSSxPQUFPO0dBQ3ZCLEtBQUssTUFBTSxPQUFPO0dBQ2xCLElBQUk7RUFDTixPQUFPLEtBQUssTUFBTSxRQUFRLEtBQUssS0FBSyxpQkFBaUIsaUJBQWlCLE1BQU0sVUFBVSxLQUFLLE1BQU0sVUFBVSxHQUFHO0dBQzVHLFFBQVEsS0FBSyxPQUFPLEtBQUs7R0FDekIsQ0FBQyxHQUFHLEdBQUcsR0FBRyxJQUFJLEtBQUs7RUFDckIsT0FBTyxLQUFLLGlCQUFpQixjQUFjLGlCQUFpQixzQkFBc0IsTUFBTSxVQUFVLEtBQUssTUFBTSxVQUFVLEdBQUc7R0FDeEgsUUFBUSxLQUFLLE9BQU8sT0FBTyxHQUFHLEdBQUc7R0FDakMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxJQUFJLE9BQU87R0FDckIsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0dBQ0wsS0FBSztFQUNQLE9BQU8sSUFBSSxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsVUFBVTtHQUNqRSxJQUFJLE9BQU8sVUFBVSxVQUFVO0lBQzdCLE1BQU0sUUFBUSxPQUFPLFlBQVksS0FBSyxLQUFLO0lBQzNDLElBQUksT0FDRixRQUFRLElBQUksTUFBTTtHQUV0QjtHQUNBLE1BQU0sUUFBUUMsRUFBTyxLQUFLO0dBQzFCLElBQUksTUFBTSxRQUFRLEdBQUc7SUFDbkIsQ0FBQyxDQUFFLEdBQUcsR0FBRyxHQUFHLEtBQU0sTUFBTTtJQUN4QixLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7R0FDUDtFQUNGO0VBQ0EsSUFBSSxNQUFNLEtBQUssR0FBRztHQUNoQixLQUFLLFlBQVksS0FBSztHQUN0QixLQUFLLFlBQVksS0FBSztHQUN0QixLQUFLLFlBQVksS0FBSztHQUN0QixLQUFLLFlBQVksS0FBSztHQUN0QixLQUFLLFlBQVk7RUFDbkIsT0FDRSxNQUFNLElBQUksTUFBTSwyQkFBMkIsT0FBTztDQUV0RDs7Q0FFQSxjQUFjO0VBQ1osS0FBSyxPQUFPLEtBQUssV0FBVztFQUM1QixNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUssS0FBSztFQUN2QixLQUFLLFFBQVEsSUFBSSxPQUFPLE9BQU8sSUFBSSxPQUFPLE1BQU0sSUFBSSxNQUFNO0NBQzVEOzs7Ozs7O0NBT0EsT0FBTyxPQUFPLE1BQU0sR0FBRyxNQUFNLEdBQUc7RUFDOUIsSUFBSSxPQUFPLFVBQVUsVUFDbkIsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sR0FBRyxHQUFHLEdBQUc7RUFFM0MsTUFBTSxTQUFTLEdBQUcsTUFBTTtHQUN0QixNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHO0VBQzNDLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F1REEsT0FBTyxZQUFZLE9BQU87RUFDeEIsT0FBTyxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsWUFBWSxpQkFBaUIsVUFBVSxpQkFBaUIsVUFBVSxNQUFNLFFBQVEsS0FBSyxLQUFLLGlCQUFpQixjQUFjLGlCQUFpQixxQkFBcUIsaUJBQWlCLGdCQUFnQixNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLEtBQUs7Q0FDaHNCO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQ0EsT0FBTyxTQUFTLElBQUksT0FBTzs7Ozs7O0FBTTNCLE9BQU8sUUFBUSxJQUFJLE9BQU87O0FBRzFCLE9BQU8sY0FBYztBQUNyQixJQUFJLFFBQVE7OztBQ2x6QlosSUFBSSxZQUFZO0FBQ2hCLElBQU0sY0FBYztBQUNwQixTQUFTLEtBQUssR0FBRyxNQUFNO0NBQ3JCLElBQUksY0FBYyxhQUFhO0NBQy9CO0NBQ0EsSUFBSSxjQUFjLGFBQ2hCLFFBQVEsS0FBSyxnR0FBZ0c7TUFFN0csUUFBUSxLQUFLLG9CQUFvQixHQUFHLElBQUk7QUFFNUM7OztBQ1ZBLElBQU0seUJBQXlCOzs7OztDQUs3QixzQ0FBc0MsSUFBSSxJQUFJOzs7OztDQUs5QyxTQUFTLE1BQU07RUFDYixLQUFLLHFCQUFxQixJQUFJLElBQUk7Q0FDcEM7Ozs7O0NBS0EsV0FBVyxNQUFNO0VBQ2YsS0FBSyxxQkFBcUIsT0FBTyxJQUFJO0NBQ3ZDOztDQUVBLFVBQVU7RUFDUixLQUFLLHFCQUFxQixTQUFTLFNBQVMsS0FBSyxNQUFNLENBQUM7Q0FDMUQ7Ozs7O0NBS0EsSUFBSSxrQkFBa0I7RUFDcEIsT0FBTyxLQUFLLHFCQUFxQjtDQUNuQzs7Ozs7O0NBTUEsYUFBYSxNQUFNO0VBQ2pCLE9BQU8sS0FBSyxxQkFBcUIsSUFBSSxJQUFJO0NBQzNDOzs7OztDQUtBLFFBQVE7RUFDTixLQUFLLHFCQUFxQixNQUFNO0NBQ2xDO0FBQ0Y7OztBQzlDQSxJQUFNLE9BQU4sTUFBVzs7Ozs7O0NBTVQsWUFBWSxXQUFXLGFBQWE7RUFDbEMsS0FBSyxRQUFRLENBQUM7RUFDZCxLQUFLLFNBQVM7RUFDZCxLQUFLLFNBQVM7RUFDZCxLQUFLLGFBQWE7RUFDbEIsSUFBSSxhQUNGLEtBQUssWUFBWSxXQUFXO0NBRWhDOzs7OztDQUtBLFlBQVksT0FBTztFQUNqQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUN6QixLQUFLLE1BQU0sS0FBSyxZQUFZLElBQUksS0FBSyxXQUFXO0VBRWxELEtBQUssVUFBVTtDQUNqQjs7Ozs7OztDQU9BLElBQUksTUFBTTtFQUNSLElBQUk7RUFDSixJQUFJLEtBQUssU0FBUyxHQUNoQixPQUFPLEtBQUssTUFBTSxFQUFFLEtBQUs7T0FDcEI7R0FDTCxPQUFPLElBQUksS0FBSyxXQUFXO0dBQzNCLEtBQUs7RUFDUDtFQUNBLEtBQUssT0FBTyxJQUFJO0VBQ2hCLE9BQU87Q0FDVDs7Ozs7Q0FLQSxPQUFPLE1BQU07RUFDWCxLQUFLLFFBQVE7RUFDYixLQUFLLE1BQU0sS0FBSyxZQUFZO0NBQzlCOzs7OztDQUtBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSztDQUNkOzs7OztDQUtBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSztDQUNkOzs7OztDQUtBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSyxTQUFTLEtBQUs7Q0FDNUI7O0NBRUEsUUFBUTtFQUNOLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLE1BQU0sRUFBRSxDQUFDLFNBQ3pDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FDL0IsS0FBSyxNQUFNLEVBQUUsQ0FBQyxRQUFRO0VBRzFCLEtBQUssTUFBTSxTQUFTO0VBQ3BCLEtBQUssU0FBUztFQUNkLEtBQUssU0FBUztDQUNoQjtBQUNGOzs7QUMvRUEsSUFBTSxpQkFBTixNQUFxQjtDQUNuQixjQUFjOzs7OztFQUtaLEtBQUssZ0NBQWdDLElBQUksSUFBSTtDQUMvQzs7Ozs7OztDQU9BLFlBQVksT0FBTyxPQUFPO0VBRXhCLEtBRHVCLFFBQVEsS0FDdkIsQ0FBQyxDQUFDLFlBQVksS0FBSztDQUM3Qjs7Ozs7Ozs7Q0FRQSxJQUFJLE9BQU8sTUFBTTtFQUVmLE9BRGEsS0FBSyxRQUFRLEtBQ2hCLENBQUMsQ0FBQyxJQUFJLElBQUk7Q0FDdEI7Ozs7O0NBS0EsT0FBTyxNQUFNO0VBRVgsS0FEa0IsUUFBUSxLQUFLLFdBQzVCLENBQUMsQ0FBQyxPQUFPLElBQUk7Q0FDbEI7Ozs7Ozs7Q0FPQSxRQUFRLFdBQVc7RUFDakIsSUFBSSxDQUFDLEtBQUssY0FBYyxJQUFJLFNBQVMsR0FDbkMsS0FBSyxjQUFjLElBQUksV0FBVyxJQUFJLEtBQUssU0FBUyxDQUFDO0VBRXZELE9BQU8sS0FBSyxjQUFjLElBQUksU0FBUztDQUN6Qzs7Q0FFQSxRQUFRO0VBQ04sTUFBTSxRQUFRLENBQUM7RUFDZixLQUFLLGNBQWMsU0FBUyxTQUFTO0dBQ25DLE1BQU0sT0FBTyxNQUFNLEtBQUssV0FBVyxRQUFRLEtBQUssV0FBVyxPQUFPLEtBQUssV0FBVyxLQUFLLEtBQUssV0FBVztHQUN2RyxNQUFNLFFBQVE7SUFDWixNQUFNLEtBQUs7SUFDWCxNQUFNLEtBQUs7SUFDWCxNQUFNLEtBQUs7R0FDYjtFQUNGLENBQUM7RUFDRCxPQUFPO0NBQ1Q7O0NBRUEsUUFBUTtFQUNOLEtBQUssY0FBYyxTQUFTLFNBQVMsS0FBSyxNQUFNLENBQUM7RUFDakQsS0FBSyxjQUFjLE1BQU07Q0FDM0I7QUFDRjtBQUNBLElBQU0sVUFBVSxJQUFJLGVBQWU7QUFDbkMsdUJBQXVCLFNBQVMsT0FBTzs7O0FDeEV2QyxTQUFTLGtCQUFrQixRQUFRLFFBQVE7Q0FDekMsSUFBSSxXQUFXLFlBQVksQ0FBQyxRQUFRLE9BQU87Q0FDM0MsSUFBSSxXQUFXLFlBQVksQ0FBQyxRQUFRLE9BQU87Q0FDM0MsTUFBTSxLQUFLLFVBQVUsS0FBSztDQUMxQixNQUFNLEtBQUssVUFBVSxJQUFJO0NBQ3pCLE1BQU0sS0FBSyxTQUFTO0NBQ3BCLE1BQU0sS0FBSyxVQUFVLEtBQUs7Q0FDMUIsTUFBTSxLQUFLLFVBQVUsSUFBSTtDQUN6QixNQUFNLEtBQUssU0FBUztDQUNwQixNQUFNLElBQUksS0FBSyxLQUFLLE1BQU07Q0FDMUIsTUFBTSxJQUFJLEtBQUssS0FBSyxNQUFNO0NBQzFCLE1BQU0sSUFBSSxLQUFLLEtBQUssTUFBTTtDQUMxQixRQUFRLEtBQUssT0FBTyxLQUFLLEtBQUs7QUFDaEM7OztBQ1hBLElBQU0saUJBQU4sTUFBcUI7Q0FDbkIsY0FBYzs7RUFFWixLQUFLLE1BQU0sSUFBSSxnQkFBZ0I7O0VBRS9CLEtBQUssZUFBZSxDQUFDOztFQUVyQixLQUFLLGtCQUFrQjtFQUN2QixLQUFLLGNBQWMsQ0FBQzs7RUFFcEIsS0FBSyxTQUFTO0NBQ2hCOztDQUVBLFFBQVE7RUFDTixLQUFLLGtCQUFrQjtDQUN6Qjs7Ozs7O0NBTUEsVUFBVTtFQUNSLElBQUksS0FBSyxhQUNQLEtBQUssTUFBTSxLQUFLLEtBQUssYUFDbkIsS0FBSyxZQUFZLEVBQUUsQ0FBQyx3QkFBd0IsSUFBSTtFQUdwRCxLQUFLLGFBQWEsU0FBUztFQUMzQixLQUFLLFlBQVksU0FBUztFQUMxQixLQUFLLGNBQWM7RUFDbkIsS0FBSyxTQUFTO0NBQ2hCOzs7OztDQUtBLElBQUksYUFBYTtFQUNmLEtBQUssYUFBYSxLQUFLLHFCQUFxQjtDQUM5Qzs7Ozs7Q0FLQSxNQUFNO0VBQ0osS0FBSyxhQUFhLFNBQVMsS0FBSztFQUNoQyxRQUFRLE1BQU0sS0FBSyxjQUFjLENBQUMsUUFBUSxRQUFRLENBQUM7Q0FDckQ7QUFDRjs7O0FDakRBLElBQU0scUJBQU4sTUFBeUI7Q0FDdkIsY0FBYzs7RUFFWixLQUFLLCtCQUErQixJQUFJLElBQUk7O0VBRTVDLEtBQUssVUFBVSxDQUFDOztFQUVoQixLQUFLLFdBQVcsQ0FBQztDQUNuQjs7Q0FFQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssYUFBYTtDQUMzQjs7Ozs7Ozs7Q0FRQSxJQUFJLGFBQWEsWUFBWSxhQUFhO0VBQ3hDLE1BQU0sVUFBVSxLQUFLLGFBQWEsSUFBSSxXQUFXO0VBQ2pELElBQUksV0FBVyxRQUFRLGVBQWUsY0FBYyxRQUFRLGdCQUFnQixhQUFhLE9BQU87RUFDaEcsS0FBSyxhQUFhLElBQUksYUFBYTtHQUFFO0dBQVk7RUFBWSxDQUFDO0VBQzlELEtBQUssUUFBUTtFQUNiLE9BQU87Q0FDVDs7Ozs7O0NBTUEsT0FBTyxhQUFhO0VBQ2xCLElBQUksQ0FBQyxLQUFLLGFBQWEsT0FBTyxXQUFXLEdBQUcsT0FBTztFQUNuRCxLQUFLLFFBQVE7RUFDYixPQUFPO0NBQ1Q7Ozs7OztDQU1BLGdCQUFnQixZQUFZO0VBQzFCLE9BQU8sS0FBSyxnQkFBZ0IsWUFBWSxLQUFLLE9BQU87Q0FDdEQ7Ozs7OztDQU1BLGlCQUFpQixhQUFhO0VBQzVCLE9BQU8sS0FBSyxnQkFBZ0IsYUFBYSxLQUFLLFFBQVE7Q0FDeEQ7Ozs7O0NBS0EsU0FBUyxPQUFPO0VBQ2QsT0FBTyxLQUFLLFFBQVEsU0FBUyxLQUFLO0NBQ3BDOzs7OztDQUtBLFVBQVUsUUFBUTtFQUNoQixPQUFPLEtBQUssU0FBUyxTQUFTLE1BQU07Q0FDdEM7Ozs7Ozs7Q0FPQSxnQkFBZ0IsV0FBVyxhQUFhO0VBQ3RDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxZQUFZLFFBQVEsS0FBSztHQUMzQyxNQUFNLGFBQWEsWUFBWTtHQUMvQixJQUFJLGNBQWMsV0FBVyxPQUFPO0VBQ3RDO0NBRUY7O0NBRUEsVUFBVTtFQUNSLEtBQUssVUFBVSxDQUFDLEdBQUcsS0FBSyxhQUFhLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxlQUFlLFdBQVcsVUFBVSxDQUFDLENBQUMsUUFBUSxPQUFPLEdBQUcsV0FBVyxPQUFPLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQztFQUN4SyxLQUFLLFdBQVcsQ0FBQyxHQUFHLEtBQUssYUFBYSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssZUFBZSxXQUFXLFdBQVcsQ0FBQyxDQUFDLFFBQVEsUUFBUSxHQUFHLFlBQVksUUFBUSxRQUFRLE1BQU0sTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUM7Q0FDaEw7QUFDRjs7O0FDckZBLElBQU0saUJBQWlCO0NBQ3JCLGVBQWUsT0FBTyxXQUFXO0VBQy9CLE1BQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtFQUM5QyxPQUFPLFFBQVE7RUFDZixPQUFPLFNBQVM7RUFDaEIsT0FBTztDQUNUO0NBQ0EsbUJBQW1CLElBQUksTUFBTTtDQUM3QixtQ0FBbUM7Q0FDbkMsZ0NBQWdDO0NBQ2hDLG9CQUFvQjtDQUNwQixrQkFBa0IsU0FBUyxXQUFXLE9BQU8sU0FBUztDQUN0RCxzQkFBc0IsU0FBUztDQUMvQixRQUFRLEtBQUssWUFBWSxNQUFNLEtBQUssT0FBTztDQUMzQyxXQUFXLFFBQVE7RUFFakIsT0FBTyxJQURZLFVBQ1AsQ0FBQyxDQUFDLGdCQUFnQixLQUFLLFVBQVU7Q0FDL0M7QUFDRjs7O0FDaEJBLElBQUksaUJBQWlCO0FBQ3JCLElBQU0sYUFBYTs7Ozs7Q0FLakIsTUFBTTtFQUNKLE9BQU87Q0FDVDs7Ozs7Q0FLQSxJQUFJLFNBQVM7RUFDWCxpQkFBaUI7Q0FDbkI7QUFDRjs7O0FDbEJBLElBQU0sV0FBMkIsdUJBQU8sT0FBTyxJQUFJO0FBQ25ELElBQU0sU0FBeUIsdUJBQU8sT0FBTyxJQUFJO0FBQ2pELFNBQVMsbUJBQW1CLE9BQU8sU0FBUztDQUMxQyxJQUFJLEtBQUssT0FBTztDQUNoQixJQUFJLE9BQU8sS0FBSyxHQUFHO0VBQ2pCLElBQUksU0FBUyxhQUFhLEtBQUssR0FDN0IsU0FBUyxXQUFXO0VBRXRCLE9BQU8sU0FBUyxLQUFLLFNBQVMsUUFBUTtDQUN4QztDQUNBLE9BQU87QUFDVDs7O0FDVEEsSUFBSTtBQUNKLFNBQVMsaUJBQWlCO0NBQ3hCLElBQUksQ0FBQyxXQUFXLFNBQVMsY0FBYyxHQUVyQyxVQURlLFdBQVcsSUFBSSxDQUFDLENBQUMsYUFDakIsQ0FBQyxDQUFDLFdBQVcsU0FBUyxDQUFDLENBQUM7Q0FFekMsT0FBTztBQUNUOzs7QUNQQSxJQUFJO0FBQ0osU0FBUywwQkFBMEI7Q0FDakMsSUFBSSxDQUFDLHNCQUFzQjtFQUN6Qix1QkFBdUI7RUFDdkIsTUFBTSxLQUFLLGVBQWU7RUFDMUIsSUFBSSxJQUNFO09BQUEsR0FBRywwQkFFTCx1QkFEdUIsR0FBRyx5QkFBeUIsR0FBRyxpQkFBaUIsR0FBRyxVQUN0QyxDQUFDLENBQUMsWUFBWSxVQUFVO0VBQUE7Q0FHbEU7Q0FDQSxPQUFPO0FBQ1Q7OztBQ2ZBLFNBQVMsa0JBQWtCLEtBQUssU0FBUyxZQUFZO0NBQ25ELElBQUksU0FBUyxPQUFPO0NBQ3BCLElBQUksWUFBWTtFQUNkLE1BQU0sSUFBSSxRQUFRLHdCQUF3QixFQUFFO0VBQzVDLE9BQU87Ozs7Ozs7VUFPRCxJQUFJOztDQUVaO0NBQ0EsT0FBTzs7Ozs7O1VBTUMsSUFBSTs7QUFFZDs7O0FDdEJBLElBQU0sNEJBQTRCO0FBQ2xDLElBQU0seUJBQXlCO0FBQy9CLElBQU0sMkJBQTJCO0NBQy9CLFdBQVc7Q0FDWCxhQUFhO0FBQ2Y7QUFDQSxTQUFTLGdCQUFnQixLQUFLLFNBQVMsWUFBWTtDQUNqRCxNQUFNLHdCQUF3QixhQUFhLFFBQVEsZ0NBQWdDLFFBQVE7Q0FDM0YsSUFBSSxJQUFJLFVBQVUsR0FBRyxDQUFDLE1BQU0sYUFBYTtFQUN2QyxJQUFJLFlBQVksYUFBYSxRQUFRLDZCQUE2QixRQUFRO0VBQzFFLElBQUksY0FBYyxXQUFXLDBCQUEwQixTQUNyRCxZQUFZO0VBRWQsTUFBTSxhQUFhLFVBQVU7RUFDL0I7Q0FDQSxPQUFPLElBQUksMEJBQTBCLFdBQVcsSUFBSSxVQUFVLEdBQUcsRUFBRSxNQUFNLG1CQUN2RSxNQUFNLElBQUksUUFBUSxtQkFBbUIsbUJBQW1CO0NBRTFELE1BQU0sbUJBQW1CLFFBQVEsa0NBQWtDLFVBQVUsVUFBVTtDQUN2RixPQUFPLHVCQUF1QixLQUFLLGdCQUFnQjtBQUNyRDtBQUNBLFNBQVMsdUJBQXVCLEtBQUssZUFBZTtDQUNsRCxNQUFNLHVCQUF1QixJQUFJLElBQUk7Q0FDckMsSUFBSSxTQUFTO0NBQ2IsS0FBSyxNQUFNLEdBQUcsU0FBUyxJQUFJLFNBQVMsc0JBQXNCLEdBQUcsS0FBSyxJQUFJLElBQUk7Q0FDMUUsS0FBSyxNQUFNLEdBQUcsU0FBUyxJQUFJLFNBQVMseUJBQXlCLEdBQUc7RUFDOUQsSUFBSSxLQUFLLElBQUksSUFBSSxHQUFHO0VBQ3BCLEtBQUssSUFBSSxJQUFJO0VBQ2IsVUFBVSxhQUFhLHlCQUF5QixTQUFTLGNBQWMsR0FBRyxLQUFLOztDQUVqRjtDQUNBLE9BQU8sU0FBUztBQUNsQjs7O0FDaENBLFNBQVMsY0FBYyxLQUFLLFNBQVM7Q0FDbkMsSUFBSSxDQUFDLFNBQVMsT0FBTztDQUNyQixPQUFPO0VBQ1A7QUFDRjs7O0FDSkEsSUFBTSxvQkFBb0IsQ0FBQztBQUMzQixJQUFNLGtCQUFrQixDQUFDO0FBQ3pCLFNBQVMsZUFBZSxLQUFLLEVBQUUsT0FBTyxrQkFBa0IsYUFBYSxNQUFNO0NBQ3pFLE9BQU8sS0FBSyxRQUFRLFFBQVEsR0FBRztDQUMvQixRQUFRLGFBQWEsY0FBYztDQUNuQyxNQUFNLFlBQVksYUFBYSxvQkFBb0I7Q0FDbkQsSUFBSSxVQUFVLE9BQU87RUFDbkIsVUFBVSxLQUFLO0VBQ2YsUUFBUSxJQUFJLFVBQVU7Q0FDeEIsT0FDRSxVQUFVLFFBQVE7Q0FFcEIsSUFBSSxJQUFJLFFBQVEscUJBQXFCLE1BQU0sSUFBSSxPQUFPO0NBRXRELE9BQU8sR0FBRyx1QkFEZ0MsT0FDckI7RUFDckI7QUFDRjs7O0FDaEJBLFNBQVMsYUFBYSxLQUFLLFNBQVM7Q0FDbEMsSUFBSSxDQUFDLFNBQVMsT0FBTztDQUNyQixPQUFPLElBQUksUUFBUSxtQkFBbUIsRUFBRTtBQUMxQzs7O0FDS0EsSUFBTSxZQUFZO0NBRWhCO0NBRUE7Q0FFQTtDQUVBO0NBRUE7QUFDRjtBQUNBLElBQU1DLGlCQUErQix1QkFBTyxPQUFPLElBQUk7QUFDdkQsSUFBTSxhQUFhLE1BQU0sV0FBVzs7Ozs7Q0FLbEMsWUFBWSxTQUFTO0VBQ25CLFVBQVU7R0FBRSxHQUFHLFdBQVc7R0FBZ0IsR0FBRztFQUFRO0VBQ3JELE1BQU0sVUFBVSxRQUFRLFNBQVMsUUFBUSxpQkFBaUIsTUFBTTtFQUNoRSxNQUFNLHNCQUFzQjtHQUMxQixjQUFjO0dBQ2QsaUJBQWlCO0lBQ2YsNEJBQTRCLFFBQVE7SUFDcEMsMEJBQTBCLFFBQVE7SUFDbEMsNkJBQTZCO0lBQzdCLCtCQUErQix3QkFBd0I7R0FDekQ7R0FDQSxnQkFBZ0IsRUFDZCxNQUFNLFFBQVEsS0FDaEI7R0FDQSxtQkFBbUI7R0FDbkIsZUFBZTtFQUNqQjtFQUNBLElBQUksV0FBVyxRQUFRO0VBQ3ZCLElBQUksU0FBUyxRQUFRO0VBQ3JCLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQyxTQUFTLGVBQWU7R0FDN0MsTUFBTSxpQkFBaUIsb0JBQW9CO0dBQzNDLFdBQVcsVUFBVSxXQUFXLENBQUMsVUFBVSxnQkFBZ0IsSUFBSTtHQUMvRCxTQUFTLFVBQVUsV0FBVyxDQUFDLFFBQVEsZ0JBQWdCLEtBQUs7RUFDOUQsQ0FBQztFQUNELEtBQUssV0FBVztFQUNoQixLQUFLLFNBQVM7RUFDZCxLQUFLLDRCQUE0QixRQUFRO0VBQ3pDLEtBQUssT0FBTyxtQkFBbUIsR0FBRyxLQUFLLE9BQU8sR0FBRyxLQUFLLFlBQVksWUFBWTtDQUNoRjs7Q0FFQSxVQUFVO0VBQ1IsS0FBSyxXQUFXO0VBQ2hCLEtBQUssU0FBUztFQUNkLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssZUFBZTtFQUNwQixLQUFLLG9CQUFvQjtFQUN6QixLQUFLLDRCQUE0QjtFQUNqQyxlQUFhLEtBQUssYUFBYTtDQUNqQzs7Ozs7Ozs7Q0FRQSxPQUFPLEtBQUssU0FBUztFQUNuQixNQUFNLE1BQU0sR0FBRyxRQUFRLE9BQU8sR0FBRyxRQUFRO0VBQ3pDLElBQUksQ0FBQ0EsZUFBYSxNQUFNO0dBQ3RCLGVBQWEsT0FBTyxJQUFJLFdBQVcsT0FBTztHQUMxQyxlQUFhLElBQUksQ0FBQyxZQUFZO0VBQ2hDO0VBQ0EsT0FBT0EsZUFBYTtDQUN0QjtBQUNGOztBQUVBLFdBQVcsaUJBQWlCO0NBQzFCLDBCQUEwQjtDQUMxQiw0QkFBNEI7QUFDOUI7QUFDQSxJQUFJLFlBQVk7OztBQ3RGaEIsSUFBTSxzQkFBc0I7Q0FDMUIsU0FBUztFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUcsWUFBWTtDQUFNO0NBQ2pELFNBQVM7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFHLFlBQVk7Q0FBTTtDQUNqRCxTQUFTO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBRyxZQUFZO0NBQU07Q0FDakQsU0FBUztFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUcsWUFBWTtDQUFNO0NBQ2pELFVBQVU7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFHLFlBQVk7Q0FBSztDQUNqRCxVQUFVO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBRyxZQUFZO0NBQUs7Q0FDakQsVUFBVTtFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUcsWUFBWTtDQUFLO0NBQ2pELFVBQVU7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFHLFlBQVk7Q0FBSztDQUNqRCxVQUFVO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBRyxZQUFZO0NBQU07Q0FDbEQsVUFBVTtFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUcsWUFBWTtDQUFNO0NBQ2xELFVBQVU7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFHLFlBQVk7Q0FBTTtDQUNsRCxVQUFVO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBRyxZQUFZO0NBQU07Q0FDbEQsV0FBVztFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUcsWUFBWTtDQUFLO0NBQ2xELFdBQVc7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFHLFlBQVk7Q0FBSztDQUNsRCxXQUFXO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBRyxZQUFZO0NBQUs7Q0FDbEQsV0FBVztFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUcsWUFBWTtDQUFLO0NBQ2xELFdBQVc7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFHLFlBQVk7Q0FBTTtDQUNuRCxXQUFXO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBRyxZQUFZO0NBQU07Q0FDbkQsU0FBUztFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUcsWUFBWTtDQUFNO0NBQ2pELFdBQVc7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFHLFlBQVk7Q0FBTTtDQUNuRCxXQUFXO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBSSxZQUFZO0NBQU07Q0FDcEQsV0FBVztFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUksWUFBWTtDQUFNO0NBQ3BELFFBQVE7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFHLFlBQVk7Q0FBTTtDQUNoRCxVQUFVO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBRyxZQUFZO0NBQU07Q0FDbEQsVUFBVTtFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUksWUFBWTtDQUFNO0NBQ25ELFVBQVU7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFJLFlBQVk7Q0FBTTtDQUNuRCxRQUFRO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBRyxZQUFZO0NBQU07Q0FDaEQsVUFBVTtFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUcsWUFBWTtDQUFNO0NBQ2xELFVBQVU7RUFBRSxNQUFNO0VBQUcsUUFBUTtFQUFJLFlBQVk7Q0FBTTtDQUNuRCxVQUFVO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBSSxZQUFZO0NBQU07QUFDckQ7QUFDQSxTQUFTLDJCQUEyQixRQUFRO0NBQzFDLE9BQU8sb0JBQW9CLFdBQVcsb0JBQW9CO0FBQzVEOzs7QUNoQ0EsSUFBTSx1QkFBdUI7Q0FDM0IsS0FBSztDQUNMLGFBQWE7Q0FDYixhQUFhO0NBQ2IsYUFBYTtDQUNiLE9BQU87Q0FDUCxPQUFPO0NBQ1AsT0FBTztDQUNQLEtBQUs7Q0FDTCxhQUFhO0NBQ2IsYUFBYTtDQUNiLGFBQWE7Q0FDYixPQUFPO0NBQ1AsT0FBTztDQUNQLE9BQU87Q0FDUCxLQUFLO0NBQ0wsYUFBYTtDQUNiLGFBQWE7Q0FDYixhQUFhO0NBQ2IsT0FBTztDQUNQLE9BQU87Q0FDUCxPQUFPO0NBQ1AsTUFBTTtDQUNOLGNBQWM7Q0FDZCxjQUFjO0NBQ2QsY0FBYztBQUNoQjtBQUNBLElBQU0saUJBQWlCO0FBQ3ZCLFNBQVMsZUFBZSxLQUFLLFNBQVM7Q0FDcEMsSUFBSTtDQUNKLFFBQVEsUUFBUSxlQUFlLEtBQUssR0FBRyxPQUFPLE1BQU07RUFDbEQsTUFBTSxTQUFTLHFCQUFxQixNQUFNLE9BQU87RUFDakQsUUFBUSxNQUFNLE1BQU07R0FDbEIsVUFBVSxTQUFTLE1BQU0sSUFBSSxFQUFFO0dBQy9CO0dBQ0EsUUFBUSwyQkFBMkIsTUFBTSxDQUFDLENBQUM7R0FDM0MsUUFBUTtHQUNSLFVBQVU7R0FDVixPQUFPO0VBQ1Q7Q0FDRjtDQUNBLGVBQWUsWUFBWTtBQUM3QjtBQUNBLFNBQVMsY0FBYyxRQUFRO0NBQzdCLE9BQU8sT0FBTyxRQUFRLGFBQWEsRUFBRSxDQUFDLENBQUMsUUFBUSxxQkFBcUIsRUFBRTtBQUN4RTtBQUNBLFNBQVMsZ0NBQWdDLEVBQUUsUUFBUSxjQUFjO0NBQy9ELE1BQU0sVUFBVSxDQUFDO0NBQ2pCLE1BQU0sY0FBYyxjQUFjLE1BQU07Q0FDeEMsTUFBTSxnQkFBZ0IsWUFBWSxRQUFRLE1BQU0sV0FBVyxFQUFFO0NBQzdELElBQUksa0JBQWtCLElBQ3BCLE9BQU87Q0FFVCxNQUFNLHFCQUFxQixZQUFZLFFBQVEsTUFBTSxhQUFhO0NBQ2xFLElBQUksdUJBQXVCLElBQ3pCLE9BQU87Q0FFVCxNQUFNLHdCQUF3QixZQUFZLFVBQVUsZUFBZSxrQkFBa0I7Q0FDckYsZUFBZSx1QkFBdUIsT0FBTztDQUM3QyxJQUFJLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxXQUFXLEdBQUc7RUFDckMsTUFBTSxjQUFjLHNCQUFzQixNQUFNLHNCQUFzQjtFQUN0RSxJQUFJLGFBQWE7R0FDZixNQUFNLGFBQWEsWUFBWTtHQUMvQixNQUFNLGNBQWMsSUFBSSxPQUFPLGFBQWEsV0FBVyxvQkFBb0IsR0FBRztHQUM5RSxNQUFNLGFBQWEsWUFBWSxNQUFNLFdBQVc7R0FDaEQsSUFBSSxZQUNGLGVBQWUsV0FBVyxJQUFJLE9BQU87RUFFekM7Q0FDRjtDQUNBLE9BQU87QUFDVDs7O0FDekVBLFNBQVMsdUJBQXVCLE1BQU07Q0FDcEMsTUFBTSxjQUFjO0NBQ3BCLE1BQU0sZUFBZTtDQUNyQixNQUFNLGlCQUFpQjtDQUN2QixNQUFNLGNBQWM7Q0FDcEIsTUFBTSxjQUFjO0NBQ3BCLE1BQU0sZ0JBQWdCO0NBQ3RCLE1BQU0sc0JBQXNCO0NBQzVCLE1BQU0sYUFBYTtDQUNuQixNQUFNLFNBQVMsS0FBSyxNQUFNLFdBQVcsQ0FBQyxFQUFFLEtBQUssU0FBUztFQUNwRCxNQUFNLFdBQVcsS0FBSyxNQUFNLFdBQVc7RUFDdkMsTUFBTSxlQUFlLFdBQVcsTUFBTTtFQUN0QyxJQUFJO0VBQ0osSUFBSSxpQkFBaUIsYUFDbkIsYUFBYTtPQUNSLElBQUksYUFBYSxXQUFXLFVBQVUsR0FDM0MsYUFBYTtFQUVmLE9BQU87R0FDTCxPQUFPLFNBQVMsS0FBSyxNQUFNLFlBQVksQ0FBQyxDQUFDLElBQUksRUFBRTtHQUMvQyxTQUFTLFNBQVMsS0FBSyxNQUFNLGNBQWMsQ0FBQyxDQUFDLElBQUksRUFBRTtHQUNuRCxNQUFNLFNBQVM7R0FDZjtHQUNBLE1BQU0sS0FBSyxNQUFNLFdBQVcsQ0FBQyxDQUFDO0VBQ2hDO0NBQ0YsQ0FBQztDQUNELElBQUksQ0FBQyxRQUNILE9BQU87RUFDTCxRQUFRLENBQUM7RUFDVCxTQUFTLENBQUM7Q0FDWjtDQW1CRixPQUFPO0VBQ0w7RUFDQSxTQW5CYyxLQUFLLE1BQU0sYUFBYSxDQUFDLEVBQUUsS0FBSyxXQUFXO0dBQ3pELE1BQU0sT0FBTyxPQUFPLE1BQU0sVUFBVSxDQUFDLENBQUM7R0FDdEMsTUFBTSxVQUFVLE9BQU8sTUFBTSxtQkFBbUIsQ0FBQyxDQUFDLFFBQVEsS0FBSyxXQUFXO0lBQ3hFLE1BQU0sQ0FBQyxPQUFPLFFBQVEsT0FBTyxNQUFNLEdBQUc7SUFDdEMsSUFBSSxNQUFNLEtBQUssS0FBSyxLQUFLLEtBQUs7SUFDOUIsT0FBTztHQUNULEdBQUcsQ0FBQyxDQUFDO0dBQ0wsSUFBSSxDQUFDLFNBQ0gsT0FBTztHQUVULE9BQU87SUFBRTtJQUFNO0dBQVE7RUFDekIsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLFdBQVcsT0FBTyxNQUM1QixVQUVDLE1BQU0sU0FBUyxRQUFRLE1BQU0sS0FBSyxTQUFTLElBQUksS0FBSyxFQUFFLENBRTFELENBQUMsS0FBSyxDQUFDO0NBSVA7QUFDRjs7O0FDckRBLElBQUksY0FBOEIsa0JBQUUsaUJBQWlCO0NBQ25ELGFBQWEsYUFBYSxZQUFZLEtBQUs7Q0FDM0MsYUFBYSxhQUFhLGNBQWMsS0FBSztDQUM3QyxhQUFhLGFBQWEsYUFBYSxLQUFLO0NBQzVDLE9BQU87QUFDVCxFQUFBLENBQUcsZUFBZSxDQUFDLENBQUM7OztBQ0hwQixTQUFTLHFCQUFxQixNQUFNO0NBQ2xDLElBQUksS0FBSyxTQUFTLE9BQU8sR0FDdkIsT0FBTztDQUVULElBQUksS0FBSyxTQUFTLE9BQU8sR0FDdkIsT0FBTztDQUVULE9BQU87QUFDVDtBQUNBLFNBQVMsd0JBQXdCLEVBQUUsVUFBVTtDQUMzQyxNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7RUFDdEMsTUFBTSxRQUFRLE9BQU87RUFDckIsSUFBSSxDQUFDLE9BQU8sTUFBTSxRQUNoQixPQUFPLE1BQU0sU0FBUyxDQUFDO0VBRXpCLElBQUksTUFBTSxlQUFlLFdBQ3ZCLE9BQU8sTUFBTSxNQUFNLENBQUMsS0FBSztHQUN2QixTQUFTLE1BQU07R0FDZixZQUFZLFlBQVksU0FBUyxZQUFZO0dBQzdDLFFBQVEsRUFDTixNQUFNLFVBQ1I7RUFDRixDQUFDO09BQ0ksSUFBSSxNQUFNLGVBQWUsV0FDOUIsT0FBTyxNQUFNLE1BQU0sQ0FBQyxLQUFLO0dBQ3ZCLFNBQVMsTUFBTTtHQUNmLFlBQVksWUFBWSxTQUFTLFlBQVk7R0FDN0MsUUFBUSxFQUNOLE1BQU0sb0JBQ1I7RUFDRixDQUFDO09BQ0ksSUFBSSxNQUFNLFNBQVMsV0FDeEIsT0FBTyxNQUFNLE1BQU0sQ0FBQyxLQUFLO0dBQ3ZCLFNBQVMsTUFBTTtHQUNmLFlBQVksWUFBWSxTQUFTLFlBQVk7R0FDN0MsU0FBUyxFQUNQLE1BQU0sWUFDUjtFQUNGLENBQUM7T0FDSSxJQUFJLE1BQU0sU0FBUyxzQkFDeEIsT0FBTyxNQUFNLE1BQU0sQ0FBQyxLQUFLO0dBQ3ZCLFNBQVMsTUFBTTtHQUNmLFlBQVksWUFBWSxTQUFTLFlBQVk7R0FDN0MsU0FBUyxFQUNQLE1BQU0sYUFDUjtFQUNGLENBQUM7T0FDSSxJQUFJLE1BQU0sU0FBUyxnQkFBZ0IsTUFBTSxLQUFLLFdBQVcsYUFBYSxHQUMzRSxPQUFPLE1BQU0sTUFBTSxDQUFDLEtBQUs7R0FDdkIsU0FBUyxNQUFNO0dBQ2YsWUFBWSxZQUFZLFNBQVMsWUFBWTtHQUM3QyxTQUFTO0lBQ1AsWUFBWSxxQkFBcUIsTUFBTSxJQUFJO0lBQzNDLGVBQWU7SUFDZixjQUFjO0dBQ2hCO0VBQ0YsQ0FBQztPQUNJLElBQUksTUFBTSxTQUFTLG9CQUN4QixPQUFPLE1BQU0sTUFBTSxDQUFDLEtBQUs7R0FDdkIsU0FBUyxNQUFNO0dBQ2YsWUFBWSxZQUFZLFNBQVMsWUFBWTtHQUM3QyxTQUFTO0lBQ1AsWUFBWTtJQUNaLGVBQWU7SUFDZixjQUFjO0dBQ2hCO0VBQ0YsQ0FBQztPQUNJLElBQUksTUFBTSxTQUFTLDBCQUN4QixPQUFPLE1BQU0sTUFBTSxDQUFDLEtBQUs7R0FDdkIsU0FBUyxNQUFNO0dBQ2YsWUFBWSxZQUFZLFNBQVMsWUFBWTtHQUM3QyxTQUFTO0lBQ1AsWUFBWTtJQUNaLGVBQWU7SUFDZixjQUFjO0dBQ2hCO0VBQ0YsQ0FBQztPQUNJLElBQUksTUFBTSxTQUFTLHNCQUFzQixNQUFNLEtBQUssV0FBVyxtQkFBbUIsR0FDdkYsT0FBTyxNQUFNLE1BQU0sQ0FBQyxLQUFLO0dBQ3ZCLFNBQVMsTUFBTTtHQUNmLFlBQVksWUFBWSxTQUFTLFlBQVk7R0FDN0MsU0FBUztJQUNQLFlBQVkscUJBQXFCLE1BQU0sSUFBSTtJQUMzQyxlQUFlO0lBQ2YsY0FBYztHQUNoQjtFQUNGLENBQUM7T0FDSSxJQUFJLE1BQU0sU0FBUyxnQkFBZ0IsTUFBTSxLQUFLLFdBQVcsYUFBYSxHQUMzRSxPQUFPLE1BQU0sTUFBTSxDQUFDLEtBQUs7R0FDdkIsU0FBUyxNQUFNO0dBQ2YsWUFBWSxZQUFZLFNBQVMsWUFBWTtHQUM3QyxTQUFTO0lBQ1AsWUFBWSxxQkFBcUIsTUFBTSxJQUFJO0lBQzNDLGVBQWU7SUFDZixjQUFjO0dBQ2hCO0VBQ0YsQ0FBQztPQUNJLElBQUksTUFBTSxTQUFTLGtCQUFrQixNQUFNLEtBQUssV0FBVyxlQUFlLEdBQy9FLE9BQU8sTUFBTSxNQUFNLENBQUMsS0FBSztHQUN2QixTQUFTLE1BQU07R0FDZixZQUFZLFlBQVksU0FBUyxZQUFZO0dBQzdDLFNBQVM7SUFDUCxZQUFZLHFCQUFxQixNQUFNLElBQUk7SUFDM0MsZUFBZTtJQUNmLGNBQWM7R0FDaEI7RUFDRixDQUFDO0NBRUw7Q0FDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQ2pDLE9BQU8sT0FBTyxPQUFPLEtBQUssQ0FBQztDQUU3QixPQUFPO0FBQ1Q7OztBQ3BIQSxTQUFTLG1CQUFtQixFQUFFLFVBQVU7Q0FDdEMsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLO0VBQ3RDLE1BQU0sUUFBUSxPQUFPO0VBQ3JCLElBQUksQ0FBQyxPQUFPLE1BQU0sUUFDaEIsT0FBTyxNQUFNLFNBQVMsQ0FBQztFQUV6QixPQUFPLE1BQU0sTUFBTSxDQUFDLE1BQU0sUUFBUSxNQUFNO0NBQzFDO0NBQ0EsT0FBTztBQUNUOzs7QUNWQSxTQUFTLCtCQUErQix3QkFBd0IsMEJBQTBCO0NBQ3hGLE1BQU0sZ0NBQWdDLElBQUksSUFBSTtDQUM5QyxNQUFNLGtDQUFrQyxJQUFJLElBQUk7Q0FnQmhELE9BQU87RUFBRSxTQWZPLENBQUMsR0FBRyx1QkFBdUIsU0FBUyxHQUFHLHlCQUF5QixPQUFPLENBQUMsQ0FBQyxRQUFRLFdBQVc7R0FDMUcsSUFBSSxjQUFjLElBQUksT0FBTyxJQUFJLEdBQy9CLE9BQU87R0FFVCxjQUFjLElBQUksT0FBTyxJQUFJO0dBQzdCLE9BQU87RUFDVCxDQVNlO0VBQUcsUUFSSCxDQUFDLEdBQUcsdUJBQXVCLFFBQVEsR0FBRyx5QkFBeUIsTUFBTSxDQUFDLENBQUMsUUFBUSxVQUFVO0dBQ3RHLE1BQU0sTUFBTSxHQUFHLE1BQU0sS0FBSyxHQUFHLE1BQU07R0FDbkMsSUFBSSxnQkFBZ0IsSUFBSSxHQUFHLEdBQ3pCLE9BQU87R0FFVCxnQkFBZ0IsSUFBSSxHQUFHO0dBQ3ZCLE9BQU87RUFDVCxDQUN1QjtDQUFFO0FBQzNCOzs7QUNaQSxJQUFNLGVBQStCLHVCQUFPLE9BQU8sSUFBSTtBQUN2RCxJQUFNLGFBQU4sTUFBTSxXQUFXOzs7OztDQUtmLFlBQVksU0FBUzs7RUFFbkIsS0FBSyxhQUFhOztFQUVsQixLQUFLLHlCQUF5QjtFQUM5QixNQUFNLEVBQUUsVUFBVSxRQUFRLFFBQVEsV0FBVyxTQUFTO0VBQ3RELEtBQUssT0FBTztFQUNaLEtBQUssV0FBVztFQUNoQixLQUFLLFNBQVM7RUFDZCxJQUFJLFNBQVMsV0FBVyxPQUFPLFFBQVE7R0FDckMsTUFBTSxtQkFBbUIsdUJBQXVCLFNBQVMsTUFBTTtHQUMvRCxLQUFLLG1CQUFtQjtFQUMxQixPQUFPO0dBQ0wsTUFBTSx5QkFBeUIsdUJBQXVCLE9BQU8sTUFBTTtHQUNuRSxNQUFNLDJCQUEyQix1QkFBdUIsU0FBUyxNQUFNO0dBQ3ZFLEtBQUssbUJBQW1CLCtCQUErQix3QkFBd0Isd0JBQXdCO0VBQ3pHO0VBQ0EsS0FBSyxTQUFTLFVBQVUsbUJBQW1CLEtBQUssZ0JBQWdCO0VBQ2hFLEtBQUssWUFBWSxhQUFhLHdCQUF3QixLQUFLLGdCQUFnQjtFQUMzRSxLQUFLLDJCQUEyQixDQUFDLEVBQUUsS0FBSyxPQUFPLEVBQUUsRUFBRSxtQkFBbUIsS0FBSztFQUMzRSxLQUFLLDBCQUEwQixDQUFDLEVBQUUsS0FBSyxPQUFPLEVBQUUsRUFBRSxrQkFBa0IsS0FBSztFQUN6RSxLQUFLLG9CQUFvQjtDQUMzQjtDQUVBLHNCQUFzQjtFQUNwQixNQUFNLEVBQUUsUUFBUSxhQUFhO0VBQzdCLE1BQU0sU0FBUyxPQUFPLFNBQVMsU0FBUyxTQUFTLE9BQU8sYUFBYSxTQUFTO0VBQzlFLEtBQUssYUFBYSxtQkFBbUIsUUFBUSxTQUFTO0NBQ3hEO0NBQ0EsSUFBSSxnQkFBZ0I7RUFDbEIsS0FBSyxtQkFBbUIsS0FBSyxpQkFBaUIsZ0NBQWdDLEtBQUssTUFBTTtFQUN6RixPQUFPLEtBQUs7Q0FDZDs7Q0FFQSxVQUFVO0VBQ1IsS0FBSyxZQUFZO0VBQ2pCLEtBQUssU0FBUztFQUNkLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssV0FBVztFQUNoQixLQUFLLFNBQVM7RUFDZCxhQUFhLEtBQUssYUFBYTtDQUNqQzs7Ozs7Ozs7Q0FRQSxPQUFPLEtBQUssU0FBUztFQUNuQixNQUFNLE1BQU0sR0FBRyxRQUFRLE9BQU8sT0FBTyxHQUFHLFFBQVEsU0FBUyxPQUFPLEdBQUcsUUFBUSxTQUFTLFdBQVcsR0FBRyxRQUFRLE9BQU87RUFDakgsSUFBSSxDQUFDLGFBQWEsTUFBTTtHQUN0QixhQUFhLE9BQU8sSUFBSSxXQUFXLE9BQU87R0FDMUMsYUFBYSxJQUFJLENBQUMsWUFBWTtFQUNoQztFQUNBLE9BQU8sYUFBYTtDQUN0QjtBQUNGOzs7QUN0RUEsSUFBTSx1QkFBdUI7Q0FDM0I7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Y7QUFDQSxJQUFNLG9CQUFvQixxQkFBcUIsUUFBUSxLQUFLLFNBQVM7Q0FDbkUsSUFBSSxRQUFRO0NBQ1osT0FBTztBQUNULEdBQUcsQ0FBQyxDQUFDOzs7QUMxQkwsU0FBUyx1QkFBdUIsTUFBTSxNQUFNO0NBQzFDLFFBQVEsTUFBUjtFQUNFLEtBQUssT0FDSCxPQUFPO0VBQ1QsS0FBSyxhQUNILE9BQU8sSUFBSSxhQUFhLElBQUksSUFBSTtFQUNsQyxLQUFLLGFBQ0gsT0FBTyxJQUFJLGFBQWEsSUFBSSxJQUFJO0VBQ2xDLEtBQUssYUFDSCxPQUFPLElBQUksYUFBYSxJQUFJLElBQUk7RUFDbEMsS0FBSyxlQUNILE9BQU8sSUFBSSxhQUFhO0dBQ3RCO0dBQ0E7R0FDQTtHQUNBO0VBQ0YsQ0FBQztFQUNILEtBQUssZUFDSCxPQUFPLElBQUksYUFBYTtHQUN0QjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRixDQUFDO0VBQ0gsS0FBSyxlQUNILE9BQU8sSUFBSSxhQUFhO0dBQ3RCO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0YsQ0FBQztDQUNMO0NBQ0EsT0FBTztBQUNUOzs7QUM1Q0EsSUFBTSxnQkFBZ0IsTUFBTSxzQkFBc0JDLHNCQUFhOzs7Ozs7Q0FNN0QsWUFBWSxtQkFBbUIsU0FBUztFQUN0QyxNQUFNOztFQUVOLEtBQUssTUFBTSxJQUFJLFNBQVM7Ozs7O0VBS3hCLEtBQUssZ0JBQWdCOzs7OztFQUtyQixLQUFLLGNBQWMsSUFBSSxVQUFVOztFQUVqQyxLQUFLLGlCQUFpQjs7Ozs7RUFLdEIsS0FBSyxXQUFXO0VBRWhCLEtBQUssWUFBWTtFQUNqQixVQUFVO0dBQUUsR0FBRyxjQUFjO0dBQWdCLEdBQUc7RUFBUTtFQUN4RCxLQUFLLG9CQUFvQjtFQUN6QixNQUFNLFdBQVcsQ0FBQztFQUNsQixLQUFLLE1BQU0sS0FBSyxtQkFBbUI7R0FDakMsTUFBTSxjQUFjLGtCQUFrQjtHQUN0QyxZQUFZLE9BQU87R0FDbkIsWUFBWSxPQUFPLFlBQVksUUFBUTtHQUN2QyxJQUFJLENBQUMsa0JBQWtCLFlBQVksT0FBTztJQUN4QyxNQUFNLGFBQWEsWUFBWSxLQUFLLE1BQU0sbUNBQW1DO0lBQzdFLElBQUksWUFBWTtLQUNkLE1BQU0sR0FBRyxXQUFXLFFBQVE7S0FDNUIsTUFBTSxJQUFJLE1BQ1IsZ0JBQWdCLFlBQVksS0FBSyxnQ0FBZ0MsVUFBVSxXQUFXLEtBQUssVUFDN0Y7SUFDRjtJQUNBLE1BQU0sSUFBSSxNQUFNLGdCQUFnQixZQUFZLEtBQUssa0RBQWtELHFCQUFxQixLQUFLLElBQUksR0FBRztHQUN0STtHQUNBLFlBQVksVUFBVSxZQUFZLFFBQVEsdUJBQXVCLFlBQVksTUFBTSxZQUFZLElBQUk7R0FDbkcsU0FBUyxLQUFLLFlBQVk7RUFDNUI7RUFDQSxLQUFLLFdBQVc7RUFDaEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssTUFBTSxRQUFRO0VBQ25CLEtBQUssV0FBVyxRQUFRO0VBQ3hCLEtBQUssYUFBYSxtQkFBbUIsT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLEtBQ3hELE1BQU0sR0FBRyxFQUFFLEdBQUcsa0JBQWtCLEVBQUUsQ0FBQyxNQUN0QyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsZUFBZTtDQUM5Qjs7Ozs7Q0FLQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksT0FBTyxPQUFPO0VBQ2hCLElBQUksS0FBSyxZQUFZLE9BQU87RUFDNUIsS0FBSyxTQUFTLElBQUksVUFBVSxLQUFLLGdCQUFnQixJQUFJO0VBQ3JELEtBQUssVUFBVTtFQUNmLE9BQU8sR0FBRyxVQUFVLEtBQUssZ0JBQWdCLElBQUk7Q0FDL0M7Ozs7Ozs7Q0FPQSxJQUFJLGNBQWM7RUFDaEIsT0FBTyxLQUFLLFNBQVMsZUFBZTtDQUN0QztDQUNBLElBQUksWUFBWSxPQUFPO0VBQ3JCLElBQUksS0FBSyxTQUFTLEtBQUssUUFBUSxjQUFjO0NBQy9DOzs7Ozs7Q0FNQSxpQkFBaUI7RUFDZixLQUFLLGNBQWMsSUFBSSxVQUFVO0VBQ2pDLEtBQUssS0FBSyxVQUFVLElBQUk7Q0FDMUI7O0NBRUEsU0FBUztFQUNQLEtBQUs7Q0FDUDtBQUNGOzs7Ozs7O0FBT0EsY0FBYyxpQkFBaUI7O0NBRTdCLEtBQUs7O0NBRUwsVUFBVTtBQUNaO0FBQ0EsSUFBSSxlQUFlOzs7QUNoSG5CLElBQU0sWUFBTixNQUFnQjs7Ozs7Q0FLZCxZQUFZLFdBQVc7Ozs7Ozs7OztFQVNyQixLQUFLLFlBQTRCLHVCQUFPLE9BQU8sSUFBSTtFQUNuRCxLQUFLLHFCQUFxQjtFQUMxQixLQUFLLFNBQVM7RUFDZCxJQUFJLFFBQVE7RUFDWixLQUFLLE1BQU0sS0FBSyxXQUFXO0dBQ3pCLE1BQU0sV0FBVyxVQUFVO0dBQzNCLEtBQUssWUFBWSxVQUFVLE9BQU87RUFDcEM7Q0FDRjs7Ozs7OztDQU9BLElBQUksZ0JBQWdCO0VBQ2xCLEtBQUssdUJBQXVCLEtBQUsscUJBQXFCLE9BQU8sS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLElBQUksTUFBTTtFQUM1RixPQUFPLEtBQUs7Q0FDZDs7Ozs7O0NBTUEsSUFBSSxPQUFPO0VBQ1QsSUFBSSxLQUFLLFFBQVE7R0FDZixLQUFLLFNBQVM7R0FDZCxNQUFNLFdBQVcsQ0FBQztHQUNsQixJQUFJLFFBQVE7R0FDWixLQUFLLE1BQU0sS0FBSyxLQUFLLFdBQ25CLFNBQVMsV0FBVyxLQUFLLFVBQVUsS0FBSyxLQUFLLFVBQVUsRUFBRSxDQUFDLGNBQWM7R0FFMUUsS0FBSyxZQUFZLFNBQVMsS0FBSyxHQUFHO0VBQ3BDO0VBQ0EsT0FBTyxLQUFLO0NBQ2Q7Ozs7Ozs7O0NBUUEsWUFBWSxVQUFVLE9BQU87RUFDM0IsTUFBTSxrQkFBa0IsS0FBSyxVQUFVO0VBQ3ZDLElBQUksYUFBYSxpQkFBaUI7RUFDbEMsSUFBSSxpQkFDRixnQkFBZ0IsTUFBTSxVQUFVLEtBQUssa0JBQWtCLElBQUk7RUFFN0QsU0FBUyxLQUFLLFVBQVUsS0FBSyxrQkFBa0IsSUFBSTtFQUNuRCxJQUFJLG9CQUFvQixLQUFLLEdBQzNCLEtBQUsscUJBQXFCO0VBRTVCLEtBQUssVUFBVSxTQUFTO0VBQ3hCLEtBQUssU0FBUztDQUNoQjs7Ozs7O0NBTUEsWUFBWSxPQUFPO0VBQ2pCLE9BQU8sS0FBSyxVQUFVO0NBQ3hCOzs7Ozs7O0NBT0EsT0FBTyxLQUFLO0VBQ1YsTUFBTSxZQUFZLEtBQUs7RUFDdkIsTUFBTSxPQUFPLEtBQUs7RUFDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0dBQ3BDLE1BQU0sV0FBVyxVQUFVLEtBQUs7R0FDaEMsSUFBSSxDQUFDLFVBQVU7R0FDZixTQUFTLGNBQWM7RUFDekI7Q0FDRjs7Q0FFQSxVQUFVO0VBQ1IsTUFBTSxZQUFZLEtBQUs7RUFDdkIsS0FBSyxNQUFNLEtBQUssV0FFZCxVQUQyQixFQUNuQixFQUFFLE1BQU0sVUFBVSxLQUFLLGtCQUFrQixJQUFJO0VBRXZELEtBQUssWUFBWTtFQUNqQixLQUFLLHFCQUFxQjtDQUM1QjtDQUNBLGlCQUFpQixVQUFVO0VBQ3pCLEtBQUssU0FBUztFQUNkLElBQUksU0FBUyxXQUFXO0dBQ3RCLE1BQU0sWUFBWSxLQUFLO0dBQ3ZCLEtBQUssTUFBTSxLQUFLLFdBQ2QsSUFBSSxVQUFVLE9BQU8sVUFDbkIsVUFBVSxLQUFLO0dBR25CLEtBQUssa0JBQWtCLFNBQVMsY0FBYywrRkFBK0Y7RUFDL0k7Q0FDRjtBQUNGOzs7QUNySEEsSUFBSSxlQUErQixrQkFBRSxrQkFBa0I7Q0FDckQsY0FBYyxjQUFjLFdBQVcsS0FBSztDQUM1QyxjQUFjLGNBQWMsWUFBWSxLQUFLO0NBQzdDLGNBQWMsY0FBYyxZQUFZLEtBQUs7Q0FDN0MsY0FBYyxjQUFjLFVBQVUsS0FBSztDQUMzQyxPQUFPO0FBQ1QsRUFBQSxDQUFHLGdCQUFnQixDQUFDLENBQUM7OztBQ0pyQixJQUFNLGtCQUFOLE1BQU0sZ0JBQWdCOzs7OztDQUtwQixZQUFZLE1BQU07RUFDaEIsS0FBSyxPQUFPLEVBQUUsR0FBRyxLQUFLO0VBQ3RCLE1BQU0sTUFBTSxPQUFPLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxNQUFNLEdBQUcsRUFBRSxHQUFHLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSyxHQUFHO0VBQzNFLEtBQUssS0FBSyxtQkFBbUIsS0FBSyxrQkFBa0I7Q0FDdEQ7Ozs7OztDQU1BLE9BQU8sS0FBSyxXQUFXO0VBQ3JCLElBQUkscUJBQXFCLGlCQUN2QixPQUFPO0VBRVQsT0FBTyxJQUFJLGdCQUFnQixTQUFTO0NBQ3RDO0FBQ0Y7OztBQ2JBLElBQU0sU0FBTixNQUFNLGVBQWVDLHNCQUFhO0NBQ2hDLFlBQVksU0FBUztFQUNuQixNQUFNOztFQUVOLEtBQUssTUFBTSxJQUFJLFFBQVE7Ozs7OztFQU12QixLQUFLLGtCQUFrQyx1QkFBTyxPQUFPLElBQUk7RUFDekQsS0FBSyxtQkFBbUIsQ0FBQzs7RUFFekIsS0FBSyxhQUFhO0VBQ2xCLElBQUksRUFDRixZQUNBLFdBQ0EsUUFDQSxXQUNBLHFCQUNBLFVBQ0EsY0FDRTtFQUNKLEtBQUssYUFBYSxZQUFZLGdCQUFnQixLQUFLLFNBQVMsSUFBSTtFQUNoRSxLQUFLLGFBQWE7RUFDbEIsS0FBSyxZQUFZO0VBQ2pCLElBQUksd0JBQXdCLEtBQUssR0FBRztHQUNsQyxzQkFBc0I7R0FDdEIsSUFBSSxZQUFZLHVCQUF1QixhQUFhO0dBQ3BELElBQUksV0FBVyx1QkFBdUIsYUFBYTtFQUNyRDtFQUNBLEtBQUssc0JBQXNCO0VBQzNCLE1BQU0sV0FBVyxDQUFDO0VBQ2xCLElBQUksVUFDRixLQUFLLE1BQU0sS0FBSyxVQUNkLEtBQUssTUFBTSxLQUFLLFNBQVMsSUFBSTtHQUMzQixNQUFNLGNBQWMsU0FBUyxFQUFFLENBQUM7R0FDaEMsU0FBUyxlQUFlO0lBQ3RCLE9BQU87SUFDUCxTQUFTO0lBQ1QsTUFBTTtHQUNSO0VBQ0Y7RUFHSixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQ2pCLFlBQVksQ0FBQztFQUVmLElBQUksYUFBYSxRQUNmLE1BQU0sSUFBSSxNQUFNLGdEQUFnRDtPQUMzRCxJQUFJLENBQUMsY0FBYyxVQUFVLENBQUMsVUFDbkMsTUFBTSxJQUFJLE1BQU0scUZBQXFGO09BQ2hHLElBQUksY0FBYyxVQUFVLENBQUMsVUFBVTtHQUM1QyxNQUFNLFlBQVksV0FBVyxpQkFBaUI7R0FDOUMsV0FBVyxDQUFDO0dBQ1osVUFBVSxTQUFTLFNBQVM7SUFDMUIsU0FBUyxLQUFLLFNBQVMsU0FBUyxLQUFLLFVBQVUsQ0FBQztJQUNoRCxTQUFTLEtBQUssTUFBTSxDQUFDLEtBQUssV0FBVyxLQUFLO0lBQzFDLFNBQVMsS0FBSyxRQUFRO0dBQ3hCLENBQUM7RUFDSCxPQUFPLElBQUksV0FBVztHQUNwQixTQUFTLENBQUM7R0FDVixhQUFhLFdBQVcsQ0FBQztHQUN6QixJQUFJLFlBRUYsV0FENkIsaUJBQWlCLE9BQ3BDLFNBQVMsU0FBUztJQUMxQixTQUFTLEtBQUssU0FBUyxTQUFTLEtBQUssVUFBVSxDQUFDO0lBQ2hELFNBQVMsS0FBSyxNQUFNLENBQUMsS0FBSyxXQUFXLEtBQUs7SUFDMUMsU0FBUyxLQUFLLFFBQVE7R0FDeEIsQ0FBQztHQUVILElBQUksV0FBVztHQUNmLEtBQUssTUFBTSxLQUFLLFdBQVc7SUFDekIsSUFBSSxTQUFTLElBQUk7SUFDakIsSUFBSSxjQUFjLENBQUMsV0FDakIsS0FBSywwQkFBMEIsRUFBRSxvRUFBb0U7SUFFdkcsSUFBSSxDQUFDLE9BQU8sS0FBSztLQUNmLE9BQU8sTUFBTSxJQUFJLFVBQVU7S0FDM0IsS0FBSyxpQkFBaUIsS0FBSyxPQUFPLEdBQUc7SUFDdkM7SUFDQSxTQUFTLEtBQUs7S0FBRSxPQUFPO0tBQUksU0FBUztLQUFVLE1BQU07SUFBRTtJQUN0RCxTQUFTLE1BQU0sU0FBUyxPQUFPLENBQUM7SUFDaEMsU0FBUyxHQUFHLENBQUMsWUFBWTtJQUN6QjtHQUNGO0dBQ0EsS0FBSyxNQUFNLEtBQUssV0FBVztJQUN6QixNQUFNLE9BQU87SUFDYixJQUFJLFFBQVEsVUFBVTtJQUN0QixJQUFJLENBQUMsTUFBTSxVQUFVLENBQUMsTUFBTSxlQUMxQixRQUFRLElBQUksYUFBYSxLQUFLO0lBRWhDLE1BQU0sT0FBTyxTQUFTO0lBQ3RCLElBQUksTUFBTTtLQUNSLElBQUksQ0FBQyxPQUFPLEtBQUssUUFBUTtNQUN2QixPQUFPLEtBQUssU0FBUyxJQUFJLFVBQVU7TUFDbkMsS0FBSyxpQkFBaUIsS0FBSyxPQUFPLEtBQUssTUFBTTtLQUMvQztLQUNBLE9BQU8sS0FBSyxNQUFNLENBQUMsWUFBWSxPQUFPLEtBQUssT0FBTztJQUNwRDtHQUNGO0VBQ0Y7RUFDQSxLQUFLLFNBQVM7RUFDZCxLQUFLLGtCQUFrQjtFQUN2QixLQUFLLFlBQVksS0FBSyx1QkFBdUIsUUFBUSxRQUFRO0NBQy9EOzs7Ozs7OztDQVFBLFlBQVksTUFBTSxZQUFZLFdBQVc7RUFDdkMsSUFBSSxJQUFJO0VBQ1IsQ0FBQyxLQUFLLEtBQUssZ0JBQUEsQ0FBaUIsZ0JBQWdCLEdBQUcsY0FBYyxDQUFDO0VBQzlELENBQUMsS0FBSyxLQUFLLGdCQUFnQixZQUFBLENBQWEsZUFBZSxHQUFHLGFBQWE7RUFDdkUsSUFBSSxDQUFDLEtBQUssT0FBTyxhQUFhO0dBQzVCLEtBQUssT0FBTyxjQUFjLElBQUksVUFBVTtHQUN4QyxLQUFLLGlCQUFpQixLQUFLLEtBQUssT0FBTyxXQUFXO0VBQ3BEO0NBQ0Y7Q0FDQSx1QkFBdUIsUUFBUSxVQUFVO0VBQ3ZDLE1BQU0sY0FBYyxDQUFDO0VBQ3JCLEtBQUssTUFBTSxLQUFLLFVBQVU7R0FDeEIsTUFBTSxPQUFPLFNBQVM7R0FDdEIsT0FBTyxlQUFlLGFBQWEsS0FBSyxNQUFNO0lBQzVDLE1BQU07S0FDSixPQUFPLE9BQU8sS0FBSyxNQUFNLENBQUMsWUFBWSxLQUFLLE9BQU87SUFDcEQ7SUFDQSxJQUFJLE9BQU87S0FDVCxPQUFPLEtBQUssTUFBTSxDQUFDLFlBQVksT0FBTyxLQUFLLE9BQU87SUFDcEQ7R0FDRixDQUFDO0VBQ0g7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Q0FPQSxRQUFRLGtCQUFrQixPQUFPO0VBQy9CLElBQUksS0FBSyxZQUFZO0VBQ3JCLEtBQUssYUFBYTtFQUNsQixLQUFLLEtBQUssV0FBVyxJQUFJO0VBQ3pCLElBQUksaUJBQWlCO0dBQ25CLEtBQUssWUFBWSxRQUFRO0dBQ3pCLEtBQUssV0FBVyxRQUFRO0VBQzFCO0VBQ0EsS0FBSyxhQUFhO0VBQ2xCLEtBQUssWUFBWTtFQUNqQixLQUFLLG1CQUFtQjtFQUN4QixLQUFLLGtCQUFrQjtFQUN2QixLQUFLLGlCQUFpQixTQUFTLGNBQWM7R0FDM0MsVUFBVSxRQUFRO0VBQ3BCLENBQUM7RUFDRCxLQUFLLG1CQUFtQjtFQUN4QixLQUFLLFlBQVk7RUFDakIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxhQUFhO0NBQ3BCO0NBQ0EsT0FBTyxLQUFLLFNBQVM7RUFDbkIsTUFBTSxFQUFFLEtBQUssSUFBSSxHQUFHLFNBQVM7RUFDN0IsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJLEtBQ0YsYUFBYSxXQUFXLEtBQUssR0FBRztFQUVsQyxJQUFJLElBQ0YsWUFBWSxVQUFVLEtBQUssRUFBRTtFQUUvQixPQUFPLElBQUksT0FBTztHQUNoQjtHQUNBO0dBQ0EsR0FBRztFQUNMLENBQUM7Q0FDSDtBQUNGOzs7QUM3TEEsSUFBSSxjQUE4QixrQkFBRSxpQkFBaUI7Q0FDbkQsYUFBYSxhQUFhLGNBQWMsS0FBSztDQUM3QyxhQUFhLGFBQWEsZUFBZSxLQUFLO0NBQzlDLGFBQWEsYUFBYSxjQUFjLEtBQUs7Q0FDN0MsYUFBYSxhQUFhLGNBQWMsS0FBSztDQUM3QyxhQUFhLGFBQWEsV0FBVyxNQUFNO0NBQzNDLGFBQWEsYUFBYSxZQUFZLE1BQU07Q0FDNUMsYUFBYSxhQUFhLGFBQWEsTUFBTTtDQUM3QyxhQUFhLGFBQWEsYUFBYSxPQUFPO0NBQzlDLGFBQWEsYUFBYSxjQUFjLE9BQU87Q0FDL0MsYUFBYSxhQUFhLG1CQUFtQixPQUFPO0NBQ3BELGFBQWEsYUFBYSxZQUFZLFFBQVE7Q0FDOUMsT0FBTztBQUNULEVBQUEsQ0FBRyxlQUFlLENBQUMsQ0FBQzs7O0FDVHBCLElBQU0sU0FBTixjQUFxQkMsc0JBQWE7Ozs7O0NBS2hDLFlBQVksU0FBUztFQUNuQixJQUFJLEVBQUUsTUFBTSxTQUFTO0VBQ3JCLE1BQU0sRUFBRSxPQUFPLE9BQU8sZ0JBQWdCO0VBQ3RDLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7RUFnQk4sS0FBSyxXQUEyQix1QkFBTyxPQUFPLElBQUk7O0VBRWxELEtBQUssY0FBYzs7RUFFbkIsS0FBSyxxQkFBcUI7O0VBRTFCLEtBQUssTUFBTSxJQUFJLFFBQVE7Ozs7O0VBS3ZCLEtBQUssZ0JBQWdCOzs7OztFQUtyQixLQUFLLGNBQWMsSUFBSSxVQUFVOztFQUVqQyxLQUFLLFlBQVk7O0VBRWpCLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssYUFBYTs7Ozs7Ozs7O0VBU2xCLEtBQUssY0FBYzs7Ozs7RUFLbkIsS0FBSyxZQUFZO0VBQ2pCLElBQUksZ0JBQWdCLE9BQ2xCLE9BQU8sSUFBSSxhQUFhLElBQUk7RUFFOUIsS0FBSyxRQUFRO0VBQ2IsU0FBUyxPQUFPLE1BQU07RUFDdEIsTUFBTSxtQkFBbUIsQ0FBQyxDQUFDO0VBQzNCLEtBQUssYUFBYTtHQUNoQjtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsS0FBSyxjQUFjLGVBQWU7Q0FDcEM7O0NBRUEsSUFBSSxPQUFPO0VBQ1QsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLEtBQUssT0FBTztFQUNkLEtBQUssZ0JBQWdCLE9BQU8sTUFBTSxRQUFRLElBQUk7Q0FDaEQ7Q0FDQSxJQUFJLFlBQVk7RUFDZCxJQUFJLENBQUMsS0FBSyxZQUNSLEtBQUssYUFBYSxJQUFJLFdBQVcsS0FBSyxLQUFLLE1BQU07RUFFbkQsT0FBTyxLQUFLO0NBQ2Q7O0NBRUEsSUFBSSxTQUFTO0VBQ1gsT0FBTyxDQUFDLEVBQUUsS0FBSyxXQUFXLFFBQVEsWUFBWTtDQUNoRDtDQUNBLElBQUksT0FBTyxPQUFPO0VBQ2hCLElBQUksT0FDRixLQUFLLFdBQVcsU0FBUyxZQUFZO09BRXJDLEtBQUssV0FBVyxTQUFTLENBQUMsWUFBWTtDQUUxQzs7Ozs7Ozs7Q0FRQSxnQkFBZ0IsT0FBTyxNQUFNLFNBQVM7RUFDcEMsS0FBSztFQUNMLEtBQUssY0FBYyxPQUFPLE1BQU07RUFDaEMsS0FBSyxnQkFBZ0I7RUFDckIsSUFBSSxLQUFLLFVBQVUsT0FBTztHQUN4QixJQUFJLFNBQVMsS0FBSyxLQUFLLFVBQVUsSUFBSTtHQUNyQztFQUNGO0VBQ0EsTUFBTSxVQUFVLEtBQUs7RUFDckIsS0FBSyxRQUFRO0VBQ2IsS0FBSyxhQUFhO0VBQ2xCLElBQUksQ0FBQyxXQUFXLFFBQVEsV0FBVyxNQUFNLFFBQVE7R0FDL0MsSUFBSSxDQUFDLEtBQUssZUFBZSxXQUFXLE1BQU0sYUFBYSxRQUFRLFlBQ3pEO1FBQUEsU0FBUyxLQUFLLEtBQUssVUFBVSxJQUFJO0dBQUEsT0FDaEM7SUFDTCxLQUFLLFdBQVcsT0FBTyxNQUFNO0lBQzdCLEtBQUssY0FBYyxJQUFJLFVBQVU7SUFDakMsS0FBSyxLQUFLLFVBQVUsSUFBSTtHQUMxQjtHQUNBO0VBQ0Y7RUFDQSxJQUFJLFNBQVMsS0FBSyxLQUFLLFVBQVUsSUFBSTtDQUN2Qzs7Ozs7Ozs7Q0FRQSxPQUFPLGFBQWEsZUFBZTtFQUNqQyxLQUFLLGNBQWMsZUFBZSxLQUFLO0VBQ3ZDLEtBQUssZ0JBQWdCLGlCQUFpQjtFQUN0QyxLQUFLO0VBQ0wsS0FBSyxLQUFLLFVBQVUsSUFBSTtDQUMxQjs7Q0FFQSxTQUFTO0VBQ1AsS0FBSyxLQUFLLFVBQVUsSUFBSTtFQUN4QixLQUFLLE1BQU0sT0FBTyxLQUFLLFVBQ3JCLEtBQUssU0FBUyxJQUFJLEVBQUUsUUFBUTtFQUU5QixLQUFLLFdBQTJCLHVCQUFPLE9BQU8sSUFBSTtFQUNsRCxJQUFJLENBQUMsS0FBSyxXQUFXO0dBQ25CLEtBQUssY0FBYyxJQUFJLFVBQVU7R0FDakMsS0FBSyxLQUFLLFVBQVUsSUFBSTtFQUMxQjtDQUNGOztDQUVBLFVBQVU7RUFDUixLQUFLLFlBQVk7RUFDakIsS0FBSyxPQUFPO0VBQ1osS0FBSyxLQUFLLFdBQVcsSUFBSTtFQUN6QixLQUFLLEtBQUssVUFBVSxJQUFJO0VBQ3hCLEtBQUssUUFBUTtFQUNiLEtBQUssYUFBYTtFQUNsQixLQUFLLG1CQUFtQjtDQUMxQjtBQUNGOzs7QUNwS0EsU0FBUyxlQUFlLFFBQVEsT0FBTztDQUNyQyxJQUFJLEVBQUUsa0JBQWtCLFNBQVM7RUFDL0IsSUFBSSxRQUFRLFFBQVEsWUFBWSxRQUFRLFlBQVk7RUFDcEQsSUFBSSxrQkFBa0IsT0FBTztHQUMzQixJQUFJLE9BQU87SUFDVCxTQUFTLElBQUksWUFBWSxNQUFNO0lBQy9CLFFBQVEsWUFBWSxRQUFRLFlBQVk7R0FDMUMsT0FBTztJQUNMLFNBQVMsSUFBSSxhQUFhLE1BQU07SUFDaEMsUUFBUSxZQUFZLFNBQVMsWUFBWTtHQUMzQztFQUNGO0VBQ0EsU0FBUyxJQUFJLE9BQU87R0FDbEIsTUFBTTtHQUNOLE9BQU8sUUFBUSxzQkFBc0I7R0FDckM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxPQUFPO0FBQ1Q7OztBQ3RCQSxTQUFTLGtCQUFrQixVQUFVLGFBQWEsUUFBUTtDQUN4RCxNQUFNLFlBQVksU0FBUyxhQUFhLFdBQVc7Q0FDbkQsSUFBSSxDQUFDLFdBQVc7RUFDZCxPQUFPLE9BQU87RUFDZCxPQUFPLE9BQU87RUFDZCxPQUFPLE9BQU87RUFDZCxPQUFPLE9BQU87RUFDZCxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLE9BQU8sVUFBVSxPQUFPO0NBQzlCLElBQUksT0FBTztDQUNYLElBQUksT0FBTztDQUNYLElBQUksT0FBTztDQUNYLElBQUksT0FBTztDQUNYLE1BQU0sV0FBVyxLQUFLO0NBQ3RCLE1BQU0sVUFBVSxVQUFVLFVBQVUsS0FBSztDQUN6QyxNQUFNLFVBQVUsVUFBVSxVQUFVLEtBQVM7Q0FDN0MsS0FBSyxJQUFJLElBQUksUUFBUSxJQUFJLEtBQUssUUFBUSxLQUFLLFFBQVE7RUFDakQsTUFBTSxJQUFJLEtBQUs7RUFDZixNQUFNLElBQUksS0FBSyxJQUFJO0VBQ25CLElBQUksSUFBSSxNQUFNLE9BQU87RUFDckIsSUFBSSxJQUFJLE1BQU0sT0FBTztFQUNyQixJQUFJLElBQUksTUFBTSxPQUFPO0VBQ3JCLElBQUksSUFBSSxNQUFNLE9BQU87Q0FDdkI7Q0FDQSxPQUFPLE9BQU87Q0FDZCxPQUFPLE9BQU87Q0FDZCxPQUFPLE9BQU87Q0FDZCxPQUFPLE9BQU87Q0FDZCxPQUFPO0FBQ1Q7OztBQ3RCQSxTQUFTLGtCQUFrQixXQUFXO0NBQ3BDLElBQUkscUJBQXFCLFVBQVUsTUFBTSxRQUFRLFNBQVMsS0FBSyxVQUFVLG1CQUN2RSxZQUFZLEVBQ1YsUUFBUSxVQUNWO0NBRUYsVUFBVSxTQUFTLGVBQWUsVUFBVSxRQUFRLEtBQUs7Q0FDekQsT0FBTztBQUNUO0FBQ0EsSUFBTSxXQUFOLGNBQXVCQyxzQkFBYTs7Ozs7Q0FLbEMsWUFBWSxVQUFVLENBQUMsR0FBRztFQUN4QixNQUFNOztFQUVOLEtBQUssV0FBMkIsdUJBQU8sT0FBTyxJQUFJOztFQUVsRCxLQUFLLHFCQUFxQjs7RUFFMUIsS0FBSyxjQUFjOztFQUVuQixLQUFLLE1BQU0sSUFBSSxVQUFVOzs7Ozs7RUFNekIsS0FBSyxhQUFhOztFQUVsQixLQUFLLGdCQUFnQjs7Ozs7Ozs7Ozs7O0VBWXJCLEtBQUssYUFBYTtFQUNsQixLQUFLLFVBQVUsSUFBSSxPQUFPO0VBQzFCLEtBQUssZUFBZTtFQUNwQixLQUFLLGVBQWU7RUFDcEIsS0FBSyxvQkFBb0I7RUFDekIsTUFBTSxFQUFFLFlBQVksYUFBYSxhQUFhO0VBQzlDLEtBQUssVUFBVSxDQUFDO0VBQ2hCLEtBQUssYUFBYSxDQUFDO0VBQ25CLElBQUksWUFDRixLQUFLLE1BQU0sS0FBSyxZQUNkLEtBQUssYUFBYSxHQUFHLFdBQVcsRUFBRTtFQUd0QyxLQUFLLGdCQUFnQixRQUFRLGlCQUFpQjtFQUM5QyxLQUFLLGFBQWEsUUFBUSxjQUFjO0VBQ3hDLElBQUksYUFDRixLQUFLLFNBQVMsV0FBVztFQUUzQixLQUFLLFdBQVcsWUFBWTtDQUM5QjtDQUNBLGlCQUFpQjtFQUNmLEtBQUssZUFBZTtFQUNwQixLQUFLLG9CQUFvQjtFQUN6QixLQUFLLEtBQUssVUFBVSxJQUFJO0NBQzFCOzs7Ozs7Q0FNQSxhQUFhLElBQUk7RUFDZixPQUFPLEtBQUssV0FBVztDQUN6Qjs7Ozs7Q0FLQSxXQUFXO0VBQ1QsT0FBTyxLQUFLO0NBQ2Q7Ozs7OztDQU1BLFVBQVUsSUFBSTtFQUNaLE9BQU8sS0FBSyxhQUFhLEVBQUUsQ0FBQyxDQUFDO0NBQy9COzs7OztDQUtBLElBQUksY0FBYztFQUNoQixJQUFJLENBQUMsS0FBSyxtQkFBbUIsT0FBTyxLQUFLO0VBQ3pDLEtBQUssb0JBQW9CO0VBQ3pCLE1BQU0sYUFBYSxLQUFLO0VBQ3hCLEtBQUssTUFBTSxLQUFLLFlBQVk7R0FDMUIsTUFBTSxZQUFZLFdBQVc7R0FDN0IsSUFBSSxVQUFVLFVBQVU7R0FDeEIsTUFBTSxTQUFTLFVBQVU7R0FDekIsS0FBSyxlQUFlLE9BQU8sS0FBSyxVQUFVLFVBQVUsU0FBUyxLQUFLLFVBQVU7R0FDNUUsT0FBTyxLQUFLO0VBQ2Q7RUFDQSxLQUFLLGVBQWU7RUFDcEIsT0FBTztDQUNUOzs7Ozs7Q0FNQSxVQUFVO0VBQ1IsWUFBWSxVQUFVLDBFQUEwRTtFQUNoRyxPQUFPLEtBQUs7Q0FDZDs7Ozs7O0NBTUEsYUFBYSxNQUFNLGlCQUFpQjtFQUNsQyxNQUFNLFlBQVksa0JBQWtCLGVBQWU7RUFFbkQsSUFEb0IsS0FBSyxRQUFRLFFBQVEsVUFBVSxNQUNyQyxNQUFNLElBQUk7R0FDdEIsS0FBSyxRQUFRLEtBQUssVUFBVSxNQUFNO0dBQ2xDLFVBQVUsT0FBTyxHQUFHLFVBQVUsS0FBSyxnQkFBZ0IsSUFBSTtHQUN2RCxVQUFVLE9BQU8sR0FBRyxVQUFVLEtBQUssZ0JBQWdCLElBQUk7RUFDekQ7RUFDQSxLQUFLLFdBQVcsUUFBUTtFQUN4QixLQUFLLG9CQUFvQjtDQUMzQjs7Ozs7Q0FLQSxTQUFTLGFBQWE7RUFDcEIsS0FBSyxjQUFjLGVBQWUsYUFBYSxJQUFJO0VBQ25ELEtBQUssUUFBUSxLQUFLLEtBQUssV0FBVztDQUNwQzs7Q0FFQSxJQUFJLFNBQVM7RUFDWCxJQUFJLENBQUMsS0FBSyxjQUFjLE9BQU8sS0FBSztFQUNwQyxLQUFLLGVBQWU7RUFDcEIsT0FBTyxrQkFBa0IsTUFBTSxhQUFhLEtBQUssT0FBTztDQUMxRDs7Q0FFQSxTQUFTO0VBQ1AsS0FBSyxLQUFLLFVBQVUsSUFBSTtFQUN4QixLQUFLLE1BQU0sT0FBTyxLQUFLLFVBQ3JCLEtBQUssU0FBUyxJQUFJLEVBQUUsUUFBUTtFQUU5QixLQUFLLFdBQTJCLHVCQUFPLE9BQU8sSUFBSTtDQUNwRDs7Ozs7Q0FLQSxRQUFRLGlCQUFpQixPQUFPO0VBQzlCLEtBQUssS0FBSyxXQUFXLElBQUk7RUFDekIsS0FBSyxNQUFNLFVBQVUsS0FBSyxTQUFTO0dBQ2pDLE9BQU8sSUFBSSxVQUFVLEtBQUssZ0JBQWdCLElBQUk7R0FDOUMsT0FBTyxJQUFJLFVBQVUsS0FBSyxnQkFBZ0IsSUFBSTtHQUM5QyxJQUFJLGdCQUFnQixPQUFPLFFBQVE7RUFDckM7RUFDQSxLQUFLLE9BQU87RUFDWixLQUFLLG1CQUFtQjtFQUN4QixLQUFLLGFBQWE7RUFDbEIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxjQUFjO0VBQ25CLEtBQUssVUFBVTtDQUNqQjtBQUNGOzs7QUMvS0EsSUFBTSxrQkFBa0I7QUFDeEIsU0FBUyxVQUFVLE9BQU8sUUFBUTtDQUNoQyxRQUFRLFNBQVMsT0FBTyxVQUFVO0FBQ3BDO0FBQ0EsSUFBTSxrQkFBTixNQUFzQjtDQUNwQixZQUFZLGVBQWU7O0VBRXpCLEtBQUssMkJBQTJCLElBQUksSUFBSTs7RUFFeEMsS0FBSyxXQUFXLElBQUksbUJBQW1CO0VBQ3ZDLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssZ0JBQWdCLGlCQUFpQixDQUFDO0NBQ3pDOzs7Ozs7Q0FNQSxJQUFJLG1CQUFtQjtFQUNyQixZQUFZLFNBQVMsc0hBQXNIO0VBQzNJLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxpQkFBaUIsT0FBTztFQUMxQixZQUFZLFNBQVMsc0hBQXNIO0VBQzNJLEtBQUssb0JBQW9CO0NBQzNCOzs7Ozs7Q0FNQSx3QkFBd0IsWUFBWSxhQUFhO0VBQy9DLE1BQU0sU0FBUyxXQUFXLElBQUksQ0FBQyxDQUFDLGFBQWE7RUFDN0MsT0FBTyxRQUFRO0VBQ2YsT0FBTyxTQUFTO0VBRWhCLE9BQU87R0FBRTtHQUFRLFNBREQsT0FBTyxXQUFXLElBQ1g7RUFBRTtDQUMzQjs7Ozs7Ozs7Q0FRQSwyQkFBMkIsVUFBVSxXQUFXLGFBQWEsR0FBRztFQUM5RCxNQUFNLEVBQUUsT0FBTyxhQUFhLFFBQVEsaUJBQWlCLEtBQUssZUFBZSxVQUFVLFdBQVcsVUFBVTtFQUN4RyxJQUFJLGNBQWMsbUJBQW1CLGVBQWUsaUJBQ2xELEtBQUssZUFBZSxZQUFZLEdBQUcsYUFBYSxzQkFBc0IsZ0JBQWdCLGdFQUFnRTtFQUV4SixNQUFNLE1BQU0sVUFBVSxhQUFhLFlBQVk7RUFDL0MsSUFBSSxTQUFTLEtBQUssU0FBUyxJQUFJLEdBQUc7RUFDbEMsSUFBSSxDQUFDLFFBQVE7R0FDWCxTQUFTLENBQUM7R0FDVixLQUFLLFNBQVMsSUFBSSxLQUFLLE1BQU07RUFDL0I7RUFDQSxJQUFJLG1CQUFtQixPQUFPLElBQUk7RUFDbEMsSUFBSSxDQUFDLGtCQUNILG1CQUFtQixLQUFLLHdCQUF3QixhQUFhLFlBQVk7RUFFM0UsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7O0NBYUEsZUFBZSxVQUFVLFdBQVcsYUFBYSxHQUFHO0VBQ2xELE1BQU0sYUFBYSxLQUFLLEtBQUssV0FBVyxhQUFhLElBQUk7RUFDekQsTUFBTSxjQUFjLEtBQUssS0FBSyxZQUFZLGFBQWEsSUFBSTtFQUMzRCxNQUFNLFdBQVcsU0FBUyxVQUFVO0VBQ3BDLE1BQU0sY0FBYyxLQUFLLFNBQVMsZ0JBQWdCLFVBQVU7RUFDNUQsTUFBTSxZQUFZLFNBQVMsV0FBVztFQUN0QyxNQUFNLGVBQWUsS0FBSyxTQUFTLGlCQUFpQixXQUFXO0VBQy9ELE9BQU87R0FDTCxPQUFPLGdCQUFnQixLQUFLLElBQUksS0FBSyxJQUFJLGFBQWEsUUFBUSxJQUFJO0dBQ2xFLFFBQVEsaUJBQWlCLEtBQUssSUFBSSxLQUFLLElBQUksY0FBYyxTQUFTLElBQUk7RUFDeEU7Q0FDRjs7Ozs7Q0FLQSx1QkFBdUIsa0JBQWtCO0VBRXZDLE1BQU0sRUFBRSxPQUFPLFdBREEsaUJBQWlCO0VBRWhDLE1BQU0sV0FBVyxLQUFLLFNBQVMsSUFBSSxVQUFVLE9BQU8sTUFBTSxDQUFDO0VBQzNELElBQUksQ0FBQyxVQUFVO0VBQ2YsaUJBQWlCLFFBQVEsZUFBZTtFQUN4QyxpQkFBaUIsUUFBUSxVQUFVLEdBQUcsR0FBRyxPQUFPLE1BQU07RUFDdEQsU0FBUyxLQUFLLGdCQUFnQjtDQUNoQzs7Ozs7Ozs7Ozs7O0NBWUEsY0FBYyxhQUFhLFlBQVksYUFBYTtFQUNsRCxJQUFJLENBQUMsS0FBSyxTQUFTLElBQUksYUFBYSxZQUFZLFdBQVcsR0FBRztFQUM5RCxLQUFLLHFCQUFxQjtDQUM1Qjs7Ozs7OztDQU9BLGFBQWEsYUFBYTtFQUN4QixJQUFJLENBQUMsS0FBSyxTQUFTLE9BQU8sV0FBVyxHQUFHO0VBQ3hDLEtBQUsscUJBQXFCO0NBQzVCOztDQUVBLFFBQVE7RUFDTixLQUFLLFNBQVMsTUFBTTtDQUN0Qjs7Ozs7Q0FLQSx1QkFBdUI7RUFDckIsS0FBSyxNQUFNLENBQUMsUUFBUSxLQUFLLFVBQVU7R0FDakMsTUFBTSxRQUFRLFFBQVE7R0FDdEIsTUFBTSxTQUFTLFFBQVEsSUFBSTtHQUMzQixLQUFLLE9BQU8sS0FBSyxLQUFLLEtBQUssU0FBUyxTQUFTLEtBQUssT0FBTyxPQUFPLE1BQU0sS0FBSyxLQUFLLFNBQVMsVUFBVSxNQUFNLElBQUk7R0FDN0csS0FBSyxTQUFTLE9BQU8sR0FBRztFQUMxQjtDQUNGO0FBQ0Y7QUFDQSxJQUFNLGFBQWEsSUFBSSxnQkFBZ0I7QUFDdkMsdUJBQXVCLFNBQVMsVUFBVSIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzLDM0LDM1LDM2LDM3LDM4LDM5LDQwLDQxLDQyLDQzLDQ0LDQ1LDQ2LDQ3LDQ4LDQ5LDUwLDUxLDUyLDUzLDU0LDU1LDU2LDU3LDU4LDU5LDYwLDYxXX0=