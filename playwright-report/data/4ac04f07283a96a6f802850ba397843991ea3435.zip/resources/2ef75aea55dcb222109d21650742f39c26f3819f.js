import { D as isStringEqual, E as isPath, I as FetchResponse, J as Emitter, K as createRequestId, O as matchRequestUrl, Q as getCleanUrlString, S as devUtils, T as httpStatusMessages, X as invariant, Y as TypedEvent, Z as isNodeProcess, _ as colors, a as executeHandlers, c as attachSiblingHandlers, i as HttpResponse, j as resolveWebSocketUrl, k as toPublicUrl, n as isPassthroughResponse, o as WebSocketConnectionEvent, p as kEmitter, r as passthrough, s as WebSocketHandler, t as isCommonAssetRequest, v as isObject, w as getTimestamp, x as cookieStore, y as RequestHandler } from "/node_modules/.vite/deps/is-common-asset-request-D_lDqhHG.js?v=43418a0e";
//#region node_modules/cookie/dist/index.js
var NullObject = /* @__PURE__ */ (() => {
	const C = function() {};
	C.prototype = Object.create(null);
	return C;
})();
/**
* Parse a `Cookie` header.
*
* Parse the given cookie header string into an object
* The object has the various cookies as keys(names) => values
*/
function parseCookie(str, options) {
	const obj = new NullObject();
	const len = str.length;
	if (len < 2) return obj;
	const dec = options?.decode || decode;
	let index = 0;
	do {
		const eqIdx = eqIndex(str, index, len);
		if (eqIdx === len) break;
		const endIdx = endIndex(str, index, len);
		if (eqIdx > endIdx) {
			index = str.lastIndexOf(";", eqIdx - 1) + 1;
			continue;
		}
		const key = valueSlice(str, index, eqIdx);
		if (obj[key] === void 0) obj[key] = dec(valueSlice(str, eqIdx + 1, endIdx));
		index = endIdx + 1;
	} while (index < len);
	return obj;
}
/**
* Find the next `;` character, or return `len`.
*/
function endIndex(str, min, len) {
	const index = str.indexOf(";", min);
	return index === -1 ? len : index;
}
/**
* Find the next `=` character, or return `len`.
*/
function eqIndex(str, min, len) {
	const index = str.indexOf("=", min);
	return index === -1 ? len : index;
}
/**
* Slice out a value between startPod to max.
*/
function valueSlice(str, min, max) {
	if (min === max) return "";
	let start = min;
	let end = max;
	do {
		const code = str.charCodeAt(start);
		if (code !== 32 && code !== 9) break;
	} while (++start < end);
	while (end > start) {
		const code = str.charCodeAt(end - 1);
		if (code !== 32 && code !== 9) break;
		end--;
	}
	return str.slice(start, end);
}
/**
* URL-decode string value. Optimized to skip native call when no %.
*/
function decode(str) {
	if (str.indexOf("%") === -1) return str;
	try {
		return decodeURIComponent(str);
	} catch (e) {
		return str;
	}
}
//#endregion
//#region node_modules/msw/lib/_chunks/http-handler.js
/**
* Returns a HEX color for a given response status code number.
*/
function getStatusCodeColor(status) {
	if (status < 300) return "#69AB32";
	if (status < 400) return "#F0BB4B";
	return "#E95F5D";
}
/**
* Formats a mocked request for introspection in browser's console.
*/
async function serializeRequest(request) {
	const requestText = await request.clone().text();
	return {
		url: new URL(request.url),
		method: request.method,
		headers: Object.fromEntries(request.headers.entries()),
		body: requestText
	};
}
async function serializeResponse(response) {
	const responseClone = response.clone();
	const responseText = await responseClone.text();
	const responseStatus = responseClone.status || 200;
	return {
		status: responseStatus,
		statusText: responseClone.statusText || httpStatusMessages[responseStatus] || "OK",
		headers: Object.fromEntries(responseClone.headers.entries()),
		body: responseText
	};
}
function parseCookies(input) {
	const parsedCookies = parseCookie(input);
	const cookies = {};
	for (const cookieName in parsedCookies) if (typeof parsedCookies[cookieName] !== "undefined") cookies[cookieName] = parsedCookies[cookieName];
	return cookies;
}
function getAllDocumentCookies() {
	return parseCookies(document.cookie);
}
/**
* Returns whether the given request would carry cookies,
* based on its `credentials` mode.
*/
function includesCredentials(request) {
	switch (request.credentials) {
		case "same-origin": return typeof location !== "undefined" && location.origin === new URL(request.url).origin;
		case "include": return true;
		default: return false;
	}
}
function getDocumentCookies() {
	if (typeof document === "undefined") return {};
	return getAllDocumentCookies();
}
function getAllRequestCookies(request) {
	const requestCookieHeader = request.headers.get("cookie");
	const cookiesFromHeaders = requestCookieHeader ? parseCookies(requestCookieHeader) : {};
	if (cookieStore === null || !includesCredentials(request)) return cookiesFromHeaders;
	const cookiesFromDocument = getDocumentCookies();
	const cookiesFromStore = cookieStore.getCookies(request.url);
	const storedCookiesObject = Object.fromEntries(cookiesFromStore.map((cookie) => [cookie.key, cookie.value]));
	return {
		...cookiesFromDocument,
		...storedCookiesObject,
		...cookiesFromHeaders
	};
}
var HttpMethods = /* @__PURE__ */ function(HttpMethods) {
	HttpMethods["HEAD"] = "HEAD";
	HttpMethods["GET"] = "GET";
	HttpMethods["POST"] = "POST";
	HttpMethods["PUT"] = "PUT";
	HttpMethods["PATCH"] = "PATCH";
	HttpMethods["OPTIONS"] = "OPTIONS";
	HttpMethods["DELETE"] = "DELETE";
	return HttpMethods;
}({});
/**
* Request handler for HTTP requests.
* Provides request matching based on method and URL.
*/
var HttpHandler = class extends RequestHandler {
	constructor(method, predicate, resolver, options) {
		const displayPath = typeof predicate === "function" ? "[custom predicate]" : predicate;
		super({
			info: {
				header: `${method}${displayPath ? ` ${displayPath}` : ""}`,
				path: predicate,
				method
			},
			resolver,
			options
		});
		this.checkRedundantQueryParameters();
	}
	checkRedundantQueryParameters() {
		const { method, path } = this.info;
		if (!path || path instanceof RegExp || typeof path === "function") return;
		if (getCleanUrlString(path) === path) return;
		devUtils.warn(`Found a redundant usage of query parameters in the request handler URL for "${method} ${path}". Please match against a path instead and access query parameters using "new URL(request.url).searchParams" instead. Learn more: https://mswjs.io/docs/http/intercepting-requests#querysearch-parameters`);
	}
	async parse(args) {
		/**
		* @note CONNECT requests target an authority ("host:port"), not a URL.
		* HTTP handlers never match them.
		* @todo Match the authority against the handler path once
		* `http.connect()` is supported instead of bailing out.
		*/
		if (isStringEqual(args.request.method, "CONNECT")) return {
			match: {
				matches: false,
				params: {}
			},
			cookies: {}
		};
		const url = new URL(args.request.url);
		const cookies = getAllRequestCookies(args.request);
		/**
		* Handle custom predicate functions.
		* @note Invoke this during parsing so the user can parse the path parameters
		* manually. Otherwise, `params` is always an empty object, which isn't nice.
		*/
		if (typeof this.info.path === "function") {
			const customPredicateResult = await this.info.path({
				request: args.request,
				cookies
			});
			return {
				match: typeof customPredicateResult === "boolean" ? {
					matches: customPredicateResult,
					params: {}
				} : customPredicateResult,
				cookies
			};
		}
		return {
			match: this.info.path ? matchRequestUrl(url, this.info.path, args.resolutionContext?.baseUrl) : {
				matches: false,
				params: {}
			},
			cookies
		};
	}
	async predicate(args) {
		const hasMatchingMethod = this.matchMethod(args.request.method);
		const hasMatchingUrl = args.parsedResult.match.matches;
		return hasMatchingMethod && hasMatchingUrl;
	}
	matchMethod(actualMethod) {
		return this.info.method instanceof RegExp ? this.info.method.test(actualMethod) : isStringEqual(this.info.method, actualMethod);
	}
	extendResolverArgs(args) {
		return {
			params: args.parsedResult.match?.params || {},
			cookies: args.parsedResult.cookies
		};
	}
	async log(args) {
		const publicUrl = toPublicUrl(args.request.url);
		const loggedRequest = await serializeRequest(args.request);
		const loggedResponse = await serializeResponse(args.response);
		const statusColor = getStatusCodeColor(loggedResponse.status);
		console.groupCollapsed(devUtils.formatMessage(`${getTimestamp()} ${args.request.method} ${publicUrl} (%c${loggedResponse.status} ${loggedResponse.statusText}%c)`), `color:${statusColor}`, "color:inherit");
		console.log("Request", loggedRequest);
		console.log("Handler:", this);
		console.log("Response", loggedResponse);
		console.groupEnd();
	}
};
//#endregion
//#region node_modules/msw/lib/_chunks/http.js
function createHttpHandler(method) {
	return (predicate, resolver, options = {}) => {
		return new HttpHandler(method, predicate, resolver, options);
	};
}
/**
* A namespace to intercept and mock HTTP requests.
*
* @example
* http.get('/user', resolver)
* http.post('/post/:id', resolver)
*
* @see {@link https://mswjs.io/docs/api/http `http` API reference}
*/
var http = {
	all: createHttpHandler(/.+/),
	head: createHttpHandler("HEAD"),
	get: createHttpHandler("GET"),
	post: createHttpHandler("POST"),
	put: createHttpHandler("PUT"),
	delete: createHttpHandler("DELETE"),
	patch: createHttpHandler("PATCH"),
	options: createHttpHandler("OPTIONS")
};
//#endregion
//#region node_modules/msw/lib/_chunks/has-ref-counted.js
function hasRefCounted(value) {
	return isObject(value) && typeof Reflect.get(value, "ref") === "function" && typeof Reflect.get(value, "unref") === "function";
}
//#endregion
//#region node_modules/msw/lib/_chunks/websocket-upgrade.js
var WEBSOCKET_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
/**
* Response resolver for the `upgrade` requests to the WebSocket protocol.
* This requires a WebSocket handler to be present to fire.
* @note This only affects Node.js as the `upgrade` request header is
* forbidden and cannot be read in the browser. Consider using the
* `WebSocket` API for establishing WebSocket connections in the browser.
*/
async function webSocketUpgrade({ request }) {
	const key = request.headers.get("sec-websocket-key");
	if (!key) return;
	const keyBytes = new TextEncoder().encode(key + WEBSOCKET_GUID);
	const digest = await crypto.subtle.digest("SHA-1", keyBytes);
	const acceptValue = btoa(String.fromCharCode(...new Uint8Array(digest)));
	const requestedProtocols = request.headers.get("sec-websocket-protocol")?.split(",").map((protocol) => protocol.trim());
	new WebSocket(resolveWebSocketUrl(request.url), requestedProtocols);
	const headers = new Headers({
		upgrade: "websocket",
		connection: "upgrade",
		"sec-websocket-accept": acceptValue
	});
	if (requestedProtocols && requestedProtocols.length > 0) headers.set("sec-websocket-protocol", requestedProtocols[0]);
	return new FetchResponse(null, {
		status: 101,
		headers
	});
}
/**
* Creates a request handler that responds to WebSocket upgrade
* requests whose URL matches the given path.
*
* @internal
*/
function createWebSocketUpgradeHandler(url, resolver) {
	return http.get(({ request }) => {
		return request.headers.get("upgrade")?.toLowerCase() === "websocket" && matchRequestUrl(new URL(resolveWebSocketUrl(request.url)), url).matches;
	}, resolver);
}
//#endregion
//#region node_modules/msw/lib/_chunks/ws.js
var WebSocketMemoryClientStore = class {
	store;
	constructor() {
		this.store = /* @__PURE__ */ new Map();
	}
	async add(client) {
		this.store.set(client.id, {
			id: client.id,
			url: client.url.href
		});
	}
	getAll() {
		return Promise.resolve(Array.from(this.store.values()));
	}
	async deleteMany(clientIds) {
		for (const clientId of clientIds) this.store.delete(clientId);
	}
};
var DB_NAME = "msw-websocket-clients";
var DB_STORE_NAME = "clients";
var WebSocketIndexedDBClientStore = class {
	db;
	constructor() {
		this.db = this.createDatabase();
	}
	async add(client) {
		const promise = Promise.withResolvers();
		/**
		* @note Use `.put()` instead of `.add()` to allow setting clients
		* that already exist in the database. This can happen if a single page
		* has multiple event handlers. Each handler will receive the "connection"
		* event in parallel, and try to set that WebSocket client in the database.
		*/
		const request = (await this.getStore()).put({
			id: client.id,
			url: client.url.href
		});
		request.onsuccess = () => {
			promise.resolve();
		};
		request.onerror = () => {
			console.error(request.error);
			promise.reject(/* @__PURE__ */ new Error(`Failed to add WebSocket client "${client.id}". There is likely an additional output above.`));
		};
		return promise.promise;
	}
	async getAll() {
		const promise = Promise.withResolvers();
		const request = (await this.getStore()).getAll();
		request.onsuccess = () => {
			promise.resolve(request.result);
		};
		request.onerror = () => {
			console.error(request.error);
			promise.reject(/* @__PURE__ */ new Error(`Failed to get all WebSocket clients. There is likely an additional output above.`));
		};
		return promise.promise;
	}
	async deleteMany(clientIds) {
		const promise = Promise.withResolvers();
		const store = await this.getStore();
		for (const clientId of clientIds) store.delete(clientId);
		store.transaction.oncomplete = () => {
			promise.resolve();
		};
		store.transaction.onerror = () => {
			console.error(store.transaction.error);
			promise.reject(/* @__PURE__ */ new Error(`Failed to delete WebSocket clients [${clientIds.join(", ")}]. There is likely an additional output above.`));
		};
		return promise.promise;
	}
	async createDatabase() {
		const promise = Promise.withResolvers();
		const request = indexedDB.open(DB_NAME, 1);
		request.onsuccess = ({ currentTarget }) => {
			const db = Reflect.get(currentTarget, "result");
			if (db.objectStoreNames.contains(DB_STORE_NAME)) return promise.resolve(db);
		};
		request.onupgradeneeded = async ({ currentTarget }) => {
			const db = Reflect.get(currentTarget, "result");
			if (db.objectStoreNames.contains(DB_STORE_NAME)) return;
			const store = db.createObjectStore(DB_STORE_NAME, { keyPath: "id" });
			store.transaction.oncomplete = () => {
				promise.resolve(db);
			};
			store.transaction.onerror = () => {
				console.error(store.transaction.error);
				promise.reject(/* @__PURE__ */ new Error("Failed to create WebSocket client store. There is likely an additional output above."));
			};
		};
		request.onerror = () => {
			console.error(request.error);
			promise.reject(/* @__PURE__ */ new Error("Failed to open an IndexedDB database. There is likely an additional output above."));
		};
		return promise.promise;
	}
	async getStore() {
		return (await this.db).transaction(DB_STORE_NAME, "readwrite").objectStore(DB_STORE_NAME);
	}
};
/**
* A manager responsible for accumulating WebSocket client
* connections across different browser runtimes.
*/
var WebSocketClientManager = class {
	channel;
	store;
	runtimeClients;
	allClients;
	constructor(channel) {
		this.channel = channel;
		this.store = typeof indexedDB !== "undefined" ? new WebSocketIndexedDBClientStore() : new WebSocketMemoryClientStore();
		this.runtimeClients = /* @__PURE__ */ new Map();
		this.allClients = /* @__PURE__ */ new Set();
		this.channel.addEventListener("message", (message) => {
			if (message.data?.type === "db:update") this.flushDatabaseToMemory();
		});
		if (typeof window !== "undefined") window.addEventListener("message", async (message) => {
			if (message.data?.type === "msw/worker:stop") await this.removeRuntimeClients();
		});
	}
	async flushDatabaseToMemory() {
		const storedClients = await this.store.getAll();
		this.allClients = new Set(storedClients.map((client) => {
			const runtimeClient = this.runtimeClients.get(client.id);
			/**
			* @note For clients originating in this runtime, use their
			* direct references. No need to wrap them in a remote connection.
			*/
			if (runtimeClient) return runtimeClient;
			return new WebSocketRemoteClientConnection(client.id, new URL(client.url), this.channel);
		}));
	}
	async removeRuntimeClients() {
		await this.store.deleteMany(Array.from(this.runtimeClients.keys()));
		this.runtimeClients.clear();
		await this.flushDatabaseToMemory();
		this.notifyOthersAboutDatabaseUpdate();
	}
	/**
	* All active WebSocket client connections.
	*/
	get clients() {
		return this.allClients;
	}
	/**
	* Notify other runtimes about the database update
	* using the shared `BroadcastChannel` instance.
	*/
	notifyOthersAboutDatabaseUpdate() {
		this.channel.postMessage({ type: "db:update" });
	}
	async addClient(client) {
		await this.store.add(client);
		await this.flushDatabaseToMemory();
		this.notifyOthersAboutDatabaseUpdate();
	}
	/**
	* Adds the given `WebSocket` client connection to the set
	* of all connections. The given connection is always the complete
	* connection object because `addConnection()` is called only
	* for the opened connections in the same runtime.
	*/
	async addConnection(client) {
		this.runtimeClients.set(client.id, client);
		await this.addClient(client);
		const handleExtraneousMessage = (message) => {
			const { type, payload } = message.data;
			if (typeof payload === "object" && "clientId" in payload && payload.clientId !== client.id) return;
			switch (type) {
				case "extraneous:send":
					client.send(payload.data);
					break;
				case "extraneous:close": client.close(payload.code, payload.reason);
			}
		};
		const abortController = new AbortController();
		this.channel.addEventListener("message", handleExtraneousMessage, { signal: abortController.signal });
		client.addEventListener("close", () => abortController.abort(), { once: true });
	}
};
/**
* A wrapper class to operate with WebSocket client connections
* from other runtimes. This class maintains 1-1 public API
* compatibility to the `WebSocketClientConnection` but relies
* on the given `BroadcastChannel` to communicate instructions
* with the client connections from other runtimes.
*/
var WebSocketRemoteClientConnection = class {
	id;
	url;
	channel;
	constructor(id, url, channel) {
		this.id = id;
		this.url = url;
		this.channel = channel;
	}
	send(data) {
		this.channel.postMessage({
			type: "extraneous:send",
			payload: {
				clientId: this.id,
				data
			}
		});
	}
	close(code, reason) {
		this.channel.postMessage({
			type: "extraneous:close",
			payload: {
				clientId: this.id,
				code,
				reason
			}
		});
	}
	addEventListener(_type, _listener, _options) {
		throw new Error("WebSocketRemoteClientConnection.addEventListener is not supported");
	}
	removeEventListener(_event, _listener, _options) {
		throw new Error("WebSocketRemoteClientConnection.removeEventListener is not supported");
	}
};
var webSocketChannel = new BroadcastChannel("msw:websocket-client-manager");
if (hasRefCounted(webSocketChannel)) webSocketChannel.unref();
/**
* Intercepts outgoing WebSocket connections to the given URL.
*
* @example
* const chat = ws.link('wss://chat.example.com')
* chat.addEventListener('connection', ({ client }) => {
*   client.send('hello from server!')
* })
*/
function createWebSocketLinkHandler(url, options) {
	invariant(url, "Expected a WebSocket server URL but got undefined");
	invariant(isPath(url), "Expected a WebSocket server URL to be a valid path but got %s", typeof url);
	const clientManager = new WebSocketClientManager(webSocketChannel);
	const upgradeHandler = createWebSocketUpgradeHandler(url, (info) => {
		return ws.onUpgrade(info);
	});
	return {
		get clients() {
			return clientManager.clients;
		},
		addEventListener(event, listener) {
			const webSocketHandler = new WebSocketHandler(url, { extensions: options?.extensions });
			webSocketHandler[kEmitter].on("connection", async ({ client }) => {
				await clientManager.addConnection(client);
			});
			webSocketHandler[kEmitter].on(event, listener);
			return attachSiblingHandlers(webSocketHandler, [upgradeHandler]);
		},
		broadcast(data) {
			this.broadcastExcept([], data);
		},
		broadcastExcept(clients, data) {
			const ignoreClients = Array.prototype.concat(clients).map((client) => client.id);
			clientManager.clients.forEach((otherClient) => {
				if (!ignoreClients.includes(otherClient.id)) otherClient.send(data);
			});
		}
	};
}
/**
* A namespace to intercept and mock WebSocket connections.
*
* @example
* const chat = ws.link('wss://chat.example.com')
*
* @see {@link https://mswjs.io/docs/api/ws `ws` API reference}
* @see {@link https://mswjs.io/docs/basics/handling-websocket-events Handling WebSocket events}
*/
var ws = {
	link: createWebSocketLinkHandler,
	onUpgrade: webSocketUpgrade
};
//#endregion
//#region node_modules/msw/lib/utils/delay.js
var SET_TIMEOUT_MAX_ALLOWED_INT = 2147483647;
var MIN_SERVER_RESPONSE_TIME = 100;
var NODE_SERVER_RESPONSE_TIME = 5;
function getRealisticResponseTime() {
	if (isNodeProcess()) return NODE_SERVER_RESPONSE_TIME;
	return Math.floor(Math.random() * 300 + MIN_SERVER_RESPONSE_TIME);
}
/**
* Delays the response by the given duration (ms).
*
* @example
* await delay() // emulate realistic server response time
* await delay(1200) // delay response by 1200ms
* await delay('infinite') // delay response infinitely
*
* @see {@link https://mswjs.io/docs/api/delay `delay()` API reference}
*/
async function delay(durationOrMode) {
	let delayTime;
	if (typeof durationOrMode === "string") switch (durationOrMode) {
		case "infinite":
			delayTime = SET_TIMEOUT_MAX_ALLOWED_INT;
			break;
		case "real":
			delayTime = getRealisticResponseTime();
			break;
		default: throw new Error(`Failed to delay a response: unknown delay mode "${durationOrMode}". Please make sure you provide one of the supported modes ("real", "infinite") or a number.`);
	}
	else if (typeof durationOrMode === "undefined") delayTime = getRealisticResponseTime();
	else {
		if (durationOrMode > SET_TIMEOUT_MAX_ALLOWED_INT) throw new Error(`Failed to delay a response: provided delay duration (${durationOrMode}) exceeds the maximum allowed duration for "setTimeout" (${SET_TIMEOUT_MAX_ALLOWED_INT}). This will cause the response to be returned immediately. Please use a number within the allowed range to delay the response by exact duration, or consider the "infinite" delay mode to delay the response indefinitely.`);
		delayTime = durationOrMode;
	}
	return new Promise((resolve) => {
		const timeoutId = setTimeout(resolve, delayTime);
		if (delayTime === SET_TIMEOUT_MAX_ALLOWED_INT && isNodeProcess() && hasRefCounted(timeoutId)) timeoutId.unref();
	});
}
//#endregion
//#region node_modules/msw/lib/_chunks/sse.js
/**
* Intercept Server-Sent Events (SSE).
*
* @example
* sse('http://localhost:4321', ({ client }) => {
*   client.send({ data: 'hello world' })
* })
*
* @see {@link https://mswjs.io/docs/sse/ Mocking Server-Sent Events}
* @see {@link https://mswjs.io/docs/api/sse `sse()` API reference}
*/
var sse = (path, resolver) => {
	return new ServerSentEventHandler(path, resolver);
};
var SSE_RESPONSE_INIT = { headers: {
	"content-type": "text/event-stream",
	"cache-control": "no-cache",
	connection: "keep-alive"
} };
var ServerSentEventHandler = class extends HttpHandler {
	#loggableRequests;
	constructor(path, resolver) {
		invariant(typeof EventSource !== "undefined", "Failed to construct a Server-Sent Event handler for path \"%s\": the EventSource API is not supported in this environment", path);
		super("GET", path, async (info) => {
			const { client, server, response } = createEventStream(info.request);
			/**
			* @note Scope the emitter to this connection so its logging
			* listeners don't accumulate on the handler across connections.
			*/
			const emitter = new Emitter();
			client[kClientEmitter] = emitter;
			if (this.#loggableRequests.has(info.request)) this.#attachClientLogger(info.request, emitter);
			/**
			* @note Extend the resolver info via assignment instead of a spread.
			* Spreading the info would invoke its lazy `finalize` getter,
			* initializing the finalize machinery for resolvers that never use it.
			*/
			await resolver(Object.assign(info, {
				client,
				server
			}));
			return response;
		});
		this.#loggableRequests = /* @__PURE__ */ new WeakSet();
	}
	async predicate(args) {
		if (args.request.headers.get("accept") !== "text/event-stream") return false;
		const matches = await super.predicate(args);
		if (matches && !args.resolutionContext?.quiet) {
			/**
			* @note Log the intercepted request early.
			* Normally, the `this.log()` method is called when the handler returns a response.
			* For SSE, call that method earlier so the logs are in correct order.
			*/
			await super.log({
				request: args.request,
				/**
				* @note Construct a placeholder response since SSE response
				* is being streamed and cannot be cloned/consumed for logging.
				*/
				response: new Response("[streaming]", SSE_RESPONSE_INIT)
			});
			this.#loggableRequests.add(args.request);
		}
		return matches;
	}
	async log(args) {
		/**
		* @note Cancel the response stream because it's not needed for logging.
		* Otherwise, this cloned response remains unconsumed and its original
		* doesn't propagate stream cancelations at all.
		*/
		args.response.body?.cancel();
	}
	#attachClientLogger(request, emitter) {
		const publicUrl = toPublicUrl(request.url);
		emitter.on("message", ({ data }) => {
			console.groupCollapsed(devUtils.formatMessage(`${getTimestamp()} SSE %s %c⇣%c ${data.event}`), publicUrl, `color:${colors.mocked}`, "color:inherit");
			console.log(data.frames);
			console.groupEnd();
		});
		emitter.on("error", () => {
			console.groupCollapsed(devUtils.formatMessage(`${getTimestamp()} SSE %s %c\u00D7%c error`), publicUrl, `color: ${colors.system}`, "color:inherit");
			console.log("Handler:", this);
			console.groupEnd();
		});
		emitter.on("close", () => {
			console.groupCollapsed(devUtils.formatMessage(`${getTimestamp()} SSE %s %c■%c close`), publicUrl, `colors:${colors.system}`, "color:inherit");
			console.log("Handler:", this);
			console.groupEnd();
		});
	}
};
var kClientEmitter = Symbol.for("kClientEmitter");
var ServerSentEventClient = class {
	[kClientEmitter];
	#encoder;
	#controller;
	#closed;
	#isClosed;
	constructor(controller) {
		this.#encoder = new TextEncoder();
		this.#controller = controller;
		this.#closed = Promise.withResolvers();
		this.#isClosed = false;
	}
	/**
	* Sends the given payload to the intercepted `EventSource`.
	*/
	send(payload) {
		if ("retry" in payload && payload.retry != null) {
			this.#sendRetry(payload.retry);
			return;
		}
		this.#sendMessage({
			id: payload.id,
			event: payload.event,
			data: typeof payload.data === "object" ? JSON.stringify(payload.data) : payload.data
		});
	}
	/**
	* Dispatches the given event on the intercepted `EventSource`.
	*/
	dispatchEvent(event) {
		if (event instanceof MessageEvent) {
			/**
			* @note Use the internal send mechanism to skip normalization
			* of the message data (already normalized by the server).
			*/
			this.#sendMessage({
				id: event.lastEventId || void 0,
				event: event.type === "message" ? void 0 : event.type,
				data: event.data
			});
			return;
		}
		if (event.type === "error") {
			this.error();
			return;
		}
		if (event.type === "close") {
			this.close();
			return;
		}
	}
	/**
	* Errors the underlying `EventSource`, closing the connection with an error.
	* This is equivalent to aborting the connection and will produce a `TypeError: Failed to fetch`
	* error.
	*/
	error() {
		if (this.#isClosed) return;
		this.#controller.error();
		this.#isClosed = true;
		this.#closed.resolve();
		this[kClientEmitter]?.emit(new TypedEvent("error"));
	}
	/**
	* Closes the underlying `EventSource`, closing the connection.
	*/
	close() {
		if (this.#isClosed) return;
		try {
			this.#controller.close();
			this.#isClosed = true;
			this.#closed.resolve();
		} catch {}
		this[kClientEmitter]?.emit(new TypedEvent("close"));
	}
	#enqueue(chunk) {
		if (this.#isClosed) return;
		try {
			this.#controller.enqueue(chunk);
		} catch (error) {
			console.error(error);
			devUtils.error("Failed to write to server-side EventSource. Please see the original error above.");
		}
	}
	#sendRetry(retry) {
		this.#enqueue(this.#encoder.encode(`retry:${retry}\n\n`));
	}
	#sendMessage(message) {
		const frames = [];
		if (message.id) frames.push(`id:${message.id}`);
		if (message.event) frames.push(`event:${message.event.toString()}`);
		if (message.data != null)
 /**
		* Split data on line terminators (LF, CR, or CRLF) and translate them to individual frames.
		* @see https://html.spec.whatwg.org/multipage/server-sent-events.html#event-stream-interpretation
		* @see https://html.spec.whatwg.org/multipage/server-sent-events.html#parsing-an-event-stream
		*/
		for (const line of message.data.toString().split(/\r\n|\r|\n/)) frames.push(`data:${line}`);
		frames.push("", "");
		this.#enqueue(this.#encoder.encode(frames.join("\n")));
		this[kClientEmitter]?.emit(new TypedEvent("message", { data: {
			id: message.id,
			event: message.event?.toString() || "message",
			data: message.data,
			frames
		} }));
	}
};
var ServerSentEventServer = class {
	#request;
	#client;
	constructor(args) {
		this.#request = args.request;
		this.#client = args.client;
	}
	/**
	* Establishes the actual connection for this SSE request
	* and returns the `EventSource` instance.
	*/
	connect() {
		const source = new ObservableEventSource(this.#request.url, {
			withCredentials: this.#request.credentials === "include",
			headers: { 
			/**
			* @note Mark this request as passthrough so it doesn't trigger
			* an infinite loop matching against the existing request handler.
			*/
accept: "msw/passthrough" },
			signal: this.#request.signal
		});
		source[kOnAnyMessage] = (event) => {
			Object.defineProperties(event, { target: {
				value: this,
				enumerable: true,
				writable: true,
				configurable: true
			} });
			queueMicrotask(() => {
				if (!event.defaultPrevented) this.#client.dispatchEvent(event);
			});
		};
		source.addEventListener("error", (event) => {
			Object.defineProperties(event, { target: {
				value: this,
				enumerable: true,
				writable: true,
				configurable: true
			} });
			queueMicrotask(() => {
				if (!event.defaultPrevented) this.#client.dispatchEvent(event);
			});
		});
		return source;
	}
};
var kRequest = Symbol("kRequest");
var kReconnectionTime = Symbol("kReconnectionTime");
var kLastEventId = Symbol("kLastEventId");
var kAbortController = Symbol("kAbortController");
var kOnOpen = Symbol("kOnOpen");
var kOnMessage = Symbol("kOnMessage");
var kOnAnyMessage = Symbol("kOnAnyMessage");
var kOnError = Symbol("kOnError");
var ObservableEventSource = class ObservableEventSource extends EventTarget {
	static CONNECTING = 0;
	static OPEN = 1;
	static CLOSED = 2;
	CONNECTING = ObservableEventSource.CONNECTING;
	OPEN = ObservableEventSource.OPEN;
	CLOSED = ObservableEventSource.CLOSED;
	readyState;
	url;
	withCredentials;
	[kRequest];
	[kReconnectionTime];
	[kLastEventId];
	[kAbortController];
	[kOnOpen] = null;
	[kOnMessage] = null;
	[kOnAnyMessage] = null;
	[kOnError] = null;
	constructor(url, init) {
		super();
		this.url = new URL(url).href;
		this.withCredentials = init?.withCredentials ?? false;
		this.readyState = this.CONNECTING;
		const headers = new Headers(init?.headers || {});
		headers.append("accept", "text/event-stream");
		this[kAbortController] = new AbortController();
		this[kReconnectionTime] = 2e3;
		this[kLastEventId] = "";
		this[kRequest] = new Request(this.url, {
			method: "GET",
			headers,
			credentials: this.withCredentials ? "include" : "omit",
			signal: this[kAbortController].signal
		});
		if (init?.signal) {
			if (init.signal.aborted) {
				this.close();
				return;
			}
			init.signal.addEventListener("abort", () => this.close(), {
				once: true,
				signal: this[kAbortController].signal
			});
		}
		this.connect();
	}
	get onopen() {
		return this[kOnOpen];
	}
	set onopen(handler) {
		if (this[kOnOpen]) this.removeEventListener("open", this[kOnOpen]);
		this[kOnOpen] = handler.bind(this);
		this.addEventListener("open", this[kOnOpen]);
	}
	get onmessage() {
		return this[kOnMessage];
	}
	set onmessage(handler) {
		if (this[kOnMessage]) this.removeEventListener("message", { handleEvent: this[kOnMessage] });
		this[kOnMessage] = handler.bind(this);
		this.addEventListener("message", { handleEvent: this[kOnMessage] });
	}
	get onerror() {
		return this[kOnError];
	}
	set onerror(handler) {
		if (this[kOnError]) this.removeEventListener("error", { handleEvent: this[kOnError] });
		this[kOnError] = handler.bind(this);
		this.addEventListener("error", { handleEvent: this[kOnError] });
	}
	addEventListener(type, listener, options) {
		super.addEventListener(type, listener, options);
	}
	removeEventListener(type, listener, options) {
		super.removeEventListener(type, listener, options);
	}
	dispatchEvent(event) {
		return super.dispatchEvent(event);
	}
	close() {
		this[kAbortController].abort();
		this.readyState = this.CLOSED;
	}
	async connect() {
		await fetch(this[kRequest]).then((response) => {
			this.processResponse(response);
		}).catch(() => {
			this.failConnection();
		});
	}
	processResponse(response) {
		if (!response.body) {
			this.failConnection();
			return;
		}
		if (isNetworkError(response)) {
			this.reestablishConnection();
			return;
		}
		if (response.status !== 200 || response.headers.get("content-type") !== "text/event-stream") {
			this.failConnection();
			return;
		}
		this.announceConnection();
		this.interpretResponseBody(response);
	}
	announceConnection() {
		queueMicrotask(() => {
			if (this.readyState !== this.CLOSED) {
				this.readyState = this.OPEN;
				this.dispatchEvent(new Event("open"));
			}
		});
	}
	interpretResponseBody(response) {
		const parsingStream = new EventSourceParsingStream({
			message: (message) => {
				if (message.id) this[kLastEventId] = message.id;
				const messageEvent = new MessageEvent(message.event ? message.event : "message", {
					data: message.data,
					origin: this[kRequest].url,
					lastEventId: this[kLastEventId],
					cancelable: true
				});
				this[kOnAnyMessage]?.(messageEvent);
				this.dispatchEvent(messageEvent);
			},
			retry: (reconnectionTime) => {
				this[kReconnectionTime] = reconnectionTime;
			},
			abort: () => {
				throw new Error("Stream abort is not implemented");
			},
			close: () => {
				this.failConnection();
			}
		});
		response.body.pipeTo(parsingStream).then(() => {
			this.processResponseEndOfBody(response);
		}).catch(() => {
			this.failConnection();
		});
	}
	processResponseEndOfBody(response) {
		if (!isNetworkError(response)) this.reestablishConnection();
	}
	async reestablishConnection() {
		queueMicrotask(() => {
			if (this.readyState === this.CLOSED) return;
			this.readyState = this.CONNECTING;
			this.dispatchEvent(new Event("error"));
		});
		const signal = this[kAbortController].signal;
		if (signal.aborted) return;
		const aborted = Promise.withResolvers();
		const onAbort = () => aborted.resolve();
		signal.addEventListener("abort", onAbort, { once: true });
		await Promise.race([delay(this[kReconnectionTime]), aborted.promise]).finally(() => {
			signal.removeEventListener("abort", onAbort);
		});
		if (signal.aborted) return;
		queueMicrotask(async () => {
			if (this.readyState !== this.CONNECTING) return;
			if (this[kLastEventId] !== "") this[kRequest].headers.set("last-event-id", this[kLastEventId]);
			await this.connect();
		});
	}
	failConnection() {
		queueMicrotask(() => {
			if (this.readyState !== this.CLOSED) {
				this.readyState = this.CLOSED;
				this.dispatchEvent(new Event("error"));
			}
		});
	}
};
/**
* Checks if the given `Response` instance is a network error.
* @see https://fetch.spec.whatwg.org/#concept-network-error
*/
function isNetworkError(response) {
	return response.type === "error" && response.status === 0 && response.statusText === "" && Array.from(response.headers.entries()).length === 0 && response.body === null;
}
var EventSourceParsingStream = class extends WritableStream {
	underlyingSink;
	decoder;
	buffer;
	position;
	fieldLength;
	discardTrailingNewline = false;
	message = {
		id: void 0,
		event: void 0,
		data: void 0
	};
	constructor(underlyingSink) {
		super({
			write: (chunk) => {
				this.processResponseBodyChunk(chunk);
			},
			abort: (reason) => {
				this.underlyingSink.abort?.(reason);
			},
			close: () => {
				this.underlyingSink.close?.();
			}
		});
		this.underlyingSink = underlyingSink;
		this.decoder = new TextDecoder();
		this.position = 0;
	}
	resetMessage() {
		this.message = {
			id: void 0,
			event: void 0,
			data: void 0
		};
	}
	processResponseBodyChunk(chunk) {
		if (this.buffer == null) {
			this.buffer = chunk;
			this.position = 0;
			this.fieldLength = -1;
		} else {
			const nextBuffer = new Uint8Array(this.buffer.length + chunk.length);
			nextBuffer.set(this.buffer);
			nextBuffer.set(chunk, this.buffer.length);
			this.buffer = nextBuffer;
		}
		const bufferLength = this.buffer.length;
		let lineStart = 0;
		while (this.position < bufferLength) {
			if (this.discardTrailingNewline) {
				if (this.buffer[this.position] === 10) lineStart = ++this.position;
				this.discardTrailingNewline = false;
			}
			let lineEnd = -1;
			for (; this.position < bufferLength && lineEnd === -1; ++this.position) switch (this.buffer[this.position]) {
				case 58:
					if (this.fieldLength === -1) this.fieldLength = this.position - lineStart;
					break;
				case 13:
					this.discardTrailingNewline = true;
					break;
				case 10: lineEnd = this.position;
			}
			if (lineEnd === -1) break;
			this.processLine(this.buffer.subarray(lineStart, lineEnd), this.fieldLength);
			lineStart = this.position;
			this.fieldLength = -1;
		}
		if (lineStart === bufferLength) this.buffer = void 0;
		else if (lineStart !== 0) {
			this.buffer = this.buffer.subarray(lineStart);
			this.position -= lineStart;
		}
	}
	processLine(line, fieldLength) {
		if (line.length === 0) {
			if (this.message.data === void 0) {
				this.message.event = void 0;
				return;
			}
			this.underlyingSink.message(this.message);
			this.resetMessage();
			return;
		}
		if (fieldLength > 0) {
			const field = this.decoder.decode(line.subarray(0, fieldLength));
			const valueOffset = fieldLength + (line[fieldLength + 1] === 32 ? 2 : 1);
			const value = this.decoder.decode(line.subarray(valueOffset));
			switch (field) {
				case "data":
					this.message.data = this.message.data ? this.message.data + "\n" + value : value;
					break;
				case "event":
					this.message.event = value;
					break;
				case "id":
					this.message.id = value;
					break;
				case "retry":
 /**
				* Apply the retry immediately. Don't buffer onto the current message.
				* @see https://html.spec.whatwg.org/multipage/server-sent-events.html#event-stream-interpretation
				*/
				if (/^\d+$/.test(value)) this.underlyingSink.retry?.(parseInt(value, 10));
			}
		}
	}
};
/**
* Create an event stream out of the given Fetch API `Request`.
* Returns the following properties:
* - `client`, to operate on the intercepted request;
* - `server`, to establish and manage the actual server connection;
* - `response`, a `Response` to use as the mock response's body.
*
* @example
* http.post('/resource', ({ request }) => {
*   const { client, server, response } = createEventStream(request)
*   client.send({ data: 'hello world' })
*   return response
* })
*/
function createEventStream(request) {
	invariant(!request.signal.aborted, "Failed to call \"createEventStream\" on the \"%s %s\" request: request aborted", request.method, request.url);
	let controller;
	const readable = new ReadableStream({
		start(defaultController) {
			controller = defaultController;
		},
		cancel() {
			client.close();
		}
	});
	const client = new ServerSentEventClient(controller);
	const server = new ServerSentEventServer({
		request,
		client
	});
	const response = new Response(readable, SSE_RESPONSE_INIT);
	request.signal.addEventListener("abort", () => {
		client.close();
	}, { once: true });
	return {
		client,
		server,
		response
	};
}
//#endregion
//#region node_modules/msw/lib/utils/get-response.js
/**
* Finds a response for the given request instance
* in the array of request handlers.
* @param handlers The array of request handlers.
* @param request The `Request` instance.
* @param resolutionContext Request resolution options.
* @returns {Response} A mocked response, if any.
*/
var getResponse = async (handlers, request, resolutionContext) => {
	return (await executeHandlers({
		request,
		requestId: createRequestId(),
		handlers,
		resolutionContext
	}))?.response;
};
//#endregion
//#region node_modules/msw/lib/utils/bypass.js
/**
* Creates a `Request` instance that will always be ignored by MSW.
*
* @example
* import { bypass } from 'msw'
*
* fetch(bypass('/resource'))
* fetch(bypass(new URL('/resource', 'https://example.com)))
* fetch(bypass(new Request('https://example.com/resource')))
*
* @see {@link https://mswjs.io/docs/api/bypass `bypass()` API reference}
*/
function bypass(input, init) {
	const request = new Request(input instanceof Request ? input.clone() : input, init);
	invariant(!request.bodyUsed, "Failed to create a bypassed request to \"%s %s\": given request instance already has its body read. Make sure to clone the intercepted request if you wish to read its body before bypassing it.", request.method, request.url);
	const requestClone = request.clone();
	/**
	* Send the internal request header that would instruct MSW
	* to perform this request as-is, ignoring any matching handlers.
	* @note Use the `accept` header to support scenarios when the
	* request cannot have headers (e.g. `sendBeacon` requests).
	*/
	requestClone.headers.append("accept", "msw/passthrough");
	/**
	* Delete the "content-length" request header.
	* Intercepted requests are parsed from the wire and include the
	* received "content-length" header. If the consumer derives a new
	* request with a different body (e.g. `new Request(request, { body })`),
	* that header becomes stale and the request client will reject the
	* bypassed request due to the content length mismatch. The request
	* client always re-computes this header from the actual request body.
	*/
	requestClone.headers.delete("content-length");
	return requestClone;
}
//#endregion
export { HttpHandler, HttpMethods, HttpResponse, RequestHandler, WebSocketConnectionEvent, WebSocketHandler, bypass, delay, getCleanUrlString, getResponse, http, isCommonAssetRequest, isPassthroughResponse, matchRequestUrl, passthrough, sse, ws };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXN3LmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL2Nvb2tpZS9kaXN0L2luZGV4LmpzIiwiLi4vLi4vbXN3L2xpYi9fY2h1bmtzL2h0dHAtaGFuZGxlci5qcyIsIi4uLy4uL21zdy9saWIvX2NodW5rcy9odHRwLmpzIiwiLi4vLi4vbXN3L2xpYi9fY2h1bmtzL2hhcy1yZWYtY291bnRlZC5qcyIsIi4uLy4uL21zdy9saWIvX2NodW5rcy93ZWJzb2NrZXQtdXBncmFkZS5qcyIsIi4uLy4uL21zdy9saWIvX2NodW5rcy93cy5qcyIsIi4uLy4uL21zdy9saWIvdXRpbHMvZGVsYXkuanMiLCIuLi8uLi9tc3cvbGliL19jaHVua3Mvc3NlLmpzIiwiLi4vLi4vbXN3L2xpYi91dGlscy9nZXQtcmVzcG9uc2UuanMiLCIuLi8uLi9tc3cvbGliL3V0aWxzL2J5cGFzcy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFJlZ0V4cCB0byBtYXRjaCBjb29raWUtbmFtZSBpbiBSRkMgNjI2NSBzZWMgNC4xLjFcbiAqIFRoaXMgcmVmZXJzIG91dCB0byB0aGUgb2Jzb2xldGVkIGRlZmluaXRpb24gb2YgdG9rZW4gaW4gUkZDIDI2MTYgc2VjIDIuMlxuICogd2hpY2ggaGFzIGJlZW4gcmVwbGFjZWQgYnkgdGhlIHRva2VuIGRlZmluaXRpb24gaW4gUkZDIDcyMzAgYXBwZW5kaXggQi5cbiAqXG4gKiBjb29raWUtbmFtZSAgICAgICA9IHRva2VuXG4gKiB0b2tlbiAgICAgICAgICAgICA9IDEqdGNoYXJcbiAqIHRjaGFyICAgICAgICAgICAgID0gXCIhXCIgLyBcIiNcIiAvIFwiJFwiIC8gXCIlXCIgLyBcIiZcIiAvIFwiJ1wiIC9cbiAqICAgICAgICAgICAgICAgICAgICAgXCIqXCIgLyBcIitcIiAvIFwiLVwiIC8gXCIuXCIgLyBcIl5cIiAvIFwiX1wiIC9cbiAqICAgICAgICAgICAgICAgICAgICAgXCJgXCIgLyBcInxcIiAvIFwiflwiIC8gRElHSVQgLyBBTFBIQVxuICpcbiAqIE5vdGU6IEFsbG93aW5nIG1vcmUgY2hhcmFjdGVycyAtIGh0dHBzOi8vZ2l0aHViLmNvbS9qc2h0dHAvY29va2llL2lzc3Vlcy8xOTFcbiAqIEFsbG93IHNhbWUgcmFuZ2UgYXMgY29va2llIHZhbHVlLCBleGNlcHQgYD1gLCB3aGljaCBkZWxpbWl0cyBlbmQgb2YgbmFtZS5cbiAqL1xuY29uc3QgY29va2llTmFtZVJlZ0V4cCA9IC9eW1xcdTAwMjEtXFx1MDAzQVxcdTAwM0NcXHUwMDNFLVxcdTAwN0VdKyQvO1xuLyoqXG4gKiBSZWdFeHAgdG8gbWF0Y2ggY29va2llLXZhbHVlIGluIFJGQyA2MjY1IHNlYyA0LjEuMVxuICpcbiAqIGNvb2tpZS12YWx1ZSAgICAgID0gKmNvb2tpZS1vY3RldCAvICggRFFVT1RFICpjb29raWUtb2N0ZXQgRFFVT1RFIClcbiAqIGNvb2tpZS1vY3RldCAgICAgID0gJXgyMSAvICV4MjMtMkIgLyAleDJELTNBIC8gJXgzQy01QiAvICV4NUQtN0VcbiAqICAgICAgICAgICAgICAgICAgICAgOyBVUy1BU0NJSSBjaGFyYWN0ZXJzIGV4Y2x1ZGluZyBDVExzLFxuICogICAgICAgICAgICAgICAgICAgICA7IHdoaXRlc3BhY2UgRFFVT1RFLCBjb21tYSwgc2VtaWNvbG9uLFxuICogICAgICAgICAgICAgICAgICAgICA7IGFuZCBiYWNrc2xhc2hcbiAqXG4gKiBBbGxvd2luZyBtb3JlIGNoYXJhY3RlcnM6IGh0dHBzOi8vZ2l0aHViLmNvbS9qc2h0dHAvY29va2llL2lzc3Vlcy8xOTFcbiAqIENvbW1hLCBiYWNrc2xhc2gsIGFuZCBEUVVPVEUgYXJlIG5vdCBwYXJ0IG9mIHRoZSBwYXJzaW5nIGFsZ29yaXRobS5cbiAqL1xuY29uc3QgY29va2llVmFsdWVSZWdFeHAgPSAvXltcXHUwMDIxLVxcdTAwM0FcXHUwMDNDLVxcdTAwN0VdKiQvO1xuLyoqXG4gKiBSZWdFeHAgdG8gbWF0Y2ggZG9tYWluLXZhbHVlIGluIFJGQyA2MjY1IHNlYyA0LjEuMVxuICpcbiAqIGRvbWFpbi12YWx1ZSAgICAgID0gPHN1YmRvbWFpbj5cbiAqICAgICAgICAgICAgICAgICAgICAgOyBkZWZpbmVkIGluIFtSRkMxMDM0XSwgU2VjdGlvbiAzLjUsIGFzXG4gKiAgICAgICAgICAgICAgICAgICAgIDsgZW5oYW5jZWQgYnkgW1JGQzExMjNdLCBTZWN0aW9uIDIuMVxuICogPHN1YmRvbWFpbj4gICAgICAgPSA8bGFiZWw+IHwgPHN1YmRvbWFpbj4gXCIuXCIgPGxhYmVsPlxuICogPGxhYmVsPiAgICAgICAgICAgPSA8bGV0LWRpZz4gWyBbIDxsZGgtc3RyPiBdIDxsZXQtZGlnPiBdXG4gKiAgICAgICAgICAgICAgICAgICAgIExhYmVscyBtdXN0IGJlIDYzIGNoYXJhY3RlcnMgb3IgbGVzcy5cbiAqICAgICAgICAgICAgICAgICAgICAgJ2xldC1kaWcnIG5vdCAnbGV0dGVyJyBpbiB0aGUgZmlyc3QgY2hhciwgcGVyIFJGQzExMjNcbiAqIDxsZGgtc3RyPiAgICAgICAgID0gPGxldC1kaWctaHlwPiB8IDxsZXQtZGlnLWh5cD4gPGxkaC1zdHI+XG4gKiA8bGV0LWRpZy1oeXA+ICAgICA9IDxsZXQtZGlnPiB8IFwiLVwiXG4gKiA8bGV0LWRpZz4gICAgICAgICA9IDxsZXR0ZXI+IHwgPGRpZ2l0PlxuICogPGxldHRlcj4gICAgICAgICAgPSBhbnkgb25lIG9mIHRoZSA1MiBhbHBoYWJldGljIGNoYXJhY3RlcnMgQSB0aHJvdWdoIFogaW5cbiAqICAgICAgICAgICAgICAgICAgICAgdXBwZXIgY2FzZSBhbmQgYSB0aHJvdWdoIHogaW4gbG93ZXIgY2FzZVxuICogPGRpZ2l0PiAgICAgICAgICAgPSBhbnkgb25lIG9mIHRoZSB0ZW4gZGlnaXRzIDAgdGhyb3VnaCA5XG4gKlxuICogS2VlcCBzdXBwb3J0IGZvciBsZWFkaW5nIGRvdDogaHR0cHM6Ly9naXRodWIuY29tL2pzaHR0cC9jb29raWUvaXNzdWVzLzE3M1xuICpcbiAqID4gKE5vdGUgdGhhdCBhIGxlYWRpbmcgJXgyRSAoXCIuXCIpLCBpZiBwcmVzZW50LCBpcyBpZ25vcmVkIGV2ZW4gdGhvdWdoIHRoYXRcbiAqIGNoYXJhY3RlciBpcyBub3QgcGVybWl0dGVkLCBidXQgYSB0cmFpbGluZyAleDJFIChcIi5cIiksIGlmIHByZXNlbnQsIHdpbGxcbiAqIGNhdXNlIHRoZSB1c2VyIGFnZW50IHRvIGlnbm9yZSB0aGUgYXR0cmlidXRlLilcbiAqL1xuY29uc3QgZG9tYWluVmFsdWVSZWdFeHAgPSAvXihbLl0/W2EtejAtOV0oW2EtejAtOS1dezAsNjF9W2EtejAtOV0pPykoWy5dW2EtejAtOV0oW2EtejAtOS1dezAsNjF9W2EtejAtOV0pPykqJC9pO1xuLyoqXG4gKiBSZWdFeHAgdG8gbWF0Y2ggcGF0aC12YWx1ZSBpbiBSRkMgNjI2NSBzZWMgNC4xLjFcbiAqXG4gKiBwYXRoLXZhbHVlICAgICAgICA9IDxhbnkgQ0hBUiBleGNlcHQgQ1RMcyBvciBcIjtcIj5cbiAqIENIQVIgICAgICAgICAgICAgID0gJXgwMS03RlxuICogICAgICAgICAgICAgICAgICAgICA7IGRlZmluZWQgaW4gUkZDIDUyMzQgYXBwZW5kaXggQi4xXG4gKi9cbmNvbnN0IHBhdGhWYWx1ZVJlZ0V4cCA9IC9eW1xcdTAwMjAtXFx1MDAzQVxcdTAwM0QtXFx1MDA3RV0qJC87XG4vKipcbiAqIFJlZ0V4cCB0byBtYXRjaCBtYXgtYWdlLXZhbHVlIGluIFJGQyA2MjY1IHNlYyA1LjYuMlxuICovXG5jb25zdCBtYXhBZ2VSZWdFeHAgPSAvXi0/XFxkKyQvO1xuLyoqXG4gKiBSZWdFeHAgdG8gbWF0Y2ggUkZDIDYyNjUgY29va2llLW9jdGV0IHZhbHVlcyAod2l0aG91dCAlIHRvIHByZXNlcnZlIHJvdW5kdHJpcCkgdGhhdCBuZWVkIG5vIFVSTCBlbmNvZGluZy5cbiAqL1xuY29uc3QgY29va2llT2N0ZXRSZWdFeHAgPSAvXlshIyQmJygpKitcXC0uXFwvMC05Ojw9Pj9AQS1aW1xcXVxcXl9gYS16e3x9fl0qJC87XG5jb25zdCBOdWxsT2JqZWN0ID0gLyogQF9fUFVSRV9fICovICgoKSA9PiB7XG4gICAgY29uc3QgQyA9IGZ1bmN0aW9uICgpIHsgfTtcbiAgICBDLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgcmV0dXJuIEM7XG59KSgpO1xuLyoqXG4gKiBQYXJzZSBhIGBDb29raWVgIGhlYWRlci5cbiAqXG4gKiBQYXJzZSB0aGUgZ2l2ZW4gY29va2llIGhlYWRlciBzdHJpbmcgaW50byBhbiBvYmplY3RcbiAqIFRoZSBvYmplY3QgaGFzIHRoZSB2YXJpb3VzIGNvb2tpZXMgYXMga2V5cyhuYW1lcykgPT4gdmFsdWVzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUNvb2tpZShzdHIsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBvYmogPSBuZXcgTnVsbE9iamVjdCgpO1xuICAgIGNvbnN0IGxlbiA9IHN0ci5sZW5ndGg7XG4gICAgLy8gUkZDIDYyNjUgc2VjIDQuMS4xLCBSRkMgMjYxNiAyLjIgZGVmaW5lcyBhIGNvb2tpZSBuYW1lIGNvbnNpc3RzIG9mIG9uZSBjaGFyIG1pbmltdW0sIHBsdXMgJz0nLlxuICAgIGlmIChsZW4gPCAyKVxuICAgICAgICByZXR1cm4gb2JqO1xuICAgIGNvbnN0IGRlYyA9IG9wdGlvbnM/LmRlY29kZSB8fCBkZWNvZGU7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBkbyB7XG4gICAgICAgIGNvbnN0IGVxSWR4ID0gZXFJbmRleChzdHIsIGluZGV4LCBsZW4pO1xuICAgICAgICBpZiAoZXFJZHggPT09IGxlbilcbiAgICAgICAgICAgIGJyZWFrOyAvLyBObyBtb3JlIGNvb2tpZSBwYWlycy5cbiAgICAgICAgY29uc3QgZW5kSWR4ID0gZW5kSW5kZXgoc3RyLCBpbmRleCwgbGVuKTtcbiAgICAgICAgaWYgKGVxSWR4ID4gZW5kSWR4KSB7XG4gICAgICAgICAgICAvLyBiYWNrdHJhY2sgb24gcHJpb3Igc2VtaWNvbG9uXG4gICAgICAgICAgICBpbmRleCA9IHN0ci5sYXN0SW5kZXhPZihcIjtcIiwgZXFJZHggLSAxKSArIDE7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBrZXkgPSB2YWx1ZVNsaWNlKHN0ciwgaW5kZXgsIGVxSWR4KTtcbiAgICAgICAgLy8gb25seSBhc3NpZ24gb25jZVxuICAgICAgICBpZiAob2JqW2tleV0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgb2JqW2tleV0gPSBkZWModmFsdWVTbGljZShzdHIsIGVxSWR4ICsgMSwgZW5kSWR4KSk7XG4gICAgICAgIH1cbiAgICAgICAgaW5kZXggPSBlbmRJZHggKyAxO1xuICAgIH0gd2hpbGUgKGluZGV4IDwgbGVuKTtcbiAgICByZXR1cm4gb2JqO1xufVxuLyoqXG4gKiBTdHJpbmdpZmllcyBhbiBvYmplY3QgaW50byBhbiBIVFRQIGBDb29raWVgIGhlYWRlci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHN0cmluZ2lmeUNvb2tpZShjb29raWUsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBlbmMgPSBvcHRpb25zPy5lbmNvZGUgfHwgZGVmYXVsdEVuY29kZTtcbiAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoY29va2llKTtcbiAgICBsZXQgc3RyID0gXCJcIjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgbmFtZSA9IGtleXNbaV07XG4gICAgICAgIGNvbnN0IHZhbCA9IGNvb2tpZVtuYW1lXTtcbiAgICAgICAgaWYgKHZhbCA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIGlmICghY29va2llTmFtZVJlZ0V4cC50ZXN0KG5hbWUpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBjb29raWUgbmFtZSBpcyBpbnZhbGlkOiAke25hbWV9YCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdmFsdWUgPSBlbmModmFsKTtcbiAgICAgICAgaWYgKCFjb29raWVWYWx1ZVJlZ0V4cC50ZXN0KHZhbHVlKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgY29va2llIHZhbCBpcyBpbnZhbGlkOiAke3ZhbH1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RyKVxuICAgICAgICAgICAgc3RyICs9IFwiOyBcIjtcbiAgICAgICAgc3RyICs9IG5hbWUgKyBcIj1cIiArIHZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gc3RyO1xufVxuLyoqXG4gKiBTZXJpYWxpemUgZGF0YSBpbnRvIGEgY29va2llIGhlYWRlci5cbiAqXG4gKiBTZXJpYWxpemUgYSBuYW1lIHZhbHVlIHBhaXIgaW50byBhIGNvb2tpZSBzdHJpbmcgc3VpdGFibGUgZm9yXG4gKiBodHRwIGhlYWRlcnMuIEFuIG9wdGlvbmFsIG9wdGlvbnMgb2JqZWN0IHNwZWNpZmllcyBjb29raWUgcGFyYW1ldGVycy5cbiAqXG4gKiBzdHJpbmdpZnlTZXRDb29raWUoeyBuYW1lOiAnZm9vJywgdmFsdWU6ICdiYXInLCBodHRwT25seTogdHJ1ZSB9KVxuICogICA9PiBcImZvbz1iYXI7IEh0dHBPbmx5XCJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHN0cmluZ2lmeVNldENvb2tpZShjb29raWUsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBlbmMgPSBvcHRpb25zPy5lbmNvZGUgfHwgZGVmYXVsdEVuY29kZTtcbiAgICBpZiAoIWNvb2tpZU5hbWVSZWdFeHAudGVzdChjb29raWUubmFtZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgYXJndW1lbnQgbmFtZSBpcyBpbnZhbGlkOiAke2Nvb2tpZS5uYW1lfWApO1xuICAgIH1cbiAgICBjb25zdCB2YWx1ZSA9IGNvb2tpZS52YWx1ZSA9PSBudWxsID8gXCJcIiA6IGVuYyhjb29raWUudmFsdWUpO1xuICAgIGlmICghY29va2llVmFsdWVSZWdFeHAudGVzdCh2YWx1ZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgYXJndW1lbnQgdmFsIGlzIGludmFsaWQ6ICR7Y29va2llLnZhbHVlfWApO1xuICAgIH1cbiAgICBsZXQgc3RyID0gY29va2llLm5hbWUgKyBcIj1cIiArIHZhbHVlO1xuICAgIGlmIChjb29raWUubWF4QWdlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgaWYgKCFOdW1iZXIuaXNJbnRlZ2VyKGNvb2tpZS5tYXhBZ2UpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBvcHRpb24gbWF4QWdlIGlzIGludmFsaWQ6ICR7Y29va2llLm1heEFnZX1gKTtcbiAgICAgICAgfVxuICAgICAgICBzdHIgKz0gXCI7IE1heC1BZ2U9XCIgKyBjb29raWUubWF4QWdlO1xuICAgIH1cbiAgICBpZiAoY29va2llLmRvbWFpbikge1xuICAgICAgICBpZiAoIWRvbWFpblZhbHVlUmVnRXhwLnRlc3QoY29va2llLmRvbWFpbikpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYG9wdGlvbiBkb21haW4gaXMgaW52YWxpZDogJHtjb29raWUuZG9tYWlufWApO1xuICAgICAgICB9XG4gICAgICAgIHN0ciArPSBcIjsgRG9tYWluPVwiICsgY29va2llLmRvbWFpbjtcbiAgICB9XG4gICAgaWYgKGNvb2tpZS5wYXRoKSB7XG4gICAgICAgIGlmICghcGF0aFZhbHVlUmVnRXhwLnRlc3QoY29va2llLnBhdGgpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBvcHRpb24gcGF0aCBpcyBpbnZhbGlkOiAke2Nvb2tpZS5wYXRofWApO1xuICAgICAgICB9XG4gICAgICAgIHN0ciArPSBcIjsgUGF0aD1cIiArIGNvb2tpZS5wYXRoO1xuICAgIH1cbiAgICBpZiAoY29va2llLmV4cGlyZXMpIHtcbiAgICAgICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoY29va2llLmV4cGlyZXMudmFsdWVPZigpKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgb3B0aW9uIGV4cGlyZXMgaXMgaW52YWxpZDogJHtjb29raWUuZXhwaXJlc31gKTtcbiAgICAgICAgfVxuICAgICAgICBzdHIgKz0gXCI7IEV4cGlyZXM9XCIgKyBjb29raWUuZXhwaXJlcy50b1VUQ1N0cmluZygpO1xuICAgIH1cbiAgICBpZiAoY29va2llLmh0dHBPbmx5KSB7XG4gICAgICAgIHN0ciArPSBcIjsgSHR0cE9ubHlcIjtcbiAgICB9XG4gICAgaWYgKGNvb2tpZS5zZWN1cmUpIHtcbiAgICAgICAgc3RyICs9IFwiOyBTZWN1cmVcIjtcbiAgICB9XG4gICAgaWYgKGNvb2tpZS5wYXJ0aXRpb25lZCkge1xuICAgICAgICBzdHIgKz0gXCI7IFBhcnRpdGlvbmVkXCI7XG4gICAgfVxuICAgIGlmIChjb29raWUucHJpb3JpdHkpIHtcbiAgICAgICAgY29uc3QgcHJpb3JpdHkgPSB0eXBlb2YgY29va2llLnByaW9yaXR5ID09PSBcInN0cmluZ1wiXG4gICAgICAgICAgICA/IGNvb2tpZS5wcmlvcml0eS50b0xvd2VyQ2FzZSgpXG4gICAgICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICAgICAgc3dpdGNoIChwcmlvcml0eSkge1xuICAgICAgICAgICAgY2FzZSBcImxvd1wiOlxuICAgICAgICAgICAgICAgIHN0ciArPSBcIjsgUHJpb3JpdHk9TG93XCI7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFwibWVkaXVtXCI6XG4gICAgICAgICAgICAgICAgc3RyICs9IFwiOyBQcmlvcml0eT1NZWRpdW1cIjtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgXCJoaWdoXCI6XG4gICAgICAgICAgICAgICAgc3RyICs9IFwiOyBQcmlvcml0eT1IaWdoXCI7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYG9wdGlvbiBwcmlvcml0eSBpcyBpbnZhbGlkOiAke2Nvb2tpZS5wcmlvcml0eX1gKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoY29va2llLnNhbWVTaXRlKSB7XG4gICAgICAgIGNvbnN0IHNhbWVTaXRlID0gdHlwZW9mIGNvb2tpZS5zYW1lU2l0ZSA9PT0gXCJzdHJpbmdcIlxuICAgICAgICAgICAgPyBjb29raWUuc2FtZVNpdGUudG9Mb3dlckNhc2UoKVxuICAgICAgICAgICAgOiBjb29raWUuc2FtZVNpdGU7XG4gICAgICAgIHN3aXRjaCAoc2FtZVNpdGUpIHtcbiAgICAgICAgICAgIGNhc2UgdHJ1ZTpcbiAgICAgICAgICAgIGNhc2UgXCJzdHJpY3RcIjpcbiAgICAgICAgICAgICAgICBzdHIgKz0gXCI7IFNhbWVTaXRlPVN0cmljdFwiO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBcImxheFwiOlxuICAgICAgICAgICAgICAgIHN0ciArPSBcIjsgU2FtZVNpdGU9TGF4XCI7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFwibm9uZVwiOlxuICAgICAgICAgICAgICAgIHN0ciArPSBcIjsgU2FtZVNpdGU9Tm9uZVwiO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBvcHRpb24gc2FtZVNpdGUgaXMgaW52YWxpZDogJHtjb29raWUuc2FtZVNpdGV9YCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN0cjtcbn1cbi8qKlxuICogRGVzZXJpYWxpemUgYSBgU2V0LUNvb2tpZWAgaGVhZGVyIGludG8gYW4gb2JqZWN0LlxuICpcbiAqIHBhcnNlU2V0Q29va2llKCdmb289YmFyOyBIdHRwT25seScpXG4gKiAgID0+IHsgbmFtZTogJ2ZvbycsIHZhbHVlOiAnYmFyJywgaHR0cE9ubHk6IHRydWUgfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VTZXRDb29raWUoc3RyLCBvcHRpb25zKSB7XG4gICAgY29uc3QgZGVjID0gb3B0aW9ucz8uZGVjb2RlIHx8IGRlY29kZTtcbiAgICBjb25zdCBsZW4gPSBzdHIubGVuZ3RoO1xuICAgIGNvbnN0IGVuZElkeCA9IGVuZEluZGV4KHN0ciwgMCwgbGVuKTtcbiAgICBsZXQgZXFJZHggPSBlcUluZGV4KHN0ciwgMCwgbGVuKTtcbiAgICBjb25zdCBzZXRDb29raWUgPSBlcUlkeCA8IGVuZElkeFxuICAgICAgICA/IHtcbiAgICAgICAgICAgIG5hbWU6IHZhbHVlU2xpY2Uoc3RyLCAwLCBlcUlkeCksXG4gICAgICAgICAgICB2YWx1ZTogZGVjKHZhbHVlU2xpY2Uoc3RyLCBlcUlkeCArIDEsIGVuZElkeCkpLFxuICAgICAgICB9XG4gICAgICAgIDogeyBuYW1lOiBcIlwiLCB2YWx1ZTogZGVjKHZhbHVlU2xpY2Uoc3RyLCAwLCBlbmRJZHgpKSB9O1xuICAgIGxldCBpbmRleCA9IGVuZElkeCArIDE7XG4gICAgd2hpbGUgKGluZGV4IDwgbGVuKSB7XG4gICAgICAgIGNvbnN0IGVuZElkeCA9IGVuZEluZGV4KHN0ciwgaW5kZXgsIGxlbik7XG4gICAgICAgIGlmIChlcUlkeCA8IGluZGV4KVxuICAgICAgICAgICAgZXFJZHggPSBlcUluZGV4KHN0ciwgaW5kZXgsIGxlbik7XG4gICAgICAgIGNvbnN0IGF0dHIgPSBlcUlkeCA8IGVuZElkeFxuICAgICAgICAgICAgPyB2YWx1ZVNsaWNlKHN0ciwgaW5kZXgsIGVxSWR4KVxuICAgICAgICAgICAgOiB2YWx1ZVNsaWNlKHN0ciwgaW5kZXgsIGVuZElkeCk7XG4gICAgICAgIGNvbnN0IHZhbCA9IGVxSWR4IDwgZW5kSWR4ID8gdmFsdWVTbGljZShzdHIsIGVxSWR4ICsgMSwgZW5kSWR4KSA6IHVuZGVmaW5lZDtcbiAgICAgICAgc3dpdGNoIChhdHRyLnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgICAgICAgIGNhc2UgXCJodHRwb25seVwiOlxuICAgICAgICAgICAgICAgIHNldENvb2tpZS5odHRwT25seSA9IHRydWU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFwic2VjdXJlXCI6XG4gICAgICAgICAgICAgICAgc2V0Q29va2llLnNlY3VyZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFwicGFydGl0aW9uZWRcIjpcbiAgICAgICAgICAgICAgICBzZXRDb29raWUucGFydGl0aW9uZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBcImRvbWFpblwiOlxuICAgICAgICAgICAgICAgIHNldENvb2tpZS5kb21haW4gPSB2YWw7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFwicGF0aFwiOlxuICAgICAgICAgICAgICAgIHNldENvb2tpZS5wYXRoID0gdmFsO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBcIm1heC1hZ2VcIjpcbiAgICAgICAgICAgICAgICBpZiAodmFsICYmIG1heEFnZVJlZ0V4cC50ZXN0KHZhbCkpXG4gICAgICAgICAgICAgICAgICAgIHNldENvb2tpZS5tYXhBZ2UgPSBOdW1iZXIodmFsKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgXCJleHBpcmVzXCI6XG4gICAgICAgICAgICAgICAgaWYgKCF2YWwpXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh2YWwpO1xuICAgICAgICAgICAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoZGF0ZS52YWx1ZU9mKCkpKVxuICAgICAgICAgICAgICAgICAgICBzZXRDb29raWUuZXhwaXJlcyA9IGRhdGU7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIFwicHJpb3JpdHlcIjpcbiAgICAgICAgICAgICAgICBpZiAoIXZhbClcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY29uc3QgcHJpb3JpdHkgPSB2YWwudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgICBpZiAocHJpb3JpdHkgPT09IFwibG93XCIgfHxcbiAgICAgICAgICAgICAgICAgICAgcHJpb3JpdHkgPT09IFwibWVkaXVtXCIgfHxcbiAgICAgICAgICAgICAgICAgICAgcHJpb3JpdHkgPT09IFwiaGlnaFwiKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldENvb2tpZS5wcmlvcml0eSA9IHByaW9yaXR5O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgXCJzYW1lc2l0ZVwiOlxuICAgICAgICAgICAgICAgIGlmICghdmFsKVxuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjb25zdCBzYW1lU2l0ZSA9IHZhbC50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgICAgIGlmIChzYW1lU2l0ZSA9PT0gXCJsYXhcIiB8fFxuICAgICAgICAgICAgICAgICAgICBzYW1lU2l0ZSA9PT0gXCJzdHJpY3RcIiB8fFxuICAgICAgICAgICAgICAgICAgICBzYW1lU2l0ZSA9PT0gXCJub25lXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q29va2llLnNhbWVTaXRlID0gc2FtZVNpdGU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGluZGV4ID0gZW5kSWR4ICsgMTtcbiAgICB9XG4gICAgcmV0dXJuIHNldENvb2tpZTtcbn1cbi8qKlxuICogRmluZCB0aGUgbmV4dCBgO2AgY2hhcmFjdGVyLCBvciByZXR1cm4gYGxlbmAuXG4gKi9cbmZ1bmN0aW9uIGVuZEluZGV4KHN0ciwgbWluLCBsZW4pIHtcbiAgICBjb25zdCBpbmRleCA9IHN0ci5pbmRleE9mKFwiO1wiLCBtaW4pO1xuICAgIHJldHVybiBpbmRleCA9PT0gLTEgPyBsZW4gOiBpbmRleDtcbn1cbi8qKlxuICogRmluZCB0aGUgbmV4dCBgPWAgY2hhcmFjdGVyLCBvciByZXR1cm4gYGxlbmAuXG4gKi9cbmZ1bmN0aW9uIGVxSW5kZXgoc3RyLCBtaW4sIGxlbikge1xuICAgIGNvbnN0IGluZGV4ID0gc3RyLmluZGV4T2YoXCI9XCIsIG1pbik7XG4gICAgcmV0dXJuIGluZGV4ID09PSAtMSA/IGxlbiA6IGluZGV4O1xufVxuLyoqXG4gKiBTbGljZSBvdXQgYSB2YWx1ZSBiZXR3ZWVuIHN0YXJ0UG9kIHRvIG1heC5cbiAqL1xuZnVuY3Rpb24gdmFsdWVTbGljZShzdHIsIG1pbiwgbWF4KSB7XG4gICAgaWYgKG1pbiA9PT0gbWF4KVxuICAgICAgICByZXR1cm4gXCJcIjtcbiAgICBsZXQgc3RhcnQgPSBtaW47XG4gICAgbGV0IGVuZCA9IG1heDtcbiAgICBkbyB7XG4gICAgICAgIGNvbnN0IGNvZGUgPSBzdHIuY2hhckNvZGVBdChzdGFydCk7XG4gICAgICAgIGlmIChjb2RlICE9PSAzMiAvKiAgICovICYmIGNvZGUgIT09IDkgLyogXFx0ICovKVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgfSB3aGlsZSAoKytzdGFydCA8IGVuZCk7XG4gICAgd2hpbGUgKGVuZCA+IHN0YXJ0KSB7XG4gICAgICAgIGNvbnN0IGNvZGUgPSBzdHIuY2hhckNvZGVBdChlbmQgLSAxKTtcbiAgICAgICAgaWYgKGNvZGUgIT09IDMyIC8qICAgKi8gJiYgY29kZSAhPT0gOSAvKiBcXHQgKi8pXG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgZW5kLS07XG4gICAgfVxuICAgIHJldHVybiBzdHIuc2xpY2Uoc3RhcnQsIGVuZCk7XG59XG4vKipcbiAqIFVSTC1kZWNvZGUgc3RyaW5nIHZhbHVlLiBPcHRpbWl6ZWQgdG8gc2tpcCBuYXRpdmUgY2FsbCB3aGVuIG5vICUuXG4gKi9cbmZ1bmN0aW9uIGRlY29kZShzdHIpIHtcbiAgICBpZiAoc3RyLmluZGV4T2YoXCIlXCIpID09PSAtMSlcbiAgICAgICAgcmV0dXJuIHN0cjtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KHN0cik7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiBzdHI7XG4gICAgfVxufVxuLyoqXG4gKiBVUkwtZW5jb2RlIHN0cmluZyB2YWx1ZS4gT3B0aW1pemVkIHRvIHNraXAgbmF0aXZlIGNhbGwgZm9yIHJvdW5kdHJpcC1zYWZlIGNvb2tpZS1vY3RldCB2YWx1ZXMuXG4gKi9cbmZ1bmN0aW9uIGRlZmF1bHRFbmNvZGUoc3RyKSB7XG4gICAgcmV0dXJuIGNvb2tpZU9jdGV0UmVnRXhwLnRlc3Qoc3RyKSA/IHN0ciA6IGVuY29kZVVSSUNvbXBvbmVudChzdHIpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgYSBhcyBtYXRjaFJlcXVlc3RVcmwsIGMgYXMgaXNTdHJpbmdFcXVhbCwgaCBhcyBkZXZVdGlscywgcCBhcyBodHRwU3RhdHVzTWVzc2FnZXMsIHIgYXMgdG9QdWJsaWNVcmwsIHMgYXMgZ2V0VGltZXN0YW1wLCB0IGFzIGNvb2tpZVN0b3JlIH0gZnJvbSBcIi4vY29va2llLXN0b3JlLmpzXCI7XG5pbXBvcnQgeyB0IGFzIFJlcXVlc3RIYW5kbGVyIH0gZnJvbSBcIi4vcmVxdWVzdC1oYW5kbGVyLmpzXCI7XG5pbXBvcnQgeyBnZXRDbGVhblVybFN0cmluZyB9IGZyb20gXCIuLi91dGlscy9nZXQtY2xlYW4tdXJsLXN0cmluZy5qc1wiO1xuaW1wb3J0IHsgcGFyc2VDb29raWUgfSBmcm9tIFwiY29va2llXCI7XG4vLyNyZWdpb24gc3JjL2NvcmUvdXRpbHMvbG9nZ2luZy9nZXQtc3RhdHVzLWNvZGUtY29sb3IudHNcbi8qKlxuKiBSZXR1cm5zIGEgSEVYIGNvbG9yIGZvciBhIGdpdmVuIHJlc3BvbnNlIHN0YXR1cyBjb2RlIG51bWJlci5cbiovXG5mdW5jdGlvbiBnZXRTdGF0dXNDb2RlQ29sb3Ioc3RhdHVzKSB7XG5cdGlmIChzdGF0dXMgPCAzMDApIHJldHVybiBcIiM2OUFCMzJcIjtcblx0aWYgKHN0YXR1cyA8IDQwMCkgcmV0dXJuIFwiI0YwQkI0QlwiO1xuXHRyZXR1cm4gXCIjRTk1RjVEXCI7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS91dGlscy9sb2dnaW5nL3NlcmlhbGl6ZS1yZXF1ZXN0LnRzXG4vKipcbiogRm9ybWF0cyBhIG1vY2tlZCByZXF1ZXN0IGZvciBpbnRyb3NwZWN0aW9uIGluIGJyb3dzZXIncyBjb25zb2xlLlxuKi9cbmFzeW5jIGZ1bmN0aW9uIHNlcmlhbGl6ZVJlcXVlc3QocmVxdWVzdCkge1xuXHRjb25zdCByZXF1ZXN0VGV4dCA9IGF3YWl0IHJlcXVlc3QuY2xvbmUoKS50ZXh0KCk7XG5cdHJldHVybiB7XG5cdFx0dXJsOiBuZXcgVVJMKHJlcXVlc3QudXJsKSxcblx0XHRtZXRob2Q6IHJlcXVlc3QubWV0aG9kLFxuXHRcdGhlYWRlcnM6IE9iamVjdC5mcm9tRW50cmllcyhyZXF1ZXN0LmhlYWRlcnMuZW50cmllcygpKSxcblx0XHRib2R5OiByZXF1ZXN0VGV4dFxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdXRpbHMvbG9nZ2luZy9zZXJpYWxpemUtcmVzcG9uc2UudHNcbmFzeW5jIGZ1bmN0aW9uIHNlcmlhbGl6ZVJlc3BvbnNlKHJlc3BvbnNlKSB7XG5cdGNvbnN0IHJlc3BvbnNlQ2xvbmUgPSByZXNwb25zZS5jbG9uZSgpO1xuXHRjb25zdCByZXNwb25zZVRleHQgPSBhd2FpdCByZXNwb25zZUNsb25lLnRleHQoKTtcblx0Y29uc3QgcmVzcG9uc2VTdGF0dXMgPSByZXNwb25zZUNsb25lLnN0YXR1cyB8fCAyMDA7XG5cdHJldHVybiB7XG5cdFx0c3RhdHVzOiByZXNwb25zZVN0YXR1cyxcblx0XHRzdGF0dXNUZXh0OiByZXNwb25zZUNsb25lLnN0YXR1c1RleHQgfHwgaHR0cFN0YXR1c01lc3NhZ2VzW3Jlc3BvbnNlU3RhdHVzXSB8fCBcIk9LXCIsXG5cdFx0aGVhZGVyczogT2JqZWN0LmZyb21FbnRyaWVzKHJlc3BvbnNlQ2xvbmUuaGVhZGVycy5lbnRyaWVzKCkpLFxuXHRcdGJvZHk6IHJlc3BvbnNlVGV4dFxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdXRpbHMvcmVxdWVzdC9nZXQtcmVxdWVzdC1jb29raWVzLnRzXG5mdW5jdGlvbiBwYXJzZUNvb2tpZXMoaW5wdXQpIHtcblx0Y29uc3QgcGFyc2VkQ29va2llcyA9IHBhcnNlQ29va2llKGlucHV0KTtcblx0Y29uc3QgY29va2llcyA9IHt9O1xuXHRmb3IgKGNvbnN0IGNvb2tpZU5hbWUgaW4gcGFyc2VkQ29va2llcykgaWYgKHR5cGVvZiBwYXJzZWRDb29raWVzW2Nvb2tpZU5hbWVdICE9PSBcInVuZGVmaW5lZFwiKSBjb29raWVzW2Nvb2tpZU5hbWVdID0gcGFyc2VkQ29va2llc1tjb29raWVOYW1lXTtcblx0cmV0dXJuIGNvb2tpZXM7XG59XG5mdW5jdGlvbiBnZXRBbGxEb2N1bWVudENvb2tpZXMoKSB7XG5cdHJldHVybiBwYXJzZUNvb2tpZXMoZG9jdW1lbnQuY29va2llKTtcbn1cbi8qKlxuKiBSZXR1cm5zIHdoZXRoZXIgdGhlIGdpdmVuIHJlcXVlc3Qgd291bGQgY2FycnkgY29va2llcyxcbiogYmFzZWQgb24gaXRzIGBjcmVkZW50aWFsc2AgbW9kZS5cbiovXG5mdW5jdGlvbiBpbmNsdWRlc0NyZWRlbnRpYWxzKHJlcXVlc3QpIHtcblx0c3dpdGNoIChyZXF1ZXN0LmNyZWRlbnRpYWxzKSB7XG5cdFx0Y2FzZSBcInNhbWUtb3JpZ2luXCI6IHJldHVybiB0eXBlb2YgbG9jYXRpb24gIT09IFwidW5kZWZpbmVkXCIgJiYgbG9jYXRpb24ub3JpZ2luID09PSBuZXcgVVJMKHJlcXVlc3QudXJsKS5vcmlnaW47XG5cdFx0Y2FzZSBcImluY2x1ZGVcIjogcmV0dXJuIHRydWU7XG5cdFx0ZGVmYXVsdDogcmV0dXJuIGZhbHNlO1xuXHR9XG59XG5mdW5jdGlvbiBnZXREb2N1bWVudENvb2tpZXMoKSB7XG5cdGlmICh0eXBlb2YgZG9jdW1lbnQgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiB7fTtcblx0cmV0dXJuIGdldEFsbERvY3VtZW50Q29va2llcygpO1xufVxuZnVuY3Rpb24gZ2V0QWxsUmVxdWVzdENvb2tpZXMocmVxdWVzdCkge1xuXHRjb25zdCByZXF1ZXN0Q29va2llSGVhZGVyID0gcmVxdWVzdC5oZWFkZXJzLmdldChcImNvb2tpZVwiKTtcblx0Y29uc3QgY29va2llc0Zyb21IZWFkZXJzID0gcmVxdWVzdENvb2tpZUhlYWRlciA/IHBhcnNlQ29va2llcyhyZXF1ZXN0Q29va2llSGVhZGVyKSA6IHt9O1xuXHRpZiAoY29va2llU3RvcmUgPT09IG51bGwgfHwgIWluY2x1ZGVzQ3JlZGVudGlhbHMocmVxdWVzdCkpIHJldHVybiBjb29raWVzRnJvbUhlYWRlcnM7XG5cdGNvbnN0IGNvb2tpZXNGcm9tRG9jdW1lbnQgPSBnZXREb2N1bWVudENvb2tpZXMoKTtcblx0Y29uc3QgY29va2llc0Zyb21TdG9yZSA9IGNvb2tpZVN0b3JlLmdldENvb2tpZXMocmVxdWVzdC51cmwpO1xuXHRjb25zdCBzdG9yZWRDb29raWVzT2JqZWN0ID0gT2JqZWN0LmZyb21FbnRyaWVzKGNvb2tpZXNGcm9tU3RvcmUubWFwKChjb29raWUpID0+IFtjb29raWUua2V5LCBjb29raWUudmFsdWVdKSk7XG5cdHJldHVybiB7XG5cdFx0Li4uY29va2llc0Zyb21Eb2N1bWVudCxcblx0XHQuLi5zdG9yZWRDb29raWVzT2JqZWN0LFxuXHRcdC4uLmNvb2tpZXNGcm9tSGVhZGVyc1xuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2h0dHAvaHR0cC1oYW5kbGVyLnRzXG5sZXQgSHR0cE1ldGhvZHMgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oSHR0cE1ldGhvZHMpIHtcblx0SHR0cE1ldGhvZHNbXCJIRUFEXCJdID0gXCJIRUFEXCI7XG5cdEh0dHBNZXRob2RzW1wiR0VUXCJdID0gXCJHRVRcIjtcblx0SHR0cE1ldGhvZHNbXCJQT1NUXCJdID0gXCJQT1NUXCI7XG5cdEh0dHBNZXRob2RzW1wiUFVUXCJdID0gXCJQVVRcIjtcblx0SHR0cE1ldGhvZHNbXCJQQVRDSFwiXSA9IFwiUEFUQ0hcIjtcblx0SHR0cE1ldGhvZHNbXCJPUFRJT05TXCJdID0gXCJPUFRJT05TXCI7XG5cdEh0dHBNZXRob2RzW1wiREVMRVRFXCJdID0gXCJERUxFVEVcIjtcblx0cmV0dXJuIEh0dHBNZXRob2RzO1xufSh7fSk7XG4vKipcbiogUmVxdWVzdCBoYW5kbGVyIGZvciBIVFRQIHJlcXVlc3RzLlxuKiBQcm92aWRlcyByZXF1ZXN0IG1hdGNoaW5nIGJhc2VkIG9uIG1ldGhvZCBhbmQgVVJMLlxuKi9cbnZhciBIdHRwSGFuZGxlciA9IGNsYXNzIGV4dGVuZHMgUmVxdWVzdEhhbmRsZXIge1xuXHRjb25zdHJ1Y3RvcihtZXRob2QsIHByZWRpY2F0ZSwgcmVzb2x2ZXIsIG9wdGlvbnMpIHtcblx0XHRjb25zdCBkaXNwbGF5UGF0aCA9IHR5cGVvZiBwcmVkaWNhdGUgPT09IFwiZnVuY3Rpb25cIiA/IFwiW2N1c3RvbSBwcmVkaWNhdGVdXCIgOiBwcmVkaWNhdGU7XG5cdFx0c3VwZXIoe1xuXHRcdFx0aW5mbzoge1xuXHRcdFx0XHRoZWFkZXI6IGAke21ldGhvZH0ke2Rpc3BsYXlQYXRoID8gYCAke2Rpc3BsYXlQYXRofWAgOiBcIlwifWAsXG5cdFx0XHRcdHBhdGg6IHByZWRpY2F0ZSxcblx0XHRcdFx0bWV0aG9kXG5cdFx0XHR9LFxuXHRcdFx0cmVzb2x2ZXIsXG5cdFx0XHRvcHRpb25zXG5cdFx0fSk7XG5cdFx0dGhpcy5jaGVja1JlZHVuZGFudFF1ZXJ5UGFyYW1ldGVycygpO1xuXHR9XG5cdGNoZWNrUmVkdW5kYW50UXVlcnlQYXJhbWV0ZXJzKCkge1xuXHRcdGNvbnN0IHsgbWV0aG9kLCBwYXRoIH0gPSB0aGlzLmluZm87XG5cdFx0aWYgKCFwYXRoIHx8IHBhdGggaW5zdGFuY2VvZiBSZWdFeHAgfHwgdHlwZW9mIHBhdGggPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuO1xuXHRcdGlmIChnZXRDbGVhblVybFN0cmluZyhwYXRoKSA9PT0gcGF0aCkgcmV0dXJuO1xuXHRcdGRldlV0aWxzLndhcm4oYEZvdW5kIGEgcmVkdW5kYW50IHVzYWdlIG9mIHF1ZXJ5IHBhcmFtZXRlcnMgaW4gdGhlIHJlcXVlc3QgaGFuZGxlciBVUkwgZm9yIFwiJHttZXRob2R9ICR7cGF0aH1cIi4gUGxlYXNlIG1hdGNoIGFnYWluc3QgYSBwYXRoIGluc3RlYWQgYW5kIGFjY2VzcyBxdWVyeSBwYXJhbWV0ZXJzIHVzaW5nIFwibmV3IFVSTChyZXF1ZXN0LnVybCkuc2VhcmNoUGFyYW1zXCIgaW5zdGVhZC4gTGVhcm4gbW9yZTogaHR0cHM6Ly9tc3dqcy5pby9kb2NzL2h0dHAvaW50ZXJjZXB0aW5nLXJlcXVlc3RzI3F1ZXJ5c2VhcmNoLXBhcmFtZXRlcnNgKTtcblx0fVxuXHRhc3luYyBwYXJzZShhcmdzKSB7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBDT05ORUNUIHJlcXVlc3RzIHRhcmdldCBhbiBhdXRob3JpdHkgKFwiaG9zdDpwb3J0XCIpLCBub3QgYSBVUkwuXG5cdFx0KiBIVFRQIGhhbmRsZXJzIG5ldmVyIG1hdGNoIHRoZW0uXG5cdFx0KiBAdG9kbyBNYXRjaCB0aGUgYXV0aG9yaXR5IGFnYWluc3QgdGhlIGhhbmRsZXIgcGF0aCBvbmNlXG5cdFx0KiBgaHR0cC5jb25uZWN0KClgIGlzIHN1cHBvcnRlZCBpbnN0ZWFkIG9mIGJhaWxpbmcgb3V0LlxuXHRcdCovXG5cdFx0aWYgKGlzU3RyaW5nRXF1YWwoYXJncy5yZXF1ZXN0Lm1ldGhvZCwgXCJDT05ORUNUXCIpKSByZXR1cm4ge1xuXHRcdFx0bWF0Y2g6IHtcblx0XHRcdFx0bWF0Y2hlczogZmFsc2UsXG5cdFx0XHRcdHBhcmFtczoge31cblx0XHRcdH0sXG5cdFx0XHRjb29raWVzOiB7fVxuXHRcdH07XG5cdFx0Y29uc3QgdXJsID0gbmV3IFVSTChhcmdzLnJlcXVlc3QudXJsKTtcblx0XHRjb25zdCBjb29raWVzID0gZ2V0QWxsUmVxdWVzdENvb2tpZXMoYXJncy5yZXF1ZXN0KTtcblx0XHQvKipcblx0XHQqIEhhbmRsZSBjdXN0b20gcHJlZGljYXRlIGZ1bmN0aW9ucy5cblx0XHQqIEBub3RlIEludm9rZSB0aGlzIGR1cmluZyBwYXJzaW5nIHNvIHRoZSB1c2VyIGNhbiBwYXJzZSB0aGUgcGF0aCBwYXJhbWV0ZXJzXG5cdFx0KiBtYW51YWxseS4gT3RoZXJ3aXNlLCBgcGFyYW1zYCBpcyBhbHdheXMgYW4gZW1wdHkgb2JqZWN0LCB3aGljaCBpc24ndCBuaWNlLlxuXHRcdCovXG5cdFx0aWYgKHR5cGVvZiB0aGlzLmluZm8ucGF0aCA9PT0gXCJmdW5jdGlvblwiKSB7XG5cdFx0XHRjb25zdCBjdXN0b21QcmVkaWNhdGVSZXN1bHQgPSBhd2FpdCB0aGlzLmluZm8ucGF0aCh7XG5cdFx0XHRcdHJlcXVlc3Q6IGFyZ3MucmVxdWVzdCxcblx0XHRcdFx0Y29va2llc1xuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRtYXRjaDogdHlwZW9mIGN1c3RvbVByZWRpY2F0ZVJlc3VsdCA9PT0gXCJib29sZWFuXCIgPyB7XG5cdFx0XHRcdFx0bWF0Y2hlczogY3VzdG9tUHJlZGljYXRlUmVzdWx0LFxuXHRcdFx0XHRcdHBhcmFtczoge31cblx0XHRcdFx0fSA6IGN1c3RvbVByZWRpY2F0ZVJlc3VsdCxcblx0XHRcdFx0Y29va2llc1xuXHRcdFx0fTtcblx0XHR9XG5cdFx0cmV0dXJuIHtcblx0XHRcdG1hdGNoOiB0aGlzLmluZm8ucGF0aCA/IG1hdGNoUmVxdWVzdFVybCh1cmwsIHRoaXMuaW5mby5wYXRoLCBhcmdzLnJlc29sdXRpb25Db250ZXh0Py5iYXNlVXJsKSA6IHtcblx0XHRcdFx0bWF0Y2hlczogZmFsc2UsXG5cdFx0XHRcdHBhcmFtczoge31cblx0XHRcdH0sXG5cdFx0XHRjb29raWVzXG5cdFx0fTtcblx0fVxuXHRhc3luYyBwcmVkaWNhdGUoYXJncykge1xuXHRcdGNvbnN0IGhhc01hdGNoaW5nTWV0aG9kID0gdGhpcy5tYXRjaE1ldGhvZChhcmdzLnJlcXVlc3QubWV0aG9kKTtcblx0XHRjb25zdCBoYXNNYXRjaGluZ1VybCA9IGFyZ3MucGFyc2VkUmVzdWx0Lm1hdGNoLm1hdGNoZXM7XG5cdFx0cmV0dXJuIGhhc01hdGNoaW5nTWV0aG9kICYmIGhhc01hdGNoaW5nVXJsO1xuXHR9XG5cdG1hdGNoTWV0aG9kKGFjdHVhbE1ldGhvZCkge1xuXHRcdHJldHVybiB0aGlzLmluZm8ubWV0aG9kIGluc3RhbmNlb2YgUmVnRXhwID8gdGhpcy5pbmZvLm1ldGhvZC50ZXN0KGFjdHVhbE1ldGhvZCkgOiBpc1N0cmluZ0VxdWFsKHRoaXMuaW5mby5tZXRob2QsIGFjdHVhbE1ldGhvZCk7XG5cdH1cblx0ZXh0ZW5kUmVzb2x2ZXJBcmdzKGFyZ3MpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0cGFyYW1zOiBhcmdzLnBhcnNlZFJlc3VsdC5tYXRjaD8ucGFyYW1zIHx8IHt9LFxuXHRcdFx0Y29va2llczogYXJncy5wYXJzZWRSZXN1bHQuY29va2llc1xuXHRcdH07XG5cdH1cblx0YXN5bmMgbG9nKGFyZ3MpIHtcblx0XHRjb25zdCBwdWJsaWNVcmwgPSB0b1B1YmxpY1VybChhcmdzLnJlcXVlc3QudXJsKTtcblx0XHRjb25zdCBsb2dnZWRSZXF1ZXN0ID0gYXdhaXQgc2VyaWFsaXplUmVxdWVzdChhcmdzLnJlcXVlc3QpO1xuXHRcdGNvbnN0IGxvZ2dlZFJlc3BvbnNlID0gYXdhaXQgc2VyaWFsaXplUmVzcG9uc2UoYXJncy5yZXNwb25zZSk7XG5cdFx0Y29uc3Qgc3RhdHVzQ29sb3IgPSBnZXRTdGF0dXNDb2RlQ29sb3IobG9nZ2VkUmVzcG9uc2Uuc3RhdHVzKTtcblx0XHRjb25zb2xlLmdyb3VwQ29sbGFwc2VkKGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoYCR7Z2V0VGltZXN0YW1wKCl9ICR7YXJncy5yZXF1ZXN0Lm1ldGhvZH0gJHtwdWJsaWNVcmx9ICglYyR7bG9nZ2VkUmVzcG9uc2Uuc3RhdHVzfSAke2xvZ2dlZFJlc3BvbnNlLnN0YXR1c1RleHR9JWMpYCksIGBjb2xvcjoke3N0YXR1c0NvbG9yfWAsIFwiY29sb3I6aW5oZXJpdFwiKTtcblx0XHRjb25zb2xlLmxvZyhcIlJlcXVlc3RcIiwgbG9nZ2VkUmVxdWVzdCk7XG5cdFx0Y29uc29sZS5sb2coXCJIYW5kbGVyOlwiLCB0aGlzKTtcblx0XHRjb25zb2xlLmxvZyhcIlJlc3BvbnNlXCIsIGxvZ2dlZFJlc3BvbnNlKTtcblx0XHRjb25zb2xlLmdyb3VwRW5kKCk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHNlcmlhbGl6ZVJlcXVlc3QgYXMgYSwgc2VyaWFsaXplUmVzcG9uc2UgYXMgaSwgSHR0cE1ldGhvZHMgYXMgbiwgZ2V0U3RhdHVzQ29kZUNvbG9yIGFzIG8sIGdldEFsbFJlcXVlc3RDb29raWVzIGFzIHIsIEh0dHBIYW5kbGVyIGFzIHQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aHR0cC1oYW5kbGVyLmpzLm1hcCIsImltcG9ydCB7IHQgYXMgSHR0cEhhbmRsZXIgfSBmcm9tIFwiLi9odHRwLWhhbmRsZXIuanNcIjtcbi8vI3JlZ2lvbiBzcmMvaHR0cC9odHRwLnRzXG5mdW5jdGlvbiBjcmVhdGVIdHRwSGFuZGxlcihtZXRob2QpIHtcblx0cmV0dXJuIChwcmVkaWNhdGUsIHJlc29sdmVyLCBvcHRpb25zID0ge30pID0+IHtcblx0XHRyZXR1cm4gbmV3IEh0dHBIYW5kbGVyKG1ldGhvZCwgcHJlZGljYXRlLCByZXNvbHZlciwgb3B0aW9ucyk7XG5cdH07XG59XG4vKipcbiogQSBuYW1lc3BhY2UgdG8gaW50ZXJjZXB0IGFuZCBtb2NrIEhUVFAgcmVxdWVzdHMuXG4qXG4qIEBleGFtcGxlXG4qIGh0dHAuZ2V0KCcvdXNlcicsIHJlc29sdmVyKVxuKiBodHRwLnBvc3QoJy9wb3N0LzppZCcsIHJlc29sdmVyKVxuKlxuKiBAc2VlIHtAbGluayBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL2h0dHAgYGh0dHBgIEFQSSByZWZlcmVuY2V9XG4qL1xuY29uc3QgaHR0cCA9IHtcblx0YWxsOiBjcmVhdGVIdHRwSGFuZGxlcigvLisvKSxcblx0aGVhZDogY3JlYXRlSHR0cEhhbmRsZXIoXCJIRUFEXCIpLFxuXHRnZXQ6IGNyZWF0ZUh0dHBIYW5kbGVyKFwiR0VUXCIpLFxuXHRwb3N0OiBjcmVhdGVIdHRwSGFuZGxlcihcIlBPU1RcIiksXG5cdHB1dDogY3JlYXRlSHR0cEhhbmRsZXIoXCJQVVRcIiksXG5cdGRlbGV0ZTogY3JlYXRlSHR0cEhhbmRsZXIoXCJERUxFVEVcIiksXG5cdHBhdGNoOiBjcmVhdGVIdHRwSGFuZGxlcihcIlBBVENIXCIpLFxuXHRvcHRpb25zOiBjcmVhdGVIdHRwSGFuZGxlcihcIk9QVElPTlNcIilcbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGh0dHAgYXMgdCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1odHRwLmpzLm1hcCIsImltcG9ydCB7IHQgYXMgaXNPYmplY3QgfSBmcm9tIFwiLi9pcy1vYmplY3QuanNcIjtcbi8vI3JlZ2lvbiBzcmMvY29yZS91dGlscy9pbnRlcm5hbC9oYXMtcmVmLWNvdW50ZWQudHNcbmZ1bmN0aW9uIGhhc1JlZkNvdW50ZWQodmFsdWUpIHtcblx0cmV0dXJuIGlzT2JqZWN0KHZhbHVlKSAmJiB0eXBlb2YgUmVmbGVjdC5nZXQodmFsdWUsIFwicmVmXCIpID09PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIFJlZmxlY3QuZ2V0KHZhbHVlLCBcInVucmVmXCIpID09PSBcImZ1bmN0aW9uXCI7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGhhc1JlZkNvdW50ZWQgYXMgdCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1oYXMtcmVmLWNvdW50ZWQuanMubWFwIiwiaW1wb3J0IHsgYSBhcyBtYXRjaFJlcXVlc3RVcmwgfSBmcm9tIFwiLi9jb29raWUtc3RvcmUuanNcIjtcbmltcG9ydCB7IHQgYXMgaHR0cCB9IGZyb20gXCIuL2h0dHAuanNcIjtcbmltcG9ydCB7IEZldGNoUmVzcG9uc2UsIHJlc29sdmVXZWJTb2NrZXRVcmwgfSBmcm9tIFwiQG1zd2pzL2ludGVyY2VwdG9yc1wiO1xuLy8jcmVnaW9uIHNyYy93cy93ZWJzb2NrZXQtdXBncmFkZS50c1xuY29uc3QgV0VCU09DS0VUX0dVSUQgPSBcIjI1OEVBRkE1LUU5MTQtNDdEQS05NUNBLUM1QUIwREM4NUIxMVwiO1xuLyoqXG4qIFJlc3BvbnNlIHJlc29sdmVyIGZvciB0aGUgYHVwZ3JhZGVgIHJlcXVlc3RzIHRvIHRoZSBXZWJTb2NrZXQgcHJvdG9jb2wuXG4qIFRoaXMgcmVxdWlyZXMgYSBXZWJTb2NrZXQgaGFuZGxlciB0byBiZSBwcmVzZW50IHRvIGZpcmUuXG4qIEBub3RlIFRoaXMgb25seSBhZmZlY3RzIE5vZGUuanMgYXMgdGhlIGB1cGdyYWRlYCByZXF1ZXN0IGhlYWRlciBpc1xuKiBmb3JiaWRkZW4gYW5kIGNhbm5vdCBiZSByZWFkIGluIHRoZSBicm93c2VyLiBDb25zaWRlciB1c2luZyB0aGVcbiogYFdlYlNvY2tldGAgQVBJIGZvciBlc3RhYmxpc2hpbmcgV2ViU29ja2V0IGNvbm5lY3Rpb25zIGluIHRoZSBicm93c2VyLlxuKi9cbmFzeW5jIGZ1bmN0aW9uIHdlYlNvY2tldFVwZ3JhZGUoeyByZXF1ZXN0IH0pIHtcblx0Y29uc3Qga2V5ID0gcmVxdWVzdC5oZWFkZXJzLmdldChcInNlYy13ZWJzb2NrZXQta2V5XCIpO1xuXHRpZiAoIWtleSkgcmV0dXJuO1xuXHRjb25zdCBrZXlCeXRlcyA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShrZXkgKyBXRUJTT0NLRVRfR1VJRCk7XG5cdGNvbnN0IGRpZ2VzdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KFwiU0hBLTFcIiwga2V5Qnl0ZXMpO1xuXHRjb25zdCBhY2NlcHRWYWx1ZSA9IGJ0b2EoU3RyaW5nLmZyb21DaGFyQ29kZSguLi5uZXcgVWludDhBcnJheShkaWdlc3QpKSk7XG5cdGNvbnN0IHJlcXVlc3RlZFByb3RvY29scyA9IHJlcXVlc3QuaGVhZGVycy5nZXQoXCJzZWMtd2Vic29ja2V0LXByb3RvY29sXCIpPy5zcGxpdChcIixcIikubWFwKChwcm90b2NvbCkgPT4gcHJvdG9jb2wudHJpbSgpKTtcblx0bmV3IFdlYlNvY2tldChyZXNvbHZlV2ViU29ja2V0VXJsKHJlcXVlc3QudXJsKSwgcmVxdWVzdGVkUHJvdG9jb2xzKTtcblx0Y29uc3QgaGVhZGVycyA9IG5ldyBIZWFkZXJzKHtcblx0XHR1cGdyYWRlOiBcIndlYnNvY2tldFwiLFxuXHRcdGNvbm5lY3Rpb246IFwidXBncmFkZVwiLFxuXHRcdFwic2VjLXdlYnNvY2tldC1hY2NlcHRcIjogYWNjZXB0VmFsdWVcblx0fSk7XG5cdGlmIChyZXF1ZXN0ZWRQcm90b2NvbHMgJiYgcmVxdWVzdGVkUHJvdG9jb2xzLmxlbmd0aCA+IDApIGhlYWRlcnMuc2V0KFwic2VjLXdlYnNvY2tldC1wcm90b2NvbFwiLCByZXF1ZXN0ZWRQcm90b2NvbHNbMF0pO1xuXHRyZXR1cm4gbmV3IEZldGNoUmVzcG9uc2UobnVsbCwge1xuXHRcdHN0YXR1czogMTAxLFxuXHRcdGhlYWRlcnNcblx0fSk7XG59XG4vKipcbiogQ3JlYXRlcyBhIHJlcXVlc3QgaGFuZGxlciB0aGF0IHJlc3BvbmRzIHRvIFdlYlNvY2tldCB1cGdyYWRlXG4qIHJlcXVlc3RzIHdob3NlIFVSTCBtYXRjaGVzIHRoZSBnaXZlbiBwYXRoLlxuKlxuKiBAaW50ZXJuYWxcbiovXG5mdW5jdGlvbiBjcmVhdGVXZWJTb2NrZXRVcGdyYWRlSGFuZGxlcih1cmwsIHJlc29sdmVyKSB7XG5cdHJldHVybiBodHRwLmdldCgoeyByZXF1ZXN0IH0pID0+IHtcblx0XHRyZXR1cm4gcmVxdWVzdC5oZWFkZXJzLmdldChcInVwZ3JhZGVcIik/LnRvTG93ZXJDYXNlKCkgPT09IFwid2Vic29ja2V0XCIgJiYgbWF0Y2hSZXF1ZXN0VXJsKG5ldyBVUkwocmVzb2x2ZVdlYlNvY2tldFVybChyZXF1ZXN0LnVybCkpLCB1cmwpLm1hdGNoZXM7XG5cdH0sIHJlc29sdmVyKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgd2ViU29ja2V0VXBncmFkZSBhcyBuLCBjcmVhdGVXZWJTb2NrZXRVcGdyYWRlSGFuZGxlciBhcyB0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXdlYnNvY2tldC11cGdyYWRlLmpzLm1hcCIsImltcG9ydCB7IGkgYXMgaXNQYXRoIH0gZnJvbSBcIi4vY29va2llLXN0b3JlLmpzXCI7XG5pbXBvcnQgeyBhIGFzIFdlYlNvY2tldEhhbmRsZXIsIGMgYXMga0VtaXR0ZXIsIHQgYXMgYXR0YWNoU2libGluZ0hhbmRsZXJzIH0gZnJvbSBcIi4vYXR0YWNoLXNpYmxpbmctaGFuZGxlcnMuanNcIjtcbmltcG9ydCB7IHQgYXMgaGFzUmVmQ291bnRlZCB9IGZyb20gXCIuL2hhcy1yZWYtY291bnRlZC5qc1wiO1xuaW1wb3J0IHsgbiBhcyB3ZWJTb2NrZXRVcGdyYWRlLCB0IGFzIGNyZWF0ZVdlYlNvY2tldFVwZ3JhZGVIYW5kbGVyIH0gZnJvbSBcIi4vd2Vic29ja2V0LXVwZ3JhZGUuanNcIjtcbmltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCJvdXR2YXJpYW50XCI7XG4vLyNyZWdpb24gc3JjL3dzL3dlYnNvY2tldC1tZW1vcnktY2xpZW50LXN0b3JlLnRzXG52YXIgV2ViU29ja2V0TWVtb3J5Q2xpZW50U3RvcmUgPSBjbGFzcyB7XG5cdHN0b3JlO1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHR0aGlzLnN0b3JlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0fVxuXHRhc3luYyBhZGQoY2xpZW50KSB7XG5cdFx0dGhpcy5zdG9yZS5zZXQoY2xpZW50LmlkLCB7XG5cdFx0XHRpZDogY2xpZW50LmlkLFxuXHRcdFx0dXJsOiBjbGllbnQudXJsLmhyZWZcblx0XHR9KTtcblx0fVxuXHRnZXRBbGwoKSB7XG5cdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZShBcnJheS5mcm9tKHRoaXMuc3RvcmUudmFsdWVzKCkpKTtcblx0fVxuXHRhc3luYyBkZWxldGVNYW55KGNsaWVudElkcykge1xuXHRcdGZvciAoY29uc3QgY2xpZW50SWQgb2YgY2xpZW50SWRzKSB0aGlzLnN0b3JlLmRlbGV0ZShjbGllbnRJZCk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvd3Mvd2Vic29ja2V0LWluZGV4ZWRkYi1jbGllbnQtc3RvcmUudHNcbmNvbnN0IERCX05BTUUgPSBcIm1zdy13ZWJzb2NrZXQtY2xpZW50c1wiO1xuY29uc3QgREJfU1RPUkVfTkFNRSA9IFwiY2xpZW50c1wiO1xudmFyIFdlYlNvY2tldEluZGV4ZWREQkNsaWVudFN0b3JlID0gY2xhc3Mge1xuXHRkYjtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0dGhpcy5kYiA9IHRoaXMuY3JlYXRlRGF0YWJhc2UoKTtcblx0fVxuXHRhc3luYyBhZGQoY2xpZW50KSB7XG5cdFx0Y29uc3QgcHJvbWlzZSA9IFByb21pc2Uud2l0aFJlc29sdmVycygpO1xuXHRcdC8qKlxuXHRcdCogQG5vdGUgVXNlIGAucHV0KClgIGluc3RlYWQgb2YgYC5hZGQoKWAgdG8gYWxsb3cgc2V0dGluZyBjbGllbnRzXG5cdFx0KiB0aGF0IGFscmVhZHkgZXhpc3QgaW4gdGhlIGRhdGFiYXNlLiBUaGlzIGNhbiBoYXBwZW4gaWYgYSBzaW5nbGUgcGFnZVxuXHRcdCogaGFzIG11bHRpcGxlIGV2ZW50IGhhbmRsZXJzLiBFYWNoIGhhbmRsZXIgd2lsbCByZWNlaXZlIHRoZSBcImNvbm5lY3Rpb25cIlxuXHRcdCogZXZlbnQgaW4gcGFyYWxsZWwsIGFuZCB0cnkgdG8gc2V0IHRoYXQgV2ViU29ja2V0IGNsaWVudCBpbiB0aGUgZGF0YWJhc2UuXG5cdFx0Ki9cblx0XHRjb25zdCByZXF1ZXN0ID0gKGF3YWl0IHRoaXMuZ2V0U3RvcmUoKSkucHV0KHtcblx0XHRcdGlkOiBjbGllbnQuaWQsXG5cdFx0XHR1cmw6IGNsaWVudC51cmwuaHJlZlxuXHRcdH0pO1xuXHRcdHJlcXVlc3Qub25zdWNjZXNzID0gKCkgPT4ge1xuXHRcdFx0cHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0fTtcblx0XHRyZXF1ZXN0Lm9uZXJyb3IgPSAoKSA9PiB7XG5cdFx0XHRjb25zb2xlLmVycm9yKHJlcXVlc3QuZXJyb3IpO1xuXHRcdFx0cHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihgRmFpbGVkIHRvIGFkZCBXZWJTb2NrZXQgY2xpZW50IFwiJHtjbGllbnQuaWR9XCIuIFRoZXJlIGlzIGxpa2VseSBhbiBhZGRpdGlvbmFsIG91dHB1dCBhYm92ZS5gKSk7XG5cdFx0fTtcblx0XHRyZXR1cm4gcHJvbWlzZS5wcm9taXNlO1xuXHR9XG5cdGFzeW5jIGdldEFsbCgpIHtcblx0XHRjb25zdCBwcm9taXNlID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0Y29uc3QgcmVxdWVzdCA9IChhd2FpdCB0aGlzLmdldFN0b3JlKCkpLmdldEFsbCgpO1xuXHRcdHJlcXVlc3Qub25zdWNjZXNzID0gKCkgPT4ge1xuXHRcdFx0cHJvbWlzZS5yZXNvbHZlKHJlcXVlc3QucmVzdWx0KTtcblx0XHR9O1xuXHRcdHJlcXVlc3Qub25lcnJvciA9ICgpID0+IHtcblx0XHRcdGNvbnNvbGUuZXJyb3IocmVxdWVzdC5lcnJvcik7XG5cdFx0XHRwcm9taXNlLnJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKGBGYWlsZWQgdG8gZ2V0IGFsbCBXZWJTb2NrZXQgY2xpZW50cy4gVGhlcmUgaXMgbGlrZWx5IGFuIGFkZGl0aW9uYWwgb3V0cHV0IGFib3ZlLmApKTtcblx0XHR9O1xuXHRcdHJldHVybiBwcm9taXNlLnByb21pc2U7XG5cdH1cblx0YXN5bmMgZGVsZXRlTWFueShjbGllbnRJZHMpIHtcblx0XHRjb25zdCBwcm9taXNlID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0Y29uc3Qgc3RvcmUgPSBhd2FpdCB0aGlzLmdldFN0b3JlKCk7XG5cdFx0Zm9yIChjb25zdCBjbGllbnRJZCBvZiBjbGllbnRJZHMpIHN0b3JlLmRlbGV0ZShjbGllbnRJZCk7XG5cdFx0c3RvcmUudHJhbnNhY3Rpb24ub25jb21wbGV0ZSA9ICgpID0+IHtcblx0XHRcdHByb21pc2UucmVzb2x2ZSgpO1xuXHRcdH07XG5cdFx0c3RvcmUudHJhbnNhY3Rpb24ub25lcnJvciA9ICgpID0+IHtcblx0XHRcdGNvbnNvbGUuZXJyb3Ioc3RvcmUudHJhbnNhY3Rpb24uZXJyb3IpO1xuXHRcdFx0cHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihgRmFpbGVkIHRvIGRlbGV0ZSBXZWJTb2NrZXQgY2xpZW50cyBbJHtjbGllbnRJZHMuam9pbihcIiwgXCIpfV0uIFRoZXJlIGlzIGxpa2VseSBhbiBhZGRpdGlvbmFsIG91dHB1dCBhYm92ZS5gKSk7XG5cdFx0fTtcblx0XHRyZXR1cm4gcHJvbWlzZS5wcm9taXNlO1xuXHR9XG5cdGFzeW5jIGNyZWF0ZURhdGFiYXNlKCkge1xuXHRcdGNvbnN0IHByb21pc2UgPSBQcm9taXNlLndpdGhSZXNvbHZlcnMoKTtcblx0XHRjb25zdCByZXF1ZXN0ID0gaW5kZXhlZERCLm9wZW4oREJfTkFNRSwgMSk7XG5cdFx0cmVxdWVzdC5vbnN1Y2Nlc3MgPSAoeyBjdXJyZW50VGFyZ2V0IH0pID0+IHtcblx0XHRcdGNvbnN0IGRiID0gUmVmbGVjdC5nZXQoY3VycmVudFRhcmdldCwgXCJyZXN1bHRcIik7XG5cdFx0XHRpZiAoZGIub2JqZWN0U3RvcmVOYW1lcy5jb250YWlucyhEQl9TVE9SRV9OQU1FKSkgcmV0dXJuIHByb21pc2UucmVzb2x2ZShkYik7XG5cdFx0fTtcblx0XHRyZXF1ZXN0Lm9udXBncmFkZW5lZWRlZCA9IGFzeW5jICh7IGN1cnJlbnRUYXJnZXQgfSkgPT4ge1xuXHRcdFx0Y29uc3QgZGIgPSBSZWZsZWN0LmdldChjdXJyZW50VGFyZ2V0LCBcInJlc3VsdFwiKTtcblx0XHRcdGlmIChkYi5vYmplY3RTdG9yZU5hbWVzLmNvbnRhaW5zKERCX1NUT1JFX05BTUUpKSByZXR1cm47XG5cdFx0XHRjb25zdCBzdG9yZSA9IGRiLmNyZWF0ZU9iamVjdFN0b3JlKERCX1NUT1JFX05BTUUsIHsga2V5UGF0aDogXCJpZFwiIH0pO1xuXHRcdFx0c3RvcmUudHJhbnNhY3Rpb24ub25jb21wbGV0ZSA9ICgpID0+IHtcblx0XHRcdFx0cHJvbWlzZS5yZXNvbHZlKGRiKTtcblx0XHRcdH07XG5cdFx0XHRzdG9yZS50cmFuc2FjdGlvbi5vbmVycm9yID0gKCkgPT4ge1xuXHRcdFx0XHRjb25zb2xlLmVycm9yKHN0b3JlLnRyYW5zYWN0aW9uLmVycm9yKTtcblx0XHRcdFx0cHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIkZhaWxlZCB0byBjcmVhdGUgV2ViU29ja2V0IGNsaWVudCBzdG9yZS4gVGhlcmUgaXMgbGlrZWx5IGFuIGFkZGl0aW9uYWwgb3V0cHV0IGFib3ZlLlwiKSk7XG5cdFx0XHR9O1xuXHRcdH07XG5cdFx0cmVxdWVzdC5vbmVycm9yID0gKCkgPT4ge1xuXHRcdFx0Y29uc29sZS5lcnJvcihyZXF1ZXN0LmVycm9yKTtcblx0XHRcdHByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gb3BlbiBhbiBJbmRleGVkREIgZGF0YWJhc2UuIFRoZXJlIGlzIGxpa2VseSBhbiBhZGRpdGlvbmFsIG91dHB1dCBhYm92ZS5cIikpO1xuXHRcdH07XG5cdFx0cmV0dXJuIHByb21pc2UucHJvbWlzZTtcblx0fVxuXHRhc3luYyBnZXRTdG9yZSgpIHtcblx0XHRyZXR1cm4gKGF3YWl0IHRoaXMuZGIpLnRyYW5zYWN0aW9uKERCX1NUT1JFX05BTUUsIFwicmVhZHdyaXRlXCIpLm9iamVjdFN0b3JlKERCX1NUT1JFX05BTUUpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3dzL3dlYnNvY2tldC1jbGllbnQtbWFuYWdlci50c1xuLyoqXG4qIEEgbWFuYWdlciByZXNwb25zaWJsZSBmb3IgYWNjdW11bGF0aW5nIFdlYlNvY2tldCBjbGllbnRcbiogY29ubmVjdGlvbnMgYWNyb3NzIGRpZmZlcmVudCBicm93c2VyIHJ1bnRpbWVzLlxuKi9cbnZhciBXZWJTb2NrZXRDbGllbnRNYW5hZ2VyID0gY2xhc3Mge1xuXHRjaGFubmVsO1xuXHRzdG9yZTtcblx0cnVudGltZUNsaWVudHM7XG5cdGFsbENsaWVudHM7XG5cdGNvbnN0cnVjdG9yKGNoYW5uZWwpIHtcblx0XHR0aGlzLmNoYW5uZWwgPSBjaGFubmVsO1xuXHRcdHRoaXMuc3RvcmUgPSB0eXBlb2YgaW5kZXhlZERCICE9PSBcInVuZGVmaW5lZFwiID8gbmV3IFdlYlNvY2tldEluZGV4ZWREQkNsaWVudFN0b3JlKCkgOiBuZXcgV2ViU29ja2V0TWVtb3J5Q2xpZW50U3RvcmUoKTtcblx0XHR0aGlzLnJ1bnRpbWVDbGllbnRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLmFsbENsaWVudHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuY2hhbm5lbC5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCAobWVzc2FnZSkgPT4ge1xuXHRcdFx0aWYgKG1lc3NhZ2UuZGF0YT8udHlwZSA9PT0gXCJkYjp1cGRhdGVcIikgdGhpcy5mbHVzaERhdGFiYXNlVG9NZW1vcnkoKTtcblx0XHR9KTtcblx0XHRpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIGFzeW5jIChtZXNzYWdlKSA9PiB7XG5cdFx0XHRpZiAobWVzc2FnZS5kYXRhPy50eXBlID09PSBcIm1zdy93b3JrZXI6c3RvcFwiKSBhd2FpdCB0aGlzLnJlbW92ZVJ1bnRpbWVDbGllbnRzKCk7XG5cdFx0fSk7XG5cdH1cblx0YXN5bmMgZmx1c2hEYXRhYmFzZVRvTWVtb3J5KCkge1xuXHRcdGNvbnN0IHN0b3JlZENsaWVudHMgPSBhd2FpdCB0aGlzLnN0b3JlLmdldEFsbCgpO1xuXHRcdHRoaXMuYWxsQ2xpZW50cyA9IG5ldyBTZXQoc3RvcmVkQ2xpZW50cy5tYXAoKGNsaWVudCkgPT4ge1xuXHRcdFx0Y29uc3QgcnVudGltZUNsaWVudCA9IHRoaXMucnVudGltZUNsaWVudHMuZ2V0KGNsaWVudC5pZCk7XG5cdFx0XHQvKipcblx0XHRcdCogQG5vdGUgRm9yIGNsaWVudHMgb3JpZ2luYXRpbmcgaW4gdGhpcyBydW50aW1lLCB1c2UgdGhlaXJcblx0XHRcdCogZGlyZWN0IHJlZmVyZW5jZXMuIE5vIG5lZWQgdG8gd3JhcCB0aGVtIGluIGEgcmVtb3RlIGNvbm5lY3Rpb24uXG5cdFx0XHQqL1xuXHRcdFx0aWYgKHJ1bnRpbWVDbGllbnQpIHJldHVybiBydW50aW1lQ2xpZW50O1xuXHRcdFx0cmV0dXJuIG5ldyBXZWJTb2NrZXRSZW1vdGVDbGllbnRDb25uZWN0aW9uKGNsaWVudC5pZCwgbmV3IFVSTChjbGllbnQudXJsKSwgdGhpcy5jaGFubmVsKTtcblx0XHR9KSk7XG5cdH1cblx0YXN5bmMgcmVtb3ZlUnVudGltZUNsaWVudHMoKSB7XG5cdFx0YXdhaXQgdGhpcy5zdG9yZS5kZWxldGVNYW55KEFycmF5LmZyb20odGhpcy5ydW50aW1lQ2xpZW50cy5rZXlzKCkpKTtcblx0XHR0aGlzLnJ1bnRpbWVDbGllbnRzLmNsZWFyKCk7XG5cdFx0YXdhaXQgdGhpcy5mbHVzaERhdGFiYXNlVG9NZW1vcnkoKTtcblx0XHR0aGlzLm5vdGlmeU90aGVyc0Fib3V0RGF0YWJhc2VVcGRhdGUoKTtcblx0fVxuXHQvKipcblx0KiBBbGwgYWN0aXZlIFdlYlNvY2tldCBjbGllbnQgY29ubmVjdGlvbnMuXG5cdCovXG5cdGdldCBjbGllbnRzKCkge1xuXHRcdHJldHVybiB0aGlzLmFsbENsaWVudHM7XG5cdH1cblx0LyoqXG5cdCogTm90aWZ5IG90aGVyIHJ1bnRpbWVzIGFib3V0IHRoZSBkYXRhYmFzZSB1cGRhdGVcblx0KiB1c2luZyB0aGUgc2hhcmVkIGBCcm9hZGNhc3RDaGFubmVsYCBpbnN0YW5jZS5cblx0Ki9cblx0bm90aWZ5T3RoZXJzQWJvdXREYXRhYmFzZVVwZGF0ZSgpIHtcblx0XHR0aGlzLmNoYW5uZWwucG9zdE1lc3NhZ2UoeyB0eXBlOiBcImRiOnVwZGF0ZVwiIH0pO1xuXHR9XG5cdGFzeW5jIGFkZENsaWVudChjbGllbnQpIHtcblx0XHRhd2FpdCB0aGlzLnN0b3JlLmFkZChjbGllbnQpO1xuXHRcdGF3YWl0IHRoaXMuZmx1c2hEYXRhYmFzZVRvTWVtb3J5KCk7XG5cdFx0dGhpcy5ub3RpZnlPdGhlcnNBYm91dERhdGFiYXNlVXBkYXRlKCk7XG5cdH1cblx0LyoqXG5cdCogQWRkcyB0aGUgZ2l2ZW4gYFdlYlNvY2tldGAgY2xpZW50IGNvbm5lY3Rpb24gdG8gdGhlIHNldFxuXHQqIG9mIGFsbCBjb25uZWN0aW9ucy4gVGhlIGdpdmVuIGNvbm5lY3Rpb24gaXMgYWx3YXlzIHRoZSBjb21wbGV0ZVxuXHQqIGNvbm5lY3Rpb24gb2JqZWN0IGJlY2F1c2UgYGFkZENvbm5lY3Rpb24oKWAgaXMgY2FsbGVkIG9ubHlcblx0KiBmb3IgdGhlIG9wZW5lZCBjb25uZWN0aW9ucyBpbiB0aGUgc2FtZSBydW50aW1lLlxuXHQqL1xuXHRhc3luYyBhZGRDb25uZWN0aW9uKGNsaWVudCkge1xuXHRcdHRoaXMucnVudGltZUNsaWVudHMuc2V0KGNsaWVudC5pZCwgY2xpZW50KTtcblx0XHRhd2FpdCB0aGlzLmFkZENsaWVudChjbGllbnQpO1xuXHRcdGNvbnN0IGhhbmRsZUV4dHJhbmVvdXNNZXNzYWdlID0gKG1lc3NhZ2UpID0+IHtcblx0XHRcdGNvbnN0IHsgdHlwZSwgcGF5bG9hZCB9ID0gbWVzc2FnZS5kYXRhO1xuXHRcdFx0aWYgKHR5cGVvZiBwYXlsb2FkID09PSBcIm9iamVjdFwiICYmIFwiY2xpZW50SWRcIiBpbiBwYXlsb2FkICYmIHBheWxvYWQuY2xpZW50SWQgIT09IGNsaWVudC5pZCkgcmV0dXJuO1xuXHRcdFx0c3dpdGNoICh0eXBlKSB7XG5cdFx0XHRcdGNhc2UgXCJleHRyYW5lb3VzOnNlbmRcIjpcblx0XHRcdFx0XHRjbGllbnQuc2VuZChwYXlsb2FkLmRhdGEpO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRjYXNlIFwiZXh0cmFuZW91czpjbG9zZVwiOiBjbGllbnQuY2xvc2UocGF5bG9hZC5jb2RlLCBwYXlsb2FkLnJlYXNvbik7XG5cdFx0XHR9XG5cdFx0fTtcblx0XHRjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdFx0dGhpcy5jaGFubmVsLmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIGhhbmRsZUV4dHJhbmVvdXNNZXNzYWdlLCB7IHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbCB9KTtcblx0XHRjbGllbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsb3NlXCIsICgpID0+IGFib3J0Q29udHJvbGxlci5hYm9ydCgpLCB7IG9uY2U6IHRydWUgfSk7XG5cdH1cbn07XG4vKipcbiogQSB3cmFwcGVyIGNsYXNzIHRvIG9wZXJhdGUgd2l0aCBXZWJTb2NrZXQgY2xpZW50IGNvbm5lY3Rpb25zXG4qIGZyb20gb3RoZXIgcnVudGltZXMuIFRoaXMgY2xhc3MgbWFpbnRhaW5zIDEtMSBwdWJsaWMgQVBJXG4qIGNvbXBhdGliaWxpdHkgdG8gdGhlIGBXZWJTb2NrZXRDbGllbnRDb25uZWN0aW9uYCBidXQgcmVsaWVzXG4qIG9uIHRoZSBnaXZlbiBgQnJvYWRjYXN0Q2hhbm5lbGAgdG8gY29tbXVuaWNhdGUgaW5zdHJ1Y3Rpb25zXG4qIHdpdGggdGhlIGNsaWVudCBjb25uZWN0aW9ucyBmcm9tIG90aGVyIHJ1bnRpbWVzLlxuKi9cbnZhciBXZWJTb2NrZXRSZW1vdGVDbGllbnRDb25uZWN0aW9uID0gY2xhc3Mge1xuXHRpZDtcblx0dXJsO1xuXHRjaGFubmVsO1xuXHRjb25zdHJ1Y3RvcihpZCwgdXJsLCBjaGFubmVsKSB7XG5cdFx0dGhpcy5pZCA9IGlkO1xuXHRcdHRoaXMudXJsID0gdXJsO1xuXHRcdHRoaXMuY2hhbm5lbCA9IGNoYW5uZWw7XG5cdH1cblx0c2VuZChkYXRhKSB7XG5cdFx0dGhpcy5jaGFubmVsLnBvc3RNZXNzYWdlKHtcblx0XHRcdHR5cGU6IFwiZXh0cmFuZW91czpzZW5kXCIsXG5cdFx0XHRwYXlsb2FkOiB7XG5cdFx0XHRcdGNsaWVudElkOiB0aGlzLmlkLFxuXHRcdFx0XHRkYXRhXG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0Y2xvc2UoY29kZSwgcmVhc29uKSB7XG5cdFx0dGhpcy5jaGFubmVsLnBvc3RNZXNzYWdlKHtcblx0XHRcdHR5cGU6IFwiZXh0cmFuZW91czpjbG9zZVwiLFxuXHRcdFx0cGF5bG9hZDoge1xuXHRcdFx0XHRjbGllbnRJZDogdGhpcy5pZCxcblx0XHRcdFx0Y29kZSxcblx0XHRcdFx0cmVhc29uXG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0YWRkRXZlbnRMaXN0ZW5lcihfdHlwZSwgX2xpc3RlbmVyLCBfb3B0aW9ucykge1xuXHRcdHRocm93IG5ldyBFcnJvcihcIldlYlNvY2tldFJlbW90ZUNsaWVudENvbm5lY3Rpb24uYWRkRXZlbnRMaXN0ZW5lciBpcyBub3Qgc3VwcG9ydGVkXCIpO1xuXHR9XG5cdHJlbW92ZUV2ZW50TGlzdGVuZXIoX2V2ZW50LCBfbGlzdGVuZXIsIF9vcHRpb25zKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKFwiV2ViU29ja2V0UmVtb3RlQ2xpZW50Q29ubmVjdGlvbi5yZW1vdmVFdmVudExpc3RlbmVyIGlzIG5vdCBzdXBwb3J0ZWRcIik7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvd3Mvd3MudHNcbmNvbnN0IHdlYlNvY2tldENoYW5uZWwgPSBuZXcgQnJvYWRjYXN0Q2hhbm5lbChcIm1zdzp3ZWJzb2NrZXQtY2xpZW50LW1hbmFnZXJcIik7XG5pZiAoaGFzUmVmQ291bnRlZCh3ZWJTb2NrZXRDaGFubmVsKSkgd2ViU29ja2V0Q2hhbm5lbC51bnJlZigpO1xuLyoqXG4qIEludGVyY2VwdHMgb3V0Z29pbmcgV2ViU29ja2V0IGNvbm5lY3Rpb25zIHRvIHRoZSBnaXZlbiBVUkwuXG4qXG4qIEBleGFtcGxlXG4qIGNvbnN0IGNoYXQgPSB3cy5saW5rKCd3c3M6Ly9jaGF0LmV4YW1wbGUuY29tJylcbiogY2hhdC5hZGRFdmVudExpc3RlbmVyKCdjb25uZWN0aW9uJywgKHsgY2xpZW50IH0pID0+IHtcbiogICBjbGllbnQuc2VuZCgnaGVsbG8gZnJvbSBzZXJ2ZXIhJylcbiogfSlcbiovXG5mdW5jdGlvbiBjcmVhdGVXZWJTb2NrZXRMaW5rSGFuZGxlcih1cmwsIG9wdGlvbnMpIHtcblx0aW52YXJpYW50KHVybCwgXCJFeHBlY3RlZCBhIFdlYlNvY2tldCBzZXJ2ZXIgVVJMIGJ1dCBnb3QgdW5kZWZpbmVkXCIpO1xuXHRpbnZhcmlhbnQoaXNQYXRoKHVybCksIFwiRXhwZWN0ZWQgYSBXZWJTb2NrZXQgc2VydmVyIFVSTCB0byBiZSBhIHZhbGlkIHBhdGggYnV0IGdvdCAlc1wiLCB0eXBlb2YgdXJsKTtcblx0Y29uc3QgY2xpZW50TWFuYWdlciA9IG5ldyBXZWJTb2NrZXRDbGllbnRNYW5hZ2VyKHdlYlNvY2tldENoYW5uZWwpO1xuXHRjb25zdCB1cGdyYWRlSGFuZGxlciA9IGNyZWF0ZVdlYlNvY2tldFVwZ3JhZGVIYW5kbGVyKHVybCwgKGluZm8pID0+IHtcblx0XHRyZXR1cm4gd3Mub25VcGdyYWRlKGluZm8pO1xuXHR9KTtcblx0cmV0dXJuIHtcblx0XHRnZXQgY2xpZW50cygpIHtcblx0XHRcdHJldHVybiBjbGllbnRNYW5hZ2VyLmNsaWVudHM7XG5cdFx0fSxcblx0XHRhZGRFdmVudExpc3RlbmVyKGV2ZW50LCBsaXN0ZW5lcikge1xuXHRcdFx0Y29uc3Qgd2ViU29ja2V0SGFuZGxlciA9IG5ldyBXZWJTb2NrZXRIYW5kbGVyKHVybCwgeyBleHRlbnNpb25zOiBvcHRpb25zPy5leHRlbnNpb25zIH0pO1xuXHRcdFx0d2ViU29ja2V0SGFuZGxlcltrRW1pdHRlcl0ub24oXCJjb25uZWN0aW9uXCIsIGFzeW5jICh7IGNsaWVudCB9KSA9PiB7XG5cdFx0XHRcdGF3YWl0IGNsaWVudE1hbmFnZXIuYWRkQ29ubmVjdGlvbihjbGllbnQpO1xuXHRcdFx0fSk7XG5cdFx0XHR3ZWJTb2NrZXRIYW5kbGVyW2tFbWl0dGVyXS5vbihldmVudCwgbGlzdGVuZXIpO1xuXHRcdFx0cmV0dXJuIGF0dGFjaFNpYmxpbmdIYW5kbGVycyh3ZWJTb2NrZXRIYW5kbGVyLCBbdXBncmFkZUhhbmRsZXJdKTtcblx0XHR9LFxuXHRcdGJyb2FkY2FzdChkYXRhKSB7XG5cdFx0XHR0aGlzLmJyb2FkY2FzdEV4Y2VwdChbXSwgZGF0YSk7XG5cdFx0fSxcblx0XHRicm9hZGNhc3RFeGNlcHQoY2xpZW50cywgZGF0YSkge1xuXHRcdFx0Y29uc3QgaWdub3JlQ2xpZW50cyA9IEFycmF5LnByb3RvdHlwZS5jb25jYXQoY2xpZW50cykubWFwKChjbGllbnQpID0+IGNsaWVudC5pZCk7XG5cdFx0XHRjbGllbnRNYW5hZ2VyLmNsaWVudHMuZm9yRWFjaCgob3RoZXJDbGllbnQpID0+IHtcblx0XHRcdFx0aWYgKCFpZ25vcmVDbGllbnRzLmluY2x1ZGVzKG90aGVyQ2xpZW50LmlkKSkgb3RoZXJDbGllbnQuc2VuZChkYXRhKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fTtcbn1cbi8qKlxuKiBBIG5hbWVzcGFjZSB0byBpbnRlcmNlcHQgYW5kIG1vY2sgV2ViU29ja2V0IGNvbm5lY3Rpb25zLlxuKlxuKiBAZXhhbXBsZVxuKiBjb25zdCBjaGF0ID0gd3MubGluaygnd3NzOi8vY2hhdC5leGFtcGxlLmNvbScpXG4qXG4qIEBzZWUge0BsaW5rIGh0dHBzOi8vbXN3anMuaW8vZG9jcy9hcGkvd3MgYHdzYCBBUEkgcmVmZXJlbmNlfVxuKiBAc2VlIHtAbGluayBodHRwczovL21zd2pzLmlvL2RvY3MvYmFzaWNzL2hhbmRsaW5nLXdlYnNvY2tldC1ldmVudHMgSGFuZGxpbmcgV2ViU29ja2V0IGV2ZW50c31cbiovXG5jb25zdCB3cyA9IHtcblx0bGluazogY3JlYXRlV2ViU29ja2V0TGlua0hhbmRsZXIsXG5cdG9uVXBncmFkZTogd2ViU29ja2V0VXBncmFkZVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgd3MgYXMgdCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD13cy5qcy5tYXAiLCJpbXBvcnQgeyB0IGFzIGhhc1JlZkNvdW50ZWQgfSBmcm9tIFwiLi4vX2NodW5rcy9oYXMtcmVmLWNvdW50ZWQuanNcIjtcbmltcG9ydCB7IGlzTm9kZVByb2Nlc3MgfSBmcm9tIFwiaXMtbm9kZS1wcm9jZXNzXCI7XG4vLyNyZWdpb24gc3JjL3V0aWxzL2RlbGF5LnRzXG5jb25zdCBTRVRfVElNRU9VVF9NQVhfQUxMT1dFRF9JTlQgPSAyMTQ3NDgzNjQ3O1xuY29uc3QgTUlOX1NFUlZFUl9SRVNQT05TRV9USU1FID0gMTAwO1xuY29uc3QgTk9ERV9TRVJWRVJfUkVTUE9OU0VfVElNRSA9IDU7XG5mdW5jdGlvbiBnZXRSZWFsaXN0aWNSZXNwb25zZVRpbWUoKSB7XG5cdGlmIChpc05vZGVQcm9jZXNzKCkpIHJldHVybiBOT0RFX1NFUlZFUl9SRVNQT05TRV9USU1FO1xuXHRyZXR1cm4gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMzAwICsgTUlOX1NFUlZFUl9SRVNQT05TRV9USU1FKTtcbn1cbi8qKlxuKiBEZWxheXMgdGhlIHJlc3BvbnNlIGJ5IHRoZSBnaXZlbiBkdXJhdGlvbiAobXMpLlxuKlxuKiBAZXhhbXBsZVxuKiBhd2FpdCBkZWxheSgpIC8vIGVtdWxhdGUgcmVhbGlzdGljIHNlcnZlciByZXNwb25zZSB0aW1lXG4qIGF3YWl0IGRlbGF5KDEyMDApIC8vIGRlbGF5IHJlc3BvbnNlIGJ5IDEyMDBtc1xuKiBhd2FpdCBkZWxheSgnaW5maW5pdGUnKSAvLyBkZWxheSByZXNwb25zZSBpbmZpbml0ZWx5XG4qXG4qIEBzZWUge0BsaW5rIGh0dHBzOi8vbXN3anMuaW8vZG9jcy9hcGkvZGVsYXkgYGRlbGF5KClgIEFQSSByZWZlcmVuY2V9XG4qL1xuYXN5bmMgZnVuY3Rpb24gZGVsYXkoZHVyYXRpb25Pck1vZGUpIHtcblx0bGV0IGRlbGF5VGltZTtcblx0aWYgKHR5cGVvZiBkdXJhdGlvbk9yTW9kZSA9PT0gXCJzdHJpbmdcIikgc3dpdGNoIChkdXJhdGlvbk9yTW9kZSkge1xuXHRcdGNhc2UgXCJpbmZpbml0ZVwiOlxuXHRcdFx0ZGVsYXlUaW1lID0gU0VUX1RJTUVPVVRfTUFYX0FMTE9XRURfSU5UO1xuXHRcdFx0YnJlYWs7XG5cdFx0Y2FzZSBcInJlYWxcIjpcblx0XHRcdGRlbGF5VGltZSA9IGdldFJlYWxpc3RpY1Jlc3BvbnNlVGltZSgpO1xuXHRcdFx0YnJlYWs7XG5cdFx0ZGVmYXVsdDogdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gZGVsYXkgYSByZXNwb25zZTogdW5rbm93biBkZWxheSBtb2RlIFwiJHtkdXJhdGlvbk9yTW9kZX1cIi4gUGxlYXNlIG1ha2Ugc3VyZSB5b3UgcHJvdmlkZSBvbmUgb2YgdGhlIHN1cHBvcnRlZCBtb2RlcyAoXCJyZWFsXCIsIFwiaW5maW5pdGVcIikgb3IgYSBudW1iZXIuYCk7XG5cdH1cblx0ZWxzZSBpZiAodHlwZW9mIGR1cmF0aW9uT3JNb2RlID09PSBcInVuZGVmaW5lZFwiKSBkZWxheVRpbWUgPSBnZXRSZWFsaXN0aWNSZXNwb25zZVRpbWUoKTtcblx0ZWxzZSB7XG5cdFx0aWYgKGR1cmF0aW9uT3JNb2RlID4gU0VUX1RJTUVPVVRfTUFYX0FMTE9XRURfSU5UKSB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBkZWxheSBhIHJlc3BvbnNlOiBwcm92aWRlZCBkZWxheSBkdXJhdGlvbiAoJHtkdXJhdGlvbk9yTW9kZX0pIGV4Y2VlZHMgdGhlIG1heGltdW0gYWxsb3dlZCBkdXJhdGlvbiBmb3IgXCJzZXRUaW1lb3V0XCIgKCR7U0VUX1RJTUVPVVRfTUFYX0FMTE9XRURfSU5UfSkuIFRoaXMgd2lsbCBjYXVzZSB0aGUgcmVzcG9uc2UgdG8gYmUgcmV0dXJuZWQgaW1tZWRpYXRlbHkuIFBsZWFzZSB1c2UgYSBudW1iZXIgd2l0aGluIHRoZSBhbGxvd2VkIHJhbmdlIHRvIGRlbGF5IHRoZSByZXNwb25zZSBieSBleGFjdCBkdXJhdGlvbiwgb3IgY29uc2lkZXIgdGhlIFwiaW5maW5pdGVcIiBkZWxheSBtb2RlIHRvIGRlbGF5IHRoZSByZXNwb25zZSBpbmRlZmluaXRlbHkuYCk7XG5cdFx0ZGVsYXlUaW1lID0gZHVyYXRpb25Pck1vZGU7XG5cdH1cblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0Y29uc3QgdGltZW91dElkID0gc2V0VGltZW91dChyZXNvbHZlLCBkZWxheVRpbWUpO1xuXHRcdGlmIChkZWxheVRpbWUgPT09IFNFVF9USU1FT1VUX01BWF9BTExPV0VEX0lOVCAmJiBpc05vZGVQcm9jZXNzKCkgJiYgaGFzUmVmQ291bnRlZCh0aW1lb3V0SWQpKSB0aW1lb3V0SWQudW5yZWYoKTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGRlbGF5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRlbGF5LmpzLm1hcCIsImltcG9ydCB7IGggYXMgZGV2VXRpbHMsIHIgYXMgdG9QdWJsaWNVcmwsIHMgYXMgZ2V0VGltZXN0YW1wIH0gZnJvbSBcIi4vY29va2llLXN0b3JlLmpzXCI7XG5pbXBvcnQgeyB0IGFzIEh0dHBIYW5kbGVyIH0gZnJvbSBcIi4vaHR0cC1oYW5kbGVyLmpzXCI7XG5pbXBvcnQgeyB0IGFzIGNvbG9ycyB9IGZyb20gXCIuL2NvbG9ycy5qc1wiO1xuaW1wb3J0IHsgZGVsYXkgfSBmcm9tIFwiLi4vdXRpbHMvZGVsYXkuanNcIjtcbmltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCJvdXR2YXJpYW50XCI7XG5pbXBvcnQgeyBFbWl0dGVyLCBUeXBlZEV2ZW50IH0gZnJvbSBcInJldHRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvc3NlL3NzZS50c1xuLyoqXG4qIEludGVyY2VwdCBTZXJ2ZXItU2VudCBFdmVudHMgKFNTRSkuXG4qXG4qIEBleGFtcGxlXG4qIHNzZSgnaHR0cDovL2xvY2FsaG9zdDo0MzIxJywgKHsgY2xpZW50IH0pID0+IHtcbiogICBjbGllbnQuc2VuZCh7IGRhdGE6ICdoZWxsbyB3b3JsZCcgfSlcbiogfSlcbipcbiogQHNlZSB7QGxpbmsgaHR0cHM6Ly9tc3dqcy5pby9kb2NzL3NzZS8gTW9ja2luZyBTZXJ2ZXItU2VudCBFdmVudHN9XG4qIEBzZWUge0BsaW5rIGh0dHBzOi8vbXN3anMuaW8vZG9jcy9hcGkvc3NlIGBzc2UoKWAgQVBJIHJlZmVyZW5jZX1cbiovXG5jb25zdCBzc2UgPSAocGF0aCwgcmVzb2x2ZXIpID0+IHtcblx0cmV0dXJuIG5ldyBTZXJ2ZXJTZW50RXZlbnRIYW5kbGVyKHBhdGgsIHJlc29sdmVyKTtcbn07XG5jb25zdCBTU0VfUkVTUE9OU0VfSU5JVCA9IHsgaGVhZGVyczoge1xuXHRcImNvbnRlbnQtdHlwZVwiOiBcInRleHQvZXZlbnQtc3RyZWFtXCIsXG5cdFwiY2FjaGUtY29udHJvbFwiOiBcIm5vLWNhY2hlXCIsXG5cdGNvbm5lY3Rpb246IFwia2VlcC1hbGl2ZVwiXG59IH07XG52YXIgU2VydmVyU2VudEV2ZW50SGFuZGxlciA9IGNsYXNzIGV4dGVuZHMgSHR0cEhhbmRsZXIge1xuXHQjbG9nZ2FibGVSZXF1ZXN0cztcblx0Y29uc3RydWN0b3IocGF0aCwgcmVzb2x2ZXIpIHtcblx0XHRpbnZhcmlhbnQodHlwZW9mIEV2ZW50U291cmNlICE9PSBcInVuZGVmaW5lZFwiLCBcIkZhaWxlZCB0byBjb25zdHJ1Y3QgYSBTZXJ2ZXItU2VudCBFdmVudCBoYW5kbGVyIGZvciBwYXRoIFxcXCIlc1xcXCI6IHRoZSBFdmVudFNvdXJjZSBBUEkgaXMgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGVudmlyb25tZW50XCIsIHBhdGgpO1xuXHRcdHN1cGVyKFwiR0VUXCIsIHBhdGgsIGFzeW5jIChpbmZvKSA9PiB7XG5cdFx0XHRjb25zdCB7IGNsaWVudCwgc2VydmVyLCByZXNwb25zZSB9ID0gY3JlYXRlRXZlbnRTdHJlYW0oaW5mby5yZXF1ZXN0KTtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBTY29wZSB0aGUgZW1pdHRlciB0byB0aGlzIGNvbm5lY3Rpb24gc28gaXRzIGxvZ2dpbmdcblx0XHRcdCogbGlzdGVuZXJzIGRvbid0IGFjY3VtdWxhdGUgb24gdGhlIGhhbmRsZXIgYWNyb3NzIGNvbm5lY3Rpb25zLlxuXHRcdFx0Ki9cblx0XHRcdGNvbnN0IGVtaXR0ZXIgPSBuZXcgRW1pdHRlcigpO1xuXHRcdFx0Y2xpZW50W2tDbGllbnRFbWl0dGVyXSA9IGVtaXR0ZXI7XG5cdFx0XHRpZiAodGhpcy4jbG9nZ2FibGVSZXF1ZXN0cy5oYXMoaW5mby5yZXF1ZXN0KSkgdGhpcy4jYXR0YWNoQ2xpZW50TG9nZ2VyKGluZm8ucmVxdWVzdCwgZW1pdHRlcik7XG5cdFx0XHQvKipcblx0XHRcdCogQG5vdGUgRXh0ZW5kIHRoZSByZXNvbHZlciBpbmZvIHZpYSBhc3NpZ25tZW50IGluc3RlYWQgb2YgYSBzcHJlYWQuXG5cdFx0XHQqIFNwcmVhZGluZyB0aGUgaW5mbyB3b3VsZCBpbnZva2UgaXRzIGxhenkgYGZpbmFsaXplYCBnZXR0ZXIsXG5cdFx0XHQqIGluaXRpYWxpemluZyB0aGUgZmluYWxpemUgbWFjaGluZXJ5IGZvciByZXNvbHZlcnMgdGhhdCBuZXZlciB1c2UgaXQuXG5cdFx0XHQqL1xuXHRcdFx0YXdhaXQgcmVzb2x2ZXIoT2JqZWN0LmFzc2lnbihpbmZvLCB7XG5cdFx0XHRcdGNsaWVudCxcblx0XHRcdFx0c2VydmVyXG5cdFx0XHR9KSk7XG5cdFx0XHRyZXR1cm4gcmVzcG9uc2U7XG5cdFx0fSk7XG5cdFx0dGhpcy4jbG9nZ2FibGVSZXF1ZXN0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha1NldCgpO1xuXHR9XG5cdGFzeW5jIHByZWRpY2F0ZShhcmdzKSB7XG5cdFx0aWYgKGFyZ3MucmVxdWVzdC5oZWFkZXJzLmdldChcImFjY2VwdFwiKSAhPT0gXCJ0ZXh0L2V2ZW50LXN0cmVhbVwiKSByZXR1cm4gZmFsc2U7XG5cdFx0Y29uc3QgbWF0Y2hlcyA9IGF3YWl0IHN1cGVyLnByZWRpY2F0ZShhcmdzKTtcblx0XHRpZiAobWF0Y2hlcyAmJiAhYXJncy5yZXNvbHV0aW9uQ29udGV4dD8ucXVpZXQpIHtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBMb2cgdGhlIGludGVyY2VwdGVkIHJlcXVlc3QgZWFybHkuXG5cdFx0XHQqIE5vcm1hbGx5LCB0aGUgYHRoaXMubG9nKClgIG1ldGhvZCBpcyBjYWxsZWQgd2hlbiB0aGUgaGFuZGxlciByZXR1cm5zIGEgcmVzcG9uc2UuXG5cdFx0XHQqIEZvciBTU0UsIGNhbGwgdGhhdCBtZXRob2QgZWFybGllciBzbyB0aGUgbG9ncyBhcmUgaW4gY29ycmVjdCBvcmRlci5cblx0XHRcdCovXG5cdFx0XHRhd2FpdCBzdXBlci5sb2coe1xuXHRcdFx0XHRyZXF1ZXN0OiBhcmdzLnJlcXVlc3QsXG5cdFx0XHRcdC8qKlxuXHRcdFx0XHQqIEBub3RlIENvbnN0cnVjdCBhIHBsYWNlaG9sZGVyIHJlc3BvbnNlIHNpbmNlIFNTRSByZXNwb25zZVxuXHRcdFx0XHQqIGlzIGJlaW5nIHN0cmVhbWVkIGFuZCBjYW5ub3QgYmUgY2xvbmVkL2NvbnN1bWVkIGZvciBsb2dnaW5nLlxuXHRcdFx0XHQqL1xuXHRcdFx0XHRyZXNwb25zZTogbmV3IFJlc3BvbnNlKFwiW3N0cmVhbWluZ11cIiwgU1NFX1JFU1BPTlNFX0lOSVQpXG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuI2xvZ2dhYmxlUmVxdWVzdHMuYWRkKGFyZ3MucmVxdWVzdCk7XG5cdFx0fVxuXHRcdHJldHVybiBtYXRjaGVzO1xuXHR9XG5cdGFzeW5jIGxvZyhhcmdzKSB7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBDYW5jZWwgdGhlIHJlc3BvbnNlIHN0cmVhbSBiZWNhdXNlIGl0J3Mgbm90IG5lZWRlZCBmb3IgbG9nZ2luZy5cblx0XHQqIE90aGVyd2lzZSwgdGhpcyBjbG9uZWQgcmVzcG9uc2UgcmVtYWlucyB1bmNvbnN1bWVkIGFuZCBpdHMgb3JpZ2luYWxcblx0XHQqIGRvZXNuJ3QgcHJvcGFnYXRlIHN0cmVhbSBjYW5jZWxhdGlvbnMgYXQgYWxsLlxuXHRcdCovXG5cdFx0YXJncy5yZXNwb25zZS5ib2R5Py5jYW5jZWwoKTtcblx0fVxuXHQjYXR0YWNoQ2xpZW50TG9nZ2VyKHJlcXVlc3QsIGVtaXR0ZXIpIHtcblx0XHRjb25zdCBwdWJsaWNVcmwgPSB0b1B1YmxpY1VybChyZXF1ZXN0LnVybCk7XG5cdFx0ZW1pdHRlci5vbihcIm1lc3NhZ2VcIiwgKHsgZGF0YSB9KSA9PiB7XG5cdFx0XHRjb25zb2xlLmdyb3VwQ29sbGFwc2VkKGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoYCR7Z2V0VGltZXN0YW1wKCl9IFNTRSAlcyAlY+KHoyVjICR7ZGF0YS5ldmVudH1gKSwgcHVibGljVXJsLCBgY29sb3I6JHtjb2xvcnMubW9ja2VkfWAsIFwiY29sb3I6aW5oZXJpdFwiKTtcblx0XHRcdGNvbnNvbGUubG9nKGRhdGEuZnJhbWVzKTtcblx0XHRcdGNvbnNvbGUuZ3JvdXBFbmQoKTtcblx0XHR9KTtcblx0XHRlbWl0dGVyLm9uKFwiZXJyb3JcIiwgKCkgPT4ge1xuXHRcdFx0Y29uc29sZS5ncm91cENvbGxhcHNlZChkZXZVdGlscy5mb3JtYXRNZXNzYWdlKGAke2dldFRpbWVzdGFtcCgpfSBTU0UgJXMgJWNcXHUwMEQ3JWMgZXJyb3JgKSwgcHVibGljVXJsLCBgY29sb3I6ICR7Y29sb3JzLnN5c3RlbX1gLCBcImNvbG9yOmluaGVyaXRcIik7XG5cdFx0XHRjb25zb2xlLmxvZyhcIkhhbmRsZXI6XCIsIHRoaXMpO1xuXHRcdFx0Y29uc29sZS5ncm91cEVuZCgpO1xuXHRcdH0pO1xuXHRcdGVtaXR0ZXIub24oXCJjbG9zZVwiLCAoKSA9PiB7XG5cdFx0XHRjb25zb2xlLmdyb3VwQ29sbGFwc2VkKGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoYCR7Z2V0VGltZXN0YW1wKCl9IFNTRSAlcyAlY+KWoCVjIGNsb3NlYCksIHB1YmxpY1VybCwgYGNvbG9yczoke2NvbG9ycy5zeXN0ZW19YCwgXCJjb2xvcjppbmhlcml0XCIpO1xuXHRcdFx0Y29uc29sZS5sb2coXCJIYW5kbGVyOlwiLCB0aGlzKTtcblx0XHRcdGNvbnNvbGUuZ3JvdXBFbmQoKTtcblx0XHR9KTtcblx0fVxufTtcbmNvbnN0IGtDbGllbnRFbWl0dGVyID0gU3ltYm9sLmZvcihcImtDbGllbnRFbWl0dGVyXCIpO1xudmFyIFNlcnZlclNlbnRFdmVudENsaWVudCA9IGNsYXNzIHtcblx0W2tDbGllbnRFbWl0dGVyXTtcblx0I2VuY29kZXI7XG5cdCNjb250cm9sbGVyO1xuXHQjY2xvc2VkO1xuXHQjaXNDbG9zZWQ7XG5cdGNvbnN0cnVjdG9yKGNvbnRyb2xsZXIpIHtcblx0XHR0aGlzLiNlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG5cdFx0dGhpcy4jY29udHJvbGxlciA9IGNvbnRyb2xsZXI7XG5cdFx0dGhpcy4jY2xvc2VkID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0dGhpcy4jaXNDbG9zZWQgPSBmYWxzZTtcblx0fVxuXHQvKipcblx0KiBTZW5kcyB0aGUgZ2l2ZW4gcGF5bG9hZCB0byB0aGUgaW50ZXJjZXB0ZWQgYEV2ZW50U291cmNlYC5cblx0Ki9cblx0c2VuZChwYXlsb2FkKSB7XG5cdFx0aWYgKFwicmV0cnlcIiBpbiBwYXlsb2FkICYmIHBheWxvYWQucmV0cnkgIT0gbnVsbCkge1xuXHRcdFx0dGhpcy4jc2VuZFJldHJ5KHBheWxvYWQucmV0cnkpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHR0aGlzLiNzZW5kTWVzc2FnZSh7XG5cdFx0XHRpZDogcGF5bG9hZC5pZCxcblx0XHRcdGV2ZW50OiBwYXlsb2FkLmV2ZW50LFxuXHRcdFx0ZGF0YTogdHlwZW9mIHBheWxvYWQuZGF0YSA9PT0gXCJvYmplY3RcIiA/IEpTT04uc3RyaW5naWZ5KHBheWxvYWQuZGF0YSkgOiBwYXlsb2FkLmRhdGFcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBEaXNwYXRjaGVzIHRoZSBnaXZlbiBldmVudCBvbiB0aGUgaW50ZXJjZXB0ZWQgYEV2ZW50U291cmNlYC5cblx0Ki9cblx0ZGlzcGF0Y2hFdmVudChldmVudCkge1xuXHRcdGlmIChldmVudCBpbnN0YW5jZW9mIE1lc3NhZ2VFdmVudCkge1xuXHRcdFx0LyoqXG5cdFx0XHQqIEBub3RlIFVzZSB0aGUgaW50ZXJuYWwgc2VuZCBtZWNoYW5pc20gdG8gc2tpcCBub3JtYWxpemF0aW9uXG5cdFx0XHQqIG9mIHRoZSBtZXNzYWdlIGRhdGEgKGFscmVhZHkgbm9ybWFsaXplZCBieSB0aGUgc2VydmVyKS5cblx0XHRcdCovXG5cdFx0XHR0aGlzLiNzZW5kTWVzc2FnZSh7XG5cdFx0XHRcdGlkOiBldmVudC5sYXN0RXZlbnRJZCB8fCB2b2lkIDAsXG5cdFx0XHRcdGV2ZW50OiBldmVudC50eXBlID09PSBcIm1lc3NhZ2VcIiA/IHZvaWQgMCA6IGV2ZW50LnR5cGUsXG5cdFx0XHRcdGRhdGE6IGV2ZW50LmRhdGFcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoZXZlbnQudHlwZSA9PT0gXCJlcnJvclwiKSB7XG5cdFx0XHR0aGlzLmVycm9yKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChldmVudC50eXBlID09PSBcImNsb3NlXCIpIHtcblx0XHRcdHRoaXMuY2xvc2UoKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogRXJyb3JzIHRoZSB1bmRlcmx5aW5nIGBFdmVudFNvdXJjZWAsIGNsb3NpbmcgdGhlIGNvbm5lY3Rpb24gd2l0aCBhbiBlcnJvci5cblx0KiBUaGlzIGlzIGVxdWl2YWxlbnQgdG8gYWJvcnRpbmcgdGhlIGNvbm5lY3Rpb24gYW5kIHdpbGwgcHJvZHVjZSBhIGBUeXBlRXJyb3I6IEZhaWxlZCB0byBmZXRjaGBcblx0KiBlcnJvci5cblx0Ki9cblx0ZXJyb3IoKSB7XG5cdFx0aWYgKHRoaXMuI2lzQ2xvc2VkKSByZXR1cm47XG5cdFx0dGhpcy4jY29udHJvbGxlci5lcnJvcigpO1xuXHRcdHRoaXMuI2lzQ2xvc2VkID0gdHJ1ZTtcblx0XHR0aGlzLiNjbG9zZWQucmVzb2x2ZSgpO1xuXHRcdHRoaXNba0NsaWVudEVtaXR0ZXJdPy5lbWl0KG5ldyBUeXBlZEV2ZW50KFwiZXJyb3JcIikpO1xuXHR9XG5cdC8qKlxuXHQqIENsb3NlcyB0aGUgdW5kZXJseWluZyBgRXZlbnRTb3VyY2VgLCBjbG9zaW5nIHRoZSBjb25uZWN0aW9uLlxuXHQqL1xuXHRjbG9zZSgpIHtcblx0XHRpZiAodGhpcy4jaXNDbG9zZWQpIHJldHVybjtcblx0XHR0cnkge1xuXHRcdFx0dGhpcy4jY29udHJvbGxlci5jbG9zZSgpO1xuXHRcdFx0dGhpcy4jaXNDbG9zZWQgPSB0cnVlO1xuXHRcdFx0dGhpcy4jY2xvc2VkLnJlc29sdmUoKTtcblx0XHR9IGNhdGNoIHt9XG5cdFx0dGhpc1trQ2xpZW50RW1pdHRlcl0/LmVtaXQobmV3IFR5cGVkRXZlbnQoXCJjbG9zZVwiKSk7XG5cdH1cblx0I2VucXVldWUoY2h1bmspIHtcblx0XHRpZiAodGhpcy4jaXNDbG9zZWQpIHJldHVybjtcblx0XHR0cnkge1xuXHRcdFx0dGhpcy4jY29udHJvbGxlci5lbnF1ZXVlKGNodW5rKTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0Y29uc29sZS5lcnJvcihlcnJvcik7XG5cdFx0XHRkZXZVdGlscy5lcnJvcihcIkZhaWxlZCB0byB3cml0ZSB0byBzZXJ2ZXItc2lkZSBFdmVudFNvdXJjZS4gUGxlYXNlIHNlZSB0aGUgb3JpZ2luYWwgZXJyb3IgYWJvdmUuXCIpO1xuXHRcdH1cblx0fVxuXHQjc2VuZFJldHJ5KHJldHJ5KSB7XG5cdFx0dGhpcy4jZW5xdWV1ZSh0aGlzLiNlbmNvZGVyLmVuY29kZShgcmV0cnk6JHtyZXRyeX1cXG5cXG5gKSk7XG5cdH1cblx0I3NlbmRNZXNzYWdlKG1lc3NhZ2UpIHtcblx0XHRjb25zdCBmcmFtZXMgPSBbXTtcblx0XHRpZiAobWVzc2FnZS5pZCkgZnJhbWVzLnB1c2goYGlkOiR7bWVzc2FnZS5pZH1gKTtcblx0XHRpZiAobWVzc2FnZS5ldmVudCkgZnJhbWVzLnB1c2goYGV2ZW50OiR7bWVzc2FnZS5ldmVudC50b1N0cmluZygpfWApO1xuXHRcdGlmIChtZXNzYWdlLmRhdGEgIT0gbnVsbClcbiAvKipcblx0XHQqIFNwbGl0IGRhdGEgb24gbGluZSB0ZXJtaW5hdG9ycyAoTEYsIENSLCBvciBDUkxGKSBhbmQgdHJhbnNsYXRlIHRoZW0gdG8gaW5kaXZpZHVhbCBmcmFtZXMuXG5cdFx0KiBAc2VlIGh0dHBzOi8vaHRtbC5zcGVjLndoYXR3Zy5vcmcvbXVsdGlwYWdlL3NlcnZlci1zZW50LWV2ZW50cy5odG1sI2V2ZW50LXN0cmVhbS1pbnRlcnByZXRhdGlvblxuXHRcdCogQHNlZSBodHRwczovL2h0bWwuc3BlYy53aGF0d2cub3JnL211bHRpcGFnZS9zZXJ2ZXItc2VudC1ldmVudHMuaHRtbCNwYXJzaW5nLWFuLWV2ZW50LXN0cmVhbVxuXHRcdCovXG5cdFx0Zm9yIChjb25zdCBsaW5lIG9mIG1lc3NhZ2UuZGF0YS50b1N0cmluZygpLnNwbGl0KC9cXHJcXG58XFxyfFxcbi8pKSBmcmFtZXMucHVzaChgZGF0YToke2xpbmV9YCk7XG5cdFx0ZnJhbWVzLnB1c2goXCJcIiwgXCJcIik7XG5cdFx0dGhpcy4jZW5xdWV1ZSh0aGlzLiNlbmNvZGVyLmVuY29kZShmcmFtZXMuam9pbihcIlxcblwiKSkpO1xuXHRcdHRoaXNba0NsaWVudEVtaXR0ZXJdPy5lbWl0KG5ldyBUeXBlZEV2ZW50KFwibWVzc2FnZVwiLCB7IGRhdGE6IHtcblx0XHRcdGlkOiBtZXNzYWdlLmlkLFxuXHRcdFx0ZXZlbnQ6IG1lc3NhZ2UuZXZlbnQ/LnRvU3RyaW5nKCkgfHwgXCJtZXNzYWdlXCIsXG5cdFx0XHRkYXRhOiBtZXNzYWdlLmRhdGEsXG5cdFx0XHRmcmFtZXNcblx0XHR9IH0pKTtcblx0fVxufTtcbnZhciBTZXJ2ZXJTZW50RXZlbnRTZXJ2ZXIgPSBjbGFzcyB7XG5cdCNyZXF1ZXN0O1xuXHQjY2xpZW50O1xuXHRjb25zdHJ1Y3RvcihhcmdzKSB7XG5cdFx0dGhpcy4jcmVxdWVzdCA9IGFyZ3MucmVxdWVzdDtcblx0XHR0aGlzLiNjbGllbnQgPSBhcmdzLmNsaWVudDtcblx0fVxuXHQvKipcblx0KiBFc3RhYmxpc2hlcyB0aGUgYWN0dWFsIGNvbm5lY3Rpb24gZm9yIHRoaXMgU1NFIHJlcXVlc3Rcblx0KiBhbmQgcmV0dXJucyB0aGUgYEV2ZW50U291cmNlYCBpbnN0YW5jZS5cblx0Ki9cblx0Y29ubmVjdCgpIHtcblx0XHRjb25zdCBzb3VyY2UgPSBuZXcgT2JzZXJ2YWJsZUV2ZW50U291cmNlKHRoaXMuI3JlcXVlc3QudXJsLCB7XG5cdFx0XHR3aXRoQ3JlZGVudGlhbHM6IHRoaXMuI3JlcXVlc3QuY3JlZGVudGlhbHMgPT09IFwiaW5jbHVkZVwiLFxuXHRcdFx0aGVhZGVyczogeyBcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBNYXJrIHRoaXMgcmVxdWVzdCBhcyBwYXNzdGhyb3VnaCBzbyBpdCBkb2Vzbid0IHRyaWdnZXJcblx0XHRcdCogYW4gaW5maW5pdGUgbG9vcCBtYXRjaGluZyBhZ2FpbnN0IHRoZSBleGlzdGluZyByZXF1ZXN0IGhhbmRsZXIuXG5cdFx0XHQqL1xuYWNjZXB0OiBcIm1zdy9wYXNzdGhyb3VnaFwiIH0sXG5cdFx0XHRzaWduYWw6IHRoaXMuI3JlcXVlc3Quc2lnbmFsXG5cdFx0fSk7XG5cdFx0c291cmNlW2tPbkFueU1lc3NhZ2VdID0gKGV2ZW50KSA9PiB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydGllcyhldmVudCwgeyB0YXJnZXQ6IHtcblx0XHRcdFx0dmFsdWU6IHRoaXMsXG5cdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRcdHdyaXRhYmxlOiB0cnVlLFxuXHRcdFx0XHRjb25maWd1cmFibGU6IHRydWVcblx0XHRcdH0gfSk7XG5cdFx0XHRxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0XHRcdGlmICghZXZlbnQuZGVmYXVsdFByZXZlbnRlZCkgdGhpcy4jY2xpZW50LmRpc3BhdGNoRXZlbnQoZXZlbnQpO1xuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHRzb3VyY2UuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIChldmVudCkgPT4ge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZXZlbnQsIHsgdGFyZ2V0OiB7XG5cdFx0XHRcdHZhbHVlOiB0aGlzLFxuXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0XHR3cml0YWJsZTogdHJ1ZSxcblx0XHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdFx0XHR9IH0pO1xuXHRcdFx0cXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuXHRcdFx0XHRpZiAoIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHRoaXMuI2NsaWVudC5kaXNwYXRjaEV2ZW50KGV2ZW50KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdHJldHVybiBzb3VyY2U7XG5cdH1cbn07XG5jb25zdCBrUmVxdWVzdCA9IFN5bWJvbChcImtSZXF1ZXN0XCIpO1xuY29uc3Qga1JlY29ubmVjdGlvblRpbWUgPSBTeW1ib2woXCJrUmVjb25uZWN0aW9uVGltZVwiKTtcbmNvbnN0IGtMYXN0RXZlbnRJZCA9IFN5bWJvbChcImtMYXN0RXZlbnRJZFwiKTtcbmNvbnN0IGtBYm9ydENvbnRyb2xsZXIgPSBTeW1ib2woXCJrQWJvcnRDb250cm9sbGVyXCIpO1xuY29uc3Qga09uT3BlbiA9IFN5bWJvbChcImtPbk9wZW5cIik7XG5jb25zdCBrT25NZXNzYWdlID0gU3ltYm9sKFwia09uTWVzc2FnZVwiKTtcbmNvbnN0IGtPbkFueU1lc3NhZ2UgPSBTeW1ib2woXCJrT25BbnlNZXNzYWdlXCIpO1xuY29uc3Qga09uRXJyb3IgPSBTeW1ib2woXCJrT25FcnJvclwiKTtcbnZhciBPYnNlcnZhYmxlRXZlbnRTb3VyY2UgPSBjbGFzcyBPYnNlcnZhYmxlRXZlbnRTb3VyY2UgZXh0ZW5kcyBFdmVudFRhcmdldCB7XG5cdHN0YXRpYyBDT05ORUNUSU5HID0gMDtcblx0c3RhdGljIE9QRU4gPSAxO1xuXHRzdGF0aWMgQ0xPU0VEID0gMjtcblx0Q09OTkVDVElORyA9IE9ic2VydmFibGVFdmVudFNvdXJjZS5DT05ORUNUSU5HO1xuXHRPUEVOID0gT2JzZXJ2YWJsZUV2ZW50U291cmNlLk9QRU47XG5cdENMT1NFRCA9IE9ic2VydmFibGVFdmVudFNvdXJjZS5DTE9TRUQ7XG5cdHJlYWR5U3RhdGU7XG5cdHVybDtcblx0d2l0aENyZWRlbnRpYWxzO1xuXHRba1JlcXVlc3RdO1xuXHRba1JlY29ubmVjdGlvblRpbWVdO1xuXHRba0xhc3RFdmVudElkXTtcblx0W2tBYm9ydENvbnRyb2xsZXJdO1xuXHRba09uT3Blbl0gPSBudWxsO1xuXHRba09uTWVzc2FnZV0gPSBudWxsO1xuXHRba09uQW55TWVzc2FnZV0gPSBudWxsO1xuXHRba09uRXJyb3JdID0gbnVsbDtcblx0Y29uc3RydWN0b3IodXJsLCBpbml0KSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLnVybCA9IG5ldyBVUkwodXJsKS5ocmVmO1xuXHRcdHRoaXMud2l0aENyZWRlbnRpYWxzID0gaW5pdD8ud2l0aENyZWRlbnRpYWxzID8/IGZhbHNlO1xuXHRcdHRoaXMucmVhZHlTdGF0ZSA9IHRoaXMuQ09OTkVDVElORztcblx0XHRjb25zdCBoZWFkZXJzID0gbmV3IEhlYWRlcnMoaW5pdD8uaGVhZGVycyB8fCB7fSk7XG5cdFx0aGVhZGVycy5hcHBlbmQoXCJhY2NlcHRcIiwgXCJ0ZXh0L2V2ZW50LXN0cmVhbVwiKTtcblx0XHR0aGlzW2tBYm9ydENvbnRyb2xsZXJdID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXHRcdHRoaXNba1JlY29ubmVjdGlvblRpbWVdID0gMmUzO1xuXHRcdHRoaXNba0xhc3RFdmVudElkXSA9IFwiXCI7XG5cdFx0dGhpc1trUmVxdWVzdF0gPSBuZXcgUmVxdWVzdCh0aGlzLnVybCwge1xuXHRcdFx0bWV0aG9kOiBcIkdFVFwiLFxuXHRcdFx0aGVhZGVycyxcblx0XHRcdGNyZWRlbnRpYWxzOiB0aGlzLndpdGhDcmVkZW50aWFscyA/IFwiaW5jbHVkZVwiIDogXCJvbWl0XCIsXG5cdFx0XHRzaWduYWw6IHRoaXNba0Fib3J0Q29udHJvbGxlcl0uc2lnbmFsXG5cdFx0fSk7XG5cdFx0aWYgKGluaXQ/LnNpZ25hbCkge1xuXHRcdFx0aWYgKGluaXQuc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRcdFx0dGhpcy5jbG9zZSgpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRpbml0LnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgKCkgPT4gdGhpcy5jbG9zZSgpLCB7XG5cdFx0XHRcdG9uY2U6IHRydWUsXG5cdFx0XHRcdHNpZ25hbDogdGhpc1trQWJvcnRDb250cm9sbGVyXS5zaWduYWxcblx0XHRcdH0pO1xuXHRcdH1cblx0XHR0aGlzLmNvbm5lY3QoKTtcblx0fVxuXHRnZXQgb25vcGVuKCkge1xuXHRcdHJldHVybiB0aGlzW2tPbk9wZW5dO1xuXHR9XG5cdHNldCBvbm9wZW4oaGFuZGxlcikge1xuXHRcdGlmICh0aGlzW2tPbk9wZW5dKSB0aGlzLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJvcGVuXCIsIHRoaXNba09uT3Blbl0pO1xuXHRcdHRoaXNba09uT3Blbl0gPSBoYW5kbGVyLmJpbmQodGhpcyk7XG5cdFx0dGhpcy5hZGRFdmVudExpc3RlbmVyKFwib3BlblwiLCB0aGlzW2tPbk9wZW5dKTtcblx0fVxuXHRnZXQgb25tZXNzYWdlKCkge1xuXHRcdHJldHVybiB0aGlzW2tPbk1lc3NhZ2VdO1xuXHR9XG5cdHNldCBvbm1lc3NhZ2UoaGFuZGxlcikge1xuXHRcdGlmICh0aGlzW2tPbk1lc3NhZ2VdKSB0aGlzLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIHsgaGFuZGxlRXZlbnQ6IHRoaXNba09uTWVzc2FnZV0gfSk7XG5cdFx0dGhpc1trT25NZXNzYWdlXSA9IGhhbmRsZXIuYmluZCh0aGlzKTtcblx0XHR0aGlzLmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIHsgaGFuZGxlRXZlbnQ6IHRoaXNba09uTWVzc2FnZV0gfSk7XG5cdH1cblx0Z2V0IG9uZXJyb3IoKSB7XG5cdFx0cmV0dXJuIHRoaXNba09uRXJyb3JdO1xuXHR9XG5cdHNldCBvbmVycm9yKGhhbmRsZXIpIHtcblx0XHRpZiAodGhpc1trT25FcnJvcl0pIHRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIHsgaGFuZGxlRXZlbnQ6IHRoaXNba09uRXJyb3JdIH0pO1xuXHRcdHRoaXNba09uRXJyb3JdID0gaGFuZGxlci5iaW5kKHRoaXMpO1xuXHRcdHRoaXMuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIHsgaGFuZGxlRXZlbnQ6IHRoaXNba09uRXJyb3JdIH0pO1xuXHR9XG5cdGFkZEV2ZW50TGlzdGVuZXIodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcblx0XHRzdXBlci5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKTtcblx0fVxuXHRyZW1vdmVFdmVudExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKSB7XG5cdFx0c3VwZXIucmVtb3ZlRXZlbnRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucyk7XG5cdH1cblx0ZGlzcGF0Y2hFdmVudChldmVudCkge1xuXHRcdHJldHVybiBzdXBlci5kaXNwYXRjaEV2ZW50KGV2ZW50KTtcblx0fVxuXHRjbG9zZSgpIHtcblx0XHR0aGlzW2tBYm9ydENvbnRyb2xsZXJdLmFib3J0KCk7XG5cdFx0dGhpcy5yZWFkeVN0YXRlID0gdGhpcy5DTE9TRUQ7XG5cdH1cblx0YXN5bmMgY29ubmVjdCgpIHtcblx0XHRhd2FpdCBmZXRjaCh0aGlzW2tSZXF1ZXN0XSkudGhlbigocmVzcG9uc2UpID0+IHtcblx0XHRcdHRoaXMucHJvY2Vzc1Jlc3BvbnNlKHJlc3BvbnNlKTtcblx0XHR9KS5jYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLmZhaWxDb25uZWN0aW9uKCk7XG5cdFx0fSk7XG5cdH1cblx0cHJvY2Vzc1Jlc3BvbnNlKHJlc3BvbnNlKSB7XG5cdFx0aWYgKCFyZXNwb25zZS5ib2R5KSB7XG5cdFx0XHR0aGlzLmZhaWxDb25uZWN0aW9uKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChpc05ldHdvcmtFcnJvcihyZXNwb25zZSkpIHtcblx0XHRcdHRoaXMucmVlc3RhYmxpc2hDb25uZWN0aW9uKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChyZXNwb25zZS5zdGF0dXMgIT09IDIwMCB8fCByZXNwb25zZS5oZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKSAhPT0gXCJ0ZXh0L2V2ZW50LXN0cmVhbVwiKSB7XG5cdFx0XHR0aGlzLmZhaWxDb25uZWN0aW9uKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdHRoaXMuYW5ub3VuY2VDb25uZWN0aW9uKCk7XG5cdFx0dGhpcy5pbnRlcnByZXRSZXNwb25zZUJvZHkocmVzcG9uc2UpO1xuXHR9XG5cdGFubm91bmNlQ29ubmVjdGlvbigpIHtcblx0XHRxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0XHRpZiAodGhpcy5yZWFkeVN0YXRlICE9PSB0aGlzLkNMT1NFRCkge1xuXHRcdFx0XHR0aGlzLnJlYWR5U3RhdGUgPSB0aGlzLk9QRU47XG5cdFx0XHRcdHRoaXMuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJvcGVuXCIpKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHRpbnRlcnByZXRSZXNwb25zZUJvZHkocmVzcG9uc2UpIHtcblx0XHRjb25zdCBwYXJzaW5nU3RyZWFtID0gbmV3IEV2ZW50U291cmNlUGFyc2luZ1N0cmVhbSh7XG5cdFx0XHRtZXNzYWdlOiAobWVzc2FnZSkgPT4ge1xuXHRcdFx0XHRpZiAobWVzc2FnZS5pZCkgdGhpc1trTGFzdEV2ZW50SWRdID0gbWVzc2FnZS5pZDtcblx0XHRcdFx0Y29uc3QgbWVzc2FnZUV2ZW50ID0gbmV3IE1lc3NhZ2VFdmVudChtZXNzYWdlLmV2ZW50ID8gbWVzc2FnZS5ldmVudCA6IFwibWVzc2FnZVwiLCB7XG5cdFx0XHRcdFx0ZGF0YTogbWVzc2FnZS5kYXRhLFxuXHRcdFx0XHRcdG9yaWdpbjogdGhpc1trUmVxdWVzdF0udXJsLFxuXHRcdFx0XHRcdGxhc3RFdmVudElkOiB0aGlzW2tMYXN0RXZlbnRJZF0sXG5cdFx0XHRcdFx0Y2FuY2VsYWJsZTogdHJ1ZVxuXHRcdFx0XHR9KTtcblx0XHRcdFx0dGhpc1trT25BbnlNZXNzYWdlXT8uKG1lc3NhZ2VFdmVudCk7XG5cdFx0XHRcdHRoaXMuZGlzcGF0Y2hFdmVudChtZXNzYWdlRXZlbnQpO1xuXHRcdFx0fSxcblx0XHRcdHJldHJ5OiAocmVjb25uZWN0aW9uVGltZSkgPT4ge1xuXHRcdFx0XHR0aGlzW2tSZWNvbm5lY3Rpb25UaW1lXSA9IHJlY29ubmVjdGlvblRpbWU7XG5cdFx0XHR9LFxuXHRcdFx0YWJvcnQ6ICgpID0+IHtcblx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKFwiU3RyZWFtIGFib3J0IGlzIG5vdCBpbXBsZW1lbnRlZFwiKTtcblx0XHRcdH0sXG5cdFx0XHRjbG9zZTogKCkgPT4ge1xuXHRcdFx0XHR0aGlzLmZhaWxDb25uZWN0aW9uKCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0cmVzcG9uc2UuYm9keS5waXBlVG8ocGFyc2luZ1N0cmVhbSkudGhlbigoKSA9PiB7XG5cdFx0XHR0aGlzLnByb2Nlc3NSZXNwb25zZUVuZE9mQm9keShyZXNwb25zZSk7XG5cdFx0fSkuY2F0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy5mYWlsQ29ubmVjdGlvbigpO1xuXHRcdH0pO1xuXHR9XG5cdHByb2Nlc3NSZXNwb25zZUVuZE9mQm9keShyZXNwb25zZSkge1xuXHRcdGlmICghaXNOZXR3b3JrRXJyb3IocmVzcG9uc2UpKSB0aGlzLnJlZXN0YWJsaXNoQ29ubmVjdGlvbigpO1xuXHR9XG5cdGFzeW5jIHJlZXN0YWJsaXNoQ29ubmVjdGlvbigpIHtcblx0XHRxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0XHRpZiAodGhpcy5yZWFkeVN0YXRlID09PSB0aGlzLkNMT1NFRCkgcmV0dXJuO1xuXHRcdFx0dGhpcy5yZWFkeVN0YXRlID0gdGhpcy5DT05ORUNUSU5HO1xuXHRcdFx0dGhpcy5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImVycm9yXCIpKTtcblx0XHR9KTtcblx0XHRjb25zdCBzaWduYWwgPSB0aGlzW2tBYm9ydENvbnRyb2xsZXJdLnNpZ25hbDtcblx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIHJldHVybjtcblx0XHRjb25zdCBhYm9ydGVkID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0Y29uc3Qgb25BYm9ydCA9ICgpID0+IGFib3J0ZWQucmVzb2x2ZSgpO1xuXHRcdHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25BYm9ydCwgeyBvbmNlOiB0cnVlIH0pO1xuXHRcdGF3YWl0IFByb21pc2UucmFjZShbZGVsYXkodGhpc1trUmVjb25uZWN0aW9uVGltZV0pLCBhYm9ydGVkLnByb21pc2VdKS5maW5hbGx5KCgpID0+IHtcblx0XHRcdHNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25BYm9ydCk7XG5cdFx0fSk7XG5cdFx0aWYgKHNpZ25hbC5hYm9ydGVkKSByZXR1cm47XG5cdFx0cXVldWVNaWNyb3Rhc2soYXN5bmMgKCkgPT4ge1xuXHRcdFx0aWYgKHRoaXMucmVhZHlTdGF0ZSAhPT0gdGhpcy5DT05ORUNUSU5HKSByZXR1cm47XG5cdFx0XHRpZiAodGhpc1trTGFzdEV2ZW50SWRdICE9PSBcIlwiKSB0aGlzW2tSZXF1ZXN0XS5oZWFkZXJzLnNldChcImxhc3QtZXZlbnQtaWRcIiwgdGhpc1trTGFzdEV2ZW50SWRdKTtcblx0XHRcdGF3YWl0IHRoaXMuY29ubmVjdCgpO1xuXHRcdH0pO1xuXHR9XG5cdGZhaWxDb25uZWN0aW9uKCkge1xuXHRcdHF1ZXVlTWljcm90YXNrKCgpID0+IHtcblx0XHRcdGlmICh0aGlzLnJlYWR5U3RhdGUgIT09IHRoaXMuQ0xPU0VEKSB7XG5cdFx0XHRcdHRoaXMucmVhZHlTdGF0ZSA9IHRoaXMuQ0xPU0VEO1xuXHRcdFx0XHR0aGlzLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiZXJyb3JcIikpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG59O1xuLyoqXG4qIENoZWNrcyBpZiB0aGUgZ2l2ZW4gYFJlc3BvbnNlYCBpbnN0YW5jZSBpcyBhIG5ldHdvcmsgZXJyb3IuXG4qIEBzZWUgaHR0cHM6Ly9mZXRjaC5zcGVjLndoYXR3Zy5vcmcvI2NvbmNlcHQtbmV0d29yay1lcnJvclxuKi9cbmZ1bmN0aW9uIGlzTmV0d29ya0Vycm9yKHJlc3BvbnNlKSB7XG5cdHJldHVybiByZXNwb25zZS50eXBlID09PSBcImVycm9yXCIgJiYgcmVzcG9uc2Uuc3RhdHVzID09PSAwICYmIHJlc3BvbnNlLnN0YXR1c1RleHQgPT09IFwiXCIgJiYgQXJyYXkuZnJvbShyZXNwb25zZS5oZWFkZXJzLmVudHJpZXMoKSkubGVuZ3RoID09PSAwICYmIHJlc3BvbnNlLmJvZHkgPT09IG51bGw7XG59XG52YXIgRXZlbnRTb3VyY2VQYXJzaW5nU3RyZWFtID0gY2xhc3MgZXh0ZW5kcyBXcml0YWJsZVN0cmVhbSB7XG5cdHVuZGVybHlpbmdTaW5rO1xuXHRkZWNvZGVyO1xuXHRidWZmZXI7XG5cdHBvc2l0aW9uO1xuXHRmaWVsZExlbmd0aDtcblx0ZGlzY2FyZFRyYWlsaW5nTmV3bGluZSA9IGZhbHNlO1xuXHRtZXNzYWdlID0ge1xuXHRcdGlkOiB2b2lkIDAsXG5cdFx0ZXZlbnQ6IHZvaWQgMCxcblx0XHRkYXRhOiB2b2lkIDBcblx0fTtcblx0Y29uc3RydWN0b3IodW5kZXJseWluZ1NpbmspIHtcblx0XHRzdXBlcih7XG5cdFx0XHR3cml0ZTogKGNodW5rKSA9PiB7XG5cdFx0XHRcdHRoaXMucHJvY2Vzc1Jlc3BvbnNlQm9keUNodW5rKGNodW5rKTtcblx0XHRcdH0sXG5cdFx0XHRhYm9ydDogKHJlYXNvbikgPT4ge1xuXHRcdFx0XHR0aGlzLnVuZGVybHlpbmdTaW5rLmFib3J0Py4ocmVhc29uKTtcblx0XHRcdH0sXG5cdFx0XHRjbG9zZTogKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnVuZGVybHlpbmdTaW5rLmNsb3NlPy4oKTtcblx0XHRcdH1cblx0XHR9KTtcblx0XHR0aGlzLnVuZGVybHlpbmdTaW5rID0gdW5kZXJseWluZ1Npbms7XG5cdFx0dGhpcy5kZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCk7XG5cdFx0dGhpcy5wb3NpdGlvbiA9IDA7XG5cdH1cblx0cmVzZXRNZXNzYWdlKCkge1xuXHRcdHRoaXMubWVzc2FnZSA9IHtcblx0XHRcdGlkOiB2b2lkIDAsXG5cdFx0XHRldmVudDogdm9pZCAwLFxuXHRcdFx0ZGF0YTogdm9pZCAwXG5cdFx0fTtcblx0fVxuXHRwcm9jZXNzUmVzcG9uc2VCb2R5Q2h1bmsoY2h1bmspIHtcblx0XHRpZiAodGhpcy5idWZmZXIgPT0gbnVsbCkge1xuXHRcdFx0dGhpcy5idWZmZXIgPSBjaHVuaztcblx0XHRcdHRoaXMucG9zaXRpb24gPSAwO1xuXHRcdFx0dGhpcy5maWVsZExlbmd0aCA9IC0xO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBuZXh0QnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkodGhpcy5idWZmZXIubGVuZ3RoICsgY2h1bmsubGVuZ3RoKTtcblx0XHRcdG5leHRCdWZmZXIuc2V0KHRoaXMuYnVmZmVyKTtcblx0XHRcdG5leHRCdWZmZXIuc2V0KGNodW5rLCB0aGlzLmJ1ZmZlci5sZW5ndGgpO1xuXHRcdFx0dGhpcy5idWZmZXIgPSBuZXh0QnVmZmVyO1xuXHRcdH1cblx0XHRjb25zdCBidWZmZXJMZW5ndGggPSB0aGlzLmJ1ZmZlci5sZW5ndGg7XG5cdFx0bGV0IGxpbmVTdGFydCA9IDA7XG5cdFx0d2hpbGUgKHRoaXMucG9zaXRpb24gPCBidWZmZXJMZW5ndGgpIHtcblx0XHRcdGlmICh0aGlzLmRpc2NhcmRUcmFpbGluZ05ld2xpbmUpIHtcblx0XHRcdFx0aWYgKHRoaXMuYnVmZmVyW3RoaXMucG9zaXRpb25dID09PSAxMCkgbGluZVN0YXJ0ID0gKyt0aGlzLnBvc2l0aW9uO1xuXHRcdFx0XHR0aGlzLmRpc2NhcmRUcmFpbGluZ05ld2xpbmUgPSBmYWxzZTtcblx0XHRcdH1cblx0XHRcdGxldCBsaW5lRW5kID0gLTE7XG5cdFx0XHRmb3IgKDsgdGhpcy5wb3NpdGlvbiA8IGJ1ZmZlckxlbmd0aCAmJiBsaW5lRW5kID09PSAtMTsgKyt0aGlzLnBvc2l0aW9uKSBzd2l0Y2ggKHRoaXMuYnVmZmVyW3RoaXMucG9zaXRpb25dKSB7XG5cdFx0XHRcdGNhc2UgNTg6XG5cdFx0XHRcdFx0aWYgKHRoaXMuZmllbGRMZW5ndGggPT09IC0xKSB0aGlzLmZpZWxkTGVuZ3RoID0gdGhpcy5wb3NpdGlvbiAtIGxpbmVTdGFydDtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0Y2FzZSAxMzpcblx0XHRcdFx0XHR0aGlzLmRpc2NhcmRUcmFpbGluZ05ld2xpbmUgPSB0cnVlO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRjYXNlIDEwOiBsaW5lRW5kID0gdGhpcy5wb3NpdGlvbjtcblx0XHRcdH1cblx0XHRcdGlmIChsaW5lRW5kID09PSAtMSkgYnJlYWs7XG5cdFx0XHR0aGlzLnByb2Nlc3NMaW5lKHRoaXMuYnVmZmVyLnN1YmFycmF5KGxpbmVTdGFydCwgbGluZUVuZCksIHRoaXMuZmllbGRMZW5ndGgpO1xuXHRcdFx0bGluZVN0YXJ0ID0gdGhpcy5wb3NpdGlvbjtcblx0XHRcdHRoaXMuZmllbGRMZW5ndGggPSAtMTtcblx0XHR9XG5cdFx0aWYgKGxpbmVTdGFydCA9PT0gYnVmZmVyTGVuZ3RoKSB0aGlzLmJ1ZmZlciA9IHZvaWQgMDtcblx0XHRlbHNlIGlmIChsaW5lU3RhcnQgIT09IDApIHtcblx0XHRcdHRoaXMuYnVmZmVyID0gdGhpcy5idWZmZXIuc3ViYXJyYXkobGluZVN0YXJ0KTtcblx0XHRcdHRoaXMucG9zaXRpb24gLT0gbGluZVN0YXJ0O1xuXHRcdH1cblx0fVxuXHRwcm9jZXNzTGluZShsaW5lLCBmaWVsZExlbmd0aCkge1xuXHRcdGlmIChsaW5lLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0aWYgKHRoaXMubWVzc2FnZS5kYXRhID09PSB2b2lkIDApIHtcblx0XHRcdFx0dGhpcy5tZXNzYWdlLmV2ZW50ID0gdm9pZCAwO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHR0aGlzLnVuZGVybHlpbmdTaW5rLm1lc3NhZ2UodGhpcy5tZXNzYWdlKTtcblx0XHRcdHRoaXMucmVzZXRNZXNzYWdlKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChmaWVsZExlbmd0aCA+IDApIHtcblx0XHRcdGNvbnN0IGZpZWxkID0gdGhpcy5kZWNvZGVyLmRlY29kZShsaW5lLnN1YmFycmF5KDAsIGZpZWxkTGVuZ3RoKSk7XG5cdFx0XHRjb25zdCB2YWx1ZU9mZnNldCA9IGZpZWxkTGVuZ3RoICsgKGxpbmVbZmllbGRMZW5ndGggKyAxXSA9PT0gMzIgPyAyIDogMSk7XG5cdFx0XHRjb25zdCB2YWx1ZSA9IHRoaXMuZGVjb2Rlci5kZWNvZGUobGluZS5zdWJhcnJheSh2YWx1ZU9mZnNldCkpO1xuXHRcdFx0c3dpdGNoIChmaWVsZCkge1xuXHRcdFx0XHRjYXNlIFwiZGF0YVwiOlxuXHRcdFx0XHRcdHRoaXMubWVzc2FnZS5kYXRhID0gdGhpcy5tZXNzYWdlLmRhdGEgPyB0aGlzLm1lc3NhZ2UuZGF0YSArIFwiXFxuXCIgKyB2YWx1ZSA6IHZhbHVlO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRjYXNlIFwiZXZlbnRcIjpcblx0XHRcdFx0XHR0aGlzLm1lc3NhZ2UuZXZlbnQgPSB2YWx1ZTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0Y2FzZSBcImlkXCI6XG5cdFx0XHRcdFx0dGhpcy5tZXNzYWdlLmlkID0gdmFsdWU7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdGNhc2UgXCJyZXRyeVwiOlxuIC8qKlxuXHRcdFx0XHQqIEFwcGx5IHRoZSByZXRyeSBpbW1lZGlhdGVseS4gRG9uJ3QgYnVmZmVyIG9udG8gdGhlIGN1cnJlbnQgbWVzc2FnZS5cblx0XHRcdFx0KiBAc2VlIGh0dHBzOi8vaHRtbC5zcGVjLndoYXR3Zy5vcmcvbXVsdGlwYWdlL3NlcnZlci1zZW50LWV2ZW50cy5odG1sI2V2ZW50LXN0cmVhbS1pbnRlcnByZXRhdGlvblxuXHRcdFx0XHQqL1xuXHRcdFx0XHRpZiAoL15cXGQrJC8udGVzdCh2YWx1ZSkpIHRoaXMudW5kZXJseWluZ1NpbmsucmV0cnk/LihwYXJzZUludCh2YWx1ZSwgMTApKTtcblx0XHRcdH1cblx0XHR9XG5cdH1cbn07XG4vKipcbiogQ3JlYXRlIGFuIGV2ZW50IHN0cmVhbSBvdXQgb2YgdGhlIGdpdmVuIEZldGNoIEFQSSBgUmVxdWVzdGAuXG4qIFJldHVybnMgdGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxuKiAtIGBjbGllbnRgLCB0byBvcGVyYXRlIG9uIHRoZSBpbnRlcmNlcHRlZCByZXF1ZXN0O1xuKiAtIGBzZXJ2ZXJgLCB0byBlc3RhYmxpc2ggYW5kIG1hbmFnZSB0aGUgYWN0dWFsIHNlcnZlciBjb25uZWN0aW9uO1xuKiAtIGByZXNwb25zZWAsIGEgYFJlc3BvbnNlYCB0byB1c2UgYXMgdGhlIG1vY2sgcmVzcG9uc2UncyBib2R5LlxuKlxuKiBAZXhhbXBsZVxuKiBodHRwLnBvc3QoJy9yZXNvdXJjZScsICh7IHJlcXVlc3QgfSkgPT4ge1xuKiAgIGNvbnN0IHsgY2xpZW50LCBzZXJ2ZXIsIHJlc3BvbnNlIH0gPSBjcmVhdGVFdmVudFN0cmVhbShyZXF1ZXN0KVxuKiAgIGNsaWVudC5zZW5kKHsgZGF0YTogJ2hlbGxvIHdvcmxkJyB9KVxuKiAgIHJldHVybiByZXNwb25zZVxuKiB9KVxuKi9cbmZ1bmN0aW9uIGNyZWF0ZUV2ZW50U3RyZWFtKHJlcXVlc3QpIHtcblx0aW52YXJpYW50KCFyZXF1ZXN0LnNpZ25hbC5hYm9ydGVkLCBcIkZhaWxlZCB0byBjYWxsIFxcXCJjcmVhdGVFdmVudFN0cmVhbVxcXCIgb24gdGhlIFxcXCIlcyAlc1xcXCIgcmVxdWVzdDogcmVxdWVzdCBhYm9ydGVkXCIsIHJlcXVlc3QubWV0aG9kLCByZXF1ZXN0LnVybCk7XG5cdGxldCBjb250cm9sbGVyO1xuXHRjb25zdCByZWFkYWJsZSA9IG5ldyBSZWFkYWJsZVN0cmVhbSh7XG5cdFx0c3RhcnQoZGVmYXVsdENvbnRyb2xsZXIpIHtcblx0XHRcdGNvbnRyb2xsZXIgPSBkZWZhdWx0Q29udHJvbGxlcjtcblx0XHR9LFxuXHRcdGNhbmNlbCgpIHtcblx0XHRcdGNsaWVudC5jbG9zZSgpO1xuXHRcdH1cblx0fSk7XG5cdGNvbnN0IGNsaWVudCA9IG5ldyBTZXJ2ZXJTZW50RXZlbnRDbGllbnQoY29udHJvbGxlcik7XG5cdGNvbnN0IHNlcnZlciA9IG5ldyBTZXJ2ZXJTZW50RXZlbnRTZXJ2ZXIoe1xuXHRcdHJlcXVlc3QsXG5cdFx0Y2xpZW50XG5cdH0pO1xuXHRjb25zdCByZXNwb25zZSA9IG5ldyBSZXNwb25zZShyZWFkYWJsZSwgU1NFX1JFU1BPTlNFX0lOSVQpO1xuXHRyZXF1ZXN0LnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgKCkgPT4ge1xuXHRcdGNsaWVudC5jbG9zZSgpO1xuXHR9LCB7IG9uY2U6IHRydWUgfSk7XG5cdHJldHVybiB7XG5cdFx0Y2xpZW50LFxuXHRcdHNlcnZlcixcblx0XHRyZXNwb25zZVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBzc2UgYXMgdCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zc2UuanMubWFwIiwiaW1wb3J0IHsgdCBhcyBleGVjdXRlSGFuZGxlcnMgfSBmcm9tIFwiLi4vX2NodW5rcy9leGVjdXRlLWhhbmRsZXJzLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVSZXF1ZXN0SWQgfSBmcm9tIFwiQG1zd2pzL2ludGVyY2VwdG9yc1wiO1xuLy8jcmVnaW9uIHNyYy91dGlscy9nZXQtcmVzcG9uc2UudHNcbi8qKlxuKiBGaW5kcyBhIHJlc3BvbnNlIGZvciB0aGUgZ2l2ZW4gcmVxdWVzdCBpbnN0YW5jZVxuKiBpbiB0aGUgYXJyYXkgb2YgcmVxdWVzdCBoYW5kbGVycy5cbiogQHBhcmFtIGhhbmRsZXJzIFRoZSBhcnJheSBvZiByZXF1ZXN0IGhhbmRsZXJzLlxuKiBAcGFyYW0gcmVxdWVzdCBUaGUgYFJlcXVlc3RgIGluc3RhbmNlLlxuKiBAcGFyYW0gcmVzb2x1dGlvbkNvbnRleHQgUmVxdWVzdCByZXNvbHV0aW9uIG9wdGlvbnMuXG4qIEByZXR1cm5zIHtSZXNwb25zZX0gQSBtb2NrZWQgcmVzcG9uc2UsIGlmIGFueS5cbiovXG5jb25zdCBnZXRSZXNwb25zZSA9IGFzeW5jIChoYW5kbGVycywgcmVxdWVzdCwgcmVzb2x1dGlvbkNvbnRleHQpID0+IHtcblx0cmV0dXJuIChhd2FpdCBleGVjdXRlSGFuZGxlcnMoe1xuXHRcdHJlcXVlc3QsXG5cdFx0cmVxdWVzdElkOiBjcmVhdGVSZXF1ZXN0SWQoKSxcblx0XHRoYW5kbGVycyxcblx0XHRyZXNvbHV0aW9uQ29udGV4dFxuXHR9KSk/LnJlc3BvbnNlO1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZ2V0UmVzcG9uc2UgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Z2V0LXJlc3BvbnNlLmpzLm1hcCIsImltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCJvdXR2YXJpYW50XCI7XG4vLyNyZWdpb24gc3JjL3V0aWxzL2J5cGFzcy50c1xuLyoqXG4qIENyZWF0ZXMgYSBgUmVxdWVzdGAgaW5zdGFuY2UgdGhhdCB3aWxsIGFsd2F5cyBiZSBpZ25vcmVkIGJ5IE1TVy5cbipcbiogQGV4YW1wbGVcbiogaW1wb3J0IHsgYnlwYXNzIH0gZnJvbSAnbXN3J1xuKlxuKiBmZXRjaChieXBhc3MoJy9yZXNvdXJjZScpKVxuKiBmZXRjaChieXBhc3MobmV3IFVSTCgnL3Jlc291cmNlJywgJ2h0dHBzOi8vZXhhbXBsZS5jb20pKSlcbiogZmV0Y2goYnlwYXNzKG5ldyBSZXF1ZXN0KCdodHRwczovL2V4YW1wbGUuY29tL3Jlc291cmNlJykpKVxuKlxuKiBAc2VlIHtAbGluayBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL2J5cGFzcyBgYnlwYXNzKClgIEFQSSByZWZlcmVuY2V9XG4qL1xuZnVuY3Rpb24gYnlwYXNzKGlucHV0LCBpbml0KSB7XG5cdGNvbnN0IHJlcXVlc3QgPSBuZXcgUmVxdWVzdChpbnB1dCBpbnN0YW5jZW9mIFJlcXVlc3QgPyBpbnB1dC5jbG9uZSgpIDogaW5wdXQsIGluaXQpO1xuXHRpbnZhcmlhbnQoIXJlcXVlc3QuYm9keVVzZWQsIFwiRmFpbGVkIHRvIGNyZWF0ZSBhIGJ5cGFzc2VkIHJlcXVlc3QgdG8gXFxcIiVzICVzXFxcIjogZ2l2ZW4gcmVxdWVzdCBpbnN0YW5jZSBhbHJlYWR5IGhhcyBpdHMgYm9keSByZWFkLiBNYWtlIHN1cmUgdG8gY2xvbmUgdGhlIGludGVyY2VwdGVkIHJlcXVlc3QgaWYgeW91IHdpc2ggdG8gcmVhZCBpdHMgYm9keSBiZWZvcmUgYnlwYXNzaW5nIGl0LlwiLCByZXF1ZXN0Lm1ldGhvZCwgcmVxdWVzdC51cmwpO1xuXHRjb25zdCByZXF1ZXN0Q2xvbmUgPSByZXF1ZXN0LmNsb25lKCk7XG5cdC8qKlxuXHQqIFNlbmQgdGhlIGludGVybmFsIHJlcXVlc3QgaGVhZGVyIHRoYXQgd291bGQgaW5zdHJ1Y3QgTVNXXG5cdCogdG8gcGVyZm9ybSB0aGlzIHJlcXVlc3QgYXMtaXMsIGlnbm9yaW5nIGFueSBtYXRjaGluZyBoYW5kbGVycy5cblx0KiBAbm90ZSBVc2UgdGhlIGBhY2NlcHRgIGhlYWRlciB0byBzdXBwb3J0IHNjZW5hcmlvcyB3aGVuIHRoZVxuXHQqIHJlcXVlc3QgY2Fubm90IGhhdmUgaGVhZGVycyAoZS5nLiBgc2VuZEJlYWNvbmAgcmVxdWVzdHMpLlxuXHQqL1xuXHRyZXF1ZXN0Q2xvbmUuaGVhZGVycy5hcHBlbmQoXCJhY2NlcHRcIiwgXCJtc3cvcGFzc3Rocm91Z2hcIik7XG5cdC8qKlxuXHQqIERlbGV0ZSB0aGUgXCJjb250ZW50LWxlbmd0aFwiIHJlcXVlc3QgaGVhZGVyLlxuXHQqIEludGVyY2VwdGVkIHJlcXVlc3RzIGFyZSBwYXJzZWQgZnJvbSB0aGUgd2lyZSBhbmQgaW5jbHVkZSB0aGVcblx0KiByZWNlaXZlZCBcImNvbnRlbnQtbGVuZ3RoXCIgaGVhZGVyLiBJZiB0aGUgY29uc3VtZXIgZGVyaXZlcyBhIG5ld1xuXHQqIHJlcXVlc3Qgd2l0aCBhIGRpZmZlcmVudCBib2R5IChlLmcuIGBuZXcgUmVxdWVzdChyZXF1ZXN0LCB7IGJvZHkgfSlgKSxcblx0KiB0aGF0IGhlYWRlciBiZWNvbWVzIHN0YWxlIGFuZCB0aGUgcmVxdWVzdCBjbGllbnQgd2lsbCByZWplY3QgdGhlXG5cdCogYnlwYXNzZWQgcmVxdWVzdCBkdWUgdG8gdGhlIGNvbnRlbnQgbGVuZ3RoIG1pc21hdGNoLiBUaGUgcmVxdWVzdFxuXHQqIGNsaWVudCBhbHdheXMgcmUtY29tcHV0ZXMgdGhpcyBoZWFkZXIgZnJvbSB0aGUgYWN0dWFsIHJlcXVlc3QgYm9keS5cblx0Ki9cblx0cmVxdWVzdENsb25lLmhlYWRlcnMuZGVsZXRlKFwiY29udGVudC1sZW5ndGhcIik7XG5cdHJldHVybiByZXF1ZXN0Q2xvbmU7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGJ5cGFzcyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1ieXBhc3MuanMubWFwIl0sIm1hcHBpbmdzIjoiOztBQW9FQSxJQUFNLGFBQTZCLHVCQUFPO0NBQ3RDLE1BQU0sSUFBSSxXQUFZLENBQUU7Q0FDeEIsRUFBRSxZQUFZLE9BQU8sT0FBTyxJQUFJO0NBQ2hDLE9BQU87QUFDWCxFQUFBLENBQUc7Ozs7Ozs7QUFPSCxTQUFnQixZQUFZLEtBQUssU0FBUztDQUN0QyxNQUFNLE1BQU0sSUFBSSxXQUFXO0NBQzNCLE1BQU0sTUFBTSxJQUFJO0NBRWhCLElBQUksTUFBTSxHQUNOLE9BQU87Q0FDWCxNQUFNLE1BQU0sU0FBUyxVQUFVO0NBQy9CLElBQUksUUFBUTtDQUNaLEdBQUc7RUFDQyxNQUFNLFFBQVEsUUFBUSxLQUFLLE9BQU8sR0FBRztFQUNyQyxJQUFJLFVBQVUsS0FDVjtFQUNKLE1BQU0sU0FBUyxTQUFTLEtBQUssT0FBTyxHQUFHO0VBQ3ZDLElBQUksUUFBUSxRQUFRO0dBRWhCLFFBQVEsSUFBSSxZQUFZLEtBQUssUUFBUSxDQUFDLElBQUk7R0FDMUM7RUFDSjtFQUNBLE1BQU0sTUFBTSxXQUFXLEtBQUssT0FBTyxLQUFLO0VBRXhDLElBQUksSUFBSSxTQUFTLEtBQUEsR0FDYixJQUFJLE9BQU8sSUFBSSxXQUFXLEtBQUssUUFBUSxHQUFHLE1BQU0sQ0FBQztFQUVyRCxRQUFRLFNBQVM7Q0FDckIsU0FBUyxRQUFRO0NBQ2pCLE9BQU87QUFDWDs7OztBQXNNQSxTQUFTLFNBQVMsS0FBSyxLQUFLLEtBQUs7Q0FDN0IsTUFBTSxRQUFRLElBQUksUUFBUSxLQUFLLEdBQUc7Q0FDbEMsT0FBTyxVQUFVLEtBQUssTUFBTTtBQUNoQzs7OztBQUlBLFNBQVMsUUFBUSxLQUFLLEtBQUssS0FBSztDQUM1QixNQUFNLFFBQVEsSUFBSSxRQUFRLEtBQUssR0FBRztDQUNsQyxPQUFPLFVBQVUsS0FBSyxNQUFNO0FBQ2hDOzs7O0FBSUEsU0FBUyxXQUFXLEtBQUssS0FBSyxLQUFLO0NBQy9CLElBQUksUUFBUSxLQUNSLE9BQU87Q0FDWCxJQUFJLFFBQVE7Q0FDWixJQUFJLE1BQU07Q0FDVixHQUFHO0VBQ0MsTUFBTSxPQUFPLElBQUksV0FBVyxLQUFLO0VBQ2pDLElBQUksU0FBUyxNQUFjLFNBQVMsR0FDaEM7Q0FDUixTQUFTLEVBQUUsUUFBUTtDQUNuQixPQUFPLE1BQU0sT0FBTztFQUNoQixNQUFNLE9BQU8sSUFBSSxXQUFXLE1BQU0sQ0FBQztFQUNuQyxJQUFJLFNBQVMsTUFBYyxTQUFTLEdBQ2hDO0VBQ0o7Q0FDSjtDQUNBLE9BQU8sSUFBSSxNQUFNLE9BQU8sR0FBRztBQUMvQjs7OztBQUlBLFNBQVMsT0FBTyxLQUFLO0NBQ2pCLElBQUksSUFBSSxRQUFRLEdBQUcsTUFBTSxJQUNyQixPQUFPO0NBQ1gsSUFBSTtFQUNBLE9BQU8sbUJBQW1CLEdBQUc7Q0FDakMsU0FDTyxHQUFHO0VBQ04sT0FBTztDQUNYO0FBQ0o7Ozs7OztBQ25WQSxTQUFTLG1CQUFtQixRQUFRO0NBQ25DLElBQUksU0FBUyxLQUFLLE9BQU87Q0FDekIsSUFBSSxTQUFTLEtBQUssT0FBTztDQUN6QixPQUFPO0FBQ1I7Ozs7QUFNQSxlQUFlLGlCQUFpQixTQUFTO0NBQ3hDLE1BQU0sY0FBYyxNQUFNLFFBQVEsTUFBTSxDQUFDLENBQUMsS0FBSztDQUMvQyxPQUFPO0VBQ04sS0FBSyxJQUFJLElBQUksUUFBUSxHQUFHO0VBQ3hCLFFBQVEsUUFBUTtFQUNoQixTQUFTLE9BQU8sWUFBWSxRQUFRLFFBQVEsUUFBUSxDQUFDO0VBQ3JELE1BQU07Q0FDUDtBQUNEO0FBR0EsZUFBZSxrQkFBa0IsVUFBVTtDQUMxQyxNQUFNLGdCQUFnQixTQUFTLE1BQU07Q0FDckMsTUFBTSxlQUFlLE1BQU0sY0FBYyxLQUFLO0NBQzlDLE1BQU0saUJBQWlCLGNBQWMsVUFBVTtDQUMvQyxPQUFPO0VBQ04sUUFBUTtFQUNSLFlBQVksY0FBYyxjQUFjLG1CQUFtQixtQkFBbUI7RUFDOUUsU0FBUyxPQUFPLFlBQVksY0FBYyxRQUFRLFFBQVEsQ0FBQztFQUMzRCxNQUFNO0NBQ1A7QUFDRDtBQUdBLFNBQVMsYUFBYSxPQUFPO0NBQzVCLE1BQU0sZ0JBQWdCLFlBQVksS0FBSztDQUN2QyxNQUFNLFVBQVUsQ0FBQztDQUNqQixLQUFLLE1BQU0sY0FBYyxlQUFlLElBQUksT0FBTyxjQUFjLGdCQUFnQixhQUFhLFFBQVEsY0FBYyxjQUFjO0NBQ2xJLE9BQU87QUFDUjtBQUNBLFNBQVMsd0JBQXdCO0NBQ2hDLE9BQU8sYUFBYSxTQUFTLE1BQU07QUFDcEM7Ozs7O0FBS0EsU0FBUyxvQkFBb0IsU0FBUztDQUNyQyxRQUFRLFFBQVEsYUFBaEI7RUFDQyxLQUFLLGVBQWUsT0FBTyxPQUFPLGFBQWEsZUFBZSxTQUFTLFdBQVcsSUFBSSxJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7RUFDdkcsS0FBSyxXQUFXLE9BQU87RUFDdkIsU0FBUyxPQUFPO0NBQ2pCO0FBQ0Q7QUFDQSxTQUFTLHFCQUFxQjtDQUM3QixJQUFJLE9BQU8sYUFBYSxhQUFhLE9BQU8sQ0FBQztDQUM3QyxPQUFPLHNCQUFzQjtBQUM5QjtBQUNBLFNBQVMscUJBQXFCLFNBQVM7Q0FDdEMsTUFBTSxzQkFBc0IsUUFBUSxRQUFRLElBQUksUUFBUTtDQUN4RCxNQUFNLHFCQUFxQixzQkFBc0IsYUFBYSxtQkFBbUIsSUFBSSxDQUFDO0NBQ3RGLElBQUksZ0JBQWdCLFFBQVEsQ0FBQyxvQkFBb0IsT0FBTyxHQUFHLE9BQU87Q0FDbEUsTUFBTSxzQkFBc0IsbUJBQW1CO0NBQy9DLE1BQU0sbUJBQW1CLFlBQVksV0FBVyxRQUFRLEdBQUc7Q0FDM0QsTUFBTSxzQkFBc0IsT0FBTyxZQUFZLGlCQUFpQixLQUFLLFdBQVcsQ0FBQyxPQUFPLEtBQUssT0FBTyxLQUFLLENBQUMsQ0FBQztDQUMzRyxPQUFPO0VBQ04sR0FBRztFQUNILEdBQUc7RUFDSCxHQUFHO0NBQ0o7QUFDRDtBQUdBLElBQUksY0FBOEIseUJBQVMsYUFBYTtDQUN2RCxZQUFZLFVBQVU7Q0FDdEIsWUFBWSxTQUFTO0NBQ3JCLFlBQVksVUFBVTtDQUN0QixZQUFZLFNBQVM7Q0FDckIsWUFBWSxXQUFXO0NBQ3ZCLFlBQVksYUFBYTtDQUN6QixZQUFZLFlBQVk7Q0FDeEIsT0FBTztBQUNSLEVBQUUsQ0FBQyxDQUFDOzs7OztBQUtKLElBQUksY0FBYyxjQUFjLGVBQWU7Q0FDOUMsWUFBWSxRQUFRLFdBQVcsVUFBVSxTQUFTO0VBQ2pELE1BQU0sY0FBYyxPQUFPLGNBQWMsYUFBYSx1QkFBdUI7RUFDN0UsTUFBTTtHQUNMLE1BQU07SUFDTCxRQUFRLEdBQUcsU0FBUyxjQUFjLElBQUksZ0JBQWdCO0lBQ3RELE1BQU07SUFDTjtHQUNEO0dBQ0E7R0FDQTtFQUNELENBQUM7RUFDRCxLQUFLLDhCQUE4QjtDQUNwQztDQUNBLGdDQUFnQztFQUMvQixNQUFNLEVBQUUsUUFBUSxTQUFTLEtBQUs7RUFDOUIsSUFBSSxDQUFDLFFBQVEsZ0JBQWdCLFVBQVUsT0FBTyxTQUFTLFlBQVk7RUFDbkUsSUFBSSxrQkFBa0IsSUFBSSxNQUFNLE1BQU07RUFDdEMsU0FBUyxLQUFLLCtFQUErRSxPQUFPLEdBQUcsS0FBSywwTUFBME07Q0FDdlQ7Q0FDQSxNQUFNLE1BQU0sTUFBTTs7Ozs7OztFQU9qQixJQUFJLGNBQWMsS0FBSyxRQUFRLFFBQVEsU0FBUyxHQUFHLE9BQU87R0FDekQsT0FBTztJQUNOLFNBQVM7SUFDVCxRQUFRLENBQUM7R0FDVjtHQUNBLFNBQVMsQ0FBQztFQUNYO0VBQ0EsTUFBTSxNQUFNLElBQUksSUFBSSxLQUFLLFFBQVEsR0FBRztFQUNwQyxNQUFNLFVBQVUscUJBQXFCLEtBQUssT0FBTzs7Ozs7O0VBTWpELElBQUksT0FBTyxLQUFLLEtBQUssU0FBUyxZQUFZO0dBQ3pDLE1BQU0sd0JBQXdCLE1BQU0sS0FBSyxLQUFLLEtBQUs7SUFDbEQsU0FBUyxLQUFLO0lBQ2Q7R0FDRCxDQUFDO0dBQ0QsT0FBTztJQUNOLE9BQU8sT0FBTywwQkFBMEIsWUFBWTtLQUNuRCxTQUFTO0tBQ1QsUUFBUSxDQUFDO0lBQ1YsSUFBSTtJQUNKO0dBQ0Q7RUFDRDtFQUNBLE9BQU87R0FDTixPQUFPLEtBQUssS0FBSyxPQUFPLGdCQUFnQixLQUFLLEtBQUssS0FBSyxNQUFNLEtBQUssbUJBQW1CLE9BQU8sSUFBSTtJQUMvRixTQUFTO0lBQ1QsUUFBUSxDQUFDO0dBQ1Y7R0FDQTtFQUNEO0NBQ0Q7Q0FDQSxNQUFNLFVBQVUsTUFBTTtFQUNyQixNQUFNLG9CQUFvQixLQUFLLFlBQVksS0FBSyxRQUFRLE1BQU07RUFDOUQsTUFBTSxpQkFBaUIsS0FBSyxhQUFhLE1BQU07RUFDL0MsT0FBTyxxQkFBcUI7Q0FDN0I7Q0FDQSxZQUFZLGNBQWM7RUFDekIsT0FBTyxLQUFLLEtBQUssa0JBQWtCLFNBQVMsS0FBSyxLQUFLLE9BQU8sS0FBSyxZQUFZLElBQUksY0FBYyxLQUFLLEtBQUssUUFBUSxZQUFZO0NBQy9IO0NBQ0EsbUJBQW1CLE1BQU07RUFDeEIsT0FBTztHQUNOLFFBQVEsS0FBSyxhQUFhLE9BQU8sVUFBVSxDQUFDO0dBQzVDLFNBQVMsS0FBSyxhQUFhO0VBQzVCO0NBQ0Q7Q0FDQSxNQUFNLElBQUksTUFBTTtFQUNmLE1BQU0sWUFBWSxZQUFZLEtBQUssUUFBUSxHQUFHO0VBQzlDLE1BQU0sZ0JBQWdCLE1BQU0saUJBQWlCLEtBQUssT0FBTztFQUN6RCxNQUFNLGlCQUFpQixNQUFNLGtCQUFrQixLQUFLLFFBQVE7RUFDNUQsTUFBTSxjQUFjLG1CQUFtQixlQUFlLE1BQU07RUFDNUQsUUFBUSxlQUFlLFNBQVMsY0FBYyxHQUFHLGFBQWEsRUFBRSxHQUFHLEtBQUssUUFBUSxPQUFPLEdBQUcsVUFBVSxNQUFNLGVBQWUsT0FBTyxHQUFHLGVBQWUsV0FBVyxJQUFJLEdBQUcsU0FBUyxlQUFlLGVBQWU7RUFDM00sUUFBUSxJQUFJLFdBQVcsYUFBYTtFQUNwQyxRQUFRLElBQUksWUFBWSxJQUFJO0VBQzVCLFFBQVEsSUFBSSxZQUFZLGNBQWM7RUFDdEMsUUFBUSxTQUFTO0NBQ2xCO0FBQ0Q7OztBQ3BMQSxTQUFTLGtCQUFrQixRQUFRO0NBQ2xDLFFBQVEsV0FBVyxVQUFVLFVBQVUsQ0FBQyxNQUFNO0VBQzdDLE9BQU8sSUFBSSxZQUFZLFFBQVEsV0FBVyxVQUFVLE9BQU87Q0FDNUQ7QUFDRDs7Ozs7Ozs7OztBQVVBLElBQU0sT0FBTztDQUNaLEtBQUssa0JBQWtCLElBQUk7Q0FDM0IsTUFBTSxrQkFBa0IsTUFBTTtDQUM5QixLQUFLLGtCQUFrQixLQUFLO0NBQzVCLE1BQU0sa0JBQWtCLE1BQU07Q0FDOUIsS0FBSyxrQkFBa0IsS0FBSztDQUM1QixRQUFRLGtCQUFrQixRQUFRO0NBQ2xDLE9BQU8sa0JBQWtCLE9BQU87Q0FDaEMsU0FBUyxrQkFBa0IsU0FBUztBQUNyQzs7O0FDdkJBLFNBQVMsY0FBYyxPQUFPO0NBQzdCLE9BQU8sU0FBUyxLQUFLLEtBQUssT0FBTyxRQUFRLElBQUksT0FBTyxLQUFLLE1BQU0sY0FBYyxPQUFPLFFBQVEsSUFBSSxPQUFPLE9BQU8sTUFBTTtBQUNySDs7O0FDQUEsSUFBTSxpQkFBaUI7Ozs7Ozs7O0FBUXZCLGVBQWUsaUJBQWlCLEVBQUUsV0FBVztDQUM1QyxNQUFNLE1BQU0sUUFBUSxRQUFRLElBQUksbUJBQW1CO0NBQ25ELElBQUksQ0FBQyxLQUFLO0NBQ1YsTUFBTSxXQUFXLElBQUksWUFBWSxDQUFDLENBQUMsT0FBTyxNQUFNLGNBQWM7Q0FDOUQsTUFBTSxTQUFTLE1BQU0sT0FBTyxPQUFPLE9BQU8sU0FBUyxRQUFRO0NBQzNELE1BQU0sY0FBYyxLQUFLLE9BQU8sYUFBYSxHQUFHLElBQUksV0FBVyxNQUFNLENBQUMsQ0FBQztDQUN2RSxNQUFNLHFCQUFxQixRQUFRLFFBQVEsSUFBSSx3QkFBd0IsQ0FBQyxFQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxhQUFhLFNBQVMsS0FBSyxDQUFDO0NBQ3RILElBQUksVUFBVSxvQkFBb0IsUUFBUSxHQUFHLEdBQUcsa0JBQWtCO0NBQ2xFLE1BQU0sVUFBVSxJQUFJLFFBQVE7RUFDM0IsU0FBUztFQUNULFlBQVk7RUFDWix3QkFBd0I7Q0FDekIsQ0FBQztDQUNELElBQUksc0JBQXNCLG1CQUFtQixTQUFTLEdBQUcsUUFBUSxJQUFJLDBCQUEwQixtQkFBbUIsRUFBRTtDQUNwSCxPQUFPLElBQUksY0FBYyxNQUFNO0VBQzlCLFFBQVE7RUFDUjtDQUNELENBQUM7QUFDRjs7Ozs7OztBQU9BLFNBQVMsOEJBQThCLEtBQUssVUFBVTtDQUNyRCxPQUFPLEtBQUssS0FBSyxFQUFFLGNBQWM7RUFDaEMsT0FBTyxRQUFRLFFBQVEsSUFBSSxTQUFTLENBQUMsRUFBRSxZQUFZLE1BQU0sZUFBZSxnQkFBZ0IsSUFBSSxJQUFJLG9CQUFvQixRQUFRLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0NBQ3pJLEdBQUcsUUFBUTtBQUNaOzs7QUNuQ0EsSUFBSSw2QkFBNkIsTUFBTTtDQUN0QztDQUNBLGNBQWM7RUFDYixLQUFLLHdCQUF3QixJQUFJLElBQUk7Q0FDdEM7Q0FDQSxNQUFNLElBQUksUUFBUTtFQUNqQixLQUFLLE1BQU0sSUFBSSxPQUFPLElBQUk7R0FDekIsSUFBSSxPQUFPO0dBQ1gsS0FBSyxPQUFPLElBQUk7RUFDakIsQ0FBQztDQUNGO0NBQ0EsU0FBUztFQUNSLE9BQU8sUUFBUSxRQUFRLE1BQU0sS0FBSyxLQUFLLE1BQU0sT0FBTyxDQUFDLENBQUM7Q0FDdkQ7Q0FDQSxNQUFNLFdBQVcsV0FBVztFQUMzQixLQUFLLE1BQU0sWUFBWSxXQUFXLEtBQUssTUFBTSxPQUFPLFFBQVE7Q0FDN0Q7QUFDRDtBQUdBLElBQU0sVUFBVTtBQUNoQixJQUFNLGdCQUFnQjtBQUN0QixJQUFJLGdDQUFnQyxNQUFNO0NBQ3pDO0NBQ0EsY0FBYztFQUNiLEtBQUssS0FBSyxLQUFLLGVBQWU7Q0FDL0I7Q0FDQSxNQUFNLElBQUksUUFBUTtFQUNqQixNQUFNLFVBQVUsUUFBUSxjQUFjOzs7Ozs7O0VBT3RDLE1BQU0sV0FBVyxNQUFNLEtBQUssU0FBUyxFQUFBLENBQUcsSUFBSTtHQUMzQyxJQUFJLE9BQU87R0FDWCxLQUFLLE9BQU8sSUFBSTtFQUNqQixDQUFDO0VBQ0QsUUFBUSxrQkFBa0I7R0FDekIsUUFBUSxRQUFRO0VBQ2pCO0VBQ0EsUUFBUSxnQkFBZ0I7R0FDdkIsUUFBUSxNQUFNLFFBQVEsS0FBSztHQUMzQixRQUFRLHVCQUF1QixJQUFJLE1BQU0sbUNBQW1DLE9BQU8sR0FBRywrQ0FBK0MsQ0FBQztFQUN2STtFQUNBLE9BQU8sUUFBUTtDQUNoQjtDQUNBLE1BQU0sU0FBUztFQUNkLE1BQU0sVUFBVSxRQUFRLGNBQWM7RUFDdEMsTUFBTSxXQUFXLE1BQU0sS0FBSyxTQUFTLEVBQUEsQ0FBRyxPQUFPO0VBQy9DLFFBQVEsa0JBQWtCO0dBQ3pCLFFBQVEsUUFBUSxRQUFRLE1BQU07RUFDL0I7RUFDQSxRQUFRLGdCQUFnQjtHQUN2QixRQUFRLE1BQU0sUUFBUSxLQUFLO0dBQzNCLFFBQVEsdUJBQXVCLElBQUksTUFBTSxrRkFBa0YsQ0FBQztFQUM3SDtFQUNBLE9BQU8sUUFBUTtDQUNoQjtDQUNBLE1BQU0sV0FBVyxXQUFXO0VBQzNCLE1BQU0sVUFBVSxRQUFRLGNBQWM7RUFDdEMsTUFBTSxRQUFRLE1BQU0sS0FBSyxTQUFTO0VBQ2xDLEtBQUssTUFBTSxZQUFZLFdBQVcsTUFBTSxPQUFPLFFBQVE7RUFDdkQsTUFBTSxZQUFZLG1CQUFtQjtHQUNwQyxRQUFRLFFBQVE7RUFDakI7RUFDQSxNQUFNLFlBQVksZ0JBQWdCO0dBQ2pDLFFBQVEsTUFBTSxNQUFNLFlBQVksS0FBSztHQUNyQyxRQUFRLHVCQUF1QixJQUFJLE1BQU0sdUNBQXVDLFVBQVUsS0FBSyxJQUFJLEVBQUUsK0NBQStDLENBQUM7RUFDdEo7RUFDQSxPQUFPLFFBQVE7Q0FDaEI7Q0FDQSxNQUFNLGlCQUFpQjtFQUN0QixNQUFNLFVBQVUsUUFBUSxjQUFjO0VBQ3RDLE1BQU0sVUFBVSxVQUFVLEtBQUssU0FBUyxDQUFDO0VBQ3pDLFFBQVEsYUFBYSxFQUFFLG9CQUFvQjtHQUMxQyxNQUFNLEtBQUssUUFBUSxJQUFJLGVBQWUsUUFBUTtHQUM5QyxJQUFJLEdBQUcsaUJBQWlCLFNBQVMsYUFBYSxHQUFHLE9BQU8sUUFBUSxRQUFRLEVBQUU7RUFDM0U7RUFDQSxRQUFRLGtCQUFrQixPQUFPLEVBQUUsb0JBQW9CO0dBQ3RELE1BQU0sS0FBSyxRQUFRLElBQUksZUFBZSxRQUFRO0dBQzlDLElBQUksR0FBRyxpQkFBaUIsU0FBUyxhQUFhLEdBQUc7R0FDakQsTUFBTSxRQUFRLEdBQUcsa0JBQWtCLGVBQWUsRUFBRSxTQUFTLEtBQUssQ0FBQztHQUNuRSxNQUFNLFlBQVksbUJBQW1CO0lBQ3BDLFFBQVEsUUFBUSxFQUFFO0dBQ25CO0dBQ0EsTUFBTSxZQUFZLGdCQUFnQjtJQUNqQyxRQUFRLE1BQU0sTUFBTSxZQUFZLEtBQUs7SUFDckMsUUFBUSx1QkFBdUIsSUFBSSxNQUFNLHNGQUFzRixDQUFDO0dBQ2pJO0VBQ0Q7RUFDQSxRQUFRLGdCQUFnQjtHQUN2QixRQUFRLE1BQU0sUUFBUSxLQUFLO0dBQzNCLFFBQVEsdUJBQXVCLElBQUksTUFBTSxtRkFBbUYsQ0FBQztFQUM5SDtFQUNBLE9BQU8sUUFBUTtDQUNoQjtDQUNBLE1BQU0sV0FBVztFQUNoQixRQUFRLE1BQU0sS0FBSyxHQUFBLENBQUksWUFBWSxlQUFlLFdBQVcsQ0FBQyxDQUFDLFlBQVksYUFBYTtDQUN6RjtBQUNEOzs7OztBQU9BLElBQUkseUJBQXlCLE1BQU07Q0FDbEM7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZLFNBQVM7RUFDcEIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxRQUFRLE9BQU8sY0FBYyxjQUFjLElBQUksOEJBQThCLElBQUksSUFBSSwyQkFBMkI7RUFDckgsS0FBSyxpQ0FBaUMsSUFBSSxJQUFJO0VBQzlDLEtBQUssNkJBQTZCLElBQUksSUFBSTtFQUMxQyxLQUFLLFFBQVEsaUJBQWlCLFlBQVksWUFBWTtHQUNyRCxJQUFJLFFBQVEsTUFBTSxTQUFTLGFBQWEsS0FBSyxzQkFBc0I7RUFDcEUsQ0FBQztFQUNELElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTyxpQkFBaUIsV0FBVyxPQUFPLFlBQVk7R0FDeEYsSUFBSSxRQUFRLE1BQU0sU0FBUyxtQkFBbUIsTUFBTSxLQUFLLHFCQUFxQjtFQUMvRSxDQUFDO0NBQ0Y7Q0FDQSxNQUFNLHdCQUF3QjtFQUM3QixNQUFNLGdCQUFnQixNQUFNLEtBQUssTUFBTSxPQUFPO0VBQzlDLEtBQUssYUFBYSxJQUFJLElBQUksY0FBYyxLQUFLLFdBQVc7R0FDdkQsTUFBTSxnQkFBZ0IsS0FBSyxlQUFlLElBQUksT0FBTyxFQUFFOzs7OztHQUt2RCxJQUFJLGVBQWUsT0FBTztHQUMxQixPQUFPLElBQUksZ0NBQWdDLE9BQU8sSUFBSSxJQUFJLElBQUksT0FBTyxHQUFHLEdBQUcsS0FBSyxPQUFPO0VBQ3hGLENBQUMsQ0FBQztDQUNIO0NBQ0EsTUFBTSx1QkFBdUI7RUFDNUIsTUFBTSxLQUFLLE1BQU0sV0FBVyxNQUFNLEtBQUssS0FBSyxlQUFlLEtBQUssQ0FBQyxDQUFDO0VBQ2xFLEtBQUssZUFBZSxNQUFNO0VBQzFCLE1BQU0sS0FBSyxzQkFBc0I7RUFDakMsS0FBSyxnQ0FBZ0M7Q0FDdEM7Ozs7Q0FJQSxJQUFJLFVBQVU7RUFDYixPQUFPLEtBQUs7Q0FDYjs7Ozs7Q0FLQSxrQ0FBa0M7RUFDakMsS0FBSyxRQUFRLFlBQVksRUFBRSxNQUFNLFlBQVksQ0FBQztDQUMvQztDQUNBLE1BQU0sVUFBVSxRQUFRO0VBQ3ZCLE1BQU0sS0FBSyxNQUFNLElBQUksTUFBTTtFQUMzQixNQUFNLEtBQUssc0JBQXNCO0VBQ2pDLEtBQUssZ0NBQWdDO0NBQ3RDOzs7Ozs7O0NBT0EsTUFBTSxjQUFjLFFBQVE7RUFDM0IsS0FBSyxlQUFlLElBQUksT0FBTyxJQUFJLE1BQU07RUFDekMsTUFBTSxLQUFLLFVBQVUsTUFBTTtFQUMzQixNQUFNLDJCQUEyQixZQUFZO0dBQzVDLE1BQU0sRUFBRSxNQUFNLFlBQVksUUFBUTtHQUNsQyxJQUFJLE9BQU8sWUFBWSxZQUFZLGNBQWMsV0FBVyxRQUFRLGFBQWEsT0FBTyxJQUFJO0dBQzVGLFFBQVEsTUFBUjtJQUNDLEtBQUs7S0FDSixPQUFPLEtBQUssUUFBUSxJQUFJO0tBQ3hCO0lBQ0QsS0FBSyxvQkFBb0IsT0FBTyxNQUFNLFFBQVEsTUFBTSxRQUFRLE1BQU07R0FDbkU7RUFDRDtFQUNBLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0VBQzVDLEtBQUssUUFBUSxpQkFBaUIsV0FBVyx5QkFBeUIsRUFBRSxRQUFRLGdCQUFnQixPQUFPLENBQUM7RUFDcEcsT0FBTyxpQkFBaUIsZUFBZSxnQkFBZ0IsTUFBTSxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDL0U7QUFDRDs7Ozs7Ozs7QUFRQSxJQUFJLGtDQUFrQyxNQUFNO0NBQzNDO0NBQ0E7Q0FDQTtDQUNBLFlBQVksSUFBSSxLQUFLLFNBQVM7RUFDN0IsS0FBSyxLQUFLO0VBQ1YsS0FBSyxNQUFNO0VBQ1gsS0FBSyxVQUFVO0NBQ2hCO0NBQ0EsS0FBSyxNQUFNO0VBQ1YsS0FBSyxRQUFRLFlBQVk7R0FDeEIsTUFBTTtHQUNOLFNBQVM7SUFDUixVQUFVLEtBQUs7SUFDZjtHQUNEO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsTUFBTSxNQUFNLFFBQVE7RUFDbkIsS0FBSyxRQUFRLFlBQVk7R0FDeEIsTUFBTTtHQUNOLFNBQVM7SUFDUixVQUFVLEtBQUs7SUFDZjtJQUNBO0dBQ0Q7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxpQkFBaUIsT0FBTyxXQUFXLFVBQVU7RUFDNUMsTUFBTSxJQUFJLE1BQU0sbUVBQW1FO0NBQ3BGO0NBQ0Esb0JBQW9CLFFBQVEsV0FBVyxVQUFVO0VBQ2hELE1BQU0sSUFBSSxNQUFNLHNFQUFzRTtDQUN2RjtBQUNEO0FBR0EsSUFBTSxtQkFBbUIsSUFBSSxpQkFBaUIsOEJBQThCO0FBQzVFLElBQUksY0FBYyxnQkFBZ0IsR0FBRyxpQkFBaUIsTUFBTTs7Ozs7Ozs7OztBQVU1RCxTQUFTLDJCQUEyQixLQUFLLFNBQVM7Q0FDakQsVUFBVSxLQUFLLG1EQUFtRDtDQUNsRSxVQUFVLE9BQU8sR0FBRyxHQUFHLGlFQUFpRSxPQUFPLEdBQUc7Q0FDbEcsTUFBTSxnQkFBZ0IsSUFBSSx1QkFBdUIsZ0JBQWdCO0NBQ2pFLE1BQU0saUJBQWlCLDhCQUE4QixNQUFNLFNBQVM7RUFDbkUsT0FBTyxHQUFHLFVBQVUsSUFBSTtDQUN6QixDQUFDO0NBQ0QsT0FBTztFQUNOLElBQUksVUFBVTtHQUNiLE9BQU8sY0FBYztFQUN0QjtFQUNBLGlCQUFpQixPQUFPLFVBQVU7R0FDakMsTUFBTSxtQkFBbUIsSUFBSSxpQkFBaUIsS0FBSyxFQUFFLFlBQVksU0FBUyxXQUFXLENBQUM7R0FDdEYsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHLGNBQWMsT0FBTyxFQUFFLGFBQWE7SUFDakUsTUFBTSxjQUFjLGNBQWMsTUFBTTtHQUN6QyxDQUFDO0dBQ0QsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHLE9BQU8sUUFBUTtHQUM3QyxPQUFPLHNCQUFzQixrQkFBa0IsQ0FBQyxjQUFjLENBQUM7RUFDaEU7RUFDQSxVQUFVLE1BQU07R0FDZixLQUFLLGdCQUFnQixDQUFDLEdBQUcsSUFBSTtFQUM5QjtFQUNBLGdCQUFnQixTQUFTLE1BQU07R0FDOUIsTUFBTSxnQkFBZ0IsTUFBTSxVQUFVLE9BQU8sT0FBTyxDQUFDLENBQUMsS0FBSyxXQUFXLE9BQU8sRUFBRTtHQUMvRSxjQUFjLFFBQVEsU0FBUyxnQkFBZ0I7SUFDOUMsSUFBSSxDQUFDLGNBQWMsU0FBUyxZQUFZLEVBQUUsR0FBRyxZQUFZLEtBQUssSUFBSTtHQUNuRSxDQUFDO0VBQ0Y7Q0FDRDtBQUNEOzs7Ozs7Ozs7O0FBVUEsSUFBTSxLQUFLO0NBQ1YsTUFBTTtDQUNOLFdBQVc7QUFDWjs7O0FDN1JBLElBQU0sOEJBQThCO0FBQ3BDLElBQU0sMkJBQTJCO0FBQ2pDLElBQU0sNEJBQTRCO0FBQ2xDLFNBQVMsMkJBQTJCO0NBQ25DLElBQUksY0FBYyxHQUFHLE9BQU87Q0FDNUIsT0FBTyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksTUFBTSx3QkFBd0I7QUFDakU7Ozs7Ozs7Ozs7O0FBV0EsZUFBZSxNQUFNLGdCQUFnQjtDQUNwQyxJQUFJO0NBQ0osSUFBSSxPQUFPLG1CQUFtQixVQUFVLFFBQVEsZ0JBQVI7RUFDdkMsS0FBSztHQUNKLFlBQVk7R0FDWjtFQUNELEtBQUs7R0FDSixZQUFZLHlCQUF5QjtHQUNyQztFQUNELFNBQVMsTUFBTSxJQUFJLE1BQU0sbURBQW1ELGVBQWUsNkZBQTZGO0NBQ3pMO01BQ0ssSUFBSSxPQUFPLG1CQUFtQixhQUFhLFlBQVkseUJBQXlCO01BQ2hGO0VBQ0osSUFBSSxpQkFBaUIsNkJBQTZCLE1BQU0sSUFBSSxNQUFNLHdEQUF3RCxlQUFlLDJEQUEyRCw0QkFBNEIsNE5BQTROO0VBQzViLFlBQVk7Q0FDYjtDQUNBLE9BQU8sSUFBSSxTQUFTLFlBQVk7RUFDL0IsTUFBTSxZQUFZLFdBQVcsU0FBUyxTQUFTO0VBQy9DLElBQUksY0FBYywrQkFBK0IsY0FBYyxLQUFLLGNBQWMsU0FBUyxHQUFHLFVBQVUsTUFBTTtDQUMvRyxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7O0FDdEJBLElBQU0sT0FBTyxNQUFNLGFBQWE7Q0FDL0IsT0FBTyxJQUFJLHVCQUF1QixNQUFNLFFBQVE7QUFDakQ7QUFDQSxJQUFNLG9CQUFvQixFQUFFLFNBQVM7Q0FDcEMsZ0JBQWdCO0NBQ2hCLGlCQUFpQjtDQUNqQixZQUFZO0FBQ2IsRUFBRTtBQUNGLElBQUkseUJBQXlCLGNBQWMsWUFBWTtDQUN0RDtDQUNBLFlBQVksTUFBTSxVQUFVO0VBQzNCLFVBQVUsT0FBTyxnQkFBZ0IsYUFBYSw2SEFBNkgsSUFBSTtFQUMvSyxNQUFNLE9BQU8sTUFBTSxPQUFPLFNBQVM7R0FDbEMsTUFBTSxFQUFFLFFBQVEsUUFBUSxhQUFhLGtCQUFrQixLQUFLLE9BQU87Ozs7O0dBS25FLE1BQU0sVUFBVSxJQUFJLFFBQVE7R0FDNUIsT0FBTyxrQkFBa0I7R0FDekIsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEtBQUssT0FBTyxHQUFHLEtBQUssb0JBQW9CLEtBQUssU0FBUyxPQUFPOzs7Ozs7R0FNNUYsTUFBTSxTQUFTLE9BQU8sT0FBTyxNQUFNO0lBQ2xDO0lBQ0E7R0FDRCxDQUFDLENBQUM7R0FDRixPQUFPO0VBQ1IsQ0FBQztFQUNELEtBQUssb0NBQW9DLElBQUksUUFBUTtDQUN0RDtDQUNBLE1BQU0sVUFBVSxNQUFNO0VBQ3JCLElBQUksS0FBSyxRQUFRLFFBQVEsSUFBSSxRQUFRLE1BQU0scUJBQXFCLE9BQU87RUFDdkUsTUFBTSxVQUFVLE1BQU0sTUFBTSxVQUFVLElBQUk7RUFDMUMsSUFBSSxXQUFXLENBQUMsS0FBSyxtQkFBbUIsT0FBTzs7Ozs7O0dBTTlDLE1BQU0sTUFBTSxJQUFJO0lBQ2YsU0FBUyxLQUFLOzs7OztJQUtkLFVBQVUsSUFBSSxTQUFTLGVBQWUsaUJBQWlCO0dBQ3hELENBQUM7R0FDRCxLQUFLLGtCQUFrQixJQUFJLEtBQUssT0FBTztFQUN4QztFQUNBLE9BQU87Q0FDUjtDQUNBLE1BQU0sSUFBSSxNQUFNOzs7Ozs7RUFNZixLQUFLLFNBQVMsTUFBTSxPQUFPO0NBQzVCO0NBQ0Esb0JBQW9CLFNBQVMsU0FBUztFQUNyQyxNQUFNLFlBQVksWUFBWSxRQUFRLEdBQUc7RUFDekMsUUFBUSxHQUFHLFlBQVksRUFBRSxXQUFXO0dBQ25DLFFBQVEsZUFBZSxTQUFTLGNBQWMsR0FBRyxhQUFhLEVBQUUsZ0JBQWdCLEtBQUssT0FBTyxHQUFHLFdBQVcsU0FBUyxPQUFPLFVBQVUsZUFBZTtHQUNuSixRQUFRLElBQUksS0FBSyxNQUFNO0dBQ3ZCLFFBQVEsU0FBUztFQUNsQixDQUFDO0VBQ0QsUUFBUSxHQUFHLGVBQWU7R0FDekIsUUFBUSxlQUFlLFNBQVMsY0FBYyxHQUFHLGFBQWEsRUFBRSx5QkFBeUIsR0FBRyxXQUFXLFVBQVUsT0FBTyxVQUFVLGVBQWU7R0FDakosUUFBUSxJQUFJLFlBQVksSUFBSTtHQUM1QixRQUFRLFNBQVM7RUFDbEIsQ0FBQztFQUNELFFBQVEsR0FBRyxlQUFlO0dBQ3pCLFFBQVEsZUFBZSxTQUFTLGNBQWMsR0FBRyxhQUFhLEVBQUUsb0JBQW9CLEdBQUcsV0FBVyxVQUFVLE9BQU8sVUFBVSxlQUFlO0dBQzVJLFFBQVEsSUFBSSxZQUFZLElBQUk7R0FDNUIsUUFBUSxTQUFTO0VBQ2xCLENBQUM7Q0FDRjtBQUNEO0FBQ0EsSUFBTSxpQkFBaUIsT0FBTyxJQUFJLGdCQUFnQjtBQUNsRCxJQUFJLHdCQUF3QixNQUFNO0NBQ2pDLENBQUM7Q0FDRDtDQUNBO0NBQ0E7Q0FDQTtDQUNBLFlBQVksWUFBWTtFQUN2QixLQUFLLFdBQVcsSUFBSSxZQUFZO0VBQ2hDLEtBQUssY0FBYztFQUNuQixLQUFLLFVBQVUsUUFBUSxjQUFjO0VBQ3JDLEtBQUssWUFBWTtDQUNsQjs7OztDQUlBLEtBQUssU0FBUztFQUNiLElBQUksV0FBVyxXQUFXLFFBQVEsU0FBUyxNQUFNO0dBQ2hELEtBQUssV0FBVyxRQUFRLEtBQUs7R0FDN0I7RUFDRDtFQUNBLEtBQUssYUFBYTtHQUNqQixJQUFJLFFBQVE7R0FDWixPQUFPLFFBQVE7R0FDZixNQUFNLE9BQU8sUUFBUSxTQUFTLFdBQVcsS0FBSyxVQUFVLFFBQVEsSUFBSSxJQUFJLFFBQVE7RUFDakYsQ0FBQztDQUNGOzs7O0NBSUEsY0FBYyxPQUFPO0VBQ3BCLElBQUksaUJBQWlCLGNBQWM7Ozs7O0dBS2xDLEtBQUssYUFBYTtJQUNqQixJQUFJLE1BQU0sZUFBZSxLQUFLO0lBQzlCLE9BQU8sTUFBTSxTQUFTLFlBQVksS0FBSyxJQUFJLE1BQU07SUFDakQsTUFBTSxNQUFNO0dBQ2IsQ0FBQztHQUNEO0VBQ0Q7RUFDQSxJQUFJLE1BQU0sU0FBUyxTQUFTO0dBQzNCLEtBQUssTUFBTTtHQUNYO0VBQ0Q7RUFDQSxJQUFJLE1BQU0sU0FBUyxTQUFTO0dBQzNCLEtBQUssTUFBTTtHQUNYO0VBQ0Q7Q0FDRDs7Ozs7O0NBTUEsUUFBUTtFQUNQLElBQUksS0FBSyxXQUFXO0VBQ3BCLEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssWUFBWTtFQUNqQixLQUFLLFFBQVEsUUFBUTtFQUNyQixLQUFLLGVBQWUsRUFBRSxLQUFLLElBQUksV0FBVyxPQUFPLENBQUM7Q0FDbkQ7Ozs7Q0FJQSxRQUFRO0VBQ1AsSUFBSSxLQUFLLFdBQVc7RUFDcEIsSUFBSTtHQUNILEtBQUssWUFBWSxNQUFNO0dBQ3ZCLEtBQUssWUFBWTtHQUNqQixLQUFLLFFBQVEsUUFBUTtFQUN0QixRQUFRLENBQUM7RUFDVCxLQUFLLGVBQWUsRUFBRSxLQUFLLElBQUksV0FBVyxPQUFPLENBQUM7Q0FDbkQ7Q0FDQSxTQUFTLE9BQU87RUFDZixJQUFJLEtBQUssV0FBVztFQUNwQixJQUFJO0dBQ0gsS0FBSyxZQUFZLFFBQVEsS0FBSztFQUMvQixTQUFTLE9BQU87R0FDZixRQUFRLE1BQU0sS0FBSztHQUNuQixTQUFTLE1BQU0sa0ZBQWtGO0VBQ2xHO0NBQ0Q7Q0FDQSxXQUFXLE9BQU87RUFDakIsS0FBSyxTQUFTLEtBQUssU0FBUyxPQUFPLFNBQVMsTUFBTSxLQUFLLENBQUM7Q0FDekQ7Q0FDQSxhQUFhLFNBQVM7RUFDckIsTUFBTSxTQUFTLENBQUM7RUFDaEIsSUFBSSxRQUFRLElBQUksT0FBTyxLQUFLLE1BQU0sUUFBUSxJQUFJO0VBQzlDLElBQUksUUFBUSxPQUFPLE9BQU8sS0FBSyxTQUFTLFFBQVEsTUFBTSxTQUFTLEdBQUc7RUFDbEUsSUFBSSxRQUFRLFFBQVE7Ozs7OztFQU1wQixLQUFLLE1BQU0sUUFBUSxRQUFRLEtBQUssU0FBUyxDQUFDLENBQUMsTUFBTSxZQUFZLEdBQUcsT0FBTyxLQUFLLFFBQVEsTUFBTTtFQUMxRixPQUFPLEtBQUssSUFBSSxFQUFFO0VBQ2xCLEtBQUssU0FBUyxLQUFLLFNBQVMsT0FBTyxPQUFPLEtBQUssSUFBSSxDQUFDLENBQUM7RUFDckQsS0FBSyxlQUFlLEVBQUUsS0FBSyxJQUFJLFdBQVcsV0FBVyxFQUFFLE1BQU07R0FDNUQsSUFBSSxRQUFRO0dBQ1osT0FBTyxRQUFRLE9BQU8sU0FBUyxLQUFLO0dBQ3BDLE1BQU0sUUFBUTtHQUNkO0VBQ0QsRUFBRSxDQUFDLENBQUM7Q0FDTDtBQUNEO0FBQ0EsSUFBSSx3QkFBd0IsTUFBTTtDQUNqQztDQUNBO0NBQ0EsWUFBWSxNQUFNO0VBQ2pCLEtBQUssV0FBVyxLQUFLO0VBQ3JCLEtBQUssVUFBVSxLQUFLO0NBQ3JCOzs7OztDQUtBLFVBQVU7RUFDVCxNQUFNLFNBQVMsSUFBSSxzQkFBc0IsS0FBSyxTQUFTLEtBQUs7R0FDM0QsaUJBQWlCLEtBQUssU0FBUyxnQkFBZ0I7R0FDL0MsU0FBUzs7Ozs7QUFLWixRQUFRLGtCQUFrQjtHQUN2QixRQUFRLEtBQUssU0FBUztFQUN2QixDQUFDO0VBQ0QsT0FBTyxrQkFBa0IsVUFBVTtHQUNsQyxPQUFPLGlCQUFpQixPQUFPLEVBQUUsUUFBUTtJQUN4QyxPQUFPO0lBQ1AsWUFBWTtJQUNaLFVBQVU7SUFDVixjQUFjO0dBQ2YsRUFBRSxDQUFDO0dBQ0gscUJBQXFCO0lBQ3BCLElBQUksQ0FBQyxNQUFNLGtCQUFrQixLQUFLLFFBQVEsY0FBYyxLQUFLO0dBQzlELENBQUM7RUFDRjtFQUNBLE9BQU8saUJBQWlCLFVBQVUsVUFBVTtHQUMzQyxPQUFPLGlCQUFpQixPQUFPLEVBQUUsUUFBUTtJQUN4QyxPQUFPO0lBQ1AsWUFBWTtJQUNaLFVBQVU7SUFDVixjQUFjO0dBQ2YsRUFBRSxDQUFDO0dBQ0gscUJBQXFCO0lBQ3BCLElBQUksQ0FBQyxNQUFNLGtCQUFrQixLQUFLLFFBQVEsY0FBYyxLQUFLO0dBQzlELENBQUM7RUFDRixDQUFDO0VBQ0QsT0FBTztDQUNSO0FBQ0Q7QUFDQSxJQUFNLFdBQVcsT0FBTyxVQUFVO0FBQ2xDLElBQU0sb0JBQW9CLE9BQU8sbUJBQW1CO0FBQ3BELElBQU0sZUFBZSxPQUFPLGNBQWM7QUFDMUMsSUFBTSxtQkFBbUIsT0FBTyxrQkFBa0I7QUFDbEQsSUFBTSxVQUFVLE9BQU8sU0FBUztBQUNoQyxJQUFNLGFBQWEsT0FBTyxZQUFZO0FBQ3RDLElBQU0sZ0JBQWdCLE9BQU8sZUFBZTtBQUM1QyxJQUFNLFdBQVcsT0FBTyxVQUFVO0FBQ2xDLElBQUksd0JBQXdCLE1BQU0sOEJBQThCLFlBQVk7Q0FDM0UsT0FBTyxhQUFhO0NBQ3BCLE9BQU8sT0FBTztDQUNkLE9BQU8sU0FBUztDQUNoQixhQUFhLHNCQUFzQjtDQUNuQyxPQUFPLHNCQUFzQjtDQUM3QixTQUFTLHNCQUFzQjtDQUMvQjtDQUNBO0NBQ0E7Q0FDQSxDQUFDO0NBQ0QsQ0FBQztDQUNELENBQUM7Q0FDRCxDQUFDO0NBQ0QsQ0FBQyxXQUFXO0NBQ1osQ0FBQyxjQUFjO0NBQ2YsQ0FBQyxpQkFBaUI7Q0FDbEIsQ0FBQyxZQUFZO0NBQ2IsWUFBWSxLQUFLLE1BQU07RUFDdEIsTUFBTTtFQUNOLEtBQUssTUFBTSxJQUFJLElBQUksR0FBRyxDQUFDLENBQUM7RUFDeEIsS0FBSyxrQkFBa0IsTUFBTSxtQkFBbUI7RUFDaEQsS0FBSyxhQUFhLEtBQUs7RUFDdkIsTUFBTSxVQUFVLElBQUksUUFBUSxNQUFNLFdBQVcsQ0FBQyxDQUFDO0VBQy9DLFFBQVEsT0FBTyxVQUFVLG1CQUFtQjtFQUM1QyxLQUFLLG9CQUFvQixJQUFJLGdCQUFnQjtFQUM3QyxLQUFLLHFCQUFxQjtFQUMxQixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLFlBQVksSUFBSSxRQUFRLEtBQUssS0FBSztHQUN0QyxRQUFRO0dBQ1I7R0FDQSxhQUFhLEtBQUssa0JBQWtCLFlBQVk7R0FDaEQsUUFBUSxLQUFLLGlCQUFpQixDQUFDO0VBQ2hDLENBQUM7RUFDRCxJQUFJLE1BQU0sUUFBUTtHQUNqQixJQUFJLEtBQUssT0FBTyxTQUFTO0lBQ3hCLEtBQUssTUFBTTtJQUNYO0dBQ0Q7R0FDQSxLQUFLLE9BQU8saUJBQWlCLGVBQWUsS0FBSyxNQUFNLEdBQUc7SUFDekQsTUFBTTtJQUNOLFFBQVEsS0FBSyxpQkFBaUIsQ0FBQztHQUNoQyxDQUFDO0VBQ0Y7RUFDQSxLQUFLLFFBQVE7Q0FDZDtDQUNBLElBQUksU0FBUztFQUNaLE9BQU8sS0FBSztDQUNiO0NBQ0EsSUFBSSxPQUFPLFNBQVM7RUFDbkIsSUFBSSxLQUFLLFVBQVUsS0FBSyxvQkFBb0IsUUFBUSxLQUFLLFFBQVE7RUFDakUsS0FBSyxXQUFXLFFBQVEsS0FBSyxJQUFJO0VBQ2pDLEtBQUssaUJBQWlCLFFBQVEsS0FBSyxRQUFRO0NBQzVDO0NBQ0EsSUFBSSxZQUFZO0VBQ2YsT0FBTyxLQUFLO0NBQ2I7Q0FDQSxJQUFJLFVBQVUsU0FBUztFQUN0QixJQUFJLEtBQUssYUFBYSxLQUFLLG9CQUFvQixXQUFXLEVBQUUsYUFBYSxLQUFLLFlBQVksQ0FBQztFQUMzRixLQUFLLGNBQWMsUUFBUSxLQUFLLElBQUk7RUFDcEMsS0FBSyxpQkFBaUIsV0FBVyxFQUFFLGFBQWEsS0FBSyxZQUFZLENBQUM7Q0FDbkU7Q0FDQSxJQUFJLFVBQVU7RUFDYixPQUFPLEtBQUs7Q0FDYjtDQUNBLElBQUksUUFBUSxTQUFTO0VBQ3BCLElBQUksS0FBSyxXQUFXLEtBQUssb0JBQW9CLFNBQVMsRUFBRSxhQUFhLEtBQUssVUFBVSxDQUFDO0VBQ3JGLEtBQUssWUFBWSxRQUFRLEtBQUssSUFBSTtFQUNsQyxLQUFLLGlCQUFpQixTQUFTLEVBQUUsYUFBYSxLQUFLLFVBQVUsQ0FBQztDQUMvRDtDQUNBLGlCQUFpQixNQUFNLFVBQVUsU0FBUztFQUN6QyxNQUFNLGlCQUFpQixNQUFNLFVBQVUsT0FBTztDQUMvQztDQUNBLG9CQUFvQixNQUFNLFVBQVUsU0FBUztFQUM1QyxNQUFNLG9CQUFvQixNQUFNLFVBQVUsT0FBTztDQUNsRDtDQUNBLGNBQWMsT0FBTztFQUNwQixPQUFPLE1BQU0sY0FBYyxLQUFLO0NBQ2pDO0NBQ0EsUUFBUTtFQUNQLEtBQUssaUJBQWlCLENBQUMsTUFBTTtFQUM3QixLQUFLLGFBQWEsS0FBSztDQUN4QjtDQUNBLE1BQU0sVUFBVTtFQUNmLE1BQU0sTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFDLE1BQU0sYUFBYTtHQUM5QyxLQUFLLGdCQUFnQixRQUFRO0VBQzlCLENBQUMsQ0FBQyxDQUFDLFlBQVk7R0FDZCxLQUFLLGVBQWU7RUFDckIsQ0FBQztDQUNGO0NBQ0EsZ0JBQWdCLFVBQVU7RUFDekIsSUFBSSxDQUFDLFNBQVMsTUFBTTtHQUNuQixLQUFLLGVBQWU7R0FDcEI7RUFDRDtFQUNBLElBQUksZUFBZSxRQUFRLEdBQUc7R0FDN0IsS0FBSyxzQkFBc0I7R0FDM0I7RUFDRDtFQUNBLElBQUksU0FBUyxXQUFXLE9BQU8sU0FBUyxRQUFRLElBQUksY0FBYyxNQUFNLHFCQUFxQjtHQUM1RixLQUFLLGVBQWU7R0FDcEI7RUFDRDtFQUNBLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssc0JBQXNCLFFBQVE7Q0FDcEM7Q0FDQSxxQkFBcUI7RUFDcEIscUJBQXFCO0dBQ3BCLElBQUksS0FBSyxlQUFlLEtBQUssUUFBUTtJQUNwQyxLQUFLLGFBQWEsS0FBSztJQUN2QixLQUFLLGNBQWMsSUFBSSxNQUFNLE1BQU0sQ0FBQztHQUNyQztFQUNELENBQUM7Q0FDRjtDQUNBLHNCQUFzQixVQUFVO0VBQy9CLE1BQU0sZ0JBQWdCLElBQUkseUJBQXlCO0dBQ2xELFVBQVUsWUFBWTtJQUNyQixJQUFJLFFBQVEsSUFBSSxLQUFLLGdCQUFnQixRQUFRO0lBQzdDLE1BQU0sZUFBZSxJQUFJLGFBQWEsUUFBUSxRQUFRLFFBQVEsUUFBUSxXQUFXO0tBQ2hGLE1BQU0sUUFBUTtLQUNkLFFBQVEsS0FBSyxTQUFTLENBQUM7S0FDdkIsYUFBYSxLQUFLO0tBQ2xCLFlBQVk7SUFDYixDQUFDO0lBQ0QsS0FBSyxjQUFjLEdBQUcsWUFBWTtJQUNsQyxLQUFLLGNBQWMsWUFBWTtHQUNoQztHQUNBLFFBQVEscUJBQXFCO0lBQzVCLEtBQUsscUJBQXFCO0dBQzNCO0dBQ0EsYUFBYTtJQUNaLE1BQU0sSUFBSSxNQUFNLGlDQUFpQztHQUNsRDtHQUNBLGFBQWE7SUFDWixLQUFLLGVBQWU7R0FDckI7RUFDRCxDQUFDO0VBQ0QsU0FBUyxLQUFLLE9BQU8sYUFBYSxDQUFDLENBQUMsV0FBVztHQUM5QyxLQUFLLHlCQUF5QixRQUFRO0VBQ3ZDLENBQUMsQ0FBQyxDQUFDLFlBQVk7R0FDZCxLQUFLLGVBQWU7RUFDckIsQ0FBQztDQUNGO0NBQ0EseUJBQXlCLFVBQVU7RUFDbEMsSUFBSSxDQUFDLGVBQWUsUUFBUSxHQUFHLEtBQUssc0JBQXNCO0NBQzNEO0NBQ0EsTUFBTSx3QkFBd0I7RUFDN0IscUJBQXFCO0dBQ3BCLElBQUksS0FBSyxlQUFlLEtBQUssUUFBUTtHQUNyQyxLQUFLLGFBQWEsS0FBSztHQUN2QixLQUFLLGNBQWMsSUFBSSxNQUFNLE9BQU8sQ0FBQztFQUN0QyxDQUFDO0VBQ0QsTUFBTSxTQUFTLEtBQUssaUJBQWlCLENBQUM7RUFDdEMsSUFBSSxPQUFPLFNBQVM7RUFDcEIsTUFBTSxVQUFVLFFBQVEsY0FBYztFQUN0QyxNQUFNLGdCQUFnQixRQUFRLFFBQVE7RUFDdEMsT0FBTyxpQkFBaUIsU0FBUyxTQUFTLEVBQUUsTUFBTSxLQUFLLENBQUM7RUFDeEQsTUFBTSxRQUFRLEtBQUssQ0FBQyxNQUFNLEtBQUssa0JBQWtCLEdBQUcsUUFBUSxPQUFPLENBQUMsQ0FBQyxDQUFDLGNBQWM7R0FDbkYsT0FBTyxvQkFBb0IsU0FBUyxPQUFPO0VBQzVDLENBQUM7RUFDRCxJQUFJLE9BQU8sU0FBUztFQUNwQixlQUFlLFlBQVk7R0FDMUIsSUFBSSxLQUFLLGVBQWUsS0FBSyxZQUFZO0dBQ3pDLElBQUksS0FBSyxrQkFBa0IsSUFBSSxLQUFLLFNBQVMsQ0FBQyxRQUFRLElBQUksaUJBQWlCLEtBQUssYUFBYTtHQUM3RixNQUFNLEtBQUssUUFBUTtFQUNwQixDQUFDO0NBQ0Y7Q0FDQSxpQkFBaUI7RUFDaEIscUJBQXFCO0dBQ3BCLElBQUksS0FBSyxlQUFlLEtBQUssUUFBUTtJQUNwQyxLQUFLLGFBQWEsS0FBSztJQUN2QixLQUFLLGNBQWMsSUFBSSxNQUFNLE9BQU8sQ0FBQztHQUN0QztFQUNELENBQUM7Q0FDRjtBQUNEOzs7OztBQUtBLFNBQVMsZUFBZSxVQUFVO0NBQ2pDLE9BQU8sU0FBUyxTQUFTLFdBQVcsU0FBUyxXQUFXLEtBQUssU0FBUyxlQUFlLE1BQU0sTUFBTSxLQUFLLFNBQVMsUUFBUSxRQUFRLENBQUMsQ0FBQyxDQUFDLFdBQVcsS0FBSyxTQUFTLFNBQVM7QUFDcks7QUFDQSxJQUFJLDJCQUEyQixjQUFjLGVBQWU7Q0FDM0Q7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLHlCQUF5QjtDQUN6QixVQUFVO0VBQ1QsSUFBSSxLQUFLO0VBQ1QsT0FBTyxLQUFLO0VBQ1osTUFBTSxLQUFLO0NBQ1o7Q0FDQSxZQUFZLGdCQUFnQjtFQUMzQixNQUFNO0dBQ0wsUUFBUSxVQUFVO0lBQ2pCLEtBQUsseUJBQXlCLEtBQUs7R0FDcEM7R0FDQSxRQUFRLFdBQVc7SUFDbEIsS0FBSyxlQUFlLFFBQVEsTUFBTTtHQUNuQztHQUNBLGFBQWE7SUFDWixLQUFLLGVBQWUsUUFBUTtHQUM3QjtFQUNELENBQUM7RUFDRCxLQUFLLGlCQUFpQjtFQUN0QixLQUFLLFVBQVUsSUFBSSxZQUFZO0VBQy9CLEtBQUssV0FBVztDQUNqQjtDQUNBLGVBQWU7RUFDZCxLQUFLLFVBQVU7R0FDZCxJQUFJLEtBQUs7R0FDVCxPQUFPLEtBQUs7R0FDWixNQUFNLEtBQUs7RUFDWjtDQUNEO0NBQ0EseUJBQXlCLE9BQU87RUFDL0IsSUFBSSxLQUFLLFVBQVUsTUFBTTtHQUN4QixLQUFLLFNBQVM7R0FDZCxLQUFLLFdBQVc7R0FDaEIsS0FBSyxjQUFjO0VBQ3BCLE9BQU87R0FDTixNQUFNLGFBQWEsSUFBSSxXQUFXLEtBQUssT0FBTyxTQUFTLE1BQU0sTUFBTTtHQUNuRSxXQUFXLElBQUksS0FBSyxNQUFNO0dBQzFCLFdBQVcsSUFBSSxPQUFPLEtBQUssT0FBTyxNQUFNO0dBQ3hDLEtBQUssU0FBUztFQUNmO0VBQ0EsTUFBTSxlQUFlLEtBQUssT0FBTztFQUNqQyxJQUFJLFlBQVk7RUFDaEIsT0FBTyxLQUFLLFdBQVcsY0FBYztHQUNwQyxJQUFJLEtBQUssd0JBQXdCO0lBQ2hDLElBQUksS0FBSyxPQUFPLEtBQUssY0FBYyxJQUFJLFlBQVksRUFBRSxLQUFLO0lBQzFELEtBQUsseUJBQXlCO0dBQy9CO0dBQ0EsSUFBSSxVQUFVO0dBQ2QsT0FBTyxLQUFLLFdBQVcsZ0JBQWdCLFlBQVksSUFBSSxFQUFFLEtBQUssVUFBVSxRQUFRLEtBQUssT0FBTyxLQUFLLFdBQXpCO0lBQ3ZFLEtBQUs7S0FDSixJQUFJLEtBQUssZ0JBQWdCLElBQUksS0FBSyxjQUFjLEtBQUssV0FBVztLQUNoRTtJQUNELEtBQUs7S0FDSixLQUFLLHlCQUF5QjtLQUM5QjtJQUNELEtBQUssSUFBSSxVQUFVLEtBQUs7R0FDekI7R0FDQSxJQUFJLFlBQVksSUFBSTtHQUNwQixLQUFLLFlBQVksS0FBSyxPQUFPLFNBQVMsV0FBVyxPQUFPLEdBQUcsS0FBSyxXQUFXO0dBQzNFLFlBQVksS0FBSztHQUNqQixLQUFLLGNBQWM7RUFDcEI7RUFDQSxJQUFJLGNBQWMsY0FBYyxLQUFLLFNBQVMsS0FBSztPQUM5QyxJQUFJLGNBQWMsR0FBRztHQUN6QixLQUFLLFNBQVMsS0FBSyxPQUFPLFNBQVMsU0FBUztHQUM1QyxLQUFLLFlBQVk7RUFDbEI7Q0FDRDtDQUNBLFlBQVksTUFBTSxhQUFhO0VBQzlCLElBQUksS0FBSyxXQUFXLEdBQUc7R0FDdEIsSUFBSSxLQUFLLFFBQVEsU0FBUyxLQUFLLEdBQUc7SUFDakMsS0FBSyxRQUFRLFFBQVEsS0FBSztJQUMxQjtHQUNEO0dBQ0EsS0FBSyxlQUFlLFFBQVEsS0FBSyxPQUFPO0dBQ3hDLEtBQUssYUFBYTtHQUNsQjtFQUNEO0VBQ0EsSUFBSSxjQUFjLEdBQUc7R0FDcEIsTUFBTSxRQUFRLEtBQUssUUFBUSxPQUFPLEtBQUssU0FBUyxHQUFHLFdBQVcsQ0FBQztHQUMvRCxNQUFNLGNBQWMsZUFBZSxLQUFLLGNBQWMsT0FBTyxLQUFLLElBQUk7R0FDdEUsTUFBTSxRQUFRLEtBQUssUUFBUSxPQUFPLEtBQUssU0FBUyxXQUFXLENBQUM7R0FDNUQsUUFBUSxPQUFSO0lBQ0MsS0FBSztLQUNKLEtBQUssUUFBUSxPQUFPLEtBQUssUUFBUSxPQUFPLEtBQUssUUFBUSxPQUFPLE9BQU8sUUFBUTtLQUMzRTtJQUNELEtBQUs7S0FDSixLQUFLLFFBQVEsUUFBUTtLQUNyQjtJQUNELEtBQUs7S0FDSixLQUFLLFFBQVEsS0FBSztLQUNsQjtJQUNELEtBQUs7Ozs7O0lBS0wsSUFBSSxRQUFRLEtBQUssS0FBSyxHQUFHLEtBQUssZUFBZSxRQUFRLFNBQVMsT0FBTyxFQUFFLENBQUM7R0FDekU7RUFDRDtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7OztBQWVBLFNBQVMsa0JBQWtCLFNBQVM7Q0FDbkMsVUFBVSxDQUFDLFFBQVEsT0FBTyxTQUFTLGtGQUFrRixRQUFRLFFBQVEsUUFBUSxHQUFHO0NBQ2hKLElBQUk7Q0FDSixNQUFNLFdBQVcsSUFBSSxlQUFlO0VBQ25DLE1BQU0sbUJBQW1CO0dBQ3hCLGFBQWE7RUFDZDtFQUNBLFNBQVM7R0FDUixPQUFPLE1BQU07RUFDZDtDQUNELENBQUM7Q0FDRCxNQUFNLFNBQVMsSUFBSSxzQkFBc0IsVUFBVTtDQUNuRCxNQUFNLFNBQVMsSUFBSSxzQkFBc0I7RUFDeEM7RUFDQTtDQUNELENBQUM7Q0FDRCxNQUFNLFdBQVcsSUFBSSxTQUFTLFVBQVUsaUJBQWlCO0NBQ3pELFFBQVEsT0FBTyxpQkFBaUIsZUFBZTtFQUM5QyxPQUFPLE1BQU07Q0FDZCxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDakIsT0FBTztFQUNOO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7O0FDdmtCQSxJQUFNLGNBQWMsT0FBTyxVQUFVLFNBQVMsc0JBQXNCO0NBQ25FLFFBQVEsTUFBTSxnQkFBZ0I7RUFDN0I7RUFDQSxXQUFXLGdCQUFnQjtFQUMzQjtFQUNBO0NBQ0QsQ0FBQyxFQUFBLEVBQUk7QUFDTjs7Ozs7Ozs7Ozs7Ozs7O0FDSkEsU0FBUyxPQUFPLE9BQU8sTUFBTTtDQUM1QixNQUFNLFVBQVUsSUFBSSxRQUFRLGlCQUFpQixVQUFVLE1BQU0sTUFBTSxJQUFJLE9BQU8sSUFBSTtDQUNsRixVQUFVLENBQUMsUUFBUSxVQUFVLG9NQUFvTSxRQUFRLFFBQVEsUUFBUSxHQUFHO0NBQzVQLE1BQU0sZUFBZSxRQUFRLE1BQU07Ozs7Ozs7Q0FPbkMsYUFBYSxRQUFRLE9BQU8sVUFBVSxpQkFBaUI7Ozs7Ozs7Ozs7Q0FVdkQsYUFBYSxRQUFRLE9BQU8sZ0JBQWdCO0NBQzVDLE9BQU87QUFDUiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5XX0=