import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/LeaderboardScreen.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2296aa11";
import { useLeaderboard, useMatchHistory } from "/src/features/matches/hooks.ts";
import { useGameStore } from "/src/stores/gameStore.ts";
import { useDialog } from "/src/ui/hooks/useDialog.ts";
import styles from "/src/ui/components/LeaderboardScreen.module.css";
var _jsxFileName = "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LeaderboardScreen.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2296aa11";
var _s = $RefreshSig$();
function formatDate(isoString) {
	const d = new Date(isoString);
	const months = [
		"JAN",
		"FEB",
		"MAR",
		"APR",
		"MAY",
		"JUN",
		"JUL",
		"AUG",
		"SEP",
		"OCT",
		"NOV",
		"DEC"
	];
	const day = String(d.getDate()).padStart(2, "0");
	const month = months[d.getMonth()];
	const hours = String(d.getHours()).padStart(2, "0");
	const mins = String(d.getMinutes()).padStart(2, "0");
	return `${day} ${month} - ${hours}:${mins}`;
}
export const LeaderboardScreen = ({ initialTab, onClose }) => {
	_s();
	const [activeTab, setActiveTab] = useState(initialTab);
	const [page, setPage] = useState(1);
	const sessionTime = useGameStore((s) => s.sessionTime);
	const spawnInterval = useGameStore((s) => s.spawnInterval);
	const configKey = `${sessionTime}-${spawnInterval}`;
	const playerId = useGameStore((s) => s.playerId);
	const dialogRef = useDialog(true, onClose);
	const { data: rankingData, isLoading: loadingRanking, isError: errorRanking, refetch: refetchRanking } = useLeaderboard(configKey, page);
	const { data: historyData, isLoading: loadingHistory, isError: errorHistory, refetch: refetchHistory } = useMatchHistory(playerId, page);
	const isLoading = activeTab === "ranking" ? loadingRanking : loadingHistory;
	const isError = activeTab === "ranking" ? errorRanking : errorHistory;
	const refetch = activeTab === "ranking" ? refetchRanking : refetchHistory;
	const currentData = activeTab === "ranking" ? rankingData : historyData;
	const totalPages = Math.max(1, Math.ceil((currentData?.total || 0) / 10));
	const handleTabSwitch = (tab) => {
		if (activeTab !== tab) {
			setActiveTab(tab);
			setPage(1);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `${styles.card} responsive-card`,
		role: "dialog",
		"aria-modal": "true",
		"aria-labelledby": "leaderboard-title",
		ref: dialogRef,
		tabIndex: -1,
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: styles.title,
				children: activeTab === "ranking" ? "Leaderboard" : "Match History"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.tabButtons,
				children: [/* @__PURE__ */ _jsxDEV("button", {
					className: activeTab === "ranking" ? styles.tabActive : styles.tabInactive,
					onClick: () => handleTabSwitch("ranking"),
					children: "Ranking"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					className: activeTab === "history" ? styles.tabActive : styles.tabInactive,
					onClick: () => handleTabSwitch("history"),
					children: "History"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 13
			}, this),
			activeTab === "ranking" ? /* @__PURE__ */ _jsxDEV("p", {
				className: styles.categoryInfo,
				children: [
					sessionTime,
					"s Battle - ",
					spawnInterval,
					"s Spawn Interval"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 17
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 18
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.tableContainer,
				children: isLoading ? /* @__PURE__ */ _jsxDEV("div", {
					className: styles.loading,
					children: "Loading records..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 21
				}, this) : isError ? /* @__PURE__ */ _jsxDEV("div", {
					className: styles.empty,
					children: [
						"Failed to load ranking ",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 48
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: styles.pageButton,
							onClick: () => refetch(),
							children: "Retry"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 25
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 21
				}, this) : currentData?.data.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: styles.empty,
					children: "No records found."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 21
				}, this) : /* @__PURE__ */ _jsxDEV("table", {
					className: styles.table,
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: activeTab === "ranking" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("th", { children: "Rank" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 39
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Player" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 52
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Score" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 67
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Time" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 81
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Date" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 94
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 37
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("th", { children: "Date" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 39
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Result" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 52
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Score" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 67
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Time" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 81
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 37
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 29
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: currentData?.data.map((record, index) => {
						const rank = (page - 1) * 10 + index + 1;
						const isFirstPlace = activeTab === "ranking" && rank === 1;
						return /* @__PURE__ */ _jsxDEV("tr", {
							className: record.playerId === playerId ? styles.highlightRow : "",
							children: activeTab === "ranking" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV("td", { children: rank }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 49
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: [isFirstPlace && /* @__PURE__ */ _jsxDEV("img", {
									src: "/assets/png/default/ui/hud/icon_score.png",
									alt: "Star",
									style: {
										width: 20,
										verticalAlign: "middle",
										marginRight: 6
									}
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 57
								}, this), record.playerName] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 49
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: record.score }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 49
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: [Math.floor(record.durationMs / 1e3), "s"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 126,
									columnNumber: 49
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: formatDate(record.createdAt) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 49
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 45
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV("td", { children: formatDate(record.createdAt) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 49
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: record.endReason === "time_up" ? styles.textGreen : styles.textRed,
									children: record.endReason === "time_up" ? "Victory" : "Defeated"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 49
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: record.score }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 49
								}, this),
								/* @__PURE__ */ _jsxDEV("td", { children: [Math.floor(record.durationMs / 1e3), "s"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 49
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 45
							}, this)
						}, record.id, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 37
						}, this);
					}) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 21
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 84,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: styles.pagination,
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						className: styles.pageButton,
						disabled: page <= 1 || isLoading,
						onClick: () => setPage((p) => p - 1),
						children: /* @__PURE__ */ _jsxDEV("img", {
							src: "/assets/png/default/ui/controls/icon_play.png",
							className: `${styles.pageIcon} ${styles.iconFlipped}`,
							alt: "Prev"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						style: {
							color: "white",
							fontWeight: "bold"
						},
						children: [
							"Page ",
							page,
							" of ",
							totalPages
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: styles.pageButton,
						disabled: page >= totalPages || isLoading,
						onClick: () => setPage((p) => p + 1),
						children: /* @__PURE__ */ _jsxDEV("img", {
							src: "/assets/png/default/ui/controls/icon_play.png",
							className: styles.pageIcon,
							alt: "Next"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 147,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				className: styles.closeButton,
				onClick: onClose,
				children: "Back to Menu"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 167,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 9
	}, this);
};
_s(LeaderboardScreen, "cTX8OU/BjQfhlNgjUPsb5Q7Wmts=", false, function() {
	return [
		useGameStore,
		useGameStore,
		useGameStore,
		useDialog,
		useLeaderboard,
		useMatchHistory
	];
});
_c = LeaderboardScreen;
var _c;
$RefreshReg$(_c, "LeaderboardScreen");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/LeaderboardScreen.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LeaderboardScreen.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LeaderboardScreen.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Cliente/Documents/GitHub/Pirate_Battle_Challenge/src/ui/components/LeaderboardScreen.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGdCQUFnQix1QkFBdUI7QUFDaEQsU0FBUyxvQkFBb0I7QUFFN0IsU0FBUyxpQkFBaUI7QUFFMUIsT0FBTyxZQUFZOzs7O0FBT25CLFNBQVMsV0FBVyxXQUFtQjtDQUNuQyxNQUFNLElBQUksSUFBSSxLQUFLLFNBQVM7Q0FDNUIsTUFBTSxTQUFTO0VBQUM7RUFBTztFQUFPO0VBQU87RUFBTztFQUFPO0VBQU87RUFBTztFQUFPO0VBQU87RUFBTztFQUFPO0NBQUs7Q0FDbEcsTUFBTSxNQUFNLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBQy9DLE1BQU0sUUFBUSxPQUFPLEVBQUUsU0FBUztDQUNoQyxNQUFNLFFBQVEsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7Q0FDbEQsTUFBTSxPQUFPLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBQ25ELE9BQU8sR0FBRyxJQUFJLEdBQUcsTUFBTSxLQUFLLE1BQU0sR0FBRztBQUN6QztBQUVBLE9BQU8sTUFBTSxxQkFBdUQsRUFBRSxZQUFZLGNBQWM7O0NBQzVGLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFnQyxVQUFVO0NBQzVFLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDO0NBRWxDLE1BQU0sY0FBYyxjQUFhLE1BQUssRUFBRSxXQUFXO0NBQ25ELE1BQU0sZ0JBQWdCLGNBQWEsTUFBSyxFQUFFLGFBQWE7Q0FDdkQsTUFBTSxZQUFZLEdBQUcsWUFBWSxHQUFHO0NBQ3BDLE1BQU0sV0FBVyxjQUFhLE1BQUssRUFBRSxRQUFRO0NBRTdDLE1BQU0sWUFBWSxVQUFVLE1BQU0sT0FBTztDQUV6QyxNQUFNLEVBQUUsTUFBTSxhQUFhLFdBQVcsZ0JBQWdCLFNBQVMsY0FBYyxTQUFTLG1CQUFtQixlQUFlLFdBQVcsSUFBSTtDQUN2SSxNQUFNLEVBQUUsTUFBTSxhQUFhLFdBQVcsZ0JBQWdCLFNBQVMsY0FBYyxTQUFTLG1CQUFtQixnQkFBZ0IsVUFBVSxJQUFJO0NBRXZJLE1BQU0sWUFBWSxjQUFjLFlBQVksaUJBQWlCO0NBQzdELE1BQU0sVUFBVSxjQUFjLFlBQVksZUFBZTtDQUN6RCxNQUFNLFVBQVUsY0FBYyxZQUFZLGlCQUFpQjtDQUMzRCxNQUFNLGNBQWMsY0FBYyxZQUFZLGNBQWM7Q0FFNUQsTUFBTSxhQUFhLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxhQUFhLFNBQVMsS0FBSyxFQUFFLENBQUM7Q0FFeEUsTUFBTSxtQkFBbUIsUUFBK0I7RUFDcEQsSUFBSSxjQUFjLEtBQUs7R0FDbkIsYUFBYSxHQUFHO0dBQ2hCLFFBQVEsQ0FBQztFQUNiO0NBQ0o7Q0FFQSxPQUNJLHdCQUFDLE9BQUQ7RUFDSSxXQUFXLEdBQUcsT0FBTyxLQUFLO0VBQzFCLE1BQUs7RUFDTCxjQUFXO0VBQ1gsbUJBQWdCO0VBQ2hCLEtBQUs7RUFDTCxVQUFVLENBQUM7WUFOZjtHQVFJLHdCQUFDLE1BQUQ7SUFBSSxXQUFXLE9BQU87Y0FBUSxjQUFjLFlBQVksZ0JBQWdCO0dBQW9COzs7OztHQUU1Rix3QkFBQyxPQUFEO0lBQUssV0FBVyxPQUFPO2NBQXZCLENBQ0ksd0JBQUMsVUFBRDtLQUNJLFdBQVcsY0FBYyxZQUFZLE9BQU8sWUFBWSxPQUFPO0tBQy9ELGVBQWUsZ0JBQWdCLFNBQVM7ZUFDM0M7SUFFTzs7OztjQUNSLHdCQUFDLFVBQUQ7S0FDSSxXQUFXLGNBQWMsWUFBWSxPQUFPLFlBQVksT0FBTztLQUMvRCxlQUFlLGdCQUFnQixTQUFTO2VBQzNDO0lBRU87Ozs7WUFDUDs7Ozs7O0dBRUosY0FBYyxZQUNYLHdCQUFDLEtBQUQ7SUFBRyxXQUFXLE9BQU87Y0FBckI7S0FDSztLQUFZO0tBQVk7S0FBYztJQUN4Qzs7Ozs7Y0FDRixvQ0FBSTs7Ozs7R0FFVCx3QkFBQyxPQUFEO0lBQUssV0FBVyxPQUFPO2NBQ2xCLFlBQ0csd0JBQUMsT0FBRDtLQUFLLFdBQVcsT0FBTztlQUFTO0lBQXVCOzs7O2VBQ3ZELFVBQ0Esd0JBQUMsT0FBRDtLQUFLLFdBQVcsT0FBTztlQUF2QjtNQUE4QjtNQUNILHdCQUFDLE1BQUQsQ0FBSzs7Ozs7TUFDNUIsd0JBQUMsVUFBRDtPQUFRLFdBQVcsT0FBTztPQUFZLGVBQWUsUUFBUTtpQkFBRztNQUFhOzs7OztLQUM1RTs7Ozs7ZUFDTCxhQUFhLEtBQUssV0FBVyxJQUM3Qix3QkFBQyxPQUFEO0tBQUssV0FBVyxPQUFPO2VBQU87SUFBc0I7Ozs7ZUFFcEQsd0JBQUMsU0FBRDtLQUFPLFdBQVcsT0FBTztlQUF6QixDQUNJLHdCQUFDLFNBQUQsWUFDSSx3QkFBQyxNQUFELFlBQ0ssY0FBYyxZQUNYO01BQUUsd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLFFBQVM7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7O0tBQUc7Ozs7Z0JBRXhFO01BQUUsd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLFFBQVM7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLE9BQVE7Ozs7O0tBQUc7Ozs7Y0FFL0Q7Ozs7Y0FDRDs7OztlQUNQLHdCQUFDLFNBQUQsWUFDSyxhQUFhLEtBQUssS0FBSyxRQUFRLFVBQVU7TUFDdEMsTUFBTSxRQUFRLE9BQU8sS0FBSyxLQUFLLFFBQVE7TUFDdkMsTUFBTSxlQUFlLGNBQWMsYUFBYSxTQUFTO01BRXpELE9BQ0ksd0JBQUMsTUFBRDtPQUFvQixXQUFXLE9BQU8sYUFBYSxXQUFXLE9BQU8sZUFBZTtpQkFDL0UsY0FBYyxZQUNYO1FBQ0ksd0JBQUMsTUFBRCxZQUFLLEtBQVM7Ozs7O1FBQ2Qsd0JBQUMsTUFBRCxhQUNLLGdCQUNHLHdCQUFDLE9BQUQ7U0FDSSxLQUFJO1NBQ0osS0FBSTtTQUNKLE9BQU87VUFBRSxPQUFPO1VBQUksZUFBZTtVQUFVLGFBQWE7U0FBRTtRQUMvRDs7OztrQkFFSixPQUFPLFVBQ1I7Ozs7O1FBQ0osd0JBQUMsTUFBRCxZQUFLLE9BQU8sTUFBVTs7Ozs7UUFDdEIsd0JBQUMsTUFBRCxhQUFLLEtBQUssTUFBTSxPQUFPLGFBQWEsR0FBSSxHQUFFLEdBQUs7Ozs7O1FBQy9DLHdCQUFDLE1BQUQsWUFBSyxXQUFXLE9BQU8sU0FBUyxFQUFNOzs7OztPQUN4Qzs7OztrQkFFRjtRQUNJLHdCQUFDLE1BQUQsWUFBSyxXQUFXLE9BQU8sU0FBUyxFQUFNOzs7OztRQUN0Qyx3QkFBQyxNQUFEO1NBQUksV0FBVyxPQUFPLGNBQWMsWUFBWSxPQUFPLFlBQVksT0FBTzttQkFDckUsT0FBTyxjQUFjLFlBQVksWUFBWTtRQUM5Qzs7Ozs7UUFDSix3QkFBQyxNQUFELFlBQUssT0FBTyxNQUFVOzs7OztRQUN0Qix3QkFBQyxNQUFELGFBQUssS0FBSyxNQUFNLE9BQU8sYUFBYSxHQUFJLEdBQUUsR0FBSzs7Ozs7T0FDakQ7Ozs7O01BRU4sR0E1QkssT0FBTzs7OzthQTRCWjtLQUVaLENBQUMsRUFDRTs7OzthQUNKOzs7Ozs7R0FFVjs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVyxPQUFPO2NBQXZCO0tBQ0ksd0JBQUMsVUFBRDtNQUNJLFdBQVcsT0FBTztNQUNsQixVQUFVLFFBQVEsS0FBSztNQUN2QixlQUFlLFNBQVEsTUFBSyxJQUFJLENBQUM7Z0JBRWpDLHdCQUFDLE9BQUQ7T0FBSyxLQUFJO09BQWdELFdBQVcsR0FBRyxPQUFPLFNBQVMsR0FBRyxPQUFPO09BQWUsS0FBSTtNQUFROzs7OztLQUN4SDs7Ozs7S0FFUix3QkFBQyxRQUFEO01BQU0sT0FBTztPQUFFLE9BQU87T0FBUyxZQUFZO01BQU87Z0JBQWxEO09BQXFEO09BQU07T0FBSztPQUFLO01BQWlCOzs7Ozs7S0FFdEYsd0JBQUMsVUFBRDtNQUNJLFdBQVcsT0FBTztNQUNsQixVQUFVLFFBQVEsY0FBYztNQUNoQyxlQUFlLFNBQVEsTUFBSyxJQUFJLENBQUM7Z0JBRWpDLHdCQUFDLE9BQUQ7T0FBSyxLQUFJO09BQWdELFdBQVcsT0FBTztPQUFVLEtBQUk7TUFBUTs7Ozs7S0FDN0Y7Ozs7O0lBQ1A7Ozs7OztHQUVMLHdCQUFDLFVBQUQ7SUFBUSxXQUFXLE9BQU87SUFBYSxTQUFTO2NBQVM7R0FFakQ7Ozs7O0VBQ1A7Ozs7OztBQUdiIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxlYWRlcmJvYXJkU2NyZWVuLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZUxlYWRlcmJvYXJkLCB1c2VNYXRjaEhpc3RvcnkgfSBmcm9tICcuLi8uLi9mZWF0dXJlcy9tYXRjaGVzL2hvb2tzJztcclxuaW1wb3J0IHsgdXNlR2FtZVN0b3JlIH0gZnJvbSAnLi4vLi4vc3RvcmVzL2dhbWVTdG9yZSc7XHJcblxyXG5pbXBvcnQgeyB1c2VEaWFsb2cgfSBmcm9tICcuLi9ob29rcy91c2VEaWFsb2cnO1xyXG5cclxuaW1wb3J0IHN0eWxlcyBmcm9tICcuL0xlYWRlcmJvYXJkU2NyZWVuLm1vZHVsZS5jc3MnO1xyXG5cclxuaW50ZXJmYWNlIExlYWRlcmJvYXJkU2NyZWVuUHJvcHMge1xyXG4gICAgaW5pdGlhbFRhYjogJ3JhbmtpbmcnIHwgJ2hpc3RvcnknO1xyXG4gICAgb25DbG9zZTogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0RGF0ZShpc29TdHJpbmc6IHN0cmluZykge1xyXG4gICAgY29uc3QgZCA9IG5ldyBEYXRlKGlzb1N0cmluZyk7XHJcbiAgICBjb25zdCBtb250aHMgPSBbXCJKQU5cIiwgXCJGRUJcIiwgXCJNQVJcIiwgXCJBUFJcIiwgXCJNQVlcIiwgXCJKVU5cIiwgXCJKVUxcIiwgXCJBVUdcIiwgXCJTRVBcIiwgXCJPQ1RcIiwgXCJOT1ZcIiwgXCJERUNcIl07XHJcbiAgICBjb25zdCBkYXkgPSBTdHJpbmcoZC5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICBjb25zdCBtb250aCA9IG1vbnRoc1tkLmdldE1vbnRoKCldO1xyXG4gICAgY29uc3QgaG91cnMgPSBTdHJpbmcoZC5nZXRIb3VycygpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgY29uc3QgbWlucyA9IFN0cmluZyhkLmdldE1pbnV0ZXMoKSkucGFkU3RhcnQoMiwgJzAnKTtcclxuICAgIHJldHVybiBgJHtkYXl9ICR7bW9udGh9IC0gJHtob3Vyc306JHttaW5zfWA7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBMZWFkZXJib2FyZFNjcmVlbjogUmVhY3QuRkM8TGVhZGVyYm9hcmRTY3JlZW5Qcm9wcz4gPSAoeyBpbml0aWFsVGFiLCBvbkNsb3NlIH0pID0+IHtcclxuICAgIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTwncmFua2luZycgfCAnaGlzdG9yeSc+KGluaXRpYWxUYWIpO1xyXG4gICAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMSk7XHJcblxyXG4gICAgY29uc3Qgc2Vzc2lvblRpbWUgPSB1c2VHYW1lU3RvcmUocyA9PiBzLnNlc3Npb25UaW1lKTtcclxuICAgIGNvbnN0IHNwYXduSW50ZXJ2YWwgPSB1c2VHYW1lU3RvcmUocyA9PiBzLnNwYXduSW50ZXJ2YWwpO1xyXG4gICAgY29uc3QgY29uZmlnS2V5ID0gYCR7c2Vzc2lvblRpbWV9LSR7c3Bhd25JbnRlcnZhbH1gO1xyXG4gICAgY29uc3QgcGxheWVySWQgPSB1c2VHYW1lU3RvcmUocyA9PiBzLnBsYXllcklkKTtcclxuXHJcbiAgICBjb25zdCBkaWFsb2dSZWYgPSB1c2VEaWFsb2codHJ1ZSwgb25DbG9zZSk7XHJcblxyXG4gICAgY29uc3QgeyBkYXRhOiByYW5raW5nRGF0YSwgaXNMb2FkaW5nOiBsb2FkaW5nUmFua2luZywgaXNFcnJvcjogZXJyb3JSYW5raW5nLCByZWZldGNoOiByZWZldGNoUmFua2luZyB9ID0gdXNlTGVhZGVyYm9hcmQoY29uZmlnS2V5LCBwYWdlKTtcclxuICAgIGNvbnN0IHsgZGF0YTogaGlzdG9yeURhdGEsIGlzTG9hZGluZzogbG9hZGluZ0hpc3RvcnksIGlzRXJyb3I6IGVycm9ySGlzdG9yeSwgcmVmZXRjaDogcmVmZXRjaEhpc3RvcnkgfSA9IHVzZU1hdGNoSGlzdG9yeShwbGF5ZXJJZCwgcGFnZSk7XHJcblxyXG4gICAgY29uc3QgaXNMb2FkaW5nID0gYWN0aXZlVGFiID09PSAncmFua2luZycgPyBsb2FkaW5nUmFua2luZyA6IGxvYWRpbmdIaXN0b3J5O1xyXG4gICAgY29uc3QgaXNFcnJvciA9IGFjdGl2ZVRhYiA9PT0gJ3JhbmtpbmcnID8gZXJyb3JSYW5raW5nIDogZXJyb3JIaXN0b3J5O1xyXG4gICAgY29uc3QgcmVmZXRjaCA9IGFjdGl2ZVRhYiA9PT0gJ3JhbmtpbmcnID8gcmVmZXRjaFJhbmtpbmcgOiByZWZldGNoSGlzdG9yeTtcclxuICAgIGNvbnN0IGN1cnJlbnREYXRhID0gYWN0aXZlVGFiID09PSAncmFua2luZycgPyByYW5raW5nRGF0YSA6IGhpc3RvcnlEYXRhO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsUGFnZXMgPSBNYXRoLm1heCgxLCBNYXRoLmNlaWwoKGN1cnJlbnREYXRhPy50b3RhbCB8fCAwKSAvIDEwKSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlVGFiU3dpdGNoID0gKHRhYjogJ3JhbmtpbmcnIHwgJ2hpc3RvcnknKSA9PiB7XHJcbiAgICAgICAgaWYgKGFjdGl2ZVRhYiAhPT0gdGFiKSB7XHJcbiAgICAgICAgICAgIHNldEFjdGl2ZVRhYih0YWIpO1xyXG4gICAgICAgICAgICBzZXRQYWdlKDEpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7c3R5bGVzLmNhcmR9IHJlc3BvbnNpdmUtY2FyZGB9XHJcbiAgICAgICAgICAgIHJvbGU9XCJkaWFsb2dcIlxyXG4gICAgICAgICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWxsZWRieT1cImxlYWRlcmJvYXJkLXRpdGxlXCJcclxuICAgICAgICAgICAgcmVmPXtkaWFsb2dSZWZ9XHJcbiAgICAgICAgICAgIHRhYkluZGV4PXstMX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9e3N0eWxlcy50aXRsZX0+e2FjdGl2ZVRhYiA9PT0gJ3JhbmtpbmcnID8gJ0xlYWRlcmJvYXJkJyA6ICdNYXRjaCBIaXN0b3J5J308L2gxPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy50YWJCdXR0b25zfT5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2FjdGl2ZVRhYiA9PT0gJ3JhbmtpbmcnID8gc3R5bGVzLnRhYkFjdGl2ZSA6IHN0eWxlcy50YWJJbmFjdGl2ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUYWJTd2l0Y2goJ3JhbmtpbmcnKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBSYW5raW5nXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2FjdGl2ZVRhYiA9PT0gJ2hpc3RvcnknID8gc3R5bGVzLnRhYkFjdGl2ZSA6IHN0eWxlcy50YWJJbmFjdGl2ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUYWJTd2l0Y2goJ2hpc3RvcnknKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBIaXN0b3J5XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7YWN0aXZlVGFiID09PSAncmFua2luZycgPyAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e3N0eWxlcy5jYXRlZ29yeUluZm99PlxyXG4gICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uVGltZX1zIEJhdHRsZSAtIHtzcGF3bkludGVydmFsfXMgU3Bhd24gSW50ZXJ2YWxcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKSA6ICg8PjwvPil9XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnRhYmxlQ29udGFpbmVyfT5cclxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5sb2FkaW5nfT5Mb2FkaW5nIHJlY29yZHMuLi48L2Rpdj5cclxuICAgICAgICAgICAgICAgICkgOiBpc0Vycm9yID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZW1wdHl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBGYWlsZWQgdG8gbG9hZCByYW5raW5nIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT17c3R5bGVzLnBhZ2VCdXR0b259IG9uQ2xpY2s9eygpID0+IHJlZmV0Y2goKX0+UmV0cnk8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkgOiBjdXJyZW50RGF0YT8uZGF0YS5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5lbXB0eX0+Tm8gcmVjb3JkcyBmb3VuZC48L2Rpdj5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT17c3R5bGVzLnRhYmxlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdyYW5raW5nJyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD48dGg+UmFuazwvdGg+PHRoPlBsYXllcjwvdGg+PHRoPlNjb3JlPC90aD48dGg+VGltZTwvdGg+PHRoPkRhdGU8L3RoPjwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+PHRoPkRhdGU8L3RoPjx0aD5SZXN1bHQ8L3RoPjx0aD5TY29yZTwvdGg+PHRoPlRpbWU8L3RoPjwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudERhdGE/LmRhdGEubWFwKChyZWNvcmQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmFuayA9IChwYWdlIC0gMSkgKiAxMCArIGluZGV4ICsgMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0ZpcnN0UGxhY2UgPSBhY3RpdmVUYWIgPT09ICdyYW5raW5nJyAmJiByYW5rID09PSAxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyZWNvcmQuaWR9IGNsYXNzTmFtZT17cmVjb3JkLnBsYXllcklkID09PSBwbGF5ZXJJZCA/IHN0eWxlcy5oaWdobGlnaHRSb3cgOiAnJ30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAncmFua2luZycgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntyYW5rfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0ZpcnN0UGxhY2UgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPVwiL2Fzc2V0cy9wbmcvZGVmYXVsdC91aS9odWQvaWNvbl9zY29yZS5wbmdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJTdGFyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIwLCB2ZXJ0aWNhbEFsaWduOiAnbWlkZGxlJywgbWFyZ2luUmlnaHQ6IDYgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWNvcmQucGxheWVyTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntyZWNvcmQuc2NvcmV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntNYXRoLmZsb29yKHJlY29yZC5kdXJhdGlvbk1zIC8gMTAwMCl9czwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD57Zm9ybWF0RGF0ZShyZWNvcmQuY3JlYXRlZEF0KX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e2Zvcm1hdERhdGUocmVjb3JkLmNyZWF0ZWRBdCl9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT17cmVjb3JkLmVuZFJlYXNvbiA9PT0gJ3RpbWVfdXAnID8gc3R5bGVzLnRleHRHcmVlbiA6IHN0eWxlcy50ZXh0UmVkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWNvcmQuZW5kUmVhc29uID09PSAndGltZV91cCcgPyAnVmljdG9yeScgOiAnRGVmZWF0ZWQnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3JlY29yZC5zY29yZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e01hdGguZmxvb3IocmVjb3JkLmR1cmF0aW9uTXMgLyAxMDAwKX1zPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMucGFnaW5hdGlvbn0+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMucGFnZUJ1dHRvbn1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZSA8PSAxIHx8IGlzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYWdlKHAgPT4gcCAtIDEpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPVwiL2Fzc2V0cy9wbmcvZGVmYXVsdC91aS9jb250cm9scy9pY29uX3BsYXkucG5nXCIgY2xhc3NOYW1lPXtgJHtzdHlsZXMucGFnZUljb259ICR7c3R5bGVzLmljb25GbGlwcGVkfWB9IGFsdD1cIlByZXZcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgY29sb3I6ICd3aGl0ZScsIGZvbnRXZWlnaHQ6ICdib2xkJyB9fT5QYWdlIHtwYWdlfSBvZiB7dG90YWxQYWdlc308L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLnBhZ2VCdXR0b259XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UgPj0gdG90YWxQYWdlcyB8fCBpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFnZShwID0+IHAgKyAxKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz1cIi9hc3NldHMvcG5nL2RlZmF1bHQvdWkvY29udHJvbHMvaWNvbl9wbGF5LnBuZ1wiIGNsYXNzTmFtZT17c3R5bGVzLnBhZ2VJY29ufSBhbHQ9XCJOZXh0XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPXtzdHlsZXMuY2xvc2VCdXR0b259IG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICAgICAgQmFjayB0byBNZW51XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuXHJcbn07XHJcbiJdfQ==